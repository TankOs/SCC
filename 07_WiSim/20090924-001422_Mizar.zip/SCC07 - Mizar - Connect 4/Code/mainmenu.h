//mainmenu.h
#ifndef MYMAINMENU_H_2309
#define MYMAINMENU_H_2309

#include <vector>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "gamestate.h"

class MainMenu: public GameState {
	typedef std::vector<sf::Key::Code> SecretData;
	typedef SecretData::size_type SecretIndex;
public:
	// C'tor
	MainMenu(sf::RenderWindow &window);
	// virtual Destructor
	virtual ~MainMenu();
	// Methods
	virtual bool init();
	virtual GameState::State events();
	virtual void draw();
private:
	sf::Sprite m_title;
	sf::Sprite m_background;
	sf::String m_optionOnePlayer;
	sf::String m_optionTwoPlayer;
	sf::String m_optionQuit;
	sf::Color m_defaultColor;
	sf::Color m_highlightColor;
	sf::Clock m_randomTimer;
	sf::Vector2f m_mouse;
	sf::Sound m_secretSound;
	SecretData m_secretCode;
	SecretIndex m_secretIndex;
};


#endif // MYMAINMENU_H_2309