//main.cpp
#include "gameengine.h"

int main()
{
	GameEngine engine(sf::VideoMode(800, 600, 32), 30, "Connect 4 by Mizar", false);
	engine.mainloop(GameState::MAINMENU);

	return 0;
}