//mainmenu.cpp
#include "mainmenu.h"
#include "ressmanager.h"

// C'tor
MainMenu::MainMenu(sf::RenderWindow &window):
GameState(window),
m_defaultColor(sf::Color::White),
m_highlightColor(sf::Color::Yellow),
m_mouse(0.f, 0.f),
m_secretIndex(0)
{
	m_randomTimer.Reset();
	m_secretCode.push_back(sf::Key::Num4);		// O
	m_secretCode.push_back(sf::Key::Num8);		// c
	m_secretCode.push_back(sf::Key::Num1);		// e
	m_secretCode.push_back(sf::Key::Num5);		// a
	m_secretCode.push_back(sf::Key::Num1);		// n
	m_secretCode.push_back(sf::Key::Num6);		// i
	m_secretCode.push_back(sf::Key::Num2);		// c
	m_secretCode.push_back(sf::Key::Num3);		//
	m_secretCode.push_back(sf::Key::Num4);		// S
	m_secretCode.push_back(sf::Key::Num2);		// i
	m_secretCode.push_back(sf::Key::Return);	// x
}

MainMenu::~MainMenu()
{
	m_secretSound.Stop();
}

// Methods
bool MainMenu::init()
{
	if(!RessManager::instance().loadImage("img/strange_background.jpg") ||
	   !RessManager::instance().loadImage("img/connect_four_title.png")||
	   !RessManager::instance().loadSound("mus/sound3.ogg") ||
	   !RessManager::instance().loadFont("fon/Augusta.ttf")) {
		return false;
	}
	m_background.SetImage(*RessManager::instance().getImage("img/strange_background.jpg"));
	m_title.SetImage(*RessManager::instance().getImage("img/connect_four_title.png"));
	m_secretSound.SetBuffer(*RessManager::instance().getSound("mus/sound3.ogg"));
	m_optionOnePlayer.SetText("1 Player");
	m_optionTwoPlayer.SetText("2 Player");
	m_optionQuit.SetText("Quit");
	m_optionOnePlayer.SetFont(*RessManager::instance().getFont("fon/Augusta.ttf"));
	m_optionTwoPlayer.SetFont(*RessManager::instance().getFont("fon/Augusta.ttf"));
	m_optionQuit.SetFont(*RessManager::instance().getFont("fon/Augusta.ttf"));
	const float TEXTSIZE(40.f);
	m_optionOnePlayer.SetSize(TEXTSIZE);
	m_optionTwoPlayer.SetSize(TEXTSIZE);
	m_optionQuit.SetSize(TEXTSIZE);
	m_optionOnePlayer.SetPosition(m_window.GetWidth() * 0.5f - m_optionOnePlayer.GetRect().GetWidth() * 0.5f, m_window.GetHeight() * 0.6f);
	m_optionTwoPlayer.SetPosition(m_window.GetWidth() * 0.5f - m_optionTwoPlayer.GetRect().GetWidth() * 0.5f, m_window.GetHeight() * 0.7f);
	m_optionQuit.SetPosition(m_window.GetWidth() * 0.5f - m_optionQuit.GetRect().GetWidth() * 0.5f, m_window.GetHeight() * 0.8f);
	m_optionOnePlayer.SetColor(m_defaultColor);
	m_optionTwoPlayer.SetColor(m_defaultColor);
	m_optionQuit.SetColor(m_defaultColor);

	return true;
}

GameState::State MainMenu::events()
{
	sf::Event input;
	while(m_window.GetEvent(input)) {
		if(input.Type == sf::Event::Closed) {
			return QUIT;
		}

		if(input.Type == sf::Event::KeyPressed) {
			if(input.Key.Code == sf::Key::Escape) {
				return QUIT;
			} else if(input.Key.Code == m_secretCode[m_secretIndex]) {	// O
				++m_secretIndex;										// t
				if(m_secretIndex >= m_secretCode.size()) {				// h
					m_secretIndex = 0;									// e
					m_secretSound.Play();								// r
				}														//
			} else {													// M
				m_secretIndex = 0;										// a
			}															// n
		}

		if(input.Type == sf::Event::MouseMoved) {
			m_mouse.x = static_cast<float>(input.MouseMove.X);
			m_mouse.y = static_cast<float>(input.MouseMove.Y);
			if(m_optionOnePlayer.GetRect().Contains(m_mouse.x, m_mouse.y)) {
				m_optionOnePlayer.SetColor(m_highlightColor);
			} else {
				m_optionOnePlayer.SetColor(m_defaultColor);
			}
			if(m_optionTwoPlayer.GetRect().Contains(m_mouse.x, m_mouse.y)) {
				m_optionTwoPlayer.SetColor(m_highlightColor);
			} else {
				m_optionTwoPlayer.SetColor(m_defaultColor);
			}
			if(m_optionQuit.GetRect().Contains(m_mouse.x, m_mouse.y)) {
				m_optionQuit.SetColor(m_highlightColor);
			} else {
				m_optionQuit.SetColor(m_defaultColor);
			}
		}

		if(input.Type == sf::Event::MouseButtonPressed && input.MouseButton.Button == sf::Mouse::Left) {
			if(m_optionOnePlayer.GetRect().Contains(m_mouse.x, m_mouse.y)) {
				GameState::randomSeed() = static_cast<unsigned int>(m_randomTimer.GetElapsedTime() * 1000.f + m_mouse.x * 100.f + m_mouse.y * 10.f);
				return ONEPLAYERMODE;
			} else if(m_optionTwoPlayer.GetRect().Contains(m_mouse.x, m_mouse.y)) {
				return TWOPLAYERMODE;
			} else if(m_optionQuit.GetRect().Contains(m_mouse.x, m_mouse.y)) {
				return QUIT;
			}
		}
	}
	return MAINMENU;
}

void MainMenu::draw()
{
	m_window.Clear();
	m_window.Draw(m_background);
	m_window.Draw(m_title);
	m_window.Draw(m_optionOnePlayer);
	m_window.Draw(m_optionTwoPlayer);
	m_window.Draw(m_optionQuit);
	m_window.Display();
}