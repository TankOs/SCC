//playfield.h
#ifndef MYPLAYFIELD_H_0949
#define MYPLAYFIELD_H_0949

#include <vector>
#include <list>
#include "field.h"

struct PlayFieldIndex;
class PlayFieldIndexContainer;

class PlayField {
	typedef std::vector<Field> FieldData;
public:
	typedef FieldData::size_type SizeType;
	typedef FieldData::const_iterator ConstIter;
	// C'tor
	PlayField(const SizeType &columns, const SizeType rows):
	m_fields(columns * rows, Field(0.f, 0.f)), m_columns(columns), m_rows(rows)
	{ }
	// Getter
	Field::Status getFieldStatus(const SizeType &column, const SizeType &row) const;
	Field::Status getFieldStatus(const PlayFieldIndex &index) const;
	float getFieldPositionX(const SizeType &column, const SizeType &row) const;
	float getFieldPositionX(const PlayFieldIndex &index) const;
	float getFieldPositionY(const SizeType &column, const SizeType &row) const;
	float getFieldPositionY(const PlayFieldIndex &index) const;
	SizeType getColumns() const;
	SizeType getRows() const;
	// Setter
	void setPositions(const float &P1X, const float &P1Y, const float &OffsetX, const float &OffsetY);
	void setFieldStatus(const SizeType &column, const SizeType &row, const Field::Status status);
	void setFieldStatus(const PlayFieldIndex &index, const Field::Status status);
	void setFieldStatus(const PlayFieldIndexContainer &indices, const Field::Status status);
	// Methods
	ConstIter begin() const;
	ConstIter end() const;
private:
	FieldData m_fields;
	SizeType m_columns;
	SizeType m_rows;
};

struct PlayFieldIndex {
	// C'tor
	PlayFieldIndex(const PlayField::SizeType Column = 0, const PlayField::SizeType Row = 0):
	column(Column), row(Row)
	{ }
	// Member
	PlayField::SizeType column;
	PlayField::SizeType row;
};

class PlayFieldIndexContainer {
	typedef std::list<PlayFieldIndex> Indices;
public:
	typedef Indices::const_iterator ConstIter;
	// Methods
	void addIndex(const PlayField::SizeType column, const PlayField::SizeType row) { m_indices.push_back(PlayFieldIndex(column, row)); }
	void addIndex(const PlayFieldIndex &index) { m_indices.push_back(index); }
	void addIndex(const PlayFieldIndexContainer &container) { m_indices.insert(m_indices.begin(), container.m_indices.begin(), container.m_indices.end()); }
	void clear() { m_indices.clear(); }
	void size() { m_indices.size(); }
	ConstIter begin() const { return m_indices.begin(); }
	ConstIter end() const { return m_indices.end(); }
private:
	Indices m_indices;
};

#endif // MYPLAYFIELD_H_0949