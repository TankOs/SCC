//gameengine.cpp
#include "gameengine.h"

GameEngine::GameEngine(const sf::VideoMode &videomode, const unsigned int frames, const std::string &title, const bool fullscreen):
m_engineWindow(videomode, title, (fullscreen ? sf::Style::Fullscreen : sf::Style::Close)),
m_gamestate(0),
m_currentState(GameState::QUIT)
{
	m_engineWindow.SetFramerateLimit(frames);
}

GameEngine::~GameEngine()
{
	delete m_gamestate;
}

void GameEngine::mainloop(GameState::State loopState)
{
	while(loopState != GameState::QUIT) {
		if(!changeCurrentState(loopState)) {
			break;
		}
		while(m_currentState == loopState) {
			loopState = m_gamestate->events();
			m_gamestate->draw();
		}
	}
}

bool GameEngine::changeCurrentState(GameState::State newState)
{
	delete m_gamestate;
	m_gamestate = 0; // to prevent a second delete by the destructor
	m_currentState = newState;
	switch(m_currentState) {
		case GameState::MAINMENU:
			m_gamestate = new MainMenu(m_engineWindow);
			break;
		case GameState::ONEPLAYERMODE:
			m_gamestate = new OnePlayerMode(m_engineWindow);
			break;
		case GameState::TWOPLAYERMODE:
			m_gamestate = new TwoPlayerMode(m_engineWindow);
			break;
		default:
			return false;
	}
	return m_gamestate->init();
}