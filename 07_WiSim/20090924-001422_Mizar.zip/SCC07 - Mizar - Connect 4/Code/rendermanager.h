//rendermanager.h
#ifndef MYRENDERMANAGER_H_1026
#define MYRENDERMANAGER_H_1026

#include <SFML/Graphics.hpp>
#include "playfield.h"

class RenderManager {
public:
	// C'tor
	RenderManager(sf::RenderWindow &window):
	m_window(window)
	{ }
	// Getter
	sf::Vector2f getFieldImageSize() const;
	// Setter
	void setFieldImage(const sf::Image &image);
	void setFieldColors(const sf::Color &noneColor, const sf::Color &player1Color, const sf::Color &player2Color, const sf::Color &highlightColor);
	// Methods
	void draw(const Field &field);
	void draw(const PlayField &playfield);
private:
	sf::RenderWindow &m_window;
	sf::Sprite m_fieldSprite;
	sf::Color m_fieldNoneColor;
	sf::Color m_fieldPlayer1Color;
	sf::Color m_fieldPlayer2Color;
	sf::Color m_fieldHighlightedColor;
};

#endif // MYRENDERMANAGER_H_1026