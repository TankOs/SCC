//gamemode.h
#ifndef MYGAMEMODE_H_2207
#define MYGAMEMODE_H_2207

#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "gamestate.h"
#include "playfield.h"
#include "rendermanager.h"

class GameMode: public GameState {
public:
	// C'tor
	GameMode(sf::RenderWindow &window);
	// virtual Destructor
	virtual ~GameMode();
	// Methods
	virtual bool init();
	virtual GameState::State events() = 0;
	virtual void draw();
protected:
	enum InGameStates { INIT = 0, PLACE, FALL, END };
	// Member
	sf::Sprite m_background;
	PlayField m_playfield;
	PlayFieldIndex m_currentIndex;
	RenderManager m_renderManager;
	sf::Vector2f m_mouse;
	sf::Vector2f m_showPositionPlayer1;
	sf::Vector2f m_showPositionPlayer2;
	sf::String m_player1Text;
	sf::String m_player2Text;
	sf::String m_bottomText;
	sf::Sound m_clickSound;
	sf::Sound m_setSound;
	sf::Sound m_endSound;
	Field m_showTurnToken;
	const float m_TOKENSPEED;
	InGameStates m_currentState;
	Field::Status m_winningPlayer;
	bool m_isPlayerOnesTurn;
	// protected Methods
	void stopAllSounds();
	void setShowTurnTokenToActivePlayer();
	void setShowTurnTokenFallPosition();
	void updateText(const std::string &player1Text, const std::string &player2Text, const std::string &bottomText);
};

#endif // MYGAMEMODE_H_2207