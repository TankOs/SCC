//twoplayermode.h
#ifndef MYTWOPLAYERMODE_H_1436
#define MYTWOPLAYERMODE_H_1436

#include "gamemode.h"

class TwoPlayerMode: public GameMode {
public:
	// C'tor
	TwoPlayerMode(sf::RenderWindow &window);
	// Methods
	virtual GameState::State events();
};

#endif // MYTWOPLAYERMODE_H_1436