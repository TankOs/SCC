//rendermanager.cpp
#include "rendermanager.h"

sf::Vector2f RenderManager::getFieldImageSize() const
{
	return m_fieldSprite.GetSize();
}

void RenderManager::setFieldImage(const sf::Image &image)
{
	m_fieldSprite.SetImage(image);
}

void RenderManager::setFieldColors(const sf::Color &noneColor, const sf::Color &player1Color, const sf::Color &player2Color, const sf::Color &highlightColor)
{
	m_fieldNoneColor = noneColor;
	m_fieldPlayer1Color = player1Color;
	m_fieldPlayer2Color = player2Color;
	m_fieldHighlightedColor = highlightColor;
}

void RenderManager::draw(const Field &field)
{
	m_fieldSprite.SetPosition(field.x, field.y);
	switch(field.status) {
		case Field::NONE:
			m_fieldSprite.SetColor(m_fieldNoneColor);
			break;
		case Field::PLAYER1:
			m_fieldSprite.SetColor(m_fieldPlayer1Color);
			break;
		case Field::PLAYER2:
			m_fieldSprite.SetColor(m_fieldPlayer2Color);
			break;
		case Field::HIGHLIGHTED:
			m_fieldSprite.SetColor(m_fieldHighlightedColor);
			break;
		default:
			break;
	}
	m_window.Draw(m_fieldSprite);
}

void RenderManager::draw(const PlayField &playfield)
{
	for(PlayField::ConstIter beg(playfield.begin()), end(playfield.end()); beg != end; ++beg) {
		m_fieldSprite.SetPosition(beg->x, beg->y);
		switch(beg->status) {
			case Field::NONE:
				m_fieldSprite.SetColor(m_fieldNoneColor);
				break;
			case Field::PLAYER1:
				m_fieldSprite.SetColor(m_fieldPlayer1Color);
				break;
			case Field::PLAYER2:
				m_fieldSprite.SetColor(m_fieldPlayer2Color);
				break;
			case Field::HIGHLIGHTED:
				m_fieldSprite.SetColor(m_fieldHighlightedColor);
				break;
			default:
				break;
		}
		m_window.Draw(m_fieldSprite);
	}
}