//ressmanager.cpp
#include "ressmanager.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <string>

// Methods
bool RessManager::loadFont(const std::string &filename)
{
	if(m_font == 0) {
		m_font = new sf::Font;
		if(!m_font->LoadFromFile(filename)) {
			delete m_font;
			m_font = 0;
			return false;
		}
	}
	return true;
}

sf::Font* RessManager::getFont(const std::string &filename)
{
	if(loadFont(filename)) {
		return m_font;
	}
	return 0;
}

bool RessManager::loadImage(const std::string &filename)
{
	if(m_images[filename] == 0) {
		m_images[filename] = new sf::Image;
		if(!m_images[filename]->LoadFromFile(filename)) {
			delete m_images[filename];
			m_images[filename] = 0; // to prevent a second delete be the destructor
			return false;
		}
	}
	return true;
}

sf::Image* RessManager::getImage(const std::string &filename)
{
	if(loadImage(filename)) {
		return m_images[filename];
	}
	return 0;
}

bool RessManager::loadSound(const std::string &filename)
{
	if(m_sounds[filename] == 0) {
		m_sounds[filename] = new sf::SoundBuffer;
		if(!m_sounds[filename]->LoadFromFile(filename)) {
			delete m_sounds[filename];
			m_sounds[filename] = 0; // to prevent a second delete by the destructor
			return false;
		}
	}
	return true;
}

sf::SoundBuffer* RessManager::getSound(const std::string &filename)
{
	if(loadSound(filename)) {
		return m_sounds[filename];
	}
	return 0;
}

// Destructor
RessManager::~RessManager()
{
	delete m_font;

	for(ImageMap::iterator it(m_images.begin()), end(m_images.end()); it != end; ++it) {
		delete it->second;
	}

	for(SoundMap::iterator it(m_sounds.begin()), end(m_sounds.end()); it != end; ++it) {
		delete it->second;
	}
}