//gamestate.h
#ifndef MYGAMESTATE_H_2112
#define MYGAMESTATE_H_2112

#include <SFML/Graphics.hpp>

class GameState {
public:
	enum State { QUIT = 0, MAINMENU, ONEPLAYERMODE, TWOPLAYERMODE };
	// C'tor
	GameState(sf::RenderWindow &window): m_window(window) { }
	// virtual Destructor
	virtual ~GameState() { }
	// Methods
	virtual bool init() = 0;
	virtual State events() = 0;
	virtual void draw() = 0;
	static unsigned int& randomSeed() { static unsigned int seed; return seed; }
protected:
	sf::RenderWindow &m_window;
};

#endif // MYGAMESTATE_H_2112