//field.h
#ifndef MYFIELD_H_0944
#define MYFIELD_H_0944

struct Field {
	enum Status { NONE = 0, PLAYER1, PLAYER2, HIGHLIGHTED };
	// C'tor
	Field(const float &X = 0.f, const float &Y = 0.f, const Status initStatus = NONE):
	x(X), y(Y), status(initStatus)
	{ }
	// Member
	float x, y;
	Status status;
};

#endif // MYFIELD_H_0944