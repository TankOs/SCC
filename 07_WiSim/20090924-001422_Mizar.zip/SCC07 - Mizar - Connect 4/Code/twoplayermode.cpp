//twoplayermode.cpp
#include "twoplayermode.h"
#include "ingamefunctions.h"

// C'tor
TwoPlayerMode::TwoPlayerMode(sf::RenderWindow &window):
GameMode(window)
{ }

// Methods
GameState::State TwoPlayerMode::events()
{
	sf::Event input;
	while(m_window.GetEvent(input)) {
		if(input.Type == sf::Event::Closed) {
			return QUIT;
		}

		if(input.Type == sf::Event::KeyPressed) {
			switch(input.Key.Code) {
				case sf::Key::Escape:
					return MAINMENU;
					break;
				case sf::Key::Return:
					if(m_currentState == END)
						m_currentState = INIT;
					break;
				default:
					break;
			}
		}

		if(input.Type == sf::Event::MouseMoved) {
			m_mouse.x = static_cast<float>(input.MouseMove.X);
			m_mouse.y = static_cast<float>(input.MouseMove.Y);
		}

		if(m_currentState == PLACE && input.Type == sf::Event::MouseButtonPressed && input.MouseButton.Button == sf::Mouse::Left) {
			PlayFieldIndex tempIndex;
			if(isPointInPlayField(m_playfield, m_mouse, m_renderManager.getFieldImageSize(), &tempIndex)) {
				if(indexOfLowestRowInColumn(m_playfield, tempIndex.column, m_currentIndex)) {
					setShowTurnTokenFallPosition();
					m_clickSound.Play();
					m_currentState = FALL;
				}
			}
		}
	}

	switch(m_currentState) {
		case INIT:
			resetPlayField(m_playfield);
			m_isPlayerOnesTurn = true;
			setShowTurnTokenToActivePlayer();
			updateText("Player 1", "Player 2", "");
			m_currentState = PLACE;
			break;
		case FALL:
			m_showTurnToken.y += m_TOKENSPEED * m_window.GetFrameTime();
			if(m_showTurnToken.y >= m_playfield.getFieldPositionY(m_currentIndex)) {
				m_playfield.setFieldStatus(m_currentIndex, (m_isPlayerOnesTurn ? Field::PLAYER1 : Field::PLAYER2));
				m_setSound.Play();
				m_winningPlayer = fourInARowSingleCheck(m_playfield, m_currentIndex);
				if(m_winningPlayer != Field::NONE) {
					m_playfield.setFieldStatus(getFourInARowWinningFields(m_playfield, m_currentIndex), Field::HIGHLIGHTED);
					if(m_winningPlayer == Field::PLAYER1) {
						updateText("Winner", "Loser", "Press [RETURN] to start a new game.");
					} else {
						updateText("Loser", "Winner", "Press [RETURN] to start a new game.");
					}
					m_endSound.Play();
					m_currentState = END;
				} else if(isPlayFieldFull(m_playfield)) {
					updateText("Draw", "Draw", "Press [RETURN] to start a new game.");
					m_endSound.Play();
					m_currentState = END;
				} else {
					m_isPlayerOnesTurn = !m_isPlayerOnesTurn;
					m_currentState = PLACE;
				}
				setShowTurnTokenToActivePlayer();
			}
			break;
		default:
			break;
	}

	return TWOPLAYERMODE;
}