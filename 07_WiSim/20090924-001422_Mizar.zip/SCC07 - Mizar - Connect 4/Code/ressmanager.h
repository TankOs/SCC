//ressmanager.h
#ifndef MYRESSMANAGER_H_1936
#define MYRESSMANAGER_H_1936

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <map>
#include <string>

class RessManager {
public:
	// Singleton
	static RessManager& instance()
	{
		static RessManager single_instance;
		return single_instance;
	}
	// Methods
	// Font
	bool loadFont(const std::string &filename);
	sf::Font* getFont(const std::string &filename);
	// Images
	bool loadImage(const std::string &filename);
	sf::Image* getImage(const std::string &filename);
	// Sounds
	bool loadSound(const std::string &filename);
	sf::SoundBuffer* getSound(const std::string &filename);
	// Destructor
	~RessManager();
private:
	typedef std::map<std::string, sf::Image*> ImageMap;
	typedef std::map<std::string, sf::SoundBuffer*> SoundMap;
	// Member
	sf::Font *m_font;
	ImageMap m_images;
	SoundMap m_sounds;
	// Hidden C'tor, Copy C'tor and assignmentoperator
	RessManager(): m_font(0) { }
	RessManager(const RessManager &orig);
	RessManager& operator=(const RessManager &rhs);
};

#endif // MYRESSMANAGER_H_1936