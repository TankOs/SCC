//oneplayermode.h
#ifndef MYONEPLAYERMODE_H_1502
#define MYONEPLAYERMODE_H_1502

#include "gamemode.h"

class OnePlayerMode: public GameMode {
public:
	// C'tor
	OnePlayerMode(sf::RenderWindow &window);
	// Methods
	virtual GameState::State events();
private:
	float m_computerThinkTime;
	const float m_MAXTHINKTIME;
};

#endif // MYONEPLAYERMODE_H_1502