//ingamefunctions.h
#ifndef MYINGAMEFUNCTIONS_H_1343
#define MYINGAMEFUNCTIONS_H_1343

#include <SFML/Graphics.hpp>
#include "playfield.h"

Field::Status checkVertical(const PlayField &playfield, const PlayFieldIndex &lastSetField, PlayFieldIndexContainer *const winningFieldIndices = 0);
Field::Status checkHorizontal(const PlayField &playfield, const PlayFieldIndex &lastSetField, PlayFieldIndexContainer *const winningFieldIndices = 0);
Field::Status checkDiagonal1(const PlayField &playfield, const PlayFieldIndex &lastSetField, PlayFieldIndexContainer *const winningFieldIndices = 0);
Field::Status checkDiagonal2(const PlayField &playfield, const PlayFieldIndex &lastSetField, PlayFieldIndexContainer *const winningFieldIndices = 0);
Field::Status fourInARowSingleCheck(const PlayField &playfield, const PlayFieldIndex &lastSetField);
PlayFieldIndexContainer getFourInARowWinningFields(const PlayField &playfield, const PlayFieldIndex &lastSetField);
bool setLowestRowInColumn(PlayField &playfield, const PlayField::SizeType &column, const Field::Status status, PlayFieldIndex *const index = 0);
bool indexOfLowestRowInColumn(const PlayField &playfield, const PlayField::SizeType &column, PlayFieldIndex &index);
bool isPointInPlayField(const PlayField &playfield, const sf::Vector2f &point, const sf::Vector2f &fieldSize, PlayFieldIndex *const index);
bool isPlayFieldFull(const PlayField &playfield);
sf::FloatRect spriteRectangle(const float &x, const float &y, const sf::Vector2f &spriteSize);
void resetPlayField(PlayField &playfield);


#endif // MYINGAMEFUNCTIONS_H_1343