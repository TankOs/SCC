//gamemode.cpp
#include "gamemode.h"
#include "ressmanager.h"
#include "ingamefunctions.h"

// C'tor
GameMode::GameMode(sf::RenderWindow &window):
GameState(window), m_playfield(7, 6), m_renderManager(window), m_mouse(0.f, 0.f), m_TOKENSPEED(325.f),
m_currentState(INIT), m_winningPlayer(Field::NONE), m_isPlayerOnesTurn(true)
{ }

GameMode::~GameMode()
{
	stopAllSounds();
}

// Methods
bool GameMode::init()
{
	if(!RessManager::instance().loadImage("img/strange_background.jpg") ||
	   !RessManager::instance().loadImage("img/gametoken.png") ||
	   !RessManager::instance().loadSound("mus/sound1.ogg") ||
	   !RessManager::instance().loadSound("mus/sound2.ogg") ||
	   !RessManager::instance().loadSound("mus/sound4.ogg") ||
	   !RessManager::instance().loadFont("fon/Augusta.ttf")) {
		return false;
	}
	m_background.SetImage(*RessManager::instance().getImage("img/strange_background.jpg"));
	m_renderManager.setFieldImage(*RessManager::instance().getImage("img/gametoken.png"));
	m_clickSound.SetBuffer(*RessManager::instance().getSound("mus/sound1.ogg"));
	m_setSound.SetBuffer(*RessManager::instance().getSound("mus/sound2.ogg"));
	m_endSound.SetBuffer(*RessManager::instance().getSound("mus/sound4.ogg"));
	m_player1Text.SetFont(*RessManager::instance().getFont("fon/Augusta.ttf"));
	m_player2Text.SetFont(*RessManager::instance().getFont("fon/Augusta.ttf"));
	m_bottomText.SetFont(*RessManager::instance().getFont("fon/Augusta.ttf"));
	const float TEXTSIZE(30.f);
	m_player1Text.SetSize(TEXTSIZE);
	m_player2Text.SetSize(TEXTSIZE);
	m_bottomText.SetSize(TEXTSIZE);
	m_renderManager.setFieldColors(sf::Color::White, sf::Color::Red, sf::Color::Green, sf::Color::Yellow);
	const float DISTANCE(5.f);
	float topLeftX(m_window.GetWidth() * 0.5f - ((m_renderManager.getFieldImageSize().x + DISTANCE) * m_playfield.getColumns()) * 0.5f);
	float topLeftY(m_window.GetHeight() * 0.5f - ((m_renderManager.getFieldImageSize().y + DISTANCE) * m_playfield.getRows()) * 0.5f);
	m_playfield.setPositions(topLeftX, topLeftY, m_renderManager.getFieldImageSize().x + DISTANCE, m_renderManager.getFieldImageSize().y);
	m_showPositionPlayer1.x = DISTANCE;
	m_showPositionPlayer1.y = ((m_renderManager.getFieldImageSize().y + DISTANCE) * m_playfield.getRows()) * 0.5f;
	m_showPositionPlayer2.x = m_window.GetWidth() - m_renderManager.getFieldImageSize().x - DISTANCE;
	m_showPositionPlayer2.y = m_showPositionPlayer1.y;

	return true;
}

void GameMode::draw()
{
	m_window.Clear();
	m_window.Draw(m_background);
	m_renderManager.draw(m_playfield);
	m_window.Draw(m_player1Text);
	m_window.Draw(m_player2Text);
	m_window.Draw(m_bottomText);
	if(m_currentState != INIT)
		m_renderManager.draw(m_showTurnToken);
	m_window.Display();
}

void GameMode::stopAllSounds()
{
	m_clickSound.Stop();
	m_setSound.Stop();
	m_endSound.Stop();
}

void GameMode::setShowTurnTokenToActivePlayer()
{
	if(m_isPlayerOnesTurn) {
		m_showTurnToken.x = m_showPositionPlayer1.x;
		m_showTurnToken.y = m_showPositionPlayer1.y;
		m_showTurnToken.status = Field::PLAYER1;
	} else {
		m_showTurnToken.x = m_showPositionPlayer2.x;
		m_showTurnToken.y = m_showPositionPlayer2.y;
		m_showTurnToken.status = Field::PLAYER2;
	}
}

void GameMode::setShowTurnTokenFallPosition()
{
	m_showTurnToken.x = m_playfield.getFieldPositionX(m_currentIndex);
	m_showTurnToken.y = -m_renderManager.getFieldImageSize().y;
}

void GameMode::updateText(const std::string &player1Text, const std::string &player2Text, const std::string &bottomText)
{
	m_player1Text.SetText(player1Text);
	m_player2Text.SetText(player2Text);
	m_bottomText.SetText(bottomText);
	m_player1Text.SetPosition(0.f, 0.f);
	m_player2Text.SetPosition(m_window.GetWidth() - m_player2Text.GetRect().GetWidth(), 0.f);
	m_bottomText.SetPosition(m_window.GetWidth() * 0.5f - m_bottomText.GetRect().GetWidth() * 0.5f, m_window.GetHeight() * 0.9f);
}