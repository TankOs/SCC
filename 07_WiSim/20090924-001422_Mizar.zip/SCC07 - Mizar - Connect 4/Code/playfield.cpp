//playfield.cpp
#include "playfield.h"
#include <cmath>


Field::Status PlayField::getFieldStatus(const PlayField::SizeType &column, const PlayField::SizeType &row) const
{
	return m_fields[row * m_columns + column].status;
}

Field::Status PlayField::getFieldStatus(const PlayFieldIndex &index) const
{
	return m_fields[index.row * m_columns + index.column].status;
}

float PlayField::getFieldPositionX(const SizeType &column, const SizeType &row) const
{
	return m_fields[row * m_columns + column].x;
}

float PlayField::getFieldPositionX(const PlayFieldIndex &index) const
{
	return m_fields[index.row * m_columns + index.column].x;
}

float PlayField::getFieldPositionY(const SizeType &column, const SizeType &row) const
{
	return m_fields[row * m_columns + column].y;
}

float PlayField::getFieldPositionY(const PlayFieldIndex &index) const
{
	return m_fields[index.row * m_columns + index.column].y;
}

PlayField::SizeType PlayField::getColumns() const
{
	return m_columns;
}

PlayField::SizeType PlayField::getRows() const
{
	return m_rows;
}

void PlayField::setPositions(const float &P1X, const float &P1Y, const float &OffsetX, const float &OffsetY)
{
	for(SizeType column(0); column != m_columns; ++column) {
		float newX(P1X + (column * OffsetX));
		for(SizeType row(0); row != m_rows; ++row) {
			float newY(P1Y + (row * OffsetY));
			m_fields[row * m_columns + column].x = newX;
			m_fields[row * m_columns + column].y = newY;
		}
	}
}

void PlayField::setFieldStatus(const PlayField::SizeType &column, const PlayField::SizeType &row, const Field::Status status)
{
	m_fields[row * m_columns + column].status = status;
}

void PlayField::setFieldStatus(const PlayFieldIndex &index, const Field::Status status)
{
	m_fields[index.row * m_columns + index.column].status = status;
}

void PlayField::setFieldStatus(const PlayFieldIndexContainer &indices, const Field::Status status)
{
	for(PlayFieldIndexContainer::ConstIter beg(indices.begin()), end(indices.end()); beg != end; ++beg)
		setFieldStatus(*beg, status);
}

PlayField::ConstIter PlayField::begin() const
{
	return m_fields.begin();
}

PlayField::ConstIter PlayField::end() const
{
	return m_fields.end();
}