//ingamefunctions.cpp
#include "ingamefunctions.h"

Field::Status checkVertical(const PlayField &playfield, const PlayFieldIndex &lastSetField, PlayFieldIndexContainer *const winningFieldIndices)
{
	Field::Status player(playfield.getFieldStatus(lastSetField));
	if(winningFieldIndices != 0)
		winningFieldIndices->addIndex(lastSetField);
	int count(1);
	PlayField::SizeType nextIndex(lastSetField.row - 1); // up
	while(nextIndex >= 0 && nextIndex < playfield.getRows()) {
		if(playfield.getFieldStatus(lastSetField.column, nextIndex) != player)
			break;
		if(winningFieldIndices != 0)
			winningFieldIndices->addIndex(lastSetField.column, nextIndex);
		--nextIndex; // up
		++count;
	}
	nextIndex = lastSetField.row + 1; // down
	while(nextIndex < playfield.getRows()) {
		if(playfield.getFieldStatus(lastSetField.column, nextIndex) != player)
			break;
		if(winningFieldIndices != 0)
			winningFieldIndices->addIndex(lastSetField.column, nextIndex);
		++nextIndex; // down
		++count;
	}
	if(count >= 4)
		return player;
	if(winningFieldIndices != 0)
		winningFieldIndices->clear();
	return Field::NONE;
}

Field::Status checkHorizontal(const PlayField &playfield, const PlayFieldIndex &lastSetField, PlayFieldIndexContainer *const winningFieldIndices)
{
	Field::Status player(playfield.getFieldStatus(lastSetField));
	if(winningFieldIndices != 0)
		winningFieldIndices->addIndex(lastSetField);
	int count(1);
	PlayField::SizeType nextIndex(lastSetField.column - 1); // left
	while(nextIndex >= 0 && nextIndex < playfield.getColumns()) {
		if(playfield.getFieldStatus(nextIndex, lastSetField.row) != player)
			break;
		if(winningFieldIndices != 0)
			winningFieldIndices->addIndex(nextIndex, lastSetField.row);
		--nextIndex; // left
		++count;
	}
	nextIndex = lastSetField.column + 1; // right
	while(nextIndex < playfield.getColumns()) {
		if(playfield.getFieldStatus(nextIndex, lastSetField.row) != player)
			break;
		if(winningFieldIndices != 0)
			winningFieldIndices->addIndex(nextIndex, lastSetField.row);
		++nextIndex; // right
		++count;
	}
	if(count >= 4)
		return player;
	if(winningFieldIndices != 0)
		winningFieldIndices->clear();
	return Field::NONE;
}

Field::Status checkDiagonal1(const PlayField &playfield, const PlayFieldIndex &lastSetField, PlayFieldIndexContainer *const winningFieldIndices)
{
	Field::Status player(playfield.getFieldStatus(lastSetField));
	if(winningFieldIndices != 0)
		winningFieldIndices->addIndex(lastSetField);
	int count(1);
	// Go up left
	PlayField::SizeType nextRow(lastSetField.row - 1);
	PlayField::SizeType nextColumn(lastSetField.column - 1);
	while(nextRow >= 0 && nextRow < playfield.getRows() && nextColumn >= 0 && nextColumn < playfield.getColumns()) {
		if(playfield.getFieldStatus(nextColumn, nextRow) != player)
			break;
		if(winningFieldIndices != 0)
			winningFieldIndices->addIndex(nextColumn, nextRow);
		--nextRow;
		--nextColumn;
		++count;
	}
	// and now go down right
	nextRow = lastSetField.row + 1;
	nextColumn = lastSetField.column + 1;
	while(nextRow < playfield.getRows() && nextColumn < playfield.getColumns()) {
		if(playfield.getFieldStatus(nextColumn, nextRow) != player)
			break;
		if(winningFieldIndices != 0)
			winningFieldIndices->addIndex(nextColumn, nextRow);
		++nextRow;
		++nextColumn;
		++count;
	}
	if(count >= 4)
		return player;
	if(winningFieldIndices != 0)
		winningFieldIndices->clear();
	return Field::NONE;
}

Field::Status checkDiagonal2(const PlayField &playfield, const PlayFieldIndex &lastSetField, PlayFieldIndexContainer *const winningFieldIndices)
{
	Field::Status player(playfield.getFieldStatus(lastSetField));
	if(winningFieldIndices != 0)
		winningFieldIndices->addIndex(lastSetField);
	int count(1);
	// Go down left
	PlayField::SizeType nextRow(lastSetField.row + 1);
	PlayField::SizeType nextColumn(lastSetField.column - 1);
	while(nextRow < playfield.getRows() && nextColumn >= 0 && nextColumn < playfield.getColumns()) {
		if(playfield.getFieldStatus(nextColumn, nextRow) != player)
			break;
		if(winningFieldIndices != 0)
			winningFieldIndices->addIndex(nextColumn, nextRow);
		++nextRow;
		--nextColumn;
		++count;
	}
	// and now go up right
	nextRow = lastSetField.row - 1;
	nextColumn = lastSetField.column + 1;
	while(nextRow >= 0 && nextRow < playfield.getRows() && nextColumn < playfield.getColumns()) {
		if(playfield.getFieldStatus(nextColumn, nextRow) != player)
			break;
		if(winningFieldIndices != 0)
			winningFieldIndices->addIndex(nextColumn, nextRow);
		--nextRow;
		++nextColumn;
		++count;
	}
	if(count >= 4)
		return player;
	if(winningFieldIndices != 0)
		winningFieldIndices->clear();
	return Field::NONE;
}

Field::Status fourInARowSingleCheck(const PlayField &playfield, const PlayFieldIndex &lastSetField)
{
	Field::Status player = checkVertical(playfield, lastSetField);
	if(player != Field::NONE)
		return player;
	player = checkHorizontal(playfield, lastSetField);
	if(player != Field::NONE)
		return player;
	player = checkDiagonal1(playfield, lastSetField);
	if(player != Field::NONE)
		return player;
	player = checkDiagonal2(playfield, lastSetField);
	if(player != Field::NONE)
		return player;
	return Field::NONE;
}

PlayFieldIndexContainer getFourInARowWinningFields(const PlayField &playfield, const PlayFieldIndex &lastSetField)
{
	PlayFieldIndexContainer current, ret;
	checkVertical(playfield, lastSetField, &current);
	ret.addIndex(current);
	checkHorizontal(playfield, lastSetField, &current);
	ret.addIndex(current);
	checkDiagonal1(playfield, lastSetField, &current);
	ret.addIndex(current);
	checkDiagonal2(playfield, lastSetField, &current);
	ret.addIndex(current);
	return ret;
}

bool setLowestRowInColumn(PlayField &playfield, const PlayField::SizeType &column, const Field::Status status, PlayFieldIndex *const index)
{
	for(PlayField::SizeType row(playfield.getRows() - 1); row >= 0 && row < playfield.getRows(); --row) {
		if(playfield.getFieldStatus(column, row) == Field::NONE) {
			playfield.setFieldStatus(column, row, status);
			if(index != 0) {
				index->column = column;
				index->row = row;
			}
			return true;
		}
	}
	return false;
}

bool indexOfLowestRowInColumn(const PlayField &playfield, const PlayField::SizeType &column, PlayFieldIndex &index)
{
	for(PlayField::SizeType row(playfield.getRows() - 1); row >= 0 && row < playfield.getRows(); --row) {
		if(playfield.getFieldStatus(column, row) == Field::NONE) {
			index.column = column;
			index.row = row;
			return true;
		}
	}
	return false;
}

bool isPointInPlayField(const PlayField &playfield, const sf::Vector2f &point, const sf::Vector2f &fieldSize, PlayFieldIndex *const index)
{
	for(PlayField::ConstIter beg(playfield.begin()), end(playfield.end()); beg != end; ++beg) {
		if(spriteRectangle(beg->x, beg->y, fieldSize).Contains(point.x, point.y)) {
			if(index != 0) {
				PlayField::ConstIter::difference_type containerIndex = (playfield.getColumns() * playfield.getRows()) - (end - beg);
				index->row = containerIndex / playfield.getColumns();
				index->column = containerIndex % playfield.getColumns();
			}
			return true;
		}
	}
	return false;
}

bool isPlayFieldFull(const PlayField &playfield)
{
	for(PlayField::ConstIter beg(playfield.begin()), end(playfield.end()); beg != end; ++beg) {
		if(beg->status == Field::NONE) {
			return false;
		}
	}
	return true;
}

sf::FloatRect spriteRectangle(const float &x, const float &y, const sf::Vector2f &spriteSize)
{
	return sf::FloatRect(x, y, x + spriteSize.x, y + spriteSize.y);
}

void resetPlayField(PlayField &playfield)
{
	for(PlayField::SizeType column(0); column != playfield.getColumns(); ++column)
		for(PlayField::SizeType row(0); row != playfield.getRows(); ++row)
			playfield.setFieldStatus(column, row, Field::NONE);
}