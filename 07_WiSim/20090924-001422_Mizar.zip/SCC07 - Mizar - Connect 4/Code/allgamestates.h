//allgamestates.h
#ifndef ALLMYGAMESTATESTOGETHER_H_2138
#define ALLMYGAMESTATESTOGETHER_H_2138

// basic Gamestate-Class
#include "gamestate.h"
// derived Gamestate-Classes
#include "mainmenu.h"
#include "gamemode.h"
#include "oneplayermode.h"
#include "twoplayermode.h"

#endif // ALLMYGAMESTATESTOGETHER_H_2138