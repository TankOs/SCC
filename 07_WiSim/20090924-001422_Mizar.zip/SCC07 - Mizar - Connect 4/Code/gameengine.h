//gameengine.h
#ifndef MYGAMEENGINE_H_2137
#define MYGAMEENGINE_H_2137

#include <string>
#include <SFML/Graphics.hpp>
#include "allgamestates.h"

class GameEngine {
public:
	// C'tor
	GameEngine(const sf::VideoMode &videomode, const unsigned int frames, const std::string &title, const bool fullscreen = false);
	// Destructor
	~GameEngine();
	// Methods
	void mainloop(const GameState::State loopState);
private:
	sf::RenderWindow m_engineWindow;
	GameState *m_gamestate;
	GameState::State m_currentState;
	// hidden Copyconstructor & Assignmentoperator
	GameEngine(const GameEngine &orig);
	GameEngine& operator=(const GameEngine &rhs);
	// private Methods
	bool changeCurrentState(GameState::State newState);
};

#endif // MYGAMEENGINE_H_2137