  |             |             |
--*=============*=============*
  | Doodle Jumpy (SCC19 2011) |
--*===========================*

Allgemeines
===========
Bewegung: [<-] & [->]
Repo-ID: SFML-17971ca


Aufbau
======
main.cpp -------+
                |
cPlatform.cpp --+--> Doodle Jumpy.exe
                |
cPlatform.hpp --+


Lizenz zlib
===========
This software is provided 'as-is', without any express or implied warranty. In no event will the authors be held liable for any damages arising from the use of this software.

Permission is granted to anyone to use this software for any purpose, including commercial applications, and to alter it and redistribute it freely, subject to the following restrictions:

- The origin of this software must not be misrepresented; you must not claim that you wrote the original software. If you use this software in a product, an acknowledgment in the product documentation would be appreciated but is not required.
- Altered source versions must be plainly marked as such, and must not be misrepresented as being the original software.
- This notice may not be removed or altered from any source distribution.

--------------------------------------------------------------------

Diese Software wird ohne ausdr�ckliche oder implizierte Garantie bereitgestellt. In keinem Fall k�nnen die Autoren f�r irgendwelche Sch�den, die durch die Benutzung dieser Software entstanden sind, haftbar gemacht werden.

Es ist jedem gestattet, diese Software f�r jeden Zweck, inklusive kommerzieller Anwendungen, zu benutzen, zu ver�ndern und sie frei weiterzuverbreiten, sofern folgende Bedingungen erf�llt sind:

- Die Herkunft dieser Software darf nicht falsch dargestellt werden; Sie d�rfen nicht angeben, dass Sie die urspr�ngliche Software geschrieben haben. Wenn Sie diese Software in einem Produkt benutzten, w�rde eine Erw�hnung gesch�tzt werden, sie ist aber nicht erforderlich.
- Ver�nderte Quelltextversionen m�ssen deutlich als solche gekennzeichnet werden und d�rfen nicht als die Originalsoftware dargestellt werden.
- Diese Notiz darf in den Quelltexten nicht ver�ndert oder gel�scht werden.



Made by eXpl0it3r - Hosted by My-Gate.NET (http://sfml.my-gate.net/)