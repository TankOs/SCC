#include <sstream>
#include "player.h"
#include "level.h"

#ifndef FRAMEWORK_H
#define FRAMEWORK_H

class Framework
{
private:
	sf::RenderWindow &App;

	int gamestate;

	Player player;
	Level level;

	sf::Font BaseFont;
	sf::String Score;
	std::stringstream sScore;

	float points;
	sf::Image Ibackground;
	sf::Image Imenue;
	sf::Image Igameover;

	sf::Sprite background;
	sf::Sprite menue;
	sf::Sprite gameover;
	
public:
	Framework(sf::RenderWindow &window);
	void Reset();

	void Run();
	void Draw();
};


#endif