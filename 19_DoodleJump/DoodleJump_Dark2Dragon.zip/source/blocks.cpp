#include "blocks.h"

// Konstruktor
Blocks::Blocks(sf::Image &image, int state)
{
	block.SetImage(image);
	status=state;
	offset = 0;
	directionLeft = false;
}

// ChangeState
void Blocks::changeState(sf::Image &image, int state)
{
	status=state;
	if (status == 5)
		block.SetSubRect(sf::IntRect(0,0,83,30));

	block.SetImage(image);

}

// Draw
void Blocks::Draw(sf::RenderWindow &App) 
{
	fTimer = App.GetFrameTime();

	if (status == 2) {
		if (offset < RANGE && directionLeft == false) {
			block.Move(40*fTimer, 0);
			offset++;
		}
		if (offset > RANGE-1)
			directionLeft = true;
		if (offset > -RANGE && directionLeft == true) {
			block.Move(-40*fTimer, 0);
			offset--;
		}
		if (offset < -RANGE+1)
			directionLeft = false;
	}

	if (status == 3) {
		if (offset < RANGE && directionLeft == false) {
			block.Move(0, 40*fTimer);
			offset++;
		}
		if (offset > RANGE-1)
			directionLeft = true;
		if (offset > -RANGE && directionLeft == true) {
			block.Move(0, -40*fTimer);
			offset--;
		}
		if (offset < -RANGE+1)
			directionLeft = false;
	}

	App.Draw(block);
}
