#include "player.h"

// Konstruktor

Player::Player(sf::RenderWindow &window) :App(window)
{
	Iplayer.LoadFromFile("gfx/player.png");
	Iplayer.SetSmooth(false);

	player.SetImage(Iplayer);

	jumpHeight=0;
	bHighJump=false;

}

// Reset
void Player::reset(int xpos) {
	xpos = xpos+40-(player.GetSize().x/2);
	player.SetPosition(xpos, 600-(player.GetSize().y + 20));
}

// Move
void Player::move() 
{
	fTimer = App.GetFrameTime()*100;

	if (App.GetInput().IsKeyDown(sf::Key::Left)) {
		player.FlipX(true);

		if (player.GetPosition().x-(2*fTimer) < 0) 
			player.SetPosition(0, player.GetPosition().y);
		else	
			player.Move(-(2*fTimer),0);
	}

	if (App.GetInput().IsKeyDown(sf::Key::Right)) {
		player.FlipX(false);

		if (player.GetPosition().x+(2*fTimer) > App.GetWidth() - player.GetSize().x) 
			player.SetPosition(App.GetWidth() - player.GetSize().x, player.GetPosition().y);
		else	
			player.Move(2*fTimer,0);
	}

}

// Jump
int Player::Jump() 
{
	fTimer = App.GetFrameTime()*100;
	int maxHeight=35;
	int speed = -3;

	if (bHighJump == true)
	{
		maxHeight=70;
		speed = -6;
	}


	if (jumpHeight < maxHeight) 
	{
		jumpHeight++; 

		if (player.GetPosition().y > App.GetHeight()/2)
			player.Move(0, speed*fTimer);
		else
			return 1;
	}
	else
	{
		if (jumpHeight < maxHeight+3)
			jumpHeight++;
		else 
		{
			player.Move(0, 3*fTimer);
		}
	}

	return 0;
}

// New Jump
void Player::newJump(int highJump) 
{
	jumpHeight=0;
	player.Move(0, 10);

	if (highJump == 2)
		bHighJump=true;
}