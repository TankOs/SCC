#include <SFML/Graphics.hpp>


#ifndef PLAYER_H
#define PLAYER_H

class Player
{
private:
	sf::Image Iplayer;
	sf::Sprite player;

	int jumpHeight;
	float fTimer;
	bool bHighJump;

	sf::RenderWindow &App;

public:
	Player(sf::RenderWindow &window);
	void reset(int xpos);
	void move();
	int Jump();
	sf::Sprite getPlayer() {return player;}
	int getJumpHeight() {return jumpHeight;}
	void newJump(int highJump);
	bool getHighJump()	{return bHighJump;}
	void clearHighJump() {bHighJump=false;}
	void Draw() {App.Draw(player);}
};




#endif