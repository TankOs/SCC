#include <SFML/Graphics.hpp>

#ifndef BLOCKS_H
#define BLOCKS_H

#define RANGE 200

class Blocks
{
private:

	sf::Sprite block;
	int status;
	float fTimer;
	int offset;
	bool directionLeft;

public:
	Blocks(sf::Image &image, int state);
	void changeState(sf::Image &image, int state);
	void setpos(float xpos, float ypos) {block.SetPosition(xpos, ypos);}
	void move(float y_offset) {block.Move(0, y_offset);}
	int getState() {return status;}
	sf::Sprite getBlock() {return block;}
	void Draw(sf::RenderWindow &App);
};

#endif