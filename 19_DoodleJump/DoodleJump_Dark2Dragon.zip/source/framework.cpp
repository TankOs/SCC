#include "framework.h"

// Konstruktor
Framework::Framework(sf::RenderWindow &window) : App(window), player(window), level(window)
{
	Ibackground.LoadFromFile("gfx/background.png");
	Ibackground.SetSmooth(false);

	Imenue.LoadFromFile("gfx/menue.png");
	Imenue.SetSmooth(false);

	Igameover.LoadFromFile("gfx/gameover.png");
	Igameover.SetSmooth(false);
	
	background.SetImage(Ibackground);
	background.SetPosition(0,0);

	menue.SetImage(Imenue);
	menue.SetPosition(0,0);

	gameover.SetImage(Igameover);
	gameover.SetPosition(0,0);

	gamestate = 0;

	BaseFont.LoadFromFile("verdanab.ttf");
	
	Score.SetFont(BaseFont);
	Score.SetSize(20);
	Score.SetColor(sf::Color(0,0,0,255));
	Score.SetPosition(5, 5);
}

// Framework RESET
void Framework::Reset()
{
	points=0;
	level.clear();
	level.build();
	player.reset(level.getFirstXPos());
}


// Framework RUN
void Framework::Run()
{
	if(gamestate==1)
	{
		int collision;
		player.move();
		
		// JUMP
		if (player.Jump() == 1)
		{
			points++;
			level.move_up(player.getHighJump());
		}

		// Check Collision
		if (player.getJumpHeight() > 34) {
			collision = level.checkCollision(player.getPlayer());
			if (collision > 0) {
				player.clearHighJump();
				player.newJump(collision);
			}
		}

		// Check GameOver
		if (player.getPlayer().GetPosition().y > 610)
			gamestate = 2;

		level.add_blocks();
		level.remove_blocks();

		sScore.str("");
		sScore << points;
		Score.SetText(sScore.str());
	}
	else
	{
		if (App.GetInput().IsKeyDown(sf::Key::Return)) {
			gamestate = 1;
			Reset();
		}
	}
}

// Framework DRAW
void Framework::Draw() 
{
	App.Draw(background);
	level.Draw();
	player.Draw();
	App.Draw(Score);

	if (gamestate == 0)
		App.Draw(menue);

	if (gamestate == 2)
		App.Draw(gameover);
}

