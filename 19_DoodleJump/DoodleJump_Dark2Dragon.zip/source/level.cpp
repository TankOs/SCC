#include "level.h"

// Konstruktor
Level::Level(sf::RenderWindow &window) :App(window)
{
	IBlock1.LoadFromFile("gfx/Block1.png");
	IBlock1.SetSmooth(false);

	IBlock2.LoadFromFile("gfx/Block2.png");
	IBlock2.SetSmooth(false);

	IBlock3.LoadFromFile("gfx/Block3.png");
	IBlock3.SetSmooth(false);

	IBlock4.LoadFromFile("gfx/Block4.png");
	IBlock4.SetSmooth(false);

	IBlock5.LoadFromFile("gfx/Block5.png");
	IBlock5.SetSmooth(false);

	RandomBlockEnable=false;
}

void Level::build() 
{
	Blocks newBlock(IBlock1, 1);
	sf::Randomizer random;

	int xpos = App.GetWidth() - newBlock.getBlock().GetSize().x;
	xpos = random.Random(0, xpos);
	newBlock.setpos(xpos, 580);
	LevelStruct.push_back(newBlock);

	for (int i=1; i<6; i++) 
	{
		xpos = random.Random(xpos - 100, xpos + 100);
		
		if (xpos < 0)
			xpos = 0;
		
		if (xpos > App.GetWidth() - newBlock.getBlock().GetSize().x)
			xpos = App.GetWidth() - newBlock.getBlock().GetSize().x;

		newBlock.setpos(xpos, i*100);	
		LevelStruct.push_back(newBlock);
	
	}	
}


// Bl�cke hinzuf�gen
void Level::add_blocks()
{
	std::list<Blocks>::iterator lIter=LevelStruct.end();
	lIter--;
	sf::Randomizer random;

	// letzter Block darf kein Durchbruch sein!
	while (lIter->getState() == 4)
		lIter--;

	if (lIter->getBlock().GetPosition().y > 100) {
		Blocks newBlock(IBlock1, 1);

		int xpos = random.Random(lIter->getBlock().GetPosition().x - 75, lIter->getBlock().GetPosition().x + 75);
		
		if (xpos < 0)
			xpos = 0;
		
		if (xpos > App.GetWidth() - newBlock.getBlock().GetSize().x)
			xpos = App.GetWidth() - newBlock.getBlock().GetSize().x;
			
		newBlock.setpos(xpos, -20);
		LevelStruct.push_back(newBlock);
	}	
	else {
		if (random.Random(1,30) == 10 && RandomBlockEnable==true) {

			Blocks newBlock2(IBlock1, 1);

			switch(random.Random(0,4))
			{		
				case 1:
					newBlock2.changeState(IBlock2, 2);
					break;
				case 2:
					newBlock2.changeState(IBlock3, 3);
					break;
				case 3:
					newBlock2.changeState(IBlock4, 4);
					break;
				case 4:
					newBlock2.changeState(IBlock5, 5);
					break;
			}
			
			int MaxRandom = App.GetWidth() - newBlock2.getBlock().GetSize().x;
			MaxRandom = random.Random(0, MaxRandom);
			newBlock2.setpos(random.Random(0, MaxRandom), -20);

			// check Collision
			if (simpleCollision(newBlock2.getBlock(), lIter->getBlock()) == 0) {
				LevelStruct.push_back(newBlock2);
				RandomBlockEnable=false;
			}		
		}
	}

}


// Bl�cke unterhalb des Bildschirms entfernen
void Level::remove_blocks() 
{
	std::list<Blocks>::iterator lIter;

	for (lIter=LevelStruct.begin(); lIter!=LevelStruct.end(); ) {
		
		if (lIter->getBlock().GetPosition().y > 610)
			lIter = LevelStruct.erase(lIter);
		else
			lIter++;
	}
}

// Draw
void Level::Draw()
{
	std::list<Blocks>::iterator lIter;

	for (lIter=LevelStruct.begin(); lIter!=LevelStruct.end(); ) {
		lIter->Draw(App);
		lIter++;
	}
}

// Level Move Up
void Level::move_up(bool highJump) 
{
	int speed = 3;

	if (highJump == true)
		speed = 6;

	fTimer = App.GetFrameTime()*100;
	std::list<Blocks>::iterator lIter;

	for (lIter=LevelStruct.begin(); lIter!=LevelStruct.end(); ) {
		lIter->move(speed*fTimer);
		lIter++;
	}

	RandomBlockEnable=true;
}

// Erste XPosition (f�r Player) liefern
int Level::getFirstXPos() 
{
	std::list<Blocks>::iterator lIter=LevelStruct.begin();

	return lIter->getBlock().GetPosition().x;
}

// Check Collision
int Level::checkCollision(sf::Sprite &player)
{
	std::list<Blocks>::iterator lIter;
	bool noIncrement=false;

	for (lIter=LevelStruct.begin(); lIter!=LevelStruct.end(); ) {
		
		if (simpleCollision(player, lIter->getBlock()) == 1)
		{
			if (lIter->getState() == 4) {
				lIter = LevelStruct.erase(lIter);
				noIncrement = true;
			}
			else
			{
				if (lIter->getState() == 5)
					return 2;
				else
					return 1;
			}
		}

		if (noIncrement == false)
			lIter++;
		else
			noIncrement = false;
	}

	return 0;
}