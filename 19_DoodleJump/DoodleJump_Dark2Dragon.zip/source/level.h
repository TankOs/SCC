#include <list>
#include <SFML/Graphics.hpp>
#include "player.h"
#include "collision.h"
#include "blocks.h"

#ifndef LEVEL_H
#define LEVEL_H

class Level
{
private:
	sf::Image IBlock1;
	sf::Image IBlock2;
	sf::Image IBlock3;
	sf::Image IBlock4;
	sf::Image IBlock5;

	sf::RenderWindow &App;

	std::list<Blocks> LevelStruct;
	float fTimer;
	bool RandomBlockEnable;

public:
	Level(sf::RenderWindow &window);
	void clear() {LevelStruct.clear();}
	void build();
	void add_blocks();
	void remove_blocks();
	void move_up(bool highJump);
	int getFirstXPos();
	int checkCollision(sf::Sprite &player);
	void Draw();
};




#endif