// DJ
////////////////////////////////////////////////////////////
// Dark2Dragon 2011
// V 0.1b

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

#include "framework.h"

int main()
{
	// ### Main Window ###
	sf::RenderWindow App(sf::VideoMode(400, 600, 16), "DJ");

	App.SetFramerateLimit(60);
	App.ShowMouseCursor(false);

	sf::Event Event;
	Framework gameEngine(App);
	
	// RESET
	gameEngine.Reset();

	while (App.IsOpened())
    {  

		// Process events
        while (App.GetEvent(Event))
        {
			// Close window: exit
            if (Event.Type == sf::Event::Closed)
                App.Close();

			// KeyEvents abfangen
			if (Event.Type == sf::Event::KeyPressed)
			{
			
				// Escape key: exit
                if (Event.Key.Code == sf::Key::Escape)
                    App.Close();	
			}	     
		}

		// Framework RUN
		gameEngine.Run();

		// DRAW
		gameEngine.Draw();

		App.Display();
		App.Clear();
	
	}

	return 0;
}

