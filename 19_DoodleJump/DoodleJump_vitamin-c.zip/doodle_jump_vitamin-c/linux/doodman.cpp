#include "doodman.hpp"

Doodman::Doodman(sf::RenderWindow *App)
{
	this->App=App;
	Position.x=200;
	Position.y=300;
	
	RM.AddImage("test.png");
	RM.AddSprite("test.png","Right",sf::IntRect(100,0,50,50));
	RM.AddSprite("test.png","Left",sf::IntRect(100,0,50,50));
	
	Right=new Animation(App,Position,40,Alignment::Middle);
	Left=new Animation(App,Position,40,Alignment::Middle);
	Right->AddSprite(RM.GetSprite("Right"));
	Left->AddSprite(RM.GetSprite("Left"));
	
	BoundingBox.Width=50;
	BoundingBox.Height=1;
	BoundingBox.Left=Position.x-25;
	BoundingBox.Top=Position.y+24;
	
	SmokeOn=false;
	SmokeTimer=0;
	
	JumpBuffer.LoadFromFile("jump.wav");
	JumpSound.SetBuffer(JumpBuffer);
	
	HyperJumpBuffer.LoadFromFile("hyperjump.wav");
	HyperJumpSound.SetBuffer(HyperJumpBuffer);
	
	Jump();
}

void Doodman::Jump()
{
	Velocity.y=-500;
	JumpSound.Play();
}

void Doodman::HyperJump()
{
	Velocity.y=-1000;
	SmokeOn=true;
	SmokeTimer=90;
	HyperJumpSound.Play();
}

void Doodman::Move(int Direction)
{
	if(Direction==Direction::Left){
		Velocity.x-=10;
		if(Velocity.x<-200)
			Velocity.x=-200;
	}else if(Direction==Direction::Right){
		Velocity.x+=10;
		if(Velocity.x>200)
			Velocity.x=200;
	}
}

void Doodman::Draw()
{
	//Position updaten
	Position.x+=Velocity.x*((float)App->GetFrameTime()/1000);
	Position.y+=Velocity.y*((float)App->GetFrameTime()/1000);
	
	//Partikelsystem
	if(SmokeOn){
		for(int i=0;i<10;i++)
			lParticel.push_back(new Particel(App,sf::Vector2f(Position.x,Position.y)));
		SmokeTimer--;
		if(SmokeTimer==0)
			SmokeOn=false;
	}
	for(std::list<Particel*>::iterator i=lParticel.begin();i!=lParticel.end();i++){
		(*i)->Handle();
		if((*i)->Age==(*i)->LiveSpan)
			i=lParticel.erase(i);
	}
	
	//Animation und BoundingBox updaten
	Right->Position=Position;
	Left->Position=Position;
	BoundingBox.Width=50;
	BoundingBox.Height=1;
	BoundingBox.Left=Position.x-25;
	BoundingBox.Top=Position.y+25;
	
	//Zeichnen
	if(Velocity.x>0)
		Right->Draw();
	else
		Left->Draw();
	
	//Geschwindigkeitsänderung(keine Physik^^)
	Velocity.y+=10;
	if(Position.x>App->GetWidth()){
		Position.x-=App->GetWidth();
	}else if(Position.x<0){
		Position.x+=App->GetWidth();
	}
}