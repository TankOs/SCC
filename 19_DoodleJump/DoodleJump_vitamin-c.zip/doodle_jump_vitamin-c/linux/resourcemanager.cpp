#include "resourcemanager.hpp"

void ResourceManager::AddImage(std::string File)
{
	sf::Image Image;
	if(!Image.LoadFromFile(File))
		exit(EXIT_FAILURE);
	std::pair<std::map<std::string, sf::Image>::iterator, bool> p;
	p=Images.insert(std::pair<std::string, sf::Image>(File, Image));
	if(!p.second)
		exit(EXIT_FAILURE);
	UpdateSprites();
}

void ResourceManager::AddSprite(std::string File,std::string Name,sf::IntRect SubRect)
{
	sf::Sprite Sprite;
	{
		std::map<std::string, sf::Image>::iterator i;
		i=Images.find(File);
		if(i==Images.end())
			exit(EXIT_FAILURE);
		Sprite.SetImage(i->second);
	}
	{
		std::pair<std::map<std::string,std::string>::iterator,bool> p;
		p=SpritesSource.insert(std::pair<std::string, std::string>(Name, File));
		if(!p.second)
			exit(EXIT_FAILURE);
	}
	Sprite.SetSubRect(SubRect);
	{
		std::pair<std::map<std::string,sf::Sprite>::iterator,bool> p;
		p=Sprites.insert(std::pair<std::string, sf::Sprite>(Name, Sprite));
		if(!p.second)
			exit(EXIT_FAILURE);
	}
}

void ResourceManager::UpdateSprites()
{
	for(std::map<std::string,sf::Sprite>::iterator i=Sprites.begin();i!=Sprites.end();i++)
	{
		std::map<std::string, std::string>::iterator iSpritesSource;
		iSpritesSource=SpritesSource.find(i->first);
		if(iSpritesSource==SpritesSource.end())
			exit(EXIT_FAILURE);
		std::map<std::string, sf::Image>::iterator iImages;
		iImages=Images.find(iSpritesSource->second);
		if(iImages==Images.end())
			exit(EXIT_FAILURE);
		i->second.SetImage(iImages->second);
	}
}

sf::Sprite* ResourceManager::GetSprite(std::string Name)
{
	std::map<std::string,sf::Sprite>::iterator i;
	i=Sprites.find(Name);
	if(i!=Sprites.end())
		return &(i->second);
	return NULL;
}

