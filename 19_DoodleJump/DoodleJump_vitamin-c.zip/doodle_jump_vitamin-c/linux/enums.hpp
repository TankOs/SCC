#ifndef ENUMS_HPP
#define ENUMS_HPP

namespace Alignment
{
	enum
	{
		TopLeft,
		Top,
		TopRight,
		MiddleLeft,
		Middle,
		MiddleRight,
		BottomLeft,
		Bottom,
		BottomRight
	};
}

namespace Direction
{
	enum
	{
		Up,
		Down,
		Left,
		Right
	};
}

namespace State
{
	enum
	{
		Dead,
		Alive
	};
}

namespace Platt
{
	enum
	{
		Plattform,
		HyperPlattform,
		hMovingPlattform,
		HyperhMovingPlattform,
		BadPlattform
	};
}

#endif