#ifndef RESOURCEMANAGER_HPP
#define RESOURCEMANAGER_HPP

#include <SFML/Graphics.hpp>
#include <map>

class ResourceManager
{
	public:
		void AddImage(std::string File);
		void AddSprite(std::string File,std::string Name,sf::IntRect SubRect);
		void UpdateSprites();
		sf::Sprite* GetSprite(std::string Name);
	private:
		std::map<std::string,sf::Image> Images;
		std::map<std::string,sf::Sprite> Sprites;
		std::map<std::string,std::string> SpritesSource;
};

#endif
