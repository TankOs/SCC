#include "gamemanager.hpp"

GameManager::GameManager(sf::RenderWindow *App)
{
	Dm=new Doodman(App);
	View.Reset(sf::FloatRect(0,0,App->GetWidth(),App->GetHeight()));
	LastViewCenter=View.GetCenter();
	
	RM.AddImage("test.png");
	RM.AddSprite("test.png","Plattform",sf::IntRect(0,75,50,10));
	RM.AddSprite("test.png","HyperPlattform",sf::IntRect(150,53,50,32));
	RM.AddSprite("test.png","hMovingPlattform",sf::IntRect(50,75,50,10));
	RM.AddSprite("test.png","HyperhMovingPlattform",sf::IntRect(100,53,50,32));
	RM.AddSprite("test.png","BadPlattform",sf::IntRect(0,85,50,10));
	RM.AddSprite("test.png","BadPlattformBroken",sf::IntRect(0,104,50,20));
	
	for(int y=620;y>=20;y-=30)
		Plattforms.push_back(new Plattform(App,this,sf::Vector2f(rand()%(int)View.GetSize().x,y)));
}

void GameManager::HandleObjects()
{
	for(std::list<Plattform*>::iterator it=Plattforms.begin();it!=Plattforms.end();it++){
		(*it)->Draw();
		(*it)->IsCollision();
	}
	Dm->Draw();
}

void GameManager::UpdateView()
{
	if(Dm->Velocity.y<0&&Dm->Position.y<LastViewCenter.y){
		View.SetCenter(View.GetCenter().x,Dm->Position.y);
		LastViewCenter=View.GetCenter();
	}
}
