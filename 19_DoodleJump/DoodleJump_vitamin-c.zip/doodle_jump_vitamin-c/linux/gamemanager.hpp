#ifndef GAMEMANAGER_HPP
#define GAMEMANAGER_HPP

#include <SFML/Graphics.hpp>
#include <cstdio>
#include <list>
#include "resourcemanager.hpp"
#include "animation.hpp"
#include "doodman.hpp"
#include "plattform.hpp"

class Plattform;

class GameManager
{
public:
	GameManager(sf::RenderWindow *App);
	void HandleObjects();
	void UpdateView();
	Doodman *Dm;
	sf::View View;
	std::list<Plattform*> Plattforms;
	ResourceManager RM;
private:
	sf::RenderWindow *App;
	sf::Vector2f LastViewCenter;
};

#endif