#include "plattform.hpp"

Plattform::Plattform(sf::RenderWindow *App,GameManager *GM,sf::Vector2f Position)
{
	this->App			= App;
	this->GM			= GM;
	this->Position		= Position;
	Sprite				= GM->RM.GetSprite("Plattform");
	
	BoundingBox.Width	= 50;
	BoundingBox.Height	= 10;
	BoundingBox.Left	= Position.x-BoundingBox.Width;
	BoundingBox.Top		= Position.y-BoundingBox.Height;
}

void Plattform::IsCollision()
{
	if(BoundingBox.Intersects(GM->Dm->BoundingBox)&&GM->Dm->Velocity.y>0)
		GM->Dm->Jump();
}

void Plattform::Draw()
{
	Sprite->SetPosition(BoundingBox.Left,BoundingBox.Top);
	App->Draw(*Sprite);
}

/////////////////////////////////////////////////////////////////////////

HyperPlattform::HyperPlattform(sf::RenderWindow *App,GameManager *GM,sf::Vector2f Position)
:Plattform(App,GM,Position)
{
	Sprite = GM->RM.GetSprite("HyperPlattform");
}

void HyperPlattform::IsCollision()
{
	if(BoundingBox.Intersects(GM->Dm->BoundingBox)&&GM->Dm->Velocity.y>0)
		GM->Dm->HyperJump();
}

void HyperPlattform::Draw()
{
	Sprite->SetPosition(BoundingBox.Left,BoundingBox.Top-22);
	App->Draw(*Sprite);
}

/////////////////////////////////////////////////////////////////////////

hMovingPlattform::hMovingPlattform(sf::RenderWindow *App,GameManager *GM,sf::Vector2f Position,float Velocity)
:Plattform(App,GM,Position)
{
	if(Position.x<(App->GetWidth()/2))
		MovingDirection = true;
	else
		MovingDirection = false;
	
	hOffset			= 0;
	this->Velocity	= Velocity;
	Sprite			= GM->RM.GetSprite("hMovingPlattform");
}

void hMovingPlattform::Move()
{
	if(MovingDirection){
		hOffset+=Velocity*((float)App->GetFrameTime()/1000);
		if(Position.x+hOffset>(App->GetWidth())){
			MovingDirection=false;
		}
	}else{
		hOffset-=Velocity*((float)App->GetFrameTime()/1000);
		if(Position.x+hOffset<50){
			MovingDirection=true;
		}
	}
}

void hMovingPlattform::IsCollision()
{
	if(sf::FloatRect(BoundingBox.Left+hOffset,BoundingBox.Top,BoundingBox.Width,BoundingBox.Height).Intersects(GM->Dm->BoundingBox)&&GM->Dm->Velocity.y>0)
		GM->Dm->Jump();
}

void hMovingPlattform::Draw()
{
	Move();
	Sprite->SetPosition(BoundingBox.Left+hOffset,BoundingBox.Top);
	App->Draw(*Sprite);
}

/////////////////////////////////////////////////////////////////////////

HyperhMovingPlattform::HyperhMovingPlattform(sf::RenderWindow *App,GameManager *GM,sf::Vector2f Position,float Velocity)
:hMovingPlattform(App,GM,Position,Velocity)
{
	Sprite = GM->RM.GetSprite("HyperhMovingPlattform");
}

void HyperhMovingPlattform::IsCollision()
{
	if(sf::FloatRect(BoundingBox.Left+hOffset,BoundingBox.Top,BoundingBox.Width,BoundingBox.Height).Intersects(GM->Dm->BoundingBox)&&GM->Dm->Velocity.y>0)
		GM->Dm->HyperJump();
}

void HyperhMovingPlattform::Draw()
{
	Move();
	Sprite->SetPosition(BoundingBox.Left+hOffset,BoundingBox.Top-22);
	App->Draw(*Sprite);
}

/////////////////////////////////////////////////////////////////////////

BadPlattform::BadPlattform(sf::RenderWindow *App,GameManager *GM,sf::Vector2f Position)
:Plattform(App,GM,Position)
{
	Sprite			= GM->RM.GetSprite("BadPlattform");
	SpriteBroken	= GM->RM.GetSprite("BadPlattformBroken");
	Velocity		= 200;
	Broken			= false;
}

void BadPlattform::Move()
{
	if(Broken){
		BoundingBox.Top+=Velocity*((float)App->GetFrameTime()/1000);
	}
}

void BadPlattform::IsCollision()
{
	if(sf::FloatRect(BoundingBox.Left,BoundingBox.Top,BoundingBox.Width,BoundingBox.Height).Intersects(GM->Dm->BoundingBox)&&GM->Dm->Velocity.y>0){
		Broken=true;;
	}
}

void BadPlattform::Draw()
{
	Move();
	if(Broken){
		SpriteBroken->SetPosition(BoundingBox.Left,BoundingBox.Top);
		App->Draw(*SpriteBroken);
	}else{
		Sprite->SetPosition(BoundingBox.Left,BoundingBox.Top);
		App->Draw(*Sprite);
	}
}