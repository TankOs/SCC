#include "animation.hpp"

Animation::Animation(sf::RenderWindow *App,sf::Vector2f Position,int TimePerSprite,int Alignment)
{
	this->App			= App;
	this->Position		= Position;
	this->TimePerSprite	= TimePerSprite;
	this->Alignment		= Alignment;
	Time				= 0;
}

void Animation::AddSprite(sf::Sprite *Sprite)
{
	Sprites.push_back(Sprite);
	it=Sprites.begin();
}

void Animation::Draw()
{
	while(Time>=TimePerSprite){
		Time=Time-TimePerSprite;
		it++;
		if(it==Sprites.end())
			it=Sprites.begin();
	}
	(*it)->SetPosition(Position);
	switch(Alignment){
		case Alignment::TopLeft:break;
		case Alignment::Middle:(*it)->Move(sf::Vector2f(-(*it)->GetSize().x/2,-(*it)->GetSize().y/2));break;
	}
	App->Draw(**it);
	Time+=App->GetFrameTime();
}