#ifndef ANIMATION_HPP
#define ANIMATION_HPP

#include <SFML/Graphics.hpp>
#include <list>
#include "enums.hpp"

class Animation
{
public:
	Animation(sf::RenderWindow *App,sf::Vector2f Position,int TimePerSprite,int Alignment);
	void AddSprite(sf::Sprite *Sprite);
	void Draw();
	sf::Vector2f Position;
private:
	sf::RenderWindow *App;
	int Alignment;
	std::list<sf::Sprite*> Sprites;
	std::list<sf::Sprite*>::iterator it;
	int TimePerSprite;	//Time in milliseconds
	int Time;
};

#endif