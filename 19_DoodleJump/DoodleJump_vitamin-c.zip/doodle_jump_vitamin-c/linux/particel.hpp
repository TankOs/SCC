#ifndef PARTICEL_HPP
#define PARTICEL_HPP

#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <ctime>
#include <iostream>

class Particel
{
	public:
		Particel(sf::RenderWindow *App,sf::Vector2f Position);
		void Handle();
		void Draw();
		void Move();
		int LiveSpan;
		int Age;
	private:
		sf::RenderWindow *App;
		sf::Vector2f Position;
		sf::Vector2f Velocity;
		sf::Color StartColor;
		sf::Color EndColor;
		sf::Color Color;
		int Size;
};

#endif
