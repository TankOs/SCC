#include "particel.hpp"

Particel::Particel(sf::RenderWindow *App,sf::Vector2f Position)
{
	this->App		= App;
	this->Position	= Position;
	
	int r1=rand()%2;
	if(r1==0)
		r1=rand()%100;
	else{
		r1=rand()%100;
		r1*=-1;
	}
	int r2=rand()%2;
	if(r2==0)
		r2=rand()%100;
	else{
		r2=rand()%100;
		r2*=-1;
	}
	
	Velocity.x=(float)r1/150;
	Velocity.y=(float)r2/150;
	
	StartColor.r	= 25;
	StartColor.g 	= 25;
	StartColor.b 	= 25;
	StartColor.a	= 255;
	
	EndColor.r		= 255;
	EndColor.g 		= 255;
	EndColor.b 		= 255;
	EndColor.a		= 0;
	
	Size 			= 5;
	LiveSpan		= 50;
	Age				= 0;
}

void Particel::Handle()
{
	Age++;
	Draw();
	Move();
}

void Particel::Draw()
{
	App->Draw(sf::Shape::Circle(Position.x,Position.y,Size,Color));
	//App->Draw(sf::Shape::Rectangle(Position.x,Position.y,Size,Size,Color));
}

void Particel::Move()
{
	float ElapsedTime=App->GetFrameTime();
	Position.x+=Velocity.x;
	Position.y+=Velocity.y;
	
	Color.r = StartColor.r + ((float)(EndColor.r - StartColor.r)/(float)LiveSpan*(float)Age);
	Color.g = StartColor.g + ((float)(EndColor.g - StartColor.g)/(float)LiveSpan*(float)Age);
	Color.b = StartColor.b + ((float)(EndColor.b - StartColor.b)/(float)LiveSpan*(float)Age);
	Color.a = StartColor.a + ((float)(EndColor.a - StartColor.a)/(float)LiveSpan*(float)Age);
}
