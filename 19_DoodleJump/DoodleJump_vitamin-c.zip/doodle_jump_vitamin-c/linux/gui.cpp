#include "gui.hpp"

////////////////////////////////////////////////////////////////

gui::Button::Button(sf::RenderWindow *App,sf::Vector2f Position,int Alignment)
{
	this->App		= App;
	this->Position	= Position;
	this->Alignment	= Alignment;
	Clicked			= false;
	MouseOver		= false;
	Buffer.LoadFromFile("mouseover.wav");
	Sound.SetBuffer(Buffer);
}

bool gui::Button::OnClick()
{
	if(OnMouseOver()){
		const sf::Input& Input=App->GetInput();
		if(Input.IsMouseButtonDown(sf::Mouse::Left)&&!Clicked){
			Clicked=true;
			Sound.Play();
			return true;
		}else if(!Input.IsMouseButtonDown(sf::Mouse::Left)){
			Clicked=false;
		}
	}
	return false;
}

////////////////////////////////////////////////////////////////

gui::TextButton::TextButton
(	sf::RenderWindow *App,
	sf::Vector2f Position,
	int Alignment,
	sf::Text TextMouseOut,
	sf::Text TextMouseOver)
:Button(App,Position,Alignment)
{
	this->TextMouseOut=TextMouseOut;
	this->TextMouseOut.SetPosition(Position);
	this->TextMouseOver=TextMouseOver;
	this->TextMouseOver.SetPosition(Position);
	
	sf::FloatRect RectMouseOut=TextMouseOut.GetRect();
	sf::FloatRect RectMouseOver=TextMouseOver.GetRect();
	
	switch(Alignment){
		case Alignment::TopLeft:	break;
		case Alignment::Middle:
		{
			this->TextMouseOut.Move(sf::Vector2f(-RectMouseOut.Width/2,-RectMouseOut.Height/2));
			this->TextMouseOver.Move(sf::Vector2f(-RectMouseOver.Width/2,-RectMouseOver.Height/2));
			break;
		}
	}
}

bool gui::TextButton::OnMouseOver()
{
	const sf::Input& Input=App->GetInput();
	if(!MouseOver){
		if(TextMouseOut.GetRect().Contains(Input.GetMouseX(),Input.GetMouseY())){
			MouseOver=true;
			return true;
		}
	}else if(MouseOver){
		if(TextMouseOver.GetRect().Contains(Input.GetMouseX(),Input.GetMouseY())){
			return true;
		}
	}
	MouseOver=false;
	return false;
}

void gui::TextButton::Draw()
{
	if(OnMouseOver()){
		App->Draw(TextMouseOver);
	}else{
		App->Draw(TextMouseOut);
	}
}

////////////////////////////////////////////////////////////////

gui::ImageButton::ImageButton
(	sf::RenderWindow *App,
	sf::Vector2f Position,
	int Alignment,
	sf::Sprite *SpriteMouseOut,
	sf::Sprite *SpriteMouseOver)
:Button(App,Position,Alignment)
{
	this->SpriteMouseOut	= SpriteMouseOut;
	this->SpriteMouseOver	= SpriteMouseOver;
}

void gui::ImageButton::UpdatePosition()
{
	SpriteMouseOut->SetPosition(Position);
	SpriteMouseOver->SetPosition(Position);
	
	sf::IntRect RectMouseOut=SpriteMouseOut->GetSubRect();
	sf::IntRect RectMouseOver=SpriteMouseOver->GetSubRect();
	switch(Alignment){
		case Alignment::TopLeft:	break;
		case Alignment::Middle:
		{
			SpriteMouseOut->Move(sf::Vector2f(-RectMouseOut.Width/2,-RectMouseOut.Height/2));
			SpriteMouseOver->Move(sf::Vector2f(-RectMouseOver.Width/2,-RectMouseOver.Height/2));
			break;
		}
	}
}

bool gui::ImageButton::OnMouseOver()
{
	UpdatePosition();
	const sf::Input& Input=App->GetInput();
	if(!MouseOver){
		if(sf::FloatRect(SpriteMouseOut->GetPosition().x,SpriteMouseOut->GetPosition().y,SpriteMouseOut->GetSize().x,SpriteMouseOut->GetSize().y).Contains(Input.GetMouseX(),Input.GetMouseY())){
			MouseOver=true;
			return true;
		}
	}else if(MouseOver){
		if(sf::FloatRect(SpriteMouseOver->GetPosition().x,SpriteMouseOver->GetPosition().y,SpriteMouseOver->GetSize().x,SpriteMouseOver->GetSize().y).Contains(Input.GetMouseX(),Input.GetMouseY())){
			return true;
		}
	}
	MouseOver=false;
	return false;
}

void gui::ImageButton::Draw()
{
	UpdatePosition();
	if(OnMouseOver()){
		App->Draw(*SpriteMouseOver);
	}else{
		App->Draw(*SpriteMouseOut);
	}
}
