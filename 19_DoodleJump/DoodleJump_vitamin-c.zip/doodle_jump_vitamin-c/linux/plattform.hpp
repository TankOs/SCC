#ifndef PLATTFORM_HPP
#define PLATTFORM_HPP

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "enums.hpp"
#include "animation.hpp"
#include "gamemanager.hpp"

class GameManager;

class Plattform
{
public:
	Plattform(sf::RenderWindow *App,GameManager *GM,sf::Vector2f Position);
	virtual void IsCollision();
	virtual void Draw();
	sf::Vector2f Position;
protected:
	sf::RenderWindow *App;
	GameManager *GM;
	sf::FloatRect BoundingBox;
	sf::Sprite *Sprite;
};

class HyperPlattform :public Plattform
{
public:
	HyperPlattform(sf::RenderWindow *App,GameManager *GM,sf::Vector2f Position);
	virtual void IsCollision();
	virtual void Draw();
};

class hMovingPlattform :public Plattform
{
public:
	hMovingPlattform(sf::RenderWindow *App,GameManager *GM,sf::Vector2f Position,float Velocity);
	virtual void Move();
	virtual void IsCollision();
	virtual void Draw();
protected:
	float hOffset;
	float Velocity;
	bool MovingDirection;
};

class HyperhMovingPlattform :public hMovingPlattform
{
public:
	HyperhMovingPlattform(sf::RenderWindow *App,GameManager *GM,sf::Vector2f Position,float Velocity);
	virtual void IsCollision();
	virtual void Draw();
};

class BadPlattform :public Plattform
{
public:
	BadPlattform(sf::RenderWindow *App,GameManager *GM,sf::Vector2f Position);
	virtual void Move();
	virtual void IsCollision();
	virtual void Draw();
protected:
	float vPosition;
	float Velocity;
	bool Broken;
	sf::Sprite *SpriteBroken;
};

#endif
