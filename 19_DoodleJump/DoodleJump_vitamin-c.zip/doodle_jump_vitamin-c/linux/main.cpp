#include <SFML/Graphics.hpp>
#include <cstdio>
#include <cstring>
#include <ctime>
#include "resourcemanager.hpp"
#include "gamemanager.hpp"
#include "gui.hpp"
#include "enums.hpp"
#include "animation.hpp"

void fGameOver(sf::RenderWindow *App,int Score)
{
	App->SetView(App->GetDefaultView());
	ResourceManager RM;
	RM.AddImage("background.png");
	RM.AddSprite("background.png","background",sf::IntRect(0,0,400,600));
	RM.AddImage("buttons.png");
	RM.AddSprite("buttons.png","MainMenueOut",sf::IntRect(0,250,300,40));
	RM.AddSprite("buttons.png","MainMenueOver",sf::IntRect(0,550,312,42));
	RM.AddSprite("buttons.png","ExitOut",sf::IntRect(0,200,300,40));
	RM.AddSprite("buttons.png","ExitOver",sf::IntRect(0,500,312,42));
	gui::ImageButton MainMenue(App,sf::Vector2f(200,490),Alignment::Middle,RM.GetSprite("MainMenueOut"),RM.GetSprite("MainMenueOver"));
	gui::ImageButton Exit(App,sf::Vector2f(200,550),Alignment::Middle,RM.GetSprite("ExitOut"),RM.GetSprite("ExitOver"));
	char buffer[255];
	sprintf(buffer,"You got %i Points",Score);
	sf::Text tScore1;
	tScore1.SetColor(sf::Color(0,0,0));
	tScore1.SetString("Game Over!");
	tScore1.SetPosition(50,50);
	sf::Text tScore2;
	tScore2.SetColor(sf::Color(0,0,0));
	tScore2.SetString(buffer);
	tScore2.SetPosition(50,100);
	
	FILE *Highscore;
	if((Highscore=fopen("Highscore.txt","a+"))==NULL)
		exit(EXIT_FAILURE);
	fprintf(Highscore,"%i\n",Score);
	fclose(Highscore);
	
	while(App->IsOpened()){
		sf::Event Event;
		while(App->PollEvent(Event)){
			if(Event.Type==sf::Event::Closed)
				App->Close();
		}
		App->Draw(*RM.GetSprite("background"));
		App->Draw(tScore1);
		App->Draw(tScore2);
		MainMenue.Draw();
		if(MainMenue.OnClick())
			break;
		Exit.Draw();
		if(Exit.OnClick())
			exit(EXIT_SUCCESS);
		App->Display();
	}
}

void fGame(sf::RenderWindow *App)
{
	ResourceManager RM;
	
	//Background
	RM.AddImage("background_game.png");
	RM.AddSprite("background_game.png","background",sf::IntRect(0,0,400,600));
	
	//Score
	sf::Text Score("0",sf::Font::GetDefaultFont(),25);
	Score.SetColor(sf::Color(0,0,0));
	char Buffer[255];
	float iScore=0;
	Score.SetPosition(sf::Vector2f(0,0));
	
	//Game
	GameManager GM(App);
	int LastPlattform=Platt::Plattform;
	float MaxDistance=30;
	
	while(App->IsOpened()){
		sf::Event Event;
		while(App->PollEvent(Event)){
			if(Event.Type==sf::Event::Closed)
				App->Close();
		}
		if (App->GetInput().IsKeyDown(sf::Key::Left)){
			GM.Dm->Move(Direction::Left);
		}else if (App->GetInput().IsKeyDown(sf::Key::Right)){
			GM.Dm->Move(Direction::Right);
		}
		
		App->SetView(GM.View);
		
		//GameOver?
		if(GM.Dm->Position.y>(GM.View.GetCenter().y+GM.View.GetSize().y/2)){
			fGameOver(App,iScore);
			break;
		}
		
		//Background
		RM.GetSprite("background")->SetSubRect(sf::IntRect(0,3400+(GM.View.GetCenter().y-GM.View.GetSize().y/2)/20,400,600));
		RM.GetSprite("background")->SetPosition
			(GM.View.GetCenter().x-GM.View.GetSize().x/2,
			GM.View.GetCenter().y-GM.View.GetSize().y/2);
			
		//Plattformen löschen und neue einfügen
		int NewPlattforms=0;
		for(std::list<Plattform*>::iterator it=GM.Plattforms.begin();it!=GM.Plattforms.end();it++){
			if(((*it)->Position.y)>GM.View.GetCenter().y+GM.View.GetSize().y/2){
				it=GM.Plattforms.erase(it);
				NewPlattforms++;
			}
		}
		for(int i=0;i<NewPlattforms;i++){
			std::list<Plattform*>::iterator it=GM.Plattforms.end();it--;
			sf::Vector2f PositionLastPlattform=(*it)->Position;
			int c=rand()%99;
			//Plattform
			if(c>=0&&c<30){
				GM.Plattforms.push_back(new Plattform
				(	App,
					&GM,
					sf::Vector2f(rand()%((int)App->GetWidth()-50)+50,PositionLastPlattform.y-MaxDistance)));
				LastPlattform=Platt::Plattform;
			}
			//BadPlattform
			else if(c>=30&&c<60){
				if(LastPlattform==Platt::BadPlattform){
					NewPlattforms++;
				}else{
					GM.Plattforms.push_back(new BadPlattform
					(	App,
						&GM,
						sf::Vector2f(rand()%((int)App->GetWidth()-50)+50,PositionLastPlattform.y-MaxDistance)));
					LastPlattform=Platt::BadPlattform;
				}
			}
			//hMovingPlattform
			else if(c>=60&&c<97){
				GM.Plattforms.push_back(new hMovingPlattform
				(	App,
					&GM,
					sf::Vector2f(rand()%((int)App->GetWidth()-50)+25,PositionLastPlattform.y-MaxDistance),
					75+iScore/750));
				LastPlattform=Platt::hMovingPlattform;
			}
			//HyperhMovingPlattform
			else if(c>=97&&c<98){
				GM.Plattforms.push_back(new HyperhMovingPlattform
				(	App,
					&GM,
					sf::Vector2f(rand()%((int)App->GetWidth()-50)+25,PositionLastPlattform.y-MaxDistance),
					75+iScore/750));
				LastPlattform=Platt::HyperhMovingPlattform;
			}
			//HyperPlattform
			else if(c>=98&&c<100){
				GM.Plattforms.push_back(new HyperPlattform
				(	App,
					&GM,
					sf::Vector2f(rand()%((int)App->GetWidth()-50)+50,PositionLastPlattform.y-MaxDistance)));
				LastPlattform=Platt::HyperPlattform;
			}
		}
		App->Draw(*RM.GetSprite("background"));
		GM.HandleObjects();
		
		//Score
		if(-(GM.Dm->Position.y)>iScore)
			iScore=-(GM.Dm->Position.y);
		sprintf(Buffer,"%i",(int)iScore);
		Score.SetString(Buffer);
		Score.SetPosition(5,GM.View.GetCenter().y-300);
		MaxDistance=30+iScore/500;
		App->Draw(Score);
		
		GM.UpdateView();
		App->Display();
	}
}

//nachdem ich im forum gelesen hab das Dark2Dragon einen Highscore hat,
//hab ich auch mal einen gemacht^^
int Sort(const void *x,const void *y){
	return (*(int*)y-*(int*)x);
}
void fHighscore(sf::RenderWindow *App)
{
	FILE *Highscore;
	char buffer[255];
	int Scores[255];
	int i=0;
	if((Highscore=fopen("Highscore.txt","r")) == NULL)
		exit(EXIT_FAILURE);
	while(fgets(buffer,255,Highscore)){
		if(i==255)
			break;
		Scores[i]=atoi(buffer);
		i++;
	}
	fclose(Highscore);
	qsort(Scores,i,sizeof(int),Sort);
	if((Highscore=fopen("Highscore.txt","w")) == NULL)
		exit(EXIT_FAILURE);
	for(int j=0;j<i;j++)
		fprintf(Highscore,"%i\n",Scores[j]);
	fclose(Highscore);
	//////////////////////////////////////////////////////
	ResourceManager RM;
	RM.AddImage("background.png");
	RM.AddSprite("background.png","background",sf::IntRect(0,0,400,600));
	RM.AddImage("buttons.png");
	RM.AddSprite("buttons.png","MainMenueOut",sf::IntRect(0,250,300,40));
	RM.AddSprite("buttons.png","MainMenueOver",sf::IntRect(0,550,312,42));
	gui::ImageButton MainMenue(App,sf::Vector2f(200,550),Alignment::Middle,RM.GetSprite("MainMenueOut"),RM.GetSprite("MainMenueOver"));
	sf::Text Caption;
	Caption.SetColor(sf::Color(0,0,0));
	Caption.SetString("Highscore");
	Caption.SetPosition(sf::Vector2f(50,30));
	Caption.SetCharacterSize(40);
	sf::Text Score;
	Score.SetColor(sf::Color(0,0,0));
	while(App->IsOpened()){
		sf::Event Event;
		while(App->PollEvent(Event)){
			if(Event.Type==sf::Event::Closed)
				App->Close();
		}
		App->Draw(*RM.GetSprite("background"));
		App->Draw(Caption);
		for(int j=0;j<13;j++){
			if(j<9)
				sprintf(buffer,"%i :\t%i",j+1,Scores[j]);
			else
				sprintf(buffer,"%i:\t%i",j+1,Scores[j]);
			Score.SetString(buffer);
			Score.SetPosition(sf::Vector2f(50,30*j+100));
			App->Draw(Score);
		}
		MainMenue.Draw();
		if(MainMenue.OnClick())
			break;
		App->Display();
	}
}

void fTutorial(sf::RenderWindow *App)
{
	ResourceManager RM;
	RM.AddImage("tutorial.png");
	RM.AddSprite("tutorial.png","tutorial",sf::IntRect(0,0,400,600));
	RM.AddImage("buttons.png");
	RM.AddSprite("buttons.png","MainMenueOut",sf::IntRect(0,250,300,40));
	RM.AddSprite("buttons.png","MainMenueOver",sf::IntRect(0,550,312,42));
	gui::ImageButton MainMenue(App,sf::Vector2f(200,550),Alignment::Middle,RM.GetSprite("MainMenueOut"),RM.GetSprite("MainMenueOver"));
	while(App->IsOpened()){
		sf::Event Event;
		while(App->PollEvent(Event)){
			if(Event.Type==sf::Event::Closed)
				App->Close();
		}
		App->Draw(*RM.GetSprite("tutorial"));
		MainMenue.Draw();
		if(MainMenue.OnClick())
			break;
		App->Display();
	}
}

void fAbout(sf::RenderWindow *App)
{
	ResourceManager RM;
	RM.AddImage("about.png");
	RM.AddSprite("about.png","about",sf::IntRect(0,0,400,600));
	RM.AddImage("buttons.png");
	RM.AddSprite("buttons.png","MainMenueOut",sf::IntRect(0,250,300,40));
	RM.AddSprite("buttons.png","MainMenueOver",sf::IntRect(0,550,312,42));
	gui::ImageButton MainMenue(App,sf::Vector2f(200,550),Alignment::Middle,RM.GetSprite("MainMenueOut"),RM.GetSprite("MainMenueOver"));
	while(App->IsOpened()){
		sf::Event Event;
		while(App->PollEvent(Event)){
			if(Event.Type==sf::Event::Closed)
				App->Close();
		}
		App->Draw(*RM.GetSprite("about"));
		MainMenue.Draw();
		if(MainMenue.OnClick())
			break;
		App->Display();
	}
}

int main(int argc,char **argv)
{
	sf::RenderWindow App(sf::VideoMode(400,600,32),"Sky Jump");
	App.SetFramerateLimit(60);
	srand(time(NULL));
	
	/*sf::Music Music;
	Music.OpenFromFile("music.wav");
	Music.SetLoop(true);
	Music.Play();*/
	
	ResourceManager RM;
	RM.AddImage("background.png");
	RM.AddSprite("background.png","background",sf::IntRect(0,0,400,600));
	
	RM.AddImage("skyjump.png");
	RM.AddSprite("skyjump.png","skyjump",sf::IntRect(0,0,400,200));
	
	RM.AddImage("buttons.png");
	RM.AddSprite("buttons.png","StartGameOut",sf::IntRect(0,0,300,40));
	RM.AddSprite("buttons.png","StartGameOver",sf::IntRect(0,300,312,42));
	RM.AddSprite("buttons.png","HighscoreOut",sf::IntRect(0,50,300,40));
	RM.AddSprite("buttons.png","HighscoreOver",sf::IntRect(0,350,312,42));
	RM.AddSprite("buttons.png","TutorialOut",sf::IntRect(0,100,300,48));
	RM.AddSprite("buttons.png","TutorialOver",sf::IntRect(0,400,312,42));
	RM.AddSprite("buttons.png","AboutOut",sf::IntRect(0,150,300,48));
	RM.AddSprite("buttons.png","AboutOver",sf::IntRect(0,450,312,42));
	RM.AddSprite("buttons.png","ExitOut",sf::IntRect(0,200,300,48));
	RM.AddSprite("buttons.png","ExitOver",sf::IntRect(0,500,312,42));
	
	RM.GetSprite("skyjump")->SetPosition(sf::Vector2f(0,0));
	
	gui::ImageButton StartGame(&App,sf::Vector2f(200,270),Alignment::Middle,RM.GetSprite("StartGameOut"),RM.GetSprite("StartGameOver"));
	gui::ImageButton Highscore(&App,sf::Vector2f(200,330),Alignment::Middle,RM.GetSprite("HighscoreOut"),RM.GetSprite("HighscoreOver"));
	gui::ImageButton Tutorial(&App,sf::Vector2f(200,390),Alignment::Middle,RM.GetSprite("TutorialOut"),RM.GetSprite("TutorialOver"));
	gui::ImageButton About(&App,sf::Vector2f(200,450),Alignment::Middle,RM.GetSprite("AboutOut"),RM.GetSprite("AboutOver"));
	gui::ImageButton Exit(&App,sf::Vector2f(200,510),Alignment::Middle,RM.GetSprite("ExitOut"),RM.GetSprite("ExitOver"));
	
	while(App.IsOpened()){
		sf::Event Event;
		while(App.PollEvent(Event)){
			if(Event.Type==sf::Event::Closed)
				App.Close();
		}
		App.Draw(*RM.GetSprite("background"));
		App.Draw(*RM.GetSprite("skyjump"));
		StartGame.Draw();
		if(StartGame.OnClick())
			fGame(&App);
		Highscore.Draw();
		if(Highscore.OnClick()){
			fHighscore(&App);
		}
		Tutorial.Draw();
		if(Tutorial.OnClick()){
			fTutorial(&App);
		}
		About.Draw();
		if(About.OnClick()){
			fAbout(&App);
		}
		Exit.Draw();
		if(Exit.OnClick())
			App.Close();
		App.Display();
	}
	return EXIT_SUCCESS;
}
