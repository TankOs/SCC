#ifndef DOODMAN_HPP
#define DOODMAN_HPP

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <list>
#include "particel.hpp"
#include "resourcemanager.hpp"
#include "animation.hpp"
#include "enums.hpp"

class Doodman
{
public:
	Doodman(sf::RenderWindow *App);
	void Jump();
	void HyperJump();
	void Move(int Direction);
	void Draw();
	sf::Vector2f Position;
	sf::FloatRect BoundingBox;
	sf::Vector2f Velocity;
private:
	sf::RenderWindow *App;
	sf::SoundBuffer JumpBuffer;
	sf::Sound JumpSound;
	sf::SoundBuffer HyperJumpBuffer;
	sf::Sound HyperJumpSound;
	ResourceManager RM;
	Animation *Right;
	Animation *Left;
	std::list<Particel*> lParticel;
	bool SmokeOn;
	int SmokeTimer;
};

#endif
