#ifndef GUI_HPP
#define GUI_HPP

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "enums.hpp"

namespace gui
{
	class Button
	{
	public:
		Button(sf::RenderWindow *App,sf::Vector2f Position,int Alignment);
		virtual bool OnMouseOver()=0;
		virtual bool OnClick();
		virtual void Draw()=0;
		sf::Vector2f Position;
		
	protected:
		sf::RenderWindow *App;
		sf::SoundBuffer Buffer;
		sf::Sound Sound;
		bool Clicked;
		bool MouseOver;
		int Alignment;
	};
	
	
	class TextButton :public Button
	{
	public:
		TextButton
		(	sf::RenderWindow *App,
			sf::Vector2f Position,
			int Alignment,
			sf::Text TextMouseOut,
			sf::Text TextMouseOver);
		virtual bool OnMouseOver();
		virtual void Draw();
		sf::Text TextMouseOut;
		sf::Text TextMouseOver;
	};
	
	
	class ImageButton :public Button
	{
	public:
		ImageButton
		(	sf::RenderWindow *App,
			sf::Vector2f Position,
			int Alignment,
			sf::Sprite *SpriteMouseOut,
			sf::Sprite *SpriteMouseOver);
		void UpdatePosition();
		virtual bool OnMouseOver();
		virtual void Draw();
		sf::Sprite *SpriteMouseOut;
		sf::Sprite *SpriteMouseOver;
	};
}

#endif