
Commit-Id: f9435eb8812419dfa58b

Ich kann es kaum glauben, dass ich doch noch eine funktionierende Windows-Version
hinbekommen hab.

Für die Linux Leute liegt im entsprechenden Ordner ein Makefile.

Viel Spaß noch mit meinem Game.


