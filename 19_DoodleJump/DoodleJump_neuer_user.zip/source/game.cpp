#include "game.h"

Game::Game()
{
    menu = true;
    help = false;
    mouse_down = false;
    showBackground = true;
    soundsEnabled = true;
    framerateLimit = 60;
    control = KEYBOARD;
    standardJumpTime = 1.2;
    hSpeed = 2.75;
    standardMaxVSpeed = 8;
    bonusHeight = 0.028;
    windowSize = sf::Vector2i(800, 600);
    distanceToSpace = (windowSize.y-20)*200;
    window.Create(sf::VideoMode(windowSize.x, windowSize.y), "DoodleJump-Klon", sf::Style::Close);
    window.SetFramerateLimit(framerateLimit);
    window.ShowMouseCursor(false);

    platformImg.push_back(sf::Image());
    platformImg.push_back(sf::Image());
    platformImg.push_back(sf::Image());
    platformImg.push_back(sf::Image());
    platformImg[0].LoadFromFile("images/platform.png");
    platformImg[1].LoadFromFile("images/platform2.png");
    platformImg[2].LoadFromFile("images/platform3.png");
    platformImg[3].LoadFromFile("images/platform4.png");
    platformImg[0].SetSmooth(false);
    platformImg[1].SetSmooth(false);
    platformImg[2].SetSmooth(false);
    platformImg[3].SetSmooth(false);
    platformSpr.push_back(sf::Sprite());
    platformSpr.push_back(sf::Sprite());
    platformSpr.push_back(sf::Sprite());
    platformSpr.push_back(sf::Sprite());
    platformSpr[0].SetImage(platformImg[0]);
    platformSpr[1].SetImage(platformImg[1]);
    platformSpr[2].SetImage(platformImg[2]);
    platformSpr[3].SetImage(platformImg[3]);

    cursorImg.LoadFromFile("images/cursor.png");
    cursorImg.SetSmooth(false);
    cursor.SetImage(cursorImg);

    barImg.LoadFromFile("images/bar.png");
    barImg.SetSmooth(false);
    bar.SetImage(barImg);
    bar.SetPosition(windowSize.x-10-bar.GetSize().x, windowSize.y-10);
    //
    barBgImg.LoadFromFile("images/barBg.png");
    barBgImg.SetSmooth(false);
    barBg.SetImage(barBgImg);
    barBg.SetPosition(bar.GetPosition().x, 10);

    backgroundImg.LoadFromFile("images/background.jpg");
    backgroundImg.SetSmooth(false);
    background.SetImage(backgroundImg);

    spaceBackground.SetSubRect(sf::IntRect(0, 0, windowSize.x, windowSize.y));

    menuBgImg.LoadFromFile("images/menuBg.jpg");
    menuBgImg.SetSmooth(false);
    menuBg.SetImage(menuBgImg);

    extraJumpDisplayImg.LoadFromFile("images/extraJumpDisplay.png");
    extraJumpDisplayImg.SetSmooth(false);
    extraJumpDisplay.SetImage(extraJumpDisplayImg);

    bonusHeightImg.LoadFromFile("images/bonusHeight.png");
    bonusHeightImg.SetSmooth(false);
    bonusHeightSpr.SetImage(bonusHeightImg);

    springImg.LoadFromFile("images/spring.png");
    springImg.SetSmooth(false);
    spring.SetImage(springImg);

    playerImg.LoadFromFile("images/player.png");
    playerImg.SetSmooth(false);
    player.SetImage(playerImg);

    sf::Image tempImg;
    tempImg.SetSmooth(false);
    tempImg.LoadFromFile("images/menuStart.png");
    menuItemImages.push_back(tempImg);
    tempImg.LoadFromFile("images/menuHelp.png");
    menuItemImages.push_back(tempImg);
    tempImg.LoadFromFile("images/menuQuit.png");
    menuItemImages.push_back(tempImg);
    //Hover
    tempImg.LoadFromFile("images/menuStartHover.png");
    menuHoverImages.push_back(tempImg);
    tempImg.LoadFromFile("images/menuHelpHover.png");
    menuHoverImages.push_back(tempImg);
    tempImg.LoadFromFile("images/menuQuitHover.png");
    menuHoverImages.push_back(tempImg);
    //
    sf::Sprite tempSprite;
    tempSprite.SetImage(menuItemImages[0]);
    tempSprite.SetPosition(134, 180);
    menuItems.push_back(tempSprite);
    tempSprite.SetImage(menuItemImages[1]);
    tempSprite.SetPosition(134, 270);
    menuItems.push_back(tempSprite);
    tempSprite.SetImage(menuItemImages[2]);
    tempSprite.SetPosition(134, 360);
    menuItems.push_back(tempSprite);

    jumpSoundBuffer.LoadFromFile("sound/jump.ogg");
    jumpSound.SetBuffer(jumpSoundBuffer);

    clickSoundBuffer.LoadFromFile("sound/click.ogg");
    clickSound.SetBuffer(clickSoundBuffer);

    pltDelSoundBuffer.LoadFromFile("sound/del.ogg");
    pltDelSound.SetBuffer(pltDelSoundBuffer);

    springSoundBuffer.LoadFromFile("sound/spring.ogg");
    springSound.SetBuffer(springSoundBuffer);

    font.LoadFromFile("Vera.ttf");
    helpString = sf::String("", font, 18.f);
    helpString.SetPosition(285, 180);
    helpString.SetText("Ziel des Spiels ist es, m�glichst hoch zu springen.\nDie Figur springt automatisch und wird mit\nden Pfeiltasten(links, rechts) bzw. der Maus bewegt.\n\nDie Plattformen, auf die man springen muss,\nhaben verschiedene Zust�nde und k�nnen auch\nweitere Extras enthalten.\n\nFunktionen:\n-Zum Abschalten des bewegenden Hintergrunds: [B]\n-Zum Umschalten der Steuerung (Tastatur/Maus) [C]\n-Pause [P]\n-Zusatzsprung [Leertaste]\n-Sounds an/aus [S]\n\nLizenzen:\n-Spiel: GNU GPL v3\n-Grafik/Sound: Creative Commons by-nd 3.0");

    string = sf::String("", font, 20.f);
    string.SetPosition(10, windowSize.y-58);
    string.SetColor(sf::Color(42, 42, 42));

    lostString = sf::String("Spiel verloren!", font);
    lostString.SetColor(sf::Color::Red);

    loop();
}

void Game::reset()
{
    bonusHeightSpritePositions.clear();

    platforms.clear();
    for(int i = 0;i < 10;i++)
    {
        addPlatform(random.Random(0, windowSize.y), 0);
    }

    background.SetPosition(0, -windowSize.y);
    player.SetPosition(windowSize.x/2 - player.GetSize().x/2, 350);

    vSpeed = 0;
    distance = 0;
    maxDistance = 0;
    extraJumps = 3;
    vDirection = UP;
    jumpTime = standardJumpTime;
    maxVSpeed = standardMaxVSpeed;
    redPlatformDeduction = 0;
    elapsedJumpTimeP = 0;
    elapsedJumpTime.Reset();
    springJump = false;
    menu = false;
    paused = false;
    gameLost = false;

    extraJumpDisplay.SetSubRect(sf::IntRect(0, 20*extraJumps, 110, 20*(extraJumps+1)));
}

void Game::lost()
{
    menu = true;
    gameLost = true;
}

float Game::frameSpeed()
{
    return window.GetFrameTime()*framerateLimit;
}

bool Game::rectCollision(sf::Sprite &obj1, sf::Sprite &obj2)
{
    if(obj2.GetPosition().x < obj1.GetPosition().x+obj1.GetSize().x && obj2.GetPosition().x+obj2.GetSize().x > obj1.GetPosition().x)
    {
        if(obj2.GetPosition().y < obj1.GetPosition().y+obj1.GetSize().y && obj2.GetPosition().y+obj2.GetSize().y > obj1.GetPosition().y)
        {
            return true;
        }
    }
    return false;
}

void Game::computeVSpeed()
{
    if(vDirection == UP)
    {
        if(springJump == true)
            vSpeed = -((maxVSpeed*1.8)/pow((jumpTime*1.15)/2, 2))*pow(elapsedJumpTime.GetElapsedTime()+elapsedJumpTimeP, 2)+(maxVSpeed*1.8);
        else
            vSpeed = -(maxVSpeed/pow(jumpTime/2, 2))*pow(elapsedJumpTime.GetElapsedTime()+elapsedJumpTimeP, 2)+maxVSpeed;
    }
    else
        vSpeed = (maxVSpeed/pow(jumpTime/2, 2))*pow(elapsedJumpTime.GetElapsedTime()+elapsedJumpTimeP, 2)+(2-elapsedJumpTime.GetElapsedTime());


    if(springJump == true && vSpeed > maxVSpeed*1.8)
        vSpeed = maxVSpeed*1.8;
    else if(springJump == false && vSpeed > maxVSpeed)
        vSpeed = maxVSpeed;
}

void Game::addPlatform(int hits)
{
    int _hits = hits;
    int extra;
    if(random.Random(0, 33) == 2)
        extra = 1;
    else
        extra = 0;
    platforms.push_back(Platform(sf::Vector2f(random.Random(windowSize.x/2-150.f, windowSize.x/2+150-platformSpr[0].GetSize().x), 0), _hits, extra));
    if(extra == 1)
    {
        platforms[platforms.size()-1].extraPosition = sf::Vector2f(random.Random(platforms[platforms.size()-1].position.x, platforms[platforms.size()-1].position.x+platformSpr[0].GetSize().x-spring.GetSize().x), platforms[platforms.size()-1].position.y-spring.GetSize().y);
    }
}
void Game::addPlatform(float yPos, int hits)
{
    int _hits = hits;
    int extra;
    if(random.Random(0, 30) == 2)
        extra = 1;
    else
        extra = 0;
    platforms.push_back(Platform(sf::Vector2f(random.Random(windowSize.x/2-150.f, windowSize.x/2+150-platformSpr[0].GetSize().x), yPos), _hits, extra));
    if(extra == 1)
    {
        platforms[platforms.size()-1].extraPosition = sf::Vector2f(random.Random(platforms[platforms.size()-1].position.x, platforms[platforms.size()-1].position.x+platformSpr[0].GetSize().x-spring.GetSize().x), platforms[platforms.size()-1].position.y-spring.GetSize().y);
    }
}

void Game::processEvents()
{
    while(window.GetEvent(event))
    {
        switch(event.Type)
        {
            case sf::Event::Closed:
                window.Close();
                break;
            case sf::Event::KeyPressed:
            {
                switch(event.Key.Code)
                {
                    case sf::Key::Escape:
                    {
                        if(menu)
                            window.Close();
                        else
                            menu = true;
                        break;
                    }
                    case sf::Key::B:
                        showBackground = !showBackground;
                        break;
                    case sf::Key::C:
                    {
                        if(control == MOUSE)
                            control = KEYBOARD;
                        else if(control == KEYBOARD)
                            control = MOUSE;
                        break;
                    }
                    case sf::Key::P:
                    {
                        if(!paused)
                            elapsedJumpTimeP = elapsedJumpTime.GetElapsedTime();
                        else
                            elapsedJumpTime.Reset();
                        paused = !paused;
                        break;
                    }
                    case sf::Key::S:
                    {
                        soundsEnabled = !soundsEnabled;
                        break;
                    }
                    case sf::Key::Space:
                    {
                        //Extra-Sprung
                        if(extraJumps > 0 && menu == false && paused == false)
                        {
                            vDirection = UP;
                            elapsedJumpTime.Reset();
                            extraJumps--;
                            extraJumpDisplay.SetSubRect(sf::IntRect(0, 20*extraJumps, 110, 20*(extraJumps+1)));
                        }
                        break;
                    }
                    default:
                        break;
                }

                break;
            }
            default:
                break;
        }
    }
}

void Game::updateGame()
{
    computeVSpeed();

    if(control == KEYBOARD)
    {
        if(window.GetInput().IsKeyDown(sf::Key::Left))
            player.SetPosition(player.GetPosition().x-hSpeed*frameSpeed(), player.GetPosition().y);
        else if(window.GetInput().IsKeyDown(sf::Key::Right))
            player.SetPosition(player.GetPosition().x+hSpeed*frameSpeed(), player.GetPosition().y);
    }
    else if(control == MOUSE)
        player.SetPosition(player.GetPosition().x+hSpeed*3*(((float)window.GetInput().GetMouseX()-(player.GetPosition().x+player.GetSize().x/2))/(player.GetPosition().x+player.GetSize().x/2))*frameSpeed(), player.GetPosition().y);

    if(player.GetPosition().x < 0)
        player.SetPosition(0, player.GetPosition().y);
    else if(player.GetPosition().x+player.GetSize().x > windowSize.x)
        player.SetPosition(windowSize.x-player.GetSize().x, player.GetPosition().y);

    if(vDirection == UP)
    {
        distance += vSpeed;
        if(distance > maxDistance)
            maxDistance = distance;

        background.SetPosition(0, background.GetPosition().y+vSpeed*frameSpeed()/1.5);
        if(background.GetPosition().y >= 0)
            background.SetPosition(0, background.GetPosition().y-windowSize.y);

        if(distance >= maxDistance && random.Random(0, (int)((60/vSpeed)+((60/vSpeed)*(distance/distanceToSpace)))) == 2)
        {
            int n;
            if(random.Random(0, 26) == 10)
                n = 3;
            else if(random.Random(0, 10) == 10)
                n = 1;
            else if(random.Random(0, 25) == 10)
                n = 2;
            else
                n = 0;
            addPlatform(n);

            if(random.Random(0, 37) == 10)
                bonusHeightSpritePositions.push_back(sf::Vector2f(random.Random(windowSize.x/2-150.f, windowSize.x/2+150-bonusHeightSpr.GetSize().x), 0));
        }

        if(elapsedJumpTime.GetElapsedTime()+elapsedJumpTimeP >= jumpTime || vSpeed <= 0)
        {
            vDirection = DOWN;
            elapsedJumpTime.Reset();
            elapsedJumpTimeP = 0;
            springJump = false;
        }

        for(int i = 0;i < bonusHeightSpritePositions.size();i++)
        {
            bonusHeightSpritePositions[i] = sf::Vector2f(bonusHeightSpritePositions[i].x, bonusHeightSpritePositions[i].y+vSpeed*frameSpeed());

            bonusHeightSpr.SetPosition(bonusHeightSpritePositions[i]);
            if(rectCollision(bonusHeightSpr, player))
            {
                jumpTime += bonusHeight;
                maxVSpeed += bonusHeight/3;
                bonusHeightSpritePositions.erase(bonusHeightSpritePositions.begin()+i);
                i--;
            }
        }

        for(int i = 0;i < platforms.size();i++)
        {
            platforms[i].position = sf::Vector2f(platforms[i].position.x, platforms[i].position.y+vSpeed*frameSpeed());
            platforms[i].extraPosition = sf::Vector2f(platforms[i].extraPosition.x, platforms[i].extraPosition.y+vSpeed*frameSpeed());

            if(platforms[i].position.y >= windowSize.y+100)
            {
                platforms.erase(platforms.begin()+i);
                i--;
            }
        }
    }
    else
    {
        distance -= vSpeed;

        background.SetPosition(0, background.GetPosition().y-vSpeed*frameSpeed());
        if(background.GetPosition().y <= -windowSize.y)
            background.SetPosition(0, background.GetPosition().y+windowSize.y);

        for(int i = 0;i < bonusHeightSpritePositions.size();i++)
        {
            bonusHeightSpritePositions[i] = sf::Vector2f(bonusHeightSpritePositions[i].x, bonusHeightSpritePositions[i].y-vSpeed*frameSpeed());

            bonusHeightSpr.SetPosition(bonusHeightSpritePositions[i]);
            if(rectCollision(bonusHeightSpr, player))
            {
                jumpTime += bonusHeight;
                maxVSpeed += bonusHeight/3;
                redPlatformDeduction -= 0.05;
                bonusHeightSpritePositions.erase(bonusHeightSpritePositions.begin()+i);
                i--;
            }
            else if(bonusHeightSpritePositions[i].y > windowSize.y)
            {
                bonusHeightSpritePositions.erase(bonusHeightSpritePositions.begin()+i);
                i--;
            }
        }

        for(int i = 0;i < platforms.size();i++)
        {
            platforms[i].position = sf::Vector2f(platforms[i].position.x, platforms[i].position.y-vSpeed*frameSpeed());
            platforms[i].extraPosition = sf::Vector2f(platforms[i].extraPosition.x, platforms[i].extraPosition.y-vSpeed*frameSpeed());
        }
        for(int i = 0;i < platforms.size();i++)
        {
            platformSpr[0].SetPosition(platforms[i].position);
            if(rectCollision(player, platformSpr[0]) && player.GetPosition().y+player.GetSize().y >= platforms[i].position.y && player.GetPosition().y+player.GetSize().y <= platforms[i].position.y+platformSpr[0].GetSize().y)
            {
                if(platforms[i].hits >= 2)
                {
                    if(platforms[i].hits == 2)
                    {
                        addPlatform(random.Random(0.f, player.GetPosition().y), 2);
                        addPlatform(random.Random(0.f, player.GetPosition().y), 2);
                        redPlatformDeduction += 0.1;
                    }
                    if(platforms[i].hits == 3)
                    {
                        if(soundsEnabled)
                            pltDelSound.Play();

                        if(extraJumps < 5)
                        {
                            extraJumps++;
                            extraJumpDisplay.SetSubRect(sf::IntRect(0, 20*extraJumps, 110, 20*(extraJumps+1)));
                        }
                    }
                    if(platforms[i].hits != 3)
                    {
                        if(soundsEnabled)
                            jumpSound.Play();

                        vDirection = UP;
                        elapsedJumpTime.Reset();
                    }

                    platforms.erase(platforms.begin()+i);
                    i--;
                }
                else
                {
                    if(soundsEnabled)
                        jumpSound.Play();

                    platforms[i].hits++;
                    vDirection = UP;
                    elapsedJumpTime.Reset();
                    elapsedJumpTimeP = 0;
                }
            }
            else if(platforms[i].extra == 1)
            {
                spring.SetPosition(platforms[i].extraPosition);
                if(rectCollision(player, spring) && player.GetPosition().y+player.GetSize().y >= platforms[i].extraPosition.y && player.GetPosition().y+player.GetSize().y <= platforms[i].extraPosition.y+spring.GetSize().y)
                {
                    if(soundsEnabled)
                        springSound.Play();
                    springJump = true;
                    vDirection = UP;
                    elapsedJumpTime.Reset();
                    elapsedJumpTimeP = 0;
                }
            }
        }

        if(vDirection == DOWN && distance < maxDistance-windowSize.y-(windowSize.y-player.GetPosition().y))
            lost();
    }

    bar.SetPosition(windowSize.x-10-bar.GetSize().x, windowSize.y-10-(maxDistance/(distanceToSpace/(windowSize.y-20))));
    spaceBackground.SetColor(sf::Color(0, 0, 163, (int)(maxDistance/distanceToSpace*255)));

    std::ostringstream ostd;
    ostd<<"Sprungkraft: "<<jumpTime/standardJumpTime<<"\nPunktabzug: "<<redPlatformDeduction;
    string.SetText(ostd.str());
}

void Game::updateMenu()
{
    if(window.GetInput().IsMouseButtonDown(sf::Mouse::Left))
    {
        if(!mouse_down)
        {
            if(rectCollision(cursor, menuItems[0]))
            {
                if(soundsEnabled)
                    clickSound.Play();

                reset();
            }
            else if(rectCollision(cursor, menuItems[1]))
            {
                if(soundsEnabled)
                    clickSound.Play();

                help = !help;
            }
            else if(rectCollision(cursor, menuItems[2]))
            {
                window.Close();
            }
        }
        mouse_down = true;
    }
    else
    {
        if(!mouse_down)
        {
            if(rectCollision(cursor, menuItems[0]))
                menuItems[0].SetImage(menuHoverImages[0]);
            else
                menuItems[0].SetImage(menuItemImages[0]);

            if(rectCollision(cursor, menuItems[1]))
                menuItems[1].SetImage(menuHoverImages[1]);
            else
                menuItems[1].SetImage(menuItemImages[1]);

            if(rectCollision(cursor, menuItems[2]))
                menuItems[2].SetImage(menuHoverImages[2]);
            else
                menuItems[2].SetImage(menuItemImages[2]);
        }
        mouse_down = false;
    }
}

void Game::updateWindow()
{
    window.Clear(sf::Color(255, 130, 20));

    if(menu)
    {
        window.Draw(menuBg);

        for(int i = 0;i < menuItems.size();i++)
        {
            window.Draw(menuItems[i]);
        }

        if(help)
            window.Draw(helpString);

        if(gameLost)
            window.Draw(lostString);
    }
    else
    {
        if(showBackground)
        {
            window.Draw(background);
            window.Draw(spaceBackground);
        }

        for(int i = 0;i < bonusHeightSpritePositions.size();i++)
        {
            bonusHeightSpr.SetPosition(bonusHeightSpritePositions[i]);
            window.Draw(bonusHeightSpr);
        }

        for(int i = 0;i < platforms.size();i++)
        {
            platformSpr[platforms[i].hits].SetPosition(platforms[i].position);
            window.Draw(platformSpr[platforms[i].hits]);

            if(platforms[i].extra == 1)
            {
                spring.SetPosition(platforms[i].extraPosition);
                window.Draw(spring);
            }
        }

        window.Draw(player);

        window.Draw(barBg);
        window.Draw(bar);

        window.Draw(extraJumpDisplay);

        window.Draw(string);
    }

    cursor.SetPosition(window.GetInput().GetMouseX(), window.GetInput().GetMouseY());
    window.Draw(cursor);

    window.Display();
}

void Game::loop()
{
    while(window.IsOpened())
    {
        processEvents();

        if(menu)
            updateMenu();
        else if(!paused)
            updateGame();

        updateWindow();
    }
}
