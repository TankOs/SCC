#include "platform.h"

Platform::Platform(sf::Vector2f _position, int _hits = 0, int _extra = 0)
{
    position = _position;
    hits = _hits;
    extra = _extra;
}
