#ifndef GAME_H
#define GAME_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <sstream>
#include "platform.h"

class Game
{
private:
    bool menu, paused, gameLost, help, mouse_down, showBackground, soundsEnabled, springJump;
    int framerateLimit, vDirection, control, extraJumps;
    static const int UP = 1; static const int DOWN = 0; static const int KEYBOARD = 0; static const int MOUSE = 1;
    float standardJumpTime, jumpTime, elapsedJumpTimeP, hSpeed, vSpeed, standardMaxVSpeed, maxVSpeed, playerHMove, distance, maxDistance, distanceToSpace, bonusHeight, redPlatformDeduction;
        //sf::vector...
    sf::Vector2i windowSize;
        //sf::image/sprite
    sf::Image menuBgImg, cursorImg, playerImg, barImg, barBgImg, backgroundImg, extraJumpDisplayImg, bonusHeightImg, springImg;
    sf::Sprite spaceBackground, menuBg, cursor, player, bar, barBg, background, extraJumpDisplay, bonusHeightSpr, spring;
        //sf::sound...
    sf::SoundBuffer jumpSoundBuffer, clickSoundBuffer, pltDelSoundBuffer, springSoundBuffer;
    sf::Sound jumpSound, clickSound, pltDelSound, springSound;
        //sf::...
    sf::RenderWindow window;
    sf::Event event;
    sf::Clock elapsedJumpTime;
    sf::Randomizer random;
    sf::Font font;
    sf::String helpString, string, lostString;
        //
    std::vector<sf::Image> menuItemImages, menuHoverImages, platformImg;
    std::vector<sf::Sprite> menuItems, platformSpr;
    std::vector<Platform> platforms;
    std::vector<sf::Vector2f> bonusHeightSpritePositions;
    //
    void reset();
    void lost();
    float frameSpeed();
    bool rectCollision(sf::Sprite &obj1, sf::Sprite &obj2);
    void computeVSpeed();
    void addPlatform(int hits);
    void addPlatform(float yPos, int hits);
    void processEvents();
    void updateWindow();
    void updateGame();
    void updateMenu();
    void loop();
public:
    Game();
};

#endif // GAME_H
