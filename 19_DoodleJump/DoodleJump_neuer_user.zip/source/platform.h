#ifndef PLATFORM_H
#define PLATFORM_H

#include <SFML/Graphics.hpp>

class Platform
{
public:
    int hits, extra;
    float jumpTime;
    sf::Vector2f position, extraPosition;
    Platform(sf::Vector2f _position, int _hits, int _extra);
};

#endif // PLATFORM_H
