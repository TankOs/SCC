#include "shot.hpp"

Shot::Shot()
: remove(false)
{
}

Shot::~Shot()
{
}
