#include "shared.hpp"

Shared::Shared(sf::RenderWindow &window, sf::VideoMode &VideoMode) :
app(window),
videoMode(VideoMode)
{
};

Shared::~Shared()
{
};

