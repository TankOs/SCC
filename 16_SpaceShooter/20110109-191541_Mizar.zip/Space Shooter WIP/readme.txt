-------------------------------------------------------------------------------
How to play
-------------------------------------------------------------------------------
To play the game on a Windows machine just execute the "start.bat" file.
-------------------------------------------------------------------------------
Controls
-------------------------------------------------------------------------------
Menu-controls
-------------
up or W and down or S - move the cursor
return - select an option
escape - cancel or quit

Game-controls
-------------
W,A,S,D or arrow keys - move the ship
space - fire your weapon
escape - open up the menu and pause the game
-------------------------------------------------------------------------------
Source Code
-------------------------------------------------------------------------------
For the source code of the game just open the "shooter.rb" file with a
texteditor. The file has the complete source code for the game. Changes made to
the "shooter.rb" file will affect the game. So don't do it, unless you know
what you do.
-------------------------------------------------------------------------------