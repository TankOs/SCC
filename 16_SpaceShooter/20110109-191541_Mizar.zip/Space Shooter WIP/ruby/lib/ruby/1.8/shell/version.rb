#
#   version.rb - shell version definition file
#   	$Release Version: 0.6.0$
#   	$Revision: 11708 $
#   	$Date: 2007-02-13 08:01:19 +0900 (Tue, 13 Feb 2007) $
#   	by Keiju ISHITSUKA(Nihon Rational Software Co.,Ltd)
#
# --
#
#   
#

class Shell
  @RELEASE_VERSION = "0.6.0"
  @LAST_UPDATE_DATE = "01/03/19"
end
