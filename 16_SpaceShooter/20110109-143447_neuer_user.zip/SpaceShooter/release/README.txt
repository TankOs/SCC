(c) 2011 Markus F.
Lizenz: GNU GPLv3
Grafiken 'meteor.png', 'player.png', 'rocket1.png', 'rocket2.png' von http://www.openclipart.org/ (user: johnny_automatic)

Steuerung:
  Pfeiltasten links/rechts --> links/rechts
  Pfeiltasten oben/unten --> schneller/langsamer
  Leertaste --> schie�en