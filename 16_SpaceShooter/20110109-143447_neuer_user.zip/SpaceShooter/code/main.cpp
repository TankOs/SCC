#include "game.h"

Game game;

int main()
{
    while(true)
    {
	if(game.loop())
	{
	    if(!game.newGame)
		break;
	}
    }

    return 0;
}