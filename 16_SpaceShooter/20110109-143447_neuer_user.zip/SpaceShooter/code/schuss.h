#ifndef SCHUSS_H
#define SCHUSS_H

#include <SFML/Graphics.hpp>

class Schuss
{
public: sf::Vector2f position;
public: sf::Vector2f direction;
public:
    Schuss();
    void start(sf::Vector2f pos, sf::Vector2f dir);
};

#endif // SCHUSS_H
