#include "object.h"

Object::Object()
{
}

void Object::init(sf::Vector2f pos, sf::Vector2f spriteSize, int typ)
{
    position = pos;
    size = spriteSize;
    type = typ;
    if(typ == 3)
    {
	direction = sf::Vector2f(sf::Randomizer::Random(-1.8f, 1.8f), sf::Randomizer::Random(0.8f, 1.2f));
	rotation = ((-atan2(direction.y, direction.x)-atan2(41, 116))/M_PI*180)+180;
    }
    else
    {
	direction = sf::Vector2f(0, 1);
	rotation = sf::Randomizer::Random(0.8f, 1.2f);
    }
    hit = false;
}