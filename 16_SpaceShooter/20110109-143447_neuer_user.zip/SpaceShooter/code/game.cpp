#include "game.h"

Game::Game()
{
}

float Game::fps()
{
    return 70/(1/window.GetFrameTime());
}

void Game::stopGame()
{
    stopped = true;
    highScore = clk3.GetElapsedTime();
}

void Game::resetGame(int i)
{
    if(i > 0)
    {
	std::ostringstream temp;
	std::ofstream schreiben;
	temp<<"Spieler "<<i<<": "<<highScore<<" Sekunden; Level "<<level<<"; "<<points<<" Punkte\n";
	schreiben.open("highscore.txt");
	schreiben<<temp.str();
	schreiben.close();
    }

    stopped = false;
    newGame = true;
}

void Game::playerDamage()
{
    player.SetSubRect(sf::IntRect(((int)(damage*5))*37, 0, (((int)(damage*5))*37)+37, 80));
    if(damage > 0.75)
	string.SetColor(sf::Color::Red);
    if(damage >= 1 || damage < 0.8)
	string.SetColor(sf::Color::Blue);
    if(damage >= 1)
    {
	stopGame();
    }
}

void Game::init()
{
    newGame = false;
    newLevel = false;

    playerSize = sf::Vector2f(37, 80);

    windowSize = sf::Vector2i(800, 600);

    positionX = (windowSize.x/2)-(playerSize.x/2);
    positionY = 0;
    playerMinMaxX = std::pair<float, float>(10, windowSize.x-10-playerSize.x);
    maxRot = 5;
    rot = 0;
    rotSpeed = 0.5;
    speedX = 3;
    maxBackgroundY = 2400;
    energy = 100;
    damage = 0;
    points = 0;
    level = 1;

    randomInt = 170;
    randomInt2 = sf::Randomizer::Random(0, randomInt);
    randomInt3 = randomInt*9;

    bonusObjPositions.clear();
    objects.clear();
    schuesse.clear();
    initObjects();

    playerImage.LoadFromFile("res/player.png");
    player.SetImage(playerImage);
    player.SetPosition(positionX, windowSize.y-playerSize.y-10);
    playerDamage();

    backgroundImage.LoadFromFile("res/background.png");
    background.SetImage(backgroundImage);
    background.SetPosition(0, positionY);

    energyImg.LoadFromFile("res/eg.png");
    energySprite.SetImage(energyImg);
    energySprite.SetPosition(5, 5);

    schussImg.LoadFromFile("res/schuss.png");
    schussSprite.SetImage(schussImg);

    font.LoadFromFile("res/Vera.ttf");
    string = sf::String("", font, 20);
    string.SetColor(sf::Color::Blue);
    string.SetPosition(2, energySprite.GetSize().y+2);
    newLevelString = sf::String("", font, 30);
    newLevelString.SetColor(sf::Color::Cyan);
    newLevelString.SetPosition(5, 500);

    soundbuffer.LoadFromFile("res/crash.ogg");
    sound.SetBuffer(soundbuffer);

    clk.Reset();
    clk2.Reset();
    clk3.Reset();

    window.Create(sf::VideoMode(windowSize.x, windowSize.y), "Space Shooter", sf::Style::Close, sf::WindowSettings(24, 8, 4));
    window.SetFramerateLimit(70);
}

void Game::initObjects()
{
    objSize.clear();
    objSize.push_back(sf::Vector2f(21, 150));	//rakete1
    objSize.push_back(sf::Vector2f(24, 150));	//rakete2
    objSize.push_back(sf::Vector2f(120, 450));	//meteor

    img1.LoadFromFile("res/rocket1.png");
    img2.LoadFromFile("res/rocket2.png");
    img3.LoadFromFile("res/meteor.png");
    spr1.SetImage(img1);
    spr2.SetImage(img2);
    spr3.SetImage(img3);
    spr3.SetCenter(4, 40);

    bonusObjImg.LoadFromFile("res/bonus.png");
    bonusObj.SetImage(bonusObjImg);
}

void Game::getInput()
{
    window.GetEvent(event);
    switch(event.Type)
    {
	default:
	    break;
	case sf::Event::Closed:
	{
	    window.Close();
	    break;
	}
	case sf::Event::KeyPressed:
	{
	    if(stopped)
	    {
		switch(event.Key.Code)
		{
		    default:
			break;
		    case sf::Key::Return:
		    {
			resetGame(0);
			break;
		    }
		    case sf::Key::Num1:
		    {
			resetGame(1);
			break;
		    }
		    case sf::Key::Num2:
		    {
			resetGame(2);
			break;
		    }
		    case sf::Key::Num3:
		    {
			resetGame(3);
			break;
		    }
		    case sf::Key::Num4:
		    {
			resetGame(4);
			break;
		    }
		    case sf::Key::Num5:
		    {
			resetGame(5);
			break;
		    }
		    case sf::Key::Num6:
		    {
			resetGame(6);
			break;
		    }
		    case sf::Key::Num7:
		    {
			resetGame(7);
			break;
		    }
		    case sf::Key::Num8:
		    {
			resetGame(8);
			break;
		    }
		    case sf::Key::Num9:
		    {
			resetGame(9);
			break;
		    }
		}
	    }
	    switch(event.Key.Code)
	    {
		default:
		    break;
		case sf::Key::Escape:
		{
		    window.Close();
		    break;
		}
		case sf::Key::Space:
		{
		    if(clk.GetElapsedTime() >= 0.5)
		    {
			clk.Reset();

			schuesse.push_back(Schuss());
			if(player.GetRotation() > 0 && player.GetRotation() <= 5)
			    schuesse[schuesse.size()-1].start(sf::Vector2f(player.GetPosition().x+(player.GetSize().x/2)-(schussSprite.GetSize().x/2), windowSize.y-player.GetSize().y+(schussSprite.GetSize().y/2)), sf::Vector2f((1/9)*((player.GetRotation()-360)/5), 1));
			else
			    schuesse[schuesse.size()-1].start(sf::Vector2f(player.GetPosition().x+(player.GetSize().x/2)-(schussSprite.GetSize().x/2), windowSize.y-player.GetSize().y+(schussSprite.GetSize().y/2)), sf::Vector2f((1/9)*(player.GetRotation()/5), 1));
		    }
		    break;
		}
	    }
	    break;
	}
    }
}

void Game::generateObjects()
{
    if(random.Random(0, randomInt) == randomInt2)
    {
	//Objekt hinzuf�gen
	int r;
	r = sf::Randomizer::Random(0, 2);   //Objekttyp
	objects.push_back(Object());
	objects.at(objects.size()-1).init(sf::Vector2f(sf::Randomizer::Random(10, windowSize.x-10), -objSize[r].y-10), objSize[r], r+1);
    }
    if(random.Random(0, randomInt3) == randomInt2)
    {
	bonusObjPositions.push_back(sf::Vector2f(random.Random(0.0f, windowSize.x-(bonusObj.GetSize().x/2)), -30));
    }
}

void Game::updateSprites()
{
    //Neue Objekte hinzufuegen (Random)
    generateObjects();
    //

    //Hintergrundbild, Energie
    tempY = 1;
    if(window.GetInput().IsKeyDown(sf::Key::Up))
    {
	energy -= 0.2*fps();
	if(energy > 0)
	    tempY += 1*fps();
    }
    if(window.GetInput().IsKeyDown(sf::Key::Down))
    {
	energy -= 0.10*fps();
	if(energy > 0)
	    tempY -= 0.3*fps();
    }
    else
    {
	energy += 0.04*fps();
    }

    if(energy < 0)
	energy = 0;
    else if(energy > 100)
	energy = 100;

    energySprite.SetSubRect(sf::IntRect(0, 0, energy*8-10, 20));

    positionY += tempY;
    background.SetPosition(0, positionY);

    if(positionY > 0)
    {
	positionY = -maxBackgroundY;
	background.SetPosition(0, positionY);
    }
    //

    //Objekte
    for(int i = 0;i < objects.size();i++)
    {
	objects[i].position = sf::Vector2f(objects[i].position.x, objects[i].position.y+(objects[i].direction.y*fps())+tempY);
	if(objects[i].type == 3)
	    objects[i].position = sf::Vector2f(objects[i].position.x+(objects[i].direction.x*fps()), objects[i].position.y);

	if(objects[i].position.x < -100 || objects[i].position.x > windowSize.x+100 || objects[i].position.y > windowSize.y+150)
	    objects.erase(objects.begin()+i);

	for(int e = 0;e < schuesse.size();e++)
	{
	    if(objects[i].type != 3)
	    {
		if(schuesse[e].position.x+schussSprite.GetSize().x > objects[i].position.x && schuesse[e].position.x < objects[i].position.x+objects[i].size.x)
		{
		    if(schuesse[e].position.y+schussSprite.GetSize().y > objects[i].position.y && schuesse[e].position.y < objects[i].position.y+objects[i].size.y)
		    {
			if(!objects[i].hit)
			{
			    objects.erase(objects.begin()+i);
			    schuesse.erase(schuesse.begin()+e);
			    points += 1;
			    sound.Play();
			}
		    }
		}
	    }
	    else
	    {
		if(schuesse[e].position.x+schussSprite.GetSize().x > objects[i].position.x+spr3.GetCenter().x-4 && schuesse[e].position.x < objects[i].position.x+spr3.GetCenter().x+4)
		{
		    if(schuesse[e].position.y+schussSprite.GetSize().y > objects[i].position.y+spr3.GetCenter().y-4 && schuesse[e].position.y < objects[i].position.y+spr3.GetCenter().y+4)
		    {
			schuesse.erase(schuesse.begin()+e);
		    }
		}
	    }

	    if(schuesse[e].position.y < -10)
		schuesse.erase(schuesse.begin()+e);
	}

	if(objects[i].type != 3)
	{
	    if(player.GetPosition().x+player.GetSize().x > objects[i].position.x && player.GetPosition().x < objects[i].position.x+objects[i].size.x)
	    {
		if(player.GetPosition().y+player.GetSize().y > objects[i].position.y && player.GetPosition().y < objects[i].position.y+objects[i].size.y)
		{
		    if(!objects[i].hit)
		    {
			objects[i].hit = true;
			damage += 0.17;
			playerDamage();
			energy -= 15;
			if(energy < 0)
			    energy = 0;
			sound.Play();
		    }
		}
	    }
	}
	else
	{
	    if(player.GetPosition().x+player.GetSize().x > objects[i].position.x+spr3.GetCenter().x-4 && player.GetPosition().x < objects[i].position.x+spr3.GetCenter().x+4)
	    {
		if(player.GetPosition().y+player.GetSize().y > objects[i].position.y+spr3.GetCenter().y-4 && player.GetPosition().y < objects[i].position.y+spr3.GetCenter().y+4)
		{
		    if(!objects[i].hit)
		    {
			objects[i].hit = true;
			damage += 0.18;
			playerDamage();
			energy -= 15;
			if(energy < 0)
			    energy = 0;
			sound.Play();
		    }
		}
	    }
	}
    }
    for(int i = 0;i < bonusObjPositions.size();i++)
    {
	bonusObjPositions[i] = sf::Vector2f(bonusObjPositions[i].x+(random.Random(-2.0f, 2.0f)/2), bonusObjPositions[i].y+tempY);

	if(bonusObjPositions[i].x < -100 || bonusObjPositions[i].x > windowSize.x+100 || bonusObjPositions[i].y > windowSize.y+150)
	    bonusObjPositions.erase(bonusObjPositions.begin()+i);
    }

    //Schuesse
    for(int i = 0;i < schuesse.size();i++)
    {
	schuesse[i].position = sf::Vector2f(schuesse[i].position.x+(schuesse[i].direction.x*6*fps()), schuesse[i].position.y-(schuesse[i].direction.y*6*fps()));
    }

    //Spieler
    if(window.GetInput().IsKeyDown(sf::Key::Left))
    {
	if(positionX > playerMinMaxX.first)
	{
	    positionX -= speedX*fps();
	    if(rot < maxRot)
		rot += rotSpeed*fps();
	}
	else
	{
	    if(rot > 0)
		rot -= rotSpeed*fps();
	}
    }
    else if(window.GetInput().IsKeyDown(sf::Key::Right))
    {
	if(positionX < playerMinMaxX.second)
	{
	    positionX += speedX*fps();
	    if(rot > -maxRot)
		rot -= rotSpeed*fps();
	}
	else
	{
	    if(rot < 0)
		rot += rotSpeed*fps();
	}
    }
    else
    {
	if(rot < 0)
	    rot += rotSpeed*2*fps();
	else if(rot > 0)
	    rot -= rotSpeed*2*fps();
    }
    if(rot < rotSpeed && rot > -rotSpeed)
	rot = 0;
    player.SetRotation(rot);
    player.SetPosition(positionX, player.GetPosition().y);


    //Anzeige
    std::ostringstream output;
    output<<"Energie: "<<(int)energy<<"%\nLevel: "<<level<<"\nSpielerzustand: "<<(int)(100*(1-damage))<<"%\nPunkte: "<<points<<"\n"<<(int)clk3.GetElapsedTime()<<"s";
    string.SetText(output.str());
}

void Game::checkCollisions()
{
    for(int i = 0;i < bonusObjPositions.size();i++)
    {
	if((player.GetPosition().x+player.GetSize().x >= bonusObjPositions[i].x && player.GetPosition().x+player.GetSize().x <= bonusObjPositions[i].x+bonusObj.GetSize().x) || (player.GetPosition().x >= bonusObjPositions[i].x && player.GetPosition().x <= bonusObjPositions[i].x+bonusObj.GetSize().x))
	{
	    if((player.GetPosition().y+player.GetSize().y >= bonusObjPositions[i].y && player.GetPosition().y+player.GetSize().y <= bonusObjPositions[i].y+bonusObj.GetSize().y) || (player.GetPosition().y >= bonusObjPositions[i].y && player.GetPosition().y <= bonusObjPositions[i].y+bonusObj.GetSize().y))
	    {
		bonusObjPositions.erase(bonusObjPositions.begin()+i);
		damage -= 0.025;
		if(damage < 0)
		    damage = 0;
		energy += 10;
		if(energy > 100)
		    energy = 100;

		playerDamage();
	    }
	}
    }
}

void Game::updateWindow()
{
    window.Clear();

    window.Draw(background);

    for(int i = 0;i < bonusObjPositions.size();i++)
    {
	bonusObj.SetPosition(bonusObjPositions[i]);
	window.Draw(bonusObj);
    }

    for(int i = 0;i < objects.size();i++)
    {
	switch(objects[i].type)
	{
	    default:
		break;
	    case 1:
	    {
		spr1.SetPosition(objects[i].position);
		window.Draw(spr1);
		break;
	    }
	    case 2:
	    {
		img2.SetSmooth(false);
		spr2.SetPosition(objects[i].position);
		window.Draw(spr2);
		break;
	    }
	    case 3:
	    {
		spr3.SetPosition(objects[i].position);
		spr3.SetRotation(objects[i].rotation);
		window.Draw(spr3);
		break;
	    }
	}
    }

    for(int i = 0;i < schuesse.size();i++)
    {
	schussSprite.SetPosition(schuesse[i].position);
	window.Draw(schussSprite);
    }

    window.Draw(player);
    window.Draw(energySprite);
    window.Draw(string);

    if(newLevel)
    {
	std::ostringstream temp;
	temp<<"Level "<<level;
	newLevelString.SetText(temp.str());
	window.Draw(newLevelString);
    }

    window.Display();
}

bool Game::loop()
{
    init();

    while(window.IsOpened())
    {
	getInput();
	checkCollisions();
	if(!stopped)
	{
	    updateSprites();
	    updateWindow();
	}
	else
	{
	    window.Clear();

	    string.SetText("Verloren!\nZum Neustarten die Eingabetaste dr�cken.\nSpielernummer zum speichern des Ergebnisses\neingeben (1 - 9).");
	    window.Draw(string);

	    window.Display();
	}
	if(newGame)
	    window.Close();

	if(clk2.GetElapsedTime() < 1.5)
	    newLevel = true;
	else
	    newLevel = false;

	if(clk2.GetElapsedTime() >= 60)
	{
	    clk2.Reset();
	    level++;

	    if(randomInt > 20)
		randomInt -= 20;
	}
    }

    return true;
}