#ifndef OBJECT_H
#define OBJECT_H
#define _USE_MATH_DEFINES

#include <cmath>
#include <SFML/Graphics.hpp>

class Object
{
public:
    sf::Vector2f position, size, direction;
    int type;
    float rotation;
    bool hit;
public:
    Object();
    void init(sf::Vector2f pos, sf::Vector2f spriteSize, int typ);
};

#endif // OBJECT_H
