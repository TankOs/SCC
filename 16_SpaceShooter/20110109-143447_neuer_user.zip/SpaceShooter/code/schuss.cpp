#include "schuss.h"

Schuss::Schuss()
{
}

void Schuss::start(sf::Vector2f pos, sf::Vector2f dir)
{
    position = pos;
    direction = dir;
}
