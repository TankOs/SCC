#ifndef GAME_H
#define GAME_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <sstream>
#include <fstream>
#include <deque>
#include "object.h"
#include "schuss.h"

class Game
{
public: bool newGame;
private:
    bool stopped,newLevel;
    float positionX,positionY,maxRot,rot,rotSpeed,speedX,damage,energy,tempY;
    int maxBackgroundY,randomInt,randomInt2,randomInt3,points,level,highScore;
    sf::Vector2i windowSize;
    sf::Vector2f playerSize;
    std::pair<float, float> playerMinMaxX;
    std::deque<Object> objects;
    std::deque<Schuss> schuesse;
    std::vector<sf::Vector2f> objSize;
    std::vector<sf::Vector2f> bonusObjPositions;
    sf::Sprite player,background,spr1,spr2,spr3,energySprite,bonusObj,schussSprite;
    sf::Image playerImage,backgroundImage,img1,img2,img3,energyImg,bonusObjImg,schussImg;
    sf::RenderWindow window;
    sf::Event event;
    sf::Font font;
    sf::SoundBuffer soundbuffer;
    sf::Sound sound;
    sf::String string,newLevelString;
    sf::Randomizer random;
    sf::Clock clk,clk2,clk3;

public:
    Game();
private:
    float fps();
    void stopGame();
    void resetGame(int i);
    void playerDamage();
    void init();
    void initObjects();
    void getInput();
    void generateObjects();
    void updateSprites();
    void checkCollisions();
    void updateWindow();
public: bool loop();
};

#endif // GAME_H
