﻿STEUERUNG:
←↑→↓		Steuerung des Raumschiffs
Leertaste	Projektil abschießen
Umschalttaste	Waffentyp wechseln
Esc		Programm beenden


HINWEISE/FEHLERQUELLEN:
Dieses Spiel wurde mit SFML 2, Revision 1769 getestet und gelinkt.
Um die mitgelieferten Windows-Binaries auszuführen, muss auf dem Zielrechner das VCredist 2010 installiert sein.
Download: -x64: http://www.microsoft.com/downloads/details.aspx?familyid=BD512D9E-43C8-4655-81BF-9350143D5867&displaylang=de
          -x86: http://www.microsoft.com/downloads/details.aspx?FamilyID=a7b7a05e-6de6-4d3a-a423-37bf0912db84&displayLang=de
Die mitgelieferten Binaries funktionieren nicht mit dem AMD Catalyst 10.11 und 10.12, da dieser zu SFML inkompatibel ist. Installieren sie den Catalyst 10.10e.
Download: - x86 und x64: http://support.amd.com/us/kbarticles/Pages/gpu88-catalyst-10-10e-hotfix.aspx


QUELLEN/LIZENZ:
Hintergrund.png: Public domain. Auf Basis eines Bildes der NASA (gefunden auf: hubble.nasa.gov)
Spieler.png: Public domain. Russische Föderation (Buran-Raumfähren-Projekt, gefunden auf www.wikipedia.de)
Gegner.png: "Creative Commons"-Lizenz 3.0. Erzeugt auf Basis eines Bildes von Steven S. Pietrobon. (gefunden auf de.wikipedia.org/w/index.php?title=Datei:Shenzhou_front_white_shadow.png&filetimestamp=20061127233318)
Drohne.ogg: "Creative Commons Sampling Plus 1.0"-Lizenz. Autor: PhreaKsAccount (freetype.org)

Der Sourcecode und die anderen Mediendateien stehen unter GPL v3.




Viel Spaß!