#include "SpaceShooter.h"
#include "Ressourcen.h"


void SpaceShooter::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.SetView(Ich.Kamera);
	Target.Draw(Ich);
	for(auto i = gegner.cbegin(), j = gegner.cend(); i != j; ++i) {
		Target.Draw(*i);
	}
	for(auto i = PowerUps.cbegin(), j = PowerUps.cend(); i != j; ++i) {
		Target.Draw(*i);
	}
	for(auto i = Projektile.cbegin(), j = Projektile.cend(); i != j; ++i) {
		Target.Draw(**i);
	}
	Target.Draw(Grenze);
	Target.SetView(Target.GetDefaultView());
	Target.Draw(mGeschwindigkeit);
	Target.Draw(mGeschwindigkeitsDir);
	Target.Draw(aLeben);
	Target.Draw(aMunition);
	Target.Draw(aTreibstoff);
	Target.Draw(sLeben);
	Target.Draw(sMunition);
	Target.Draw(sTreibstoff);
}

void SpaceShooter::Run(const sf::Input& IP, bool Umschalttaste, float Time) {
	// Ich
	Ich.Run(IP, Time);

	// Projektile
	for(auto i = Projektile.begin(), j = Projektile.end(); i != j; ++i) {
		if((*i)->Run(Time)) {
			delete *i;
			i = Projektile.erase(i);
		}
		else if((*i)->Sender != &Ich && Collision(Ich, **i)) {
			Ich.Leben -= (*i)->GetSchaden();
			Punkte -= (int32_t)(*i)->GetSchaden();
			delete *i;
			i = Projektile.erase(i);
		}
		else {
			for(auto k = gegner.begin(), l = gegner.end(); k != l; ++k) {
				if((*i)->Sender != &(*k) && Collision(*k, **i)) {
					k->Leben -= (*i)->GetSchaden();
					if((*i)->Sender == &Ich)
						Punkte += (int32_t)(*i)->GetSchaden();
					delete *i;
					i = Projektile.erase(i);
					break;
				}
			}
		}
		if(i == j) break;
	}
	
	// Gegner
	sf::Vector2f Ziel = Ich.GetPosition();
	for(auto i = gegner.begin(), j = gegner.end(); i != j; ++i) {
		if(Collision(*i, Ich)) { // Kollision mit Spieler
			Ich.Leben -= std::pow((i->Bewegung-Ich.Bewegung).v, 2);
			Punkte -= std::pow((i->Bewegung-Ich.Bewegung).v, 2);
			i = gegner.erase(i);
			Ich.Crash.Play();
			if(i == j) break;
		}
		else {
			std::pair<bool, Projektil*> p = i->Run(Time, Ziel);
			if(p.first) {
				i = gegner.erase(i);
				if(i == j) break;
			}
			else if(p.second != nullptr) {
				Projektile.push_back(p.second);
				p.second->Sender = &(*i);
			}
		}
	}
	if(std::rand()% std::max<int>(1, (int)(0.5f+((float)gegner.size())/15.f)/Time) == 0)
	{
		gegner.push_back(Gegner(Ich.GetPosition()));
	}

	// PowerUps
	for(auto i = PowerUps.begin(), j = PowerUps.end(); i != j; ++i) {
		if(Collision(*i, Ich)) {
			switch(i->Typ) {
				case PowerUp::LEBEN:
					Ich.Leben = std::min(200.f, Ich.Leben+100.f);
					break;
				case PowerUp::TREIBSTOFF:
					Ich.Treibstoff = std::min(100.f, Ich.Treibstoff+50.f);
					break;
				case PowerUp::DROHNE:
					Ich.Munition.Add(&Projektil::Typ::Drohne, 1);
					break;
				case PowerUp::LASER:
					Ich.Munition.Add(&Projektil::Typ::Laser, 15);
					break;
				case PowerUp::KUGEL:
					Ich.Munition.Add(&Projektil::Typ::Kugel, 50);
					break;
			}
			PowerUps.erase(i);
			PowerUps.push_back(PowerUp());
			Ich.PowerUpSound.Play();
			break;
		}
	}

	// Men�/Steuerung
	if(Umschalttaste) {
		++Ich.Munition;
		sMunition.SetImage(Ich.Munition.GetLogo());
		aMunition.Max = Ich.Munition.GetMax();
		aMunition.ZuBeobachten = Ich.Munition.GetVorat();
	}
	if(IP.IsKeyDown(sf::Key::Space)) {
		Projektil* p = Ich.Munition(Ich.GetPosition(), Ich.Bewegung, Ich.GetRotation());
		if(p != nullptr) {
			Projektile.push_back(p);
			p->Sender = &Ich;
		}
	}
	mGeschwindigkeit.SetString("v: " + std::to_string((long double)Ich.Bewegung.v));
	mGeschwindigkeitsDir.SetRotation(Ich.Bewegung.Alpha);
}

SpaceShooter::SpaceShooter()
	: Ich(), aLeben(&Ich.Leben, 200.f, sf::FloatRect(40,738,150,15)), aMunition(Ich.Munition.GetVorat(), Ich.Munition.GetMax(), sf::FloatRect(40,711,150,15)), aTreibstoff(&Ich.Treibstoff, 100.f, sf::FloatRect(40,684,150,15)),
	  sLeben(RM.Get<sf::Image>("Leben.png"), sf::Vector2f(5, 735)), sMunition(Ich.Munition.GetLogo(), sf::Vector2f(5, 704)), sTreibstoff(RM.Get<sf::Image>("Treibstoff.png"), sf::Vector2f(8, 678)),
	  Feldgrenze(-5000,-5000,10000,10000), Grenze(sf::Shape::Rectangle(Feldgrenze, sf::Color(0,0,0,0), 3, sf::Color(225,25,25,200))), mGeschwindigkeit("v: 0"), mGeschwindigkeitsDir(sf::FloatRect(920,633,75,75))
{
	for(uint16_t i = 0; i < 200; i++) {
		PowerUps.push_back(PowerUp());
	}
	mGeschwindigkeit.SetPosition(900, 723);
	mGeschwindigkeit.SetColor(sf::Color(50,225,50,200));
}

SpaceShooter::~SpaceShooter() {
	for(auto i = Projektile.cbegin(), j = Projektile.cend(); i != j; ++i) {
		delete *i;
	}
}
