#include "Ressourcen.h"


template<>
void Ressource::Load<sf::Image>(const std::string& pfad) {
	if(Type == RES_NONE)
	{
		Type = RES_IMAGE;
		Image = new sf::Image();
		Image->LoadFromFile("Grafik/" + pfad);
	}
}
template<>
void Ressource::Load<sf::SoundBuffer>(const std::string& pfad) {
	if(Type == RES_NONE)
	{
		Type = RES_SOUND;
		Sound = new sf::SoundBuffer();
		Sound->LoadFromFile("Sound/" + pfad);
	}
}
template<>
void Ressource::Load<sf::Font>(const std::string& pfad) {
	if(Type == RES_NONE)
	{
		Type = RES_FONT;
		Font = new sf::Font();
		Font->LoadFromFile("Fonts/" + pfad);
	}
}

template<>
sf::Image& Ressource::Get<sf::Image>() const {
	if(Type != RES_IMAGE) throw 0;
	return(*Image);
}
template<>
sf::SoundBuffer& Ressource::Get<sf::SoundBuffer>() const {
	if(Type != RES_SOUND) throw 0;
	return(*Sound);
}
template<>
sf::Font& Ressource::Get<sf::Font>() const {
	if(Type != RES_FONT) throw 0;
	return(*Font);
}

Ressourcenmanager RM;

Ressource::Ressource() : Type(RES_NONE) {}

Ressource::~Ressource() {
	switch(Type) {
		case RES_IMAGE:
			delete Image;
			break;
		case RES_SOUND:
			delete Sound;
			break;
		case RES_FONT:
			delete Font;
			break;
		default:
			break;
	}
}
