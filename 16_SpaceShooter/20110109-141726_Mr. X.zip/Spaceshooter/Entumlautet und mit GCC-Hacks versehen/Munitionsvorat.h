#ifndef MUNITIONSVORAT_H
#define MUNITIONSVORAT_H

#include "Global.h"
#include "Projektil.h"
#include <array>


class Munitionsvorat {
	std::array<std::pair<uint16_t, const Projektil::Typ*>, Projektil::Typ::Typanzahl> Vorat;
	size_t GewaehlterTyp;
	sf::Clock Ladeuhr;
public:
	Munitionsvorat();
	void operator++();
	void operator--();
	void Add(const Projektil::Typ* Typ, uint16_t Menge);
	Projektil* operator()(const sf::Vector2f& Position, const VectorP& Schuetzenbewegung, float Schuetzendrehung);
	const sf::Image& GetLogo() const;
	const uint16_t* GetVorat() const;
	uint16_t GetMax() const;
};


#endif
