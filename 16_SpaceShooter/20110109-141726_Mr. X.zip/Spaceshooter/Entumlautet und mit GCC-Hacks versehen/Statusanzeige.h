#ifndef STATUSANZEIGE_H
#define STATUSANZEIGE_H

#include "Global.h"


template<typename T>
class Statusanzeige : public sf::Drawable {
	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
	const sf::Shape Rand;
	const sf::FloatRect RandRect;
	mutable T alterWert;
	mutable T altesMax;
	mutable sf::Shape Inneres;
public:
	T Max;
	const T* ZuBeobachten;
	Statusanzeige(const T* ZuBeobachten, T max, const sf::FloatRect& rand);
};


#include "Statusanzeige.inl"

#endif
