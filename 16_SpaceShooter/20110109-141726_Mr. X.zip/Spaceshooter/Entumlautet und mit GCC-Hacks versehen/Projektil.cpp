#include "Projektil.h"
#include "Ressourcen.h"


const Projektil::Typ Projektil::Typ::Kugel("Kugel", 3, 20.f, 100, 0, 1000);
const Projektil::Typ Projektil::Typ::Laser("Laser", 7, 40.f, 200, 0, 200);
const Projektil::Typ Projektil::Typ::Drohne("Drohne", 20, 8.f, 1000, 10, 5);

Projektil::Typ::Typ(const std::string& name, uint32_t schaden, float fluggeschwindigkeit, uint16_t ladezeit, uint16_t flugzeit, uint16_t maxLager)
	: Name(name), Schaden(schaden), Fluggeschwindigkeit(fluggeschwindigkeit), Ladezeit(ladezeit), Flugzeit(flugzeit), MaxLager(maxLager)
{
}
const sf::Image& Projektil::Typ::GetImg() const {
	return(RM.Get<sf::Image>("M_" + Name + ".png"));
}
const sf::Image& Projektil::Typ::GetLImg() const {
	return(RM.Get<sf::Image>(Name + ".png"));
}
const sf::SoundBuffer& Projektil::Typ::GetSchuss() const {
	return(RM.Get<sf::SoundBuffer>(Name + ".ogg"));
}



void Projektil::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(Sp);
}

Projektil::Projektil(const Typ* t) : typ(t), Sp(t->GetImg()), Schuss(t->GetSchuss()) {
	SetOrigin(Sp.GetImage()->GetWidth()/2, Sp.GetImage()->GetHeight()/2);
}

void Projektil::Abschuss() {
	if(typ->Flugzeit > 0)
		Uhr.Reset();
}

bool Projektil::Run(float Time) {
	if(typ->Flugzeit > 0) {
		if(Uhr.GetElapsedTime() > typ->Flugzeit) {
			return(true);
		}
	}
	return(Flugobjekt::Run(Time));
}

float Projektil::GetSchaden() const {
	return((float)typ->Schaden);
}

const sf::Vector2i& Projektil::GetSize() const {
	static sf::Vector2i retVal(Sp.GetImage()->GetWidth(), Sp.GetImage()->GetHeight());
	return(retVal);
}
