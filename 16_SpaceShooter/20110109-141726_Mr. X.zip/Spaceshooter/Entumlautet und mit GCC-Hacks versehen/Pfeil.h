#ifndef PFEIL_H
#define PFEIL_H

#include "Global.h"


class Pfeil : public sf::Drawable {
	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
	const sf::Shape s1, s2, s3;
public:
	Pfeil(const sf::FloatRect& Groesse);
};


#endif
