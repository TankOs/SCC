#include "Flugobjekt.h"


bool Flugobjekt::Run(float Time) {
	Move(static_cast<sf::Vector2f>(Bewegung)*Time*50.f);
	return(std::abs(GetPosition().x) > 6500 || std::abs(GetPosition().y) > 6500);
}
