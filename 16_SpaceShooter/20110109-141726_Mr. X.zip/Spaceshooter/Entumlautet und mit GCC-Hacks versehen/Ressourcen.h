#ifndef RESSOURCEN_H
#define RESSOURCEN_H

#include "Global.h"
#include <typeinfo>


namespace sf {
	class SoundBuffer;
}

enum RESSOURCETYPE {RES_NONE, RES_IMAGE, RES_SOUND, RES_FONT};
	
class Ressource {
	RESSOURCETYPE Type;
	union {
		sf::Image* Image;
		sf::SoundBuffer* Sound;
		sf::Font* Font;
	};
public:
	Ressource();
	template<typename T>
	void Load(const std::string& pfad);
	template<typename T>
	T& Get() const;
	~Ressource();
};

class Ressourcenmanager {
	std::map<std::string, Ressource> Ressourcen;
public:
	template<typename T>
	T& Get(const std::string& pfad);
};

extern Ressourcenmanager RM;


#include "Ressourcen.inl"

#endif
