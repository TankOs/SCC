#ifndef GEGNER_H
#define GEGNER_H

#include "Global.h"
#include "Flugobjekt.h"
#include "Munitionsvorat.h"


class Gegner : public Flugobjekt {
	sf::Sprite Sp;
	sf::Clock Schussuhr;
	Munitionsvorat Vorat;

	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	float Leben;

	Gegner(const sf::Vector2f& Ziel = sf::Vector2f(0,0));
	std::pair<bool, Projektil*> Run(float Time, const sf::Vector2f& Ziel);
	const sf::Vector2i& GetSize() const;
};


#endif
