#ifndef GLOBAL_H
#define GLOBAL_H

#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <cstdint>


//#define DEBUG

enum Spielstatus {
	SPIEL, GAMEOVER
};

extern Spielstatus Status;
extern int32_t Punkte;


#endif
