#include "Ressourcen.h"
#include "SpaceShooter.h"
#include <cstdlib>
#include <fstream>


Spielstatus Status = SPIEL;
int32_t Punkte = 0;

int main() {
	std::srand(static_cast<unsigned int>(std::time(0)));

	sf::RenderWindow RW(sf::VideoMode(1024,768), "SpaceShooter", sf::Style::Close);
	RW.SetFramerateLimit(100);

	bool Running = true;
	sf::Event EV;
	const sf::Input& IP = RW.GetInput();

	SpaceShooter* Spiel = new SpaceShooter();

	sf::Sprite Hintergrund(RM.Get<sf::Image>("Hintergrund.png"));

#ifdef DEBUG
	sf::Text FPS; float counter = 0;
	FPS.SetPosition(10, 180);
	sf::Text Projektile;
	Projektile.SetPosition(10,45);
	sf::Text Gegner;
	Gegner.SetPosition(10,90);
	sf::Text PUs;
	PUs.SetPosition(10,135);
#endif
	sf::Text tPunkte("Punkte: 0");
	tPunkte.SetPosition(10, 5);
	tPunkte.SetColor(sf::Color(50,225,50,200));
	sf::Text GameOver("Ihr Raumschiff wurde zerst�rt!");
	GameOver.SetCharacterSize(75);
	GameOver.SetPosition(512 - GameOver.GetRect().Width/2, 380 - GameOver.GetRect().Height);
	GameOver.SetColor(sf::Color(240, 25, 25, 200));
	sf::Text Erreichtes;
	Erreichtes.SetColor(sf::Color(225, 225, 25));
	Erreichtes.SetCharacterSize(40);
	sf::Text CountDown("");
	CountDown.SetCharacterSize(100);
	CountDown.SetPosition(512 - CountDown.GetRect().Width/2, 390);
	CountDown.SetColor(sf::Color(25, 240, 25, 200));
	int8_t Zaehler = -1;
	sf::Clock Uhr;

	bool Umschalttaste = false;
	while(Running) {
		while(RW.GetEvent(EV)) {
			switch(EV.Type) {
				case sf::Event::Closed:
					Running = false;
					break;
				case sf::Event::KeyPressed:
					switch(EV.Key.Code) {
						case sf::Key::Escape:
							Running = false;
							break;
						case sf::Key::RShift: case sf::Key::LShift:
							Umschalttaste = true;
							break;
					}
					break;
			}
		}

		if(Status == SPIEL) {
			Spiel->Run(IP, Umschalttaste, RW.GetFrameTime());
			Umschalttaste = false;
		}
		else {
			if(Zaehler == -1) {
				delete Spiel;
				Uhr.Reset();
				Zaehler = 5;
				// Highscore
				std::ifstream ifs("Daten/Highscore.txt");
				if(!ifs.good()) {
					ifs.close();
					if(Punkte > 0)
						Erreichtes.SetString("F�rs erste Mal: Nicht schlecht.");
					else
						Erreichtes.SetString("Naja, sie m�sssen noch �ben.");
					std::ofstream ofs("Daten/Highscore.txt");
					ofs << Punkte;
				}
				else {
					int32_t Bestwert;
					ifs >> Bestwert;
					ifs.close();
					if(Bestwert >= Punkte) {
						if(Punkte < 0) {
							Erreichtes.SetString("Ihre Leistung war katastrophal. Sie m�ssen sich verbessern.");
						}
						else
							Erreichtes.SetString("Das k�nnen Sie besser.");
					}
					else {
						Erreichtes.SetString("Gratulation! Sie haben eine neue Bestleistung erzielt.");
						std::ofstream ofs("Daten/Highscore.txt");
						ofs << Punkte;
					}
				}
				Erreichtes.SetPosition(1024.f/2.f-Erreichtes.GetRect().Width/2, 768-5-Erreichtes.GetRect().Height);
			}
			if(Uhr.GetElapsedTime() > 1.f) {
				if(Zaehler == 0) {
					Status = SPIEL;
					Spiel = new SpaceShooter();
					Punkte = 0;
					Zaehler = -1;
					continue;
				}
				Uhr.Reset();
				Zaehler--;
			}
			CountDown.SetString(std::to_string((long long)Zaehler));
		}

		RW.Clear();
		RW.Draw(Hintergrund);
		if(Status == SPIEL) {
			RW.Draw(*Spiel);
#ifdef DEBUG
			Projektile.SetString("Projektile: " + std::to_string((long long)Spiel->Projektile.size()));
			RW.Draw(Projektile);
			Gegner.SetString("Gegner: " + std::to_string((long long)Spiel->gegner.size()));
			RW.Draw(Gegner);
			PUs.SetString("PowerUps: " + std::to_string((long long)Spiel->PowerUps.size()));
			RW.Draw(PUs);
			counter+=RW.GetFrameTime();
			if(counter >= 1.f) {
				FPS.SetString("FPS: " + std::to_string((long double)1/RW.GetFrameTime()));
				counter = 0.f;
			}
			RW.Draw(FPS);
#endif
		}
		else {
			RW.Draw(Erreichtes);
			RW.Draw(GameOver);
			RW.Draw(CountDown);
		}
		tPunkte.SetString("Punkte: " + std::to_string((long long)Punkte));
		RW.Draw(tPunkte);
		RW.Display();
	}

	delete Spiel;

	return(0);
}
