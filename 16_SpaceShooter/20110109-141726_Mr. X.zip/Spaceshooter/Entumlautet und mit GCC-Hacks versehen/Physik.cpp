#include "Physik.h"
#include <cmath>


#define PI 3.14159265358979323846f


inline float radtodeg(float f) {
	return(180.0f*f/PI);
}
static inline float degtorad(float f) {
	return(f*PI/180.0f);
}


VectorP::VectorP(float V, float alpha) : v(V), Alpha(alpha) {}
VectorP::VectorP(const sf::Vector2f& vec) : v(sqrt(vec.x*vec.x+vec.y*vec.y)), Alpha(radtodeg(atan2(vec.x, vec.y))) {}

VectorP::operator sf::Vector2f() const {
	float alpha = degtorad(Alpha);
	return(sf::Vector2f(v*sin(alpha), v*cos(alpha)));
}

void VectorP::Beschleunigen(float a, float t, float beta) { // v=a*t + v0
	*this = *this + VectorP(a*t, beta);
}

VectorP operator+(const VectorP& l, const VectorP& r) {
	sf::Vector2f v1 = l, v2 = r;
	return VectorP(v1+v2);
}
VectorP operator-(const VectorP& l, const VectorP& r) {
	sf::Vector2f v1 = l, v2 = r;
	return VectorP(v1-v2);
}
