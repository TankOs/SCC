#ifndef PHYSIK_H
#define PHYSIK_H

#include "Global.h"
#include <cmath>


inline float radtodeg(float f);


struct VectorP {
	float v;
	float Alpha;

	VectorP(float x = 0.f, float alpha = 0.f);
	VectorP(const sf::Vector2f& vec);
	operator sf::Vector2f() const;

	void Beschleunigen(float a, float t, float beta);
};

VectorP operator+(const VectorP& l, const VectorP& r);
VectorP operator-(const VectorP& l, const VectorP& r);


template<typename T, typename U>
bool Collision(const T& d1, const U& d2)
{
	sf::Vector2f d1Center = d1.GetPosition();
	sf::Vector2f d2Center = d2.GetPosition();

	float tempx = std::abs(d2Center.x-d1Center.x);
	float tempy = std::abs(d2Center.y-d1Center.y);
	float distance = sqrt(tempx*tempx + tempy*tempy);
	// Distanz zwischen Zentren < Summe der Radien beider die Objekte umschliessenden Kreise
	return(distance < (std::max(d1.GetSize().x, d1.GetSize().y)/2 + std::max(d2.GetSize().x, d2.GetSize().y)/2));
}


#endif
