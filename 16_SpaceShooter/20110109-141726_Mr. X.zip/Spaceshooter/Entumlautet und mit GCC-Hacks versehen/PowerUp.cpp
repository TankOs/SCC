#include "PowerUp.h"
#include "Ressourcen.h"


void PowerUp::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(Sp);
}

PowerUp::PowerUp() : Typ((PowerUp::typ)(std::rand() % TEND)) {
	switch(Typ) {
		case LEBEN:
			Sp.SetImage(RM.Get<sf::Image>("PU_Leben.png"));
			break;
		case TREIBSTOFF:
			Sp.SetImage(RM.Get<sf::Image>("PU_Treibstoff.png"));
			break;
		case KUGEL:
			Sp.SetImage(RM.Get<sf::Image>("PU_Kugel.png"));
			break;
		case LASER:
			Sp.SetImage(RM.Get<sf::Image>("PU_Laser.png"));
			break;
		case DROHNE:
			Sp.SetImage(RM.Get<sf::Image>("PU_Drohne.png"));
			break;
	}
	SetOrigin(Sp.GetImage()->GetWidth()/2, Sp.GetImage()->GetHeight()/2);
	SetPosition((int32_t)(std::rand()%(10000-Sp.GetImage()->GetWidth()/2))-5000, (int32_t)(std::rand()%(10000-Sp.GetImage()->GetHeight()/2))-5000);
}

const sf::Vector2i& PowerUp::GetSize() const {
	static sf::Vector2i retVal(Sp.GetImage()->GetWidth(), Sp.GetImage()->GetHeight());
	return(retVal);
}
