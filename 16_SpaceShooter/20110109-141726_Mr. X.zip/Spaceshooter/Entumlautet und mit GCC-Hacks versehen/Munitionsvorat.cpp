#include "Munitionsvorat.h"


Munitionsvorat::Munitionsvorat() : GewaehlterTyp(0) {
	Vorat[0].second = &Projektil::Typ::Laser;
	Vorat[1].second = &Projektil::Typ::Kugel;
	Vorat[2].second = &Projektil::Typ::Drohne;
}

void Munitionsvorat::operator++() {
	++GewaehlterTyp;
	if(GewaehlterTyp >= Vorat.size())
		GewaehlterTyp = 0;
}

void Munitionsvorat::operator--() {
	--GewaehlterTyp;
	if(GewaehlterTyp == 0)
		GewaehlterTyp = Vorat.size()-1;
}

void Munitionsvorat::Add(const Projektil::Typ* Typ, uint16_t Menge) {
	for(auto i = Vorat.begin(), j = Vorat.end(); i != j; ++i) {
		if(i->second == Typ) {
			if(Typ == Vorat[GewaehlterTyp].second && i->first == 0)
				Ladeuhr.Reset();
			i->first = std::min<uint16_t>(i->first+Menge, i->second->MaxLager);
			break;
		}
	}
}

Projektil* Munitionsvorat::operator()(const sf::Vector2f& Position, const VectorP& Schuetzenbewegung, float Schuetzendrehung) {
 	if(Vorat[GewaehlterTyp].first != 0 && Ladeuhr.GetElapsedTime()*1000.f >= Vorat[GewaehlterTyp].second->Ladezeit) {
		--Vorat[GewaehlterTyp].first;
		Ladeuhr.Reset();
		Projektil* p = new Projektil(Vorat[GewaehlterTyp].second);
		p->Bewegung = VectorP(Vorat[GewaehlterTyp].second->Fluggeschwindigkeit, Schuetzendrehung) + Schuetzenbewegung;
		p->SetPosition(Position);
		p->SetRotation(Schuetzendrehung);
		p->Schuss.Play();
		return(p);
	}
	return(0);
}

const sf::Image& Munitionsvorat::GetLogo() const {
	return(Vorat[GewaehlterTyp].second->GetLImg());
}

const uint16_t* Munitionsvorat::GetVorat() const {
	return(&Vorat[GewaehlterTyp].first);
}

uint16_t Munitionsvorat::GetMax() const {
	return(Vorat[GewaehlterTyp].second->MaxLager);
}
