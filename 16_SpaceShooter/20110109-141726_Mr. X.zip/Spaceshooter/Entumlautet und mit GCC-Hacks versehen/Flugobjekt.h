#ifndef FLUGOBJEKT_H
#define FLUGOBJEKT_H

#include "Global.h"
#include "Physik.h"


class Flugobjekt : public sf::Drawable {
protected:
	bool Run(float Time);
public:
	VectorP Bewegung;
	virtual const sf::Vector2i& GetSize() const = 0;
};


#endif
