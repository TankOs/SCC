#include "Pfeil.h"


void Pfeil::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(s1);
	Target.Draw(s2);
	Target.Draw(s3);
}

Pfeil::Pfeil(const sf::FloatRect& rand)
	: s1(sf::Shape::Line(rand.Width/2, 0, rand.Width/2, rand.Height, 3, sf::Color(50,225,50,200))),
	  s2(sf::Shape::Line(rand.Width/2, rand.Height, 0, rand.Height*2/5, 3, sf::Color(50,225,50,200))),
	  s3(sf::Shape::Line(rand.Width/2, rand.Height, rand.Width, rand.Height*2/5, 3, sf::Color(50,225,50,200))),
	  sf::Drawable(sf::Vector2f(rand.Left+rand.Width/2, rand.Top+rand.Height/2))
{
	SetOrigin(rand.Width/2, rand.Height/2);
}
