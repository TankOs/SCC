#ifndef SPIELER_H
#define SPIELER_H

#include "Global.h"
#include "Munitionsvorat.h"
#include "Flugobjekt.h"


class Spieler : public Flugobjekt {
	sf::Sprite Sp;
	bool Ruecktrieb, Vortrieb, SeittriebL, SeittriebR;
	sf::Sprite SP_r, SP_v, SP_sl, SP_sr;

	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	sf::View Kamera;
	float Leben, Treibstoff;
	Munitionsvorat Munition;
	sf::Sound Crash;
	sf::Sound PowerUpSound;

	void Run(const sf::Input& IP, float Time);
	const sf::Vector2i& GetSize() const;
	Spieler();
};


#endif
