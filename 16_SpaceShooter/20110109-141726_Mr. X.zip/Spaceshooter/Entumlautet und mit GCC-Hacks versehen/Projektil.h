#ifndef PROJEKTIL_H
#define PROJEKTIL_H

#include "Global.h"
#include "Flugobjekt.h"


class Projektil : public Flugobjekt {
public:
	struct Typ {
		const std::string Name;
		const uint32_t Schaden;
		const float Fluggeschwindigkeit;
		const uint16_t Ladezeit;
		const uint16_t Flugzeit;
		const uint16_t MaxLager;

		Typ(const std::string& name, uint32_t schaden, float fluggeschwindigkeit, uint16_t ladezeit, uint16_t flugzeit, uint16_t maxLager);
		const sf::Image& GetImg() const;
		const sf::Image& GetLImg() const;
		const sf::SoundBuffer& GetSchuss() const;

		static const Typ Kugel, Laser, Drohne;
		static const uint16_t Typanzahl = 3;
	};

private:
	sf::Sprite Sp;
	const Typ* typ;
	sf::Clock Uhr;

	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	void* Sender;
	sf::Sound Schuss;

	Projektil(const Typ* t);
	void Abschuss();
	bool Run(float Time);
	float GetSchaden() const;
	const sf::Vector2i& GetSize() const;
};


#endif
