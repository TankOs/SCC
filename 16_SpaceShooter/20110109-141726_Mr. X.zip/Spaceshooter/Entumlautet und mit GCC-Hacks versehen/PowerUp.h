#ifndef POWERUP_H
#define POWERUP_H

#include "Global.h"


class PowerUp : public sf::Drawable {
	sf::Sprite Sp;

	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	enum typ {LEBEN, TREIBSTOFF, KUGEL, LASER, DROHNE, TEND} Typ;

	PowerUp();
	const sf::Vector2i& GetSize() const;
};


#endif
