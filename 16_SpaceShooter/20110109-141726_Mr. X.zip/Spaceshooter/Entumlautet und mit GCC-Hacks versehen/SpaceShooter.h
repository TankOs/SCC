#ifndef SPACESHOOTER_H
#define SPACESHOOTER_H

#include "Global.h"
#include "Spieler.h"
#include "Gegner.h"
#include "PowerUp.h"
#include "Statusanzeige.h"
#include "Pfeil.h"
#include <list>


class SpaceShooter : public sf::Drawable {
public:
	Spieler Ich;
	std::list<Gegner> gegner;
	std::list<PowerUp> PowerUps;
	std::list<Projektil*> Projektile;

	sf::FloatRect Feldgrenze;
	sf::Shape Grenze;
	Statusanzeige<uint16_t> aMunition;
	Statusanzeige<float> aLeben, aTreibstoff;
	sf::Sprite sMunition, sLeben, sTreibstoff;
	sf::Text mGeschwindigkeit;
	Pfeil mGeschwindigkeitsDir;

	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	SpaceShooter();
	void Run(const sf::Input& IP, bool Umschalttaste, float Time);
	~SpaceShooter();
};


#endif
