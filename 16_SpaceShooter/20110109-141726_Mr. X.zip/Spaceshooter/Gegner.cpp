#include "Gegner.h"
#include "Ressourcen.h"
#include <cmath>


void Gegner::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(Sp);
}

Gegner::Gegner(const sf::Vector2f& Ziel) : Sp(RM.Get<sf::Image>("Gegner.png")), Leben(20.f) {
	Vorat.Add(&Projektil::Typ::Laser, 20);
	SetOrigin(Sp.GetImage()->GetWidth()/2, Sp.GetImage()->GetHeight()/2);
	int32_t x;
	int32_t y;
	if(std::rand()%2 == 0) {
		x = std::rand()%2==0?-6000:6000;
		y = std::rand()%12000-6000;
	}
	else {
		x = std::rand()%12000-6000;
		y = std::rand()%2==0?-6000:6000;
	}
	SetPosition((float)x, (float)y);
	Bewegung.v = (float)(2+std::rand()%5);
	Bewegung.Alpha = radtodeg(atan2(Ziel.x - x, Ziel.y - y)) + sf::Randomizer::Random(-5.f, 5.f);
	SetRotation(Bewegung.Alpha);
}

std::pair<bool, Projektil*> Gegner::Run(float Time, const sf::Vector2f& Ziel) {
	std::pair<bool, Projektil*> retVal(false, nullptr);
	if(Leben <= 0) {
		Punkte += 20;
		retVal.first = true;
	}
	else
		retVal.first = Flugobjekt::Run(Time);
	if(!retVal.first) {
		// Drehen
		float xDist = Ziel.x - GetPosition().x;
		float yDist = Ziel.y - GetPosition().y;
		float distance = std::sqrt(xDist*xDist + yDist*yDist);

		if(distance <= 2000.f) { // Schie�en
			SetRotation(radtodeg(atan2(xDist, yDist)));

			if(distance <= 300.f && Schussuhr.GetElapsedTime() > 1.5f) {
				Schussuhr.Reset();
				Projektil* P = Vorat(GetPosition(), Bewegung, GetRotation());
				retVal.second = P;
			}
		}
	}
	return(retVal);
}

const sf::Vector2i& Gegner::GetSize() const {
	static sf::Vector2i retVal(Sp.GetImage()->GetWidth(), Sp.GetImage()->GetHeight());
	return(retVal);
}
