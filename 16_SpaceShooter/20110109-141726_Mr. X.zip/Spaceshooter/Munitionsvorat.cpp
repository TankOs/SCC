#include "Munitionsvorat.h"


Munitionsvorat::Munitionsvorat() : Gew�hlterTyp(0) {
	Vorat[0].second = &Projektil::Typ::Laser;
	Vorat[1].second = &Projektil::Typ::Kugel;
	Vorat[2].second = &Projektil::Typ::Drohne;
}

void Munitionsvorat::operator++() {
	++Gew�hlterTyp;
	if(Gew�hlterTyp >= Vorat.size())
		Gew�hlterTyp = 0;
}

void Munitionsvorat::operator--() {
	--Gew�hlterTyp;
	if(Gew�hlterTyp == 0)
		Gew�hlterTyp = Vorat.size()-1;
}

void Munitionsvorat::Add(const Projektil::Typ* Typ, uint16_t Menge) {
	for(auto i = Vorat.begin(), j = Vorat.end(); i != j; ++i) {
		if(i->second == Typ) {
			if(Typ == Vorat[Gew�hlterTyp].second && i->first == 0)
				Ladeuhr.Reset();
			i->first = std::min<uint16_t>(i->first+Menge, i->second->MaxLager);
			break;
		}
	}
}

Projektil* Munitionsvorat::operator()(const sf::Vector2f& Position, const VectorP& Sch�tzenbewegung, float Sch�tzendrehung) {
 	if(Vorat[Gew�hlterTyp].first != 0 && Ladeuhr.GetElapsedTime()*1000.f >= Vorat[Gew�hlterTyp].second->Ladezeit) {
		--Vorat[Gew�hlterTyp].first;
		Ladeuhr.Reset();
		Projektil* p = new Projektil(Vorat[Gew�hlterTyp].second);
		p->Bewegung = VectorP(Vorat[Gew�hlterTyp].second->Fluggeschwindigkeit, Sch�tzendrehung) + Sch�tzenbewegung;
		p->SetPosition(Position);
		p->SetRotation(Sch�tzendrehung);
		p->Schuss.Play();
		return(p);
	}
	return(nullptr);
}

const sf::Image& Munitionsvorat::GetLogo() const {
	return(Vorat[Gew�hlterTyp].second->GetLImg());
}

const uint16_t* Munitionsvorat::GetVorat() const {
	return(&Vorat[Gew�hlterTyp].first);
}

uint16_t Munitionsvorat::GetMax() const {
	return(Vorat[Gew�hlterTyp].second->MaxLager);
}
