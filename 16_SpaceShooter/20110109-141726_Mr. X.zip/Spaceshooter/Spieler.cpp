#include "Spieler.h"
#include "Ressourcen.h"


void Spieler::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(Sp);
	if(Vortrieb)
		Target.Draw(SP_v);
	if(R�cktrieb)
		Target.Draw(SP_r);
	if(SeittriebR)
		Target.Draw(SP_sr);
	if(SeittriebL)
		Target.Draw(SP_sl);
}

Spieler::Spieler()
	: SP_v(RM.Get<sf::Image>("SpielerV.png")), SP_r(RM.Get<sf::Image>("SpielerR.png")), SP_sr(RM.Get<sf::Image>("SpielerSR.png")), SP_sl(RM.Get<sf::Image>("SpielerSL.png")), 
	Sp(RM.Get<sf::Image>("Spieler.png")), Kamera(sf::FloatRect(0.f,0.f,1024.f,768.f)), Leben(200.f), Treibstoff(100.f), Crash(RM.Get<sf::SoundBuffer>("Crash.ogg")), PowerUpSound(RM.Get<sf::SoundBuffer>("PowerUp.ogg"))
{
	SetOrigin(Sp.GetImage()->GetWidth()/2, Sp.GetImage()->GetHeight()/2);
	SetPosition(512, 384);
	SetRotation(180);
}

const sf::Vector2i& Spieler::GetSize() const {
	static sf::Vector2i retVal(Sp.GetImage()->GetWidth(), Sp.GetImage()->GetHeight());
	return(retVal);
}

void Spieler::Run(const sf::Input& IP, float Time) {
	if(Treibstoff > 0) {
		SeittriebL = IP.IsKeyDown(sf::Key::Left);
		if(SeittriebL) {
			Rotate(100.f*Time);
			Treibstoff -= 1*Time;
		}
		SeittriebR = IP.IsKeyDown(sf::Key::Right);
		if(SeittriebR) {
			Rotate(-100.f*Time);
			Treibstoff -= 1*Time;
		}
		Vortrieb = IP.IsKeyDown(sf::Key::Up);
		if(Vortrieb) {
			Bewegung.Beschleunigen(5.f, Time, GetRotation());
			Treibstoff -= 2.5f*Time;
		}
		R�cktrieb = IP.IsKeyDown(sf::Key::Down);
		if(R�cktrieb) {
			Bewegung.Beschleunigen(-3.f, Time, GetRotation());
			Treibstoff -= 1*Time;
		}
	}
	else {
		R�cktrieb = false;
		Vortrieb = false;
		SeittriebL = false;
		SeittriebR = false;
	}
	Flugobjekt::Run(Time);
	Kamera.Move(static_cast<sf::Vector2f>(Bewegung)*Time*50.f);

	if(GetPosition().x < -5000 || GetPosition().x > 5000) {
		Leben -= std::pow(std::abs(static_cast<sf::Vector2f>(Bewegung).x), 2)/4.f;
		Flugobjekt::Run(-Time);
		Kamera.Move(static_cast<sf::Vector2f>(Bewegung)*-Time*50.f);
		Bewegung.v = 0;
	}
	if(GetPosition().y < -5000 || GetPosition().y > 5000) {
		Leben -= std::pow(std::abs(static_cast<sf::Vector2f>(Bewegung).y), 2)/4.f;
		Flugobjekt::Run(-Time);
		Kamera.Move(static_cast<sf::Vector2f>(Bewegung)*-Time*50.f);
		Bewegung.v = 0;
	}
	if(Leben <= 0)
		Status = GAMEOVER;
}
