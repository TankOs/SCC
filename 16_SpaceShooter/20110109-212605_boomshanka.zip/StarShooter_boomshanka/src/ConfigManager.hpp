#ifndef CONFIGMANAGER_HPP
#define CONFIGMANAGER_HPP

#include <string>

#include <SFML/Window.hpp>


class ConfigManager
{
	private:
		int myArgc;
		char** myArgv;
		char* myProgramName;
		
		bool myQuit;
		
		sf::VideoMode myVideoMode;
		unsigned long myStyle;
		
		unsigned int myLevel;
		unsigned int myMaxLevel;
	public:
		ConfigManager(int argc, char* argv[]);
		~ConfigManager();
		
		void Load();
		
		bool LoadConfig(const std::string& path="settings.conf");
		void LoadDefault();
		
		void SaveConfig(const std::string& path="settings.conf");
		
		void Help();
		void Resolution(const std::string&);
		
		//Getter
		const sf::VideoMode& GetVideoMode() {return myVideoMode;}
		unsigned long GetStyle() {return myStyle;}
		
		unsigned int& GetLevelPointer() {return myLevel;}
		unsigned int GetMaxLevel() {return myMaxLevel;}
		
		void NextLevel() {++myLevel; if(myLevel>myMaxLevel) myMaxLevel=myLevel; }
		
		bool Quit() {return myQuit;}
		
		//Seter
		void SetVideoMode(const sf::VideoMode& videomode) {myVideoMode=videomode;}
		void SetStyle(unsigned long style) {myStyle=style;}
};


#endif


