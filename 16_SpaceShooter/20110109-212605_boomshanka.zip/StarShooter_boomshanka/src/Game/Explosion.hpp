#ifndef EXPLOSION_HPP
#define EXPLOSION_HPP

#include <list>
#include <queue>

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "Explosionsprite.hpp"


class Explosion
{
	private:
		sf::Vector2i myWindowsize;
		
		sf::Image myExplosionImage;
		
		std::list<Explosionsprite*> myExplosions;
		std::queue<sf::Sound*> mySoundList;
		sf::SoundBuffer mySmallBuffer;
		sf::SoundBuffer myNormalBuffer;
		sf::SoundBuffer myPlayerBuffer;
		sf::Sound mySound;
		sf::Sound myPlayerSound;
	public:
		
		void Update();
		void NewExplosion(const sf::Vector2f&, float scale=1.f);
		void Draw(sf::RenderWindow&);
		
		void LoadMedia(const sf::Vector2i&);
		
		void SmallDamageSound();
		void NormalDamageSound();
		void PlayerDamageSound();
};



#endif


