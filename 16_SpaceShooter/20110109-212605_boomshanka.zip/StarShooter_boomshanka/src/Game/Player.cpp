#include "Player.hpp"

#include <sstream>



Player::Player()
:myLive(500),
myShield(500),
myPoints(0),
my2Points(0),
myPhotonicTorpedoTime(0.4),
myLaserCanonTime(0.5),
myPlasmaTorpedoTime(0.8),
myPhaseCanonTime(1),
myPhaserCanonTime(1.3)
{

}




void Player::Update(const sf::Input& input, Weapons& weapons, float time)
{
	mySprite.SetPosition(input.GetMouseX(), input.GetMouseY()-mySprite.GetSize().y*(input.GetMouseY()/static_cast<float>(myWindowsize.y)));
	
	if(Alive())
	{
		if(input.IsMouseButtonDown(sf::Mouse::Left))
		{
			Fire(weapons, time);
			myShield+=10*time;
			if(myShield>500) myShield=500;
		}
		else
		{
			myShield+=40*time;
			if(myShield>500) myShield=500;
		}
	}
	
	myShieldSprite.SetScale((myShield/500.f)*(myWindowsize.x/1600.f),(myShield/500.f)*(myWindowsize.y/1200.f));
	
	if(myPoints>2000)
	{
		myPhaserText.SetColor(sf::Color(10,10,255));
		myPhaseText.SetColor(sf::Color(255,10,10));
		myPlasmaText.SetColor(sf::Color(255,30,30));
		myLaserText.SetColor(sf::Color(10,255,10));
		myCanons.PhotonicTorpedos=true; myCanons.LaserCanons=true; myCanons.PlasmaTorpedos=true; myCanons.PhaseCanons=true; myCanons.PhaserCanons=true;
	}
	else if(myPoints>750)
	{
		myPhaseText.SetColor(sf::Color(255,10,10));
		myPlasmaText.SetColor(sf::Color(255,30,30));
		myLaserText.SetColor(sf::Color(10,255,10));
		myPhaserText.SetColor(sf::Color(30,30,30));
		myCanons.PhotonicTorpedos=true; myCanons.LaserCanons=true; myCanons.PlasmaTorpedos=true; myCanons.PhaseCanons=true; myCanons.PhaserCanons=false;
	}
	else if(myPoints>300)
	{
		myPlasmaText.SetColor(sf::Color(255,30,30));
		myLaserText.SetColor(sf::Color(10,255,10));
		myPhaseText.SetColor(sf::Color(30,30,30));
		myPhaserText.SetColor(sf::Color(30,30,30));
		myCanons.PhotonicTorpedos=true; myCanons.LaserCanons=true; myCanons.PlasmaTorpedos=true; myCanons.PhaseCanons=false; myCanons.PhaserCanons=false;
	}
	else if(myPoints>100)
	{
		myLaserText.SetColor(sf::Color(10,255,10));
		myPlasmaText.SetColor(sf::Color(30,30,30));
		myPhaseText.SetColor(sf::Color(30,30,30));
		myPhaserText.SetColor(sf::Color(30,30,30));
		myCanons.PhotonicTorpedos=true; myCanons.LaserCanons=true; myCanons.PlasmaTorpedos=false; myCanons.PhaseCanons=false; myCanons.PhaserCanons=false;
	}
	else
	{
		myLaserText.SetColor(sf::Color(30,30,30));
		myPlasmaText.SetColor(sf::Color(30,30,30));
		myPhaseText.SetColor(sf::Color(30,30,30));
		myPhaserText.SetColor(sf::Color(30,30,30));
		myCanons.PhotonicTorpedos=true; myCanons.LaserCanons=false; myCanons.PlasmaTorpedos=false; myCanons.PhaseCanons=false; myCanons.PhaserCanons=false;
	}
}



void Player::Draw(sf::RenderWindow& window)
{
	
	window.Draw(mySprite);
}





void Player::LoadMedia(const sf::Vector2i& windowsize)
{
	myImage.LoadFromFile("img/enterprise.png");
	mySprite.SetImage(myImage);
	mySprite.SetOrigin(45,0);
	mySprite.SetScale(windowsize.x/1600.f, windowsize.y/1200.f);
	
	myWindowsize=windowsize;
	
	myFont.LoadFromFile("img/AstronBoyVideo.ttf");
	myPointText.SetString("Points: 0");
	myPointText.SetFont(myFont);
	myPointText.SetCharacterSize(40*(windowsize.x/1600.f));
	myPointText.SetPosition(0,myWindowsize.y-myPointText.GetRect().Height);
	
	myPhotonicText.SetString("Photonic-Torpedo");
	myPhotonicText.SetColor(sf::Color(230,220,50));
	myPhotonicText.SetFont(myFont);
	myPhotonicText.SetCharacterSize(40*(windowsize.x/1600.f));
	
	myLaserText.SetString("Laser-Canon");
	myLaserText.SetColor(sf::Color(30,30,30));
	myLaserText.SetFont(myFont);
	myLaserText.SetCharacterSize(40*(windowsize.x/1600.f));
	
	myPlasmaText.SetString("Plasma-Torpedo");
	myPlasmaText.SetColor(sf::Color(30,30,30));
	myPlasmaText.SetFont(myFont);
	myPlasmaText.SetCharacterSize(40*(windowsize.x/1600.f));
	
	myPhaseText.SetString("Phase-Canon");
	myPhaseText.SetColor(sf::Color(30,30,30));
	myPhaseText.SetFont(myFont);
	myPhaseText.SetCharacterSize(40*(windowsize.x/1600.f));
	
	myPhaserText.SetString("Phaser-Canon");
	myPhaserText.SetColor(sf::Color(30,30,30));
	myPhaserText.SetFont(myFont);
	myPhaserText.SetCharacterSize(40*(windowsize.x/1600.f));
	
	
	myPhotonicText.SetPosition(myWindowsize.x*0.15,myWindowsize.y-myPointText.GetRect().Height);
	myLaserText.SetPosition(myWindowsize.x*0.35,myWindowsize.y-myPointText.GetRect().Height);
	myPlasmaText.SetPosition(myWindowsize.x*0.5,myWindowsize.y-myPointText.GetRect().Height);
	myPhaseText.SetPosition(myWindowsize.x*0.7,myWindowsize.y-myPointText.GetRect().Height);
	myPhaserText.SetPosition(myWindowsize.x-myPhaserText.GetRect().Width,myWindowsize.y-myPointText.GetRect().Height);
	
	mySoundBuffer.LoadFromFile("snd/damage/reactor_damage.ogg");
	mySound.SetBuffer(mySoundBuffer);
	
	myLiveImage.LoadFromFile("img/live.png");
	myShieldSprite.SetImage(myLiveImage);
	myLiveSprite.SetImage(myLiveImage);
	myShieldSprite.FlipX(true);
	myShieldSprite.SetColor(sf::Color::Blue);
	myLiveSprite.SetColor(sf::Color::Green);
	myShieldSprite.SetOrigin(myShieldSprite.GetSize());
	myLiveSprite.SetOrigin(0,myShieldSprite.GetSize().y);
	myShieldSprite.SetScale(myWindowsize.x/1600.f,myWindowsize.y/1200.f);
	myLiveSprite.SetScale(myWindowsize.x/1600.f,myWindowsize.y/1200.f);
	myShieldSprite.SetPosition(myWindowsize.x, myWindowsize.y);
	myLiveSprite.SetPosition(0,myWindowsize.y);
}




void Player::Fire(Weapons& weapons, float time)
{
	if(myCanons.PhotonicTorpedos && myPhotonicTorpedoClock.GetElapsedTime()>myPhotonicTorpedoTime)
	{
		myPhotonicTorpedoClock.Reset();
		weapons.AddPlayerShot(PhotonicTorpedos, mySprite.GetPosition());
	}
	if(myCanons.LaserCanons && myLaserCanonClock.GetElapsedTime()>myLaserCanonTime)
	{
		if(myLaserCanonClock.GetElapsedTime()>myLaserCanonTime+0.4)
			myLaserCanonClock.Reset();
		weapons.AddPlayerShot(LaserCanons, mySprite.GetPosition(), time);
	}
	if(myCanons.PlasmaTorpedos && myPlasmaTorpedoClock.GetElapsedTime()>myPlasmaTorpedoTime)
	{
		myPlasmaTorpedoClock.Reset();
		weapons.AddPlayerShot(PlasmaTorpedos, mySprite.GetPosition());
	}
	if(myCanons.PhaseCanons && myPhaseCanonClock.GetElapsedTime()>myPhaseCanonTime)
	{
		if(myPhaseCanonClock.GetElapsedTime()>myPhaseCanonTime+0.2)
			myPhaseCanonClock.Reset();
		weapons.AddPlayerShot(PhaseCanons, mySprite.GetPosition(), time);
	}
	if(myCanons.PhaserCanons && myPhaserCanonClock.GetElapsedTime()>myPhaserCanonTime)
	{
		if(myPhaserCanonClock.GetElapsedTime()>myPhaserCanonTime+0.8)
			myPhaserCanonClock.Reset();
		weapons.AddPlayerShot(PhaserCanons, mySprite.GetPosition(), time);
	}
	
}



const sf::Text& Player::GetPointText()
{
	if(myPoints!=my2Points)
	{
		my2Points=myPoints;
		std::string string("Points: "), str;
		std::stringstream sstr;
		sstr<<myPoints;
		sstr>>str;
		string+=str;
		myPointText.SetString(string);
		myPointText.SetPosition(0,myWindowsize.y-myPointText.GetRect().Height);
	}
	
	return myPointText;
}


void Player::DrawText(sf::RenderWindow& window)
{
	window.Draw(myPhotonicText);
	window.Draw(myLaserText);
	window.Draw(myPlasmaText);
	window.Draw(myPhaseText);
	window.Draw(myPhaserText);
	
	window.Draw(myShieldSprite);
	window.Draw(myLiveSprite);
}



bool Player::CheckCollision(const sf::Vector2f& position, float destruction)
{
	sf::Vector2f Origin(mySprite.GetOrigin());
	Origin.x*=mySprite.GetScale().x; Origin.y*=mySprite.GetScale().y;
	if(sf::Rect<float>(mySprite.GetPosition()-Origin,mySprite.GetSize()).Contains(position))
	{
		if(mySprite.GetPixel(mySprite.TransformToLocal(position).x,mySprite.TransformToLocal(position).y).a>2)
		{
			Damage(destruction);
			
			return true;
		}
	}
	
	return false;
}



void Player::Damage(float damage)
{
	myShield-=damage;
	if(myShield<0)
	{
		myLive+=myShield;
		myShield=0;
		myLiveSprite.SetScale((myLive/500.f)*(myWindowsize.x/1600.f),(myLive/500.f)*(myWindowsize.y/1200.f));
		if(mySound.GetStatus()==sf::Sound::Stopped)
			mySound.Play();
		
	}
}



