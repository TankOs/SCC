#include "GameState.hpp"

#include <string>
#include <sstream>
#include <fstream>



GameState::GameState(sf::RenderWindow& window, unsigned int& level)
:State(window),
myLevel(level),
myInput(window.GetInput())
{

}


GameState::~GameState()
{

}



void GameState::OnEnter()
{
	myWindow.ShowMouseCursor(false);
	myWindow.SetCursorPosition(myWindow.GetWidth()/2, myWindow.GetHeight());
	myFinish=false;
	
	myPlayer.LoadMedia(sf::Vector2i(myWindow.GetWidth(), myWindow.GetHeight()));
	myWeapons.LoadMedia(sf::Vector2i(myWindow.GetWidth(), myWindow.GetHeight()));
	myExplosions.LoadMedia(sf::Vector2i(myWindow.GetWidth(), myWindow.GetHeight()));
	
	if(!myBackground.LoadMedia(myLevel))
	{
		myLevel=1;
		myBackground.LoadMedia(myLevel);
	}
	
	myEnemy.LoadMedia(sf::Vector2i(myWindow.GetWidth(), myWindow.GetHeight()), myLevel);
	
	myBackground.Start(sf::Vector2i(myWindow.GetWidth(), myWindow.GetHeight()));
	
	LoadFile();
	
	myText.SetCharacterSize(50*(myWindow.GetWidth()/1600.f));
	myFont.LoadFromFile("img/AstronBoyVideo.ttf");
	myText.SetFont(myFont);
}


void GameState::OnLeave()
{

}



int GameState::Update()
{
	int state=CheckEvents();
	if(state!=State::NoChange)
		return state;
	
	myBackground.Update(myWindow.GetFrameTime());
	
	int negpoints=0;
	if(myFinish==false && myEnemy.Update(myWindow.GetFrameTime(), myWeapons, negpoints))
	{
		myFinish=true;
		myClock.Reset();
	}
	if(!myFinish)
	{
		myWeapons.CheckEnemyShots(myPlayer, myExplosions);
		myPlayer.AddPoints(myWeapons.CheckPlayerShots(myEnemy, myExplosions)+negpoints);
	}
	
	myPlayer.Update(myInput, myWeapons, myWindow.GetFrameTime());
	myWeapons.Update(myWindow.GetFrameTime());
	
	if(!myPlayer.Alive() && !myFinish)
	{
		myFinish=true;
		myClock.Reset();
		myExplosions.NewExplosion(myPlayer.GetCenter(),1.5);
	}
	
	myExplosions.Update();
	
	
	if(myFinish)
	{
		if(myClock.GetElapsedTime()<5)
		{
			if(myPlayer.Alive() && myPlayer.GetPoints()>=myMinimumPoints)
			{
				myText.SetString(myWinText);
				myText.SetColor(sf::Color(10,255,10));
			}
			else
			{
				myEnemy.Update(myWindow.GetFrameTime(), myWeapons, negpoints);
				myText.SetString(myLooseText);
				myText.SetColor(sf::Color(255,10,10));
			}
			myText.SetPosition(myWindow.GetWidth()/2.f-myText.GetRect().Width/2.f, myWindow.GetHeight()/2.f-myText.GetRect().Height/2.f);
		}
		else
		{
			if(myPlayer.Alive() && myPlayer.GetPoints()>=myMinimumPoints)
				return State::NextLevel;
			
			return State::Game;
		}
	}
	
	return State::NoChange;
}



void GameState::Draw()
{
	myWindow.Clear();
	
	myBackground.Draw(myWindow);
	myWindow.Draw(myPlayer.GetPointText());
	myPlayer.DrawText(myWindow);
	myWeapons.Draw(myWindow);
	
	myEnemy.Draw(myWindow);
	if(myPlayer.Alive())
		myPlayer.Draw(myWindow);
	myExplosions.Draw(myWindow);
	
	if(myFinish)
		myWindow.Draw(myText);
	
	
	myWindow.Display();
}



int GameState::CheckEvents()
{
	sf::Event event;
	
	while(myWindow.GetEvent(event))
	{
		switch(event.Type)
		{
			case sf::Event::Closed:
				return State::Quit;
				break;
			
			case sf::Event::KeyPressed:
				if(event.Key.Code == sf::Key::Escape)
					return State::Menu; // State::Menu;
			
			default:
				
				break;
		}
	}
	
	return State::NoChange;
}



void GameState::LoadFile()
{
	myMinimumPoints=0;
	
	std::string path("lev/level");
	std::string string;
	std::stringstream sstring;
	sstring<<myLevel;
	sstring>>string;
	path+=string;
	path+=".conf";
	
	std::ifstream file(path.c_str());
	
	if(file.fail())
		return;
	
	while(!file.eof())
	{
		std::getline(file,string);
		std::string str(string);
		std::stringstream sstr(string);
		sstr>>string;
		
		if(string=="WinMessage:")
		{
			myWinText=str.substr(12);
		}
		else if(string=="LooseMessage:")
		{
			myLooseText=str.substr(14);
		}
		else if(string=="MinimumPoints:")
		{
			sstr>>myMinimumPoints;
		}
	}
}



