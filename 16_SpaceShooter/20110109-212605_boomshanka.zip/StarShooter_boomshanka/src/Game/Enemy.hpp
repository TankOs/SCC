#ifndef ENEMY_HPP
#define ENEMY_HPP

#include <list>
#include <stack>

#include <SFML/Graphics.hpp>

#include "Enemyship.hpp"
#include "Weapons.hpp"


class Weapons;
class Enemyship;


class Enemy
{
	private:
		sf::Image myEnemyImage;
		std::list<Enemyship*> myEnemyships;
		
		std::stack<std::string> myMap;
		unsigned int myStage;
		
		sf::Vector2i myWindowSize;
		sf::Clock myTime;
	public:
		
		~Enemy();
		
		void LoadMedia(const sf::Vector2i&, unsigned int);
		
		bool Update(float, Weapons& weapons, int&);
		void Draw(sf::RenderWindow&);
		
		sf::Vector2i CheckCollision(const sf::Vector2f&, float, bool, sf::Vector2f&);
};


#endif


