#ifndef ENEMYSHIP_HPP
#define ENEMYSHIP_HPP

#include <SFML/Graphics.hpp>

#include "Weapons.hpp"


class Weapons;



class Enemyship : public sf::Sprite
{
	friend class Enemy;
	
	private:
		float myLive;
		int myPoints;
		float mySpeed;
		float myShootPeriod;
		int myWeapon;
		
		sf::Clock myClock;
	public:
		Enemyship(sf::Image& image) {SetImage(image);}
		
		bool RemoveLive(float live) {myLive-=live; if(myLive<=0) return true; return false;}
		
		void Update(Weapons&);
};


#endif


