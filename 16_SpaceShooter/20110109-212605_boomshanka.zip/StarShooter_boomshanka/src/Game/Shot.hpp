#ifndef SHOT_HPP
#define SHOT_HPP

#include <SFML/Graphics.hpp>

#include "../Vector2.hpp"


enum PlayerWeapons
{
	PhotonicTorpedos = 0,
	LaserCanons = 1,
	PlasmaTorpedos = 2,
	PhaseCanons = 3,
	PhaserCanons = 4
};


enum EnemyWeapons
{
	First = 5,
	Second = 6,
	Third = 7,
	None = 8
};



class Shot : public sf::Sprite
{
	friend class Weapons;
	
	private:
		sfp::Vector2f mySpeed;
		int myWeaponType;
		float myDestruction;
		bool myImmortal;
		
		sf::Clock myClock;
		unsigned int mySubRect;
	public:
		Shot(sf::Image& img, int type):myWeaponType(type), mySubRect(1) {sf::Sprite::SetImage(img);}
		
		void Update(float time)
		{
			if(myClock.GetElapsedTime()>0.1)
			{
				int lenght=30;
				if(myWeaponType==PhotonicTorpedos || myWeaponType==PlasmaTorpedos) lenght=10;
				if(myWeaponType==First || myWeaponType==Second || myWeaponType==Third) lenght=50;
				SetSubRect(sf::Rect<int>(0,0+mySubRect*lenght,10,lenght));
				++mySubRect;
				if(mySubRect>2) mySubRect=0;
				myClock.Reset();
			}
			
			Move(mySpeed*time);
			
		}
};


#endif


