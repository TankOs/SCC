#include "Enemy.hpp"

#include <fstream>
#include <sstream>

#define STAGEFACTOR 0.8


Enemy::~Enemy()
{
	for(std::list<Enemyship*>::iterator it=myEnemyships.begin(); it!=myEnemyships.end(); ++it)
	{
		delete (*it);
	}
}



void Enemy::LoadMedia(const sf::Vector2i& windowsize, unsigned int level)
{
	myWindowSize=windowsize;
	myStage=0;
	
	myEnemyImage.LoadFromFile("img/enemy.png");
	
	
	std::string path("lev/level");
	std::string string;
	std::stringstream sstring;
	sstring<<level;
	sstring>>string;
	path+=string;
	path+=".conf";
	
	std::ifstream file(path.c_str());
	if(file.fail()) return;
	bool read=false;
	
	while(!file.eof())
	{
		std::getline(file,string);
		
		if(read)
		{
			if(string=="LevelEnd")
				break;
			
			myMap.push(string);
		}
		else if(string=="LevelBegin")
		{
			read=true;
		}
	}
}




bool Enemy::Update(float time, Weapons& weapons, int& negpoints)
{
	if(!myMap.empty() && myStage*STAGEFACTOR<myTime.GetElapsedTime())
	{
		if(myMap.top().length()==13)
		{
			for(unsigned int i=0; i<13; ++i)
			{
				switch(myMap.top()[i])
				{
					case '1':
						myEnemyships.push_front(new Enemyship(myEnemyImage));
						myEnemyships.front()->SetPosition((114.286f*static_cast<float>(i+1))*(myWindowSize.x/1600.f),0);
						myEnemyships.front()->SetScale(myWindowSize.x/1600.f, myWindowSize.y/1200.f);
						myEnemyships.front()->SetOrigin(myEnemyships.front()->GetSize().x/2.f,myEnemyships.front()->GetSize().y);
						myEnemyships.front()->myLive=50;
						myEnemyships.front()->myPoints=10;
						myEnemyships.front()->mySpeed=100;
						myEnemyships.front()->myShootPeriod=3;
						myEnemyships.front()->myWeapon=First;
						break;
						
					case '2':
						myEnemyships.push_front(new Enemyship(myEnemyImage));
						myEnemyships.front()->SetPosition((114.286f*static_cast<float>(i+1))*(myWindowSize.x/1600.f),0);
						myEnemyships.front()->SetScale(myWindowSize.x/1600.f, myWindowSize.y/1200.f);
						myEnemyships.front()->SetOrigin(myEnemyships.front()->GetSize().x/2.f,myEnemyships.front()->GetSize().y);
						myEnemyships.front()->myLive=75;
						myEnemyships.front()->myPoints=15;
						myEnemyships.front()->mySpeed=125;
						myEnemyships.front()->myShootPeriod=2.5;
						myEnemyships.front()->myWeapon=First;
						break;
						
					case '3':
						myEnemyships.push_front(new Enemyship(myEnemyImage));
						myEnemyships.front()->SetPosition((114.286f*static_cast<float>(i+1))*(myWindowSize.x/1600.f),0);
						myEnemyships.front()->SetScale(myWindowSize.x/1600.f, myWindowSize.y/1200.f);
						myEnemyships.front()->SetOrigin(myEnemyships.front()->GetSize().x/2.f,myEnemyships.front()->GetSize().y);
						myEnemyships.front()->myLive=150;
						myEnemyships.front()->myPoints=35;
						myEnemyships.front()->mySpeed=150;
						myEnemyships.front()->myShootPeriod=2.5;
						myEnemyships.front()->myWeapon=Second;
						break;
						
					case '4':
						myEnemyships.push_front(new Enemyship(myEnemyImage));
						myEnemyships.front()->SetPosition((114.286f*static_cast<float>(i+1))*(myWindowSize.x/1600.f),0);
						myEnemyships.front()->SetScale(myWindowSize.x/1600.f, myWindowSize.y/1200.f);
						myEnemyships.front()->SetOrigin(myEnemyships.front()->GetSize().x/2.f,myEnemyships.front()->GetSize().y);
						myEnemyships.front()->myLive=300;
						myEnemyships.front()->myPoints=100;
						myEnemyships.front()->mySpeed=200;
						myEnemyships.front()->myShootPeriod=2;
						myEnemyships.front()->myWeapon=Second;
						break;
						
					case '6':
						myEnemyships.push_front(new Enemyship(myEnemyImage));
						myEnemyships.front()->SetPosition((114.286f*static_cast<float>(i+1))*(myWindowSize.x/1600.f),0);
						myEnemyships.front()->SetScale(myWindowSize.x/1600.f, myWindowSize.y/1200.f);
						myEnemyships.front()->SetOrigin(myEnemyships.front()->GetSize().x/2.f,myEnemyships.front()->GetSize().y);
						myEnemyships.front()->myLive=500;
						myEnemyships.front()->myPoints=250;
						myEnemyships.front()->mySpeed=50;
						myEnemyships.front()->myShootPeriod=2;
						myEnemyships.front()->myWeapon=Third;
						break;
						
					case '7':
						myEnemyships.push_front(new Enemyship(myEnemyImage));
						myEnemyships.front()->SetPosition((114.286f*static_cast<float>(i+1))*(myWindowSize.x/1600.f),0);
						myEnemyships.front()->SetScale(myWindowSize.x/1600.f, myWindowSize.y/1200.f);
						myEnemyships.front()->SetOrigin(myEnemyships.front()->GetSize().x/2.f,myEnemyships.front()->GetSize().y);
						myEnemyships.front()->myLive=750;
						myEnemyships.front()->myPoints=500;
						myEnemyships.front()->mySpeed=50;
						myEnemyships.front()->myShootPeriod=1.5;
						myEnemyships.front()->myWeapon=Third;
						break;
						
					case '8':
						myEnemyships.push_front(new Enemyship(myEnemyImage));
						myEnemyships.front()->SetPosition((114.286f*static_cast<float>(i+1))*(myWindowSize.x/1600.f),0);
						myEnemyships.front()->SetScale(myWindowSize.x/1600.f, myWindowSize.y/1200.f);
						myEnemyships.front()->SetOrigin(myEnemyships.front()->GetSize().x/2.f,myEnemyships.front()->GetSize().y);
						myEnemyships.front()->myLive=1000;
						myEnemyships.front()->myPoints=750;
						myEnemyships.front()->mySpeed=50;
						myEnemyships.front()->myShootPeriod=1;
						myEnemyships.front()->myWeapon=Third;
						break;
						
					case 'a':
						myEnemyships.push_front(new Enemyship(myEnemyImage));
						myEnemyships.front()->SetPosition((114.286f*static_cast<float>(i+1))*(myWindowSize.x/1600.f),0);
						myEnemyships.front()->myLive=0;
						myEnemyships.front()->myPoints=100;
						myEnemyships.front()->myWeapon=First;
						myEnemyships.front()->myShootPeriod=5;
						break;
						
					case 'b':
						myEnemyships.push_front(new Enemyship(myEnemyImage));
						myEnemyships.front()->myLive=0;
						myEnemyships.front()->myPoints=300;
						myEnemyships.front()->myWeapon=None;
						myEnemyships.front()->myShootPeriod=5;
						break;
						
					case 'c':
						myEnemyships.push_front(new Enemyship(myEnemyImage));
						myEnemyships.front()->myLive=0;
						myEnemyships.front()->myPoints=750;
						myEnemyships.front()->myWeapon=None;
						myEnemyships.front()->myShootPeriod=5;
						break;
						
					case 'd':
						myEnemyships.push_front(new Enemyship(myEnemyImage));
						myEnemyships.front()->myLive=0;
						myEnemyships.front()->myPoints=2000;
						myEnemyships.front()->myWeapon=None;
						myEnemyships.front()->myShootPeriod=5;
						break;
					
				}
			}
		}
		++myStage;
		myMap.pop();
	}
	else if(myMap.empty() && myEnemyships.empty())
	{
		return true;
	}
	
	std::stack<std::list<Enemyship*>::iterator> removelist;
	
	for(std::list<Enemyship*>::iterator it=myEnemyships.begin(); it!=myEnemyships.end(); ++it)
	{
		(*it)->Move(0,(*it)->mySpeed*time*(myWindowSize.y/1200.f));
		(*it)->Update(weapons);
		if((*it)->GetPosition().y-(*it)->GetSize().y>myWindowSize.y)
		{
			removelist.push(it);
			negpoints-=(*it)->myPoints*4;
		}
	}
	
	while(!removelist.empty())
	{
		delete (*removelist.top());
		myEnemyships.erase(removelist.top());
		removelist.pop();
	}
	
	return false;
}




void Enemy::Draw(sf::RenderWindow& window)
{
	for(std::list<Enemyship*>::iterator it=myEnemyships.begin(); it!=myEnemyships.end(); ++it)
	{
		if((*it)->myWeapon!=None)
			window.Draw(**it);
		
	}
}



sf::Vector2i Enemy::CheckCollision(const sf::Vector2f& position, float destruction, bool immortal, sf::Vector2f& pos)
{
	int points=0; int hit=0;
	std::stack<std::list<Enemyship*>::iterator> removelist;
	
	for(std::list<Enemyship*>::iterator it=myEnemyships.begin(); it!=myEnemyships.end(); ++it)
	{
		sf::Vector2f Origin((*it)->GetSize().x/2.f,(*it)->GetSize().y);
		Origin.x*=(*it)->GetScale().x; Origin.y*=(*it)->GetScale().y;
		if((*it)->myWeapon==None)
		{
			points+=(*it)->myPoints;
			removelist.push(it);
		}
		else if(sf::Rect<float>((*it)->GetPosition()-Origin,(*it)->GetSize()).Contains(position))
		{
			if((*it)->GetPixel((*it)->TransformToLocal(position).x,(*it)->TransformToLocal(position).y).a>2)
			{
				hit=1;
				if((*it)->RemoveLive(destruction))
				{
					points+=(*it)->myPoints;
					pos=(*it)->GetPosition();
					removelist.push(it);
				}
				if(!immortal)
					break;
			}
		}
	}
	
	while(!removelist.empty())
	{
		delete (*removelist.top());
		myEnemyships.erase(removelist.top());
		removelist.pop();
	}
	
	return sf::Vector2i(points, hit);
}





