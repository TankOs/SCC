#ifndef PLAYER_HPP
#define PLAYER_HPP

#include <SFML/Graphics.hpp>

#include "Weapons.hpp"
#include "../Vector2.hpp"


class Weapons;


class Player
{
	private:
		sf::Image myImage;
		sf::Sprite mySprite;
		
		sf::Vector2i myWindowsize;
		
		float myLive;
		float myShield;
		int myPoints;
		int my2Points;
		
		struct Canons
		{
			bool PhotonicTorpedos;
			bool LaserCanons;
			bool PlasmaTorpedos;
			bool PhaseCanons;
			bool PhaserCanons;
			
			Canons() {PhotonicTorpedos=true; LaserCanons=false; PlasmaTorpedos=false; PhaseCanons=false; PhaserCanons=false;}
			
		} myCanons;
		
		float myPhotonicTorpedoTime;
		float myLaserCanonTime;
		float myPlasmaTorpedoTime;
		float myPhaseCanonTime;
		float myPhaserCanonTime;
		
		sf::Clock myPhotonicTorpedoClock;
		sf::Clock myLaserCanonClock;
		sf::Clock myPlasmaTorpedoClock;
		sf::Clock myPhaseCanonClock;
		sf::Clock myPhaserCanonClock;
		
		sf::Font myFont;
		sf::Text myPointText;
		sf::Text myPhotonicText;
		sf::Text myLaserText;
		sf::Text myPlasmaText;
		sf::Text myPhaseText;
		sf::Text myPhaserText;
		
		sf::SoundBuffer mySoundBuffer;
		sf::Sound mySound;
		
		sf::Image myLiveImage;
		sf::Sprite myShieldSprite;
		sf::Sprite myLiveSprite;
	public:
		Player();
		
		void Update(const sf::Input&, Weapons& weapons, float);
		void Draw(sf::RenderWindow&);
		void Fire(Weapons& weapons, float);
		
		void AddPoints(int points) {myPoints+=points;}
		void RemoveLive(float live) {myLive-=live;}
		
		int GetPoints() {return myPoints;}
		const sf::Text& GetPointText();
		void DrawText(sf::RenderWindow&);
		bool Alive() {if(myLive>0) return true; return false;}
		sf::Vector2f GetCenter() {return mySprite.TransformToGlobal(mySprite.GetOrigin()+sf::Vector2f(0,mySprite.GetSize().y/2.f));}
		
		void LoadMedia(const sf::Vector2i&);
		
		bool CheckCollision(const sf::Vector2f&, float);
		void Damage(float);
};


#endif


