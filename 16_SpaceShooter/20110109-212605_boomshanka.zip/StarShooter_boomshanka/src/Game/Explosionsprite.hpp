#ifndef EXPLOSIONSPRITE_HPP
#define EXPLOSIONSPRITE_HPP

#include <SFML/Graphics.hpp>



class Explosionsprite : public sf::Sprite
{
	friend class Explosion;
	
	private:
		sf::Clock myTime;
		
	public:
		Explosionsprite(sf::Image& image, const sf::Vector2f& pos, float scale=1.f)
		{
			SetImage(image);
			myTime.Reset();
			SetSubRect(sf::Rect<int>(0,0,256,205));
			SetScale(scale, scale);
			SetOrigin((GetSize()/scale)/2.f);
			SetPosition(pos);
			SetRotation(sf::Randomizer::Random(0.f,360.f));
		}
		
		bool Alive() {if(myTime.GetElapsedTime()>0.8) return false; return true;}
		
		void Update()
		{
			int x, y;
			float time=myTime.GetElapsedTime();
			
			for(x=0; x<time*25; ++x);
			for(y=0; y<time*6.25; ++y);
			
			int z=--x;
			x=z%4;
			SetSubRect(sf::Rect<int>(x*256,--y*205,256,205));
		}
		
};


#endif


