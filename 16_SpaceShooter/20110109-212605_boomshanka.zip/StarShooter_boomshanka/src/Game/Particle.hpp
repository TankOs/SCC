#ifndef PARTICLE_HPP
#define PARTICLE_HPP

#include <SFML/Graphics.hpp>

#include <list>


class Particle
{
	private:
		sf::Image* myImage;
		sf::Vector2i myResolution;
		
		float mySpeed;
		float myRandom;
		sf::Clock myClock;
		
		std::list<sf::Sprite*> mySprites;
	public:
		Particle(sf::Image*, float, float);
		~Particle();
		
		void SetResolution(sf::Vector2i res) {myResolution=res;}
		
		void Update(float);
		void Draw(sf::RenderWindow&);
};


#endif


