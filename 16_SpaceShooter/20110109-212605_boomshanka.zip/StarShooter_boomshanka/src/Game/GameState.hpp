#ifndef GAMESTATE_HPP
#define GAMESTATE_HPP

#include "../State.hpp"
#include "Player.hpp"
#include "Enemy.hpp"
#include "Weapons.hpp"
#include "Background.hpp"
#include "Explosion.hpp"

#include <SFML/Graphics.hpp>


class GameState : public State
{
	private:
		Player myPlayer;
		Enemy myEnemy;
		Weapons myWeapons;
		Explosion myExplosions;
		Background myBackground;
		
		unsigned int& myLevel;
		bool myFinish;
		
		const sf::Input& myInput;
		
		std::string myWinText, myLooseText;
		sf::Font myFont;
		sf::Text myText;
		int myMinimumPoints;
		
		sf::Clock myClock;
	public:
		GameState(sf::RenderWindow&, unsigned int&);
		
		virtual ~GameState();

        virtual int Update();
        virtual void Draw();

        virtual void OnEnter();
        virtual void OnLeave();
		
	private:
		int CheckEvents();
		void LoadFile();
};

#endif


