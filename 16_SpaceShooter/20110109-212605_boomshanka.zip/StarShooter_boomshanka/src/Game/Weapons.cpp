#include "Weapons.hpp"

#include <stack>



Weapons::~Weapons()
{
	for(std::list<Shot*>::iterator it=myPlayerShots.begin(); it!=myPlayerShots.end(); ++it)
	{
		delete (*it);
	}
	for(std::list<Shot*>::iterator it=myEnemyShots.begin(); it!=myEnemyShots.end(); ++it)
	{
		delete (*it);
	}
}



void Weapons::LoadMedia(const sf::Vector2i& windowsize)
{
	myWindowSize=windowsize;
	
	myPhotonicSound.LoadFromFile("snd/weapons/PhotonicTorpedo.ogg");
	myLaserSound.LoadFromFile("snd/weapons/LaserCanon.ogg");
	myPlasmaSound.LoadFromFile("snd/weapons/PlasmaTorpedo.ogg");
	myPhaseSound.LoadFromFile("snd/weapons/PhaseCanon.ogg");
	myPhaserSound.LoadFromFile("snd/weapons/PhaserCanon.ogg");
	
	myTorpedoImage.LoadFromFile("img/torpedo.png");
	myLaserImage.LoadFromFile("img/laser.png");
	myEnemyWeaponImage.LoadFromFile("img/enemyweapon.png");
	
	mySound.SetVolume(70);
}




void Weapons::AddPlayerShot(int shot, const sf::Vector2f& position, float time)
{
	switch(shot)
	{			
		case PhaserCanons:
			myPlayerShots.push_front(new Shot(myLaserImage, PhaserCanons));
			myPlayerShots.front()->SetColor(sf::Color::Blue);
			myPlayerShots.front()->SetSubRect(sf::Rect<int>(0,0,10,30));
			myPlayerShots.front()->SetScale(myWindowSize.x/1600.f,2*myWindowSize.y/1200.f);
			myPlayerShots.front()->SetOrigin(myPlayerShots.front()->GetSize().x/2.f,myPlayerShots.front()->GetSize().y/2);
			myPlayerShots.front()->SetPosition(position);
			myPlayerShots.front()->mySpeed=sfp::Vector2f(0,-2250.f*(static_cast<float>(myWindowSize.y)/1200.f));
			myPlayerShots.front()->myImmortal=true;
			myPlayerShots.front()->myDestruction=500.f*time;
			
			PlaySound(myPhaserSound);
			break;
			
		case PhaseCanons:
			myPlayerShots.push_front(new Shot(myLaserImage, PhaseCanons));
			myPlayerShots.front()->SetColor(sf::Color::Red);
			myPlayerShots.front()->SetSubRect(sf::Rect<int>(0,0,10,30));
			myPlayerShots.front()->SetScale(myWindowSize.x/1600.f,2*myWindowSize.y/1200.f);
			myPlayerShots.front()->SetOrigin(myPlayerShots.front()->GetSize().x/2.f,myPlayerShots.front()->GetSize().y/2.f);
			myPlayerShots.front()->SetPosition(position.x-(myWindowSize.y/1200.f)*20.f,position.y+(myWindowSize.y/1200.f)*7.f);
			myPlayerShots.front()->mySpeed=sfp::Vector2f(0,-2250.f*(myWindowSize.y/1200.f));
			myPlayerShots.front()->myImmortal=false;
			myPlayerShots.front()->myDestruction=500.f*time;
			
			myPlayerShots.push_front(new Shot(myLaserImage, PhaseCanons));
			myPlayerShots.front()->SetColor(sf::Color::Red);
			myPlayerShots.front()->SetSubRect(sf::Rect<int>(0,0,10,30));
			myPlayerShots.front()->SetScale(myWindowSize.x/1600.f,2*myWindowSize.y/1200.f);
			myPlayerShots.front()->SetOrigin(myPlayerShots.front()->GetSize().x/2.f,myPlayerShots.front()->GetSize().y/2.f);
			myPlayerShots.front()->SetPosition(position.x+(myWindowSize.y/1200.f)*20.f,position.y+(myWindowSize.y/1200.f)*7.f);
			myPlayerShots.front()->mySpeed=sfp::Vector2f(0,-2000.f*(myWindowSize.y/1200.f));
			myPlayerShots.front()->myImmortal=false;
			myPlayerShots.front()->myDestruction=500.f*time;
			
			PlaySound(myPhaseSound);
			break;
			
		case PlasmaTorpedos:
			myPlayerShots.push_front(new Shot(myTorpedoImage, PlasmaTorpedos));
			myPlayerShots.front()->SetColor(sf::Color::Red);
			myPlayerShots.front()->SetSubRect(sf::Rect<int>(0,0,10,10));
			myPlayerShots.front()->SetScale(myWindowSize.x/1600.f,myWindowSize.y/1200.f);
			myPlayerShots.front()->SetOrigin(myPlayerShots.front()->GetSize().x/2.f,myPlayerShots.front()->GetSize().y/2.f);
			myPlayerShots.front()->SetPosition(position);
			myPlayerShots.front()->mySpeed=sfp::Vector2f(0,-1500.f*(static_cast<float>(myWindowSize.y)/1200.f));
			myPlayerShots.front()->myImmortal=false;
			myPlayerShots.front()->myDestruction=75.f;
			
			PlaySound(myPlasmaSound);
			break;
			
		case LaserCanons:
			myPlayerShots.push_front(new Shot(myLaserImage, LaserCanons));
			myPlayerShots.front()->SetColor(sf::Color::Green);
			myPlayerShots.front()->SetSubRect(sf::Rect<int>(0,0,10,30));
			myPlayerShots.front()->SetScale(myWindowSize.x/1600.f,myWindowSize.y/1200.f);
			myPlayerShots.front()->SetOrigin(myPlayerShots.front()->GetSize().x/2.f,myPlayerShots.front()->GetSize().y/2.f);
			myPlayerShots.front()->SetPosition(position.x+(myWindowSize.y/1200.f)*55.f,position.y+(myWindowSize.y/1200.f)*20.f);
			myPlayerShots.front()->mySpeed=sfp::Vector2f(0,-1250.f*(static_cast<float>(myWindowSize.y)/1200.f));
			myPlayerShots.front()->myImmortal=false;
			myPlayerShots.front()->myDestruction=125.f*time;
			
			myPlayerShots.push_front(new Shot(myLaserImage, LaserCanons));
			myPlayerShots.front()->SetColor(sf::Color::Green);
			myPlayerShots.front()->SetSubRect(sf::Rect<int>(0,0,10,30));
			myPlayerShots.front()->SetScale(myWindowSize.x/1600.f,myWindowSize.y/1200.f);
			myPlayerShots.front()->SetOrigin(myPlayerShots.front()->GetSize().x/2.f,myPlayerShots.front()->GetSize().y/2.f);
			myPlayerShots.front()->SetPosition(position.x-(myWindowSize.y/1200.f)*55.f,position.y+(myWindowSize.y/1200.f)*20.f);
			myPlayerShots.front()->mySpeed=sfp::Vector2f(0,-1250.f*(static_cast<float>(myWindowSize.y)/1200.f));
			myPlayerShots.front()->myImmortal=false;
			myPlayerShots.front()->myDestruction=125.f*time;
			
			PlaySound(myLaserSound);
			break;
		
		case PhotonicTorpedos:
			myPlayerShots.push_front(new Shot(myTorpedoImage, PhotonicTorpedos));
			myPlayerShots.front()->SetColor(sf::Color::Yellow);
			myPlayerShots.front()->SetSubRect(sf::Rect<int>(0,0,10,10));
			myPlayerShots.front()->SetScale(myWindowSize.x/1600.f,myWindowSize.y/1200.f);
			myPlayerShots.front()->SetOrigin(myPlayerShots.front()->GetSize().x/2.f,myPlayerShots.front()->GetSize().y/2.f);
			myPlayerShots.front()->SetPosition(position);
			myPlayerShots.front()->mySpeed=sfp::Vector2f(0,-750.f*(static_cast<float>(myWindowSize.y)/1200.f));
			myPlayerShots.front()->myImmortal=false;
			myPlayerShots.front()->myDestruction=25.f;
			
			PlaySound(myPhotonicSound);
			break;
		
	}
}



void Weapons::AddEnemyShot(int shot, const sf::Vector2f& pos)
{
	switch(shot)
	{
		case First:
			myEnemyShots.push_front(new Shot(myEnemyWeaponImage, First));
			myEnemyShots.front()->SetColor(sf::Color::Green);
			myEnemyShots.front()->SetScale(myWindowSize.x/1600.f,myWindowSize.y/1200.f);
			myEnemyShots.front()->SetSubRect(sf::Rect<int>(0,0,10,50));
			myEnemyShots.front()->SetOrigin(myEnemyShots.front()->GetSize().x/2.f,myEnemyShots.front()->GetSize().y);
			myEnemyShots.front()->SetPosition(pos);
			myEnemyShots.front()->mySpeed=sfp::Vector2f(0,500.f*(myWindowSize.y/1200.f));
			myEnemyShots.front()->myImmortal=false;
			myEnemyShots.front()->myDestruction=15.f;
			
			break;
		
		case Second:
			myEnemyShots.push_front(new Shot(myEnemyWeaponImage, Second));
			myEnemyShots.front()->SetColor(sf::Color::Blue);
			myEnemyShots.front()->SetScale(myWindowSize.x/1600.f,myWindowSize.y/1200.f);
			myEnemyShots.front()->SetSubRect(sf::Rect<int>(0,0,10,50));
			myEnemyShots.front()->SetOrigin(myEnemyShots.front()->GetSize().x/2.f,myEnemyShots.front()->GetSize().y);
			myEnemyShots.front()->SetPosition(pos);
			myEnemyShots.front()->mySpeed=sfp::Vector2f(0,750.f*(myWindowSize.y/1200.f));
			myEnemyShots.front()->myImmortal=false;
			myEnemyShots.front()->myDestruction=25.f;
			
			break;
		
		case Third:
			myEnemyShots.push_front(new Shot(myEnemyWeaponImage, Third));
			myEnemyShots.front()->SetColor(sf::Color::Red);
			myEnemyShots.front()->SetScale(myWindowSize.x/1600.f,myWindowSize.y/1200.f);
			myEnemyShots.front()->SetSubRect(sf::Rect<int>(0,0,10,50));
			myEnemyShots.front()->SetOrigin(myEnemyShots.front()->GetSize().x/2.f,myEnemyShots.front()->GetSize().y);
			myEnemyShots.front()->SetPosition(pos);
			myEnemyShots.front()->mySpeed=sfp::Vector2f(0,1000.f*(myWindowSize.y/1200.f));
			myEnemyShots.front()->myImmortal=false;
			myEnemyShots.front()->myDestruction=50.f;
			
			break;
			
	}
}




void Weapons::PlaySound(sf::SoundBuffer& buffer)
{
	if(mySoundTime.GetElapsedTime()>1.03 && mySound.GetStatus()==sf::Sound::Stopped)
	{
		mySoundTime.Reset();
		mySound.SetBuffer(buffer);
		mySound.Play();
	}
}



void Weapons::Update(float time)
{
	std::stack<std::list<Shot*>::iterator> myRemoveList;
	
	for(std::list<Shot*>::iterator it=myPlayerShots.begin(); it!=myPlayerShots.end(); ++it)
	{
		(*it)->Update(time);
		if((*it)->GetPosition().y<0-myWindowSize.y*0.2)
			myRemoveList.push(it);
	}
	
	while(!myRemoveList.empty())
	{
		delete *myRemoveList.top();
		myPlayerShots.erase(myRemoveList.top());
		myRemoveList.pop();
	}
	
	for(std::list<Shot*>::iterator it=myEnemyShots.begin(); it!=myEnemyShots.end(); ++it)
	{
		(*it)->Update(time);
		if((*it)->GetPosition().y>myWindowSize.y*1.2)
			myRemoveList.push(it);
	}
	
	while(!myRemoveList.empty())
	{
		delete *myRemoveList.top();
		myEnemyShots.erase(myRemoveList.top());
		myRemoveList.pop();
	}
}




void Weapons::Draw(sf::RenderWindow& window)
{
	for(std::list<Shot*>::iterator it=myPlayerShots.begin(); it!=myPlayerShots.end(); ++it)
	{
		window.Draw(**it);
	}
	for(std::list<Shot*>::iterator it=myEnemyShots.begin(); it!=myEnemyShots.end(); ++it)
	{
		window.Draw(**it);
	}
}




int Weapons::CheckPlayerShots(Enemy& enemy, Explosion& explosion)
{
	int points=0;
	std::stack<std::list<Shot*>::iterator> removelist;
	
	for(std::list<Shot*>::iterator it=myPlayerShots.begin(); it!=myPlayerShots.end(); ++it)
	{
		sf::Vector2f vector;
		sf::Vector2i vec=enemy.CheckCollision((*it)->GetPosition(), (*it)->myDestruction, (*it)->myImmortal, vector);
		if(vec.y!=0)
		{
			if(!(*it)->myImmortal)
			{
				removelist.push(it);
				explosion.NewExplosion((*it)->GetPosition(), 0.2);
			}
			if(vec.x!=0)
			{
				explosion.NewExplosion(vector);
			}
		}
		points+=vec.x;
	}
	
	while(!removelist.empty())
	{
		delete (*removelist.top());
		myPlayerShots.erase(removelist.top());
		removelist.pop();
	}
	
	return points;
}



void Weapons::CheckEnemyShots(Player& player, Explosion& explosion)
{
	std::stack<std::list<Shot*>::iterator> removelist;
	
	for(std::list<Shot*>::iterator it=myEnemyShots.begin(); it!=myEnemyShots.end(); ++it)
	{
		if(player.CheckCollision((*it)->GetPosition(), (*it)->myDestruction))
		{
			removelist.push(it);
			explosion.NewExplosion((*it)->GetPosition(), 0.3);
		}
	}
	
	while(!removelist.empty())
	{
		delete (*removelist.top());
		myEnemyShots.erase(removelist.top());
		removelist.pop();
	}
	
}

