#ifndef WEAPONS_HPP
#define WEAPONS_HPP

#include <list>

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "Shot.hpp"
#include "Enemy.hpp"
#include "Player.hpp"
#include "Explosion.hpp"


class Enemy;
class Player;
class Enemyship;


class Weapons
{
	private:
		std::list<Shot*> myPlayerShots;
		std::list<Shot*> myEnemyShots;
		
		sf::Vector2i myWindowSize;
		
		sf::Sound mySound;
		sf::SoundBuffer myPhotonicSound;
		sf::SoundBuffer myLaserSound;
		sf::SoundBuffer myPlasmaSound;
		sf::SoundBuffer myPhaseSound;
		sf::SoundBuffer myPhaserSound;
		sf::Clock mySoundTime;
		
		sf::Image myTorpedoImage;
		sf::Image myLaserImage;
		sf::Image myEnemyWeaponImage;
	public:
		
		~Weapons();
		
		void LoadMedia(const sf::Vector2i&);
		
		void Update(float);
		int CheckPlayerShots(Enemy&, Explosion&);
		void CheckEnemyShots(Player&, Explosion&);
		
		void Draw(sf::RenderWindow&);
		
		void AddPlayerShot(int, const sf::Vector2f&, float time=0);
		void AddEnemyShot(int, const sf::Vector2f&);
		
		void PlaySound(sf::SoundBuffer&);
};


#endif


