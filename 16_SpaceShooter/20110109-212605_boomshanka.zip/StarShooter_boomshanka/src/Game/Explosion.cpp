#include "Explosion.hpp"




void Explosion::LoadMedia(const sf::Vector2i& windowsize)
{
	myWindowsize=windowsize;
	
	myExplosionImage.LoadFromFile("img/explosion.png");
	
	mySmallBuffer.LoadFromFile("snd/damage/destruction.ogg");
	myNormalBuffer.LoadFromFile("snd/damage/damage.ogg");
	myPlayerBuffer.LoadFromFile("snd/damage/deep_explosion.ogg");
	
	mySound.SetBuffer(mySmallBuffer);
	mySound.SetVolume(25);
	myPlayerSound.SetBuffer(myPlayerBuffer);
}



void Explosion::Update()
{
	while(!myExplosions.empty() && !(*myExplosions.begin())->Alive())
	{
		delete (*myExplosions.begin());
		myExplosions.pop_front();
	}
	
	for(std::list<Explosionsprite*>::iterator it=myExplosions.begin(); it!=myExplosions.end(); ++it)
	{
		(*it)->Update();
	}
	
	while(mySoundList.size()>0 && mySoundList.front()->GetStatus()==sf::Sound::Stopped)
	{
		delete mySoundList.front();
		mySoundList.pop();
	}
}



void Explosion::NewExplosion(const sf::Vector2f& pos, float scale)
{
	myExplosions.push_back(new Explosionsprite(myExplosionImage, pos, scale*(myWindowsize.x/1600.f)));
	if(scale<0.3)
	{
		SmallDamageSound();
	}
	else if(scale>0.4)
	{
		NormalDamageSound();
	}
	else
	{
		PlayerDamageSound();
	}
}



void Explosion::Draw(sf::RenderWindow& window)
{
	for(std::list<Explosionsprite*>::iterator it=myExplosions.begin(); it!=myExplosions.end(); ++it)
	{
		window.Draw(**it);
	}
}


void Explosion::SmallDamageSound()
{
	if(mySound.GetStatus()==sf::Sound::Stopped)
	{
		mySound.Play();
	}
}



void Explosion::NormalDamageSound()
{
	sf::Sound* sound = new sf::Sound(myNormalBuffer);
	sound->SetVolume(50);
	sound->Play();
	mySoundList.push(sound);
}


void Explosion::PlayerDamageSound()
{
	if(myPlayerSound.GetStatus()==sf::Sound::Stopped)
	{
		myPlayerSound.Play();
	}
}



