#include "Background.hpp"

#include <string>
#include <sstream>
#include <fstream>


Background::~Background()
{
	for(unsigned int i=0; i<mySounds.size(); ++i)
	{
		delete mySounds[i];
	}
	for(unsigned int i=0; i<myParticle.size(); ++i)
	{
		delete myParticle[i];
	}
}


bool Background::LoadMedia(unsigned int level)
{
	myBackground=false;
	
	std::string path("lev/level");
	std::string string;
	std::stringstream sstring;
	sstring<<level;
	sstring>>string;
	path+=string;
	path+=".conf";
	
	std::ifstream file(path.c_str());
	
	if(file.fail())
		return false;
	
	while(!file.eof())
	{
		std::getline(file,string);
		std::stringstream sstr(string);
		sstr>>string;
		
		if(string=="BackgroundImage:")
		{
			sstr>>string;
			myBackgroundImage.LoadFromFile(string);
			myBackground=true;
		}
		else if(string=="BackgroundMusic:")
		{
			sstr>>string;
			myBackgroundMusic.OpenFromFile(string);
		}
		else if(string=="ParticleImage:")
		{
			sstr>>string;
			sf::Image* image= new sf::Image;
			if(image->LoadFromFile(string))
			{
				float speed, foo;
				sstr>>speed; sstr>>foo;
				myParticle.push_back(new Particle(image, speed, foo));
			}
			else
			{
				delete image;
			}
		}
		else if(string=="Sound:")
		{
			sstr>>string;
			mySounds.push_back(new sf::SoundBuffer());
			if(!mySounds[mySounds.size()-1]->LoadFromFile(string))
			{
				delete mySounds[mySounds.size()-1];
				mySounds.pop_back();
			}
		}
	}
	
	return true;
}


void Background::Start(const sf::Vector2i& windowsize)
{
	myBackgroundMusic.SetLoop(true);
	myBackgroundMusic.Play();
	
	if(myBackground)
	{
		mySprite.SetImage(myBackgroundImage);
		mySprite.Resize(static_cast<float>(windowsize.x),static_cast<float>(windowsize.y));
	}
	
	for(unsigned int i=0; i<myParticle.size(); ++i)
	{
		myParticle[i]->SetResolution(windowsize);
	}
	mySprite.SetImage(myBackgroundImage);
	mySoundTime=sf::Randomizer::Random(10,50);
	mySoundClock.Reset();
}



void Background::Update(float time)
{
	if(mySoundTime<mySoundClock.GetElapsedTime())
	{
		mySoundTime=sf::Randomizer::Random(10,20);
		mySoundClock.Reset();
		
		if(mySound.GetStatus()==sf::Sound::Stopped)
		{
			mySound.SetBuffer(*mySounds[sf::Randomizer::Random(0,mySounds.size()-1)]);
			mySound.Play();
		}
	}
	
	for(unsigned int i=0; i<myParticle.size(); ++i)
	{
		myParticle[i]->Update(time);
	}
	
}




void Background::Draw(sf::RenderWindow& window)
{
	if(myBackground)
	{
		window.Draw(mySprite);
	}
	
	
	for(unsigned int i=0; i<myParticle.size(); ++i)
	{
		myParticle[i]->Draw(window);
	}
}



