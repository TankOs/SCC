#ifndef BACKGROUND_HPP
#define BACKGROUND_HPP

#include <vector>

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "Particle.hpp"


class Background
{
	private:
		sf::Image myBackgroundImage;
		sf::Music myBackgroundMusic;
		
		sf::Sprite mySprite;
		bool myBackground;
		
		std::vector<sf::SoundBuffer*> mySounds;
		sf::Sound mySound;
		sf::Clock mySoundClock;
		int mySoundTime;
		
		std::vector<Particle*> myParticle;
	public:
		
		~Background();
		
		void Update(float);
		void Draw(sf::RenderWindow&);
		
		bool LoadMedia(unsigned int);
		void Start(const sf::Vector2i&);
};


#endif


