#include "Enemyship.hpp"



void Enemyship::Update(Weapons& weapons)
{
	if(myShootPeriod<myClock.GetElapsedTime())
	{
		myClock.Reset();
		
		weapons.AddEnemyShot(myWeapon, GetPosition());
	}
}


