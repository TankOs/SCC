#include "Particle.hpp"


Particle::Particle(sf::Image* image, float speed, float random)
:myImage(image), mySpeed(speed), myRandom(random)
{
	myClock.Reset();
}



Particle::~Particle()
{
	delete myImage;
	for(std::list<sf::Sprite*>::iterator it=mySprites.begin(); it!=mySprites.end(); ++it)
	{
		delete (*it);
	}
}




void Particle::Update(float time)
{
	if(myClock.GetElapsedTime()>1/myRandom)
	{
		myClock.Reset();
		mySprites.push_front(new sf::Sprite(*myImage));
		(*mySprites.begin())->SetScale(myResolution.x/1600.f,myResolution.y/1200.f);
		(*mySprites.begin())->SetOrigin((*mySprites.begin())->GetSize().x/2.f,(*mySprites.begin())->GetSize().y);
		(*mySprites.begin())->SetPosition(sf::Randomizer::Random(0,myResolution.x),0);
	}
	
	unsigned int i=0;
	for(std::list<sf::Sprite*>::iterator it=mySprites.begin(); it!=mySprites.end(); ++it)
	{
		(*it)->Move(0,mySpeed*time*(myResolution.y/1200.f));
		if((*it)->GetPosition().y-(*it)->GetSize().y>myResolution.y)
		{
			delete (*it);
			++i;
		}
	}
	for(unsigned int j=0; j<i; ++j)
	{
		mySprites.pop_back();
	}
}



void Particle::Draw(sf::RenderWindow& window)
{
	for(std::list<sf::Sprite*>::iterator it=mySprites.begin(); it!=mySprites.end(); ++it)
	{
		window.Draw(*(*it));
	}
}



