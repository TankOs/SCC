#include "StateManager.hpp"


int main(int argc, char* argv[])
{
	ConfigManager configmanager(argc, argv);
	
	StateManager statemanager(configmanager);
	statemanager.Init();
	
	if(configmanager.Quit())
		return 0;
	
	return statemanager.Run();
}

