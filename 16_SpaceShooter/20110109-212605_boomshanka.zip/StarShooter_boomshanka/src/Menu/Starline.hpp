#ifndef STARLINE_HPP
#define STARLINE_HPP

#include <SFML/Graphics.hpp>

#include "../Vector2.hpp"


class Starline
{
	private:
		sf::Shape myShape;
		
		float myTime;
		float myAngle;
		
		float myLength;
	public:
		Starline(const Starline& starline): myTime(0), myAngle(starline.myAngle), myLength(starline.myLength) {myShape=starline.myShape;}
		Starline(sf::Shape shape, float angle, float length): myTime(0), myAngle(angle),myLength(length)
					{myShape=shape; myShape.SetPosition(myLength,myLength*0.75);}
		
		bool Update(float time){myTime+=time; sfp::Vector2f vec(100*myLength*myTime*myTime,0); vec.SetDirection(myAngle);
								sfp::Vector2f vec2(0.5,0.5); vec2.SetDirection(myAngle+90);
								myShape.SetPointPosition(0,vec-vec2); myShape.SetPointPosition(3,vec+vec2); vec*=1.3f;
								myShape.SetPointPosition(1,vec-vec2); myShape.SetPointPosition(2,vec+vec2);
								if((myTime*myTime)>0.02) return false; return true;}
		void Draw(sf::RenderWindow& window) {window.Draw(myShape);}
};


#endif


