#ifndef WARPEFFECT_HPP
#define WARPEFFECT_HPP

#include <list>

#include <SFML/Graphics.hpp>

#include "Starline.hpp"


class WarpEffect
{
	private:
		std::list<Starline> myBackback;
		std::list<Starline> myBack;
		std::list<Starline> myMiddle;
		std::list<Starline> myFront;
		
	public:
		
		
		void LoadMedia();
		
		void Update(float, float);
		void Draw(sf::RenderWindow&);
};


#endif


