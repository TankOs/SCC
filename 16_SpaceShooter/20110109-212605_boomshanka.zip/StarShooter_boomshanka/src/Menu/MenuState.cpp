#include "MenuState.hpp"



MenuState::MenuState(sf::RenderWindow& window, ConfigManager& configmanager)
:State(window),
myMenu(window, configmanager.GetLevelPointer()),
myConfigManager(configmanager),
myNewResolution(window.GetWidth(), window.GetHeight()),
myNewStyle(sf::Style::Close)
{

}


MenuState::~MenuState()
{

}



void MenuState::OnEnter()
{
	sf::Event event;
	while(myWindow.GetEvent(event));
	
	warpeffect.LoadMedia();
	myMenu.LoadMedia(sf::Vector2f(myWindow.GetWidth(), myWindow.GetHeight()), myConfigManager.GetMaxLevel());
	myWarpSound.LoadFromFile("snd/music/warp.ogg");
	myBackgroundSound.LoadFromFile("snd/music/menu.ogg");
	
	myShape=sf::Shape::Rectangle(0,0,myWindow.GetWidth(), myWindow.GetHeight(), sf::Color::White);
	myShape.SetColor(sf::Color::Black);
	
	myNextState=State::NoChange;
	myRunning=true;
	
	mySound.SetBuffer(myWarpSound);
	mySound.Play();
	
	myWindow.ShowMouseCursor(true);
	myClock.Reset();
}


void MenuState::OnLeave()
{

}



int MenuState::Update()
{
	warpeffect.Update(myWindow.GetFrameTime(), myWindow.GetWidth()/2);
	
	if(myRunning)
	{
		if(myClock.GetElapsedTime()>9)
		{
			myShape.SetColor(sf::Color(0,0,0,0));
			CheckEvents();
			myMenu.Update();
		}
		else if(myClock.GetElapsedTime()>6)
		{
			myShape.SetColor(sf::Color(255,255,255,255-(myClock.GetElapsedTime()-6)*85.f));
			CheckEvents();
			myMenu.Update();
		}
		else if(myClock.GetElapsedTime()>3.6)
		{
			myShape.SetColor(sf::Color::White);
			if(!CloseEvents()) return State::Quit;
		}
		else
		{
			float time=myClock.GetElapsedTime();
			myShape.SetColor(sf::Color(time*time*time*5.47,time*time*time*5.47,time*time*time*5.47));
			if(!CloseEvents()) return State::Quit;
		}
	
		if(mySound.GetStatus()==sf::Sound::Stopped)
		{
			mySound.SetBuffer(myBackgroundSound);
			mySound.SetLoop(true);
			mySound.Play();
			if(!CloseEvents()) return State::Quit;
		}
	}
	else
	{
		if(myClock.GetElapsedTime()>2)
		{
			return myNextState;
		}
		else
		{
			float time=myClock.GetElapsedTime();
			mySound.SetVolume(100-time*50);
			myShape.SetColor(sf::Color(0,0,0,time*time*63.75));
		}
	}
	
	return State::NoChange;
}



void MenuState::Draw()
{
	myWindow.Clear();
	
	warpeffect.Draw(myWindow);
	myMenu.Draw(myWindow);
	myWindow.Draw(myShape);
	
	myWindow.Display();
}



bool MenuState::CheckEvents()
{
	sf::Event event;
	
	while(myWindow.GetEvent(event))
	{
		switch(event.Type)
		{
			case sf::Event::Closed:
				myClock.Reset();
				myRunning=false;
				myNextState=State::Quit;
				return false;
				break;
			
			case sf::Event::KeyPressed:
				if(event.Key.Code == sf::Key::Escape)
				{
					myClock.Reset();
					myRunning=false;
					myNextState=State::Quit;
					return false;
				}
				
				else if(event.Key.Code == sf::Key::Return)
				{
					Choosed();
				}
			
				break;
				
			case sf::Event::MouseButtonReleased:
				if(event.MouseButton.Button == sf::Mouse::Left)
				{
					Choosed();
				}
				
			default:
				
				break;
		}
	}
	
	return true;
}




void MenuState::ChangeResolution()
{
	//myWindow.Close(); FIXME vllt State::Restart
	//myWindow.Create(myNewResolution, "SpaceShooter", myNewStyle); //In StateManager nochmal Titel
	myConfigManager.SetVideoMode(myNewResolution);
	myConfigManager.SetStyle(myNewStyle);
	myMenu.SetResolution(sf::Vector2f(myWindow.GetWidth(), myWindow.GetHeight()));
	
	myShape=sf::Shape::Rectangle(0,0,myWindow.GetWidth(), myWindow.GetHeight(), sf::Color::White);
	myShape.SetColor(sf::Color(0,0,0,0));
}



void MenuState::Choosed()
{
	switch(myMenu.Choose())
	{
		case GAME:
			myNextState=State::Game;
			myClock.Reset();
			myRunning=false;
			break;
			
		case QUIT:
			myNextState=State::Quit;
			myClock.Reset();
			myRunning=false;
			break;
			
		case WINDOWMODE:
			myNewResolution=myMenu.GetVideoMode();
			myNewStyle=myMenu.GetStyle();
			ChangeResolution();
			break;
	}
}


bool MenuState::CloseEvents()
{
	sf::Event event;
	
	while(myWindow.GetEvent(event))
	{
		if(event.Type==sf::Event::Closed || (sf::Event::KeyPressed && event.Key.Code == sf::Key::Escape))
			return false;
	
	}
	
	return true;
}



