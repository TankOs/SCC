#ifndef MENU_HPP
#define MENU_HPP

#include <SFML/Graphics.hpp>


enum ACTION
{
	NOTHING,
	GAME,
	QUIT,
	WINDOWMODE
};



class MenuText
{
	private:
		sf::Text Start;
		sf::Text Level;
		sf::Text WindowMode;
		sf::Text Quit;
		
		sf::Text Resolution;
		sf::Text Style;
		sf::Text Apply;
		sf::Text Back;
		
		sf::Font myFont;
		
		bool WindowChange;
		unsigned int Selection;
		
		sf::VideoMode myResolution;
		unsigned long myStyle;
		unsigned int& myLevel;
		unsigned int myMaxlevel;
		
		const sf::Input& myInput;
		
		sf::Clock myClock;
		std::vector<sf::VideoMode> VideoModes;
		
		unsigned int X; unsigned int Y; unsigned int I;
	public:
		MenuText(sf::Window&, unsigned int&);
		
		void Update();
		int Choose();
		void Draw(sf::RenderWindow&);
		
		void LoadMedia(const sf::Vector2f&, unsigned int);
		void SetResolution(const sf::Vector2f&);
		
		const sf::VideoMode& GetVideoMode() {return myResolution;}
		unsigned long GetStyle() {return myStyle;}
};


#endif


