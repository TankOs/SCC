#include "Menu.hpp"

#include <sstream>
#include <cmath>



MenuText::MenuText(sf::Window& window, unsigned int& level)
:WindowChange(false),
Selection(0),
myResolution(sf::VideoMode::GetDesktopMode()),
myStyle(sf::Style::Close),
myLevel(level),
myInput(window.GetInput()),
VideoModes(sf::VideoMode::GetFullscreenModes()),
I(0)
{

}



void MenuText::LoadMedia(const sf::Vector2f& resolution, unsigned int maxlevel)
{
	myMaxlevel=maxlevel;
	
	myFont.LoadFromFile("img/AstronBoyVideo.ttf");
	
	std::stringstream sstr;
	std::string string, string2;
	
	Start.SetString("Start game");
	Start.SetFont(myFont);
	sstr.clear();
	sstr<<myLevel;
	sstr>>string;
	Level.SetString("Level: "+string);
	Level.SetFont(myFont);
	WindowMode.SetString("Change windowmode");
	WindowMode.SetFont(myFont);
	Quit.SetString("Quit");
	Quit.SetFont(myFont);
	
	sstr.clear();
	sstr<<resolution.x;
	sstr>>string;
	sstr.clear();
	sstr<<resolution.y;
	sstr>>string2;
	
	Resolution.SetString("Resolution: "+string+"*"+string2);
	Resolution.SetFont(myFont);
	Style.SetString("Window style: Window");
	Style.SetFont(myFont);
	Apply.SetString("Apply");
	Apply.SetFont(myFont);
	Back.SetString("Back");
	Back.SetFont(myFont);
	
	SetResolution(resolution);
}



void MenuText::SetResolution(const sf::Vector2f& resolution)
{
	myResolution=sf::VideoMode(resolution.x, resolution.y);
	
	unsigned int size=(resolution.x/1600)*70;
	
	Start.SetCharacterSize(size);
	Level.SetCharacterSize(size);
	WindowMode.SetCharacterSize(size);
	Quit.SetCharacterSize(size);
	
	Resolution.SetCharacterSize(size);
	Style.SetCharacterSize(size);
	Apply.SetCharacterSize(size);
	Back.SetCharacterSize(size);
	
	Start.SetPosition(resolution.x/2-Start.GetRect().Width/2,resolution.y*0.20);
	Level.SetPosition(resolution.x/2-Level.GetRect().Width/2,resolution.y*0.35);
	WindowMode.SetPosition(resolution.x/2-WindowMode.GetRect().Width/2,resolution.y*0.50);
	Quit.SetPosition(resolution.x/2-Quit.GetRect().Width/2,resolution.y*0.75);
	
	Resolution.SetPosition(resolution.x/2-Resolution.GetRect().Width/2,resolution.y*0.20);
	Style.SetPosition(resolution.x/2-Style.GetRect().Width/2,resolution.y*0.35);
	Apply.SetPosition(resolution.x/2-Apply.GetRect().Width/2,resolution.y*0.50);
	Back.SetPosition(resolution.x/2-Back.GetRect().Width/2,resolution.y*0.75);
}



void MenuText::Draw(sf::RenderWindow& window)
{
	if(!WindowChange)
	{
		window.Draw(Start);
		window.Draw(Level);
		window.Draw(WindowMode);
		window.Draw(Quit);
	}
	else
	{
		window.Draw(Resolution);
		window.Draw(Style);
		window.Draw(Apply);
		window.Draw(Back);
	}
}



void MenuText::Update()
{
	unsigned int x=myInput.GetMouseX(), y=myInput.GetMouseY();
	
	if(!WindowChange)
	{
		if(x!=X  || y!=Y) {
		if(Start.GetRect().Contains(x,y))
		{
			Selection=0;
		}
		else if(Level.GetRect().Contains(x,y))
		{
			Selection=1;
		}
		else if(WindowMode.GetRect().Contains(x,y))
		{
			Selection=2;
		}
		else if(Quit.GetRect().Contains(x,y))
		{
			Selection=3;
		}
		else
		{
			Selection=4;
		}
		X=x; Y=y;
		}
		
		float time=myClock.GetElapsedTime();
		switch(Selection)
		{
			case 0:
				Start.SetColor(sf::Color(127.5*(1-std::sin(time*10)),127.5*(1-std::sin(time*7)),127.5*(1-std::sin(time*5))));
	Level.SetColor(sf::Color(255-(Level.GetColor().r-255)*-0.95,255-(Level.GetColor().g-255)*-0.95,255-(Level.GetColor().b-255)*-0.95));
	WindowMode.SetColor(sf::Color(255-(WindowMode.GetColor().r-255)*-0.95,255-(WindowMode.GetColor().g-255)*-0.95,255-(WindowMode.GetColor().b-255)*-0.95));
	Quit.SetColor(sf::Color(255-(Quit.GetColor().r-255)*-0.95,255-(Quit.GetColor().g-255)*-0.95,255-(Quit.GetColor().b-255)*-0.95));
				break;
			
			case 1:
				Level.SetColor(sf::Color(127.5*(1-std::sin(time*10)),127.5*(1-std::sin(time*7)),127.5*(1-std::sin(time*5))));
	Start.SetColor(sf::Color(255-(Start.GetColor().r-255)*-0.95,255-(Start.GetColor().g-255)*-0.95,255-(Start.GetColor().b-255)*-0.95));
	WindowMode.SetColor(sf::Color(255-(WindowMode.GetColor().r-255)*-0.95,255-(WindowMode.GetColor().g-255)*-0.95,255-(WindowMode.GetColor().b-255)*-0.95));
	Quit.SetColor(sf::Color(255-(Quit.GetColor().r-255)*-0.95,255-(Quit.GetColor().g-255)*-0.95,255-(Quit.GetColor().b-255)*-0.95));
				break;
			
			case 2:
				WindowMode.SetColor(sf::Color(127.5*(1-std::sin(time*10)),127.5*(1-std::sin(time*7)),127.5*(1-std::sin(time*5))));
	Start.SetColor(sf::Color(255-(Start.GetColor().r-255)*-0.95,255-(Start.GetColor().g-255)*-0.95,255-(Start.GetColor().b-255)*-0.95));
	Level.SetColor(sf::Color(255-(Level.GetColor().r-255)*-0.95,255-(Level.GetColor().g-255)*-0.95,255-(Level.GetColor().b-255)*-0.95));
	Quit.SetColor(sf::Color(255-(Quit.GetColor().r-255)*-0.95,255-(Quit.GetColor().g-255)*-0.95,255-(Quit.GetColor().b-255)*-0.95));
				break;
			
			case 3:
				Quit.SetColor(sf::Color(127.5*(1-std::sin(time*10)),127.5*(1-std::sin(time*7)),127.5*(1-std::sin(time*5))));
	Start.SetColor(sf::Color(255-(Start.GetColor().r-255)*-0.95,255-(Start.GetColor().g-255)*-0.95,255-(Start.GetColor().b-255)*-0.95));
	Level.SetColor(sf::Color(255-(Level.GetColor().r-255)*-0.95,255-(Level.GetColor().g-255)*-0.95,255-(Level.GetColor().b-255)*-0.95));
	WindowMode.SetColor(sf::Color(255-(WindowMode.GetColor().r-255)*-0.95,255-(WindowMode.GetColor().g-255)*-0.95,255-(WindowMode.GetColor().b-255)*-0.95));
				break;
			
			default:
	Start.SetColor(sf::Color(255-(Start.GetColor().r-255)*-0.95,255-(Start.GetColor().g-255)*-0.95,255-(Start.GetColor().b-255)*-0.95));
	Level.SetColor(sf::Color(255-(Level.GetColor().r-255)*-0.95,255-(Level.GetColor().g-255)*-0.95,255-(Level.GetColor().b-255)*-0.95));
	WindowMode.SetColor(sf::Color(255-(WindowMode.GetColor().r-255)*-0.95,255-(WindowMode.GetColor().g-255)*-0.95,255-(WindowMode.GetColor().b-255)*-0.95));
	Quit.SetColor(sf::Color(255-(Quit.GetColor().r-255)*-0.95,255-(Quit.GetColor().g-255)*-0.95,255-(Quit.GetColor().b-255)*-0.95));
				break;
		}
	}
	else
	{
		if(x!=X  || y!=Y) {
		if(Resolution.GetRect().Contains(x,y))
		{
			Selection=0;
		}
		else if(Style.GetRect().Contains(x,y))
		{
			Selection=1;
		}
		else if(Apply.GetRect().Contains(x,y))
		{
			Selection=2;
		}
		else if(Back.GetRect().Contains(x,y))
		{
			Selection=3;
		}
		else
		{
			Selection=4;
		}
		X=x; Y=y;
		}
		
		float time=myClock.GetElapsedTime();
		switch(Selection)
		{
			case 0:
				Resolution.SetColor(sf::Color(127.5*(1-std::sin(time*10)),127.5*(1-std::sin(time*7)),127.5*(1-std::sin(time*5))));
	Style.SetColor(sf::Color(255-(Style.GetColor().r-255)*-0.95,255-(Style.GetColor().g-255)*-0.95,255-(Style.GetColor().b-255)*-0.95));
	Apply.SetColor(sf::Color(255-(Apply.GetColor().r-255)*-0.95,255-(Apply.GetColor().g-255)*-0.95,255-(Apply.GetColor().b-255)*-0.95));
	Back.SetColor(sf::Color(255-(Back.GetColor().r-255)*-0.95,255-(Back.GetColor().g-255)*-0.95,255-(Back.GetColor().b-255)*-0.95));
				break;
			
			case 1:
				Style.SetColor(sf::Color(127.5*(1-std::sin(time*10)),127.5*(1-std::sin(time*7)),127.5*(1-std::sin(time*5))));
	Resolution.SetColor(sf::Color(255-(Resolution.GetColor().r-255)*-0.95,255-(Resolution.GetColor().g-255)*-0.95,255-(Resolution.GetColor().b-255)*-0.95));
	Apply.SetColor(sf::Color(255-(Apply.GetColor().r-255)*-0.95,255-(Apply.GetColor().g-255)*-0.95,255-(Apply.GetColor().b-255)*-0.95));
	Back.SetColor(sf::Color(255-(Back.GetColor().r-255)*-0.95,255-(Back.GetColor().g-255)*-0.95,255-(Back.GetColor().b-255)*-0.95));
				break;
			
			case 2:
				Apply.SetColor(sf::Color(127.5*(1-std::sin(time*10)),127.5*(1-std::sin(time*7)),127.5*(1-std::sin(time*5))));
	Resolution.SetColor(sf::Color(255-(Resolution.GetColor().r-255)*-0.95,255-(Resolution.GetColor().g-255)*-0.95,255-(Resolution.GetColor().b-255)*-0.95));
	Style.SetColor(sf::Color(255-(Style.GetColor().r-255)*-0.95,255-(Style.GetColor().g-255)*-0.95,255-(Style.GetColor().b-255)*-0.95));
	Back.SetColor(sf::Color(255-(Back.GetColor().r-255)*-0.95,255-(Back.GetColor().g-255)*-0.95,255-(Back.GetColor().b-255)*-0.95));
				break;
			
			case 3:
				Back.SetColor(sf::Color(127.5*(1-std::sin(time*10)),127.5*(1-std::sin(time*7)),127.5*(1-std::sin(time*5))));
	Resolution.SetColor(sf::Color(255-(Resolution.GetColor().r-255)*-0.95,255-(Resolution.GetColor().g-255)*-0.95,255-(Resolution.GetColor().b-255)*-0.95));
	Style.SetColor(sf::Color(255-(Style.GetColor().r-255)*-0.95,255-(Style.GetColor().g-255)*-0.95,255-(Style.GetColor().b-255)*-0.95));
	Apply.SetColor(sf::Color(255-(Apply.GetColor().r-255)*-0.95,255-(Apply.GetColor().g-255)*-0.95,255-(Apply.GetColor().b-255)*-0.95));	
				break;
			
			default:
	Style.SetColor(sf::Color(255-(Style.GetColor().r-255)*-0.95,255-(Style.GetColor().g-255)*-0.95,255-(Style.GetColor().b-255)*-0.95));
	Apply.SetColor(sf::Color(255-(Apply.GetColor().r-255)*-0.95,255-(Apply.GetColor().g-255)*-0.95,255-(Apply.GetColor().b-255)*-0.95));
	Back.SetColor(sf::Color(255-(Back.GetColor().r-255)*-0.95,255-(Back.GetColor().g-255)*-0.95,255-(Back.GetColor().b-255)*-0.95));
	Resolution.SetColor(sf::Color(255-(Resolution.GetColor().r-255)*-0.95,255-(Resolution.GetColor().g-255)*-0.95,255-(Resolution.GetColor().b-255)*-0.95));
	
				break;
				
		}
	}
}



int MenuText::Choose()
{
	if(!WindowChange)
	{
		std::stringstream sstr;
		std::string string;
		
		switch(Selection)
		{
			case 0:
				return GAME;
				
			case 1:
				++myLevel;
				if(myLevel>myMaxlevel)
					myLevel=1;
				sstr.clear(); sstr<<myLevel; sstr>>string;
				Level.SetString("Level: "+string);
				break;
				
			case 2:
				Start.SetColor(sf::Color::White);
				Level.SetColor(sf::Color::White);
				WindowMode.SetColor(sf::Color::White);
				Quit.SetColor(sf::Color::White);
				WindowChange=true;
				break;
			
			case 3:
				return QUIT;
		}
	}
	else
	{
		std::string string, string2;
		std::stringstream sstr;
		switch(Selection)
		{
			case 0:
				++I;
				if(VideoModes.size()<I)
					I=0;
				sstr.clear();
				sstr<<VideoModes[I].Width;
				sstr>>string; sstr.clear();
				sstr<<VideoModes[I].Height;
				sstr>>string2;
				Resolution.SetString("Resolution: "+string+"*"+string2);
				myResolution=VideoModes[I];
				break;
			
			case 1:
				if(myStyle==sf::Style::Close)
				{
					myStyle=sf::Style::Fullscreen;
					Style.SetString("Window style: Fullscreen");
				}
				else
				{
					myStyle=sf::Style::Close;
					Style.SetString("Window style: Window");
				}
				break;
			
			case 2:
				WindowChange=false;
				Resolution.SetColor(sf::Color::White);
				Style.SetColor(sf::Color::White);
				Apply.SetColor(sf::Color::White);
				Back.SetColor(sf::Color::White);
				return WINDOWMODE;
				
			case 3:
				WindowChange=false;
				break;
				
		}
	}
	
	return NOTHING;
}



