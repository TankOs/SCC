#ifndef MENUSTATE_HPP
#define MENUSTATE_HPP

#include "../State.hpp"
#include "../ConfigManager.hpp"

#include "WarpEffect.hpp"
#include "Menu.hpp"

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>


class MenuState : public State
{
	private:
		WarpEffect warpeffect;
		MenuText myMenu;
		ConfigManager& myConfigManager;
		
		sf::Clock myClock;
		
		sf::Sound mySound;
		sf::SoundBuffer myWarpSound;
		sf::SoundBuffer myBackgroundSound;
		
		sf::Shape myShape;
		
		bool myRunning;
		int myNextState;
		
		sf::VideoMode myNewResolution;
		unsigned long myNewStyle;
	public:
		MenuState(sf::RenderWindow&, ConfigManager&);
		
		virtual ~MenuState();

        virtual int Update();
        virtual void Draw();

        virtual void OnEnter();
        virtual void OnLeave();
		
	private:
		bool CheckEvents();
		bool CloseEvents();
		
		void Choosed();
		void ChangeResolution();
		
};

#endif


