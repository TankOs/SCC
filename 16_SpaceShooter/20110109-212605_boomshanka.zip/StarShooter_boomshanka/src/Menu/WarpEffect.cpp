#include "WarpEffect.hpp"



void WarpEffect::LoadMedia()
{

}



void WarpEffect::Update(float time, float length)
{
	if(sf::Randomizer::Random(0,1)==1)
		myBackback.push_front(Starline(sf::Shape::Line(sf::Vector2f(0,0),sf::Vector2f(10,10),3,sf::Color(20,20,40)),sf::Randomizer::Random(0.f,360.f),length));
	
	if(sf::Randomizer::Random(0,1)==1)
		myBack.push_front(Starline(sf::Shape::Line(sf::Vector2f(0,0),sf::Vector2f(10,10),3,sf::Color(70,70,80)),sf::Randomizer::Random(0.f,360.f),length));
	myBack.push_front(Starline(sf::Shape::Line(sf::Vector2f(0,0),sf::Vector2f(10,10),3,sf::Color(70,70,80)),sf::Randomizer::Random(0.f,360.f),length));
	
	myMiddle.push_front(Starline(sf::Shape::Line(sf::Vector2f(0,0),sf::Vector2f(10,10),3,sf::Color(100,100,140)),sf::Randomizer::Random(0.f,360.f),length));
	
	myFront.push_front(Starline(sf::Shape::Line(sf::Vector2f(0,0),sf::Vector2f(10,10),3,sf::Color(250,250,255)),sf::Randomizer::Random(0.f,360.f),length));
//	myFront.push_front(Starline(sf::Shape::Line(sf::Vector2f(0,0),sf::Vector2f(10,10),3,sf::Color(250,250,255)),sf::Randomizer::Random(0.f,360.f),length));
	
	
	for(std::list<Starline>::iterator i=myBackback.end(); i!=myBackback.begin(); )
	{
		--i;
		if(!(*i).Update(time/80))
		{
			myBackback.erase(i);
			i=myBackback.end();
		}
	}
	for(std::list<Starline>::iterator i=myBack.end(); i!=myBack.begin(); )
	{
		--i;
		if(!(*i).Update(time/60))
		{
			myBack.erase(i);
			i=myBack.end();
		}
	}
	for(std::list<Starline>::iterator i=myMiddle.end(); i!=myMiddle.begin(); )
	{
		--i;
		if(!(*i).Update(time/30))
		{
			myMiddle.erase(i);
			i=myMiddle.end();
		}
	}
	for(std::list<Starline>::iterator i=myFront.end(); i!=myFront.begin(); )
	{
		--i;
		if(!(*i).Update(time/20))
		{
			myFront.erase(i);
			i=myFront.end();
		}
	}
}



void WarpEffect::Draw(sf::RenderWindow& window)
{
	for(std::list<Starline>::iterator it=myBackback.begin();it!=myBackback.end();++it)
	{
		(*it).Draw(window);
	}
	for(std::list<Starline>::iterator it=myBack.begin();it!=myBack.end();++it)
	{
		(*it).Draw(window);
	}
	for(std::list<Starline>::iterator it=myMiddle.begin();it!=myMiddle.end();++it)
	{
		(*it).Draw(window);
	}
	for(std::list<Starline>::iterator it=myFront.begin();it!=myFront.end();++it)
	{
		(*it).Draw(window);
	}
}



