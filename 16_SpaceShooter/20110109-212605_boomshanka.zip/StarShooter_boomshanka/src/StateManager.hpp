#ifndef STATEMANAGER_HPP
#define STATEMANAGER_HPP

#include <SFML/Graphics.hpp>

#include "ConfigManager.hpp"

#include "State.hpp"
#include "Menu/MenuState.hpp"
#include "Game/GameState.hpp"


class StateManager
{
	private:
		sf::RenderWindow myWindow;
		
		sf::VideoMode myVideomode;
		std::string myTitle;
		unsigned long myStyle;
		
		
		ConfigManager& myConfigManager;
		
		State* myState;
		
	public:
		StateManager(ConfigManager&);
		~StateManager();
		
		void Init();
		
		int Run();
};


#endif


