#include "StateManager.hpp"



StateManager::StateManager(ConfigManager& manager)
:
myTitle("SpaceShooter"),
myConfigManager(manager)
{

}



StateManager::~StateManager()
{
	myConfigManager.SaveConfig();
	delete myState;
}




void StateManager::Init()
{
	myState=new MenuState(myWindow, myConfigManager);//new GameState(myWindow, myConfigManager.GetLevelPointer()), //FIXME
	
	myConfigManager.Load();
	
	if(!myConfigManager.Quit())
	{
		myVideomode=myConfigManager.GetVideoMode();
		myStyle=myConfigManager.GetStyle();
	
		myWindow.Create(myVideomode, myTitle, myStyle);
		myWindow.EnableVerticalSync(true);
		
		myState->OnEnter();
	}
	
}




int StateManager::Run()
{
	while(true)
	{
		switch(myState->Update())
		{
			case State::NoChange:
				
				break;
			
			case State::Menu:
				myState->OnLeave();
				delete myState;
				myState=new MenuState(myWindow, myConfigManager);
				myState->OnEnter();
				break;
			
			case State::Game:
				myState->OnLeave();
				delete myState;
				myState=new GameState(myWindow, myConfigManager.GetLevelPointer());
				myState->OnEnter();
				break;
			
			case State::NextLevel:
				myState->OnLeave();
				delete myState;
				myConfigManager.NextLevel();
				myState=new GameState(myWindow, myConfigManager.GetLevelPointer());
				myState->OnEnter();
				break;
			
			case State::Quit:
				myState->OnLeave();
				return 0;
			
			case State::Crash:
				
				return 1;
				
		}
		
		myState->Draw();
	}
}



