#ifndef STATE_HPP
#define STATE_HPP

#include <SFML/Graphics.hpp>

class State
{
    public:
        State(sf::RenderWindow& window):myWindow(window) {}

        virtual ~State() {}

        //draw und update werden getrennt
        virtual int Update() = 0;
        virtual void Draw() = 0;

        //zum initialsieren bzw. löschen des states
        virtual void OnEnter() = 0;
        virtual void OnLeave() = 0;

        enum NextState
        {
            NoChange,
            Menu,
            Game,
            NextLevel,
            Quit,
            Crash
        };

    protected:
        sf::RenderWindow& myWindow;
};

#endif // STATE_H_INCLUDED


