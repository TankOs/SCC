#include "ConfigManager.hpp"

#include <sstream>
#include <fstream>
#include <iostream>



ConfigManager::ConfigManager(int argc, char* argv[])
:myArgc(argc),
myArgv(argv),
myProgramName(argv[0]),
myQuit(false)
{
	
}



ConfigManager::~ConfigManager()
{

}



void ConfigManager::Load()
{
	LoadDefault();
	LoadConfig();
	
	for(int i=1; i<myArgc; ++i)
	{
		std::string argument=myArgv[i];
		
		if(argument=="--fullscreen" || argument=="-full")
		{
			myStyle=sf::Style::Fullscreen;
		}
		else if(argument=="--window" || argument=="-win")
		{
			myStyle=sf::Style::Close;
		}
		else if(argument=="--desktop-mode")
		{
			myVideoMode=myVideoMode.GetDesktopMode();
		}
		else if(argument.substr(0,13)=="--resolution=" && argument.length()>18)
		{
			std::string string(argument.substr(13));
			Resolution(string);
		}
		else if(argument.substr(0,5)=="-res=" && argument.length()>10)
		{
			std::string string(argument.substr(5));
			Resolution(string);
		}
		else if(argument=="--help" || argument=="-h")
		{
			Help();
			myQuit=true;
		}
		else
		{
			std::cout<<myProgramName<<": invalid optin '"<<argument<<"'\n";
			std::cout<<"Try '"<<myProgramName<<" --help' to get more information."<<std::endl;
			myQuit=true;
		}
	}
}



bool ConfigManager::LoadConfig(const std::string& path)
{
	std::ifstream file(path.c_str());
	
	if(file.fail())
		return false;
	
	while(!file.eof())
	{
		std::string string;
		std::getline(file,string);
		std::stringstream sstr(string);
		sstr>>string;
		
		if(string=="WindowStyle:")
		{
			sstr>>myStyle;
		}
		else if(string=="VideoMode:")
		{
			sstr>>myVideoMode.Width;
			sstr>>myVideoMode.Height;
		}
		else if(string=="Level:")
		{
			sstr>>myMaxLevel;
			myLevel=myMaxLevel;
		}
	}
	
	return true;
}



void ConfigManager::LoadDefault()
{
	myVideoMode=sf::VideoMode(1024,768);
	myStyle=sf::Style::Close;
	myMaxLevel=myLevel=1;
}



void ConfigManager::SaveConfig(const std::string& path)
{
	std::ofstream file(path.c_str(), std::ios_base::app);
	file.close();
	file.open(path.c_str(), std::ios_base::trunc);
	
	file<<"WindowStyle: "<<myStyle<<"\n";
	file<<"VideoMode: "<<myVideoMode.Width<<" "<<myVideoMode.Height<<"\n";
	file<<"Level: "<<myMaxLevel<<"\n";
	
	file<<"\n";
	
	file.close();
}



void ConfigManager::Help()
{
	std::cout<<"\n\n";
	std::cout<<"Arguments are:\n";
	std::cout<<"\t-h\t  --help\t\tShow this help text.\n";
	std::cout<<"\t-win\t  --window\t\tPlay the game in window mode.\n";
	std::cout<<"\t-full\t  --fullscreen\t\tPlay the game in fullscreen mode.\n";
	std::cout<<"\t-res=x,y  --resolution=x,y\tPlay with a resolution x, y.\n";
	std::cout<<"\t\t  --desktop-mode\tPlay with the desktop resolution.\n";
	
	
	std::cout<<std::endl;
}



void ConfigManager::Resolution(const std::string& string)
{
	std::stringstream sstr(string);
	int x, y; char z;
	sstr>>x;
	sstr>>z;
	sstr>>y;
	myVideoMode=sf::VideoMode(x,y);
}



