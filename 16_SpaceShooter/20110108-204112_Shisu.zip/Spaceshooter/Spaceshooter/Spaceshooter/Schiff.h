#ifndef SCHIFF_H
#define SCHIFF_H

/* Bibliotheken-Includes */
#include "ImageManager.h"
#include "FontManager.h"
#include "PlayerSchuss.h"
#include "Interface.h"
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

class Schiff : public sf::Drawable
{
protected:
	unsigned int HealthPoints;
	sf::Sprite Ship;
	sf::Sprite Balken_Rand;
	sf::Shape Balken_Inhalt;
	sf::Clock Schussfrequenz;
	bool Alive;
	virtual void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const = 0;
public:
	Schiff(const sf::Vector2f& pPosition);
	virtual sf::Vector2f getCenter() const = 0;
	sf::Vector2f getSize() const;
	virtual void verwunden(int pWert, Interface& pInterface) = 0;
	void Die();
	bool isAlive() const;
	void Reset();
};

#endif