#ifndef BUTTON_H
#define BUTTON_H

/* Bibliotheken-Includes */
#include <SFML/Graphics.hpp>

/* Eigene Header-Includes */
#include "Structs.h"

/* Button
 * Ein Button stellt einen Knopf dar, der gedr�ckt werden kann, worauf daraufhin von Seiten des Programms reagiert wird. */
class Button : public sf::Drawable
{
private:
	//Die Sprite des Buttons
	sf::Sprite *NormalSP, *PressedSP;
	
	//Die Shapes des Buttons
	sf::Shape *NormalSH, *PressedSH;
	
	//Gibt an, ob der Button im Moment gedr�ckt ist
	bool Pressed;
	
	//Enth�lt die Ma�e des Buttons
	sf::Vector2f Size;
	
	//Stellt den Text des Buttons grafisch dar
	sf::Text Text;

protected:
	void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const;

public:
	//Konstruktor f�r einen Button, bestehend aus Rechtecken
	Button( const sf::Color& pFarbeNormal, const sf::Color& pFarbePressed, const sf::Vector2f& pSize, const TextProp& pText,
		const sf::Vector2f& pPosition = sf::Vector2f( 0, 0 ) );
	
	//Konstruktor f�r einen Button, bestehend aus Grafiken
	Button( const std::string& pPfadNormal, const std::string& pPfadPressed, const TextProp& pText,
		const sf::Vector2f& pPosition = sf::Vector2f( 0, 0 ), const sf::Vector2f& pOffset = sf::Vector2f( 0, 0 ) );
	
	//Copy-Konstruktor f�r einen Button
	Button(const Button& b);
	
	//Destruktor f�r einen Button
	~Button();

	//Setzt das Offset des Buttons auf pOffset
	void SetTextOffset( const sf::Vector2f& pOffset );
	
	//Gibt zur�ck, ob der Button getroffen wurde
	bool Getroffen( const sf::Vector2f& pPosition );
	
	//Setzt die Variable Pressed auf pPressed
	void SetPressed( bool pPressed );
	
	//Gibt zur�ck, ob der Button gedr�ckt ist
	bool IsPressed() const;
};

#endif