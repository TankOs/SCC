#include "Schiff.h"

extern double less(double p1, double p2);

Schiff::Schiff(const sf::Vector2f& pPosition)
	: Drawable(pPosition), Alive(true), Balken_Rand(*ImgMng.getResource("Pictures/HP-Rand.png"), sf::Vector2f(-6, 5)),
	Balken_Inhalt(sf::Shape::Rectangle(-6, 5, 41, 7, sf::Color(51, 255, 0, 100))), HealthPoints(1000)
{
}

sf::Vector2f Schiff::getSize() const
{
	return Ship.GetSize();
}

bool Schiff::isAlive() const
{
	return Alive;
}

void Schiff::Die()
{
	Alive = false;
	HealthPoints = 0;
}

void Schiff::Reset()
{
	Alive = true;
	HealthPoints = 1000;
	Balken_Inhalt = sf::Shape::Rectangle(-6, 5, 41*HealthPoints/1000, 7, sf::Color(51, 255, 0, 100));
}