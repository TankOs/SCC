#ifndef SLOTMASCHINE_H
#define SLOTMASCHINE_H

/* Bibliotheken-Includes */
#include "ImageManager.h"
#include "FontManager.h"
#include "Gegnerschiff.h"
#include <fstream>
#include <strstream>
#include <iostream>
#include <sstream>
#include <list>
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

class Slotmaschine
{
private:
	std::vector<Gegnerschiff>* Gegner;
	std::list<std::string> AktuelleBefehle;
	std::vector<std::pair<int, std::string>> Levels;
	sf::Clock Uhr;
public:
	Slotmaschine(std::vector<Gegnerschiff>& Gegner);
	void loadLevels();
	void loadCommands( const std::string& Datei );
	void initClock();
	bool CheckNews();
	bool empty() const;
	void Reset(int pLevel);
};

#endif