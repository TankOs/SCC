 _____        _____ _   _         
| __  |_ _   |   __| |_|_|___ _ _ 
| __ -| | |  |__   |   | |_ -| | |
|_____|_  |  |_____|_|_|_|___|___|
      |___|                       
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Dies ist ein Wettbewerbsbeitrag f�r die deutsche SFML-Community
von Dennis Marschner aka Shisu.


- Steuerung -

Maus bewegen			Das Schiff folgt
Linksklick			Das Schiff schie�t



- Ablauf -

Der Levelfortschritt ist an den Icons der
Sch�sse ablesbar, 4 Icons = 4 Level:

Kindertraining (Level 1): 0Pkt - 1000Pkt, Kindergeschoss
Rekrutenausbildung (Level 2): 1001Pkt - 2500Pkt, leichtes Mediumgeschoss
�bungsschlacht (Level 3): 2501Pkt - 4000Pkt, gehobenes Mediumgeschoss
Nacktes �berleben (Level 4): 4001Pkt - 6999 Pkt, Chaosgeschoss

Wenn der Spieler das 4. Level �bersteht, ohne seine Leben zu verlieren,
dann erf�hrt er seine Spielzeit. Ziel ist es, diese m�glichst gering zu
halten.


- Credits -

Code Programmiert von		Dennis Marschner
Grafiken erstellt von		Dennis Marschner
		Audiodateien erhalten von	http://www.freesound.org/
		Lizenz der Audiodateien		http://creativecommons.org/licenses/sampling+/1.0/


- Daten -

Genutzte SFML-Version:		2.0
Download Redistributable Pack:	http://www.microsoft.com/downloads/en/details.aspx?familyid=A7B7A05E-6DE6-4D3A-A423-37BF0912DB84
