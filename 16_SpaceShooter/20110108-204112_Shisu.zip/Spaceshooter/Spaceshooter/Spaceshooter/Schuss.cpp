#include "Schuss.h"

Schuss::Schuss(const sf::Vector2f& pCenter)
{
	SetPosition( pCenter.x-Shot.GetSize().x/2, pCenter.y-Shot.GetSize().y/2 );
}

sf::Vector2f Schuss::getCenter() const
{
	return sf::Vector2f( GetPosition().x+Shot.GetSize().x/2, GetPosition().y+Shot.GetSize().y/2 );
}

bool Schuss::inScreen() const
{
	return GetPosition().x > -50 && GetPosition().x < 450
		&& GetPosition().y > -50 && GetPosition().y < 450;
}

sf::Vector2f Schuss::getSize() const
{
	return Shot.GetSize();
}