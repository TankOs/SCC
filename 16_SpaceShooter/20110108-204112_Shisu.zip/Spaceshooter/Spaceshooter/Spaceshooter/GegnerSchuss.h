#ifndef GEGNERSCHUSS_H
#define GEGNERSCHUSS_H

/* Bibliotheken-Includes */
#include "ImageManager.h"
#include "FontManager.h"
#include "Schuss.h"
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

class GegnerSchuss : public Schuss
{
protected:
	void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const;
public:
	GegnerSchuss(const sf::Vector2f& pCenter);
	void Process(double pFaktor);
};

#endif