#include "PlayerSchiff.h"

extern double less(double p1, double p2);

PlayerSchiff::PlayerSchiff( const sf::Vector2f& pPosition )
	: Schiff(pPosition), Drift(Straight)
{
	Ship.SetImage(*ImgMng.getResource("Pictures/Schiff.png"));
	Ship.SetSubRect( sf::IntRect(41, 0, 41, 43) );
}

void PlayerSchiff::Follow( sf::Vector2f pPosition, double pFaktor )
{
	pPosition.y = less(pPosition.y, 400);
	if( pPosition.y - (this->GetPosition().y + Ship.GetSize().y/2) > 2 )
	{
		if( Drift != Down )
		{
			Ship.SetSubRect( sf::IntRect(82, 0, 41, 43) );
			Drift = Down;
		}
		Move( 0, less(pPosition.y - this->GetPosition().y + Ship.GetSize().y/2, pFaktor*300) );
	}
	else if (pPosition.y - (this->GetPosition().y + Ship.GetSize().y/2) < -2 )
	{
		if( Drift != Up )
		{
			Ship.SetSubRect( sf::IntRect(0, 0, 41, 43) );
			Drift = Up;
		}
		Move( 0, -less(pFaktor*300, this->GetPosition().y + Ship.GetSize().y/2 - pPosition.y) );
	}
	else
	{
		if( Drift != Straight )
		{
			Ship.SetSubRect( sf::IntRect(41, 0, 41, 43) );
			Drift = Straight;
		}
	}

	if(pPosition.x < this->GetPosition().x + Ship.GetSize().x/2)
	{
		Move( -less(pFaktor*180, this->GetPosition().x + Ship.GetSize().x/2 - pPosition.x), 0 );
	}
	else if(pPosition.x > this->GetPosition().x + Ship.GetSize().x/2)
	{
		Move( less(pFaktor*350, pPosition.x - this->GetPosition().x + Ship.GetSize().x/2), 0 );
	}
}

void PlayerSchiff::Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const
{
	if(Alive)
	{
		Target.Draw( Ship );
		Target.Draw( Balken_Inhalt );
		Target.Draw( Balken_Rand );
	}
}

sf::Vector2f PlayerSchiff::getCenter() const
{
	return sf::Vector2f( GetPosition().x + Ship.GetSize().x/2, GetPosition().y + Ship.GetSize().y/2 );
}

void PlayerSchiff::Schuss(std::vector<PlayerSchuss>& Shots, const Interface& pKonsole)
{
	if(Schussfrequenz.GetElapsedTime() > 0.2)
	{
		Shots.push_back( PlayerSchuss(pKonsole.getCurrentShotdirectory(), getCenter(), pKonsole.getCurrentPower() ) );
		Schussfrequenz.Reset();
	}
}

void PlayerSchiff::verwunden(int pWert, Interface& pInterface)
{
	HealthPoints -= less(HealthPoints, pWert);
	if(HealthPoints == 0)
	{
			Alive = false;
	}
	Balken_Inhalt = sf::Shape::Rectangle(-6, 5, 41*HealthPoints/1000, 7, sf::Color(51, 255, 0, 100));
}