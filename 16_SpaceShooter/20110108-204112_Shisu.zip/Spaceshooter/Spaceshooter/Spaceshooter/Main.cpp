/* Bibliotheken-Includes */
#include <iostream>
#include <fstream>
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <sstream>
#include <math.h>

/* Eigene Header-Includes */
#include "ImageManager.h"
#include "FontManager.h"
#include "Button.h"
#include "Structs.h"
#include "PlayerSchiff.h"
#include "Gegnerschiff.h"
#include "Slotmaschine.h"
#include "GegnerSchuss.h"
#include "PlayerSchuss.h"
#include "Interface.h"

/* Spaceshooter
 * Dieses Spiel ist ein Ballerspiel, bei dem man ein Raumschiff durch das Weltall man�vrieren muss. Das Spiel ist in Level unterteilt,
   die durch die verschiedenen Schusssorten im GUI dargestellt werden. Es gibt vier Level mit jeweils anderen "Flugman�vern" der Gegner
   und anderen Schusssorten. Wenn alle Leben aufgebraucht sind ist das Spiel verloren. */

/* To-Do:
 * "Hauptmen�"
 * Abl�ufe integrieren
 * Musik (!!)
 */

int PlayerAmmu_Little = 90, PlayerAmmu_Medium = 140, PlayerAmmu_Big = 175, PlayerAmmu_SuperBig = 480,
	GegnerAmmu = 49, GegnerKill_Pkt = 100, Grenze_Lv4 = 4000, Grenze_Lv3 = 2500, Grenze_Lv2 = 1000;

ImageManager ImgMng;
FontManager FntMng;
std::vector<Gegnerschiff> Gegner;
std::vector<GegnerSchuss> Gegner_Mun;
std::vector<PlayerSchuss> Player_Mun;

bool collision(const Schuss* First, const Schiff* Second);

bool collision(const Schiff* First, const Schiff* Second);

double betrag(double pWert)
{
	if(pWert >= 0) return pWert;
	return -pWert;
}

double less(double p1, double p2)
{
	if( p1 < p2 )
	{
		return p1;
	}
	return p2;
}

int main()
{
	sf::RenderWindow App(sf::VideoMode( 400, 450, 32 ), "Spaceshooter by Shisu", sf::Style::Close);
	App.SetFramerateLimit(60);
	App.ShowMouseCursor(false);
	Slotmaschine Slottest(Gegner); Slottest.loadLevels();
	PlayerSchiff Player( sf::Vector2f(200, 200) );
	sf::Sprite Hintergrund (*ImgMng.getResource("Pictures/Sternenbild.png"));
	sf::Sprite Cursor (*ImgMng.getResource("Pictures/Cursor.png"));
	Interface Konsole(sf::Vector2f(0, 400));
	bool Ex_NoEnemy = false, Ex_Death = false; //"Exeptions" - Ausnahmen
	{
		bool Begin = false;
		Button BeginButton(sf::Color(49, 0, 189, 130), sf::Color(60, 0, 150, 255), sf::Vector2f(42, 24),
			TextProp(sf::Color(255, 0, 150), 20, "", "Start"), sf::Vector2f(170, 190));
		while(App.IsOpened() && !Begin)
		{
			sf::Event Event;
			while(App.GetEvent(Event))
			{
				switch(Event.Type)
				{
				case sf::Event::Closed:
					{
						App.Close();
						break;
					}
				case sf::Event::MouseButtonPressed:
					{
						if(BeginButton.Getroffen(sf::Vector2f(App.GetInput().GetMouseX(), App.GetInput().GetMouseY())))
							BeginButton.SetPressed(true);
						break;
					}
				case sf::Event::MouseButtonReleased:
					{
						if(BeginButton.IsPressed())
							Begin = true;
						break;
					}
				}
			}
			Cursor.SetPosition( App.GetInput().GetMouseX()-8, App.GetInput().GetMouseY()-8 );
			App.Clear();
			App.Draw(Hintergrund);
			App.Draw(Konsole);
			App.Draw(BeginButton);
			App.Draw(Cursor);
			App.Display();
		}
	}
	sf::Clock GesUhr;
	while(App.IsOpened() && Konsole.getScore() < 7500)
	{
		while(App.IsOpened() && !Ex_NoEnemy && !Ex_Death)
		{
			sf::Event Event;
			while(App.GetEvent(Event))
			{
				switch(Event.Type)
				{
				case sf::Event::Closed:
					{
						App.Close();
					}
				case sf::Event::MouseButtonReleased:
					{
						Player.Schuss( Player_Mun, Konsole );
					}
				}
			}
			while ( Slottest.CheckNews() ) {}
			Player.Follow(sf::Vector2f( App.GetInput().GetMouseX(), App.GetInput().GetMouseY() ), App.GetFrameTime());
			if(Hintergrund.GetPosition().x > -1200) Hintergrund.Move(-2*App.GetFrameTime(), 0);
			for(std::vector<Gegnerschiff>::iterator i = Gegner.begin(); i != Gegner.end(); ++i)
			{
				i->Process(App.GetFrameTime());
				i->Schuss(Gegner_Mun);
				if(collision(&(*i), &Player) && i->isAlive())
				{
					i->Die();
					Ex_Death = true;
				}
				for(std::vector<PlayerSchuss>::iterator j = Player_Mun.begin(); j != Player_Mun.end(); ++j)
				{
					if(collision(&(*j), &(*i)) && i->isAlive())
					{
						i->verwunden( j->getPower(), Konsole);
						Player_Mun.erase(j);
						break;
					}
				}
			}
			for(std::vector<GegnerSchuss>::iterator i = Gegner_Mun.begin(); i != Gegner_Mun.end(); ++i)
			{
				i->Process(App.GetFrameTime());
				if(!i->inScreen())
				{
					Gegner_Mun.erase(i);
					break;
				}
				if(collision(&(*i), &Player))
				{
						Player.verwunden( GegnerAmmu, Konsole );
						if(!Player.isAlive())
							Ex_Death = true;
						Gegner_Mun.erase(i);
						break;
				}
			}
			for(std::vector<PlayerSchuss>::iterator i = Player_Mun.begin(); i != Player_Mun.end(); ++i)
			{
				if(!i->inScreen())
				{
					Player_Mun.erase(i);
					break;
				}
				i->Process(App.GetFrameTime());
			}
			Cursor.SetPosition( App.GetInput().GetMouseX()-8, App.GetInput().GetMouseY()-8 );
			App.Clear();
			App.Draw(Hintergrund);
			App.Draw(Player);
			for(std::vector<GegnerSchuss>::iterator i = Gegner_Mun.begin(); i != Gegner_Mun.end(); ++i)
			{
				App.Draw(*i);
			}
			for(std::vector<PlayerSchuss>::iterator i = Player_Mun.begin(); i != Player_Mun.end(); ++i)
			{
				App.Draw(*i);
			}
			for(std::vector<Gegnerschiff>::iterator i = Gegner.begin(); i != Gegner.end(); ++i)
			{
				App.Draw(*i);
			}
			App.Draw(Konsole);
			App.Draw(Cursor);
			App.Display();
			Ex_NoEnemy = Slottest.empty();
		}
		if(Ex_NoEnemy)
		{
			Slottest.Reset( Konsole.getCurrentLevel() ); //Suche neue Gegner aus und starte die Gegnerroutine neu!
			Ex_NoEnemy = false;
		}
		if(Ex_Death)
		{
			Konsole.Life_decrease();
			if(Konsole.Life_getLives() < 1)
			{
				App.Close(); //HandleDeath
			}
			Ex_Death = false;
			Player.Reset();
			Player.SetPosition(-100, 170);
		}
	}
	if(App.IsOpened())
	{
		std::ostringstream Temp;
		Temp<<(int)GesUhr.GetElapsedTime();
		sf::Text Schlussschrift(sf::String("Du hast gewonnen!!\n\nDeine Spielzeit betr�gt\n"+Temp.str()+" Sekunden."));
		sf::Text Schlie�en(sf::String("Du kannst das Fenster schlie�en."), sf::Font::GetDefaultFont(), 16);
		Schlussschrift.SetColor(sf::Color(230, 20, 10));
		Schlie�en.SetColor(sf::Color(230, 20, 10));
		Schlussschrift.SetPosition(10, 10);
		Schlie�en.SetPosition(160, 370);
		while(App.IsOpened())
		{
			sf::Event Event;
			while(App.GetEvent(Event))
			{
				switch(Event.Type)
				{
				case sf::Event::Closed:
					{
						App.Close();
					}
				}
			}
			App.Clear();
			App.Draw(Hintergrund);
			App.Draw(Konsole);
			App.Draw(Player);
			App.Draw(Schlussschrift);
			App.Draw(Schlie�en);
			App.Display();
		}
	}
	return 0;
}

bool collision(const Schuss* First, const Schiff* Second)
{
	return !( (betrag( First->getCenter().x - Second->getCenter().x ) > First->getSize().x/2 + Second->getSize().x/2)
		|| (betrag( First->getCenter().y - Second->getCenter().y ) > First->getSize().y/2 + Second->getSize().y/2) );
}

bool collision(const Schiff* First, const Schiff* Second)
{
	return !( (betrag( First->getCenter().x - Second->getCenter().x ) > First->getSize().x/2 + Second->getSize().x/2)
		|| (betrag( First->getCenter().y - Second->getCenter().y ) > First->getSize().y/2 + Second->getSize().y/2) );
}