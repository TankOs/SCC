#include "Button.h"
#include "ImageManager.h"
#include "FontManager.h"

Button::Button( const sf::Color& pFarbeNormal, const sf::Color& pFarbePressed, const sf::Vector2f& pSize, const TextProp& pText,
			   const sf::Vector2f& pPosition )
			   : Drawable( pPosition ), NormalSP( 0 ), PressedSP( 0 ), Pressed( false ), Size( pSize ),
			   Text( pText.Text, sf::Font::GetDefaultFont(), pText.Size )
{
	NormalSH = new sf::Shape();
	PressedSH = new sf::Shape();
	*NormalSH = sf::Shape::Rectangle( 0, 0, pSize.x, pSize.y, pFarbeNormal );
	*PressedSH = sf::Shape::Rectangle( 0, 0, pSize.x, pSize.y, pFarbePressed );
	Text.SetColor( pText.Color );
}

Button::Button( const std::string& pPfadNormal, const std::string& pPfadPressed, const TextProp& pText, const sf::Vector2f& pPosition,
			   const sf::Vector2f& pOffset )
	: Drawable( pPosition ), NormalSH( 0 ), PressedSH( 0 ), Pressed( false ),
	Text( pText.Text, *FntMng.getResource( pText.Font ), pText.Size )
{
	NormalSP = new sf::Sprite( *ImgMng.getResource( pPfadNormal ) );
	PressedSP = new sf::Sprite( *ImgMng.getResource( pPfadPressed ) );
	Size = sf::Vector2f( ImgMng.getResource( pPfadNormal )->GetWidth(), ImgMng.getResource( pPfadNormal )->GetHeight() );
	Text.SetPosition( pOffset );
	Text.SetColor( pText.Color );
}

Button::Button( const Button& b )
	: Drawable( b.GetPosition() ), Size( b.Size ), Text( b.Text ), Pressed( b.Pressed )
{
	if( b.NormalSH == 0 && b.PressedSH == 0 )
	{
		NormalSP = new sf::Sprite( *b.NormalSP );
		PressedSP = new sf::Sprite( *b.PressedSP );
		NormalSH = 0;
		PressedSH = 0;
	}
	else if( b.NormalSP == 0 && b.PressedSP == 0 )
	{
		NormalSH = new sf::Shape( *b.NormalSH );
		PressedSH = new sf::Shape( *b.PressedSH );
		NormalSP = 0;
		PressedSP = 0;
	}
}

Button::~Button()
{
	/* Zerst�re alle existierenden Elemente und nulle ihre Pointer */
	if( NormalSH != 0 )
	{
		delete NormalSH;
		NormalSH = 0;
	}
	if( NormalSP != 0 )
	{
		delete NormalSP;
		NormalSP = 0;
	}
	if( PressedSH != 0 )
	{
		delete PressedSH;
		PressedSH = 0;
	}
	if( PressedSP != 0 )
	{
		delete PressedSP;
		PressedSP = 0;
	}
}

void Button::Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const
{
	if( NormalSH == 0 && PressedSH == 0 )
	{	//Wenn Sprites genutzt werden
		if( Pressed )
		{
			Target.Draw( *PressedSP );
		}
		else
		{
			Target.Draw( *NormalSP );
		}
	}
	else if( NormalSP == 0 && PressedSP == 0 )
	{	//Wenn Shapes genutzt werden
		if( Pressed )
		{
			Target.Draw( *PressedSH );
		}
		else
		{
			Target.Draw( *NormalSH );
		}
	}
	Target.Draw( Text );
}

bool Button::Getroffen( const sf::Vector2f& pPosition )
{
	sf::Vector2f temp = TransformToLocal( pPosition );
	if( temp.x < 0 || temp.x > Size.x || temp.y < 0 || temp.y > Size.y )
	{
		Pressed = false;
		return false;
	}
	else
	{
		Pressed = true;
		return true;
	}
}

void Button::SetPressed( bool pPressed )
{
	Pressed = pPressed;
}

void Button::SetTextOffset( const sf::Vector2f& pOffset )
{
	Text.SetPosition( pOffset );
}

bool Button::IsPressed() const
{
	return Pressed;
}