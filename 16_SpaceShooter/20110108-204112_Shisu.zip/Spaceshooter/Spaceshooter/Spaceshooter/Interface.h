#ifndef INTERFACE_H
#define INTERFACE_H

/* Bibliotheken-Includes */
#include "ImageManager.h"
#include "FontManager.h"
#include "Lifebar.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

class Interface : public sf::Drawable
{
private:
	Lifebar Lives;
	unsigned int Score;
	sf::Sprite Background;
	sf::Text Score_Txt;
	int PlayerShotPower;
	sf::Shape PlayerShot_Rahmen;
protected:
	void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const;
public:
	Interface(const sf::Vector2f& pPosition);
	void Life_increase();
	void Life_decrease();
	int Life_getLives() const;
	int getCurrentLevel() const;
	void increaseScore(int pWert);
	int getScore() const;
	std::string getCurrentShotdirectory() const;
	int getCurrentPower() const;
	void setShotPower(int pPower);
};

#endif