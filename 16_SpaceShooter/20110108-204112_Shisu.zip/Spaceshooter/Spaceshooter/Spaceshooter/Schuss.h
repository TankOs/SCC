#ifndef SCHUSS_H
#define SCHUSS_H

/* Bibliotheken-Includes */
#include "ImageManager.h"
#include "FontManager.h"
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

class Schuss : public sf::Drawable
{
protected:
	sf::Sprite Shot;
public:
	Schuss(const sf::Vector2f& pCenter);
	bool inScreen() const;
	sf::Vector2f getCenter() const;
	sf::Vector2f getSize() const;
};

#endif