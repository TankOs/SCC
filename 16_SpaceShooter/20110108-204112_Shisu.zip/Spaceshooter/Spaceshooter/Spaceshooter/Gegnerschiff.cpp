#include "Gegnerschiff.h"

extern double less(double p1, double p2);
extern int GegnerKill_Pkt;

Gegnerschiff::Gegnerschiff( const sf::Vector2f& pPosition, float pReloadTime )
	: Schiff(pPosition), Tempo(0, 0), ReloadTime(pReloadTime), Shooting(true)
{
	Ship.SetImage(*ImgMng.getResource("Pictures/Gegnerschiff.png"));
}

void Gegnerschiff::Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const
{
	if(Alive)
	{
		Target.Draw(Ship);
		Target.Draw(Balken_Inhalt);
		Target.Draw(Balken_Rand);
	}
}

void Gegnerschiff::SetTempo( const sf::Vector2f& pTempo )
{
	Tempo = pTempo;
}

sf::Vector2f Gegnerschiff::GetTempo() const
{
	return Tempo;
}

void Gegnerschiff::Process(double pFaktor)
{
	if(Alive)
		Move(sf::Vector2f(pFaktor*Tempo.x, pFaktor*Tempo.y));
}

void Gegnerschiff::Schuss(std::vector<GegnerSchuss>& Shots)
{
	if(Schussfrequenz.GetElapsedTime() > ReloadTime && Alive && Shooting)
	{
		Shots.push_back( GegnerSchuss( getCenter() ) );
		Schussfrequenz.Reset();
	}
}

sf::Vector2f Gegnerschiff::getCenter() const
{
	return sf::Vector2f( GetPosition().x + Ship.GetSize().x/2, GetPosition().y + Ship.GetSize().y/2 );
}

void Gegnerschiff::switchShooting()
{
	Shooting = !Shooting;
}

void Gegnerschiff::verwunden(int pWert, Interface& pInterface)
{
	HealthPoints -= less(HealthPoints, pWert);
	if(HealthPoints == 0)
	{
			Alive = false;
			pInterface.increaseScore(GegnerKill_Pkt);
	}
	Balken_Inhalt = sf::Shape::Rectangle(-6, 5, 41*HealthPoints/1000, 7, sf::Color(51, 255, 0, 100));
}