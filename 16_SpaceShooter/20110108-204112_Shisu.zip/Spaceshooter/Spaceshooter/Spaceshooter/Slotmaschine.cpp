#include "Slotmaschine.h"

Slotmaschine::Slotmaschine(std::vector<Gegnerschiff>& pGegner)
{
	Gegner = &pGegner;
}

void Slotmaschine::loadLevels()
{
	std::fstream Stream( "Data/index.txt", std::fstream::in );
	std::string FullString = "";
	while( std::getline( Stream, FullString ) )
	{
		int Lv;
		std::stringstream StrStream;
		StrStream.str( FullString.substr(0, FullString.find(" ")) );
		StrStream >> Lv;
		FullString = FullString.substr( FullString.find(" ")+1 );
		Levels.push_back(std::pair<int, std::string>(Lv, FullString));
	}
	Stream.close();
	Reset(1);
}

void Slotmaschine::loadCommands( const std::string& pDatei )
{
	std::fstream Stream( pDatei, std::fstream::in );
	std::string FullString = "";
	while( std::getline( Stream, FullString ) )
	{
		AktuelleBefehle.push_back(FullString);
	}
	Stream.close();
}

void Slotmaschine::initClock()
{
	Uhr.Reset();
}

bool Slotmaschine::empty() const
{
	for(std::vector<Gegnerschiff>::iterator i = Gegner->begin(); i != Gegner->end(); ++i)
	{
		if(i->isAlive()) return false;
	}
	return true;
}

bool Slotmaschine::CheckNews()
{
	if(!AktuelleBefehle.empty())
	{
		float Time, VecSize = AktuelleBefehle.size();
		std::stringstream StrStream;
		StrStream.str( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) );
		StrStream >> Time;
		if( Uhr.GetElapsedTime() > Time )
		{
			*(AktuelleBefehle.begin()) = AktuelleBefehle.begin()->substr( AktuelleBefehle.begin()->find(" ")+1 );
			if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "Create" )
			{
				float Schuss = 0;
				sf::Vector2f Position;
				*(AktuelleBefehle.begin()) = AktuelleBefehle.begin()->substr( AktuelleBefehle.begin()->find(" ")+1 );
				std::stringstream StrStream_Pos_X;
				StrStream_Pos_X.str( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) );
				StrStream_Pos_X >> Position.x;
				*(AktuelleBefehle.begin()) = AktuelleBefehle.begin()->substr( AktuelleBefehle.begin()->find(" ")+1 );
				std::stringstream StrStream_Pos_Y;
				StrStream_Pos_Y.str( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) );
				StrStream_Pos_Y >> Position.y;
				
				*(AktuelleBefehle.begin()) = AktuelleBefehle.begin()->substr( AktuelleBefehle.begin()->find(" ")+1 );
				std::stringstream StrStream_Schuss;
				StrStream_Schuss.str( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) );
				StrStream_Schuss >> Schuss;
				Gegner->push_back( Gegnerschiff(Position, Schuss) );
			}
			else
			{
				Gegnerschiff* Pointer;
				if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "1" )
				{
					Pointer = &(*Gegner)[0];
				}
				else if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "2" )
				{
					Pointer = &(*Gegner)[1];
				}
				else if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "3" )
				{
					Pointer = &(*Gegner)[2];
				}
				else if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "4" )
				{
					Pointer = &(*Gegner)[3];
				}
				else if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "5" )
				{
					Pointer = &(*Gegner)[4];
				}
				else if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "6" )
				{
					Pointer = &(*Gegner)[5];
				}
				else if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "7" )
				{
					Pointer = &(*Gegner)[6];
				}
				else if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "8" )
				{
					Pointer = &(*Gegner)[7];
				}
				else if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "9" )
				{
					Pointer = &(*Gegner)[8];
				}
				else if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "10" )
				{
					Pointer = &(*Gegner)[9];
				}
				*(AktuelleBefehle.begin()) = AktuelleBefehle.begin()->substr( AktuelleBefehle.begin()->find(" ")+1 );
				if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "Tempo" )
				{
					sf::Vector2f Tempo;
					*(AktuelleBefehle.begin()) = AktuelleBefehle.begin()->substr( AktuelleBefehle.begin()->find(" ")+1 );
					std::stringstream StrStream_Pos_X;
					StrStream_Pos_X.str( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) );
					StrStream_Pos_X >> Tempo.x;
					*(AktuelleBefehle.begin()) = AktuelleBefehle.begin()->substr( AktuelleBefehle.begin()->find(" ")+1 );
					std::stringstream StrStream_Pos_Y;
					StrStream_Pos_Y.str( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) );
					StrStream_Pos_Y >> Tempo.y;
					Pointer->SetTempo(Tempo);
				}
				else if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "switchShooting" )
				{
					Pointer->switchShooting();
				}
				else if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "die" )
				{
					Pointer->Die();
				}
				else if( AktuelleBefehle.begin()->substr(0, AktuelleBefehle.begin()->find(" ")) == "reset" )
				{
					Pointer->Reset();
				}
			}
			AktuelleBefehle.pop_front();
		}
		else return false;
	}
	else return false;
}

void Slotmaschine::Reset(int pLevel)
{
	while(!Gegner->empty()) Gegner->pop_back();
	while(!AktuelleBefehle.empty()) AktuelleBefehle.pop_front();
	unsigned int Nr = 0;
	do
	{
		Nr = sf::Randomizer::Random(0, Levels.size()-1);
	} while(Levels[Nr].first != pLevel);
	loadCommands( Levels[Nr].second );
	initClock();
}