#ifndef PLAYERSCHIFF_H
#define PLAYERSCHIFF_H

/* Bibliotheken-Includes */
#include "ImageManager.h"
#include "FontManager.h"
#include "PlayerSchuss.h"
#include "Schiff.h"
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

class PlayerSchiff : public Schiff
{
	enum Richtung
	{
		Up, Down, Straight
	};
private:
	Richtung Drift;
protected:
	void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const;
public:
	PlayerSchiff( const sf::Vector2f& pPosition );
	void Follow( sf::Vector2f pPosition, double pFaktor );
	sf::Vector2f getCenter() const;
	void Schuss(std::vector<PlayerSchuss>& Shots, const Interface& pKonsole);
	void verwunden(int pWert, Interface& pInterface);
};

#endif