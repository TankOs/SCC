#ifndef GEGNERSCHIFF_H
#define GEGNERSCHIFF_H

/* Bibliotheken-Includes */
#include "ImageManager.h"
#include "FontManager.h"
#include "GegnerSchuss.h"
#include "Schiff.h"
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

class Gegnerschiff : public Schiff
{
private:
	sf::Vector2f Tempo;
	bool Shooting;
	float ReloadTime;
protected:
	void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const;
public:
	Gegnerschiff( const sf::Vector2f& pPosition, float pReloadTime );
	void SetTempo( const sf::Vector2f& pTempo );
	sf::Vector2f GetTempo() const;
	void Process(double pFaktor);
	void Schuss(std::vector<GegnerSchuss>& Shots);
	sf::Vector2f getCenter() const;
	void switchShooting();
	void verwunden(int pWert, Interface& pInterface);
};

#endif