#ifndef LIFEBAR_H
#define LIFEBAR_H

/* Bibliotheken-Includes */
#include "ImageManager.h"
#include "FontManager.h"
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

class Lifebar : public sf::Drawable
{
private:
	unsigned int Lifecounter;
	sf::Sprite FirstLife, SecondLife, ThirdLife;
protected:
	void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const;
public:
	Lifebar(const sf::Vector2f& pPosition);
	void increase();
	void decrease();
	int getLives() const;
};

#endif