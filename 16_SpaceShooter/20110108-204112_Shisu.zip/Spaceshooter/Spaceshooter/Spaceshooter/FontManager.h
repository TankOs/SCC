#ifndef FONTMANAGER_H_INCLUDED
#define FONTMANAGER_H_INCLUDED
 
#include <SFML/Graphics.hpp>
 
#include "RessourceManager.h"
 
class FontManager : public ResourceManager< sf::Font > {
private:
protected:
	virtual sf::Font* load( const std::string& strId );
public:
};
 
extern FontManager FntMng;
 
#endif