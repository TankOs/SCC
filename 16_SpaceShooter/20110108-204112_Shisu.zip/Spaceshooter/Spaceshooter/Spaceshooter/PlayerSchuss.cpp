#include "PlayerSchuss.h"

PlayerSchuss::PlayerSchuss(const std::string& pPfad, const sf::Vector2f& pCenter, int pPower)
	: Schuss(sf::Vector2f(0, 0)), Power(pPower)
{
	Shot.SetImage(*ImgMng.getResource(pPfad));
	SetPosition( pCenter.x, pCenter.y - Shot.GetSize().y/2 );
}

void PlayerSchuss::Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const
{
	Target.Draw(Shot);
}

void PlayerSchuss::Process(double pFaktor)
{
	Move(pFaktor*300, 0);
}

int PlayerSchuss::getPower() const
{
	return Power;
}