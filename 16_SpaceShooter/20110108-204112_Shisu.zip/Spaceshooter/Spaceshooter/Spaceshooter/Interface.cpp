#include "Interface.h"

extern int PlayerAmmu_Little, PlayerAmmu_Medium, PlayerAmmu_Big, PlayerAmmu_SuperBig, Grenze_Lv4, Grenze_Lv3, Grenze_Lv2;

Interface::Interface(const sf::Vector2f& pPosition)
	: Drawable(pPosition), Lives(sf::Vector2f(7, 27)), Background(*ImgMng.getResource("Pictures/Interface.png")), Score(0),
	PlayerShotPower(1), PlayerShot_Rahmen(sf::Shape::Rectangle(117, 21, 15, 10, sf::Color(0, 0, 0, 0), 1, sf::Color(240, 12, 30, 255)))
{
	Score_Txt.SetPosition(318, 15);
	Score_Txt.SetCharacterSize(14);
	Score_Txt.SetColor(sf::Color(30, 240, 13, 255));
	std::ostringstream Temp;
	Temp<<Score;
	Score_Txt.SetString(Temp.str());
}

void Interface::Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const
{
	Target.Draw(Background);
	Target.Draw(Lives);
	Target.Draw(Score_Txt);
	Target.Draw(PlayerShot_Rahmen);
}

void Interface::Life_increase()
{
	Lives.increase();
}

void Interface::Life_decrease()
{
	Lives.decrease();
}

int Interface::Life_getLives() const
{
	return Lives.getLives();
}

int Interface::getCurrentLevel() const
{
	return PlayerShotPower;
}

void Interface::increaseScore(int pWert)
{
	Score += pWert;
	std::ostringstream Temp;
	Temp<<Score;
	Score_Txt.SetString(Temp.str());
	if(Score > Grenze_Lv4)
	{
		setShotPower(4);
	}
	else if(Score > Grenze_Lv3)
	{
		setShotPower(3);
	}
	else if(Score > Grenze_Lv2)
	{
		setShotPower(2);
	}
	else
	{
		setShotPower(1);
	}
}

int Interface::getScore() const
{
	return Score;
}

std::string Interface::getCurrentShotdirectory() const
{
	switch(PlayerShotPower)
	{
	case 1:
		return "Pictures/Shot Little.png";
		break;
	case 2:
		return "Pictures/Shot Medium.png";
		break;
	case 3:
		return "Pictures/Shot Big.png";
		break;
	case 4:
		return "Pictures/Shot Superbig.png";
		break;
	}
}

int Interface::getCurrentPower() const
{
	switch(PlayerShotPower)
	{
	case 1:
		return PlayerAmmu_Little;
		break;
	case 2:
		return PlayerAmmu_Medium;
		break;
	case 3:
		return PlayerAmmu_Big;
		break;
	case 4:
		return PlayerAmmu_SuperBig;
		break;
	}
}

void Interface::setShotPower(int pPower)
{
	switch(pPower)
	{
	case 1:
		{
			PlayerShot_Rahmen = sf::Shape::Rectangle(117, 21, 15, 10, sf::Color(0, 0, 0, 0), 1, sf::Color(240, 12, 30, 255));
			PlayerShotPower = pPower;
			break;
		}
	case 2:
		{
			PlayerShot_Rahmen = sf::Shape::Rectangle(134, 20, 18, 12, sf::Color(0, 0, 0, 0), 1, sf::Color(240, 12, 30, 255));
			PlayerShotPower = pPower;
			break;
		}
	case 3:
		{
			PlayerShot_Rahmen = sf::Shape::Rectangle(154, 18, 28, 16, sf::Color(0, 0, 0, 0), 1, sf::Color(240, 12, 30, 255));
			PlayerShotPower = pPower;
			break;
		}
	case 4:
		{
			PlayerShot_Rahmen = sf::Shape::Rectangle(185, 7, 32, 38, sf::Color(0, 0, 0, 0), 1, sf::Color(240, 12, 30, 255));
			PlayerShotPower = pPower;
			break;
		}
	}
}