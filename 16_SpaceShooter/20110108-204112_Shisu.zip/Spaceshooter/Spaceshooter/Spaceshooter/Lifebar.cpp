#include "Lifebar.h"

Lifebar::Lifebar(const sf::Vector2f& pPosition)
	: Drawable(pPosition), Lifecounter(3),
	FirstLife(*ImgMng.getResource("Pictures/Leben.png"), sf::Vector2f(0, 0)),
	SecondLife(*ImgMng.getResource("Pictures/Leben.png"), sf::Vector2f(19, 0)),
	ThirdLife(*ImgMng.getResource("Pictures/Leben.png"), sf::Vector2f(38, 0))
{
}

void Lifebar::increase()
{
	if(Lifecounter < 3)
	{
		Lifecounter++;
	}
}

void Lifebar::decrease()
{
	if(Lifecounter > 0)
	{
		Lifecounter--;
	}
}

int Lifebar::getLives() const
{
	return Lifecounter;
}

void Lifebar::Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const
{
	if(Lifecounter >= 1)
		Target.Draw(FirstLife);
	if(Lifecounter >= 2)
		Target.Draw(SecondLife);
	if(Lifecounter >= 3)
		Target.Draw(ThirdLife);
}