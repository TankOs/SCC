#ifndef TEXTPROP_H
#define TEXTPROP_H

/* Bibliotheken-Includes */
#include <SFML/Graphics.hpp>

/* TextProp
 * Eine Klasse, die alle relevanten Informationen �ber einen Text in sich vereint, um sie
 * komfortabler als Parameter Funktionen �bergeben kann. */
struct TextProp
{
	//Enth�lt die Schriftgr��e
	float Size;

	//Enth�lt die Schriftfarbe
	sf::Color Color;

	//Enth�lt den Font
	std::string Font;

	//Enth�lt den Text als solches
	std::string Text;

	//Konstruktor einer TextProp
	TextProp( const sf::Color& pColor, float pSize, const std::string& pFont, const std::string& pText = "" )
		: Color( pColor ), Font( pFont ), Size( pSize ), Text( pText )
	{
	}
};

#endif

#ifndef LOOL_H
#define LOOL_H

/* Bibliotheken-Includes */
#include <SFML/Graphics.hpp>

/* Lool
 * Eine (in Anlehnung an "Bool" entstandene) Wahrheitswertenumeration, die zus�tzlich zu yes (true) und no (false)
 * auch ein maybe zul�sst, was besonders f�r Momente, indenen der Inhalt des Bools ungewiss ist, geeignet ist. */
enum lool
{
	yes,
	no,
	maybe
};

#endif