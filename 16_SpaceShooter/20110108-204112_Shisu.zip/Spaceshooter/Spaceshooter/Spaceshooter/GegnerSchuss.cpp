#include "GegnerSchuss.h"

GegnerSchuss::GegnerSchuss(const sf::Vector2f& pCenter)
	: Schuss(pCenter)
{
	Shot.SetImage(*ImgMng.getResource("Pictures/Shot Enemy.png"));
}

void GegnerSchuss::Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const
{
	Target.Draw(Shot);
}

void GegnerSchuss::Process(double pFaktor)
{
	Move(-pFaktor*200, 0);
}