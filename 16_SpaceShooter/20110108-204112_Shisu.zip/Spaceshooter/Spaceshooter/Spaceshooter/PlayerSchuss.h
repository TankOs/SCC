#ifndef PLAYERSCHUSS_H
#define PLAYERSCHUSS_H

/* Bibliotheken-Includes */
#include "ImageManager.h"
#include "FontManager.h"
#include "Schuss.h"
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

class PlayerSchuss : public Schuss
{
private:
	int Power;
protected:
	void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const;
public:
	PlayerSchuss(const std::string& pPfad, const sf::Vector2f& pCenter, int pPower);
	void Process(double pFaktor);
	int getPower() const;
};

#endif