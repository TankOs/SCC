#include "menustate.hpp"

MenuState::MenuState(sf::RenderWindow &window) :
State(window)
{
}

MenuState::~MenuState()
{
}
