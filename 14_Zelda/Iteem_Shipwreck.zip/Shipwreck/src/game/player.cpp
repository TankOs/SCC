#include "player.hpp"
#include "imagemanager.hpp"
#include <cmath>

const float PI = 3.1415926;

const float Speed = 120;
const float StepSize = 18;

Player::Player()
{
    //ctor
}

Player::~Player()
{
    //dtor
}

bool Player::load(sf::Vector2f startPosition)
{
    sf::Image *image = globalImageManager.get("data/head.png");
    if(image == NULL)
        return false;
    head.SetImage(*image);
    head.SetPosition(startPosition);
    head.SetOrigin(image->GetWidth()/2.f, image->GetHeight()/2.f);
    target = head.GetPosition();

    image = globalImageManager.get("data/hand.png");
    if(image == NULL)
        return false;
    leftHand.SetImage(*image); rightHand.SetImage(*image);
    leftHand.SetOrigin (image->GetWidth()/2.f, image->GetHeight()/2.f);
    leftHand.SetOrigin (leftHand.GetOrigin() + sf::Vector2f( 17.f,   0.f));
    rightHand.SetOrigin(image->GetWidth()/2.f, image->GetHeight()/2.f);
    rightHand.SetOrigin(rightHand.GetOrigin() + sf::Vector2f(-17.f,   0.f));

    image = globalImageManager.get("data/foot.png");
    if(image == NULL)
        return false;
    leftFoot.SetImage(*image); rightFoot.SetImage(*image);
    leftFoot.SetOrigin (image->GetWidth()/2.f, image->GetHeight()/2.f);
    leftFoot.SetOrigin (leftFoot.GetOrigin() + sf::Vector2f(  7.f,  2.f));
    rightFoot.SetOrigin(image->GetWidth()/2.f, image->GetHeight()/2.f);
    rightFoot.SetOrigin(rightFoot.GetOrigin() + sf::Vector2f(- 7.f,  2.f));


    leftHand.SetPosition (head.GetPosition());
    rightHand.SetPosition(head.GetPosition());
    leftFoot.SetPosition (head.GetPosition());
    rightFoot.SetPosition(head.GetPosition());


    origin = sf::Vector2f(image->GetWidth()/2.f, image->GetHeight()/2.f);

    head.SetScale(0.5f, 0.5f) ;
    leftHand.SetScale (0.5f, 0.5f);
    rightHand.SetScale(0.5f, 0.5f);
    leftFoot.SetScale (0.5f, 0.5f);
    rightFoot.SetScale(0.5f, 0.5f);

    return true;
}

void Player::draw(sf::RenderTarget &target) const
{
    target.Draw(leftFoot);
    target.Draw(rightFoot);
    target.Draw(leftHand);
    target.Draw(rightHand);
    target.Draw(head);
}

void Player::handleInput(sf::Vector2f mouseCoords, const sf::Input &input, float elapsedTime)
{
    static bool left = true;
    static float x = 0.f;
    if(input.IsMouseButtonDown(sf::Mouse::Left))
    {
        target = mouseCoords;
    }
    sf::Vector2f tmp = target - head.GetPosition();
    if(tmp.x * tmp.x > 10 or tmp.y * tmp.y > 10)
    {
        float c = std::sqrt(tmp.x * tmp.x + tmp.y * tmp.y);
        float angle = std::atan2(tmp.x, tmp.y) * 180 / PI + 180;
        float k = Speed * leftFoot.GetScale().x / c * elapsedTime;
        tmp *= k;

        head.Move(tmp);
        leftHand.SetPosition (head.GetPosition());
        rightHand.SetPosition(head.GetPosition());
        leftFoot.SetPosition (head.GetPosition());
        rightFoot.SetPosition(head.GetPosition());

        if(left)
            x += c*k;
        else
            x -= c*k;
        if(x > StepSize * leftFoot.GetScale().x)
        {
            x = StepSize* leftFoot.GetScale().x - (x - StepSize* leftFoot.GetScale().x);
            left = false;
        }
        else if(x < -StepSize * leftFoot.GetScale().x)
        {
            x = -StepSize* leftFoot.GetScale().x - (x + StepSize* leftFoot.GetScale().x);
            left = true;
        }

        leftFoot.SetOrigin ( origin + sf::Vector2f(  7.f,  2.f+x));
        rightFoot.SetOrigin( origin + sf::Vector2f(- 7.f,  2.f-x));

        head.SetRotation(angle) ;
        leftHand.SetRotation (angle+x);
        rightHand.SetRotation(angle+x);
        leftFoot.SetRotation (angle);
        rightFoot.SetRotation(angle);
    }
}

sf::Vector2f Player::getPosition(void) const
{
    return head.GetPosition();
}
