#include "character.hpp"

Character::Character()
{
    //ctor
}

Character::~Character()
{
    //dtor
}
