#include "shipwreck.hpp"

int main(void)
{
    Shipwreck shipwreck;
    return shipwreck.run();
}
