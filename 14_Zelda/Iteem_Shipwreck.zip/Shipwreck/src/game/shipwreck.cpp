#include "shipwreck.hpp"
#include "gamestate.hpp"
#include "menustate.hpp"

#include <SFML/Graphics.hpp>

#include "imagemanager.hpp"

Shipwreck::Shipwreck():
myState(NULL)
{
}

Shipwreck::~Shipwreck()
{
    if(myState != NULL)
    {
        myState->clear();
        delete myState;
    }
}

int Shipwreck::run()
{
    sf::RenderWindow app(sf::VideoMode(1024, 768, 32), "Shipwreck");//, sf::Style::Fullscreen);
    //app.UseVerticalSync(true);
    app.SetFramerateLimit(60);

    myState = new MenuState(app);
    myState->init();
    bool IsRunning = true;
    while(IsRunning)
    {
        switch(myState->run())
        {
            case State::NoChange :
                break;
            case State::Close :
                IsRunning = false;
                break;
            case State::MenuState :
                myState->clear();
                delete myState;
                myState = new MenuState(app);
                myState->init();
                break;
            case State::GameState :
                myState->clear();
                delete myState;
                myState = new GameState(app);
                myState->init();
                break;
        }
        myState->draw();
    }
    return EXIT_SUCCESS;
}
