#include "gamestate.hpp"
#include <SFML/Graphics.hpp>
#include <iostream>

GameState::GameState(sf::RenderWindow &window) :
State(window)
{
}

GameState::~GameState()
{
}

int GameState::run()
{
    sf::Event Event;
    while(app.GetEvent(Event))
    {
        if(Event.Type == sf::Event::Closed)
            return State::Close;
        if(Event.Type == sf::Event::KeyPressed and Event.Key.Code == sf::Key::Escape)
            return State::Close;
    }

    const sf::Input &input = app.GetInput();

    myPlayer.handleInput(app.ConvertCoords(input.GetMouseX(), input.GetMouseY()), input, app.GetFrameTime());

    myCamera.move(myPlayer.getPosition());
    myCamera.update(app.GetFrameTime());
    app.SetView(myCamera.getView());

    myTilemap.setCenter(myCamera.getView().GetCenter());

    return State::NoChange;
}

void GameState::draw()
{
    app.Clear();

    app.Draw(myTilemap);
    myPlayer.draw(app);

    app.Display();
}

int GameState::init()
{
    myCamera.setView(app.GetDefaultView());

    if(!myPlayer.load(sf::Vector2f(1600, 1600)))
        return 1;
    if(!myTilemap.loadFromFile("data/tilemap.tmx", myPlayer.getPosition(), myCamera.getView().GetSize()))
        return 1;

    return 0;
}

int GameState::clear()
{
    return 0;
}

int GameState::pause()
{
    return 0;
}

int GameState::resume()
{
    return 0;
}
