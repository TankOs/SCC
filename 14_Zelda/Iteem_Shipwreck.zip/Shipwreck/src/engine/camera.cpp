#include "camera.hpp"

Camera::Camera()
{
    //ctor
}

Camera::~Camera()
{
    //dtor
}

const sf::View & Camera::getView(void) const
{
    return myView;
}

void Camera::setView(const sf::View & view)
{
    myView = view;
    myTarget = myView.GetCenter();
}

void Camera::move(sf::Vector2f point)
{
    myTarget = point;
}

void Camera::update(float elapsedTime)
{
    sf::Vector2f tmp = myTarget - myView.GetCenter();
    if(tmp.x * tmp.x > 9 or tmp.y * tmp.y > 9)
    {
        myView.Move(tmp * CameraSpeed * elapsedTime);
    }
}
