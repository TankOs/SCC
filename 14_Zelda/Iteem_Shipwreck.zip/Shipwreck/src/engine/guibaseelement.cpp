#include "guibaseelement.hpp"

GuiBaseElement::GuiBaseElement()
{
    //ctor
}

GuiBaseElement::~GuiBaseElement()
{
    //dtor
}
