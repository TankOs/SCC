#include "guimanager.hpp"

GuiManager::GuiManager()
{
    //ctor
}

GuiManager::~GuiManager()
{
    //dtor
}
