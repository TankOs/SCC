#include "state.hpp"

State::State(sf::RenderWindow &window) :
app(window)
{
}

State::~State()
{
}
