#include "tilemap.hpp"
#include "imagemanager.hpp"
#include <iostream>
#include <fstream>
#include <sstream>

Tilemap::Tilemap() :
myTileDimension(0, 0),
myMapDimension(0, 0),
myCenter(0, 0),
mySize(0, 0),
myTileSet(NULL)
{
}

Tilemap::~Tilemap()
{
}

void Tilemap::Render(sf::RenderTarget& target, sf::Renderer& renderer) const
{
    for(std::list< sf::Sprite >::const_iterator it = myTiles.begin(); it != myTiles.end(); ++it)
    {
        target.Draw(*it);
    }
}

bool Tilemap::loadFromFile(const std::string &path, sf::Vector2f center, sf::Vector2f size)
{
    myCenter = center;
    mySize = size;

    std::ifstream file(path.c_str());
    if(!file.good())
    {
        std::cerr << "Not able to open file " << path << std::endl;
        return false;
    }
    std::string line;
    std::stringstream str;
    while(!file.eof())
    {
        std::getline(file, line);
        size_t pos = line.find("=");
        if(pos == std::string::npos)
            return false;

        int tmp = 0;
        std::string tmpString = line.substr(0, pos);

        if(tmpString == "tileset")
        {
            myTileSet = globalImageManager.get("data/"+line.substr(pos+1, std::string::npos));
            myTileSet->SetSmooth(false);
        }
        else
        {
            str << line.substr(pos+1, std::string::npos);
            str >> tmp;
            str.clear();
        }
        if(tmpString == "width")
            myMapDimension.x = tmp;
        else if(tmpString =="height")
            myMapDimension.y = tmp;
        else if(tmpString == "tilewidth")
            myTileDimension.x = tmp;
        else if(tmpString == "tileheight")
            myTileDimension.y = tmp;
        else if(tmpString == "layer")
            break;
    }
    if(myMapDimension.x < 1 or myMapDimension.y < 1 or myTileDimension.x < 1 or myTileDimension.y < 1 or myTileSet == NULL)
        return false;

    myMap.resize(myMapDimension.x);
    for(int i = 0; i < myMapDimension.x; i++)
    {
       myMap[i].resize(myMapDimension.y);

    }

    int i = 0;
    while(!file.eof())
    {
        getline(file, line);

        if(i < myMapDimension.y)
        {
            size_t curPos = 0;
            for(int j = 0; j < myMapDimension.x; j++)
            {
                std::string tmpString;
                int tmp = 0;
                while(line[curPos] != ',' and curPos != line.size())
                {
                    tmpString += line[curPos];
                    curPos++;
                }
                curPos++;
                str << tmpString;
                str >> tmp;
                str.clear();
                myMap[j][i] = tmp;
            }
        }
        i++;
    }

    reloadMap();

    return true;
}

void Tilemap::setCenter(sf::Vector2f center)
{
    if(static_cast<int>(myCenter.x/myTileDimension.x) != static_cast<int>(center.x/myTileDimension.x) or
       static_cast<int>(myCenter.y/myTileDimension.y) != static_cast<int>(center.y/myTileDimension.y))
    {
        myCenter = center;
        reloadMap();
    }
    myCenter = center;
}

void Tilemap::setSize(sf::Vector2f size)
{
    mySize = size;
    reloadMap();
}

void Tilemap::reloadMap()
{
    myTiles.clear();
    sf::IntRect rect(static_cast<int>((myCenter.x - mySize.x / 2) / myTileDimension.x - 1),
                     static_cast<int>((myCenter.y - mySize.y / 2) / myTileDimension.y - 1),
                     static_cast<int>(mySize.x / myTileDimension.x + 4),
                     static_cast<int>(mySize.y / myTileDimension.y + 4));

    sf::Sprite tmp;

    int tileSetWidth = myTileSet->GetWidth()/myTileDimension.x;
    tmp.SetImage(*myTileSet);

    for(int i = rect.Left; i < rect.Left + rect.Width; ++i)
    {
        for(int j = rect.Top; j < rect.Top + rect.Height; ++j)
        {
            if(i >= 0 and i < myMapDimension.x and j >=0 and j < myMapDimension.y)
            {
                tmp.SetPosition(i * myTileDimension.x, j * myTileDimension.y);
                tmp.SetSubRect(sf::IntRect(myTileDimension.x * ((myMap[i][j]-1) % tileSetWidth),
                                           myTileDimension.y * ((myMap[i][j]-1) / tileSetWidth),
                                           myTileDimension.x,
                                           myTileDimension.y));
                myTiles.push_back(tmp);
            }
        }
    }
}
