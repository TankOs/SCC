#ifndef CAMERA_H
#define CAMERA_H

#include <SFML/Graphics.hpp>

class Camera
{
    public:
        Camera();
        ~Camera();

        const sf::View & getView(void) const;
        void setView(const sf::View & view);
        void update(float elapsedTime);

        void move(sf::Vector2f point);
    private:
        sf::View myView;
        sf::Vector2f myTarget;
        static const float CameraSpeed = 3.f;
};

#endif // CAMERA_H
