#ifndef STATE_H
#define STATE_H

#include <SFML/Graphics/RenderWindow.hpp>

class State
{
    public:
        State(sf::RenderWindow &window);
        virtual ~State();

        virtual int run() = 0;
        virtual void draw() = 0;

        virtual int init() = 0;
        virtual int clear() = 0;

        virtual int pause() = 0;
        virtual int resume() = 0;

        enum
        {
            NoChange,
            Close,
            GameState,
            MenuState
        };
    protected:
        sf::RenderWindow &app;
};

#endif // STATE_H
