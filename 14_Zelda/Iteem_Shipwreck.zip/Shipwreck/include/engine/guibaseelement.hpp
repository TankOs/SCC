#ifndef GUIBASEELEMENT_HPP
#define GUIBASEELEMENT_HPP

#include <SFML/Graphics.hpp>


class GuiBaseElement : public sf::Drawable
{
    public:
        GuiBaseElement();
        virtual ~GuiBaseElement();
    protected:
    private:
};

#endif // GUIBASEELEMENT_HPP
