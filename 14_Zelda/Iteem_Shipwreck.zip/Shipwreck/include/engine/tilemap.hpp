#ifndef TILEMAP_H
#define TILEMAP_H

#include <SFML/Graphics.hpp>
#include <vector>
#include <list>
#include <string>

class Tilemap : public sf::Drawable
{
    public:
        Tilemap();
        virtual ~Tilemap();

        bool loadFromFile(const std::string &path, sf::Vector2f center = sf::Vector2f(0,0), sf::Vector2f size = sf::Vector2f(0,0));
        void setCenter(sf::Vector2f center);
        void setSize(sf::Vector2f size);

    private:
        virtual void Render(sf::RenderTarget& target, sf::Renderer& renderer) const;
        void reloadMap(void);

        std::list< sf::Sprite > myTiles;
        std::vector< std::vector< sf::Uint32 > > myMap;

        sf::Vector2i myTileDimension;
        sf::Vector2i myMapDimension;
        sf::Vector2f myCenter;
        sf::Vector2f mySize;

        sf::Image *myTileSet;
};

#endif // TILEMAP_H
