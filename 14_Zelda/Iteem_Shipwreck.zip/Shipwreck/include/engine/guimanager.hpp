#ifndef GUIMANAGER_HPP
#define GUIMANAGER_HPP

#include <SFML/Graphics.hpp>
#include <string>
#include <list>
#include "guibaseelement.hpp"

class GuiManager
{
    public:
        GuiManager();
        virtual ~GuiManager();
        bool loadSkin(const std::string &path);
        void handleEvent(sf::Event event);
        void draw(sf::RenderTarget &target);
        void addElement(GuiBaseElement *);
    private:
        std::list<GuiBaseElement *> myElements;
};

#endif // GUIMANAGER_HPP
