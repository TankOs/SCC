#ifndef CHARACTER_H
#define CHARACTER_H

#include <SFML/Graphics.hpp>

class Character
{
    public:
        Character();
        virtual ~Character();
        //virtual bool load() = 0;
        //virtual void draw(sf::RenderTarget &target)const = 0;
};

#endif // CHARACTER_H
