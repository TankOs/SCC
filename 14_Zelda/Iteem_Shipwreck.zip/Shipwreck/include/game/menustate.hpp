#ifndef MENUSTATE_HPP
#define MENUSTATE_HPP

#include "state.hpp"


class MenuState : public State
{
    public:
        MenuState(sf::RenderWindow &window);
        virtual ~MenuState();

        virtual int run(){return State::GameState;};
        virtual void draw() {};

        virtual int init(){return 0;};
        virtual int clear(){return 0;};

        virtual int pause(){return 0;};
        virtual int resume(){return 0;};
};

#endif // MENUSTATE_HPP
