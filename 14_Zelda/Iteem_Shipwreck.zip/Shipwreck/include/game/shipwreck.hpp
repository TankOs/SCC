#ifndef SHIPWRECK_H
#define SHIPWRECK_H

#include "state.hpp"

class Shipwreck
{
    public:
        Shipwreck();
        ~Shipwreck();
        int run(void);
    private:
        State *myState;
};

#endif // SHIPWRECK_H
