#ifndef PLAYER_H
#define PLAYER_H

#include "character.hpp"
#include <SFML/Graphics.hpp>

class Player : public Character
{
    public:
        Player();
        virtual ~Player();
        virtual bool load(sf::Vector2f startPosition);
        virtual void draw(sf::RenderTarget &target) const;
        void handleInput(sf::Vector2f mouseCoords, const sf::Input &input, float elapsedTime);
        sf::Vector2f getPosition(void) const;
    private:
        sf::Sprite head;
        sf::Sprite leftHand;
        sf::Sprite rightHand;
        sf::Sprite leftFoot;
        sf::Sprite rightFoot;
        sf::Vector2f target;


        sf::Vector2f origin;
};

#endif // PLAYER_H
