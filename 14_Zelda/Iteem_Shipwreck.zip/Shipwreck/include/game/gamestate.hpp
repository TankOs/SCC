#ifndef GAMESTATE_H
#define GAMESTATE_H

#include "state.hpp"
#include "tilemap.hpp"
#include "player.hpp"
#include "camera.hpp"

class GameState : public State
{
    public:
        GameState(sf::RenderWindow &window);
        virtual ~GameState();

        virtual int run();
        virtual void draw();

        virtual int init();
        virtual int clear();

        virtual int pause();
        virtual int resume();
    private:
        Tilemap myTilemap;
        Player myPlayer;
        Camera myCamera;
};

#endif // GAMESTATE_H
