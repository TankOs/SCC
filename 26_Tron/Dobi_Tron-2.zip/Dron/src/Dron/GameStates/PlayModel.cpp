/*
 * Dron (Dobi's Tron/Snake game)
 * Copyright (C) 2012 Tobias Hermann

 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "PlayModel.h"
#include "Play.h"

#include "../Player.h"
#include "../Items/RandomItemFactory.h"
#include "../DronGame.h"

#include "../../Synthesizer.h"

#include "ShowTextAndWait.h"
#include "MainMenu.h"

#include <iostream>

namespace Dron
{

PlayModel::PlayModel(const World& world, const PlayerPtrs playerPtrs, float stepsPerSecond, double newItemProbability) :
		world_(world), playerPtrs_(playerPtrs), stepsPerSecond_(stepsPerSecond), newItemProbability_(
				newItemProbability), elapsedTimeSinceLastStep_(0.f), stepNum_(0), randomGenerator_(randomDevice_()), randomDoubleDistribution_(
				0., 1.)
{
}

const PlayModel::PlayerPtrs PlayModel::GetAlivePlayers() const
{
	PlayerPtrs alivePlayers;
	for (auto it(std::begin(playerPtrs_)); it != std::end(playerPtrs_); ++it)
		if ((*it)->IsAlive())
			alivePlayers.push_back(*it);
	return alivePlayers;
}

void PlayModel::Step()
{
	++stepNum_;
	typedef std::vector<Position> Positions;

	// Helper function: Return a copy of a list of players with one particular player removed.
	auto FilterOtherPlayers = [](const PlayerPtr& playerPtr, const PlayerPtrs& playerPtrs) -> PlayerPtrs
	{
		PlayerPtrs otherPlayers;
		std::remove_copy_if(std::begin(playerPtrs),
				std::end(playerPtrs),
				std::back_inserter(otherPlayers),
				[&](const PlayerPtr otherPlayerPtr)
				{
					return otherPlayerPtr == playerPtr;
				}
		);
		return otherPlayers;
	};

	// Precalculate where the players would be after this time step.
	PlayerPtrs alivePlayers(GetAlivePlayers());
	std::for_each(std::begin(alivePlayers), std::end(alivePlayers), [&](PlayerPtr& playerPtr)
	{
		playerPtr->CalculateNextStep(world_, FilterOtherPlayers(playerPtr,playerPtrs_));
	});

	// Helper function: Checks if one player will hit another.
	auto CheckForPlayerHit = [&](PlayerPtr& hitterPtr, PlayerPtr& hitteePtr)
	{
		// Will the heads of both players be at the same spot after this step?
			if (hitterPtr != hitteePtr && hitterPtr->IsAlive() && hitteePtr->IsAlive() &&
					hitterPtr->NextPosition(world_) == hitteePtr->NextPosition(world_))
			{
				hitterPtr->HitOtherPlayer(hitterPtr->NextPosition(world_), *hitteePtr, world_);
				hitteePtr->HitOtherPlayer(hitteePtr->NextPosition(world_), *hitterPtr, world_);
				return;
			}
			// Does the possible hitter crash into already existing elements of the potential hittee?
			const Player::Positions& positions(hitteePtr->GetPositions());
			for (auto posIt(std::begin(positions)); posIt != std::end(positions); ++posIt)
			{
				if (hitterPtr->NextPosition(world_) != hitterPtr->GetFrontPosition() &&
						hitterPtr->NextPosition(world_) == *posIt)
				{
					if (hitterPtr == hitteePtr)
					{
						hitterPtr->HitSelf(hitterPtr->NextPosition(world_), world_);
						break;
					}
					hitterPtr->HitOtherPlayer(hitterPtr->NextPosition(world_), *hitteePtr, world_);
					break;
				}
			}
		};

	// Check if one player hits another.
	std::for_each(std::begin(playerPtrs_), std::end(playerPtrs_), [&](PlayerPtr& playerPtr)
	{
		if (playerPtr->IsAlive())
		{
			const Position& nextPos(playerPtr->NextPosition(world_));
			World::Positions wallPositions(world_.GetWallPositions());
			if (std::find(std::begin(wallPositions), std::end(wallPositions), nextPos) != std::end(wallPositions))
			playerPtr->HitWall(nextPos, world_);
			std::for_each(std::begin(playerPtrs_), std::end(playerPtrs_),
					[&](PlayerPtr& otherPlayerPtr)
					{
						CheckForPlayerHit(playerPtr, otherPlayerPtr);
					}
			);
		}
	});

	// Check if players collect items.
	alivePlayers = GetAlivePlayers(); // This may have changed meanwhile.
	World::ItemPtrs& itemPtrs(world_.GetItemPtrs());
	std::for_each(std::begin(alivePlayers), std::end(alivePlayers), [&](PlayerPtr& playerPtr)
	{
		auto itItemPtr(std::begin(itemPtrs));
		const Position& nextPos(playerPtr->NextPosition(world_));
		while (itItemPtr != std::end(itemPtrs))
		{
			if (nextPos == (*itItemPtr)->GetPosition() && playerPtr->HitItem(nextPos, *itItemPtr, world_))
			{
				itItemPtr = itemPtrs.erase(itItemPtr);
				continue;
			}
			if (itItemPtr != std::end(itemPtrs))
			++itItemPtr;
		}
	});

	// Let Items decay.
	for (auto it(std::begin(itemPtrs)); it != std::end(itemPtrs);)
	{
		(*it)->Decay();
		if ((*it)->IsDecayed())
			it = itemPtrs.erase(it);
		else
			++it;
	}

	// Move Players one step.
	std::for_each(std::begin(alivePlayers), std::end(alivePlayers), [&](PlayerPtr& playerPtr)
	{
		playerPtr->ExecuteNextStep(world_, stepNum_);
	});
}

void PlayModel::UpdateAnimations(float elapsedTime)
{
	world_.UpdateAnimations(elapsedTime);
}

bool PlayModel::Update(float elapsedTime, Play& play)
{
	elapsedTimeSinceLastStep_ += elapsedTime;

	UpdateAnimations(elapsedTime);

	// Do nothing before it's time for the next step.
	if (elapsedTimeSinceLastStep_ < 1.f / stepsPerSecond_)
		return true;

	Step();

	// Place new Item?
	if (randomDoubleDistribution_(randomGenerator_) < newItemProbability_)
	{
		World::ItemPtr newItemPtr(RandomItemFactory::Instance().Create(world_, playerPtrs_));
		if (newItemPtr)
			world_.InsertItem(newItemPtr);
	}

	// Did somebody win or was there even a draw?
	PlayerPtrs alivePlayers(GetAlivePlayers());
	switch (alivePlayers.size())
	{
	case 0:
		std::cout << "Draw." << std::endl;
		Synthesizer::PlaySound("Draw");
		play.SetNextState(
				GameState::GameStatePtr(
						new ShowTextAndWait("Draw.", sf::Color(255, 255, 255), GameState::GameStatePtr(new MainMenu()),
								1.f, DronGame::Instance().CaptureScreen())));
		break;
	case 1:
		std::string text(alivePlayers.front()->GetName() + " won.");
		Synthesizer::PlaySound("Win");
		std::cout << text << std::endl;
		play.SetNextState(
				GameState::GameStatePtr(
						new ShowTextAndWait(text, alivePlayers.front()->GetColor(),
								GameState::GameStatePtr(new MainMenu()), 1.f, DronGame::Instance().CaptureScreen())));
		break;
	}

	// Reset the next step waiting time.
	elapsedTimeSinceLastStep_ = 0.f;
	return true;
}

} /* namespace Dron */
