/*
 * Dron (Dobi's Tron/Snake game)
 * Copyright (C) 2012 Tobias Hermann

 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef DRON_PLAYER_H_
#define DRON_PLAYER_H_

#include "../Vector2D.h"

#include <SFML/Graphics/Color.hpp>
#include <SFML/Window/Event.hpp>
#include <SFML/Graphics/Rect.hpp>

#include <string>
#include <list>
#include <memory>
#include <vector>

namespace Dron
{

class World;
class PlayerController;
class Item;

/*
 * A player inside the tron world
 *
 * The first position in the list of elements marks the head.
 */
class Player
{
public:
	typedef Vector2D<int> Position;
	typedef Vector2D<int> Vector;
	typedef sf::Rect<int> Rect;
	typedef std::list<Position> Positions;
	typedef std::shared_ptr<Player> PlayerPtr;
	typedef std::vector<PlayerPtr> PlayerPtrs;
	typedef std::shared_ptr<Item> ItemPtr;
	typedef std::list<ItemPtr> ItemPtrs;
	typedef std::shared_ptr<PlayerController> ControllerPtr;
	Player(const std::string& name, const Position& initialPosition, const sf::Color& color,
			const ControllerPtr& controllerPtr, ItemPtrs::size_type maxItems, Positions::size_type minLength = 8);

	// Forward keyboard inputs to controller.
	void PushKeyInput(const sf::Key::Code& keyCode);

	// Forward joypad inputs to controller.
	void PushJoyInput(const sf::Event::JoyMoveEvent& jobMoveEvent);

	// Let the controller tell us what to do next.
	void CalculateNextStep(const World& world, const PlayerPtrs& otherPlayerPtrs);
	bool RemovePosition(const Position& pos, World& world);
	void ExecuteNextStep(const World& world, std::size_t stepNum);

	// returns true if item is collected, false if not
	bool HitItem(const Position& pos, ItemPtr& itemPtr, World& world);
	void HitWall(const Position& pos, World& world);
	void HitSelf(const Position& pos, World& world);
	void HitOtherPlayer(const Position& pos, Player& other, World& world);

	// Reduze tail length every nth step
	void ShrinkTail(std::size_t stepNum, std::size_t n = 2);
	bool IsAlive() const
	{
		return alive_;
	}

	// Where will his head be in the next time step in a given workd?
	const Position NextPosition(const World& world) const;

	// The head's position.
	const Position& GetFrontPosition() const;
	const Position& GetBackPosition() const;
	const sf::Color& GetColor() const
	{
		return color_;
	}
	const Positions& GetPositions() const
	{
		return positions_;
	}
	void SetPositions(const Positions& positions)
	{
		positions_ = positions;
	}
	const ItemPtrs& GetItemPtrs() const
	{
		return itemPtrs_;
	}

	const ControllerPtr& GetControllerPtr() const
	{
		return controllerPtr_;
	}
	Vector GetLastDirection() const
	{
		return lastDirection_;
	}
	void ShrinkToMinLength();
	const std::string& GetName() const
	{
		return name_;
	}
protected:
	void Die(const Position& position, World& world);
	std::string name_;
	Positions positions_;
	sf::Color color_;
	ControllerPtr controllerPtr_;
	Vector lastDirection_;
	bool alive_;
	ItemPtrs::size_type maxItems_;
	Positions::size_type minLength_;
	ItemPtrs itemPtrs_;
};

} /* namespace Dron */

#endif /* DRON_PLAYER_H_ */
