#include <cstdlib>
#include <time.h>
#include "game.h"

int main()
{
    srand(time(NULL));

    Game game;
    game.run();
    return 0;
}
