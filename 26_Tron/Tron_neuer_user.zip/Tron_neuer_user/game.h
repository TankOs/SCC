#ifndef GAME_H
#define GAME_H

#include <iostream>
#include <sstream>
#include <math.h>
#include <SFML/Graphics.hpp>
#include "player.h"

class Game
{
private:
    enum GameState { _Menu, _Pause, _Run, _Close } m_gameState;

    sf::RenderWindow m_window;
    sf::Clock m_clock, m_stepTimer;
    //
    sf::Font m_font;
    sf::Text m_player1_score_text, m_player2_score_text, m_info_text, m_info2_text;
    //
    sf::RenderTexture m_menuTex;
    sf::Texture m_cursorTex, m_menuBgTex, m_backgroundTex;
    sf::Sprite m_cursorSprite, m_menuBgSprite, m_backgroundSprite;
    //
    char keyCodeToChar[26];
    //
    int m_level;
    std::string m_player1Name, m_player2Name;
    int m_playerNameInput;
    Player m_player1, m_player2;
    //
    void pause();
    void resume();
    void close();
    //

    void addLetterToPlayerName(int keyCode);
    void menuKeyboardEvent(int keyCode);
    void resetPlayers();
    void updateText();
    void newLevel();
    //
    void getEvents();
    void update(float frameTime);
    void render();
    void loop();
public:
    Game();
    void run();
};

#endif // GAME_H
