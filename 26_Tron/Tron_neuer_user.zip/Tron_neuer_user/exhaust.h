#ifndef EXHAUST_H
#define EXHAUST_H

#include <SFML/Graphics.hpp>
#include <cstdlib>

class Exhaust
{
    sf::CircleShape m_shape;
    float m_speed, m_maxRadius;
public:
    Exhaust(sf::Vector2f position);
    void evaporate();
    void render(sf::RenderWindow& window);
    sf::Vector2f getPosition();
    float getRadius();
};

#endif // EXHAUST_H
