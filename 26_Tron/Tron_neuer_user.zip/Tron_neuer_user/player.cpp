#include "player.h"

Player::Player(sf::RenderWindow &window, sf::Vector2f position, const std::string& image) :
    m_mainWindow(window),
    m_startPosition(position),
    m_velocity(1, 0),
    m_newVelocity(1, 0),
    m_score(0),
    m_speed(10)
{
    m_texture.loadFromFile(image);
    m_sprite.setTexture(m_texture);
    m_sprite.setOrigin(13, 7);
    m_sprite.setPosition(position);

    m_carCircleCollisionRadius = sqrt(pow(m_sprite.getOrigin().x, 2) + pow(m_sprite.getOrigin().y, 2));
}

sf::Vector2f Player::randomPosition(sf::Vector2f position, float deviation)
{
    sf::Vector2f ret_vect;
    float dev_x = (static_cast<float>(rand())/static_cast<float>(RAND_MAX)*2 - 1) * deviation;
    float dev_y = (static_cast<float>(rand())/static_cast<float>(RAND_MAX)*2 - 1) * deviation;
    ret_vect.x = position.x + dev_x;
    ret_vect.y = position.y + dev_y;
    return ret_vect;
}

bool Player::testCollision(sf::Vector2f position)
{
    for(unsigned int i = 0;i < m_exhaustCloud.size();i++)
    {
        if(sqrt(pow(m_exhaustCloud[i].getPosition().x-position.x, 2) + pow(m_exhaustCloud[i].getPosition().y-position.y, 2)) < m_exhaustCloud[i].getRadius()+m_carCircleCollisionRadius)
            return true;
    }

    return false;
}

void Player::move(float frameTime)
{
    m_sprite.setPosition(m_sprite.getPosition().x+m_velocity.x*frameTime*m_speed, m_sprite.getPosition().y+m_velocity.y*frameTime*m_speed);
}

void Player::step()
{
    m_velocity = m_newVelocity;
    float angle = asin(m_velocity.y / m_speed)*180/M_PI;
    m_sprite.setRotation(angle);

    m_exhaustCloud.push_back(Exhaust(randomPosition(m_sprite.getPosition(), 2.5)));
    m_exhaustCloud.push_back(Exhaust(randomPosition(m_sprite.getPosition(), 2.5)));
    for(unsigned int i = 0;i < m_exhaustCloud.size();i++)
    {
        m_exhaustCloud[i].evaporate();
    }
}

void Player::render()
{
    for(unsigned int i = 0;i < m_exhaustCloud.size();i++)
    {
        m_exhaustCloud[i].render(m_mainWindow);
    }
    m_mainWindow.draw(m_sprite);
}

void Player::panLeft()
{
    float angle = asin(m_newVelocity.y / m_speed) - M_PI/18;    // -= 10 degrees
    m_newVelocity.y = sin(angle)*m_speed;
    m_newVelocity.x = m_newVelocity.y/tan(angle);
}
void Player::panRight()
{
    float angle = asin(m_newVelocity.y / m_speed) + M_PI/18;    // += 10 degrees
    m_newVelocity.y = sin(angle)*m_speed;
    m_newVelocity.x = m_newVelocity.y/tan(angle);
}

int Player::getScore()
{
    return m_score;
}
void Player::incScore()
{
    m_score++;
}

sf::Vector2f Player::getPosition()
{
    return m_sprite.getPosition();
}
void Player::setPosition(sf::Vector2f position)
{
    m_sprite.setPosition(position);
}

void Player::reset()
{
    m_sprite.setPosition(m_startPosition);
    m_sprite.setRotation(0);
    m_velocity.x = 1;
    m_velocity.y = 0;
    m_newVelocity = m_velocity;
    m_exhaustCloud.clear();
}
