#include "exhaust.h"

Exhaust::Exhaust(sf::Vector2f position) :
    m_speed(1.0f),
    m_maxRadius(0)
{
    m_speed = static_cast<float>(rand())/static_cast<float>(RAND_MAX)*0.8f + 0.25f;

    float radius = static_cast<float>(rand())/static_cast<float>(RAND_MAX)*2 + 2.5f;

    int alpha = static_cast<float>(rand())/static_cast<float>(RAND_MAX)*110 + 10;

    m_shape.setPosition(position);
    m_shape.setRadius(radius);
    m_shape.setFillColor(sf::Color(0, 0, 0, alpha));

    m_maxRadius = static_cast<float>(rand())/static_cast<float>(RAND_MAX)*8 + 3;
}

void Exhaust::evaporate()
{
    if(m_shape.getRadius() < m_maxRadius)
        m_shape.setRadius(m_shape.getRadius() + m_speed);
}

void Exhaust::render(sf::RenderWindow& window)
{
    window.draw(m_shape);
}

sf::Vector2f Exhaust::getPosition()
{
    return m_shape.getPosition();
}

float Exhaust::getRadius()
{
    return m_shape.getRadius();
}
