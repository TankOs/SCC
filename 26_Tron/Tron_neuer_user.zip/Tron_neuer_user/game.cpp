#include "game.h"

Game::Game() :
    m_gameState(_Menu),
    m_window(sf::VideoMode(1024, 768), "Tron", sf::Style::Close),
    m_player1(m_window, sf::Vector2f(100, 100), "media/images/player.png"),
    m_player2(m_window, sf::Vector2f(100, 300), "media/images/player2.png"),
    m_level(0),
    m_playerNameInput(1)
{
    m_window.setMouseCursorVisible(false);
    m_window.setVerticalSyncEnabled(true);
    m_menuTex.create(m_window.getSize().x, 50, true);
    m_cursorTex.loadFromFile("media/images/cursor.png");
    m_menuBgTex.loadFromFile("media/images/menu.png");
    m_backgroundTex.loadFromFile("media/images/background.jpg");
    m_cursorSprite.setTexture(m_cursorTex);
    m_cursorSprite.setOrigin(m_cursorTex.getSize().x/2, m_cursorTex.getSize().y/2);
    m_menuBgSprite.setTexture(m_menuBgTex);
    m_backgroundSprite.setTexture(m_backgroundTex);
    m_backgroundSprite.setPosition(0, 50);

    m_font.loadFromFile("Vera.ttf");
    m_player1_score_text.setFont(m_font);
    m_player1_score_text.setColor(sf::Color::Black);
    m_player1_score_text.setString("0");
    m_player1_score_text.setPosition(0, 7);
    m_player2_score_text.setFont(m_font);
    m_player2_score_text.setColor(sf::Color::Black);
    m_player2_score_text.setString("0");
    m_player2_score_text.setPosition(0, 7);
    m_info_text.setFont(m_font);
    m_info_text.setString("Spieler 1 --- Spieler 2");
    m_info_text.setPosition(0, 6);
    m_info2_text.setFont(m_font);
    m_info2_text.setCharacterSize(20);
    m_info2_text.setString("Namen f�r beide Spieler eingeben.\nJeweils mit \"Return\" best�tigen.\nLos!");
    m_info2_text.setPosition(m_window.getSize().x/2 - m_info2_text.getGlobalBounds().width/2, m_window.getSize().y/2 - m_info2_text.getGlobalBounds().height/2);

    keyCodeToChar[0] = 'A';
    keyCodeToChar[1] = 'B';
    keyCodeToChar[2] = 'C';
    keyCodeToChar[3] = 'D';
    keyCodeToChar[4] = 'E';
    keyCodeToChar[5] = 'F';
    keyCodeToChar[6] = 'G';
    keyCodeToChar[7] = 'H';
    keyCodeToChar[8] = 'I';
    keyCodeToChar[9] = 'J';
    keyCodeToChar[10] = 'K';
    keyCodeToChar[11] = 'L';
    keyCodeToChar[12] = 'M';
    keyCodeToChar[13] = 'N';
    keyCodeToChar[14] = 'O';
    keyCodeToChar[15] = 'P';
    keyCodeToChar[16] = 'Q';
    keyCodeToChar[17] = 'R';
    keyCodeToChar[18] = 'S';
    keyCodeToChar[19] = 'T';
    keyCodeToChar[20] = 'U';
    keyCodeToChar[21] = 'V';
    keyCodeToChar[22] = 'W';
    keyCodeToChar[23] = 'X';
    keyCodeToChar[24] = 'Y';
    keyCodeToChar[25] = 'Z';

    newLevel();
}

void Game::run()
{
    m_clock.restart();
    m_stepTimer.restart();
    loop();
}

void Game::pause()
{
    m_gameState = _Pause;
}
void Game::resume()
{
    m_gameState = _Run;
}
void Game::close()
{
    m_gameState = _Close;
}

void Game::resetPlayers()
{
    m_player1.reset();
    m_player2.reset();
}

void Game::updateText()
{
    std::ostringstream stream;
    stream<<m_player1.getScore();
    m_player1_score_text.setString(stream.str());
    m_player1_score_text.setPosition(51 - m_player1_score_text.getGlobalBounds().width/2, m_player1_score_text.getPosition().y);

    std::ostringstream stream2;
    stream2<<m_player2.getScore();
    m_player2_score_text.setString(stream2.str());
    m_player2_score_text.setPosition(973 - m_player2_score_text.getGlobalBounds().width/2, m_player2_score_text.getPosition().y);

    std::ostringstream stream3;
    stream3<<m_player1Name<<" ---- Level "<<m_level<<" ---- "<<m_player2Name;
    m_info_text.setString(stream3.str());
    m_info_text.setPosition(m_window.getSize().x/2 - m_info_text.getGlobalBounds().width/2, m_info_text.getPosition().y);
}

void Game::newLevel()
{
    m_level++;
    resetPlayers();
    updateText();
}

void Game::addLetterToPlayerName(int keyCode)
{
    std::ostringstream stream;

    if(m_playerNameInput == 1)
    {
        stream<<m_player1Name<<keyCodeToChar[keyCode];
        m_player1Name = stream.str();
    }
    else
    {
        stream<<m_player2Name<<keyCodeToChar[keyCode];
        m_player2Name = stream.str();
    }
}

void Game::menuKeyboardEvent(int keyCode)
{
     if(keyCode >= 0 && keyCode <= 25)
         addLetterToPlayerName(keyCode);
}

void Game::getEvents()
{
    sf::Event event;
    while(m_window.pollEvent(event))
    {
        switch(event.type)
        {
            case sf::Event::Closed:
            {
                close();
                break;
            }
            case sf::Event::KeyPressed:
            {
                if(m_gameState == _Menu)
                    menuKeyboardEvent(event.key.code);
                switch(event.key.code)
                {
                    case sf::Keyboard::Escape:
                    {
                        close();
                        break;
                    }
                    case sf::Keyboard::Return:
                    {
                        if(m_gameState == _Menu)
                        {
                            if(m_playerNameInput == 1)
                                m_playerNameInput = 2;
                            else
                                m_gameState = _Run;
                        }
                        break;
                    }
                    case sf::Keyboard::Pause:
                    {
                        if(m_gameState == _Run)
                            pause();
                        else if(m_gameState == _Pause)
                            resume();
                        break;
                    }
                    default:
                        break;
                }
                break;
            }
            case sf::Event::MouseMoved:
            {
                m_cursorSprite.setPosition(sf::Mouse::getPosition(m_window).x, sf::Mouse::getPosition(m_window).y);
            }
            default:
                break;
        }
    }
}

void Game::update(float frameTime)
{
    if(m_gameState == _Close)
        m_window.close();
    if(m_gameState == _Menu)
    {
        updateText();
        return;
    }

    m_player1.move(frameTime);
    m_player2.move(frameTime);

    if(m_stepTimer.getElapsedTime().asMilliseconds() > 100)
    {
        m_stepTimer.restart();

        if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
            m_player1.panLeft();
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
            m_player1.panRight();

        if(sf::Keyboard::isKeyPressed(sf::Keyboard::A))
            m_player2.panLeft();
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::D))
            m_player2.panRight();

        m_player1.step();
        m_player2.step();
    }

    if(m_player1.testCollision(m_player2.getPosition()))
    {
        m_player1.incScore();
        newLevel();
    }
    else if(m_player2.testCollision(m_player1.getPosition()))
    {
        m_player2.incScore();
        newLevel();
    }

    //player1 out of screen
    if(m_player1.getPosition().x > m_window.getSize().x)
        m_player1.setPosition(sf::Vector2f(m_window.getSize().x-10, m_player1.getPosition().y));
    else if(m_player1.getPosition().x < 0)
        m_player1.setPosition(sf::Vector2f(10, m_player1.getPosition().y));
    else if(m_player1.getPosition().y > m_window.getSize().y)
        m_player1.setPosition(sf::Vector2f(m_player1.getPosition().x, m_window.getSize().y-10));
    else if(m_player1.getPosition().y < m_menuBgSprite.getGlobalBounds().height)
        m_player1.setPosition(sf::Vector2f(m_player1.getPosition().x, m_menuBgSprite.getGlobalBounds().height+10));
    //player2 out of screen
    if(m_player2.getPosition().x > m_window.getSize().x)
        m_player2.setPosition(sf::Vector2f(m_window.getSize().x-10, m_player2.getPosition().y));
    else if(m_player2.getPosition().x < 0)
        m_player2.setPosition(sf::Vector2f(10, m_player2.getPosition().y));
    else if(m_player2.getPosition().y > m_window.getSize().y)
        m_player2.setPosition(sf::Vector2f(m_player2.getPosition().x, m_window.getSize().y-10));
    else if(m_player2.getPosition().y < m_menuBgSprite.getGlobalBounds().height)
        m_player2.setPosition(sf::Vector2f(m_player2.getPosition().x, m_menuBgSprite.getGlobalBounds().height+10));
}

void Game::render()
{
    m_window.clear(sf::Color(40, 35, 200));

    m_window.draw(m_backgroundSprite);

    m_player1.render();
    m_player2.render();

    //Menu
    m_menuTex.clear(sf::Color::Transparent);

    m_menuTex.draw(m_menuBgSprite);
    m_menuTex.draw(m_player1_score_text);
    m_menuTex.draw(m_player2_score_text);
    m_menuTex.draw(m_info_text);

    m_menuTex.display();
    sf::Sprite sprite(m_menuTex.getTexture());
    m_window.draw(sprite);
    //

    if(m_gameState == _Menu)
        m_window.draw(m_info2_text);

    m_window.draw(m_cursorSprite);

    m_window.display();
}

void Game::loop()
{
    while(m_window.isOpen())
    {
        getEvents();

        if(m_gameState == _Pause)
            m_clock.restart();
        else
            update(m_clock.restart().asSeconds());

        render();
    }
}