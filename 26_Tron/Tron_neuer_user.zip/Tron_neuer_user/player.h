#ifndef PLAYER_H
#define PLAYER_H

#include <SFML/Graphics.hpp>
#include <deque>
#include <math.h>
#include <time.h>
#include "exhaust.h"

class Player
{
private:
    sf::RenderWindow &m_mainWindow;
    sf::Vector2f m_startPosition, m_velocity, m_newVelocity;
    sf::Texture m_texture;
    sf::Sprite m_sprite;
    std::deque<Exhaust> m_exhaustCloud;
    int m_score;
    float m_speed, m_carCircleCollisionRadius;
    //
    sf::Vector2f randomPosition(sf::Vector2f position, float deviation);
public:
    Player(sf::RenderWindow &window, sf::Vector2f position, const std::string& image);
    bool testCollision(sf::Vector2f position);
    void move(float frameTime);
    void step();
    void render();
    void panLeft();
    void panRight();
    int getScore();
    void incScore();
    sf::Vector2f getPosition();
    void setPosition(sf::Vector2f position);
    void reset();
};

#endif // PLAYER_H
