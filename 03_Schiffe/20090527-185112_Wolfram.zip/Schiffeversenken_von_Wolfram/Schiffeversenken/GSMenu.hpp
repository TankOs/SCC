#ifndef __GSMENU_HPP__
#define __GSMENU_HPP__

#include "GameStates.hpp"

class GSMenu : public GameStates
{
    private:
        static GSMenu mGSMenu;
    public:
		sf::Sprite mSBG;
		sf::String mTitel;

        void Init(GameEngine *Game);
        void HandleEvents(GameEngine *Game);
        void Update(GameEngine *Game);
        void Draw(GameEngine *Game);

        static GSMenu *Instance()
        {
            return &mGSMenu;
        }
    protected:
        GSMenu() {}
};

#endif
