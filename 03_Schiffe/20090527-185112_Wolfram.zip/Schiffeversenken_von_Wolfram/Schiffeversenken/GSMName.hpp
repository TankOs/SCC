#ifndef __GSMNAME_HPP__
#define __GSMNAME_HPP__

#include "GameStates.hpp"

class GSMName : public GameStates
{
    private:
        static GSMName mGSMName;
    public:
		sf::Sprite mSBG;
		sf::String mSNickname;

		std::string TextEntered;
		std::string LegalCharacters;
		std::string::size_type MaxLength;

        void Init(GameEngine *Game);
        void HandleEvents(GameEngine *Game);
        void Update(GameEngine *Game);
        void Draw(GameEngine *Game);

        static GSMName *Instance()
        {
            return &mGSMName;
        }
    protected:
        GSMName() {}
};

#endif
