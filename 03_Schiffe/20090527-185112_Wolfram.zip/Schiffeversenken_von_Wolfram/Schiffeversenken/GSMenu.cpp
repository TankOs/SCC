#include "GSGame.hpp"
#include "GSMName.hpp"

#include "GSMenu.hpp"

GSMenu GSMenu::mGSMenu;

void GSMenu::Init(GameEngine *Game)
{
	mSBG.SetImage(Game->mIBG1);
	mSBG.SetPosition(435.f, 220.f);

	mTitel.SetText("Schiffeversenken von Wolfram");
	mTitel.SetFont(sf::Font::GetDefaultFont());
	mTitel.SetColor(sf::Color::Cyan);
	mTitel.SetSize(48.f);
	mTitel.SetCenter(mTitel.GetRect().GetWidth() / 2.f, mTitel.GetSize() / 2.f);
	mTitel.SetPosition(540.f, 100.f);
}

void GSMenu::HandleEvents(GameEngine *Game)
{
	sf::Event Event;
    while (Game->mWindow.GetEvent(Event))
    {
        switch (Event.Type)
        {
            case sf::Event::Closed:
            {
                Game->mWindow.Close();
                break;
            }
            case sf::Event::KeyPressed:
            {
                switch(Event.Key.Code)
                {
                    case sf::Key::Escape:
                    {
                        Game->mWindow.Close();
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }
            case sf::Event::MouseButtonPressed:
            {
                switch(Event.MouseButton.Button)
                {
                    case sf::Mouse::Left:
                    {
						if (Game->mWindow.GetInput().GetMouseX() >= 440 && Game->mWindow.GetInput().GetMouseX() <= 640 && Game->mWindow.GetInput().GetMouseY() >= 225 && Game->mWindow.GetInput().GetMouseY() <= 275)
                        {
							Game->ChangeGameState(GSGame::Instance());
						}
						if (Game->mWindow.GetInput().GetMouseX() >= 440 && Game->mWindow.GetInput().GetMouseX() <= 640 && Game->mWindow.GetInput().GetMouseY() >= 300 && Game->mWindow.GetInput().GetMouseY() <= 350)
                        {
							Game->ChangeGameState(GSMName::Instance());
						}
						if (Game->mWindow.GetInput().GetMouseX() >= 440 && Game->mWindow.GetInput().GetMouseX() <= 640 && Game->mWindow.GetInput().GetMouseY() >= 375 && Game->mWindow.GetInput().GetMouseY() <= 425)
                        {
							Game->mWindow.Close();
						}
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }
            default:
            {
                break;
            }
        }
    }
}

void GSMenu::Update(GameEngine *Game)
{
}

void GSMenu::Draw(GameEngine *Game)
{
	Game->mWindow.Draw(mSBG);
	Game->mWindow.Draw(mTitel);
}
