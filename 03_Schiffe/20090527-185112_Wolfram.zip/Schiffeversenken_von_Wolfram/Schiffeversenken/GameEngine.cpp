#include "GameEngine.hpp"
#include "GameStates.hpp"

bool GameEngine::Init()
{
    mServerAddress = "boxbox.org";
    mServerPort = 10500;

    if (!mServerAddress.IsValid() || mClient.Connect(mServerPort, mServerAddress) != sf::Socket::Done)
    {
        std::cout << "Verbindung zum Server konnte nicht hergestellt werden." << std::endl;
        std::cout << "[Enter druecken um das Programm zu beenden]" << std::endl;
        std::cin.get();
        return false;
    }

    if (!mICursor.LoadFromFile("cursor.png") || !mIBG1.LoadFromFile("menu.png") || !mIBG2.LoadFromFile("name.png") || !mIBG3_1.LoadFromFile("gamebrowser.png") || !mIBG3_2.LoadFromFile("gamebrowserarrows.png") || !mIBG3_3.LoadFromFile("gamebrowsermenu.png") || !mIBG4.LoadFromFile("bg.png") || !mIRadar.LoadFromFile("radar.png") || !mIMiss.LoadFromFile("miss.png") || !mIHit.LoadFromFile("hit.png") || !mIShip.LoadFromFile("ship.png"))
    {
        std::cout << "Ein Bild konnte nicht geladen werden." << std::endl;
        std::cout << "[Enter druecken um das Programm zu beenden]" << std::endl;
        std::cin.get();
        return false;
    }

    mClient.SetBlocking(false);

    mICursor.CreateMaskFromColor(sf::Color(255, 242, 0), 0);
    mSCursor.SetImage(mICursor);

	Nickname = "Captain";

    mWindow.Create(sf::VideoMode(1080, 640, 32), "Schiffeversenken Client von Wolfram", sf::Style::Close, sf::WindowSettings(24, 8, 0));
    mWindow.SetFramerateLimit(120);
    mWindow.ShowMouseCursor(false);

    return true;
}

void GameEngine::ChangeGameState(GameStates *NewGameState)
{
    CurrentGameState = NewGameState;
    CurrentGameState->Init(this);
}

void GameEngine::HandleEvents()
{
    CurrentGameState->HandleEvents(this);
    mSCursor.SetPosition(mWindow.GetInput().GetMouseX(), mWindow.GetInput().GetMouseY());
}

void GameEngine::Update()
{
    CurrentGameState->Update(this);
}

void GameEngine::Draw()
{
	mWindow.Clear(sf::Color(63, 72, 204, 255));
    CurrentGameState->Draw(this);
    mWindow.Draw(mSCursor);
    mWindow.Display();
}

void GameEngine::Run()
{
    while (mWindow.IsOpened())
    {
        HandleEvents();
        Update();
        Draw();
    }
}

void GameEngine::CleanUp()
{
    mClient.Close();
}
