#include "GSMenu.hpp"

int main()
{
    GameEngine Game;

    if (Game.Init())
    {
        Game.ChangeGameState(GSMenu::Instance());
        Game.Run();
        Game.CleanUp();
        return EXIT_SUCCESS;
    }
    else
    {
        return EXIT_FAILURE;
    }
}
