#ifndef __GAMEENGINE_HPP__
#define __GAMEENGINE_HPP__

#include <iostream>
#include <string>
#include <sstream>

#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Network.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>

class GameStates;

class GameEngine
{
    private:
        GameStates *CurrentGameState;

        sf::IPAddress mServerAddress;
        unsigned short mServerPort;
    public:
        sf::RenderWindow mWindow;
        sf::SocketTCP mClient;
        sf::Packet mPacket;
        
        sf::Image mICursor;
		sf::Image mIBG1;
		sf::Image mIBG2;
		sf::Image mIBG3_1;
		sf::Image mIBG3_2;
		sf::Image mIBG3_3;
		sf::Image mIBG4;
        sf::Image mIRadar;
        sf::Image mIMiss;
        sf::Image mIHit;
        sf::Image mIShip;

        sf::Sprite mSCursor;

		std::string Nickname;

        bool Init();

        void ChangeGameState(GameStates *NewGameState);

        void HandleEvents();
        void Update();
        void Draw();

        void Run();

        void CleanUp();
};

#endif
