#include "GSMenu.hpp"

#include "GSGame.hpp"

GSGame GSGame::mGSGame;

void GSGame::Init(GameEngine *Game)
{
	Menu = true;

	mSBG1_1.SetImage(Game->mIBG3_1);
	mSBG1_1.SetPosition(98.f, 98.f);

	mSBG1_2.SetImage(Game->mIBG3_2);
	mSBG1_2.SetPosition(438.f, 44.f);

	mSBG1_3.SetImage(Game->mIBG3_3);
	mSBG1_3.SetPosition(775.f, 155.f);

	mSBG2_1.SetImage(Game->mIBG4);
	mSBG2_1.SetPosition(0.f, 0.f);

	mSBG2_2.SetImage(Game->mIBG4);
	mSBG2_2.FlipX(true);
	mSBG2_2.SetPosition(540.f, 0.f);

	mSBG2_3.SetImage(Game->mIBG4);
	mSBG2_3.FlipY(true);
	mSBG2_3.SetPosition(0.f, 320.f);

	mSBG2_4.SetImage(Game->mIBG4);
	mSBG2_4.FlipX(true);
	mSBG2_4.FlipY(true);
	mSBG2_4.SetPosition(540.f, 320.f);

    mSRadar1.SetImage(Game->mIRadar);
    mSRadar1.SetCenter(250, 250);
    mSRadar1.SetPosition(290, 320);

    mSRadar2.SetImage(Game->mIRadar);
    mSRadar2.SetCenter(250, 250);
    mSRadar2.SetPosition(790, 320);

    mSMiss.SetImage(Game->mIMiss);
    mSHit.SetImage(Game->mIHit);
    mSShip.SetImage(Game->mIShip);

	Nickname.SetText(Game->Nickname);
	Nickname.SetCenter(Nickname.GetRect().GetWidth() / 2.f, Nickname.GetSize() / 2.f);
	Nickname.SetPosition(280.f, 45.f);

	SOrientation.SetPosition(240.f, 510.f);

	SSeite.SetText("Seite 0");
	SSeite.SetPosition(520.f, 0.f);
	Seite=0;

	for(int i=0; i<90; i+=10)
	{
		for(int j=1; j<11; j++)
		{
			SSpiel[i+j].SetPosition(103.f, 55.f+j*50.f);
			SSpiel[i+j].SetFont(sf::Font::GetDefaultFont());
			SSpiel[i+j].SetSize(32);
		}
	}

    PlaceShips = false;
    MyTurn = false;

	WinMessage.SetSize(48.f);
	WinMessage.SetFont(sf::Font::GetDefaultFont());
	WinMessage.SetPosition(540.f, 250.f);

	Message.SetSize(32.f);
	Message.SetFont(sf::Font::GetDefaultFont());
	Message.SetColor(sf::Color::Blue);
	Message.SetPosition(540.f, 575.f);

	Game->mPacket.Clear();
	Game->mPacket << Protocol::ReqMatchInfoList;
	Game->mClient.Send(Game->mPacket);
	Game->mPacket.Clear();
}

void GSGame::PlaceShip(unsigned char ShipID, unsigned char PosX, unsigned char PosY, unsigned char Orientation, sf::SocketTCP &Socket)
{
    sf::Packet Packet;
    Packet << Protocol::PlaceShip << ShipID << PosX << PosY << Orientation;
    Socket.Send(Packet);
}

void GSGame::DropBomb(unsigned char PosX, unsigned char PosY, sf::SocketTCP &Socket)
{
    sf::Packet Packet;
    Packet << Protocol::DropBomb << PosX << PosY;
    Socket.Send(Packet);
}

void GSGame::HandleEvents(GameEngine *Game)
{
    sf::Event Event;
    while (Game->mWindow.GetEvent(Event))
    {
        switch (Event.Type)
        {
            case sf::Event::Closed:
            {
				Game->mPacket.Clear();
				Game->mPacket << Protocol::Quit;
				Game->mClient.Send(Game->mPacket);
				Game->mPacket.Clear();
                Game->mWindow.Close();
                break;
            }
            case sf::Event::KeyPressed:
            {
                switch(Event.Key.Code)
                {
                    case sf::Key::Escape:
                    {
						Game->mPacket.Clear();
						Game->mPacket << Protocol::Quit;
						Game->mClient.Send(Game->mPacket);
						Game->mPacket.Clear();
						Game->mWindow.Close();
                        break;
                    }
					case sf::Key::A:
                    {
                        if (Orientation == 0)
						{
							Orientation = 1;
						}
						else
						{
							Orientation = 0;
						}
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }
            case sf::Event::MouseButtonPressed:
            {
                switch(Event.MouseButton.Button)
                {
                    case sf::Mouse::Left:
                    {
						if (Menu == true)
						{
							if (Game->mWindow.GetInput().GetMouseX() >= 443 && Game->mWindow.GetInput().GetMouseX() <= 568 && Game->mWindow.GetInput().GetMouseY() >= 49 && Game->mWindow.GetInput().GetMouseY() <= 92)
							{
								if (Seite == 0)
								{
									Seite = 2;
								}
								else
								{
									Seite -= 1;
								}
							}
							if (Game->mWindow.GetInput().GetMouseX() >= 571 && Game->mWindow.GetInput().GetMouseX() <= 696 && Game->mWindow.GetInput().GetMouseY() >= 49 && Game->mWindow.GetInput().GetMouseY() <= 92)
							{
								if (Seite == 2)
								{
									Seite = 0;
								}
								else
								{
									Seite += 1;
								}
							}
							for(int x=0; x<10; x++)
							{
								if (Game->mWindow.GetInput().GetMouseX() >= 103 && Game->mWindow.GetInput().GetMouseX() <= 696 && Game->mWindow.GetInput().GetMouseY() >= 103+x*50 && Game->mWindow.GetInput().GetMouseY() <= 153+x*50)
								{
									if (Spiel[Seite*10+x+1] != "")
									{
										Game->mPacket.Clear();
										Game->mPacket << Protocol::JoinMatch << Spiel[Seite*10+x+1];
										Game->mClient.Send(Game->mPacket);
										Game->mPacket.Clear();
										Gegner.SetText(Spiel[Seite*10+x+1]);
										Gegner.SetCenter(Gegner.GetRect().GetWidth() / 2.f, Gegner.GetSize() / 2.f);
										Gegner.SetPosition(790.f, 45.f);
									}
								}
							}
							if (Game->mWindow.GetInput().GetMouseX() >= 780 && Game->mWindow.GetInput().GetMouseX() <= 980 && Game->mWindow.GetInput().GetMouseY() >= 160 && Game->mWindow.GetInput().GetMouseY() <= 210)
							{
								Game->mPacket.Clear();
								Game->mPacket << Protocol::ReqMatchInfoList;
								Game->mClient.Send(Game->mPacket);
								Game->mPacket.Clear();
							}
							if (Game->mWindow.GetInput().GetMouseX() >= 780 && Game->mWindow.GetInput().GetMouseX() <= 980 && Game->mWindow.GetInput().GetMouseY() >= 220 && Game->mWindow.GetInput().GetMouseY() <= 270)
							{
								Game->mPacket.Clear();
								Game->mPacket << Protocol::CreateMatch;
								Game->mClient.Send(Game->mPacket);
								Game->mPacket.Clear();
							}
							if (Game->mWindow.GetInput().GetMouseX() >= 780 && Game->mWindow.GetInput().GetMouseX() <= 980 && Game->mWindow.GetInput().GetMouseY() >= 330 && Game->mWindow.GetInput().GetMouseY() <= 380)
							{
								Game->mPacket.Clear();
								Game->mPacket << Protocol::JoinRandomMatch;
								Game->mClient.Send(Game->mPacket);
								Game->mPacket.Clear();
							}
						}
						else
						{
							if (PlaceShips)
							{
								for(int j=145; j<145+FieldSize*35; j+=35)
								{
									for(int i=115; i<115+FieldSize*35; i+=35)
									{
										if (Game->mWindow.GetInput().GetMouseX() >= i && Game->mWindow.GetInput().GetMouseX() <= i+35 && Game->mWindow.GetInput().GetMouseY() >= j && Game->mWindow.GetInput().GetMouseY() <= j+35)
										{
											PlaceShip(ShipsLeft-1, (i-115)/35, (j-145)/35, Orientation, Game->mClient);
										}
									}
								}
							}

							if (MyTurn)
							{
								for(int j=145; j<145+FieldSize*35; j+=35)
								{
									for(int i=615; i<615+FieldSize*35; i+=35)
									{
										if (Game->mWindow.GetInput().GetMouseX() >= i && Game->mWindow.GetInput().GetMouseX() <= i+35 && Game->mWindow.GetInput().GetMouseY() >= j && Game->mWindow.GetInput().GetMouseY() <= j+35)
										{
											DropBomb((i-615)/35, (j-145)/35, Game->mClient);
										}
									}
								}
							}
						}
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }
            default:
            {
                break;
            }
        }
    }
}

void GSGame::Update(GameEngine *Game)
{
	if(Orientation == 0)
	{
		SOrientation.SetText("horizontal");
	}
	else
	{
		SOrientation.SetText("vertikal");
	}

	std::stringstream string;
	if (Menu == true)
	{
		string << "Seite ";
		string << Seite;
		SSeite.SetText(string.str());
		string.str("");
		string.clear();

		Game->mClient.Receive(Game->mPacket);
	}
	else
	{
		if (Rotation == -360)
		{
			Rotation = 0;
		}
		else
		{
			Rotation--;
		}
	}

	mSRadar1.SetRotation(Rotation);
	mSRadar2.SetRotation(Rotation);

    Game->mClient.Receive(Game->mPacket);

			int Code;
			Game->mPacket >> Code;
			switch(Code)
			{
				case Protocol::Welcome:
				{
					std::string Message;
					Game->mPacket >> Message >> FieldSize >> MaxShips;

                    std::cout << Message << " (" << static_cast<short>(FieldSize) << "x" << static_cast<short>(FieldSize) << " Felder, " << static_cast<short>(MaxShips) << " Schiffe)" << std::endl;
                    
                    ShipsLeft = MaxShips;
                    OurField.resize(FieldSize*FieldSize);
                    OpponentField.resize(FieldSize*FieldSize);

					std::cout << "Sende Benutzername..." << std::endl;

                    Game->mPacket.Clear();
                    Game->mPacket << Protocol::ChangeNickname << Game->Nickname;
                    Game->mClient.Send(Game->mPacket);
					Game->mPacket.Clear();
					break;
				}
				case Protocol::SystemMessage:
				{
					std::string Message;
					Game->mPacket >> Message;
					std::cout << Message << std::endl;
					Game->mPacket.Clear();
					break;
				}
				case Protocol::Error:
				{
					int Code;
                    std::string Message;
                    Game->mPacket >> Code >> Message;

                    switch (Code)
                    {
						case Protocol::Generic:
						{
							std::cout << "Allgemeiner Fehler" << std::endl;
							break;
						}
						case Protocol::BadMessage:
						{
							std::cout << "Fehlerhafte Nachricht, bitte nochmal versuchen." << std::endl;
							break;
						}
						case Protocol::NotAllowed:
						{
							std::cout << "Eine Aktion, die Administratoren vorbehalten ist" << std::endl;
							break;
						}
						case Protocol::WrongStatus:
						{
							std::cout << "Du befindest dich im falschen Zustand, um die geforderte Aktion durchzuf�hren" << std::endl;
							break;
						}
						case Protocol::CannotPlaceShip:
						{
							std::cout << "Setzen des Schiffes nicht moeglich (kollidiert mit anderem Schiff, falsche Koordinaten)" << std::endl;
							break;
						}
						case Protocol::NotYourTurn:
						{
							std::cout << "Du bist nicht am Zug." << std::endl;
							break;
						}
						case Protocol::AlreadyBombed:
						{
							std::cout << "Nochmal den selben Ort angreiffen?" << std::endl;
							break;
						}
						case Protocol::InvalidPosition:
						{
							std::cout << "Das Schiff kann nicht an dieser Position platziert werden." << std::endl;
							break;
						}
						case Protocol::UserlimitReached:
						{
							std::cout << "Der Server akzeptiert keine weiteren Clients mehr." << std::endl;
							break;
						}
						case Protocol::BadNickname:
						{
							std::cout << "Der Benutzername ist bereits vergeben." << std::endl;
							break;
						}
						case Protocol::MatchAlreadyStarted:
						{
							std::cout << "Das Spiel ist bereits gestartet." << std::endl;
							break;
						}
						default:
						{
							std::cout << "Error #" << Code << ": " << Message << std::endl;
							break;
						}
                    }
					Game->mPacket.Clear();
					break;
				}
				case Protocol::AuthSuccessful:
				{
					std::cout << "Authentifiziert" << std::endl;
					Game->mPacket.Clear();
					break;
				}
				case Protocol::MatchInfoList:
				{
					unsigned int amount;
					unsigned char open;
					std::string player1;
					std::string player2;

					Game->mPacket >> amount;

					string << amount;
					string << " Spiele gefunden";
					Spiele.SetText(string.str());
					string.str("");
					string.clear();

					for(unsigned int x=1; x<amount+1; x++)
					{
						string << x;
						Game->mPacket >> open;
						if (static_cast<short>(open) == 1)
						{
							Game->mPacket >> player1;
							SSpiel[x].SetText(string.str()+") "+player1+" [Offen]");
							SSpiel[x].SetColor(sf::Color::Green);
							Spiel[x] = player1;
						}
						else
						{
							Game->mPacket >> player1 >> player2;
							SSpiel[x].SetText(string.str()+") "+player1+" VS "+player2+" [Im Spiel]");
							SSpiel[x].SetColor(sf::Color::Red);
							Spiel[x] = "";
						}
						string.str("");
						string.clear();
					}

					for(int y=amount+1; y<32; y++)
					{
						SSpiel[y].SetText("");
						SSpiel[y].SetColor(sf::Color::Black);
						Spiel[y] = "";
					}

					Game->mPacket.Clear();
					break;
				}
				case Protocol::MatchJoined:
				{
					std::string Opponent;

                    Game->mPacket >> Opponent;

					Menu=false;

                    if (Opponent == "")
                    {
                        std::cout << "Warte auf einen Gegner..." << std::endl;
						Message.SetText("Warte auf einen Gegner...");
						Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);
                    }
                    else
                    {
						Gegner.SetText(Opponent);
						Gegner.SetCenter(Gegner.GetRect().GetWidth() / 2.f, Gegner.GetSize() / 2.f);
						Gegner.SetPosition(790.f, 45.f);
						Message.SetText("Platzieren wir schnell unsere Schiffe "+Game->Nickname+"!");
						Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);
						PlaceShips = true;
                    }

					Game->mPacket.Clear();
					break;
				}
				case Protocol::MatchLeft:
				{
					std::string Who;
                    
                    Game->mPacket >> Who;
                    
                    if(Who == "")
                    {
						Message.SetText("Das Spiel ist vorbei "+Game->Nickname+" , wir haben das Spiel verlassen.");
						Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);
                    }
                    else
                    {
						Message.SetText("Der Spieler "+Who+" hat das Spiel verlassen.");
						Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);
                    }

					Game->mPacket.Clear();
					break;
				}
				case Protocol::PlaceShip:
				{
					unsigned char ShipID, PosX, PosY, Orientation;

                    Game->mPacket >> ShipID >> PosX >> PosY >> Orientation;

					if (Orientation == 0)
					{
						std::cout << "Schiff " << static_cast<short>(ShipID) << " wurde horizontal an der Stelle [" << static_cast<short>(PosX) << "|" << static_cast<short>(PosY) << "] platziert." << std::endl;
					}
					else
					{
						std::cout << "Schiff " << static_cast<short>(ShipID) << " wurde vertikal an der Stelle [" << static_cast<short>(PosX) << "|" << static_cast<short>(PosY) << "] platziert." << std::endl;
					}

                    for (int s=0; s<static_cast<short>(ShipID)+2; s++)
                    {
                        if (static_cast<short>(Orientation)==0)
						{
							OurField[PosY*FieldSize+PosX+s] = Our::Ship;
						}
						else
						{
							OurField[(PosY+s)*FieldSize+PosX] = Our::Ship;
						}
                    }
                    
					--ShipsLeft;
		                    
					if (ShipsLeft == 0)
					{
						Message.SetText("Wir haben alle Schiffe platziert, warte auf Server...");
						Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);
					}
					else
					{
						std::cout << "Wir muessen noch " << static_cast<short>(ShipsLeft) << " Schiffe platzieren." << std::endl;
						Message.SetText("Wir muessen noch weitere Schiffe platzieren.");
						Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);
					}

					Game->mPacket.Clear();
					break;
				}
				case Protocol::PlacementComplete:
				{
					PlaceShips = false;
					Message.SetText("Alle Schiffe wurden korrekt platziert. Warte auf Gegner...");
					Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);
					Game->mPacket.Clear();
					break;
				}
				case Protocol::GameStarts:
				{
					Message.SetText("Warte bis wir an der Reihe sind...");
					Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);
					Game->mPacket.Clear();
					break;
				}
				case Protocol::YourTurn:
				{
					MyTurn = true;
					Message.SetText("Wir sind am Zug. "+Game->Nickname+" wo sollen wir angreiffen?");
					Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);
					Game->mPacket.Clear();
					break;
				}
				case Protocol::YourTurnEnded:
				{
					MyTurn = false;
					Message.SetText("Wir sind fertig mit unserem Zug. Unser Gegner ist am Zug...");
					Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);
					Game->mPacket.Clear();
					break;
				}
				case Protocol::BombHit:
				{
					if(MyTurn)
					{
						std::cout << Game->Nickname << ", wir haben ein feindliches Schiff getroffen! :-)" << std::endl;

						unsigned char  PosX, PosY;
						Game->mPacket >> PosX >> PosY;
						OpponentField[PosY*FieldSize+PosX] = Opponent::Hit;
					}
					else
					{
						std::cout << Game->Nickname << ", eines unserer Schiffe wurde getroffen! :-(" << std::endl;
						Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);

						unsigned char  PosX, PosY;
						Game->mPacket >> PosX >> PosY;
						OurField[PosY*FieldSize+PosX] = Our::Hit;
					}

					Game->mPacket.Clear();
					break;
				}
				case Protocol::BombMissed:
				{
					if(MyTurn)
					{
						std::cout << Game->Nickname << ", wir haben daneben getroffen. :-(" << std::endl;
						Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);

						unsigned char  PosX, PosY;
						Game->mPacket >> PosX >> PosY;
						OpponentField[PosY*FieldSize+PosX] = Opponent::Miss;
					}
					else
					{
						std::cout << Game->Nickname << ", unser Gegner schoss daneben. :-)" << std::endl;
						Message.SetCenter(Message.GetRect().GetWidth() / 2.f, Message.GetSize() / 2.f);

						unsigned char  PosX, PosY;
						Game->mPacket >> PosX >> PosY;
						OurField[PosY*FieldSize+PosX] = Our::Miss;
					}

					Game->mPacket.Clear();
					break;
				}
				case Protocol::YouWin:
				{
					WinMessage.SetText("GEWONNEN! "+Game->Nickname+", sie sind der Beste. :-)");
					WinMessage.SetColor(sf::Color::Cyan);
					WinMessage.SetCenter(WinMessage.GetRect().GetWidth() / 2.f, WinMessage.GetSize() / 2.f);
					MyTurn = false;
					Game->mPacket.Clear();
					break;
				}
				case Protocol::YouLose:
				{
					WinMessage.SetText("VERLOREN! Vielleicht beim naechsten Mal. :-(");
					WinMessage.SetColor(sf::Color::Red);
					WinMessage.SetCenter(WinMessage.GetRect().GetWidth() / 2.f, WinMessage.GetSize() / 2.f);
					MyTurn = false;
					Game->mPacket.Clear();
					break;
				}
				default:
				{
					break;
				}
			}
    Game->mPacket.Clear();
}

void GSGame::Draw(GameEngine *Game)
{
	if (Menu == true)
	{
		Game->mWindow.Draw(mSBG1_1);
		Game->mWindow.Draw(mSBG1_2);
		Game->mWindow.Draw(mSBG1_3);
		Game->mWindow.Draw(Spiele);
		Game->mWindow.Draw(SSeite);
		for(int k=1; k<11; k++)
		{
			Game->mWindow.Draw(SSpiel[Seite*10+k]);
		}
	}
	else
	{
		Game->mWindow.Draw(mSBG2_1);
		Game->mWindow.Draw(mSBG2_2);
		Game->mWindow.Draw(mSBG2_3);
		Game->mWindow.Draw(mSBG2_4);

		for(int j=0; j<FieldSize; j++)
		{
			for(int i=0; i<FieldSize; i++)
			{
				if (OurField.at(j*FieldSize+i) == Our::Miss)
				{
					mSMiss.SetPosition(115.f+i*35.f, 145.f+j*35.f);
					Game->mWindow.Draw(mSMiss);
				}
				else if (OurField.at(j*FieldSize+i) == Our::Hit)
				{
					mSHit.SetPosition(115.f+i*35.f, 145.f+j*35.f);
					Game->mWindow.Draw(mSHit);
				}
				else if (OurField.at(j*FieldSize+i) == Our::Ship)
				{
					mSShip.SetPosition(115.f+i*35.f, 145.f+j*35.f);
					Game->mWindow.Draw(mSShip);
				}
			}
		}

		for(int j=0; j<FieldSize; j++)
		{
			for(int i=0; i<FieldSize; i++)
			{
				if (OpponentField.at(j*FieldSize+i) == Opponent::Miss)
				{
					mSMiss.SetPosition(615.f+i*35.f, 145.f+j*35.f);
					Game->mWindow.Draw(mSMiss);
				}
				else if (OpponentField.at(j*FieldSize+i) == Opponent::Hit)
				{
					mSHit.SetPosition(615.f+i*35.f, 145.f+j*35.f);
					Game->mWindow.Draw(mSHit);
				}
			}
		}

		Game->mWindow.Draw(mSRadar1);
		Game->mWindow.Draw(mSRadar2);
		Game->mWindow.Draw(WinMessage);
		Game->mWindow.Draw(Message);
		Game->mWindow.Draw(Nickname);
		Game->mWindow.Draw(Gegner);
		if(PlaceShips == true)
		{
			Game->mWindow.Draw(SOrientation);
		}
	}
}
