#ifndef __GSGAME_HPP__
#define __GSGAME_HPP__

namespace Protocol
{
	enum MessageId
	{
		First = 0,
		Welcome,
		SystemMessage,
		Error,
		Quit,

		AuthSuccessful,
		ChangeNickname,

		ReqMatchInfoList,
		MatchInfoList,

		CreateMatch,
		JoinMatch,
		JoinRandomMatch,
		LeaveMatch,
		MatchJoined,
		MatchLeft,

		YourTurn,
		YourTurnEnded,
		PlaceShip,
		PlacementComplete,
		GameStarts,

		DropBomb,
		BombHit,
		BombMissed,

		YouWin,
		YouLose,

		Shutdown,

		Last
	};

    enum ErrorCode
	{
		Generic = 0,
		BadMessage,
		NotAllowed,
		WrongStatus,
		CannotPlaceShip,
		NotYourTurn,
		AlreadyBombed,
		InvalidPosition,
		UserlimitReached,
		BadNickname,
		MatchAlreadyStarted
	};
}

namespace Our
{
    enum FieldStatus
    {
        Free = 0,
        Miss,
        Hit,
        Ship
    };
}

namespace Opponent
{
    enum FieldStatus
    {
        Free = 0,
        Miss,
        Hit
    };
}

#include "GameStates.hpp"

class GSGame : public GameStates
{
    private:
        static GSGame mGSGame;
    public:
		bool Menu;
		
		sf::String Spiele;
		sf::String SSeite;
		sf::String SSpiel[89];
		std::string Spiel[89];
		int Seite;

		sf::String WinMessage;
		sf::String Message;
		sf::String Nickname;
		sf::String Gegner;
		sf::String SOrientation;

		sf::Sprite mSBG1_1;
		sf::Sprite mSBG1_2;
		sf::Sprite mSBG1_3;

		sf::Sprite mSBG2_1;
		sf::Sprite mSBG2_2;
		sf::Sprite mSBG2_3;
		sf::Sprite mSBG2_4;

        sf::Sprite mSRadar1;
        sf::Sprite mSRadar2;

        sf::Sprite mSMiss;
        sf::Sprite mSHit;
        sf::Sprite mSShip;

        float Rotation;

        std::vector<Our::FieldStatus> OurField;
        std::vector<Opponent::FieldStatus> OpponentField;
        unsigned char FieldSize;
		unsigned char MaxShips;
		unsigned char ShipsLeft;
        bool PlaceShips;
		int Orientation;
		bool MyTurn;
        
        void Init(GameEngine *Game);

        void PlaceShip(unsigned char ShipID, unsigned char PosX, unsigned char PosY, unsigned char Orientation, sf::SocketTCP &Socket);
        void DropBomb(unsigned char PosX, unsigned char PosY, sf::SocketTCP &Socket);

        void HandleEvents(GameEngine *Game);
        void Update(GameEngine *Game);
        void Draw(GameEngine *Game);

        static GSGame *Instance()
        {
            return &mGSGame;
        }
    protected:
        GSGame() {}
};

#endif
