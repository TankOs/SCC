#ifndef __GAMESTATES_HPP__
#define __GAMESTATES_HPP__

#include "GameEngine.hpp"

class GameStates
{
    public:
        virtual void Init(GameEngine *Game) = 0;

        virtual void HandleEvents(GameEngine *Game) = 0;
        virtual void Update(GameEngine *Game) = 0;
        virtual void Draw(GameEngine *Game) = 0;

        void ChangeGameState(GameEngine *Game, GameStates *NewGameState)
        {
            Game->ChangeGameState(NewGameState);
        }
    protected:
        GameStates() {}
};

#endif
