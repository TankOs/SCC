#include "GSMenu.hpp"

#include "GSMName.hpp"

GSMName GSMName::mGSMName;

void GSMName::Init(GameEngine *Game)
{
	mSBG.SetImage(Game->mIBG2);
	mSBG.SetPosition(255.f, 170.f);

	mSNickname.SetFont(sf::Font::GetDefaultFont());
	mSNickname.SetColor(sf::Color::Blue);
	mSNickname.SetSize(40.f);

	TextEntered = Game->Nickname;
	LegalCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_()[]";
	MaxLength = 16;
}

void GSMName::HandleEvents(GameEngine *Game)
{
	sf::Event Event;
    while (Game->mWindow.GetEvent(Event))
    {
        switch (Event.Type)
        {
            case sf::Event::Closed:
            {
                Game->mWindow.Close();
                break;
            }
            case sf::Event::KeyPressed:
            {
                switch(Event.Key.Code)
                {
                    case sf::Key::Escape:
                    {
                        Game->mWindow.Close();
                        break;
                    }
					case sf::Key::Back:
					{
						if (!TextEntered.empty())
						{
							TextEntered.erase(TextEntered.end() - 1);
						}
						break;
					}
					case sf::Key::Return:
					{
						if (!TextEntered.empty())
						{
							TextEntered.clear();
						}
						break;
					}
                    default:
                    {
                        break;
                    }
                }
                break;
            }
			case sf::Event::TextEntered:
			{
				if (TextEntered.size() != MaxLength)
				{
					sf::Unicode::Text character(&Event.Text.Unicode);
					std::string::size_type Index = LegalCharacters.find_first_of(character);
					if(Index != LegalCharacters.npos)
					{
						TextEntered.append(LegalCharacters.substr(Index, 1));
					}
				}
				break;
			}
            case sf::Event::MouseButtonPressed:
            {
                switch(Event.MouseButton.Button)
                {
                    case sf::Mouse::Left:
                    {
						if (Game->mWindow.GetInput().GetMouseX() >= 440 && Game->mWindow.GetInput().GetMouseX() <= 640 && Game->mWindow.GetInput().GetMouseY() >= 300 && Game->mWindow.GetInput().GetMouseY() <= 350)
                        {
							Game->Nickname = TextEntered;
							Game->ChangeGameState(GSMenu::Instance());
						}
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }
            default:
            {
                break;
            }
        }
    }
}

void GSMName::Update(GameEngine *Game)
{
	mSNickname.SetText(TextEntered);
	mSNickname.SetCenter(mSNickname.GetRect().GetWidth() / 2.f, mSNickname.GetSize() / 2.f);
	mSNickname.SetPosition(540.f, 220);
}

void GSMName::Draw(GameEngine *Game)
{
	Game->mWindow.Draw(mSBG);
	Game->mWindow.Draw(mSNickname);
}
