.::Steurung::.
Haupts�chlich mit der Maus.
Wenn man die Schiffe plaziert kann man mit der Taste A die SChiffe horizontal/vertikal stellen.