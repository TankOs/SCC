#include <iostream>
#include <sstream>
#include <algorithm>
#include <set>
#include <ctime>
#include "peer.hpp"
#include "protocol.hpp"
#include "shipsserver.hpp"

ShipsServer::ShipsServer() :
	m_protocol( *this )
{
	std::srand( std::time( 0 ) );
}

bool ShipsServer::Start( const std::string &config ) {
	if( m_listener.IsValid() ) {
		return false;
	}

	if( !m_config.Load( config ) ) {
		return false;
	}

	if( !m_listener.Listen( m_config.GetInt( "port" ) ) ) {
		return false;
	}

	// Prepare selector.
	unsigned int     readyamount;

	m_selector.Add( m_listener );

	// Mainloop.
	while( (readyamount = m_selector.Wait()) ) {
		for( unsigned int socketid = 0; socketid < readyamount; ++socketid ) {
			sf::SocketTCP  readysocket( m_selector.GetSocketReady( socketid ) );

			// Something happened on the listener socket.
			if( readysocket == m_listener ) {
				sf::IPAddress  ipaddr;
				sf::SocketTCP  tmp;

				m_listener.Accept( tmp, &ipaddr );
				std::cout << "Client connected from " << ipaddr.ToString() << "." << std::endl;

				// Check if userlimit is reached.
				if( m_peers.size() >= static_cast<std::size_t>( m_config.GetInt( "userlimit" ) ) ) {
					std::cout << "Dropping " << ipaddr.ToString() << ", userlimit reached." << std::endl;
					Protocol::SendErrorMessage( tmp, Protocol::UserlimitReached, "Userlimit is reached, try again later." );
					tmp.Close();
					continue;
				}

				// Since we're using a selector for checking if a socket gets ready to receive data,
				// we set all peer sockets to non-blocking.
				tmp.SetBlocking( false );

				// Create new Peer and add to Peers list.
				m_peers[tmp] = new Peer( m_config.GetInt( "fieldsize" ), m_config.GetInt( "maxships" ), tmp, ipaddr );

				// Add socket to selector.
				m_selector.Add( tmp );

				// Send the new client the ultimate welcome message! :-)
				Protocol::SendWelcomeMessage( m_peers[tmp]->GetSocket(), m_config.GetString( "welcome" ), m_config.GetInt( "fieldsize" ), m_config.GetInt( "maxships" ) );
			}
			else {
				PeerList::iterator  iter( m_peers.find( readysocket ) );

				if( iter == m_peers.end() ) {
					std::cout << "FATAL ERROR: Socket got ready that isn't mapped!" << std::endl;
					m_selector.Remove( readysocket );
					readysocket.Close();
					continue;
				}

				// Receive data.
				sf::Packet          rpkt;
				sf::Socket::Status  status( iter->second->GetSocket().Receive( rpkt ) );

				if( status == sf::Socket::Disconnected ) {
					DisconnectPeer( *iter->second );
				}
				else if( status == sf::Socket::Done ) {
					m_protocol.ParsePacket( rpkt, iter->second->GetSocket() );
				}
			}
		}
	}

	Stop();

	return true;
}

void ShipsServer::Stop() {
	m_peermap.clear();

	std::cout << "Server shutdown initiated..." << std::endl;

	for( PeerList::iterator iter = m_peers.begin(); iter != m_peers.end(); ++iter ) {
		std::cout << "Disconnecting client " << iter->second->GetIP().ToString() << "..." << std::endl;
		iter->second->GetSocket().Close();
		delete iter->second;
	}

	m_peers.clear();
	m_listener.Close();
	m_selector.Clear();
}

void ShipsServer::UnlinkMatch( Peer &peer, bool notifypeer ) {
	// Get linked match.
	PeerMap::iterator  piter( m_peermap.find( &peer ) );

	if( piter != m_peermap.end() ) { // Match assigned?
		m_peermap.erase( piter );

		Peer               *opponent( piter->second );
		PeerMap::iterator  p2iter( m_peermap.find( opponent ) );

		if( p2iter != m_peermap.end() ) {
			m_peermap.erase( p2iter );
		}

		if( notifypeer ) {
			Protocol::SendMatchLeftMessage( peer.GetSocket() );
		}

		peer.SetStatus( Peer::Auth );

		if( opponent != 0 ) {
			Protocol::SendMatchLeftMessage( opponent->GetSocket(), peer.GetName() );
			opponent->SetStatus( Peer::Auth );
		}
	}
}

void ShipsServer::DisconnectPeer( Peer &peer ) {
	PeerList::iterator   liter( m_peers.find( peer.GetSocket() ) );

	// Remove peer from selector.
	m_selector.Remove( peer.GetSocket() );

	// Unlink match.
	UnlinkMatch( peer, false );

	peer.GetSocket().Close();

	std::cout << liter->second->GetIP() << ": Disconnected." << std::endl;

	if( liter != m_peers.end() ) {
		delete liter->second;
		m_peers.erase( liter );
	}
}

bool ShipsServer::OnMessage( sf::SocketTCP &peer ) {
	PeerList::iterator  iter( m_peers.find( peer ) );

	if( iter == m_peers.end() ) {
		m_lastpeer = 0;
		return false;
	}

	m_lastpeer = iter->second;
	return true;
}

void ShipsServer::OnInvalidPacketMessage() {
	Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::BadMessage, "You sent a malformed message." );
}

void ShipsServer::OnNicknameMessage( const std::string &nickname ) {
	if( m_lastpeer->GetStatus() == Peer::Preauth ) {
		if( !IsNicknameValid( nickname ) ) {
			Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::BadNickname, "You sent a bad nickname." );
			return;
		}

		Protocol::SendAuthSuccessfulMessage( m_lastpeer->GetSocket() );
		m_lastpeer->SetStatus( Peer::Auth );
		m_lastpeer->SetName( nickname );
		std::cout << m_lastpeer->GetIP() << "/" << nickname << ": Authenticated." << std::endl;
	}
	else {
		Protocol::SendSystemMessage( m_lastpeer->GetSocket(), "Nickname changes not allowed." );
	}
}

void ShipsServer::OnReqMatchInfoListMessage() {
	std::vector<Protocol::Match>  matches;

	PeerMap::iterator  iter( m_peermap.begin() );
	std::set<Peer*>    alreadysent;

	for( ; iter != m_peermap.end(); ++iter ) {
		if( alreadysent.find( iter->second ) != alreadysent.end() ) {
			continue;
		}

		Protocol::Match  match;
		match.open = (iter->second == 0);
		match.player1 = iter->first->GetName();
		
		if( !match.open ) {
			match.player2 = iter->second->GetName();
		}

		matches.push_back( match );
		alreadysent.insert( iter->first );
	}

	Protocol::SendMatchInfoListMessage( m_lastpeer->GetSocket(), matches );
}

void ShipsServer::OnCreateMatchMessage() {
	if( m_lastpeer->GetStatus() != Peer::Auth ) {
		Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::WrongStatus, "You must be authenticated and NOT be in a match." );
		return;
	}

	m_peermap[m_lastpeer] = 0;
	m_lastpeer->SetStatus( Peer::Waiting );
	Protocol::SendMatchJoinedMessage( m_lastpeer->GetSocket() );
}

void ShipsServer::OnShutdownMessage( const std::string &password ) {
	if( password != m_config.GetString( "adminpassword" ) ) {
		Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::NotAllowed, "You're not allowed to do that (wrong password?)." );
		std::cout << m_lastpeer->GetIP() << "/" << m_lastpeer->GetName() << ": Tried SHUTDOWN!" << std::endl;
	}
	else {
		std::cout << m_lastpeer->GetIP() << ": Received SHUTDOWN command!" << std::endl;
		Stop();
	}
}

void ShipsServer::OnJoinRandomMatchMessage() {
	if( m_lastpeer->GetStatus() != Peer::Auth ) {
		Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::WrongStatus, "You must be authenticated and NOT be in a match." );
		return;
	}

	std::vector<PeerMap::iterator>  openmatches;
	PeerMap::iterator               iter( m_peermap.begin() );

	for( ; iter != m_peermap.end(); ++iter ) {
		if( iter->second == 0 ) {
			openmatches.push_back( iter );
		}
	}

	if( openmatches.size() == 0 ) {
		OnCreateMatchMessage();
		return;
	}

	std::size_t  matchid( std::rand() % openmatches.size() );

	StartMatch( *openmatches[matchid]->first, *m_lastpeer );
}

void ShipsServer::StartMatch( Peer &first, Peer &second ) {
	m_peermap[&first]  = &second;
	m_peermap[&second] = &first;

	first.Clear();
	first.SetTurn( true );
	first.SetStatus( Peer::ShipPlacement );
	second.Clear();
	second.SetTurn( false );
	second.SetStatus( Peer::ShipPlacement );

	Protocol::SendMatchJoinedMessage( first.GetSocket(), second.GetName() );
	Protocol::SendMatchJoinedMessage( second.GetSocket(), first.GetName() );
}

void ShipsServer::OnPlaceShipMessage( unsigned char shipid, unsigned char x, unsigned char y, bool vertical ) {
	if( m_lastpeer->GetStatus() != Peer::ShipPlacement ) {
		Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::WrongStatus, "You're not allowed to place ships in your current state." );
		return;
	}

	if( m_lastpeer->PlaceShip( shipid, x, y, vertical ) == false ) {
		Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::CannotPlaceShip, "Ship can't be placed." );
		return;
	}

	// Success, "read back" ship placement message to client as notification of success.
	Protocol::SendPlaceShipMessage( m_lastpeer->GetSocket(), shipid, x, y, vertical ? 1 : 0 );

	// Check if player has completed placing his ships.
	if( m_lastpeer->IsComplete() ) {
		Protocol::SendPlacementCompleteMessage( m_lastpeer->GetSocket() );

		// Check if opponent has already placed all ships. If so, it's time to start the game.
		PeerMap::iterator  iter( m_peermap.find( m_lastpeer ) );
		if( iter == m_peermap.end() ) { // Really shouldn't happen!!!
			std::cout << "FATAL ERROR/game start: No match assigned to peer " << m_lastpeer->GetIP() << "!!!" << std::endl;
			return;
		}

		if( iter->second->IsComplete() ) {
			Protocol::SendGameStartsMessage( iter->first->GetSocket() );
			Protocol::SendGameStartsMessage( iter->second->GetSocket() );
			Protocol::SendYourTurnMessage( (iter->first->IsHisTurn() ? iter->first : iter->second)->GetSocket() );

			iter->first->SetStatus( Peer::Playing );
			iter->second->SetStatus( Peer::Playing );
		}
	}

}

void ShipsServer::OnLeaveMatchMessage() {
	if( m_lastpeer->GetStatus() < Peer::Waiting ) {
		Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::WrongStatus, "You must be in a match to be able to leave it." );
		return;
	}

	UnlinkMatch( *m_lastpeer );
}

void ShipsServer::OnDropBombMessage( unsigned char x, unsigned char y ) {
	if( m_lastpeer->GetStatus() != Peer::Playing ) {
		Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::WrongStatus, "You must be playing a match to drop bombs." );
		return;
	}

	if( m_lastpeer->IsHisTurn() != true ) {
		Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::NotYourTurn, "Please wait for your turn." );
		return;
	}

	PeerMap::iterator  iter( m_peermap.find( m_lastpeer ) );
	if( iter == m_peermap.end() ) { // Really shouldn't happen!!!
		std::cout << "FATAL ERROR/bomb drop: No match assigned to peer " << m_lastpeer->GetIP() << "!!!" << std::endl;
		return;
	}

	Peer::BombResult  result( iter->second->DropBomb( x, y ) );
	bool              changeturn( false );
	
	if( result == Peer::InvalidPosition ) {
		Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::InvalidPosition, "Invalid position for bomb." );
	}
	else if( result == Peer::AlreadyBombed ) {
		Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::AlreadyBombed, "You've already bombed that cell." );
	}
	else if( result == Peer::Hit ) {
		changeturn = true;

		Protocol::SendBombHitMessage( m_lastpeer->GetSocket(), x, y );
		Protocol::SendBombHitMessage( iter->second->GetSocket(), x, y );

		if( iter->second->IsKilled() ) { // Game over.
			Protocol::SendYouWinMessage( m_lastpeer->GetSocket() );
			Protocol::SendYouLoseMessage( iter->second->GetSocket() );

			m_lastpeer->Clear();
			iter->second->Clear();

			UnlinkMatch( *m_lastpeer );
			return;
		}
	}
	else if( result == Peer::Miss ) {
		Protocol::SendBombMissedMessage( m_lastpeer->GetSocket(), x, y );
		Protocol::SendBombMissedMessage( iter->second->GetSocket(), x, y );
		changeturn = true;
	}

	if( changeturn ) {
		m_lastpeer->SetTurn( false );
		iter->second->SetTurn( true );
		Protocol::SendYourTurnEndedMessage( m_lastpeer->GetSocket() );
		Protocol::SendYourTurnMessage( iter->second->GetSocket() );
	}
}

void ShipsServer::OnQuitMessage() {
	DisconnectPeer( *m_lastpeer );
}

void ShipsServer::OnJoinMatchMessage( const std::string &opponent ) {
	if( m_lastpeer->GetStatus() != Peer::Auth ) {
		Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::WrongStatus, "You aren't allowed to join a match in your current state." );
		return;
	}

	PeerMap::iterator  iter( m_peermap.begin() );

	for( ; iter != m_peermap.end(); ++iter ) {
		if( iter->first->GetName() == opponent ) {
			if( iter->second != 0 ) {
				Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::MatchAlreadyStarted, "Match has already been started." );
				return;
			}

			StartMatch( *iter->first, *m_lastpeer );
			return;
		}
	}

	Protocol::SendErrorMessage( m_lastpeer->GetSocket(), Protocol::BadNickname, "The wanted user hasn't started a match." );
}

bool ShipsServer::IsNicknameValid( const std::string &nickname ) {
	PeerList::iterator  iter( m_peers.begin() );
	std::string         validchars( m_config.GetString( "nicknamechars" ) );

	if( nickname.empty() || nickname.size() > static_cast<std::size_t>( m_config.GetInt( "maxnicknamelength" ) ) ) {
		return false;
	}

	for( std::size_t chid = 0; chid < nickname.size(); ++chid ) {
		if( validchars.find( nickname[chid] ) == std::string::npos ) {
			return false;
		}
	}

	for( ; iter != m_peers.end(); ++iter ) {
		if( iter->second->GetName() == nickname ) {
			return false;
		}
	}

	return true;
}
