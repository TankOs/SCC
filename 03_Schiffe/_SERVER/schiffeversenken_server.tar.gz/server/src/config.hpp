#ifndef __CONFIG_HPP__
#define __CONFIG_HPP__

#include <string>
#include <map>

class Config {
	public:
		bool Load( const std::string &filename );

		const std::string GetString( const std::string &key );
		int GetInt( const std::string &key );

	private:
		typedef std::map<const std::string, std::string>  ConfigMap;

		ConfigMap  m_values;
};

#endif
