#include <SFML/Network.hpp>
#include "messagehandler.hpp"

bool MessageHandler::OnMessage( sf::SocketTCP & ) {
	return true;
}
