#include <SFML/Network.hpp>
#include <iostream>
#include "protocol.hpp"
#include "peer.hpp"

Peer::Peer( unsigned char fieldsize, unsigned char maxships, const sf::SocketTCP &socket, const sf::IPAddress &ip ) :
	m_socket( socket ),
	m_ip( ip ),
	m_shipfieldsleft( 0 ),
	m_status( Preauth ),
	m_turn( false ),
	m_fieldsize( fieldsize ),
	m_maxships( maxships )
{
	Clear();
}

void Peer::Clear() {
	m_field.clear();
	m_field.resize( m_fieldsize * m_fieldsize );

	for( unsigned int y = 0; y < m_fieldsize; ++y ) {
		for( unsigned int x = 0; x < m_fieldsize; ++x ) {
			m_field[y * m_fieldsize + x] = Free;
		}
	}

	m_shipplaced.clear();
	m_shipplaced.resize( m_maxships );

	for( unsigned int shipid = 0; shipid < m_maxships; ++shipid ) {
		m_shipplaced[shipid] = false;
	}

	m_shipfieldsleft = 0;
}

bool Peer::PlaceShip( unsigned char shipid, unsigned char x, unsigned char y, bool vertical ) {
	unsigned char  length( shipid + 2 );

	// Check valid ship ID and if ship hasn't been placed before. Also check coords.
	if( shipid >= m_maxships || m_shipplaced[shipid] == true || x >= m_fieldsize || y >= m_fieldsize ) {
		return false;
	}

	// Check boundary.
	if( (vertical == false && x + length > m_fieldsize) || (vertical == true && y + length > m_fieldsize) ) {
		return false;
	}

	// Check if new ship would collide with previous ships, at first.
	unsigned char  startpos( vertical ? y : x );
	unsigned char  boundary( (vertical ? y : x) + length );

	for( unsigned char pos = startpos; pos < boundary; ++pos ) {
		if( m_field[(vertical ? pos : y) * m_fieldsize + (vertical ? x : pos)] != Free ) {
			return false;
		}
	}

	// Place ship.
	for( unsigned char pos = startpos; pos < boundary; ++pos ) {
		m_field[(vertical ? pos : y) * m_fieldsize + (vertical ? x : pos)] = Ship;
	}

	m_shipplaced[shipid] = true;

	// Adjust amount of ship fields.
	m_shipfieldsleft += length;

	/*for( unsigned char ypos = 0; ypos < m_fieldsize; ++ypos ) {
		for( unsigned char xpos = 0; xpos < m_fieldsize; ++xpos ) {
			std::cout << (m_field[ypos * m_fieldsize + xpos] != Ship ? ". " : "X ");
		}

		std::cout << std::endl;
	}*/

	return true;
}

Peer::BombResult Peer::DropBomb( unsigned char x, unsigned char y ) {
	if( x >= m_fieldsize || y >= m_fieldsize ) {
		return InvalidPosition;
	}

	if( m_field[y * m_fieldsize + x] == Ship ) {
		m_field[y * m_fieldsize + x] = Destroyed;
		--m_shipfieldsleft;
		return Hit;
	}
	else if( m_field[y * m_fieldsize + x] != Free ) {
		return AlreadyBombed;
	}

	m_field[y * m_fieldsize + x] = Missed;
	return Miss;
}

bool Peer::IsComplete() const {
	for( unsigned char shipid = 0; shipid < m_maxships; ++shipid ) {
		if( m_shipplaced[shipid] == false ) {
			return false;
		}
	}

	return true;
}

const std::string &Peer::GetName() const {
	return m_name;
}

void Peer::SetName( const std::string &name ) {
	m_name = name;
}

sf::SocketTCP &Peer::GetSocket() {
	return m_socket;
}

const sf::IPAddress &Peer::GetIP() const {
	return m_ip;
}

Peer::Status Peer::GetStatus() {
	return m_status;
}

void Peer::SetStatus( Status newstatus ) {
	m_status = newstatus;
}

bool Peer::operator==( const Peer &other ) {
	return m_socket == other.m_socket;
}

bool Peer::operator<( const Peer &other ) {
	return m_socket < other.m_socket;
}

bool Peer::operator==( const sf::SocketTCP &other ) {
	return m_socket == other;
}

bool Peer::operator<( const sf::SocketTCP &other ) {
	return m_socket < other;
}

void Peer::SetTurn( bool turn ) {
	m_turn = turn;
}

bool Peer::IsHisTurn() {
	return m_turn;
}

bool Peer::IsKilled() const {
	return m_shipfieldsleft == 0;
}
