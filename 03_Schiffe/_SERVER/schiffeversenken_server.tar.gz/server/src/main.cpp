#include <iostream>
#include "shipsserver.hpp"

int main( void ) {
	ShipsServer  server;

	if( !server.Start( "config.cfg" ) ) {
		std::cout << "Failed to start server!" << std::endl;
	}

	return 0;
}
