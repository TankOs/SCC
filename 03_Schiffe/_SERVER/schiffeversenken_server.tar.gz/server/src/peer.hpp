#ifndef __PEER_HPP__
#define __PEER_HPP__

#include <SFML/Network.hpp>
#include <string>
#include "settings.hpp"

enum FieldStatus { // TODO: Goes to class Field.
	Free = 0,
	Ship = 1,
	Destroyed = 2,
	Missed = 3
};

class Peer {
	public:
		enum Status {
			Preauth = 0,
			Auth,
			Waiting,
			ShipPlacement,
			Playing
		};

		enum BombResult { // TODO: Goes to class Field.
			InvalidPosition = 0,
			AlreadyBombed,
			Hit,
			Miss
		};

		Peer( unsigned char fieldsize, unsigned char maxships, const sf::SocketTCP &socket, const sf::IPAddress &ip );

		void Clear(); // TODO: Goes to class Field.

		bool PlaceShip( unsigned char shipid, unsigned char x, unsigned char y, bool vertical ); // TODO: Goes to class Field.
		BombResult DropBomb( unsigned char x, unsigned char y ); // TODO: Goes to class Field.

		bool IsComplete() const; // TODO: Goes to class Field.
		bool IsKilled() const; // TODO: Goes to class Field.

		void SetName( const std::string &name );
		const std::string &GetName() const;

		sf::SocketTCP &GetSocket();
		const sf::IPAddress &GetIP() const;

		void SetStatus( Status newstatus );
		Status GetStatus();

		void SetTurn( bool turn );
		bool IsHisTurn();

		bool operator==( const Peer &other );
		bool operator<( const Peer &other );

		bool operator==( const sf::SocketTCP &other );
		bool operator<( const sf::SocketTCP &other );

	private:
		sf::SocketTCP  m_socket;
		sf::IPAddress  m_ip;

		unsigned char               m_shipfieldsleft; // TODO: Goes to class Field.
		std::vector<bool>           m_shipplaced; // TODO: Goes to class Field.
		std::vector<unsigned char>  m_field; // TODO: Goes to class Field.

		std::string  m_name;
		Status       m_status;
		bool         m_turn;

		unsigned char  m_fieldsize; // TODO: Goes to class Field.
		unsigned char  m_maxships; // TODO: Goes to class Field.
};

#endif
