#ifndef __PROTOCOL_HPP__
#define __PROTOCOL_HPP__

#include <string>
#include <vector>

namespace sf {
	class Packet;
	class SocketTCP;
}

class MessageHandler;

class Protocol {
	public:
		enum MessageId {
			First = 0,
			Welcome,              // s:msg i:fieldsize i:maxships
			SystemMessage,        // s:msg
			Error,                // i:code s:msg
			Quit,

			AuthSuccessful,
			ChangeNickname,       // s:newnickname

			ReqMatchInfoList,
			MatchInfoList,        // i:amount (uc:open s:player1 [s:player2])

			CreateMatch,
			JoinMatch,            // s:opponent
			JoinRandomMatch,
			LeaveMatch,
			MatchJoined,          // [s:opponent]
			MatchLeft,            // [s:opponent]

			YourTurn,
			YourTurnEnded,
			PlaceShip,            // uc:shipid uc:x uc:y uc:vertical
			PlacementComplete,
			GameStarts,

			DropBomb,             // uc:x uc:y
			BombHit,              // uc:x uc:y
			BombMissed,           // uc:x uc:y

			YouWin,
			YouLose,

			Shutdown,             // s:password

			Last
		};

		enum ErrorCode {
			Generic = 0,
			BadMessage,
			NotAllowed,
			WrongStatus,
			CannotPlaceShip,
			NotYourTurn,
			AlreadyBombed,
			InvalidPosition,
			UserlimitReached,
			BadNickname,
			MatchAlreadyStarted
		};

		struct Match {
			bool         open;
			std::string  player1;
			std::string  player2;
		};

		static unsigned char GetVersion();

		Protocol( MessageHandler &msghandler );

		bool ParsePacket( sf::Packet &packet, sf::SocketTCP &peer ); 

		static bool SendWelcomeMessage( sf::SocketTCP &peer, const std::string &msg, unsigned char fieldsize, unsigned char maxships );
		static bool SendSystemMessage( sf::SocketTCP &peer, const std::string &msg );
		static bool SendAuthSuccessfulMessage( sf::SocketTCP &peer );
		static bool SendMatchJoinedMessage( sf::SocketTCP &peer, const std::string &other = "" );
		static bool SendMatchLeftMessage( sf::SocketTCP &peer, const std::string &other = "" );
		static bool SendMatchInfoListMessage( sf::SocketTCP &peer, const std::vector<Match> &matches );
		static bool SendYourTurnMessage( sf::SocketTCP &peer );
		static bool SendYourTurnEndedMessage( sf::SocketTCP &peer );
		static bool SendGameStartsMessage( sf::SocketTCP &peer );
		static bool SendErrorMessage( sf::SocketTCP &peer, ErrorCode code, const std::string &msg );
		static bool SendPlaceShipMessage( sf::SocketTCP &peer, unsigned char shipid, unsigned char x, unsigned char y, unsigned char v );
		static bool SendPlacementCompleteMessage( sf::SocketTCP &peer );
		static bool SendBombHitMessage( sf::SocketTCP &peer, unsigned char x, unsigned char y );
		static bool SendBombMissedMessage( sf::SocketTCP &peer, unsigned char x, unsigned char y );
		static bool SendYouWinMessage( sf::SocketTCP &peer );
		static bool SendYouLoseMessage( sf::SocketTCP &peer );

	private:
		static const unsigned char  m_version;

		MessageHandler  &m_msghandler;

};

#endif
