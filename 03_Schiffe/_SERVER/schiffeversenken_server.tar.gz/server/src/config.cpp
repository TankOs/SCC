#include <fstream>
#include <iostream>
#include <sstream>
#include "config.hpp"

bool Config::Load( const std::string &filename ) {
	std::ifstream  in( filename.c_str() );

	if( !in.good() ) {
		return false;
	}

	std::string  line, key, value;
	std::size_t  eqpos;

	while( !in.eof() ) {
		std::getline( in, line );

		if( in.eof() ) {
			break;
		}

		eqpos = line.find( "=" );
		if( eqpos == std::string::npos || line[0] == '#' ) {
			continue;
		}

		key = line.substr( 0, eqpos );
		value = line.substr( eqpos + 1 );

		m_values[key] = value;
	}

	in.close();
	return true;
}

const std::string Config::GetString( const std::string &key ) {
	ConfigMap::iterator  iter( m_values.find( key ) );
	return iter != m_values.end() ? iter->second : "";
}

int Config::GetInt( const std::string &key ) {
	ConfigMap::iterator  iter( m_values.find( key ) );

	if( iter == m_values.end() ) {
		return 0;
	}

	std::stringstream  sstr;
	int                intval;

	sstr << iter->second;
	sstr >> intval;
	return intval;
}
