#ifndef __SETTINGS_HPP__
#define __SETTINGS_HPP__

const unsigned char FIELD_SIZE = 8;
const unsigned char MAX_SHIPS  = 5;

#endif
