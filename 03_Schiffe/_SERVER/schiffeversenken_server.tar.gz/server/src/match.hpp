#ifndef __MATCH_HPP__
#define __MATCH_HPP__

class Match {
	public:
		Match( Peer *first, Peer *second );

		Peer &GetFirstPlayer();
		Peer &GetSecondPlayer();

	private:
		Peer  &m_firstplayer;
		Peer  &m_secondplayer;
};

#endif
