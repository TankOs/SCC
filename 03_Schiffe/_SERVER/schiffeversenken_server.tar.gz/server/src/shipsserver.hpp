#ifndef __SCHIFFESERVER_HPP__
#define __SCHIFFESERVER_HPP__

#include <SFML/Network.hpp>
#include <map>
#include "config.hpp"
#include "messagehandler.hpp"
#include "protocol.hpp"
#include "peer.hpp"

/** Main server class.
 *
 * ShipsServer implements the communication loop and
 * glues all the stuff together.
 */
class ShipsServer : public MessageHandler {
	public:
		/** Constructor.
		 */
		ShipsServer();

		/** Start server.
		 * The server reads its configuration from a configuration file.
		 * @param config Configuration file
		 */
		bool Start( const std::string &config );

		/** Stop server.
		 * Disconnects all clients and closes the listener socket.
		 */
		void Stop();

		/** Called when a message arrives through the protocol.
		 * A pointer to the Peer who sent the message is stored in
		 * m_lastpeer, so that it can be referenced in all the
		 * OnXXXMessage() functions.
		 * @param peer Peer who sent the message
		 */
		bool OnMessage( sf::SocketTCP &peer );

		// For documentation of the MessageHandler functions, please refer
		// to messagehandler.hpp.
		void OnInvalidPacketMessage();
		void OnNicknameMessage( const std::string &nickname );
		void OnReqMatchInfoListMessage();
		void OnCreateMatchMessage();
		void OnJoinMatchMessage( const std::string &opponent );
		void OnJoinRandomMatchMessage();
		void OnShutdownMessage( const std::string &password );
		void OnPlaceShipMessage( unsigned char shipid, unsigned char x, unsigned char y, bool vertical );
		void OnLeaveMatchMessage();
		void OnDropBombMessage( unsigned char x, unsigned char y );
		void OnQuitMessage();

	private:
		typedef std::map<sf::SocketTCP,Peer*>  PeerList;
		typedef std::map<Peer*,Peer*>          PeerMap;

		void DisconnectPeer( Peer &peer );
		void UnlinkMatch( Peer &peer, bool notifypeer = true );
		bool IsNicknameValid( const std::string &nickname );
		void StartMatch( Peer &first, Peer &newplayer );

		sf::SocketTCP    m_listener;
		sf::SelectorTCP  m_selector;

		PeerList   m_peers;
		PeerMap    m_peermap;
		Peer       *m_lastpeer;

		Protocol  m_protocol;

		Config  m_config;
};

#endif
