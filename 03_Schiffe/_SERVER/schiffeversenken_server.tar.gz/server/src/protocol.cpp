#include <SFML/Network.hpp>
#include <cstring>
#include "messagehandler.hpp"
#include "protocol.hpp"

const unsigned char  Protocol::m_version = 1;

unsigned char Protocol::GetVersion() {
	return m_version;
}

Protocol::Protocol( MessageHandler &msghandler ) :
	m_msghandler( msghandler )
{
}

bool Protocol::ParsePacket( sf::Packet &packet, sf::SocketTCP &peer ) {
	int  opcode( First );

	// Ask if packet for peer should be processed.
	if( m_msghandler.OnMessage( peer ) == false ) {
		return false;
	}

	packet >> opcode;

	switch( opcode ) {
		case ChangeNickname:
			{
				std::string  nickname;
				packet >> nickname;

				if( nickname.empty() ) {
					m_msghandler.OnInvalidPacketMessage();
				}
				else {
					m_msghandler.OnNicknameMessage( nickname );
				}
			}
			break;

		case Quit:
			m_msghandler.OnQuitMessage();
			break;

		case Shutdown:
			{
				std::string  password;
				packet >> password;

				if( password.empty() ) {
					m_msghandler.OnInvalidPacketMessage();
				}
				else {
					m_msghandler.OnShutdownMessage( password );
				}
			}
			break;

		case ReqMatchInfoList:
			m_msghandler.OnReqMatchInfoListMessage();
			break;

		case CreateMatch:
			m_msghandler.OnCreateMatchMessage();
			break;

		case JoinMatch:
			{
				std::string  opponent;

				packet >> opponent;
				if( opponent.empty() ) {
					m_msghandler.OnInvalidPacketMessage();
					break;
				}

				m_msghandler.OnJoinMatchMessage( opponent );
			}
			break;

		case JoinRandomMatch:
			m_msghandler.OnJoinRandomMatchMessage();
			break;

		case LeaveMatch:
			m_msghandler.OnLeaveMatchMessage();
			break;

		case DropBomb:
			{
				unsigned char  x, y;
				packet >> x >> y;

				if( !packet ) {
					m_msghandler.OnInvalidPacketMessage();
				}
				else {
					m_msghandler.OnDropBombMessage( x, y );
				}
			}
			break;

		case PlaceShip:
			{
				unsigned char  shipid, x, y, vertical;
				packet >> shipid >> x >> y >> vertical;

				if( !packet ) {
					m_msghandler.OnInvalidPacketMessage();
				}
				else {
					m_msghandler.OnPlaceShipMessage( shipid, x, y, vertical == 1 );
				}
			}
			break;

		default:
			m_msghandler.OnInvalidPacketMessage();
			return false;
	}

	return true;
}

bool Protocol::SendWelcomeMessage( sf::SocketTCP &peer, const std::string &msg, unsigned char fieldsize, unsigned char maxships ) {
	sf::Packet  pkt;
	pkt << Welcome << msg << fieldsize << maxships;
	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendSystemMessage( sf::SocketTCP &peer, const std::string &msg ) {
	sf::Packet  pkt;
	pkt << SystemMessage << msg;
	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendAuthSuccessfulMessage( sf::SocketTCP &peer ) {
	sf::Packet  pkt;
	pkt << AuthSuccessful;
	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendMatchInfoListMessage( sf::SocketTCP &peer, const std::vector<Match> &matches ) {
	sf::Packet  pkt;

	pkt << MatchInfoList;
	pkt << static_cast<unsigned int>( matches.size() );

	for( std::vector<Match>::const_iterator iter = matches.begin(); iter != matches.end(); ++iter ) {
		pkt << iter->open << iter->player1;
		
		if( iter->open == false ) {
			pkt << iter->player2;
		}
	}

	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendMatchJoinedMessage( sf::SocketTCP &peer, const std::string &other ) {
	sf::Packet  pkt;
	pkt << MatchJoined;

	if( other != "" ) {
		pkt << other;
	}

	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendErrorMessage( sf::SocketTCP &peer, ErrorCode code, const std::string &msg ) {
	sf::Packet  pkt;
	pkt << Error << code << msg;
	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendMatchLeftMessage( sf::SocketTCP &peer, const std::string &other ) {
	sf::Packet  pkt;
	pkt << MatchLeft;

	if( other != "" ) {
		pkt << other;
	}

	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendYourTurnMessage( sf::SocketTCP &peer ) {
	sf::Packet  pkt;
	pkt << YourTurn;
	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendPlaceShipMessage( sf::SocketTCP &peer, unsigned char shipid, unsigned char x, unsigned char y, unsigned char v ) {
	sf::Packet  pkt;
	pkt << PlaceShip << shipid << x << y << v;
	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendGameStartsMessage( sf::SocketTCP &peer ) {
	sf::Packet  pkt;
	pkt << GameStarts;
	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendPlacementCompleteMessage( sf::SocketTCP &peer ) {
	sf::Packet  pkt;
	pkt << PlacementComplete;
	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendYourTurnEndedMessage( sf::SocketTCP &peer ) {
	sf::Packet  pkt;
	pkt << YourTurnEnded;
	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendBombHitMessage( sf::SocketTCP &peer, unsigned char x, unsigned char y ) {
	sf::Packet  pkt;
	pkt << BombHit << x << y;
	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendBombMissedMessage( sf::SocketTCP &peer, unsigned char x, unsigned char y ) {
	sf::Packet  pkt;
	pkt << BombMissed << x << y;
	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendYouWinMessage( sf::SocketTCP &peer ) {
	sf::Packet  pkt;
	pkt << YouWin;
	return peer.Send( pkt ) == sf::Socket::Done;
}

bool Protocol::SendYouLoseMessage( sf::SocketTCP &peer ) {
	sf::Packet  pkt;
	pkt << YouLose;
	return peer.Send( pkt ) == sf::Socket::Done;
}
