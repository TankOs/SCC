#ifndef __MESSAGEHANDLER_HPP__
#define __MESSAGEHANDLER_HPP__

#include <vector>

namespace sf {
	class SocketTCP;
	struct Match;
}

/** MessageHandler interface for server.
 * This abstract class provides an interface for servers that want to
 * handle messages coming from the client.
 */
class MessageHandler {
	public:
		virtual bool OnMessage( sf::SocketTCP & );

		virtual void OnInvalidPacketMessage() = 0;
		virtual void OnNicknameMessage( const std::string &nickname ) = 0;
		virtual void OnReqMatchInfoListMessage() = 0;
		virtual void OnCreateMatchMessage() = 0;
		virtual void OnJoinMatchMessage( const std::string &opponent ) = 0;
		virtual void OnJoinRandomMatchMessage() = 0;
		virtual void OnLeaveMatchMessage() = 0;
		virtual void OnShutdownMessage( const std::string &password ) = 0;
		virtual void OnPlaceShipMessage( unsigned char shipid, unsigned char x, unsigned char y, bool vertical ) = 0;
		virtual void OnDropBombMessage( unsigned char x, unsigned char y ) = 0;
		virtual void OnQuitMessage() = 0;
};

#endif
