#include <iostream>

#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
//#include <SFML/Audio.hpp>
//#include <SFML/Network.hpp>

#include "networkmanager.hpp"
#include "mainloop.hpp"
#include <cstring>

void printHelp();


int main(int argc, char* argv[])
{
	Mainloop loop;
	int i=argc;
	while(i>1)
	{
		if(strcmp(argv[argc-i+1], "--help") == 0||strcmp(argv[argc-i+1], "-h")==0)
		{
			printHelp();
			return EXIT_SUCCESS;
		}
		else if(strcmp(argv[argc-i+1], "--fullscreen") == 0||strcmp(argv[argc-i+1], "-full")==0)
		{
			loop.setWindow(true);
		}
		else if(strcmp(argv[argc-i+1], "--window") == 0||strcmp(argv[argc-i+1], "-win")==0)
		{
			loop.setWindow(false);
		}
		else
		{
			std::cout<<"Invalid option '"<<argv[argc-i+1]<<"'. Please try '--help' to get more information.\n";
			return EXIT_SUCCESS;
		}
		--i;
	}
	
	loop.start();
	
	return EXIT_SUCCESS;
}

void printHelp()
{
	std::cout<<"Schiffles Versenken V-0.1\n\n";
	std::cout<<"Dies ist eine Entwicklerversion von deren Benutzung dringends\nabgeraten werden muss.\n\n";
	std::cout<<"Argumente sind:\n";
	std::cout<<"--help\t\t-h\t\tDieser Hilfetext.\n";
	std::cout<<"--fullscreen\t-full\t\tDas Spiel im Vollbild spielen.\n";
	std::cout<<"--window\t-win\t\tIm Fenstermodus aufrufen (standard).\n\n";
	std::cout<<"In der Funktion 'void loadDefaults()' in der Datei 'mainloop.cpp' kann\nman die Standardwerte ändern (neu kompilieren).";
	std::cout<<std::endl;
}


