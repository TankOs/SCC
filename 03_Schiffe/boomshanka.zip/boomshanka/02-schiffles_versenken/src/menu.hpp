#ifndef MENU_HPP
#define MENU_HPP

#include <iostream>

#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "mediamanager.hpp"
#include "enums.hpp"
#include "networkmanager.hpp"

class ClassMenu : public Enums
{
	private:
		sf::Sprite background;
		sf::Sprite background2;
		sf::Sprite mouse;
		sf::Sprite Spiel_Beitreten, Spiel_Beenden, Vollbild, Fenster_Modus, Zurruck, Name_Verwenden, Name_Andern, Spiel_Erstellen;
		
		sf::Sprite button[5];
		
		sf::String topic;
		sf::String message;
		
		sf::Event event;
		
		unsigned int maus_x, maus_y;
		
		bool namefound;
		bool MenuIsTrue;
		bool ClickIsTrue;
		bool gamelist;
		bool gamestatus;
		int listenauswahl;
		bool gamejoined;
		
		int wert;
		
		std::vector<std::string> games;
		std::vector<bool> activegames;
		
		sf::Clock clocks[20];
		std::vector<std::string> konsolentext;
	public:
		ClassMenu();
		~ClassMenu();
		
		void getPics(Mediamanager&);
		void configure();
		
		void chooseName(sf::RenderWindow&, Mediamanager&, Gamestatus&, bool&, Networkmanager&);
		void showMenu(sf::RenderWindow&, Mediamanager&, Gamestatus&, bool&, Networkmanager&);
		
		Enums::ButtonInputs mouseInputs(bool&, Gamestatus&, bool);
		int buttons(bool);
		
		void changeWinMode(sf::RenderWindow&, bool&);
		
		void printMessages(Networkmanager&, sf::RenderWindow&);
		
};

#endif
