#ifndef MAINLOOP_HPP
#define MAINLOOP_HPP

#include "networkmanager.hpp"
#include "enums.hpp"
#include "mediamanager.hpp"
#include "menu.hpp"
#include "game.hpp"

#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

class Mainloop : public Enums
{
	private:
		sf::RenderWindow window;
		
		Networkmanager networker;
		
		bool fullscreen;
		bool connected;
		bool WindowIsTrue;
		bool MusicIsTrue;
		bool GameIsRunning;

		Mediamanager media;
		Gamestatus status;
		ClassMenu menu;
	public:
		Mainloop();
		~Mainloop();
		
		void setFull();
		void loadDefaults();
		int setWindow(bool);
		
		int start();
		void gameloop();
		
};


#endif

