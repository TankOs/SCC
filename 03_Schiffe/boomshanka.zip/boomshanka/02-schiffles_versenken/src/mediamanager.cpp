#include "mediamanager.hpp"

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include <iostream>


Mediamanager::Mediamanager()
{

}


Mediamanager::~Mediamanager()
{

}




bool Mediamanager::loadMusic()
{
	return true;
}


bool Mediamanager::loadImages()
{
	if (!menubackground.LoadFromFile("media/img/menubackground.png"))
	{
		std::cout<<"Error: Cant load 'media/img/menubackground.png'.\n";
		return false;
	}
	if (!menubackground2.LoadFromFile("media/img/menubackground2.png"))
	{
		std::cout<<"Error: Cant load 'media/img/menubackground2.png'.\n";
		return false;
	}
	if (!mouse.LoadFromFile("media/img/mouse.png"))
	{
		std::cout<<"Error: Cant load 'media/img/mouse.png'.\n";
		return false;
	}
	if (!button[0].LoadFromFile("media/img/menupoint1.png"))
	{
		std::cout<<"Error: Cant load 'media/img/menupoint1.png'.\n";
		return false;
	}
	if (!button[1].LoadFromFile("media/img/menupoint2.png"))
	{
		std::cout<<"Error: Cant load 'media/img/menupoint2.png'.\n";
		return false;
	}
	if (!button[2].LoadFromFile("media/img/menupoint3.png"))
	{
		std::cout<<"Error: Cant load 'media/img/menupoint3.png'.\n";
		return false;
	}
	if (!button[3].LoadFromFile("media/img/menupoint4.png"))
	{
		std::cout<<"Error: Cant load 'media/img/menupoint4.png'.\n";
		return false;
	}
	if (!button[4].LoadFromFile("media/img/menupoint5.png"))
	{
		std::cout<<"Error: Cant load 'media/img/menupoint5.png'.\n";
		return false;
	}
	if (!button[5].LoadFromFile("media/img/menupoint6.png"))
	{
		std::cout<<"Error: Cant load 'media/img/menupoint6.png'.\n";
		return false;
	}
	if (!button[6].LoadFromFile("media/img/menupoint7.png"))
	{
		std::cout<<"Error: Cant load 'media/img/menupoint7.png'.\n";
		return false;
	}
	if (!button[7].LoadFromFile("media/img/menupoint8.png"))
	{
		std::cout<<"Error: Cant load 'media/img/menupoint8.png'.\n";
		return false;
	}
	if (!gamebackground[0].LoadFromFile("media/img/game1.jpg"))
	{
		std::cout<<"Error: Cant load 'media/img/game1.jpg'.\n";
		return false;
	}
	if (!gamebackground[1].LoadFromFile("media/img/game2.jpg"))
	{
		std::cout<<"Error: Cant load 'media/img/game2.jpg'.\n";
		return false;
	}
	if (!spielfeld.LoadFromFile("media/img/spielfeld.png"))
	{
		std::cout<<"Error: Cant load 'media/img/spielfeld.png'.\n";
		return false;
	}
	if (!spielfeldhintergrund.LoadFromFile("media/img/spielfeldhintergrund.png"))
	{
		std::cout<<"Error: Cant load 'media/img/spielfeldhintergrund.png'.\n";
		return false;
	}
	if (!ship[0].LoadFromFile("media/img/ship1.png"))
	{
		std::cout<<"Error: Cant load 'media/img/ship1.png'.\n";
		return false;
	}
	if (!ship[1].LoadFromFile("media/img/ship2.png"))
	{
		std::cout<<"Error: Cant load 'media/img/ship2.png'.\n";
		return false;
	}
	if (!ship[2].LoadFromFile("media/img/ship3.png"))
	{
		std::cout<<"Error: Cant load 'media/img/ship3.png'.\n";
		return false;
	}
	if (!ship[3].LoadFromFile("media/img/ship4.png"))
	{
		std::cout<<"Error: Cant load 'media/img/ship4.png'.\n";
		return false;
	}
	if (!ship[4].LoadFromFile("media/img/ship5.png"))
	{
		std::cout<<"Error: Cant load 'media/img/ship5.png'.\n";
		return false;
	}
	if (!explusion.LoadFromFile("media/img/explusion.png"))
	{
		std::cout<<"Error: Cant load 'media/img/explusion.png'.\n";
		return false;
	}
	if (!wather.LoadFromFile("media/img/wather.png"))
	{
		std::cout<<"Error: Cant load 'media/img/wather.png'.\n";
		return false;
	}
	
	return true;
}



sf::Sprite Mediamanager::getImage(Bilder name)
{
	sf::Sprite back;
	switch (name)
	{
		case Menubackground:
			back.SetImage(menubackground);
			break;
		case Menubackground2:
			back.SetImage(menubackground2);
			break;
		case Mouse:
			back.SetImage(mouse);
			break;
		case Button1:
			back.SetImage(button[0]);
			break;
		case Button2:
			back.SetImage(button[1]);
			break;
		case Button3:
			back.SetImage(button[2]);
			break;
		case Button4:
			back.SetImage(button[3]);
			break;
		case Button5:
			back.SetImage(button[4]);
			break;
		case Button6:
			back.SetImage(button[5]);
			break;
		case Button7:
			back.SetImage(button[6]);
			break;
		case Button8:
			back.SetImage(button[7]);
			break;
		case Game1:
			back.SetImage(gamebackground[0]);
			break;
		case Game2:
			back.SetImage(gamebackground[1]);
			break;
		case Spielfeld:
			back.SetImage(spielfeld);
			break;
		case Spielfeldhintergrund:
			back.SetImage(spielfeldhintergrund);
			break;
		case Ship1:
			back.SetImage(ship[0]);
			break;
		case Ship2:
			back.SetImage(ship[1]);
			break;
		case Ship3:
			back.SetImage(ship[2]);
			break;
		case Ship4:
			back.SetImage(ship[3]);
			break;
		case Ship5:
			back.SetImage(ship[4]);
			break;
		case Explusion:
			back.SetImage(explusion);
			break;
		case Wather:
			back.SetImage(wather);
			break;
	}
	return back;
}



/*sf::Font Mediamanager::getFont(Fonts name)
{
	switch(name)
	{
		case Topic:
			return topic;
			break;
		
	}
}*/


