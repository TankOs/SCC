#ifndef ENUMS_HPP
#define ENUMS_HPP

#include <SFML/System.hpp>
#include <SFML/Network.hpp>

#include <iostream>

class Enums
{
	public:
		enum MessageId
		{
			First = 0,
			Welcome,
			SystemMessage,
			Error,
			Quit,
		
			AuthSuccessful,
			ChangeNickname,
		
			ReqMatchInfoList,
			MatchInfoList,
		
			CreateMatch,
			JoinMatch,
			JoinRandomMatch,
			LeaveMatch,
			MatchJoined,
			MatchLeft,
		
			YourTurn,
			YourTurnEnded,
			PlaceShip,
			PlacementComplete,
			GameStarts,
		
			DropBomb,
			BombHit,
			BombMissed,
		
			YouWin,
			YouLose,

			Shutdown,

			Last
		};
		
		
		enum ErrorCode
		{
			Generic = 0,
			BadMessage,
			NotAllowed,
			WrongStatus,
			CannotPlaceShip,
			NotYourTurn,
			AlreadyBombed,
			InvalidPosition,
			UserlimitReached,
			BadNickname,
			MatchAlreadyStarted
		};
		
		
		enum Zustaende
		{
			Preauth = 0,
			Auth,
			Waiting,
			ShipPlacement,
			Playing,
			WaitForInputs
		};
		
		
		enum Connectionstatus
		{
			Disconnected =0,
			Nameless,
			LoginFailed,
			Connected,
			ConnectionFailed
		};
		
		
		enum Gamestatus
		{
			ChooseName =0,
			Menu,
			Gamemenu,
			Game,
			Exit
		};
		
		
		enum Bilder
		{
			Menubackground,
			Menubackground2,
			Mouse,
			Button1,
			Button2,
			Button3,
			Button4,
			Button5,
			Button6,
			Button7,
			Button8,
			Game1,
			Game2,
			Spielfeld,
			Spielfeldhintergrund,
			Ship1,
			Ship2,
			Ship3,
			Ship4,
			Ship5,
			Explusion,
			Wather
		};
		
		
		enum Fonts
		{
			Topic
		};
		
		
		enum ButtonInputs
		{
			WindowMode,
			SpielBeitreten,
			SpielErstellen,
			NameAndern,
			Back,
			
			NameVerwenden,
			
			Nothing
		};
		
		
		enum GameInputs
		{
			NewMatch,
			RandomMatch,
			Left,
			Join,
			
			None
		};
		
		
};

#endif

