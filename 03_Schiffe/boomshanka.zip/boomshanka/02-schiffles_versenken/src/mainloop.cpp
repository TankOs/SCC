#include "mainloop.hpp"

#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>

#include <iostream>
#include <fstream>


Mainloop::Mainloop()
{
	WindowIsTrue=false;
	GameIsRunning=true;
	
	status=Menu;
}


Mainloop::~Mainloop()
{

}




int Mainloop::setWindow(bool full)
{
	fullscreen=full;
	sf::VideoMode vid=sf::VideoMode(800, 600, 32);
	if(!vid.IsValid())
	{
		std::cout<<"Error: Video Mode isn´t Valid."<<std::endl;
		return EXIT_FAILURE; 
	}
	if (full)
	{
		window.Create(sf::VideoMode(800, 600, 32), "Schiffles Versenken", sf::Style::Fullscreen);
	}
	else
	{
		window.Create(sf::VideoMode(800, 600, 32), "Schiffles Versenken", sf::Style::Close);
	}
	window.SetFramerateLimit(60);
	window.ShowMouseCursor(false);
	WindowIsTrue=true;
}


void Mainloop::loadDefaults()
{
	MusicIsTrue=true;
	
	if(!WindowIsTrue)
	{
		
		setWindow(false);
	}
	sf::IPAddress clientaddress("boxbox.org");
	int port=10500;
	
	std::string nickname="";

	networker.saveAddress(port, clientaddress, nickname);
}




int Mainloop::start()
{
	loadDefaults();
	
	networker.Launch();
	
	while(networker.getConnectionstatus()==Disconnected || networker.getConnectionstatus()==Nameless)
	{
		sf::Sleep(0.1f);
	}
	connected=true;
	sf::Sleep(1.f);
	if (networker.getConnectionstatus()==LoginFailed)
		status=ChooseName;
	if (networker.getConnectionstatus()==ConnectionFailed)
		connected=false;
	
	
	media.loadImages();
	if(MusicIsTrue)
		media.loadMusic();
	
	gameloop();
	
}


void Mainloop::gameloop()
{
	menu.getPics(media);
	sf::Event event;
	bool noMenu=true;
	
	while(GameIsRunning)
	{
		ClassGame game;
		switch(status)
		{
			case ChooseName:
				menu.chooseName(window, media, status, fullscreen, networker);
				break;
			
			case Menu:
				menu.showMenu(window, media, status, fullscreen, networker);
				break;
			
			case Gamemenu:
				game.gamemenu(window);
				//menu.
				break;
			
			case Game:
				game.loop(window, media, status, networker);
				break;
				
			case Exit:
				window.Close();
				if(connected)
					networker.disconnect();
				GameIsRunning=false;
				break;
		}
		sf::Sleep(0.1f);
	}
	networker.Wait();
}



