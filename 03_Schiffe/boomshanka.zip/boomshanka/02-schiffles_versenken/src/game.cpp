#include "game.hpp"


ClassGame::ClassGame()
{
	sf::Randomizer::Random(0, 10);
	shipcounter=0;
	nextship=true;
	TurnShipIsTrue=false;
	turnship=0;
	
	schiffeplatziert=false;
	
	x=0;
	y=0;
	
	turn.SetSize(20);
	turn.SetColor(sf::Color(170,0,200));
}


ClassGame::~ClassGame()
{

}



void ClassGame::loop(sf::RenderWindow& window, Mediamanager& media, Gamestatus& status, Networkmanager& networker)
{
	spielfeld[0]=media.getImage(Spielfeld);
	spielfeld[1]=media.getImage(Spielfeld);
	spielfeldhintergrund=media.getImage(Spielfeldhintergrund);
	sf::Sprite mouse=media.getImage(Mouse);
	
	spielfeld[0].SetPosition(5, 70);
	spielfeld[1].SetPosition(415, 130);
	spielfeldhintergrund.SetPosition(5, 70);
	
	explusion=media.getImage(Explusion);
	wather=media.getImage(Wather);
	
	if(sf::Randomizer::Random(0, 1)==1)
	{
		background=media.getImage(Game1);
	}
	else
	{
		background=media.getImage(Game2);
	}
	
	const sf::Input& input = window.GetInput();//input für maus
	sf::Event event;
	
	GameIsTrue=true;
	ClickIsTrue=false;
	
	turn.SetText("Setzen Sie ihre Schiffe (Mit der rechten Maustaste drehen)");
	
	while(window.GetEvent(event)){}
	
	while(GameIsTrue)
	{
		ClickIsTrue=false;
		while(window.GetEvent(event))//check events
		{
			if(event.Type == sf::Event::Closed)
			{
				status=Exit;
				GameIsTrue=false;
			}
			else if((event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Escape))
			{
				status=Gamemenu;
			}
			else if((event.Type == sf::Event::MouseButtonReleased) && (event.MouseButton.Button == sf::Mouse::Left))
			{
				ClickIsTrue=true;
			}
			else if((event.Type == sf::Event::MouseButtonReleased) && (event.MouseButton.Button == sf::Mouse::Right))
			{
				++turnship;
				if(turnship>3)
					turnship=0;
				TurnShipIsTrue=true;
			}
		}
		
		window.Clear();
		window.Draw(background);
		
		maus_x=input.GetMouseX();//get mouse position
		maus_y=input.GetMouseY();
		
		mouse.SetPosition(maus_x - mouse.GetSize().x / 2.f, maus_y - mouse.GetSize().y / 2.f);
		
		//if()
		{
			switch(networker.getGameStatus())
			{
				case ShipPlacement:
					shipPlacement(window, media, networker);
					break;
				case Playing:
					playing(window, media, networker);
					break;
				case WaitForInputs:
					status=Menu;
					GameIsTrue=false;
					break;
				default:
					std::cout<<networker.getGameStatus();
					std::cout<<" Fehler: Synchonisation mir Networmanagerthread fehlgeschlagen, abbruch."<<std::endl;
					status=Exit;
					GameIsTrue=false;
					break;
			}
		}
		
		turn.SetPosition(400.f - turn.GetRect().GetWidth() / 2, 596 - turn.GetRect().GetHeight());
		
		window.Draw(spielfeldhintergrund);
		window.Draw(spielfeld[0]);
		window.Draw(spielfeld[1]);
		window.Draw(schiff[0]);
		window.Draw(schiff[1]);
		window.Draw(schiff[2]);
		window.Draw(schiff[3]);
		window.Draw(schiff[4]);
		
		//Draw explusions
		for(int i=0; i<gegner_wasser.size(); ++i)
		{
			wather.SetPosition(5+38*gegner_wasser[i].x, 70+38*gegner_wasser[i].y);
			window.Draw(wather);
		}
		for(int i=0; i<gegner_treffer.size(); ++i)
		{
			explusion.SetPosition(5+38*gegner_treffer[i].x, 70+38*gegner_treffer[i].y);
			window.Draw(explusion);
		}
		for(int i=0; i<spieler_wasser.size(); ++i)
		{
			wather.SetPosition(415+38*spieler_wasser[i].x,130+38*spieler_wasser[i].y);
			window.Draw(wather);
		}
		for(int i=0; i<spieler_treffer.size(); ++i)
		{
			explusion.SetPosition(415+38*spieler_treffer[i].x,130+38*spieler_treffer[i].y);
			window.Draw(explusion);
		}
		printMessages(networker, window);
		
		window.Draw(turn);
		window.Draw(mouse);
		window.Display();
	}//end loop
	
	int iwin=networker.win();
	if(iwin!=0)
	{
		sf::String win;
		win.SetSize(50);
		win.SetColor(sf::Color(185,0,0));
		
		std::cout<<spieler_wasser.size()+spieler_treffer.size()<<" Bomben abgeworfen, davon "<<spieler_treffer.size();
		std::cout<<" treffer ("<<100.f*(static_cast<float>(spieler_treffer.size())
		/(static_cast<float>(spieler_wasser.size())+static_cast<float>(spieler_treffer.size())));
		std::cout<<" %).\n"<<std::endl;
		
		std::cout<<"Gegner:\n";
		std::cout<<gegner_wasser.size()+gegner_treffer.size()<<" Bomben abgeworfen, davon "<<gegner_treffer.size();
		std::cout<<" treffer ("<<100.f*(static_cast<float>(gegner_treffer.size())
		/(static_cast<float>(gegner_wasser.size())+static_cast<float>(gegner_treffer.size())));
		std::cout<<" %).\n"<<std::endl;
		
		switch(iwin)
		{
			case 1:
				std::cout<<"Gewonnen!!! :) :) :)\n"<<std::endl;
				win.SetText("Sie haben Gewonnen!");
				break;
			case 2:
				std::cout<<"Verloren :( :( :(\n"<<std::endl;
				win.SetText("Sie haben Verloren.");
				break;
			case 0:
				win.SetText("Gegner hat das Spiel verlassen.");
				break;
		}
		
		win.SetPosition(400 - win.GetRect().GetWidth() / 2.f, 300 * 0.70f);
		
		while(window.GetEvent(event)){}
		
		int i=0;
		do
		{
			while(window.GetEvent(event)){event.Type;}
			mouse.SetPosition(input.GetMouseX(), input.GetMouseY());
			
			gamemenu(window);
			
			window.Draw(win);
			window.Draw(mouse);
			window.Display();
			
			window.Clear();
			
			++i;
		}
		while(((event.Type != sf::Event::KeyReleased) && (event.Type != sf::Event::MouseButtonReleased)
			 && (event.Type != sf::Event::Closed)) || (i<120));
	}
	if(event.Type==sf::Event::Closed)
	{
		status=Exit;
	}
}


void ClassGame::gamemenu(sf::RenderWindow& window)
{
	window.Clear();
	window.Draw(background);
	window.Draw(spielfeldhintergrund);
	window.Draw(spielfeld[0]);
	window.Draw(spielfeld[1]);
	window.Draw(schiff[0]);
	window.Draw(schiff[1]);
	window.Draw(schiff[2]);
	window.Draw(schiff[3]);
	window.Draw(schiff[4]);
}


void ClassGame::shipPlacement(sf::RenderWindow& window, Mediamanager& media, Networkmanager& networker)
{
	if(nextship)
	{
		if(shipcounter<5)
		{
			schiff[shipcounter]=getShipimage(media);
			++shipcounter;
			turnship=0;
		}
		else
		{
			schiffeplatziert=true;
			turn.SetText("Bitte warten, bis der Gegner seine Schiffe platziert hat");
		}
	}
	
	if((TurnShipIsTrue && !schiffeplatziert) || nextship)
	{
		if(!nextship)
			schiff[shipcounter-1].SetRotation(schiff[shipcounter-1].GetRotation()+90.f);
		switch(turnship)
		{
			case 0:
				x=0;
				y=0;
				break;
			case 1:
				y=0.f+schiff[shipcounter-1].GetSize().x;
				x=0;
				break;
			case 2:
				x=0.f+schiff[shipcounter-1].GetSize().x;
				y=0.f+schiff[shipcounter-1].GetSize().y;
				break;
			case 3:
				x=0.f+schiff[shipcounter-1].GetSize().y;
				y=0;
				break;
		}
		TurnShipIsTrue=false;
		nextship=false;
	}
	
	for(ship_x=1; ship_x<10; ++ship_x)
	{
		if(((ship_x-1)*38<=(maus_x-5)) && ((maus_x-5)<=38*ship_x))
			break;
	}
	for(ship_y=1; ship_y<10; ++ship_y)
	{
		if(((ship_y-1)*38<=(maus_y-70)) && ((maus_y-70)<=38*ship_y))
			break;
	}
	
	//überprüfe, ob schiffe nicht aus dem feld kommen
	if(turnship==1 || turnship==3)
	{
		if(shipcounter+ship_x>10)
			ship_x=10-shipcounter;
	}
	else
	{
		if(shipcounter+ship_y>10)
			ship_y=10-shipcounter;
	}
	
	if(ClickIsTrue)
	{
		if(!networker.setShip(ship_x, ship_y, turnship))
		{
			ClickIsTrue=false;
		}
		else
		{
			nextship=true;
			ClickIsTrue=false;
		}
	}
	
	if(schiffeplatziert==false)
		schiff[shipcounter-1].SetPosition((ship_x-1)*38+x+5, (ship_y-1)*38+y+70);
}


sf::Sprite ClassGame::getShipimage(Mediamanager& media)
{
	switch(shipcounter)
	{
		case 0:
			return (media.getImage(Ship1));
			break;
		case 1:
			return (media.getImage(Ship2));
			break;
		case 2:
			return (media.getImage(Ship3));
			break;
		case 3:
			return (media.getImage(Ship4));
			break;
		case 4:
			return (media.getImage(Ship5));
			break;
	}
}


void ClassGame::setShip(float& position_x, float& position_y)
{
	
}



void ClassGame::playing(sf::RenderWindow& window, Mediamanager& media, Networkmanager& networker)
{
	if(networker.myTurn())
	{
		turn.SetText("Sie sind dran, werfen sie die Bombe ab");
		turn.SetColor(sf::Color(180,0,60));
		if(ClickIsTrue)
		{
			int bomb_x, bomb_y;
			for(bomb_x=1; bomb_x<10; ++bomb_x)
			{
				if(((bomb_x-1)*38<=(maus_x-415)) && ((maus_x-415)<=38*bomb_x))
					break;
			}
			for(bomb_y=1; bomb_y<10; ++bomb_y)
			{
				if(((bomb_y-1)*38<=(maus_y-132)) && ((maus_y-130)<=38*bomb_y))
					break;
			}
			networker.bomb(bomb_x, bomb_y);
			ClickIsTrue=false;
		}
		bombhit=networker.bombHit();
		sf::Vector2f vec;
		if(bombhit!=0)
			vec=networker.getBomb();
		if(bombhit==1)
		{
			std::cout<<"Treffer!\n";
			spieler_treffer.push_back(vec);
		}
		else if(bombhit==2)
		{
			spieler_wasser.push_back(vec);
			std::cout<<"Wasser!\n";
		}
	}
	else
	{
		turn.SetText("Warten Sie, bis der Gegner die Bombe abgeworfen hat");
		turn.SetColor(sf::Color(60,0,180));
		bombhit=networker.bombHit();
		sf::Vector2f vec;
		if(bombhit!=0)
			vec=networker.getBomb();
		if(bombhit==1)
		{
			gegner_treffer.push_back(vec);
		}
		else if(bombhit==2)
		{
			gegner_wasser.push_back(vec);
		}
	}
}



void ClassGame::printMessages(Networkmanager& networker, sf::RenderWindow& window)
{
	if(networker.getMessages().size()>0)
	{
		konsolentext.push_back(networker.getMessages()[networker.getMessages().size()-1]);
		clocks[networker.getMessages().size()-1].Reset();
	}
	bool istrue=false;
	sf::String text;
	text.SetSize(20);
	text.SetColor(sf::Color(30,0,130));
	
	for(int i=0;i<konsolentext.size();++i)
	{
		if(clocks[i].GetElapsedTime()<5.f)
		{
			text.SetText(konsolentext[i]);
			text.SetPosition(800-text.GetRect().GetWidth(), 400+10*i);
			window.Draw(text);
			istrue=true;
		}
	}
	
	if (!istrue)
	{
		while(konsolentext.size()>0)
		{
			konsolentext.pop_back();
		}
	}
}




