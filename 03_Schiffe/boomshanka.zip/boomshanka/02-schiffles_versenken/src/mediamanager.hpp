#ifndef MEDIAMANAGER_HPP
#define MEDIAMANAGER_HPP

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include <iostream>

#include "enums.hpp"

class Mediamanager : public Enums
{
	private:
		sf::Image menubackground;
		sf::Image menubackground2;
		sf::Image mouse;
		sf::Image button[8];
		sf::Image gamebackground[2];
		sf::Image spielfeld;
		sf::Image spielfeldhintergrund;
		sf::Image ship[5];
		sf::Image explusion;
		sf::Image wather;
		
//		sf::Font topic;
	public:
		Mediamanager();
		~Mediamanager();
		
		bool loadMusic();
		bool loadImages();
		
		sf::Sprite getImage(Bilder);
//		sf::Font getFont(Fonts);
};

#endif

