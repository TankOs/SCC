#include "menu.hpp"

#include <iostream>

#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>


ClassMenu::ClassMenu()
{
	namefound=false;
	gamelist=false;
	gamestatus=false;
	listenauswahl=0;
	gamejoined=false;
	
	message.SetColor(sf::Color(160,0,110));
	message.SetSize(18);
}


ClassMenu::~ClassMenu()
{

}



void ClassMenu::getPics(Mediamanager& media)
{
	background=media.getImage(Menubackground);
	background2=media.getImage(Menubackground2);
	mouse=media.getImage(Mouse);
	Spiel_Beitreten=media.getImage(Button1);
	Spiel_Erstellen=media.getImage(Button8);
	Spiel_Beenden=media.getImage(Button2);
	Vollbild=media.getImage(Button3);
	Fenster_Modus=media.getImage(Button4);
	Zurruck=media.getImage(Button5);
	Name_Verwenden=media.getImage(Button6);
	Name_Andern=media.getImage(Button7);
	
	configure();
	
	topic.SetText("Schiffe Versenken");
//	topic.SetFont(FTopic);
	topic.SetSize(50);
	topic.SetColor(sf::Color(0, 20, 70));
	topic.SetPosition((482 - topic.GetRect().GetWidth() / 2), 20);
	
}



void ClassMenu::configure()
{
	Spiel_Beitreten.SetPosition(0,120);
	Name_Verwenden.SetPosition(0,120);
	Name_Andern.SetPosition(0,280);
	Spiel_Erstellen.SetPosition(0,200);
	Vollbild.SetPosition(0,420);
	Fenster_Modus.SetPosition(0,420);
	Zurruck.SetPosition(0,500);
	Spiel_Beenden.SetPosition(0,500);
	
}


void ClassMenu::chooseName(sf::RenderWindow& window, Mediamanager& media, Gamestatus& status, bool& full,  Networkmanager& 	 networker)
{
	button[0]=Name_Verwenden;
	
	button[3]=Vollbild;
	button[4]=Spiel_Beenden;
	
	const sf::Input& input = window.GetInput();
	bool newname=false;
	
	sf::String nickname("", sf::Font::GetDefaultFont(), 40.f);
	nickname.SetColor(sf::Color(0, 0, 80));
	nickname.SetPosition(200, 120);
	
	std::string text_entered("Name Eingeben");
	std::string legal_characters("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
	std::string::size_type max_length = 20;
	
	
	while(!newname)
	{
		message.SetText("");
		
		ClickIsTrue=false;
		while(window.GetEvent(event))
		{
			if((event.Type==sf::Event::MouseButtonReleased) && (event.MouseButton.Button==sf::Mouse::Left))
			{
				ClickIsTrue=true;
			}
			else if(((event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Escape )) || (event.Type == sf::Event::Closed))
			{
				status=Exit;
				newname=true;
			}
			else if(event.Type == sf::Event::TextEntered && text_entered.size() != max_length)
			{
				sf::Unicode::Text character(&event.Text.Unicode);
				std::string::size_type index = legal_characters.find_first_of(character);
				if(text_entered=="Name Eingeben")
					text_entered="";
				if(index != legal_characters.npos)
					text_entered.append(legal_characters.substr(index, 1));
			}
			else if(!text_entered.empty() && event.Type == sf::Event::KeyPressed && event.Key.Code == sf::Key::Back)
			{
				text_entered.erase(text_entered.end() - 1);
			}
		}
		nickname.SetText(text_entered);
		
		maus_x=input.GetMouseX();
		maus_y=input.GetMouseY();
		
		switch(mouseInputs(ClickIsTrue, status, false))//witch button is pressed
		{
			case WindowMode:
				changeWinMode(window, full);
				break;
			case NameVerwenden:
				if(text_entered!="" && text_entered!="Name Eingeben")
				{
					if(networker.newName(text_entered))
					{
						newname=true;
						status=Menu;
					}
					else
					{
						std::cout<<"Name '"<<text_entered<<"' konnte nicht verwendet werden."<<std::endl;
					}
				}
				break;
			case Back:
				newname=true;
				break;
		}
		
		//clear window
		window.Clear();
		
		window.Draw(background);
		window.Draw(button[0]);
		window.Draw(button[3]);
		window.Draw(button[4]);
		window.Draw(topic);
		window.Draw(nickname);
		
		message.SetPosition((482 - message.GetRect().GetWidth() / 2), 596 - message.GetRect().GetHeight());
		window.Draw(message);
		
		window.Draw(mouse);
		window.Display();
	}
//	namefound=true;
}






void ClassMenu::showMenu(sf::RenderWindow& window, Mediamanager& media, Gamestatus& status, bool& full, Networkmanager& 	 networker)
{
	//aus constructor:
	gamelist=false;
	gamestatus=false;
	listenauswahl=0;
	gamejoined=false;
	
	
	
	button[0]=Spiel_Beitreten;
	button[1]=Spiel_Erstellen;
//	button[2]=Name_Andern;
	if(!full)
	{
		button[3]=Vollbild;
	}
	else
	{
		button[3]=Fenster_Modus;
	}
	button[4]=Spiel_Beenden;
	
	const sf::Input& input = window.GetInput();
	int scrolling=0;
	
	MenuIsTrue=true;
	namefound=true;
	ClickIsTrue=false;
	
	while(MenuIsTrue)	//menuloop
	{
		message.SetText("");
		
		ClickIsTrue=false;
		while(window.GetEvent(event))//check events
		{
			if((event.Type==sf::Event::MouseButtonReleased) && (event.MouseButton.Button==sf::Mouse::Left))
			{
				ClickIsTrue=true;
			}
			else if(((event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Escape )) || (event.Type == sf::Event::Closed))
			{
				status=Exit;
				MenuIsTrue=false;
			}
			else if(event.Type==sf::Event::MouseWheelMoved)
			{
				scrolling=scrolling+15*event.MouseWheel.Delta;
			}
		}
		if(listenauswahl!=0 && activegames[listenauswahl-1]==true)//FIXME möglicherweise warnung bei false
		{
			networker.joinGame(games[listenauswahl-1]);
			gamejoined=true;
		}
		
		if(gamejoined==true||gamestatus==true)
		{
			switch(networker.getGameStatus())
			{
				case Waiting:
					message.SetText("Es wurde ein Match erstellt, bitte warten Sie auf einen Gegner.");
					break;
				case ShipPlacement:
					status=Game;
					MenuIsTrue=false;
					break;
				case WaitForInputs:
					//fehler, oder thread noch nicht so weit
					gamelist=false;
					break;
				default:
					std::cout<<networker.getGameStatus()<<" ";
					std::cout<<"Fehler: Synchonisation mir Networmanagerthread fehlgeschlagen, abbruch."<<std::endl;
					status=Exit;
					MenuIsTrue=false;
					break;
			}
		}
		
		maus_x=input.GetMouseX();//get mouse position
		maus_y=input.GetMouseY();
		
		switch(mouseInputs(ClickIsTrue, status, true))//witch button is pressed
		{
			case WindowMode:
				changeWinMode(window, full);
				break;
			case SpielBeitreten:
				networker.getGamelist(games, activegames);
				gamelist=true;
				scrolling=0;
				break;
			case SpielErstellen:
				gamelist=false;
				networker.setInputs(NewMatch);
				gamestatus=true;
				break;
/*			case NameAndern:
				status=ChooseName;
				MenuIsTrue=false;
				break;*/
			case Back:
				if(gamejoined||gamestatus)
					networker.setInputs(Left);
				gamestatus=false;
				gamejoined=false;
				break;
		}
		
		//possition von message setzen
		message.SetPosition((482 - message.GetRect().GetWidth() / 2), 596 - message.GetRect().GetHeight());
		
		//Clear window
		window.Clear();
		
		//Draw everything
		window.Draw(background);
		
		if(gamelist)
		{
			sf::String text;
			text.SetSize(30);
			listenauswahl=0;
			
			for(int i=0; i<games.size(); ++i)
			{
				text.SetPosition(200, (120 + i * 45 + scrolling));
				text.SetText(games[i]);
				
				if((maus_x>=200 && maus_x<=(text.GetRect().GetWidth()+200))
				&& (maus_y>=text.GetPosition().y && maus_y<=(text.GetPosition().y + text.GetRect().GetHeight())))
				{
					if(ClickIsTrue)
						listenauswahl=++i;
					text.SetColor(sf::Color(150, 0, 0));
				}
				else
				{
					text.SetColor(sf::Color(0, 0, 80));
				}
				window.Draw(text);
			}
		}
		window.Draw(background2);
		
		window.Draw(button[0]);
		window.Draw(button[1]);
//		window.Draw(button[2]);
		window.Draw(button[3]);
		window.Draw(button[4]);
		window.Draw(topic);
		
		//draw message
		window.Draw(message);
		
		printMessages(networker, window);
		
		//draw mouse
		window.Draw(mouse);
		
		//Displaying
		window.Display();
	}
}



Enums::ButtonInputs ClassMenu::mouseInputs(bool& click, Gamestatus& status, bool mainmenu)//iwie unnötig, vllt auch gutxD
{
	mouse.SetPosition(maus_x - mouse.GetSize().x / 2.f, maus_y - mouse.GetSize().y / 2.f);
	if (!mainmenu)
	{
		wert=buttons(false);
		if(wert!=0 && click==true)
		{
			switch(wert)
			{	
				case 1:
					return NameVerwenden;
					break;
				case 4:
					return WindowMode;
					break;
				case 5:
					status=Exit;
					return Back;
					break;
			}
		}
	}
	else
	{
		wert=buttons(true);
		if(wert!=0 && click==true)
		{
			switch(wert)
			{
				case 1:
					button[4]=Zurruck;
					return SpielBeitreten;
					break;
				case 2:
					button[4]=Zurruck;
					return SpielErstellen;
					break;
//				case 3:
//					return NameAndern;
//					break;
				case 4:
					return WindowMode;
					break;
				case 5:
					if(gamelist==false && gamestatus==false)
					{
						status=Exit;
						MenuIsTrue=false;
						break;
					}
					else
					{
						gamelist=false;
						button[4]=Spiel_Beenden;
					}
					return Back;
					break;
			}
		}
	}
	return Nothing;
}



int ClassMenu::buttons(bool mainmenu)
{
	if(!gamestatus)
	{
		button[0].SetColor(sf::Color(0, 0, 255));
	}
	else
	{
		button[0].SetColor(Zurruck.GetColor());
	}
	if(mainmenu)
	{
		button[1].SetColor(sf::Color(0, 0, 255));
		button[2].SetColor(sf::Color(0, 0, 255));
	}
//	button[2].SetColor(sf::Color(0, 0, 255));
	button[3].SetColor(sf::Color(0, 0, 255));
	button[4].SetColor(sf::Color(0, 0, 255));
	
	if(((maus_x>=0)&&(maus_x<=180)) && ((maus_y>=120)&&(maus_y<=174)) && gamestatus==false)
	{
		button[0].SetColor(sf::Color(255, 0, 0));
		if(!mainmenu)
		{
			message.SetText("Name verwenden.");
		}
		else
		{
			message.SetText("Matchliste abrufen.");
		}
		return 1;
	}
	else if(((maus_x>=0)&&(maus_x<=180))&&((maus_y>=200)&&(maus_y<=254)) && mainmenu==true)
	{
		button[1].SetColor(sf::Color(255, 0, 0));
		message.SetText("Ein Match erstellen.");
		return 2;
	}
/*	else if(((maus_x>=0)&&(maus_x<=180))&&((maus_y>=280)&&(maus_y<=334)) && mainmenu==true)
	{
		button[2].SetColor(sf::Color(255, 0, 0));
		return 3;
	}*/
	else if(((maus_x>=0)&&(maus_x<=180))&&((maus_y>=420)&&(maus_y<=474)))
	{
		message.SetText("Das Spiel im Vollbild oder Fenstermodus spielen.");
		button[3].SetColor(sf::Color(255, 0, 0));
		return 4;
	}
	else if(((maus_x>=0)&&(maus_x<=180))&&((maus_y>=500)&&(maus_y<=554)))
	{
		if(!gamelist && !gamestatus)
		{
			message.SetText("Das Spiel beenden.");
		}
		else if (gamestatus)
		{
			message.SetText("Erstelltes Match verlassen.");
		}
		else
		{
			message.SetText("Zurrueck zum Menue");
		}
		button[4].SetColor(sf::Color(255, 0, 0));
		return 5;
	}
	
	return 0;
}



void ClassMenu::changeWinMode(sf::RenderWindow& window, bool& full)
{
	if(full)//wenn fullscreen, dann windowed
				{
		window.Create(sf::VideoMode(800, 600, 32), "Schiffles Versenken", sf::Style::Close);
		button[3]=Vollbild;
		full=false;
	}
	else
	{
		window.Create(sf::VideoMode(800, 600, 32), "Schiffles Versenken", sf::Style::Fullscreen);
		button[3]=Fenster_Modus;
		full=true;
	}
	window.SetFramerateLimit(60);
	window.ShowMouseCursor(false);
}


void ClassMenu::printMessages(Networkmanager& networker, sf::RenderWindow& window)
{
	if(networker.getMessages().size()>0)
	{
		konsolentext.push_back(networker.getMessages()[networker.getMessages().size()-1]);
		clocks[networker.getMessages().size()-1].Reset();
	}
	bool istrue=false;
	sf::String text;
	text.SetSize(20);
	text.SetColor(sf::Color(30,0,130));
	
	for(int i=0;i<konsolentext.size();++i)
	{
		if(clocks[i].GetElapsedTime()<5.f)
		{
			text.SetText(konsolentext[i]);
			text.SetPosition(800-text.GetRect().GetWidth(), 400+10*i);
			window.Draw(text);
			istrue=true;
		}
	}
	
	if (!istrue)
	{
		while(konsolentext.size()>0)
		{
			konsolentext.pop_back();
		}
	}
}



