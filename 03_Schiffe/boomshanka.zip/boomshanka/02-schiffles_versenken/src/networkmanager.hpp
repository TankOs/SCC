#ifndef NETWORKMANAGER_HPP
#define	NETWORKMANAGER_HPP

#include <SFML/Network.hpp>
#include "enums.hpp"


class Networkmanager : public sf::Thread, public Enums
{
	private:
		sf::SocketTCP client;
		sf::Packet packet;
		unsigned int   msgid;
		std::string    msg;
		
		int port;
		sf::IPAddress address;
		std::string nickname;
		
		std::string adder;
		
		Connectionstatus status;
		Zustaende zustand;
		GameInputs inputs;
		
		std::vector<std::string> message;
		
		bool running;
		bool newaddress;
		bool newname;
		
		int fieldsize;
		int ships;
		
		int ship_x;
		int ship_y;
		int orientation;
		int shipnum;
		bool shipplaced;
		bool shipisplaced;
		bool alreadyplaced;
		
		bool wait;
		bool dowaiting;
		bool myturn;
		
		int bombhit;
		
		int youwin;
		
		unsigned char x;
		unsigned char y;
		
		std::string gegner;
		
		virtual void Run();
	public:
		Networkmanager();
		~Networkmanager();
		
		
		
		void saveAddress(int, sf::IPAddress, std::string);
		bool changeingNickname(std::string);
		Connectionstatus getConnectionstatus();
		void getGamelist(std::vector<std::string>&, std::vector<bool>&);
		void setInputs(GameInputs);
		Zustaende getGameStatus();
		bool newName(std::string&);
		void oldName();
		void joinGame(std::string);
		bool setShip(int&, int&, int&);
		bool myTurn();
		void bomb(int&, int&);
		int bombHit();
		sf::Vector2f getBomb();
		int win();
		std::vector<std::string> getMessages();
		
		void disconnect();
		
		
		
		void netmanagerloop();
		
		bool changeingNickname();
		
		bool preauth();
		bool auth();
		void waiting();
		void shipPlacement();
		void playing();
		void waitforinputs();
		
		unsigned char errorcoder();
		
		void waitforaddress();
		void waitforname();
		
};

#endif

