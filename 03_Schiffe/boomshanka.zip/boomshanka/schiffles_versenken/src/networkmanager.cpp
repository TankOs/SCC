#include "networkmanager.hpp"

#include <SFML/Network.hpp>

#include <iostream>



Networkmanager::Networkmanager()
{
	running=true;
	status=Disconnected;
	newname=false;
	newaddress=false;
	
	wait=false;
	dowaiting=false;
	
	inputs=None;
	
	shipnum=0;
	shipplaced=true;
	alreadyplaced=true;
	
	myturn=false;
	bombhit=0;
	
	youwin=0;
}


Networkmanager::~Networkmanager()
{
	
}


//---------------------------------------------------------------------------------------------------------------------//


 
void Networkmanager::saveAddress(int newport, sf::IPAddress newIPAddress, std::string newNickname)
{
	port=newport;
	address=newIPAddress;
	nickname=newNickname;
	newaddress=false;
}


bool Networkmanager::changeingNickname(std::string newnickname)
{
	packet << ChangeNickname << newnickname;
	client.Send(packet);
	packet.Clear();
	
	client.Receive(packet);
	packet >> msgid;
	
	if(msgid == AuthSuccessful)
		return true;
	
	//when nickname is not ok
	unsigned char errorcode;
	packet >> errorcode >> msg;
	std::cout << "Fehler #" << static_cast<int>(errorcode) << "bcvb: " << msg << std::endl;
	return false;
}


Networkmanager::Connectionstatus Networkmanager::getConnectionstatus()
{
	return status;
}



void Networkmanager::getGamelist(std::vector<std::string>& games, std::vector<bool>& activegames)
{
	wait=true;
	while(!dowaiting)
	{
		sf::Sleep(0.1f);
	}
	while(games.size()>0)
	{
		games.pop_back();
	}
	while(activegames.size()>0)
	{
		activegames.pop_back();
	}
	
	games.push_back("Irgendeinem Match beitreten");
	activegames.push_back(true);
	
	sf::Packet pack;
	pack<<ReqMatchInfoList;
	client.Send(pack);
	pack.Clear();
	client.Receive(pack);
	pack>>msgid;
	if(msgid==MatchInfoList)
	{
		unsigned int amount;
		unsigned char open;
		std::string spieler1, spieler2, beide;
		
		pack>>amount;
		while(amount>0)
		{
			pack>>open;
			if(static_cast<bool>(open))
			{
				pack>>spieler1;
				games.push_back(spieler1);
				activegames.push_back(true);
			}
			else//wenn spiel gestartet:
			{
				pack>>spieler1>>spieler2;
				beide=spieler1;
				beide+=" vs. ";
				beide+=spieler2;
				games.push_back(beide);
				activegames.push_back(false);
			}
			--amount;
		}
	}
	pack.Clear();
	wait=false;
}



void Networkmanager::setInputs(GameInputs input)
{
	inputs=input;
}



Networkmanager::Zustaende Networkmanager::getGameStatus()
{
	return zustand;
}


bool Networkmanager::newName(std::string& newnickname)
{
	nickname=newnickname;
	status=Nameless;
	newname=true;//verhindert leistungsverbrauch
	zustand=Auth;
	while(status!=Connected)
	{
		if (status==LoginFailed)
			return false;
		sleep(0.1f);
	}
	return true;
}


void Networkmanager::oldName()
{
	zustand=WaitForInputs;
	status=Connected;
}



void Networkmanager::disconnect()
{
	running=false;
	newaddress=true;
	newname=true;
	sf::Packet pack;
	switch (zustand)
	{
		case Playing:
		case ShipPlacement:
		case Waiting:
			pack<<LeaveMatch;
			client.Send(pack);
			pack.Clear();
		default:
			pack<<Quit;
			client.Send(pack);
			pack.Clear();
			break;			
	}
	
}



void Networkmanager::joinGame(std::string gegenspieler)
{
	if(gegenspieler=="Irgendeinem Match beitreten")
	{
		inputs=RandomMatch;
	}
	else
	{
		gegner=gegenspieler;
		inputs=Join;
	}
}



bool Networkmanager::setShip(int& x, int& y, int& richtung)
{
	ship_x=x;
	ship_y=y;
	if(richtung==0||richtung==2)
	{
		orientation=1;
	}
	else
	{
		orientation=0;//---------------------------------------------------------
	}
	shipplaced=false;
	while(!shipplaced)
	{
		sleep(0.1f);
	}
	if(shipisplaced)
	{
		++shipnum;
		return true;
	}
	else
	{
		return false;
	}
}


bool Networkmanager::myTurn()
{
	return myturn;
}


void Networkmanager::bomb(int& x, int& y)
{
	sf::Packet pack;
	pack<<DropBomb<<static_cast<unsigned char>(x-1)<<static_cast<unsigned char>(y-1);
	client.Send(pack);
	std::cout<<"Bombing on "<<x<<", "<<y<<std::endl;
}



int Networkmanager::bombHit()
{
	int bomb=bombhit;
	bombhit=0;
	return bomb;
}


sf::Vector2f Networkmanager::getBomb()
{
	return (sf::Vector2f(x, y));
	
}


int Networkmanager::win()
{
	int iwin=youwin;
	youwin=0;
	return iwin;
}



//---------------------------------------------------------------------------------------------------------------------//



void Networkmanager::Run()
{
	netmanagerloop();
}





void Networkmanager::netmanagerloop()
{
	zustand=Preauth;
	
	while(running)
	{
		switch (zustand)
		{
			case Preauth:
				if(preauth())
				{
					status=Nameless;
					zustand=Auth;
				}
				else
				{
					status=ConnectionFailed;
					newaddress=false;
					waitforaddress();
				}
				break;
				
			case Auth:
				if(auth())
				{
					zustand=WaitForInputs;
					status=Connected;
				}
				else
				{
					status=LoginFailed;
					newname=false;
					waitforname();
				}
				break;
				
			case Waiting:
				waiting();
				break;
				
			case ShipPlacement:
				shipPlacement();
				break;
				
			case Playing:
				playing();
				break;
			
			case WaitForInputs:
				waitforinputs();
				break;
			
		}
		
		packet.Clear();
		sf::Sleep(0.1f);
	}
}



bool Networkmanager::preauth()
{
	if(client.Connect(port, address) != sf::Socket::Done)
	{
		std::cout<<"Error: Could not connect to '"<<address<<"' on port "<<port<<std::endl;
		return false;
	}
	
	unsigned char  field, maxships;
	
	client.Receive(packet);
	packet >> msgid >> msg >> fieldsize >> maxships;
	
	std::cout << "Server: " << msg << std::endl;
	
	fieldsize=static_cast<int>(field);
	ships=static_cast<int>(maxships);
	
	message.push_back(msg);
	
	return true;
}


bool Networkmanager::auth()
{
	packet.Clear();
	packet << ChangeNickname << nickname;
	client.Send(packet);
	packet.Clear();
	
	do{
		oben:
		client.Receive(packet);
		packet >> msgid;
		if(msgid == AuthSuccessful)
		{
			return true;
			break;
		}
		else if( msgid == Error )
		{
			errorcoder();
			break;
		}
		else
		{
			std::cout<<"Fehler, unpassende MessageID: "<<msgid<<std::endl;
			packet.Clear();
		}
	}while(false);
	return false;
}



void Networkmanager::waiting()
{
	packet.Clear();
	client.SetBlocking(false);
	client.Receive(packet);
	client.SetBlocking(true);
	packet>>msgid;
	
	switch (msgid)
	{
		case SystemMessage:
			packet>>adder;
			message.push_back("Server: ");
			message[message.size()-1]+=adder;
			break;
			
		case MatchJoined:
			packet>>gegner;
			if(gegner!="")
			{
				zustand=ShipPlacement;
				adder+=gegner;
				adder+=".";
				message.push_back(adder);
			}
			break;
			
		case Error:
			errorcoder();
			break;
			
	}
	packet.Clear();
	if (inputs==Left)
	{
		packet<<LeaveMatch;
		client.Send(packet);
		packet.Clear();
		zustand=WaitForInputs;
	}
}


void Networkmanager::shipPlacement()
{
	packet.Clear();
	client.SetBlocking(false);
	client.Receive(packet);
	client.SetBlocking(true);
	packet>>msgid;
	
	switch (msgid)
	{
		case SystemMessage:
			packet>>adder;
			message.push_back("Server: ");
			message[message.size()-1]+=adder;
			break;
			
		case PlaceShip:
			shipisplaced=true;
			if(!alreadyplaced)
			{
				shipplaced=true;
				alreadyplaced=true;
			}
			break;
			
		case Error:
			shipisplaced=false;//
			if(errorcoder()==CannotPlaceShip)
				shipisplaced=false;
			if(!alreadyplaced)
			{
				shipplaced=true;
				alreadyplaced=true;
			}
			break;
			
		case GameStarts:
			zustand=Playing;
			shipnum=0;
			shipplaced=true;
			alreadyplaced=true;
			myturn=false;
			break;
		case MatchLeft:
			zustand=WaitForInputs;
			packet.Clear();
			packet<<LeaveMatch;
			client.Send(packet);
			packet.Clear();
			break;
	}
	msgid=0;
	packet.Clear();
	
	if(!shipplaced)
	{
		packet<<PlaceShip<<static_cast<unsigned char>(shipnum);
		packet<<static_cast<unsigned char>(ship_x-1)<<static_cast<unsigned char>(ship_y-1);
		packet<<static_cast<unsigned char>(orientation);
		client.Send(packet);
		alreadyplaced=false;
		
		std::cout<<ship_x<<" "<<ship_y<<" "<<orientation<<"\n";
	}
	inputs=None;
}


void Networkmanager::playing()
{
	packet.Clear();
//	client.SetBlocking(false);
	client.Receive(packet);
//	client.SetBlocking(true);
	packet>>msgid;
	
	switch(msgid)
	{
		case SystemMessage:
			
			break;
		case Error:
			errorcoder();
			break;
		case MatchLeft:
			zustand=WaitForInputs;
			packet.Clear();
			packet<<LeaveMatch;
			client.Send(packet);
			packet.Clear();
			break;
		case YourTurn:
			myturn=true;
			break;
		case YourTurnEnded:
			myturn=false;
			break;
		case BombHit:
			packet>>x>>y;
			bombhit=1;
			break;
		case BombMissed:
			packet>>x>>y;
			bombhit=2;
			break;
		case YouWin:
			youwin=1;
			zustand=WaitForInputs;
			break;
		case YouLose:
			youwin=2;
			zustand=WaitForInputs;
			break;
	}
	packet.Clear();
	msgid=0;
	inputs=None;
}



void Networkmanager::waitforinputs()
{
	while(wait)//FIXME noch nicht fertig
	{
		dowaiting=true;
		sf::Sleep(0.2f);
	}
	dowaiting=false;
	
	packet.Clear();
	client.SetBlocking(false);
	client.Receive(packet);
	client.SetBlocking(true);
	
	switch (msgid)
	{
		case SystemMessage:
			packet>>adder;
			message.push_back("Server: ");
			message[message.size()-1]+=adder;
			break;
			
		case AuthSuccessful:
			break;
			
		case Error:
			errorcoder();
			break;
			
	}
	packet.Clear();
	switch (inputs)
	{
		case NewMatch:
			packet<<CreateMatch;
			client.Send(packet);
			packet.Clear();
			zustand=Waiting;
			inputs=None;
			break;
		case RandomMatch:
			inputs=None;
			
			packet.Clear();
			packet<<JoinRandomMatch;
			client.Send(packet);
			packet.Clear();
			client.Receive(packet);
			packet>>msgid;
			while(msgid!=MatchJoined)
			{
				packet.Clear();
				packet<<JoinRandomMatch;
				client.Send(packet);
				packet.Clear();
				client.Receive(packet);
				packet>>msgid;
			}

			if(msgid==MatchJoined)
			{
				std::string who;
				packet>>who;
				
				if(who=="")
				{
					zustand=Waiting;
					message.push_back("Server hat ein neues Spiel erstellt, warte auf Spieler");
				}
				else
				{
					adder="Sie Spielen mit ";
					adder+=who;
					message.push_back(adder);
					
					zustand=ShipPlacement;
				}
			}
			break;
		case Join:
			packet<<JoinMatch<<gegner;
			client.Send(packet);
			packet.Clear();
			client.Receive(packet);
			packet>>msgid;
			if(msgid==MatchJoined)
			{
				std::string who;
				packet>>who;
				zustand=ShipPlacement;
					
				adder="Sie Spielen mit ";
				adder+=who;
				message.push_back(adder);
			}
			else
			{
				std::cout<<"Error";
			}
			inputs=None;
			break;
	}
	inputs=None;
	shipnum=0;
	packet.Clear();
}



unsigned char Networkmanager::errorcoder()
{
	unsigned char  errorcode;
	std::string msg;
	
	packet>>errorcode>>msg;
	std::cout<<"Fehler Nr ";
	switch(errorcode)
	{
		case Generic:
			std::cout<<"0 'Generic': ";
			break;
		case BadMessage:
			std::cout<<"1 'BadMessage': ";
			break;
		case NotAllowed:
			std::cout<<"2 'NotAllowed': ";
			break;
		case WrongStatus:
			std::cout<<"3 'WrongStatus': ";
			break;
		case CannotPlaceShip:
			std::cout<<"4 'CannotPlaceShip': ";
			break;
		case NotYourTurn:
			std::cout<<"5 'NotYourTurn': ";
			break;
		case AlreadyBombed:
			std::cout<<"6 'AlreadyBombed': ";
			break;
		case InvalidPosition:
			std::cout<<"7 'InvalidPosition': ";
			break;
		case UserlimitReached:
			std::cout<<"8 'UserlimitReached': ";
			break;
		case BadNickname:
			std::cout<<"9 'BadNickname': ";
			break;
		case MatchAlreadyStarted:
			std::cout<<"10 'MatchAlreadyStarted': ";
			break;
	}
	std::cout<<msg<<std::endl;
	return errorcode;
}



void Networkmanager::waitforaddress()
{
	while(!newaddress)
	{
		sf::Sleep(0.2f);
	}
}


void Networkmanager::waitforname()
{
	while(!newname)
	{
		sf::Sleep(0.2f);
	}
}





