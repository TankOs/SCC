#ifndef GAME_HPP
#define GAME_HPP

#include <iostream>

#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "mediamanager.hpp"
#include "enums.hpp"
#include "networkmanager.hpp"



class ClassGame : public Enums
{
	private:
		bool GameIsTrue;
		bool ClickIsTrue;
		
		int maus_x;
		int maus_y;
		
		float x;
		float y;
		
		int ship_x;
		int ship_y;
		
		int shipcounter;
		bool nextship;
		bool TurnShipIsTrue;
		int turnship;
		
		bool schiffeplatziert;
		
		int bombhit;
		
		std::vector<sf::Vector2f> gegner_wasser;
		std::vector<sf::Vector2f> gegner_treffer;
		std::vector<sf::Vector2f> spieler_wasser;
		std::vector<sf::Vector2f> spieler_treffer;
		
		sf::Sprite background;
		sf::Sprite spielfeld[2];
		sf::Sprite spielfeldhintergrund;
		
		sf::Sprite schiff[5];
		
		sf::Sprite explusion;
		sf::Sprite wather;
		
		sf::String turn;
	public:
		ClassGame();
		~ClassGame();
		
		void loop(sf::RenderWindow&, Mediamanager&, Gamestatus&, Networkmanager&);
		void gamemenu(sf::RenderWindow&);
		
		void shipPlacement(sf::RenderWindow&, Mediamanager&, Networkmanager&);
		void playing(sf::RenderWindow&, Mediamanager&, Networkmanager&);
		
		sf::Sprite getShipimage(Mediamanager&);
		void setShip(float&, float&);
};

#endif

