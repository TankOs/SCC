#ifndef __UTILS_HPP__
#define __UTILS_HPP__

#include <SFML/Graphics.hpp>

namespace utl {
	enum Alignment {
		AlignNone   = 0,
		AlignLeft   = 1,
		AlignCenter = 2,
		AlignRight  = 4,
		AlignTop    = 8,
		AlignMiddle = 16,
		AlignBottom = 32
	};

	void AlignStringInRect( sf::String &str, const sf::FloatRect &rect, int alignment );
	sf::FloatRect GetTargetRect( const sf::RenderTarget &target );
	sf::String CreateShadowString( const sf::String &original, float offset = 2.f, unsigned char alpha = 130 );
	void CenterOrigin( sf::Sprite &spr );
}

#endif
