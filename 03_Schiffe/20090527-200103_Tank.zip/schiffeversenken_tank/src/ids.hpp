#ifndef __IDS_HPP__
#define __IDS_HPP__

namespace id {
	enum ID {
		Connect = 0,
		Disconnect,
		Quit,
		Join,
		Create,
		Instant,
		Leave,
		Refresh,
		ScrollUp,
		ScrollDown,
		Invalid
	};
}

namespace idig {
	enum ID {
		Quit = 0,
		Music,
		Invalid
	};
}

#endif
