#ifndef __BUTTON_HPP__
#define __BUTTON_HPP__

#include <SFML/Graphics.hpp>

class Button {
	public:
		enum State {
			Normal = 0,
			Hover,
			Pressed,
			Last
		};

		Button( unsigned int id, const sf::String &text, const sf::Vector2i &position, sf::Image &image, const sf::Vector2i &offset = sf::Vector2i( 0, 0 ) );

		void Draw( sf::RenderTarget &target ) const;

		void ChangeState( State state );
		State GetState() const;
		bool TestCollision( const sf::Vector2i &point ) const;

		void SetVisible( bool visible );
		bool IsVisible() const;

		void SetText( const std::string &text );

		sf::Sprite &GetSprite();

	private:
		void Realign();

		unsigned int  m_id;
		bool          m_visible;

		sf::String    m_text;
		sf::String    m_shadow;
		sf::Vector2i  m_position;
		sf::Image     *m_image;
		sf::Vector2i  m_offset;
		State         m_state;

		sf::Sprite  m_button;
};

#endif
