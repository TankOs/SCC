#ifndef __GAMEBROWSERSTATE_HPP__
#define __GAMEBROWSERSTATE_HPP__

#include <vector>
#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include <SFML/System.hpp>

#include "state.hpp"
#include "button.hpp"
#include "signals.hpp"

class GameBrowserState : public State {
	public:
		GameBrowserState( sf::RenderTarget &target, sf::SocketTCP &conn, const std::string &nickname = std::string( "Pirate" ) );

		int Touch( float factor );
		void Render();
		bool HandleEvent( const sf::Event &event );

		unsigned char GetFieldsize() const;

		const std::string GetMyNickname() const;
		const std::string GetOtherNickname() const;
		
	private:
		static void ConnectToServer( void *data );
		void RefreshGameList();
		void FocusNickname( bool focus );
		void HandlePacket( sf::Packet packet );
		void ScrollMatchList( std::size_t pos );
		void UpdateButtons();

		sf::Clock  m_clock;

		sgn::Signal  m_signal;

		sf::SocketTCP  &m_conn;
		bool           m_connecting;
		bool           m_connected;

		bool  m_refreshing;
		bool  m_nickfocus;
		bool  m_waiting;

		unsigned char  m_fieldsize;

		sf::Thread  m_connectthread;

		sf::Font    m_fontsmall;
		sf::Font    m_fontbig;
		sf::String  m_statustext;
		sf::String  m_nickname;
		sf::String  m_lblnickname, m_lblnicknameshadow;
		sf::String  m_lblmatches, m_lblmatchesshadow;
		sf::String  m_lblwaiting;

		sf::Image   m_backgroundimage;
		sf::Image   m_refreshimage;
		sf::Sprite  m_background;
		sf::Sprite  m_refreshbutton;

		sf::SoundBuffer  m_keybuffer;
		sf::SoundBuffer  m_clickbuffer;
		sf::Sound        m_keysound;
		sf::Sound        m_clicksound;

		sf::Music  m_rockmusic;

		sf::Image            m_buttonimage;
		sf::Image            m_upbuttonimage;
		sf::Image            m_downbuttonimage;
		std::vector<Button>  m_buttons;

		sf::Shape                m_selectionbox;
		std::size_t              m_matchlistpos;
		std::size_t              m_selectedmatch;
		std::vector<sf::String>  m_matchlines;

		std::string  m_othernickname;
};

#endif
