#ifndef __STATE_HPP__
#define __STATE_HPP__

namespace sf {
	class RenderTarget;
	class Event;
}

#include <iostream>

class State {
	public:
		State( sf::RenderTarget &target );
		virtual ~State() {};
		virtual int Touch( float factor ) = 0;
		virtual void Render() = 0;
		virtual bool HandleEvent( const sf::Event &event ) = 0;

	protected:
		sf::RenderTarget  &m_target;
};

#endif
