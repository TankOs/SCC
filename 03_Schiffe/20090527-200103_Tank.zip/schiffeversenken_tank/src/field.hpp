#ifndef __FIELD_HPP__
#define __FIELD_HPP__

#include <vector>
#include <SFML/Graphics.hpp>

class Field {
	public:
		enum Status {
			Free = 0,
			Missed,
			Hit,
			Ship,
			Invalid
		};

		Field( unsigned char size, const sf::Vector2i &screenpos );

		void SetImages( sf::Image &markship, sf::Image &markmissed, sf::Image &markhit );
		void Clear();

		Status GetCellStatus( const sf::Vector2i &pos ) const;
		bool MarkCell( const sf::Vector2i &pos, Status status );
		bool PlaceShip( unsigned char shipid, const sf::Vector2i &pos, bool vertical = false );

		bool IsValidPosition( const sf::Vector2i &pos ) const;

		void Render( sf::RenderTarget &target );

	private:
		typedef std::vector<Status>  CellVector;

		CellVector  m_cells;

		unsigned char  m_fieldsize;
		sf::Vector2i   m_screenpos;

		sf::Sprite  m_markship;
		sf::Sprite  m_markmissed;
		sf::Sprite  m_markhit;
};

#endif
