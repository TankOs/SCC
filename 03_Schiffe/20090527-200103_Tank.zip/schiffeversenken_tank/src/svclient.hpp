#ifndef __SVCLIENT_HPP__
#define __SVCLIENT_HPP__

#include <SFML/Graphics.hpp>
#include <SFML/Network.hpp>

class State;

class SVClient {
	public:
		SVClient( const sf::VideoMode &mode );
		~SVClient();

		void Run();
		
	private:
		void ChangeState( State *newstate );

		sf::VideoMode     m_mode;
		sf::RenderWindow  m_window;

		sf::SocketTCP  m_socket;

		State  *m_state;
};

#endif
