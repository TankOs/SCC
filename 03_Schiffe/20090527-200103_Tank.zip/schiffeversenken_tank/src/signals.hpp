#ifndef __SIGNALS_HPP__
#define __SIGNALS_HPP__

namespace sgn {
	enum Signal {
		Continue = 0,
		Quit,
		Intro,
		GameBrowser,
		InGame
	};
}

#endif
