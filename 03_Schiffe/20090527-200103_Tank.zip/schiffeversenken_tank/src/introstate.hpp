#ifndef __INTROSTATE_HPP__
#define __INTROSTATE_HPP__

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include "state.hpp"

class IntroState : public State {
	public:
		IntroState( sf::RenderTarget &target );

		int Touch( float factor );
		void Render();
		bool HandleEvent( const sf::Event &event );
		
	private:
		sf::Clock   m_clock;

		bool   m_fadeout;
		float  m_fade;
		float  m_blink;
		float  m_blinkstep;

		sf::Font    m_burnstowfont;
		sf::String  m_title;
		sf::String  m_author;
		sf::String  m_hitenter;

		std::vector<sf::String>  m_shadows;

		sf::Image   m_backgroundimage;
		sf::Sprite  m_background;
		sf::Shape   m_whitebox;

		sf::SoundBuffer  m_bombbuffer;
		sf::SoundBuffer  m_sonarbuffer;
		sf::Sound        m_bomb;
		sf::Sound        m_sonar;
		sf::Music        m_oceanmusic;
};

#endif
