#include "state.hpp"

State::State( sf::RenderTarget &target ) :
	m_target( target )
{}
