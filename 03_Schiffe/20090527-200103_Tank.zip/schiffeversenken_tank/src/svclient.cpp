#include <iostream>
#include <typeinfo>
#include "svclient.hpp"
#include "signals.hpp"
#include "introstate.hpp"
#include "gamebrowserstate.hpp"
#include "ingamestate.hpp"

SVClient::SVClient( const sf::VideoMode &mode ) :
	m_mode( mode ),
	m_state( 0 )
{
}

SVClient::~SVClient() {
	ChangeState( 0 );
}

void SVClient::Run() {
	m_window.Create( m_mode, "Ship Bomber (By Tank)" );
	if( !m_window.IsOpened() ) {
		std::cerr << "Fatal error: Could not create window with resolution "
			<< m_mode.Width << "*" << m_mode.Height << "*" << m_mode.BitsPerPixel << "." << std::endl;
		return;
	}

	// Window intialization.
	m_window.SetFramerateLimit( 60 );

	//ChangeState( new GameBrowserState( m_window, m_socket ) );
	ChangeState( new IntroState( m_window ) );

	while( m_window.IsOpened() ) {
		sf::Event  event;

		while( m_window.GetEvent( event ) ) {
			if( !m_state->HandleEvent( event ) ) {
				switch( event.Type ) {
					case sf::Event::Closed:
						m_window.Close();
						break;

					case sf::Event::KeyPressed:
						if( event.Key.Code == sf::Key::Escape ) { // TODO: Remove this hook!
							m_window.Close();
						}
						break;

					default:
						break;
				}
			}
		}

		// Logic.
		switch( m_state->Touch( m_window.GetFrameTime() ) ) {
			case sgn::Continue:
				break;

			case sgn::GameBrowser:
				{
					std::string  nick( "Pirate" );

					if( typeid( *m_state ) == typeid( InGameState ) ) {
						InGameState  *igs( reinterpret_cast<InGameState*>( m_state ) );
						nick = igs->GetMyNickname();
					}

					ChangeState( new GameBrowserState( m_window, m_socket, nick ) );
				}
				break;

			case sgn::InGame:
				{
					// Current state is GameBrowser, fetch fieldsize.
					GameBrowserState  *gb( reinterpret_cast<GameBrowserState*>( m_state ) );
					unsigned char     fieldsize( gb->GetFieldsize() );
					ChangeState( new InGameState( m_window, m_socket, fieldsize, gb->GetMyNickname(), gb->GetOtherNickname() ) );
				}
				break;

			case sgn::Quit:
				m_window.Close();
				break;

			default:
				break;
		}

		// Rendering.
		m_window.Clear();
		m_state->Render();
		m_window.Display();
	}

	ChangeState( 0 );
}

void SVClient::ChangeState( State *newstate ) {
	if( m_state != 0 ) {
		delete m_state;
		m_state = 0;
	}

	if( newstate != 0 ) {
		m_state = newstate;
	}
}

int main( void ) {
	SVClient  client( sf::VideoMode( 1024, 768, 32 ) );

	client.Run();
	return 0;
}
