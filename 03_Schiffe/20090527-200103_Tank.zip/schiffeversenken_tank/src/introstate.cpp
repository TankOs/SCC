#include <sstream>
#include <iostream>
#include "introstate.hpp"
#include "signals.hpp"
#include "utils.hpp"

IntroState::IntroState( sf::RenderTarget &target ) :
	State( target ),
	m_fadeout( false ),
	m_fade( 0.f ),
	m_blink( 0.f ),
	m_blinkstep( 1.f ),
	m_title( "Ship Bomber", sf::Font::GetDefaultFont(), 100.f ),
	m_author( "By Tank, 2009", sf::Font::GetDefaultFont(), 50.f ),
	m_hitenter( "Hit Enter to continue", sf::Font::GetDefaultFont(), 50.f ),
	m_whitebox( sf::Shape::Rectangle( 0, 0, target.GetWidth(), target.GetHeight(), sf::Color( 255, 255, 255, 255 ) ) )
{
	// Fonts and strings.
	m_burnstowfont.LoadFromFile( "media/fonts/blackcastle.ttf", 100 );
	m_title.SetFont( m_burnstowfont );
	m_author.SetFont( m_burnstowfont );
	m_hitenter.SetFont( m_burnstowfont );
	m_hitenter.SetColor( sf::Color( 255, 0, 0 ) );

	utl::AlignStringInRect( m_title, utl::GetTargetRect( m_target ), utl::AlignCenter | utl::AlignMiddle );
	utl::AlignStringInRect( m_author, utl::GetTargetRect( m_target ), utl::AlignCenter | utl::AlignMiddle );
	utl::AlignStringInRect( m_hitenter, utl::GetTargetRect( m_target ), utl::AlignCenter | utl::AlignBottom );
	m_title.Move( 0, -100.f );
	m_hitenter.Move( 0, -30.f );

	m_shadows.push_back( utl::CreateShadowString( m_title ) );
	m_shadows.push_back( utl::CreateShadowString( m_author ) );
	m_shadows.push_back( utl::CreateShadowString( m_hitenter ) );

	// Images and sprites.
	m_backgroundimage.LoadFromFile( "media/images/underwater.jpg" );
	m_background.SetImage( m_backgroundimage );

	// Sounds.
	m_bombbuffer.LoadFromFile( "media/sfx/introbomb.ogg" );
	m_sonarbuffer.LoadFromFile( "media/sfx/sonar.ogg" );
	m_bomb.SetBuffer( m_bombbuffer );
	m_sonar.SetBuffer( m_sonarbuffer );

	m_sonar.SetLoop( true );
	m_sonar.Play();

	// Music.
	m_oceanmusic.OpenFromFile( "media/sfx/ocean.ogg" );
	//m_oceanmusic.Play();
}

int IntroState::Touch( float factor ) {
	if( m_clock.GetElapsedTime() < 6.f ) {
		return sgn::Continue;
	}
	else if( m_oceanmusic.GetStatus() != sf::Music::Playing && !m_fadeout ) {
		m_oceanmusic.Play();
	}

	if( !m_fadeout ) {
		m_fade += factor * 30.f;

		if( m_fade > 255.f ) {
			m_fade = 255.f;
		}
	}
	else {
		m_fade -= factor * 50.f;

		if( m_fade < 0.f ) {
			return sgn::GameBrowser;
		}
	}

	m_blink += m_blinkstep * (factor * 500.f );
	if( m_blink > 255.f ) {
		m_blink = 255.f;
		m_blinkstep = -m_blinkstep;
	}
	else if( m_blink < 100.f ) {
		m_blink = 100.f;
		m_blinkstep = -m_blinkstep;
	}

	return sgn::Continue;
}

void IntroState::Render() {
	sf::Color  col( 255, 255, 255, 255 );

	if( m_fadeout == false ) {
		col.a = m_fade;
		m_background.SetColor( col );

		col = m_hitenter.GetColor();
		col.a = m_blink;
		m_hitenter.SetColor( col );

		m_target.Draw( m_background );

		if( m_fade == 255.f ) {
			for( unsigned int shadowid = 0; shadowid < m_shadows.size(); ++shadowid ) {
				m_target.Draw( m_shadows[shadowid] );
			}

			m_target.Draw( m_title );
			m_target.Draw( m_author );
			m_target.Draw( m_hitenter );
		}
	}
	else {
		col = m_whitebox.GetColor();
		col.a = m_fade;
		m_whitebox.SetColor( col );

		m_target.Draw( m_whitebox );
	}
}

bool IntroState::HandleEvent( const sf::Event &event ) {
	bool  handled( false );

	if( event.Type == sf::Event::KeyPressed && event.Key.Code == sf::Key::Return ) {
		handled = true;

		if( m_fadeout == false ) {
			m_oceanmusic.Stop();
			m_sonar.Stop();
			m_bomb.Play();
			m_fadeout = true;
			m_fade = 255.f;
		}
	}

	return handled;
}
