#include <string>
#include <sstream>
#include "utils.hpp"
#include "button.hpp"
#include "ids.hpp"
#include "protocol.hpp"
#include "ingamestate.hpp"

const sf::Vector2i  FIELD_OWN_OFFSET( 60, 223 );
const sf::Vector2i  FIELD_OPP_OFFSET( 570, 223 );

InGameState::InGameState( sf::RenderTarget &target, sf::SocketTCP &conn, unsigned char fieldsize, const std::string &mynick, const std::string &othernick ) :
	State( target ),
	m_signal( sgn::Continue ),
	m_conn( conn ),
	m_surrendered( false ),
	m_playmusic( true ),
	m_wasmyturn( false ),
	m_playstate( PSShipPlacement ),
	m_placevertical( false ),
	m_shiplength( 2 ),
	m_selectedcell( -1, -1 ),
	m_fieldsize( fieldsize ),
	m_ownfield( fieldsize, FIELD_OWN_OFFSET ),
	m_oppfield( fieldsize, FIELD_OPP_OFFSET ),
	m_statustext( "Please place your ships. Right mouse button to rotate the ship, left mouse button to place." ),
	m_mynickname( mynick ),
	m_othernickname( othernick )
{
	// Fonts and strings.
	m_fontsmall.LoadFromFile( "media/fonts/blackcastle.ttf", 18.f );
	m_fontbig.LoadFromFile( "media/fonts/blackcastle.ttf", 36.f );

	m_statustext.SetFont( m_fontsmall );
	m_statustext.SetSize( 18.f );
	m_mynickname.SetFont( m_fontbig );
	m_mynickname.SetSize( 36.f );
	m_othernickname.SetFont( m_fontbig );
	m_othernickname.SetSize( 36.f );
	m_othernickname.SetColor( sf::Color( 255, 0, 0 ) );

	utl::AlignStringInRect( m_statustext, utl::GetTargetRect( m_target ), utl::AlignBottom );
	utl::AlignStringInRect( m_mynickname, sf::FloatRect( 0, 80, 512, 130 ), utl::AlignCenter | utl::AlignMiddle );
	utl::AlignStringInRect( m_othernickname, sf::FloatRect( 512, 80, 1024, 130 ), utl::AlignCenter | utl::AlignMiddle );

	m_statustext.Move( 7.f, -5.f );

	// Images and sprites.
	m_imgbackground.LoadFromFile( "media/images/ingame.png" );
	m_imgwoodbutton.LoadFromFile( "media/images/woodbutton.png" );
	m_imgmarkship.LoadFromFile( "media/images/mark_cross.png" );
	m_imgmarkmissed.LoadFromFile( "media/images/mark_missed.png" );
	m_imgmarkhit.LoadFromFile( "media/images/mark_hit.png" );

	m_imgquad.Create( m_imgmarkship.GetWidth(), m_imgmarkship.GetHeight(), sf::Color( 255, 255, 255 ) );

	m_imgbackground.SetSmooth( false );
	m_imgwoodbutton.SetSmooth( false );

	m_background.SetImage( m_imgbackground );
	m_selbox.SetImage( m_imgquad );

	// Buttons.
	m_buttons.push_back( Button( idig::Quit, sf::String( "Surrender", m_fontbig, 36.0f ), sf::Vector2i( 10, 10 ), m_imgwoodbutton, sf::Vector2i( 0, -5 ) ) );
	m_buttons.push_back( Button( idig::Music, sf::String( "No music", m_fontbig, 36.0f ), sf::Vector2i( 205, 10 ), m_imgwoodbutton, sf::Vector2i( 0, -5 ) ) );

	// Sounds and music.
	m_bufclick.LoadFromFile( "media/sfx/click.ogg" );
	m_bufsplash.LoadFromFile( "media/sfx/splash.ogg" );
	m_bufexplosion.LoadFromFile( "media/sfx/explosion.ogg" );
	m_buflost.LoadFromFile( "media/sfx/lost.ogg" );
	m_bufwon.LoadFromFile( "media/sfx/won.ogg" );

	m_sndclick.SetBuffer( m_bufclick );
	m_sndsplash.SetBuffer( m_bufsplash );
	m_sndexplosion.SetBuffer( m_bufexplosion );
	m_sndlost.SetBuffer( m_buflost );
	m_sndwon.SetBuffer( m_bufwon );

	m_mscthesailor.OpenFromFile( "media/sfx/thesailor.ogg" );
	m_mscthesailor.SetLoop( true );
	m_mscthesailor.Play();

	// Fields.
	m_ownfield.SetImages( m_imgmarkship, m_imgmarkmissed, m_imgmarkhit );
	m_oppfield.SetImages( m_imgmarkship, m_imgmarkmissed, m_imgmarkhit );
}

int InGameState::Touch( float /*factor*/ ) {
	// Check for incoming packets.
	sf::Packet          packet;
	sf::Socket::Status  status( m_conn.Receive( packet ) );

	if( status == sf::Socket::Done ) {
		HandlePacket( packet );
	}
	else if( status == sf::Socket::Disconnected ) {
		m_statustext.SetText( "The server disconnected me!" );
		m_surrendered = true;
		m_buttons[idig::Quit].SetText( "Leave" );
		return m_signal;
	}

	return m_signal;
}

void InGameState::Render() {
	m_target.Draw( m_background );

	for( std::size_t buttonid = 0; buttonid < m_buttons.size(); ++buttonid ) {
		m_buttons[buttonid].Draw( m_target );
	}

	m_ownfield.Render( m_target );
	m_oppfield.Render( m_target );

	if( m_selectedcell.x != -1 ) {
		m_target.Draw( m_selbox );
	}

	m_target.Draw( m_mynickname );
	m_target.Draw( m_othernickname );
	m_target.Draw( m_statustext );
}

bool InGameState::HandleEvent( const sf::Event &event ) {
	switch( event.Type ) {
		case sf::Event::MouseButtonReleased:
			{
				// Ship placement stuff.
				if( m_playstate == PSShipPlacement ) {
					if( event.MouseButton.Button == sf::Mouse::Right ) {
						m_placevertical = !m_placevertical;
						UpdateSelectionBox( m_selectedcell, true );
						m_sndclick.Play();
						break;
					}
					else if( event.MouseButton.Button == sf::Mouse::Left ) {
						if( m_ownfield.PlaceShip( m_shiplength - 2, m_selectedcell, m_placevertical ) ) {
							sf::Packet  pkt;

							pkt << prot::PlaceShip
								<< static_cast<unsigned char>( m_shiplength - 2 )
								<< static_cast<unsigned char>( m_selectedcell.x )
								<< static_cast<unsigned char>( m_selectedcell.y )
								<< static_cast<unsigned char>( m_placevertical ? 1 : 0 );

							m_conn.Send( pkt );

							m_sndclick.Play();
							++m_shiplength;
							m_selectedcell = sf::Vector2i( -1, -1 );
							m_playstate = PSBlocked;
						}
					}
				}
				else if( m_playstate == PSTurn && m_selectedcell.x != -1 ) {
					if( m_oppfield.GetCellStatus( m_selectedcell ) != Field::Free ) {
						break;
					}

					sf::Packet  pkt;
					pkt << prot::DropBomb 
						<< static_cast<unsigned char>( m_selectedcell.x )
						<< static_cast<unsigned char>( m_selectedcell.y );

					m_conn.Send( pkt );
					m_playstate = PSBlocked;
					m_selectedcell = sf::Vector2i( -1, -1 );
					m_wasmyturn = true;
				}

				// Check for buttons.
				for( unsigned int buttonid = 0; buttonid < m_buttons.size(); ++buttonid ) {
					if( !m_buttons[buttonid].TestCollision( sf::Vector2i( event.MouseButton.X, event.MouseButton.Y ) ) ) {
						continue;
					}

					bool  clicked( false );

					switch( buttonid ) {
						case idig::Music:
							m_playmusic = !m_playmusic;
							if( m_playmusic ) {
								m_mscthesailor.Play();
								m_buttons[idig::Music].SetText( "No music" );
							}
							else {
								m_mscthesailor.Stop();
								m_buttons[idig::Music].SetText( "Music" );
							}

							clicked = true;
							break;

						case idig::Quit:
							{
								if( !m_surrendered ) {
									m_conn.Close();
									m_surrendered = true;
									m_buttons[idig::Quit].SetText( "Leave" );
									UpdateButtons();
								}
								else {
									m_signal = sgn::GameBrowser;
								}

								clicked = true;
							}
							break;

						default:
							break;
					}

					if( clicked ) {
						m_sndclick.Play();
						UpdateButtons();
					}

				}
			}
			return true;

		case sf::Event::MouseMoved:
			{
				sf::Vector2i  mouse( event.MouseMove.X, event.MouseMove.Y );

				for( std::size_t buttonid = 0; buttonid < m_buttons.size(); ++buttonid ) {
					bool  result = m_buttons[buttonid].TestCollision( mouse );

					if( m_buttons[buttonid].GetState() == Button::Normal && result ) {
						m_buttons[buttonid].ChangeState( Button::Hover );
					}
					else if( m_buttons[buttonid].GetState() == Button::Hover && !result ) {
						m_buttons[buttonid].ChangeState( Button::Normal );
					}
				}

				if( m_playstate == PSShipPlacement ) {
					sf::Vector2i  newcellpos(
						(mouse.x - FIELD_OWN_OFFSET.x) / m_imgmarkship.GetWidth(),
						(mouse.y - FIELD_OWN_OFFSET.y) / m_imgmarkship.GetHeight()
					);

					UpdateSelectionBox( newcellpos );
				}
				else if( m_playstate == PSTurn ) {
					sf::Vector2i  newcellpos(
						(mouse.x - FIELD_OPP_OFFSET.x) / m_imgmarkship.GetWidth(),
						(mouse.y - FIELD_OPP_OFFSET.y) / m_imgmarkship.GetHeight()
					);

					UpdateSelectionBox( newcellpos );
				}
			}

			return true;

		default:
			break;
	}

	return false;
}

void InGameState::UpdateButtons() {
}

void InGameState::UpdateSelectionBox( const sf::Vector2i &newpos, bool force ) {
	if( (newpos == m_selectedcell && !force) || m_surrendered ) {
		return;
	}

	if( m_playstate == PSTurn ) {
		if( m_oppfield.IsValidPosition( newpos ) ) {
			m_selectedcell = newpos;

			m_imgquad.Create( m_imgmarkship.GetWidth(), m_imgmarkship.GetHeight(), sf::Color( 255, 255, 255 ) );
			m_selbox.SetImage( m_imgquad );
			m_selbox.SetSubRect( sf::IntRect( 0, 0, m_imgquad.GetWidth(), m_imgquad.GetHeight() ) );
			m_selbox.SetPosition(
				FIELD_OPP_OFFSET.x + m_selectedcell.x * m_imgmarkship.GetWidth(),
				FIELD_OPP_OFFSET.y + m_selectedcell.y * m_imgmarkship.GetHeight()
			);

			if( m_oppfield.GetCellStatus( sf::Vector2i( newpos.x, newpos.y ) ) != Field::Free ) {
				m_selbox.SetColor( sf::Color( 255, 0, 0, 100 ) );
			}
			else {
				m_selbox.SetColor( sf::Color( 0, 255, 0, 100 ) );
			}
		}
		else {
			m_selectedcell = sf::Vector2i( -1, -1 );
		}
	}
	else if( m_playstate == PSShipPlacement ) {
		sf::Vector2i  targetpos(
			newpos.x + (m_placevertical ? 0 : m_shiplength - 1),
			newpos.y + (m_placevertical ? m_shiplength - 1 : 0 )
		);

		if( m_ownfield.IsValidPosition( newpos ) ) {
			m_selectedcell = newpos;

			unsigned char  cellsize( m_shiplength );
			if( !m_placevertical && targetpos.x >= m_fieldsize ) {
				cellsize = m_fieldsize - newpos.x;
			}
			else if( m_placevertical && targetpos.y >= m_fieldsize ) {
				cellsize = m_fieldsize - newpos.y;
			}

			m_imgquad.Create(
				(m_placevertical ? m_imgmarkship.GetWidth() : m_imgmarkship.GetWidth() * cellsize),
				(m_placevertical ? m_imgmarkship.GetHeight() * cellsize : m_imgmarkship.GetHeight()),
				sf::Color( 255, 255, 255 )
			);

			m_selbox.SetImage( m_imgquad );
			m_selbox.SetSubRect( sf::IntRect( 0, 0, m_imgquad.GetWidth(), m_imgquad.GetHeight() ) );

			m_selbox.SetPosition(
				FIELD_OWN_OFFSET.x + m_selectedcell.x * m_imgmarkship.GetWidth(),
				FIELD_OWN_OFFSET.y + m_selectedcell.y * m_imgmarkship.GetHeight()
			);

			bool  valid( true );

			if( !m_ownfield.IsValidPosition( targetpos ) ) {
				valid = false;
			}
			else {
				for( unsigned char delta = 0; delta < m_shiplength; ++delta ) {
					sf::Vector2i  dpos( (m_placevertical ? newpos.x : newpos.x + delta), (m_placevertical ? newpos.y + delta : newpos.y) );

					if( m_ownfield.GetCellStatus( dpos ) != Field::Free ) {
						valid = false;
						break;
					}
				}
			}

			if( valid ) {
				m_selbox.SetColor( sf::Color( 0, 255, 0, 100 ) );
			}
			else {
				m_selbox.SetColor( sf::Color( 255, 0, 0, 100 ) );
			}
		}
		else {
			m_selectedcell = sf::Vector2i( -1, -1 );
		}
	}
}

void InGameState::HandlePacket( sf::Packet packet ) {
	unsigned int  msgid( prot::Last );
	bool          missed( true );

	packet >> msgid;

	switch( msgid ) {
		case prot::PlaceShip:
			m_playstate = PSShipPlacement;
			break;

		case prot::PlacementComplete:
			m_playstate = PSBlocked;
			m_selectedcell = sf::Vector2i( -1, -1 );
			m_statustext.SetText( "All ships placed. Waiting for opponent to finish..." );
			break;

		case prot::GameStarts:
			m_statustext.SetText( "The game starts!" );
			break;

		case prot::Error:
			{
				unsigned char      errnum;
				std::string        errmsg;
				std::stringstream  sstr;

				packet >> errnum >> errmsg;

				sstr << "Error #" << static_cast<int>( errnum ) << ": " << errmsg;
				m_statustext.SetText( sstr.str() );
			}
			break;

		case prot::BombHit:
			missed = false;

		case prot::BombMissed:
			{
				unsigned char  x, y;

				packet >> x >> y;
				(!m_wasmyturn ? m_ownfield : m_oppfield).MarkCell( sf::Vector2i( x, y ), (missed ? Field::Missed : Field::Hit) );
				(missed ? m_sndsplash : m_sndexplosion).Play();

				m_wasmyturn = false;
			}
			break;

		case prot::YourTurn:
			m_selectedcell = sf::Vector2i( -1, -1 );
			m_playstate = PSTurn;
			m_statustext.SetText( "It's your turn. Please drop a bomb!" );
			break;

		case prot::YouWin:
		case prot::YouLose:
			m_statustext.SetText( msgid == prot::YouWin ? "You won!" : "You lost!" );

			m_playstate = PSBlocked;
			(msgid == prot::YouWin ? m_sndwon : m_sndlost).Play();

			m_buttons[idig::Quit].SetText( "Leave" );
			m_buttons[idig::Music].SetText( "Music" );
			m_playmusic = false;
			m_surrendered = true;
			m_mscthesailor.Stop();
			m_conn.Close();
			break;

		case prot::MatchLeft:
			m_statustext.SetText( "The opponent left the match." );
			m_playstate = PSBlocked;

			m_buttons[idig::Quit].SetText( "Leave" );
			m_buttons[idig::Music].SetText( "Music" );
			m_playmusic = false;
			m_surrendered = true;
			m_mscthesailor.Stop();
			m_conn.Close();
			break;

		default:
			break;
	}
}

const std::string InGameState::GetMyNickname() const {
	return m_mynickname.GetText();
}
