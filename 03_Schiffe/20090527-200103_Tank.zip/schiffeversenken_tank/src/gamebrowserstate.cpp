#include <iostream>
#include <sstream>
#include <limits>
#include "utils.hpp"
#include "gamebrowserstate.hpp"
#include "protocol.hpp"
#include "ids.hpp"

const std::size_t  MAX_MATCHES = 19;
const std::size_t  MAX_SIZET( std::numeric_limits<std::size_t>::max() );

GameBrowserState::GameBrowserState( sf::RenderTarget &target, sf::SocketTCP &conn, const std::string &nickname ) :
	State( target ),
	m_signal( sgn::Continue ),
	m_conn( conn ),
	m_connecting( false ),
	m_connected( false ),
	m_refreshing( false ),
	m_nickfocus( false ),
	m_waiting( false ),
	m_fieldsize( 0 ),
	m_connectthread( &GameBrowserState::ConnectToServer, this ),
	m_statustext( "Please enter your nickname and click on \"Connect\" to play." ),
	m_nickname( nickname ),
	m_matchlistpos( 0 ),
	m_selectedmatch( MAX_SIZET )
{
	m_fontsmall.LoadFromFile( "media/fonts/blackcastle.ttf", 18.f );
	m_fontbig.LoadFromFile( "media/fonts/blackcastle.ttf", 36.f );

	m_statustext.SetFont( m_fontsmall );
	m_statustext.SetSize( 18.f );

	utl::AlignStringInRect( m_statustext, utl::GetTargetRect( m_target ), utl::AlignBottom );
	m_statustext.Move( 7.f, -5.f );

	m_nickname.SetFont( m_fontbig );
	m_nickname.SetSize( 36.0f );
	m_nickname.SetPosition( 235, 80 );

	m_lblnickname = m_lblmatches = m_lblwaiting = m_nickname;
	m_lblnickname.SetText( "Enter nickname:" );
	m_lblnickname.SetPosition( 222, 40 );
	m_lblmatches.SetText( "Available matches:" );
	m_lblmatches.SetPosition( 222, 140 );
	m_lblwaiting.SetText( "Waiting for an opponent..." );
	utl::AlignStringInRect( m_lblwaiting, utl::GetTargetRect( m_target ), utl::AlignCenter | utl::AlignBottom );
	m_lblwaiting.Move( 0, -m_lblwaiting.GetRect().GetHeight() );

	m_lblnicknameshadow = utl::CreateShadowString( m_lblnickname );
	m_lblmatchesshadow = utl::CreateShadowString( m_lblmatches );

	m_backgroundimage.LoadFromFile( "media/images/browser.png" );
	m_refreshimage.LoadFromFile( "media/images/refresh.png" );

	m_background.SetImage( m_backgroundimage );
	m_refreshbutton.SetImage( m_refreshimage );
	m_refreshbutton.SetPosition( sf::Vector2f( 184, 229 ) );
	m_refreshbutton.SetSubRect( sf::IntRect( 0, 0, 48, 48 ) );
	m_refreshbutton.SetCenter( 24, 24 );

	// Setup buttons.
	m_buttonimage.LoadFromFile( "media/images/button.png" );
	m_upbuttonimage.LoadFromFile( "media/images/upbutton.png" );
	m_downbuttonimage.LoadFromFile( "media/images/downbutton.png" );

	m_buttons.push_back( Button( id::Connect, sf::String( "Connect", m_fontbig, 36.0f ), sf::Vector2i( 817, 183 ), m_buttonimage, sf::Vector2i( -4, -8 ) ) );
	m_buttons.push_back( Button( id::Disconnect, sf::String( "Disconnect", m_fontbig, 36.0f ), sf::Vector2i( 817, 183 ), m_buttonimage, sf::Vector2i( -4, -8 ) ) );
	m_buttons.push_back( Button( id::Quit, sf::String( "Quit game", m_fontbig, 36.0f ), sf::Vector2i( 817, 250 ), m_buttonimage, sf::Vector2i( -4, -8 ) ) );
	m_buttons.push_back( Button( id::Join, sf::String( "Join", m_fontbig, 36.0f ), sf::Vector2i( 422, 600 ), m_buttonimage, sf::Vector2i( -4, -8 ) ) );
	m_buttons.push_back( Button( id::Create, sf::String( "Create", m_fontbig, 36.0f ), sf::Vector2i( 222, 600 ), m_buttonimage, sf::Vector2i( -4, -8 ) ) );
	m_buttons.push_back( Button( id::Instant, sf::String( "Instant!", m_fontbig, 36.0f ), sf::Vector2i( 622, 600 ), m_buttonimage, sf::Vector2i( -4, -8 ) ) );
	m_buttons.push_back( Button( id::Leave, sf::String( "Leave", m_fontbig, 36.0f ), sf::Vector2i( 422, 600 ), m_buttonimage, sf::Vector2i( -4, -8 ) ) );
	m_buttons.push_back( Button( id::Refresh, sf::String( "", m_fontbig, 36.0f ), sf::Vector2i( 160, 205 ), m_refreshimage ) );

	m_buttons.push_back( Button( id::ScrollUp, sf::String( "", m_fontbig, 30.0f ), sf::Vector2i( 755, 185 ), m_upbuttonimage ) );
	m_buttons.push_back( Button( id::ScrollDown, sf::String( "", m_fontbig, 30.0f ), sf::Vector2i( 755, 535 ), m_downbuttonimage ) );

	// Misc.
	m_selectionbox = sf::Shape::Rectangle( 0, 0, 580, 20, sf::Color( 120, 120, 120 ) );

	// Sounds & music.
	m_keybuffer.LoadFromFile( "media/sfx/key.ogg" );
	m_clickbuffer.LoadFromFile( "media/sfx/click.ogg" );
	m_keysound.SetBuffer( m_keybuffer );
	m_clicksound.SetBuffer( m_clickbuffer );

	m_rockmusic.OpenFromFile( "media/sfx/ipray.ogg" );
	m_rockmusic.SetLoop( true );
	m_rockmusic.Play();

	// Init GUI.
	UpdateButtons();
}

void GameBrowserState::ConnectToServer( void *data ) {
	GameBrowserState  *th( reinterpret_cast<GameBrowserState*>( data ) );

	th->m_statustext.SetText( "Connecting..." );
	th->m_nickname.SetColor( sf::Color( 120, 120, 120 ) );

	th->m_conn.SetBlocking( true );

	if( th->m_conn.Connect( 10500, "boxbox.org" ) == sf::Socket::Done ) {
		th->m_connected = true;
		th->m_statustext.SetText( "Connection to server established!" );
		th->m_conn.SetBlocking( false );

		// Authenticate.
		sf::Packet  pkt;
		pkt << prot::ChangeNickname << static_cast<std::string>( th->m_nickname.GetText() );
		th->m_conn.Send( pkt );
	}
	else {
		th->m_connected = false;
		th->m_statustext.SetText( "Connecting...failed!" );
		th->m_nickname.SetColor( sf::Color( 255, 255, 255 ) );
	}

	th->m_connecting = false;
}

int GameBrowserState::Touch( float factor ) {
	if( m_connected ) {
		// Check for incoming packets.
		sf::Packet  packet;
		if( m_conn.Receive( packet ) == sf::Socket::Done ) {
			HandlePacket( packet );
		}
	}

	if( m_refreshing ) {
		m_refreshbutton.Rotate( -800.f * factor );
	}

	return m_signal;
}

bool GameBrowserState::HandleEvent( const sf::Event &event ) {
	switch( event.Type ) {
		case sf::Event::KeyPressed:
			if( m_nickfocus ) {
				// Check for alphanumeric characters.
				if( (event.Key.Code >= sf::Key::A && event.Key.Code <= sf::Key::Z) ||
						(event.Key.Code >= sf::Key::Num0 && event.Key.Code <= sf::Key::Num9) ) {

					std::string  nick( m_nickname.GetText() );

					if( nick.size() < 16 ) {
						char         ch( event.Key.Code );

						if( event.Key.Shift == true ) {
							ch += 'A' - 'a';
						}

						nick += ch;
						m_nickname.SetText( nick );
						m_keysound.Play();
					}
				}
				else if( event.Key.Code == sf::Key::Back && static_cast<std::string>( m_nickname.GetText() ).size() > 0 ) {
					std::string  nick( m_nickname.GetText() );
					nick.erase( nick.size() - 1 );
					m_nickname.SetText( nick );
					m_keysound.Play();
				}
				else if( event.Key.Code == sf::Key::Return ) {
					FocusNickname( false );
				}
			}
			return true;

		case sf::Event::MouseButtonReleased:
			{
				// Check if match was clicked.
				if( m_connected && m_matchlines.size() > 0 &&
						event.MouseButton.X >= 222 && event.MouseButton.Y >= 190 &&
						event.MouseButton.X <= 742 && event.MouseButton.Y <= 190 + (static_cast<int>( MAX_MATCHES ) * 20) ) {
					std::size_t  org( m_selectedmatch );

					m_selectedmatch = m_matchlistpos + ((event.MouseButton.Y - 190) / 20.f);
					if( m_selectedmatch >= m_matchlines.size() ) {
						m_selectedmatch = org;
					}
					else {
						ScrollMatchList( m_matchlistpos );
						m_clicksound.Play();
					}

					return true;
				}

				if( event.MouseButton.X >= 222 && event.MouseButton.Y >= 84 &&
						event.MouseButton.X <= 802 && event.MouseButton.Y <= 124 &&
						!m_nickfocus && !m_connected ) {
					FocusNickname( true );
					return true;
				}

				// Check for buttons.
				for( unsigned int buttonid = 0; buttonid < m_buttons.size(); ++buttonid ) {
					if( !m_buttons[buttonid].TestCollision( sf::Vector2i( event.MouseButton.X, event.MouseButton.Y ) ) ) {
						continue;
					}

					bool  clicked( false );

					switch( buttonid ) {
						case id::Quit:
							m_signal = sgn::Quit;
							clicked = true;
							break;

						case id::Join:
							{
								std::string  line( m_matchlines[m_selectedmatch].GetText() );
								std::size_t  pos( line.find( " (open)" ) );

								if( pos == std::string::npos ) {
									m_statustext.SetText( "You can only join open matches." );
								}
								else {
									std::string  opponent( line.substr( 0, pos ) );
									m_statustext.SetText( "Joining match..." );

									sf::Packet  pkt;
									pkt << prot::JoinMatch << opponent;
									m_conn.Send( pkt );
								}

								clicked = true;
							}
							break;

						case id::Instant:
							{
								sf::Packet  pkt;
								pkt << prot::JoinRandomMatch;
								m_conn.Send( pkt );
								clicked = true;
							}
							break;

						case id::Create:
							{
								if( m_waiting ) {
									break;
								}

								sf::Packet  pkt;
								pkt << prot::CreateMatch;
								m_conn.Send( pkt );

								clicked = true;
							}
							break;

						case id::Leave:
							{
								if( !m_waiting ) {
									break;
								}

								sf::Packet  pkt;
								pkt << prot::LeaveMatch;
								m_conn.Send( pkt );
								clicked = true;
							}
							break;

						case id::Connect:
							if( m_connected || m_connecting ) {
								break;
							}

							clicked = true;

							if( m_nickfocus ) {
								m_statustext.SetText( "Please complete your nickname, first." );
								break;
							}
							else if( static_cast<std::string>( m_nickname.GetText() ).size() == 0 ) {
								m_statustext.SetText( "Please enter a nickname!" );
								break;
							}

							m_connecting = true;
							m_connectthread.Wait();
							m_connectthread.Launch();
							break;

						case id::Refresh:
							if( m_connected ) {
								clicked = true;
								RefreshGameList();
							}
							break;

						case id::Disconnect:
							if( m_connected ) {
								clicked = true;
								m_connected = false;
								m_waiting = false;
								m_refreshing = false;
								m_conn.Close();
								m_matchlines.clear();
								m_selectedmatch = MAX_SIZET;
								m_statustext.SetText( "Disconnected." );
								m_nickname.SetColor( sf::Color( 255, 255, 255 ) );
							}
							break;

						case id::ScrollDown:
							if( m_matchlistpos < m_matchlines.size() - MAX_MATCHES ) {
								ScrollMatchList( m_matchlistpos + 1 );
								clicked = true;
							}
							break;

						case id::ScrollUp:
							if( m_matchlistpos > 0 ) {
								ScrollMatchList( m_matchlistpos - 1 );
								clicked = true;
							}
							break;

						default:
							break;
					}

					if( clicked ) {
						m_clicksound.Play();
						UpdateButtons();
					}

				}
			}
			return true;

		case sf::Event::MouseMoved:
			{
				sf::Vector2i  mouse( event.MouseMove.X, event.MouseMove.Y );

				for( std::size_t buttonid = 0; buttonid < m_buttons.size(); ++buttonid ) {
					bool  result = m_buttons[buttonid].TestCollision( mouse );

					if( m_buttons[buttonid].GetState() == Button::Normal && result ) {
						m_buttons[buttonid].ChangeState( Button::Hover );
					}
					else if( m_buttons[buttonid].GetState() == Button::Hover && !result ) {
						m_buttons[buttonid].ChangeState( Button::Normal );
					}
				}
			}

			return true;

		default:
			break;
	}

	return false;
}

void GameBrowserState::RefreshGameList() {
	m_matchlines.clear();

	m_refreshing = true;
	m_selectedmatch = MAX_SIZET;
	m_matchlistpos = 0;
	m_statustext.SetText( "Refreshing games list..." );

	sf::Packet  pkt;
	pkt << prot::ReqMatchInfoList;
	m_conn.Send( pkt );

	UpdateButtons();
}

void GameBrowserState::FocusNickname( bool focus ) {
	if( focus ) {
		m_nickname.SetColor( sf::Color( 255, 0, 0 ) );
	}
	else {
		m_nickname.SetColor( sf::Color( 255, 255, 255 ) );
	}

	m_nickfocus = focus;
	m_clicksound.Play();
}

void GameBrowserState::HandlePacket( sf::Packet packet ) {
	unsigned int  msgid( prot::Last );

	packet >> msgid;

	switch( msgid ) {
		case prot::AuthSuccessful:
			RefreshGameList();
			break;

		case prot::Welcome:
			{
				std::string        msg;
				std::stringstream  sstr;

				packet >> msg >> m_fieldsize;
				sstr << "Connected to: " << msg;
				m_statustext.SetText( sstr.str() );
			}
			break;

		case prot::MatchJoined:
			{
				std::string  other;
				packet >> other;

				if( other.empty() ) {
					m_matchlines.clear();
					m_waiting = true;
					m_statustext.SetText( "Waiting for an opponent..." );
					UpdateButtons();
					RefreshGameList();
				}
				else {
					m_othernickname = other;
					m_signal = sgn::InGame;
				}
			}
			break;

		case prot::MatchLeft:
			{
				m_waiting = false;
				RefreshGameList();
			}
			break;

		case prot::MatchInfoList:
			{
				std::stringstream  sstr;
				unsigned int       amount( 0 );
				unsigned char      open( 0 );
				std::string        p1, p2;

				packet >> amount;

				if( !amount ) {
					m_statustext.SetText( "Currently nobody is playing a match. :-(" );
					m_selectedmatch = MAX_SIZET;
				}
				else {
					sf::String         matchline( "", m_fontsmall, 18.f );

					for( unsigned int matchid = 0; matchid < amount; ++matchid ) {
						sstr.str( "" );

						packet >> open >> p1;

						if( open == 0 ) {
							packet >> p2;
							sstr << p1 << " vs. " << p2;
							matchline.SetColor( sf::Color( 160, 160, 160 ) );
						}
						else {
							sstr << p1 << " (open)";
							matchline.SetColor( sf::Color( 255, 255, 255 ) );
						}

						matchline.SetText( sstr.str() );
						m_matchlines.push_back( matchline );
					}

					m_selectedmatch = 0;
				}

				sstr.str( "" );
				sstr << "Found " << amount << " match" << (amount != 1 ? "es" : "") << ".";
				m_statustext.SetText( sstr.str() );

				ScrollMatchList( 0 );
				m_refreshing = false;
				UpdateButtons();
			}
			break;

		case prot::Error:
			{
				unsigned int   errorcode;
				std::string    msg;

				packet >> errorcode >> msg;

				switch( errorcode ) {
					case prot::BadNickname:
						m_conn.Close();
						m_connected = false;
						m_statustext.SetText( "Error: Your nickname is already in use!" );
						break;

					default:
						{
							std::stringstream  sstr;
							sstr << "Error #" << errorcode << ": " << msg;
							m_statustext.SetText( sstr.str() );
						}
						break;
				}
			}
			break;

		default:
			break;
	}
}

void GameBrowserState::ScrollMatchList( std::size_t pos ) {
	m_matchlistpos = std::min( pos, m_matchlines.size() );

	unsigned int  linenum( 0 );

	for( std::size_t matchid = m_matchlistpos; matchid < std::max( m_matchlistpos, m_matchlines.size() ); ++matchid ) {
		m_matchlines[matchid].SetPosition( sf::Vector2f( 238, 188.f + linenum * 20.f ) );
		++linenum;
	}

	if( m_selectedmatch >= m_matchlistpos && m_selectedmatch < m_matchlistpos + MAX_MATCHES ) {
		m_selectionbox.SetPosition( 222, 190.f + (m_selectedmatch - m_matchlistpos) * 20.f );
	}

	UpdateButtons();
}

void GameBrowserState::Render() {
	m_target.Draw( m_background );

	if( m_waiting ) {
		m_target.Draw( m_lblwaiting );
	}

	if( m_selectedmatch != MAX_SIZET && m_selectedmatch >= m_matchlistpos && m_selectedmatch < m_matchlistpos + MAX_MATCHES ) {
		m_target.Draw( m_selectionbox );
	}

	// Draw buttons.
	for( std::size_t buttonid = 0; buttonid < m_buttons.size(); ++buttonid ) {
		m_buttons[buttonid].Draw( m_target );
	}

	if( m_refreshing ) {
		m_target.Draw( m_refreshbutton );
	}

	// Show matches.
	for( std::size_t matchid = m_matchlistpos; matchid < std::min( m_matchlistpos + MAX_MATCHES, m_matchlines.size() ); ++matchid ) {
		m_target.Draw( m_matchlines[matchid] );
	}

	m_target.Draw( m_lblnicknameshadow );
	m_target.Draw( m_lblmatchesshadow );
	m_target.Draw( m_lblnickname );
	m_target.Draw( m_lblmatches );

	m_target.Draw( m_nickname );

	m_target.Draw( m_statustext );
}

void GameBrowserState::UpdateButtons() {
	m_buttons[id::Connect].SetVisible( !m_connected && !m_connecting );
	m_buttons[id::Disconnect].SetVisible( m_connected );
	m_buttons[id::Refresh].SetVisible( m_connected && !m_refreshing );

	m_buttons[id::Create].SetVisible( m_connected && !m_refreshing && !m_waiting );
	m_buttons[id::Join].SetVisible( m_connected && !m_refreshing && !m_waiting && m_selectedmatch != MAX_SIZET );
	m_buttons[id::Instant].SetVisible( m_connected && !m_refreshing && !m_waiting );
	m_buttons[id::Leave].SetVisible( m_waiting );

	m_buttons[id::ScrollUp].SetVisible( m_matchlines.size() > 0 && m_matchlistpos > 0 );
	m_buttons[id::ScrollDown].SetVisible( m_matchlines.size() > 0 && MAX_MATCHES < m_matchlines.size() && m_matchlistpos < m_matchlines.size() - MAX_MATCHES );
}

unsigned char GameBrowserState::GetFieldsize() const {
	return m_fieldsize;
}

const std::string GameBrowserState::GetMyNickname() const {
	return m_nickname.GetText();
}

const std::string GameBrowserState::GetOtherNickname() const {
	return m_othernickname;
}
