#include "button.hpp"
#include "utils.hpp"

Button::Button( unsigned int id, const sf::String &text, const sf::Vector2i &position, sf::Image &image, const sf::Vector2i &offset ) :
	m_id( id ),
	m_visible( true ),
	m_text( text ),
	m_position( position ),
	m_image( &image ),
	m_offset( offset ),
	m_state( Button::Normal ),
	m_button( *m_image, sf::Vector2f( m_position.x, m_position.y ) )
{
	Realign();
	ChangeState( Button::Normal );
	m_shadow = utl::CreateShadowString( m_text, 2.f, 60 );
}

void Button::Realign() {
	utl::AlignStringInRect( m_text,
		sf::FloatRect( m_position.x, m_position.y, m_position.x + m_image->GetWidth(), m_position.y + m_image->GetHeight() / Button::Last ),
		utl::AlignCenter | utl::AlignMiddle
	);

	m_text.Move( sf::Vector2f( m_offset.x, m_offset.y ) );
}

void Button::ChangeState( Button::State state ) {
	sf::IntRect  subrect;

	m_state = state;

	subrect.Left = 0;
	subrect.Right = m_image->GetWidth();
	subrect.Top  = state * (m_image->GetHeight() / Last);
	subrect.Bottom = (state + 1) * (m_image->GetHeight() / 3);

	m_button.SetSubRect( subrect );
}

bool Button::TestCollision( const sf::Vector2i &point ) const {
	if( !m_visible ) {
		return false;
	}

	if( point.x >= m_position.x && point.y >= m_position.y &&
			point.x < m_position.x + static_cast<int>( m_image->GetWidth() ) &&
			point.y < m_position.y + static_cast<int>( m_image->GetHeight() ) / Button::Last ) {
		return true;
	}
	
	return false;
}

void Button::Draw( sf::RenderTarget &target ) const {
	if( !m_visible ) {
		return;
	}

	target.Draw( m_button );
	target.Draw( m_shadow );
	target.Draw( m_text );
}

Button::State Button::GetState() const {
	return m_state;
}

sf::Sprite &Button::GetSprite() {
	return m_button;
}

void Button::SetVisible( bool visible ) {
	m_visible = visible;
}

bool Button::IsVisible() const {
	return m_visible;
}

void Button::SetText( const std::string &text ) {
	m_text.SetText( text );
	Realign();
	m_shadow = utl::CreateShadowString( m_text, 2.f, 60 );
}
