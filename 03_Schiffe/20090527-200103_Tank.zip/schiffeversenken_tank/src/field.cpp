#include <iostream>
#include "field.hpp"

Field::Field( unsigned char size, const sf::Vector2i &screenpos ) :
	m_fieldsize( size ),
	m_screenpos( screenpos )
{
	Clear();
}

void Field::Clear() {
	m_cells.clear();
	m_cells.resize( m_fieldsize * m_fieldsize );

	for( std::size_t cid = 0; cid < m_cells.size(); ++cid ) {
		m_cells[cid] = Free;
	}
}


Field::Status Field::GetCellStatus( const sf::Vector2i &pos ) const {
	if( !IsValidPosition( pos ) ) {
		return Invalid;
	}

	return m_cells[pos.y * m_fieldsize + pos.x];
}

bool Field::MarkCell( const sf::Vector2i &pos, Status status ) {
	if( !IsValidPosition( pos ) || (status != Hit && status != Missed) ) {
		return false;
	}

	m_cells[pos.y * m_fieldsize + pos.x] = status;
	return true;
}

bool Field::PlaceShip( unsigned char shipid, const sf::Vector2i &pos, bool vertical ) {
	if( !IsValidPosition( pos ) ) {
		return false;
	}

	sf::Vector2i  targetpos(
		pos.x + (vertical ? 0 : shipid + 1),
		pos.y + (vertical ? shipid + 1 : 0)
	);

	if( !IsValidPosition( targetpos ) ) {
		return false;
	}

	CellVector  copy( m_cells );

	for( unsigned char y = pos.y; y <= targetpos.y; ++y ) {
		for( unsigned char x = pos.x; x <= targetpos.x; ++x ) {
			if( copy[y * m_fieldsize + x] != Free ) {
				return false;
			}

			copy[y * m_fieldsize + x] = Ship;
		}
	}

	m_cells = copy;
	return true;
}


bool Field::IsValidPosition( const sf::Vector2i &pos ) const {
	return pos.x >= 0 && pos.y >= 0 && pos.x < m_fieldsize && pos.y < m_fieldsize;
}


void Field::Render( sf::RenderTarget &target ) {
	sf::Sprite  *drawspr( 0 );

	for( unsigned char y = 0; y < m_fieldsize; ++y ) {
		for( unsigned char x = 0; x < m_fieldsize; ++x ) {
			switch( m_cells[y * m_fieldsize + x] ) {
				case Free:
					drawspr = 0;
					break;

				case Missed:
					drawspr = &m_markmissed;
					break;

				case Ship:
					drawspr = &m_markship;
					break;

				case Hit:
					drawspr = &m_markhit;
					break;

				default:
					drawspr = 0;
					break;
			}

			if( drawspr ) {
				drawspr->SetPosition( m_screenpos.x + x * drawspr->GetImage()->GetWidth(), m_screenpos.y + y * drawspr->GetImage()->GetHeight() );
				target.Draw( *drawspr );
			}
		}
	}
}

void Field::SetImages( sf::Image &markship, sf::Image &markmissed, sf::Image &markhit ) {
	m_markship.SetImage( markship );
	m_markmissed.SetImage( markmissed );
	m_markhit.SetImage( markhit );
}
