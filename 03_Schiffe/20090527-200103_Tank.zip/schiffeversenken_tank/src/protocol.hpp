#ifndef __PROTOCOL_HPP__
#define __PROTOCOL_HPP__

namespace prot {

	enum MessageId {
		First = 0,
		Welcome,
		SystemMessage,
		Error,
		Quit,

		AuthSuccessful,
		ChangeNickname,

		ReqMatchInfoList,
		MatchInfoList,

		CreateMatch,
		JoinMatch,
		JoinRandomMatch,
		LeaveMatch,
		MatchJoined,
		MatchLeft,

		YourTurn,
		YourTurnEnded,
		PlaceShip,
		PlacementComplete,
		GameStarts,

		DropBomb,
		BombHit,
		BombMissed,

		YouWin,
		YouLose,

		Shutdown,

		Last
	};

enum ErrorCode {
	Generic = 0,
	BadMessage,
	NotAllowed,
	WrongStatus,
	CannotPlaceShip,
	NotYourTurn,
	AlreadyBombed,
	InvalidPosition,
	UserlimitReached,
	BadNickname,
	MatchAlreadyStarted
};



}

#endif
