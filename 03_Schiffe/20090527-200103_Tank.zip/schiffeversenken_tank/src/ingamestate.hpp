#ifndef __INGAMESTATE_HPP__
#define __INGAMESTATE_HPP__

#include <vector>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include "state.hpp"
#include "signals.hpp"
#include "field.hpp"

class InGameState : public State {
	public:
		InGameState( sf::RenderTarget &target, sf::SocketTCP &conn, unsigned char fieldsize, const std::string &mynick, const std::string &othernick );

		int Touch( float factor );
		void Render();
		bool HandleEvent( const sf::Event &event );

		const std::string GetMyNickname() const;

	private:
		enum PlayState {
			PSShipPlacement,
			PSBlocked,
			PSTurn
		};

		void HandlePacket( sf::Packet packet );
		void UpdateButtons();
		void UpdateSelectionBox( const sf::Vector2i &newpos, bool force = false );

		sgn::Signal    m_signal;
		sf::SocketTCP  &m_conn;

		bool  m_surrendered;
		bool  m_playmusic;
		bool  m_wasmyturn;

		PlayState      m_playstate;
		bool           m_placevertical;
		unsigned char  m_shiplength;

		sf::Vector2i  m_selectedcell;

		unsigned char  m_fieldsize;
		Field          m_ownfield;
		Field          m_oppfield;

		std::vector<Button>  m_buttons;

		sf::Font    m_fontsmall;
		sf::Font    m_fontbig;
		sf::String  m_statustext;
		sf::String  m_mynickname;
		sf::String  m_othernickname;


		sf::Image   m_imgbackground;
		sf::Image   m_imgwoodbutton;
		sf::Image   m_imgmarkship;
		sf::Image   m_imgmarkmissed;
		sf::Image   m_imgmarkhit;
		sf::Image   m_imgquad;
		sf::Sprite  m_background;
		sf::Sprite  m_selbox;

		sf::SoundBuffer  m_bufclick;
		sf::SoundBuffer  m_bufsplash;
		sf::SoundBuffer  m_bufexplosion;
		sf::SoundBuffer  m_buflost;
		sf::SoundBuffer  m_bufwon;
		sf::Sound        m_sndclick;
		sf::Sound        m_sndsplash;
		sf::Sound        m_sndexplosion;
		sf::Sound        m_sndlost;
		sf::Sound        m_sndwon;

		sf::Music  m_mscthesailor;
};

#endif
