#include "utils.hpp"

namespace utl {

void AlignStringInRect( sf::String &str, const sf::FloatRect &rect, int alignment ) {
	sf::FloatRect  srect( str.GetRect() );
	sf::Vector2f   pos;

	str.SetCenter( 0, 0 );

	if( alignment & AlignLeft ) {
		pos.x = rect.Left;
	}
	else if( alignment & AlignCenter ) {
		pos.x = rect.Left + ((rect.GetWidth() / 2.f) - srect.GetWidth() / 2.f);
	}
	else if( alignment & AlignRight ) {
		pos.x = rect.Right - srect.GetWidth();
	}

	if( alignment & AlignTop ) {
		pos.y = rect.Top;
	}
	else if( alignment & AlignMiddle ) {
		pos.y = rect.Top + ((rect.GetHeight() / 2.f) - srect.GetHeight() / 2.f);
	}
	else if( alignment & AlignBottom ) {
		pos.y = rect.Bottom - srect.GetHeight();
	}

	str.SetPosition( pos );
}

sf::FloatRect GetTargetRect( const sf::RenderTarget &target ) {
	return sf::FloatRect( 0, 0, target.GetWidth(), target.GetHeight() );
}

sf::String CreateShadowString( const sf::String &original, float offset, unsigned char alpha ) {
	sf::String  shadow( original );
	sf::Color   col( 0, 0, 0, alpha );

	shadow.Move( offset, offset );
	shadow.SetColor( col );

	return shadow;
}

void CenterOrigin( sf::Sprite &spr ) {
	sf::Vector2f  size( spr.GetImage()->GetWidth(), spr.GetImage()->GetHeight() );

	size.x *= spr.GetScale().x;
	size.y *= spr.GetScale().y;

	spr.SetCenter( size.x / 2, size.y / 2 );
}

}
