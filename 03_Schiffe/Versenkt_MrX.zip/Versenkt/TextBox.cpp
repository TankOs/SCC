#include "TextBox.h"
const std::string allowedchar = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_()[]";

TextBox::TextBox(std::string sText, std::string lText, sf::Vector2f Position) {
	Pos = Position;
	Leertext = lText;
	Text.SetSize(30);
	Text.SetColor(sf::Color::Black);
	Inhalt = sText;
	if(Inhalt != "") {
		Text.SetColor(sf::Color::Black);
		Text.SetText(Inhalt);
	}
	else {
		Text.SetColor(sf::Color(0,0,0,100));
		Text.SetText(Leertext);
	}
	SetPosition();
}
bool TextBox::IsNotLeer() {
	return(Inhalt != "");
}
void TextBox::AddText(char c) {
	if(c == 8) {
		if(Inhalt.length() > 0) {
			Inhalt.erase(Inhalt.length()-1, 1);
		}
	}
	else if (allowedchar.find(c) != -1) {
		if(Inhalt.length() < 16) {
			Inhalt += c;
		}
	}
	if(Inhalt != "") {
		Text.SetColor(sf::Color::Black);
		Text.SetText(Inhalt);
	}
	else {
		Text.SetColor(sf::Color(0,0,0,100));
		Text.SetText(Leertext);
	}
	SetPosition();
}
void TextBox::SetPosition(sf::Vector2f Position) {
	Pos = Position;
	Text.SetPosition(Pos - sf::Vector2f(Text.GetRect().GetWidth() / 2, Text.GetRect().GetHeight() / 2));
	Rand = sf::Shape::Rectangle(Text.GetPosition().x, Text.GetPosition().y, Text.GetPosition().x + Text.GetRect().GetWidth() + 2, Text.GetPosition().y + Text.GetRect().GetHeight() + 2, sf::Color(255,255,255), 5, sf::Color(0,0,80));
}
void TextBox::SetPosition() {
	Text.SetPosition(Pos - sf::Vector2f(Text.GetRect().GetWidth() / 2, Text.GetRect().GetHeight() / 2));
	Rand = sf::Shape::Rectangle(Text.GetPosition().x, Text.GetPosition().y, Text.GetPosition().x + Text.GetRect().GetWidth() + 2, Text.GetPosition().y + Text.GetRect().GetHeight() + 2, sf::Color(255,255,255), 5, sf::Color(0,0,80));
}
sf::Shape TextBox::getBorder() {
	return(Rand);
}
sf::String TextBox::getText() {
	return(Text);
}