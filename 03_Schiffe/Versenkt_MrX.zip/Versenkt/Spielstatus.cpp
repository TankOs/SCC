#include "Spielstatus.h"

STATUS Spielstatus;

STATUS GetStatus() {
	return(Spielstatus);
}

void InitStati() {
	KI = 0;
	SetzenFertig = 0;
	Hauptmen� = 0;
	Men�[0] = 0;
	Men�[1] = 0;
	Men�[2] = 0;
	Men�[3] = 0;
	Zuf�lligPlatzieren = 0;
	SetStatus(NAME);
}

void SetStatus(STATUS state) {
	if(state > MEN� && Spielstatus == MEN�) {
		KISpielt = KI->Checked;
	}
	if(state != MEN� && KI != 0) {
		delete KI;
		KI = 0;
	}
	if(state != SETZEN && SetzenFertig != 0) {
		delete SetzenFertig;
		SetzenFertig = 0;
	}
	if(state != SETZEN && state != GESETZT && Zuf�lligPlatzieren != 0) {
		delete Zuf�lligPlatzieren;
		Zuf�lligPlatzieren = 0;
	}
	if((state <= MEN� || state == ENDE) && Hauptmen� != 0) {
		delete Hauptmen�;
		Hauptmen� = 0;
	}
	if(state != MEN�) {
		for(int i = 0; i < 4; i++) {
			if(Men�[i] != 0) {
				delete Men�[i];
				Men�[i] = 0;
			}
		}
	}
	if(state == MEN� && Spielstatus >= WARTEN) {
		SoundPlayer.Clear();
		Hintergrundsound.Stop();
		ExitMatch();
	}
	if(state == NAME && Spielstatus >= MEN�) {
		Reconnect();
	}
	if(state != WARTEN && Spielstatus == AUSWAHL) {
		Spielauswahl.clear();
	}
	if(Hauptmen� == 0 && state > MEN� && state != ENDE) {
		Hauptmen� = new Button("Hauptmen�", sf::Vector2f(250, 150), sf::Vector2f(550, 250));
	}
	switch(state) {
		case NAME:
			Hintergrund.SetImage(iHintergrund[0]);
			Name = new TextBox("", "Bitte geben Sie ihren Namen ein...", sf::Vector2f(400, 300));
			Spielstatus = state;
			break;
		case MEN�:
			Hintergrund.SetImage(iHintergrund[1]);
			Men�[0] = new Button("Beenden", sf::Vector2f(37, 46), sf::Vector2f(387, 255));
			Men�[1] = new Button("Spiel er�ffnen", sf::Vector2f(410, 45), sf::Vector2f(760, 277));
			Men�[2] = new Button("Zuf�lligem Spiel\nbeitreten", sf::Vector2f(38, 313), sf::Vector2f(388, 525));
			Men�[3] = new Button("Bestimmtem Spiel\nbeitreten", sf::Vector2f(412, 340), sf::Vector2f(762, 525));
			KI = new CheckBox(sf::Vector2f(37, 276), "Computer spielt (KI-Modus)");
			Spielstatus = state;
			if(Spielstatus == NAME && Name != 0) {
				delete Name;
				Name = 0;
			}
			break;
		case AUSWAHL:
			Hauptmen�->SetPosition(sf::Vector2f(555, 260), sf::Vector2f(795, 340));
			Spielstatus = state;
			break;
		case WARTEN:
			Hintergrund.SetImage(iHintergrund[2]);
			Hauptmen�->SetPosition(sf::Vector2f(250, 150), sf::Vector2f(550, 250));
			Spielstatus = state;
			break;
		case SETZEN:
			Zuf�lligPlatzieren = new Button("Zuf�llig platzieren", sf::Vector2f(210, 465), sf::Vector2f(540, 525));
			SetzenFertig = new Button("Flotte auf Position", sf::Vector2f(200, 465), sf::Vector2f(550, 525));
			AnDerReihe.SetText("Bitte bringen Sie ihre Flotte auf Position!");
			AnDerReihe.SetPosition(400-AnDerReihe.GetRect().GetWidth()/2,430);
			Hintergrundsound.Play();
			Hintergrund.SetImage(iHintergrund[3]);
			Hauptmen�->SetPosition(sf::Vector2f(220, 535), sf::Vector2f(530, 595));
			ResetSchiffFelder();
			Spielstatus = state;
			break;
		case GESETZT:
			AnDerReihe.SetText("Bitte warten Sie, bis der Gegner\nseine Flotte positioniert hat!");
			AnDerReihe.SetPosition(400-AnDerReihe.GetRect().GetWidth()/2,435);
			Spielstatus = state;
			break;
		case WERFEN:
			AnDerReihe.SetText("Bitte warten Sie auf den gegnerischen Angriff!");
			AnDerReihe.SetPosition(400-AnDerReihe.GetRect().GetWidth()/2,435);
			Spielstatus = state;
			break;
		case GEWONNEN:
			Spielstatus = state;
			break;
		case VERLOREN:
			Spielstatus = state;
			break;
		case ENDE:
			Running = false;
			Spielstatus = state;
			break;
	}
}