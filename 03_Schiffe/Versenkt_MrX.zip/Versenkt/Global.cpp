#include "Global.h"

TextBox *Name;
sf::Image iHintergrund[4];
sf::Sprite Hintergrund;
const int KSize = 19;
bool AmZug;
sf::String Fehler;
sf::Clock Fehleruhr;
std::vector<Button> Spielauswahl;
sf::String AnDerReihe;
CheckBox *KI;
sf::Music Hintergrundsound;
Button *SetzenFertig;
Button *Hauptmen�;
sf::Event EV;
Button *Men�[4];
bool Running = true;
bool KISpielt;
sf::String Gegner;
Button *Zuf�lligPlatzieren;

void SetFehler(std::string str) {
	Fehleruhr.Reset();
	Fehler.SetText(static_cast<std::string>(Fehler.GetText()) + "    " + str);
}
void ResetFehler() {
	Fehler.SetText("");
}