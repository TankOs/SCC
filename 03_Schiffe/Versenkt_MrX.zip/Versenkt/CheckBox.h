#pragma once
#include <SFML/Graphics.hpp>

class CheckBox {
private:
	sf::Shape Rand;
	sf::Shape Line1;
	sf::Shape Line2;
	sf::String Text;
public:
	bool Checked;
	CheckBox(sf::Vector2f& Position, std::string text);
	sf::Drawable& getBorder();
	sf::Shape getLine1();
	sf::Shape getLine2();
	sf::Drawable& getText();
	void IsClicked(sf::Vector2i& MousePosition);
};