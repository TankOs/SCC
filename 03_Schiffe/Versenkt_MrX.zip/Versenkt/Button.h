#pragma once
#include <string>
#include <SFML/Graphics.hpp>

class Button {
private:
	sf::Shape Rand;
	sf::String Text;
	bool geklickt;
	float Border;
public:
	sf::Vector2f GetPosition();
	void SetPosition(sf::Vector2f Pos);
	void SetPosition(sf::Vector2f Pos1, sf::Vector2f Pos2);
	const sf::Drawable& getBorder() const;
	const sf::String& getText() const;
	bool IsClicked(const sf::Vector2i& MousePosition);
	void setText(const std::string sText);
	Button(const std::string sText, const sf::Vector2f& Pos1, const sf::Vector2f& Pos2, int size = 40, float border = 8);
};