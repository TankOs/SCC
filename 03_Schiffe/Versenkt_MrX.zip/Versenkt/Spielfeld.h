#pragma once
#include "Schiff.h"

extern sf::Image ImgGetroffen;

class Spielfeld {
private:
	static sf::Image Wasser;
	static sf::Image Bombardiert;
	sf::Vector2i Position;
	sf::Sprite Kacheln[10][10];
public:
	__int8 Feldzustand[10][10];
	Spielfeld();
	void Init(sf::Vector2i Pos);
	bool Pr�fen();
	void SchiffAufFeld(Schiff *schiff, sf::Vector2i& MousePosition);
	void Click(sf::Vector2i& MousePosition);
	void Draw(sf::RenderWindow& RW);
	sf::Vector2i& GetPosition();
	void Getroffen(int x, int y, bool b);
	sf::Vector2<unsigned char> GetKoords(Schiff *schiff);
	static void ImgLaden() {
		Wasser.LoadFromFile("Grafik/Wasser.png");
		Bombardiert.LoadFromFile("Grafik/Bombardiert.png");
		ImgGetroffen.LoadFromFile("Grafik/Treffer.png");
	}
};

extern Spielfeld FeldI, FeldG;