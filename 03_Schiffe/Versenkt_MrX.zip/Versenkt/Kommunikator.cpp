#include "Kommunikator.h"

Kommunikator Client;
void ExitMatch() {
	Client.ExitMatch();
}
void Reconnect() {
	Client.Disconnect();
	Client.Anmelden();
}

Kommunikator::Kommunikator() {
	//Anmelden(); //Funzt warum auch immer nicht...
	Launch();
	Client.SetBlocking(true);
}
void Kommunikator::Anmelden(sf::IPAddress IP, int Port) {
	if(Client.Connect(Port, IP) != sf::Socket::Done) {
		std::cout << "Konnte nicht verbunden werden...";
	}
}
void Kommunikator::Run() {
	std::srand(std::clock());
	unsigned int msgID, c;
	std::string msg;
	unsigned char a, b;
	bool d;
	while(GetStatus() != ENDE) {
		Meldung.Clear();
		std::ostringstream os;
		Client.Receive(Meldung);
		Meldung >> msgID;
		switch(msgID) {
			case Welcome:
				Meldung >> msg >> a >> b;
				std::cout << msg << "\n"
					<< "Spielfeldgroesse: " << static_cast<int>(a) << "\n"
					<< "Anzahl Schiffe: " << static_cast<int>(b) << "\n";
				break;
			case Error:
				Meldung >> c >> msg;
				os << c;
				if(c == AlreadyBombed && KISpielt) {
					WerfeRandomBombe();
					break;
				}
				else {
					SetFehler("Fehler (" + os.str() + "): " + msg);
					std::cout << "Fehler (" << os.str() << "): " << msg;
				}
				break;
			case MatchInfoList:
				Meldung >> c;
				for(unsigned int i = 0; i < c; i++) {
					Meldung >> d;
					Meldung >> msg;
					if(d) {
						Spielauswahl.push_back(Button("Gegner: " + msg, sf::Vector2f(25, 55+i*30), sf::Vector2f(550, 80+i*30), 15, 2));
					}
					else {
						Meldung >> msg;
					}
				}
				SetStatus(AUSWAHL);
				ResetFehler();
				break;
			case AuthSuccessful:
				SetStatus(MEN�);
				break;
			case MatchJoined:
				Meldung >> msg;
				if(msg != "") {
					Gegner.SetColor(sf::Color(0,0,0));
					Gegner.SetPosition(600, 110);
					Gegner.SetText("Gegner:\n  " + msg);
					SetStatus(SETZEN);
					if(KISpielt) {
						SetRandomSchiffe();
					}
				}
				break;
			case MatchLeft:
				if(GetStatus() != GEWONNEN && GetStatus() != VERLOREN) {
					SoundPlayer.PlaySound(FEIND_WEG);
					SetStatus(MEN�);
				}
				break;
			case PlaceShip:
				break;
			case PlacementComplete:
				SoundPlayer.PlaySound(POSITION_EINGENOMMEN);
				SetStatus(GESETZT);
				break;
			case GameStarts:
				SetStatus(WERFEN);
				break;
			case YourTurn:
				AnDerReihe.SetText("Sie k�nnen nun Angreifen!");
				AnDerReihe.SetPosition(400-AnDerReihe.GetRect().GetWidth()/2,435);
				AmZug = true;
				if(KISpielt) {
					WerfeRandomBombe();
				}
				break;
			case YourTurnEnded:
				AnDerReihe.SetText("Bitte warten Sie auf den gegnerischen Angriff!");
				AnDerReihe.SetPosition(400-AnDerReihe.GetRect().GetWidth()/2,435);
				AmZug = false;
				break;
			case BombHit:
				Meldung >> a >> b;
				if(AmZug) {
					SoundPlayer.PlaySound(SCHIFF_GETROFFEN);
					(*Treffer)(a, b, true);
				}
				else {
					(*Getroffen)(a, b, true);
				}
				break;
			case BombMissed:
				Meldung >> a >> b;
				if(AmZug) {
					(*Treffer)(a, b, false);
				}
				else {
					(*Getroffen)(a, b, false);
				}
				break;
			case YouLose:
				SetStatus(VERLOREN);
				break;
			case YouWin:
				SetStatus(GEWONNEN);
				break;
		}
	}
}
void Kommunikator::SetNick(std::string Nick) {
	Meldung.Clear();
	Meldung << ChangeNickname << Nick;
	Client.Send(Meldung);
}
void Kommunikator::Bombardieren(unsigned char x, unsigned char y) {
	Meldung.Clear();
	Meldung << DropBomb << x << y;
	Client.Send(Meldung);
}
void Kommunikator::SetzeSchiff(unsigned char Num, bool Vertikal, sf::Vector2<unsigned char> Koord) {
	Meldung.Clear();
	Meldung << PlaceShip << Num << Koord.x << Koord.y;
	if(Vertikal) {
		Meldung << static_cast<unsigned char>(1);
	}
	else {
		Meldung << static_cast<unsigned char>(0);
	}
	Client.Send(Meldung);
}
void Kommunikator::ExitMatch() {
	Meldung.Clear();
	Meldung << LeaveMatch;
	Client.Send(Meldung);
}
void Kommunikator::Zuf�lligesSpiel() {
	Meldung.Clear();
	Meldung << JoinRandomMatch;
	Client.Send(Meldung);
	SetStatus(WARTEN);
}
void Kommunikator::NeuesSpiel() {
	Meldung.Clear();
	Meldung << CreateMatch;
	Client.Send(Meldung);
	SetStatus(WARTEN);
	SetFehler("Ein neues Spiel wurde er�ffnet... Es wird auf einen Gegner gewartet...");
}
void Kommunikator::BestimmtesSpiel(std::string Gegner) {
	Meldung.Clear();
	Meldung << JoinMatch << Gegner;
	Client.Send(Meldung);
	SetStatus(WARTEN);
	SetFehler("Bitte warten... Sie werden mit dem gew�nschten Spiel verbunden");
}
void Kommunikator::MatchInfo() {
	Meldung.Clear();
	SetFehler("Bitte warten... Die �bersicht wird erstellt...");
	Meldung << ReqMatchInfoList;
	Client.Send(Meldung);
	SetStatus(WARTEN);
}
void Kommunikator::Disconnect() {
	Meldung.Clear();
	Meldung << Quit;
	Client.Send(Meldung);
}
Kommunikator::~Kommunikator() {
	Disconnect();
}