#include "Schiff.h"

Schiffstyp Schifftyp[5];

Schiff Schiffe[5];

void InitSchiffTypen() {
	Schifftyp[0].Init(2, "UBoot");
	Schifftyp[1].Init(3, "leichterKreuzer");
	Schifftyp[2].Init(4, "Zerstoerer");
	Schifftyp[3].Init(5, "Schlachtkreuzer");
	Schifftyp[4].Init(6, "Schlachtschiff");
}

Schiff::Schiff() {}
void Schiff::RadGedreht() {
	if(Geklickt) {
		Vertikal = !Vertikal;
	}
}
void Schiff::Click(sf::Vector2i Pos, sf::Vector2i Vorher) {
	if((!Vertikal && Vorher.x >= Position.x && Vorher.y >= Position.y && Vorher.x <= Position.x + KSize*Typ->GetL�nge() && Vorher.y <= Position.y + KSize) ||
		(Vertikal && Vorher.x >= Position.x && Vorher.y >= Position.y && Vorher.x <= Position.x + KSize && Vorher.y <= Position.y + KSize*Typ->GetL�nge())) {
			Geklickt = true;
	}
	if(Geklickt) {
		Position += Pos-Vorher;
	}
}
__int8 Schiff::GetL�nge() {
	return(Typ->GetL�nge());
}
void Schiff::Init(__int8 typ, sf::Vector2i Pos) {
	Typ = &Schifftyp[typ];
	Zerst�rt.resize(Typ->GetL�nge());
	Position = Pos;
	for(int i = 0; i < Typ->GetL�nge(); i++) {
		Zerst�rt[i] = false;
	}
	Geklickt = false;
	Vertikal = false;
}
void Schiff::Getroffen(int St�ck) {
	Zerst�rt[St�ck] = true;
}
void Schiff::Draw(sf::RenderTarget *RW) {
	for(int i = 0; i < Typ->GetL�nge(); i++) {
		sf::Sprite SP(Typ->GetImg(Zerst�rt[i], i, Vertikal));
		if(Vertikal) {
			if(Zerst�rt[i]) {
				SP.SetPosition(Position.x, Position.y + i*KSize-1);
			}
			else {
				SP.SetPosition(Position.x + KSize - 2, Position.y + i*KSize - 1);
				SP.Rotate(-90);
			}
		}
		else {
			SP.SetPosition(Position.x + i*KSize-1, Position.y);
		}
		RW->Draw(SP);
	}
}