#pragma once
#include "Schifftyp.h"
#include "Kommunikator.h"

class Schiff {
private:
	std::vector<bool> Zerst�rt;
	Schiffstyp *Typ;
public:
	sf::Vector2i Position;
	bool Geklickt;
	bool Vertikal;
	Schiff();
	void Init(__int8 typ, sf::Vector2i Pos);
	void Getroffen(int St�ck);
	__int8 GetL�nge();
	void Click(sf::Vector2i Pos, sf::Vector2i Vorher);
	void Draw(sf::RenderTarget *RW);
	void RadGedreht();
};

extern Schiff Schiffe[5];

void InitSchiffTypen();