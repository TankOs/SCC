#include "Spielfeld.h"

sf::Image Spielfeld::Wasser;
sf::Image Spielfeld::Bombardiert;
sf::Image ImgGetroffen;

void Treffer(int x, int y, bool b) {
	FeldG.Getroffen(x,y,b);
}
void Getroffen(int x, int y, bool b) {
	FeldI.Getroffen(x,y,b);
}

void ResetSchiffFelder() {
	FeldI.Init(sf::Vector2i(187,221));
	FeldG.Init(sf::Vector2i(383,221));		
	for(int i = 0; i < 5; i++) {
		Schiffe[i].Init(i, sf::Vector2i(641, 193 + i*(KSize + 5)));
	}
}

Spielfeld::Spielfeld() {
}
sf::Vector2i& Spielfeld::GetPosition() {
	return(Position);
}
void Spielfeld::Getroffen(int x, int y, bool b) {
	if(b) {
		Kacheln[x][y].SetImage(ImgGetroffen);
		Feldzustand[x][y] = 2;
		sf::Vector2<unsigned __int8> Koords;
		int St�ck;
		for(int i = 0; i < 5; i++) {
			Koords = GetKoords(&Schiffe[i]);
			if(Schiffe[i].Vertikal) {
				if(x == Koords.x && y >= Koords.y && y < Koords.y + Schiffe[i].GetL�nge()) {
					St�ck = y-Koords.y;
					Schiffe[i].Getroffen(St�ck);
				}
			}
			else {
				if(y == Koords.y && x >= Koords.x && x < Koords.x + Schiffe[i].GetL�nge()) {
					St�ck = x-Koords.x;
					Schiffe[i].Getroffen(St�ck);
				}
			}
		}
	}
	else {
		Kacheln[x][y].SetImage(Bombardiert);
	}
}
void Spielfeld::Init(sf::Vector2i Pos) {
	Client.Treffer = ::Treffer;
	Client.Getroffen = ::Getroffen;
	Position = Pos;
	for(int i = 0; i < 10; i++) {
		for(int j = 0; j < 10; j++) {
			Kacheln[i][j].SetImage(Wasser);
			Kacheln[i][j].SetPosition(Pos.x + i * KSize-1, Pos.y +  j * KSize-1);
			Feldzustand[i][j] = 0;
		}
	}
}
void Spielfeld::Draw(sf::RenderWindow& RW) {
	for(int i = 0; i < 10; i++) {
		for(int j = 0; j < 10; j++) {
			RW.Draw(Kacheln[i][j]);
		}
	}
}
sf::Vector2<unsigned char> Spielfeld::GetKoords(Schiff *schiff) {
	sf::Vector2<sf::Uint8> Koord;
	Koord.x = (schiff->Position.x - Position.x) / KSize;
	Koord.y = (schiff->Position.y - Position.y) / KSize;
	return(Koord);
}
void Spielfeld::Click(sf::Vector2i& MousePosition) {
	if(MousePosition.x > Position.x && MousePosition.y > Position.y && MousePosition.x < Position.x + KSize*10 && MousePosition.y < Position.y + KSize*10) {
		Client.Bombardieren((MousePosition.x - Position.x)/KSize, (MousePosition.y - Position.y)/KSize);
		Feldzustand[(MousePosition.x - Position.x)/KSize][(MousePosition.y - Position.y)/KSize] = 1;
	}
}
void Spielfeld::SchiffAufFeld(Schiff *schiff, sf::Vector2i& MousePosition) {
	if(MousePosition.x >= Position.x && MousePosition.y >= Position.y && 
		MousePosition.x <= Position.x + KSize * 10 && 
		MousePosition.y <= Position.y + KSize * 10 && schiff->Geklickt) {
			schiff->Position.x = std::max(Position.x, static_cast<int>((MousePosition.x - Position.x) / KSize) * KSize + Position.x);
			schiff->Position.y = std::max(Position.y, static_cast<int>((MousePosition.y - Position.y) / KSize) * KSize + Position.y);
			if(schiff->Vertikal) {
				if(schiff->Position.y + schiff->GetL�nge() * KSize >= Position.y + 10 * KSize) {
					schiff->Position.y = Position.y + (10-schiff->GetL�nge()) * KSize;
				}
			}
			else {
				if(schiff->Position.x + schiff->GetL�nge() * KSize >= Position.x + 10 * KSize) {
					schiff->Position.x = Position.x + (10-schiff->GetL�nge()) * KSize;
				}
			}
	}
}
bool Spielfeld::Pr�fen() {
	bool Besetzt[10][10];
	for(int i = 0; i < 10; i++) {
		for(int j = 0; j < 10; j++) {
			Besetzt[i][j] = false;
		}
	}
	for(int i = 0; i < 5; i++) {
		if(Schiffe[i].Vertikal) {
			if(Schiffe[i].Position.x >= Position.x && 
				Schiffe[i].Position.y >= Position.y && 
				Schiffe[i].Position.x + KSize <= Position.x + KSize * 10 && 
				Schiffe[i].Position.y + KSize * Schiffe[i].GetL�nge() <= Position.y + KSize*10) {
				for(int j = 0; j < Schiffe[i].GetL�nge(); j++) {
					if(!Besetzt[(Schiffe[i].Position.x - Position.x) / KSize][(Schiffe[i].Position.y - Position.y) / KSize + j]) {
						Besetzt[(Schiffe[i].Position.x - Position.x) / KSize][(Schiffe[i].Position.y - Position.y) / KSize + j] = true;
					}
					else {
						return(false);
					}
				}
			}
			else {
				return(false);
			}
		}
		else {
			if(Schiffe[i].Position.x >= Position.x && 
				Schiffe[i].Position.y >= Position.y && 
				Schiffe[i].Position.x + KSize * Schiffe[i].GetL�nge() <= Position.x + KSize*10 && 
				Schiffe[i].Position.y + KSize <= Position.y + KSize * 10) {
				for(int j = 0; j < Schiffe[i].GetL�nge(); j++) {
					if(!Besetzt[(Schiffe[i].Position.x - Position.x) / KSize + j][(Schiffe[i].Position.y - Position.y) / KSize]) {
						Besetzt[(Schiffe[i].Position.x - Position.x) / KSize + j][(Schiffe[i].Position.y - Position.y) / KSize] = true;
					}
					else {
						return(false);
					}
				}
			}
			else {
				return(false);
			}
		}
	}
	return(true);
}

Spielfeld FeldI, FeldG;