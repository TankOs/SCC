#pragma once
#include "SoundLoop.h"

enum STATUS {NAME, MEN�, AUSWAHL, WARTEN, SETZEN, GESETZT, WERFEN, GEWONNEN, VERLOREN, ENDE};

STATUS GetStatus();
void InitStati();
void SetStatus(STATUS state);