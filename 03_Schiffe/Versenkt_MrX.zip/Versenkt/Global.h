#pragma once
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/System.hpp>
#include <SFML/Network.hpp>
#include <iostream>
#include <sstream>
#include <cmath>
#include "Button.h"
#include "TextBox.h"
#include "CheckBox.h"

enum MessageId {
	First = 0, Welcome,   // s:msg i:fieldsize i:maxships
	SystemMessage,        // s:msg
	Error,                // i:code s:msg
	Quit, AuthSuccessful, ChangeNickname, ReqMatchInfoList, MatchInfoList, CreateMatch, JoinMatch,
	JoinRandomMatch, LeaveMatch, MatchJoined, MatchLeft, YourTurn, YourTurnEnded,
	PlaceShip, PlacementComplete, GameStarts, DropBomb, BombHit, BombMissed, YouWin,
	YouLose, Shutdown, Last
};
enum ErrorCode {
	Generic = 0, BadMessage, NotAllowed, WrongStatus, CannotPlaceShip, NotYourTurn,
	AlreadyBombed, InvalidPosition, UserlimitReached, BadNickname, MatchAlreadyStarted
};

extern const int KSize;
extern bool AmZug;
extern TextBox *Name;
extern sf::String Fehler;
extern sf::Clock Fehleruhr;
extern sf::Sprite Hintergrund;
extern sf::Image iHintergrund[4];
extern std::vector<Button> Spielauswahl;
extern CheckBox *KI;
extern sf::Music Hintergrundsound;
extern sf::String AnDerReihe;
extern Button *SetzenFertig;
extern Button *Hauptmen�;
extern Button *Zuf�lligPlatzieren;
extern sf::Event EV;
extern Button *Men�[4];
extern bool Running;
extern bool KISpielt;
extern sf::String Gegner;

void SetFehler(std::string str);
void ResetFehler();

void SetRandomSchiffe();
void WerfeRandomBombe();
void ExitMatch();
void Reconnect();
void ResetSchiffFelder();