#include "Button.h"

const sf::Drawable& Button::getBorder() const {
	return(Rand);
}
const sf::String& Button::getText() const {
	return(Text);
}
bool Button::IsClicked(const sf::Vector2i& MousePosition) {
	if(MousePosition.x > Rand.GetPointPosition(0).x && MousePosition.x < Rand.GetPointPosition(2).x && MousePosition.y > Rand.GetPointPosition(0).y && MousePosition.y < Rand.GetPointPosition(2).y) {
		if(!geklickt) {
			geklickt = true;
			return(true);
		}
	}
	else {
		geklickt = false;
	}
	return(false);
}
void Button::setText(const std::string sText) {
	Text.SetText(sText);
}
sf::Vector2f Button::GetPosition() {
	return(Text.GetPosition());
}
void Button::SetPosition(sf::Vector2f Pos) {
	Rand.Move(Pos - Text.GetPosition());
	Text.SetPosition(Pos);
}
void Button::SetPosition(sf::Vector2f Pos1, sf::Vector2f Pos2) {
	Text.SetPosition(((Pos2.x+Pos1.x) / 2 - Text.GetRect().GetWidth() / 2), ((Pos2.y+Pos1.y) / 2 - Text.GetRect().GetHeight() / 2));
	Rand = sf::Shape::Rectangle(Pos1.x + Border, Pos1.y + Border, Pos2.x - Border, Pos2.y - Border, sf::Color(0,0,0,0), Border, sf::Color(0,0,0,80));
}
Button::Button(const std::string sText, const sf::Vector2f& Pos1, const sf::Vector2f& Pos2, int size, float border) {
	Border = border;
	geklickt = false;
	Text.SetText(sText);
	Text.SetSize(size);
	Text.SetColor(sf::Color(50,150,50));
	Text.SetPosition(((Pos2.x+Pos1.x) / 2 - Text.GetRect().GetWidth() / 2), ((Pos2.y+Pos1.y) / 2 - Text.GetRect().GetHeight() / 2));
	Rand = sf::Shape::Rectangle(Pos1.x + Border, Pos1.y + Border, Pos2.x - Border, Pos2.y - Border, sf::Color(0,0,0,0), Border, sf::Color(0,0,0,80));
}