#include "SoundLoop.h"

std::vector<sf::SoundBuffer> SoundLoop::Sound;
SoundLoop SoundPlayer;

SoundLoop::SoundLoop() {
}
void SoundLoop::Run() {
	while(Running) {
		if(Warteschlange.size() > 0 && !KISpielt) {
			Player.Stop();
			Player.SetBuffer(Sound[Warteschlange[0]]);
			Player.Play();
			Warteschlange.erase(Warteschlange.begin());
		}
	}
}
void SoundLoop::PlaySound(SOUND index) {
	Warteschlange.push_back(index);
}
void SoundLoop::Clear() {
	Warteschlange.resize(0);
	Player.Stop();
}