#pragma once
#include <string>
#include <SFML/Graphics.hpp>

class TextBox {
private:
	sf::Shape Rand;
	sf::String Text;
	std::string Leertext;
	std::string Inhalt;
	sf::Vector2f Pos;
public:
	sf::Shape getBorder();
	sf::String getText();
	void SetPosition(sf::Vector2f Position);
	void SetPosition();
	bool IsNotLeer();
	TextBox(std::string sText, std::string lText, sf::Vector2f Position);
	void AddText(char c);
};