#pragma once
#include "Global.h"

enum SOUND {
	POSITION_EINGENOMMEN, SCHIFF_GETROFFEN, FEIND_WEG
};

class SoundLoop : public sf::Thread {
private:
	static std::vector<sf::SoundBuffer> Sound;
	sf::Sound Player;
	std::vector<SOUND> Warteschlange;
public:
	SoundLoop();
	virtual void Run();
	void PlaySound(SOUND index);
	void Clear();
	static void LadeSounds() {
		Sound.resize(3);
		Sound[POSITION_EINGENOMMEN].LoadFromFile("Sound/PositionEingenommen.ogg");
		Sound[SCHIFF_GETROFFEN].LoadFromFile("Sound/SchiffGetroffen.ogg");
		Sound[FEIND_WEG].LoadFromFile("Sound/FeindWeg.ogg");
	}
};

extern SoundLoop SoundPlayer;