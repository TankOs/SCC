#include "CheckBox.h"

sf::Drawable& CheckBox::getBorder() {
	return(Rand);
}
sf::Drawable& CheckBox::getText() {
	return(Text);
}
sf::Shape CheckBox::getLine1() {
	if(Checked) {
		return(Line1);
	}
	else {
		return(sf::Shape::Line(0,0,0,0,0,sf::Color(0,0,0,0)));
	}
}
sf::Shape CheckBox::getLine2() {
	if(Checked) {
		return(Line2);
	}
	else {
		return(sf::Shape::Line(0,0,0,0,0,sf::Color(0,0,0,0)));
	}
}
CheckBox::CheckBox(sf::Vector2f& Position, std::string text) {
	Checked = false;
	int LineWidth = 2;
	int Size = 15;
	Position.x += LineWidth;
	Position.y += LineWidth;
	Size -= LineWidth;
	Line1 = sf::Shape::Line((Position.x+1), Position.y+Size/2, (Position.x+Size/2-1), (Position.y+Size-1), LineWidth, sf::Color(0,0,0));
	Line2 = sf::Shape::Line((Position.x+Size/2-1), (Position.y+Size-1), (Position.x+Size-1), (Position.y+1), LineWidth, sf::Color(0,0,0));
	Text.SetPosition(Position.x + Size + 3, Position.y - 3);
	Text.SetSize(15);
	Text.SetText(text);
	Text.SetColor(sf::Color::Black);
	Rand = sf::Shape::Rectangle(Position.x, Position.y, Position.x+Size, Position.y+Size, sf::Color(0,0,0,0), LineWidth, sf::Color(0,0,0,80));
}
void CheckBox::IsClicked(sf::Vector2i& MousePosition) {
	if(MousePosition.x > Rand.GetPointPosition(0).x && MousePosition.x < Rand.GetPointPosition(2).x && MousePosition.y > Rand.GetPointPosition(0).y && MousePosition.y < Rand.GetPointPosition(2).y) {
		Checked = !Checked;
	}
}