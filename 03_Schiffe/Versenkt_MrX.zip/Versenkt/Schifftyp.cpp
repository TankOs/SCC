#include "Schifftyp.h"

sf::Image Schiffstyp::GetroffenV, Schiffstyp::GetroffenH;

Schiffstyp::Schiffstyp() {}
void Schiffstyp::Init(int l�nge, std::string basis) {
	Img.resize(l�nge);
	for(int i = 0; i < l�nge; i++) {
		std::ostringstream os;
		os << i;
		Img[i].LoadFromFile("Grafik/" + basis + "/" + os.str() + ".png");
		Img[i].CreateMaskFromColor(sf::Color::White);
	}
	GetroffenH.LoadFromFile("Grafik/TrefferSchiffH.png");
	GetroffenV.LoadFromFile("Grafik/TrefferSchiffV.png");
}
int Schiffstyp::GetL�nge() {
	return(Img.size());
}
sf::Image& Schiffstyp::GetImg(bool Zerst�rt, int St�ck, bool Vertikal) {
	if(Zerst�rt) {
		if(Vertikal) {
			return(GetroffenV);
		}
		else {
			return(GetroffenH);
		}
	}
	else {
		return(Img[St�ck]);
	}
}