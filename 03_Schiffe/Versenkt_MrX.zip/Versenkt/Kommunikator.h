#pragma once
#include "Spielstatus.h"

class Kommunikator : sf::Thread {
private:
	sf::Packet Meldung;
	sf::SocketTCP Client;
public:
	Kommunikator();
	void (*Treffer)(int x, int y, bool b);
	void (*Getroffen)(int x, int y, bool b);
	void Anmelden(sf::IPAddress IP = sf::IPAddress("boxbox.org"), int Port = 10500);
	virtual void Run();
	void SetNick(std::string Nick);
	void Bombardieren(unsigned char x, unsigned char y);
	void SetzeSchiff(unsigned char Num, bool Vertikal, sf::Vector2<unsigned char> Koord);
	void ExitMatch();
	void Zuf�lligesSpiel();
	void NeuesSpiel();
	void MatchInfo();
	void Disconnect();
	void BestimmtesSpiel(std::string Gegner);
	~Kommunikator();
};
extern Kommunikator Client;