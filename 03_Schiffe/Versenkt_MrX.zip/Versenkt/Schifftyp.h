#pragma once
#include "SoundLoop.h"

class Schiffstyp {
private:
	static sf::Image GetroffenV, GetroffenH;
	std::vector<sf::Image> Img;
public:
	Schiffstyp();
	void Init(int l�nge, std::string basis);
	int GetL�nge();
	sf::Image& GetImg(bool Zerst�rt, int St�ck, bool Vertikal);
};