#include "Spielfeld.h"

sf::Vector2i MausVorher;
sf::Shape Up, Down;

void RessourcenLaden() {
	for(int i = 0; i < 4; i++) {
		std::ostringstream os;
		os << i;
		iHintergrund[i].LoadFromFile("Grafik/Hintergrund" + os.str() + ".png");
	}
	Hintergrundsound.OpenFromFile("Sound/Hintergrund.ogg");
	SoundLoop::LadeSounds();
	Spielfeld::ImgLaden();
	InitSchiffTypen();
}

void SetRandomSchiffe() {
	do {
		for(int i = 0; i < 5; i++) {
			if(std::rand() % 2 == 0) {
				Schiffe[i].Vertikal = true;
			}
			else {
				Schiffe[i].Vertikal = false;
			}
			Schiffe[i].Position = FeldI.GetPosition() + sf::Vector2i((std::rand()%10) * KSize, (std::rand()%10) * KSize);
		}
	}
	while(!FeldI.Pr�fen());
	for(int i = 0; i < 5; i++) {
		Client.SetzeSchiff(i, Schiffe[i].Vertikal, FeldI.GetKoords(&Schiffe[i]));
	}
}

int WRBi = 0;
int WRBj = 0;

void WerfeRandomBombe() {
	for(int i = 9; i >= 0; i--) {
		for(int j = 9; j >= 0; j--) {
			if(FeldG.Feldzustand[i][j] == 2) {
				if(i < 9 && FeldG.Feldzustand[i+1][j] == 0) {
					FeldG.Click(FeldG.GetPosition() + sf::Vector2i((i+1)*KSize+5, j*KSize+5));
					return;
				}
				if(j < 9 && FeldG.Feldzustand[i][j+1] == 0) {
					FeldG.Click(FeldG.GetPosition() + sf::Vector2i(i*KSize+5, (j+1)*KSize+5));
					return;
				}
				if(i > 0 && FeldG.Feldzustand[i-1][j] == 0) {
					FeldG.Click(FeldG.GetPosition() + sf::Vector2i((i-1)*KSize+5, j*KSize+5));
					return;
				}
				if(j > 0 && FeldG.Feldzustand[i][j-1] == 0) {
					FeldG.Click(FeldG.GetPosition() + sf::Vector2i(i*KSize+5, (j-1)*KSize+5));
					return;
				}
			}
		}
	}
	FeldG.Click(FeldG.GetPosition() + sf::Vector2i(WRBj * KSize + 5, (WRBi * 2 + WRBj % 2) * KSize + 5));
	WRBj++;
	if(WRBj >= 10) {
		WRBi++;
		WRBj = 0;
	}
	if(WRBi >= 5) {
		WRBi = 0;
	}
}

int main() {
	std::srand(std::clock());
	sf::String Sieg("Gewonnen!"), Niederlage("Verloren!");
	Sieg.SetSize(100);
	Sieg.SetColor(sf::Color(50, 175, 50));
	Sieg.SetPosition(400-Sieg.GetRect().GetWidth()/2, 300 - Sieg.GetRect().GetHeight()/2);
	Niederlage.SetSize(100);
	Niederlage.SetColor(sf::Color(175, 50, 50));
	Niederlage.SetPosition(400-Sieg.GetRect().GetWidth()/2, 300 - Sieg.GetRect().GetHeight()/2);
	Up.SetColor(sf::Color(50,150,50));
	Up.AddPoint(287.5, 35);
	Up.AddPoint(277, 50);
	Up.AddPoint(298, 50);
	Down.SetColor(sf::Color(50,150,50));
	Down.AddPoint(287.5, 580);
	Down.AddPoint(277, 565);
	Down.AddPoint(298, 565);
	RessourcenLaden();
	SoundPlayer.Launch();
	InitStati();
	Client.Anmelden();
	sf::RenderWindow RW(sf::VideoMode(800, 600), "Versenkt!", sf::Style::Close);
	Hintergrundsound.SetLoop(true);
	Fehler.SetPosition(5, 5);
	Fehler.SetSize(15);
	RW.UseVerticalSync(true);
	const sf::Input& IP = RW.GetInput();
	while(GetStatus() != ENDE) {
		RW.Clear();
		RW.Draw(Hintergrund);
		RW.Draw(Fehler);
		if(Fehleruhr.GetElapsedTime() > 5) {
			Fehler.SetText("");
		}
		switch(GetStatus()) {
			case NAME:
				RW.Draw(Name->getBorder());
				RW.Draw(Name->getText());
				if(IP.IsKeyDown(sf::Key::Return)) {
					if(Name->IsNotLeer()) {
						Client.SetNick(Name->getText().GetText());
					}
				}
				break;
			case MEN�:
				for(int i = 0; i < 4; i++) {
					RW.Draw(Men�[i]->getBorder());
					RW.Draw(Men�[i]->getText());
				}
				RW.Draw(KI->getBorder());
				RW.Draw(KI->getLine1());
				RW.Draw(KI->getLine2());
				RW.Draw(KI->getText());
				break;
			case AUSWAHL:
				for(unsigned int i = 0; i < Spielauswahl.size(); i++) {
					if(Spielauswahl[i].GetPosition().y <= 550 && Spielauswahl[i].GetPosition().y >= 55) {
						RW.Draw(Spielauswahl[i].getBorder());
						RW.Draw(Spielauswahl[i].getText());
					}
				}
				if(Spielauswahl.size() != 0) {
					if(Spielauswahl[0].GetPosition().y < 55) {
						RW.Draw(Up);
					}
					if(Spielauswahl[Spielauswahl.size()-1].GetPosition().y > 550) {
						RW.Draw(Down);
					}
				}
				RW.Draw(Hauptmen�->getBorder());
				RW.Draw(Hauptmen�->getText());
				break;
			case WARTEN:
				RW.Draw(Hauptmen�->getBorder());
				RW.Draw(Hauptmen�->getText());
				break;
			case SETZEN:
				RW.Draw(Hauptmen�->getBorder());
				RW.Draw(Hauptmen�->getText());
				if(!KISpielt) {
					RW.Draw(AnDerReihe);
				}
				for(int i = 0; i < 5; i++) {
					FeldI.SchiffAufFeld(&Schiffe[i], sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()));
				}
				if(FeldI.Pr�fen() && !KISpielt) {
					RW.Draw(SetzenFertig->getBorder());
					RW.Draw(SetzenFertig->getText());
				}
				else {
					RW.Draw(Zuf�lligPlatzieren->getBorder());
					RW.Draw(Zuf�lligPlatzieren->getText());
				}
				FeldI.Draw(RW);
				FeldG.Draw(RW);
				RW.Draw(Gegner);
				for(int i = 0; i < 5; i++) {
					Schiffe[i].Draw(&RW);
				}
				break;
			case GESETZT:
				RW.Draw(Hauptmen�->getBorder());
				RW.Draw(Hauptmen�->getText());
				FeldI.Draw(RW);
				FeldG.Draw(RW);
				if(!KISpielt) {
					RW.Draw(AnDerReihe);
				}
				RW.Draw(Gegner);
				for(int i = 0; i < 5; i++) {
					Schiffe[i].Draw(&RW);
				}
				break;
			case WERFEN:
				RW.Draw(Hauptmen�->getBorder());
				RW.Draw(Hauptmen�->getText());
				FeldI.Draw(RW);
				FeldG.Draw(RW);
				RW.Draw(Gegner);
				RW.Draw(AnDerReihe);
				for(int i = 0; i < 5; i++) {
					Schiffe[i].Draw(&RW);
				}
				break;
			case GEWONNEN:
				RW.Draw(Hauptmen�->getBorder());
				RW.Draw(Hauptmen�->getText());
				FeldI.Draw(RW);
				FeldG.Draw(RW);
				RW.Draw(Gegner);
				for(int i = 0; i < 5; i++) {
					Schiffe[i].Draw(&RW);
				}
				RW.Draw(Sieg);
				break;
			case VERLOREN:
				RW.Draw(Hauptmen�->getBorder());
				RW.Draw(Hauptmen�->getText());
				FeldI.Draw(RW);
				FeldG.Draw(RW);
				for(int i = 0; i < 5; i++) {
					Schiffe[i].Draw(&RW);
				}
				RW.Draw(Niederlage);
				break;
		}
		while(RW.GetEvent(EV)) {
			if(EV.Type == sf::Event::Closed) {
				SetStatus(ENDE);
			}
			if(EV.Type == sf::Event::TextEntered && EV.Text.Unicode < 128) {
				if(GetStatus() == NAME)
					Name->AddText(static_cast<char>(EV.Text.Unicode)); 
				if(GetStatus() == SETZEN && EV.Text.Unicode == 'd') {
					for(int i = 0; i < 5; i++) {
						Schiffe[i].RadGedreht();
					}
				}
			}
			if(EV.Type == sf::Event::MouseWheelMoved) {
				for(int i = 0; i < 5; i++) {
					Schiffe[i].RadGedreht();
				}
			}
			if(EV.Type == sf::Event::MouseMoved) {
				if(IP.IsMouseButtonDown(sf::Mouse::Left) && GetStatus() == SETZEN)  {
					for(int i = 0; i < 5; i++) {
						Schiffe[i].Click(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()), MausVorher);
					}
				}
			}
			if(EV.Type == sf::Event::MouseButtonReleased) {
				if(EV.MouseButton.Button == sf::Mouse::Left) {
					switch(GetStatus()) {
						case SETZEN:
							for(int i = 0; i < 5; i++) {
								Schiffe[i].Geklickt = false;
							}
							break;
					}
				}
			}
			if(EV.Type == sf::Event::MouseButtonPressed) {
				if(EV.MouseButton.Button == sf::Mouse::Left) {
					switch(GetStatus()) {
						case NAME:
							break;
						case MEN�:
							KI->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()));
							if(Men�[0]->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
								SetStatus(ENDE);
								break;
							}
							if(Men�[1]->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
								Client.NeuesSpiel();
								break;
							}
							if(Men�[2]->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
								Client.Zuf�lligesSpiel();
								break;
							}
							if(Men�[3]->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
								Client.MatchInfo();
								break;
							}
							break;
						case AUSWAHL:
							if(IP.GetMouseX() < 298 && IP.GetMouseX() > 277) {
								if(IP.GetMouseY() < 50 && IP.GetMouseY() > 35 && Spielauswahl[0].GetPosition().y < 55) {
									for(unsigned int i = 0; i < Spielauswahl.size(); i++) {
										Spielauswahl[i].SetPosition(sf::Vector2f(Spielauswahl[i].GetPosition().x, Spielauswahl[i].GetPosition().y + 30));
									}
								}
								if(IP.GetMouseY() < 580 && IP.GetMouseY() > 565 && Spielauswahl[Spielauswahl.size()-1].GetPosition().y > 550) {
									for(unsigned int i = 0; i < Spielauswahl.size(); i++) {
										Spielauswahl[i].SetPosition(sf::Vector2f(Spielauswahl[i].GetPosition().x, Spielauswahl[i].GetPosition().y - 30));
									}
								}
							}
							if(IP.GetMouseY() <= 565 && IP.GetMouseY() >= 50) {
								for(unsigned int i = 0; i < Spielauswahl.size(); i++) {
									if(Spielauswahl[i].IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
										Client.BestimmtesSpiel(Spielauswahl[i].getText().GetText().operator std::string().substr(8));
									}
								}
							}
							if(Hauptmen�->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
								SetStatus(MEN�);
							}
							break;
						case WARTEN:
							if(Hauptmen�->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
								SetStatus(MEN�);
							}
							break;
						case SETZEN:
							if(!KISpielt) {
								if(FeldI.Pr�fen()) {
									if(SetzenFertig->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
										for(int i = 0; i < 5; i++) {
											Client.SetzeSchiff(i, Schiffe[i].Vertikal, FeldI.GetKoords(&Schiffe[i]));
										}
									}
								}
								else {
									if(Zuf�lligPlatzieren->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
										SetRandomSchiffe();
									}
								}
							}
							if(Hauptmen�->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
								SetStatus(MEN�);
							}
							break;
						case GESETZT:
							if(Hauptmen�->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
								SetStatus(MEN�);
							}
							break;
						case WERFEN:
							if(Hauptmen�->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
								SetStatus(MEN�);
							}
							if(!KISpielt) {
								FeldG.Click(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()));
							}
							break;
						case GEWONNEN:
							if(Hauptmen�->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
								SetStatus(MEN�);
							}
							break;
						case VERLOREN:
							if(Hauptmen�->IsClicked(sf::Vector2i(IP.GetMouseX(), IP.GetMouseY()))) {
								SetStatus(MEN�);
							}
							break;

					}
				}
			}
		}
		RW.Display();
		MausVorher = sf::Vector2i(IP.GetMouseX(), IP.GetMouseY());
	}
	return EXIT_SUCCESS;
}