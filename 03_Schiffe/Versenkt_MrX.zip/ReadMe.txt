Schiffe Versenken Client "Versenkt!" von Philipp Kloke

Anleitung:
1. Starten Sie das Programm
2. Geben Sie ihren Nicknamen ein
3. Dr�cken Sie Enter
4. W�hlen Sie den Spielmodus. Wenn Die KI-Spielen sollen, setzen sie ein H�kchen bei "Computer spielt (KI-Modus)". Dann k�nnen sie, nachdem Sie den Spielmodus gew�hlt haben, direkt mit Schritt 7 fortfahren.
4.1. Wenn Sie "Bestimmtes Spiel" gew�hlt haben: W�hlen Sie den Gegner aus
5. Platzieren Sie per Drag&Drop ihre Schiffe und klicken Sie auf "Schiffe Positionieren". Sie k�nnen die Schiffe mitdem Mausrad oder der Taste "d" drehen. Sie k�nnen auch einfach "Zuf�llig platzieren" dr�cken, dann werden die Schiffe zuf�llig platziert.
6. Werfen Sie wenn Sie an der Reihe sind Bomben, indem Sie in das gegnerische Feld klicken.
7. Gewinnen Sie ;-)



Der Quellcode steht unter GPL.
Das Copyright der Grafiken liegt bei:
Hintergrund0.png	Abgelaufen
Hintergrund1.png	Abgelaufen
Hintergrund2.png	Siehe Bild
Das Copyright aller anderen Bilder und der Sounds liegt beim Programmautor.


Viel Spa� mit Versenkt!