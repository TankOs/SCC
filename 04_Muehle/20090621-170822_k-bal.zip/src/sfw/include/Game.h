#pragma once


#include "GameState.h"
#include <stack>
#include <SFML/Graphics.hpp>

namespace sfw {

typedef std::stack<GameState*> StateStack;

class Game : public sf::RenderWindow
{
    protected:
    // Member
        StateStack m_gameStates;

    public:
    // Functions
    // ---- Init, Main Loop & CleanUp ----
        virtual void init() = 0;
        virtual void doMainLoop() = 0;
        virtual void cleanUp() = 0;

    // ---- Game State Related ----
        void changeState(GameState* newState);
        void pushState(GameState* newState);
        void popState();

    public:
    // Constructor / Destructor
        Game(const sf::VideoMode videoMode,
                const std::string& windowTitle,
                unsigned long windowStyle = sf::Style::Resize|sf::Style::Close);
        virtual ~Game();
};

}
