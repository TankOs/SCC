#pragma once

#include <SFML/Graphics.hpp>

namespace sfw {

class GameState
{
    public:
    // Functions
        virtual void init() = 0;
        virtual void cleanUp() = 0;

        virtual void pause() = 0;
        virtual void resume() = 0;

        virtual void handleEvents() = 0;
        virtual void update() = 0;
        virtual void render() = 0;

        static GameState* instance();

    protected:
    // Constructor / Destructor
        GameState(sf::RenderWindow* app);
        virtual ~GameState();

    // Member
        sf::RenderWindow* m_app;
};

}
