#pragma once

#include <map>
#include <string>

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

// Container for Images
typedef std::map<std::string, sf::Image*> ImageMap;
// Container for SoundBuffers
typedef std::map<std::string, sf::SoundBuffer*> SoundBufferMap;
// Countainer for Music
typedef std::map<std::string, sf::Music*> MusicMap;

namespace sfw {

class ResourceManager
{
    private:
        // Member
        ImageMap m_Images;
        SoundBufferMap m_SoundBuffers;
        MusicMap m_Songs;
        sf::Font* m_DefaultFont;

    public:
        // Functions

        // ---- Singleton ----

        static ResourceManager* instance()
        {
            static ResourceManager myInstance;
            return &myInstance;
        }

        // ---- Image related ----
    private:
        bool pushImage(const std::string& key);         // Loads an Image, key is the relative filename,
                                                        // returns true on success, false on failure
    public:
        void deleteImage(const std::string& key);       // Deletes an Image, key is the relative filename

        sf::Image* getImage(const std::string& key);    // Returns an Image from the Container,
                                                        // if the image is not found it will try to load it,
                                                        // if that fails to it will return 0

        int getNumImages();                             // Returns the number of images in the container


        // ---- Sound related ----
    private:
        bool pushSoundBuffer(const std::string& key);               // Loads a Sound, key is the relative filename,
                                                                    // returns true on success, false on failure
    public:
        void deleteSoundBuffer(const std::string& key);             // Deletes a Sound, key is the relative filename

        sf::SoundBuffer* getSoundBuffer(const std::string& key);    // Returns an SoundBuffer from the Container,
                                                                    // if the SoundBuffer is not found it will try to load it,
                                                                    // if that fails to it will return 0

        int getNumSoundBuffers();                                   // Returns the number of SoundBuffers in the Container


        // ---- Music related ----
    private:
        bool loadSong(const std::string& key);

    public:
        void deleteSong(const std::string& key);

        void playSong(const std::string& key, bool loop);
        void pauseSong(const std::string& key);
        void stopSong(const std::string& key);

        int getNumSongs();                                   // Returns the number of Songs in the Container



        // ---- Font related ----

        sf::Font* getDefaultFont();                                            // Returns the default font

        void setDefaultFont(const std::string& filename, int fontsize = 30);   // Sets the default font

    protected:
        // Constructor / Destructor
        ResourceManager();
        virtual ~ResourceManager();
};

}
