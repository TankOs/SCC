#include "GameState.h"
#include "Game.h"

namespace sfw{

// Constructor / Destructor
GameState::GameState(sf::RenderWindow* app) : m_app(app)
{
}

GameState::~GameState()
{

}

}
