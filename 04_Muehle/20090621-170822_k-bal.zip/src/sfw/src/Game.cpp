#include "Game.h"
#include "GameState.h"

namespace sfw{

// ---- Game State Related ----
void Game::changeState(GameState* newState)
{
    if(!m_gameStates.empty())
    {
        m_gameStates.top()->cleanUp();
        m_gameStates.pop();
    }
    m_gameStates.push(newState);
    m_gameStates.top()->init();

}

void Game::pushState(GameState* newState)
{
    if(!m_gameStates.empty())
    {
        m_gameStates.top()->pause();
    }
    m_gameStates.push(newState);
    m_gameStates.top()->init();
}

void Game::popState()
{
    if(!m_gameStates.empty())
    {
        m_gameStates.top()->cleanUp();
        m_gameStates.pop();
    }
    if(!m_gameStates.empty())
    {
        m_gameStates.top()->resume();
    }
}

// Constructor / Destructor
Game::Game
(const sf::VideoMode videoMode,
const std::string& windowTitle,
unsigned long windowStyle)
: sf::RenderWindow(videoMode, windowTitle, windowStyle)
{

}

Game::~Game()
{

}

}
