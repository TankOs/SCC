#include "GameState.h"

class GS_Intro : public sfw::GameState
{
    protected:
    // Constructor / Destructor
        GS_Intro(sf::RenderWindow* app);
        virtual ~GS_Intro();

    public:
    // Functions
        void init();
        void cleanUp();

        void pause();
        void resume();

        void handleEvents();
        void update();
        void render();

        static GS_Intro* instance(sf::RenderWindow* app);

    private:
        double m_clock;
        sf::String m_description1;
        sf::String m_description2;
        sf::String m_description3;
};
