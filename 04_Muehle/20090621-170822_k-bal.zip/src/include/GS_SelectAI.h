#include "GameState.h"

class GS_SelectAI : public sfw::GameState
{
    protected:
    // Constructor / Destructor
        GS_SelectAI(sf::RenderWindow* app);
        virtual ~GS_SelectAI();

    public:
    // Functions
        void init();
        void cleanUp();

        void pause();
        void resume();

        void handleEvents();
        void update();
        void render();

        bool getIsAI();

        static GS_SelectAI* instance(sf::RenderWindow* app);

    private:
        double m_clock;
        sf::String m_description1;
        sf::String m_description2;
        bool m_isAI;
};

