#pragma once

#include "Game.h"

class MorrisGame : public sfw::Game
{
    public:
        MorrisGame(const sf::VideoMode videoMode,
                const std::string& windowTitle,
                unsigned long windowStyle = sf::Style::Resize|sf::Style::Close);
        ~MorrisGame();

        void init();
        void doMainLoop();
        void cleanUp();
};
