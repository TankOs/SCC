#pragma once

#include "Stone.h"
#include "Enums.h"
#include <SFML/Graphics.hpp>
#include <vector>

class PlayerStatus
{
    private:
        PlayerStatus();
    public:
        PlayerStatus(Owner owner, const int startMoney, const int startMoral);
        ~PlayerStatus();

        void update();
        void draw(sf::RenderWindow& window);

        unsigned int getNumActiveStones();

        bool getIsComputer();

        void setIsComputer(bool isComputer);

        static const int maxUnits = 9;

    public:
        int m_money;
    private:
        int m_startMoney;
    public:
        int m_moral;
    private:
        int m_startMoral;


    public:
        Stone* m_stones[maxUnits];

    private:
        Owner m_owner;
        bool m_isComputer;

};
