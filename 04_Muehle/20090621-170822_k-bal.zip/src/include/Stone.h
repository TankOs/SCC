#ifndef _STONE_H_
#define _STONE_H_

#include "Enums.h"
#include <SFML/Graphics.hpp>

class BoardPoint;

class Stone : public sf::Sprite
{
    public:
        Stone(Owner owner, bool isKnight = false);
        virtual ~Stone();

        virtual void Render(sf::RenderTarget& Target) const;

        BoardPoint* m_position;
        bool m_isKnight;
        bool m_isActive;

        Owner m_owner;
};

#endif
