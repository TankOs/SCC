#pragma once

#include "GameState.h"
#include "Board.h"
#include "Enums.h"
#include "PlayerStatus.h"
#include <SFML/Audio.hpp>

class GS_Main : public sfw::GameState
{
    protected:
    // Constructor / Destructor
        GS_Main();
        GS_Main(sf::RenderWindow* app);
        virtual ~GS_Main();

    public:
    // Functions
        void init();
        void cleanUp();

        void pause();
        void resume();

        void handleEvents();
        void update();
        void render();

        static GS_Main* instance(sf::RenderWindow* app);

    private:
        double m_clock;
        Board m_board;

        GamePhase m_gamePhase;
        InputState m_inputState;

        PlayerStatus m_playerWhite;
        PlayerStatus m_playerBlack;

        sf::String m_gamePhaseString;
        sf::String m_inputStateString;
        sf::String m_soundString;

        sf::Sprite m_marker;
        sf::Sprite m_soundSprite;

        sf::Sound m_stonePutSound;

        int startPhaseCounterWhite;
        int startPhaseCounterBlack;

        bool m_soundOn;
};
