#ifndef _ENUMS_H_
#define _ENUMS_H_

enum Rings
{
    inner = 0,
    middle,
    outer
};

enum RingPositions
{
    upper_left = 0,
    upper_middle,
    upper_right,
    middle_right,
    lower_right,
    lower_middle,
    lower_left,
    middle_left
};

enum Owner
{
    none = 0,
    white = 1,
    black = 2
};

enum InputState
{
    whiteSelectOwn = 0,
    whiteSelected,
    whiteSelectEnemy,
    blackSelectOwn,
    blackSelected,
    blackSelectEnemy
};

enum GamePhase
{
    start = 0,
    midgame,
    whiteEndgame,
    blackEndgame,
    endgame,
    whiteWin,
    blackWin
};

#endif
