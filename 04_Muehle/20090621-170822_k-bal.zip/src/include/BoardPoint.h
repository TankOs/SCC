#ifndef _BOARDPOINT_H_
#define _BOARDPOINT_H_


#include "Enums.h"
#include "Stone.h"

class BoardPoint
{
    public:
        BoardPoint();
        ~BoardPoint();

        bool setStone(Stone* stone);
        void setPosition(Rings ring, RingPositions position, sf::Vector2f pixelPos);


        Owner getOwner();
        Stone* getStone();
        Rings getRing();
        RingPositions getRingPosition();
        sf::Vector2f getPixelPosition();

        bool operator== (const BoardPoint& operand)
        {
            if(m_ringPosition == operand.m_ringPosition
            && m_ring == operand.m_ring)
            {
                return true;
            }
            return false;
        }

        static const unsigned int radius = 22;

    private:
        Rings m_ring;
        RingPositions m_ringPosition;
        sf::Vector2f m_pixelPosition;
        Owner m_owner;
        Stone* m_stone;


    public:
        BoardPoint* upperNeighbor;
        BoardPoint* leftNeighbor;
        BoardPoint* rightNeighbor;
        BoardPoint* lowerNeighbor;
};



#endif
