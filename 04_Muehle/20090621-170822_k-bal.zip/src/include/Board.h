#pragma once

#include "BoardPoint.h"
#include "Stone.h"
#include "Enums.h"
#include <SFML/Graphics.hpp>

class Board : public sf::Sprite
{
    public:
        Board();
        ~Board();

        bool putStone(Stone* stone);

        BoardPoint* checkMouseButtonClick(sf::Vector2f mousePos);
        BoardPoint* getRandomPoint();
        BoardPoint* getRandomBlackPoint();
        BoardPoint* getRandomWhitePoint();
        BoardPoint* getRandomNeighbor(BoardPoint* point);
        bool checkMill(BoardPoint* closer);
        bool checkAllStonesInMill(Owner owner);
        bool checkPlayerCanMove(Owner owner);
        bool checkStoneCanMove(BoardPoint* point);

        void updatePositions();

    private:
        BoardPoint m_points[24];
};
