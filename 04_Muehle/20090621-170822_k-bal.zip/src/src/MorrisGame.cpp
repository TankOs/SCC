#include "MorrisGame.h"
#include "GS_Intro.h"

MorrisGame::MorrisGame
(const sf::VideoMode videoMode,
const std::string& windowTitle,
unsigned long windowStyle)
: sfw::Game(videoMode, windowTitle, windowStyle)
{

}

MorrisGame::~MorrisGame()
{

}

void MorrisGame::init()
{
    changeState(GS_Intro::instance(this));
}

void MorrisGame::doMainLoop()
{
    while(IsOpened())
    {
        m_gameStates.top()->handleEvents();

        m_gameStates.top()->update();

        Clear(sf::Color(0, 0, 0));

        m_gameStates.top()->render();

        Display();
    }
}
void MorrisGame::cleanUp()
{}
