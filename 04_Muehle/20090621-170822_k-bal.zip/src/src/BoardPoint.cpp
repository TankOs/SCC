#include "BoardPoint.h"
#include "Enums.h"
#include "ResourceManager.h"

BoardPoint::BoardPoint()
{

}
BoardPoint::~BoardPoint()
{

}

void BoardPoint::setPosition(Rings ring, RingPositions position, sf::Vector2f pixelPos)
{
    m_ring = ring;
    m_ringPosition = position;
    m_pixelPosition = pixelPos;
}

bool BoardPoint::setStone(Stone* stone)
{
    if(stone == 0 && m_stone)
    {
        m_stone = 0;
        m_owner = none;
        return true;
    }
    if(m_stone == 0)
    {
        m_stone = stone;
        m_stone->m_isActive = true;
        m_stone->SetPosition(m_pixelPosition);
        m_owner = stone->m_owner;
        return true;
    }
    return false;
}



Owner BoardPoint::getOwner()
{
    return m_owner;
}
Stone* BoardPoint::getStone()
{
    return m_stone;
}
Rings BoardPoint::getRing()
{
    return m_ring;
}
RingPositions BoardPoint::getRingPosition()
{
    return m_ringPosition;
}
sf::Vector2f BoardPoint::getPixelPosition()
{
    return m_pixelPosition;
}

