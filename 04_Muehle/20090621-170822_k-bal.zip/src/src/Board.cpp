#include "Board.h"
#include "Enums.h"
#include "stdlib.h"
#include "time.h"

Board::Board()
{
    m_points[0].upperNeighbor = 0;
    m_points[0].leftNeighbor = 0;
    m_points[0].rightNeighbor = &m_points[1];
    m_points[0].lowerNeighbor = &m_points[7];

    m_points[1].upperNeighbor = &m_points[9];
    m_points[1].leftNeighbor = &m_points[0];
    m_points[1].rightNeighbor = &m_points[2];
    m_points[1].lowerNeighbor = 0;

    m_points[2].upperNeighbor = 0;
    m_points[2].leftNeighbor = &m_points[1];
    m_points[2].rightNeighbor = 0;
    m_points[2].lowerNeighbor = &m_points[3];

    m_points[3].upperNeighbor = &m_points[2];
    m_points[3].leftNeighbor = 0;
    m_points[3].rightNeighbor = &m_points[11];
    m_points[3].lowerNeighbor = &m_points[4];

    m_points[4].upperNeighbor = &m_points[3];
    m_points[4].leftNeighbor = &m_points[5];
    m_points[4].rightNeighbor = 0;
    m_points[4].lowerNeighbor = 0;

    m_points[5].upperNeighbor = 0;
    m_points[5].leftNeighbor = &m_points[6];
    m_points[5].rightNeighbor = &m_points[4];
    m_points[5].lowerNeighbor = &m_points[13];

    m_points[6].upperNeighbor = &m_points[7];
    m_points[6].leftNeighbor = 0;
    m_points[6].rightNeighbor = &m_points[5];
    m_points[6].lowerNeighbor = 0;

    m_points[7].upperNeighbor = &m_points[0];
    m_points[7].leftNeighbor = &m_points[15];
    m_points[7].rightNeighbor = 0;
    m_points[7].lowerNeighbor = &m_points[6];

    m_points[8].upperNeighbor = 0;
    m_points[8].leftNeighbor = 0;
    m_points[8].rightNeighbor = &m_points[9];
    m_points[8].lowerNeighbor = &m_points[15];

    m_points[9].upperNeighbor = &m_points[17];
    m_points[9].leftNeighbor = &m_points[8];
    m_points[9].rightNeighbor = &m_points[10];
    m_points[9].lowerNeighbor = &m_points[1];

    m_points[10].upperNeighbor = 0;
    m_points[10].leftNeighbor = &m_points[9];
    m_points[10].rightNeighbor = 0;
    m_points[10].lowerNeighbor = &m_points[11];

    m_points[11].upperNeighbor = &m_points[10];
    m_points[11].leftNeighbor = &m_points[3];
    m_points[11].rightNeighbor = &m_points[19];
    m_points[11].lowerNeighbor = &m_points[12];

    m_points[12].upperNeighbor = &m_points[11];
    m_points[12].leftNeighbor = &m_points[13];
    m_points[12].rightNeighbor = 0;
    m_points[12].lowerNeighbor = 0;

    m_points[13].upperNeighbor = &m_points[5];
    m_points[13].leftNeighbor = &m_points[14];
    m_points[13].rightNeighbor = &m_points[12];
    m_points[13].lowerNeighbor = &m_points[21];

    m_points[14].upperNeighbor = &m_points[15];
    m_points[14].leftNeighbor = 0;
    m_points[14].rightNeighbor = &m_points[13];
    m_points[14].lowerNeighbor = 0;

    m_points[15].upperNeighbor = &m_points[8];
    m_points[15].leftNeighbor = &m_points[23];
    m_points[15].rightNeighbor = &m_points[7];
    m_points[15].lowerNeighbor = &m_points[14];

    m_points[16].upperNeighbor = 0;
    m_points[16].leftNeighbor = 0;
    m_points[16].rightNeighbor = &m_points[17];
    m_points[16].lowerNeighbor = &m_points[23];

    m_points[17].upperNeighbor = 0;
    m_points[17].leftNeighbor = &m_points[16];
    m_points[17].rightNeighbor = &m_points[18];
    m_points[17].lowerNeighbor = &m_points[9];

    m_points[18].upperNeighbor = 0;
    m_points[18].leftNeighbor = &m_points[17];
    m_points[18].rightNeighbor = 0;
    m_points[18].lowerNeighbor = &m_points[19];

    m_points[19].upperNeighbor = &m_points[18];
    m_points[19].leftNeighbor = &m_points[11];
    m_points[19].rightNeighbor = 0;
    m_points[19].lowerNeighbor = &m_points[20];

    m_points[20].upperNeighbor = &m_points[19];
    m_points[20].leftNeighbor = &m_points[21];
    m_points[20].rightNeighbor = 0;
    m_points[20].lowerNeighbor = 0;

    m_points[21].upperNeighbor = &m_points[13];
    m_points[21].leftNeighbor = &m_points[22];
    m_points[21].rightNeighbor = &m_points[20];
    m_points[21].lowerNeighbor = 0;

    m_points[22].upperNeighbor = &m_points[23];
    m_points[22].leftNeighbor = 0;
    m_points[22].rightNeighbor = &m_points[21];
    m_points[22].lowerNeighbor = 0;

    m_points[23].upperNeighbor = &m_points[16];
    m_points[23].leftNeighbor = 0;
    m_points[23].rightNeighbor = &m_points[15];
    m_points[23].lowerNeighbor = &m_points[22];
}

Board::~Board()
{}

BoardPoint* Board::checkMouseButtonClick(sf::Vector2f mousePos)
{
    double radius_sqr = BoardPoint::radius*BoardPoint::radius;

    for(int i = 0; i < 24; i++)
    {
        double x_sqr = (m_points[i].getPixelPosition().x+20 - mousePos.x)*(m_points[i].getPixelPosition().x+20 - mousePos.x);
        double y_sqr = (m_points[i].getPixelPosition().y+20 - mousePos.y)*(m_points[i].getPixelPosition().y+20 - mousePos.y);

        if((x_sqr + y_sqr) < radius_sqr)
        {
            return &m_points[i];
        }
    }
    return 0;
}

BoardPoint* Board::getRandomPoint()
{
    srand(time(0));
    return &m_points[rand() % 24];
}

BoardPoint* Board::getRandomBlackPoint()
{
    std::vector<BoardPoint*> points;
    for(int i = 0; i < 24; i++)
    {
        if(m_points[i].getOwner() == black)
        {
            points.push_back(&m_points[i]);
        }
    }
    return points[rand() % points.size()];
}

BoardPoint* Board::getRandomWhitePoint()
{
    std::vector<BoardPoint*> points;
    for(int i = 0; i < 24; i++)
    {
        if(m_points[i].getOwner() == white)
        {
            points.push_back(&m_points[i]);
        }
    }
    return points[rand() % points.size()];
}

BoardPoint* Board::getRandomNeighbor(BoardPoint* point)
{
    if(!point)
    {
        return 0;
    }


    BoardPoint* returnPoint = 0;

    while(!returnPoint)
    {
        unsigned int randomValue = rand() % 4;
        if(randomValue == 0 && point->upperNeighbor)
        {
            returnPoint = point->upperNeighbor;
        }
        else if(randomValue == 1 && point->leftNeighbor)
        {
            returnPoint = point->leftNeighbor;
        }
        else if(randomValue == 2 && point->rightNeighbor)
        {
            returnPoint = point->rightNeighbor;
        }
        else if(randomValue == 3 && point->lowerNeighbor)
        {
            returnPoint = point->rightNeighbor;
        }
    }
    return returnPoint;
}

bool Board::checkMill(BoardPoint* closer)
{
    if(closer->upperNeighbor && closer->upperNeighbor->upperNeighbor)
    {
        if(closer->getOwner() & closer->upperNeighbor->getOwner() & closer->upperNeighbor->upperNeighbor->getOwner())
        {
            return true;
        }
    }
    if(closer->leftNeighbor && closer->leftNeighbor->leftNeighbor)
    {
        if(closer->getOwner() & closer->leftNeighbor->getOwner() & closer->leftNeighbor->leftNeighbor->getOwner())
        {
            return true;
        }
    }
    if(closer->rightNeighbor && closer->rightNeighbor->rightNeighbor)
    {
        if(closer->getOwner() & closer->rightNeighbor->getOwner() & closer->rightNeighbor->rightNeighbor->getOwner())
        {
            return true;
        }
    }
    if(closer->lowerNeighbor && closer->lowerNeighbor->lowerNeighbor)
    {
        if(closer->getOwner() & closer->lowerNeighbor->getOwner() & closer->lowerNeighbor->lowerNeighbor->getOwner())
        {
            return true;
        }
    }
    if(closer->lowerNeighbor && closer->upperNeighbor)
    {
        if(closer->getOwner() & closer->lowerNeighbor->getOwner() & closer->upperNeighbor->getOwner())
        {
            return true;
        }
    }
    if(closer->leftNeighbor && closer->rightNeighbor)
    {
        if(closer->getOwner() & closer->leftNeighbor->getOwner() & closer->rightNeighbor->getOwner())
        {
            return true;
        }
    }
    return false;
}

bool Board::checkAllStonesInMill(Owner owner)
{
    for(int i = 0; i < 24; i++)
    {
        if(m_points[i].getOwner() == owner && !checkMill(&m_points[i]))
        {
            return false;
        }
    }
    return true;
}
bool Board::checkPlayerCanMove(Owner owner)
{
    for(int i = 0; i < 24; i++)
    {
        if(m_points[i].getOwner() == owner)
        {
            if(m_points[i].upperNeighbor && (m_points[i].upperNeighbor->getOwner() == none))
            {
                return true;
            }
            else if(m_points[i].leftNeighbor && (m_points[i].leftNeighbor->getOwner() == none))
            {
                return true;
            }
            else if(m_points[i].rightNeighbor && (m_points[i].rightNeighbor->getOwner() == none))
            {
                return true;
            }
            else if(m_points[i].lowerNeighbor && (m_points[i].lowerNeighbor->getOwner() == none))
            {
                return true;
            }
        }
    }
    return false;
}

bool Board::checkStoneCanMove(BoardPoint* point)
{
    if(!point)
    {
        return false;
    }

    if(point->upperNeighbor && point->upperNeighbor->getOwner() == none)
    {
        return true;
    }
    if(point->leftNeighbor && point->leftNeighbor->getOwner() == none)
    {
        return true;
    }
    if(point->rightNeighbor && point->rightNeighbor->getOwner() == none)
    {
        return true;
    }
    if(point->lowerNeighbor && point->lowerNeighbor->getOwner() == none)
    {
        return true;
    }
    return false;
}

void Board::updatePositions()
{
    sf::Vector2f boardPos = GetPosition();

    m_points[0].setPosition(inner, upper_left, sf::Vector2f(150+boardPos.x-20,150+boardPos.y-20));
    m_points[1].setPosition(inner, upper_middle, sf::Vector2f(300+boardPos.x-20,150+boardPos.y-20));
    m_points[2].setPosition(inner, upper_right, sf::Vector2f(450+boardPos.x-20,150+boardPos.y-20));
    m_points[3].setPosition(inner, middle_right, sf::Vector2f(450+boardPos.x-20,300+boardPos.y-20));
    m_points[4].setPosition(inner, lower_right, sf::Vector2f(450+boardPos.x-20,450+boardPos.y-20));
    m_points[5].setPosition(inner, lower_middle, sf::Vector2f(300+boardPos.x-20,450+boardPos.y-20));
    m_points[6].setPosition(inner, lower_left, sf::Vector2f(150+boardPos.x-20,450+boardPos.y-20));
    m_points[7].setPosition(inner, middle_left, sf::Vector2f(150+boardPos.x-20,300+boardPos.y-20));

    m_points[8].setPosition(middle, upper_left, sf::Vector2f(100+boardPos.x-20,100+boardPos.y-20));
    m_points[9].setPosition(middle, upper_middle, sf::Vector2f(300+boardPos.x-20,100+boardPos.y-20));
    m_points[10].setPosition(middle, upper_right, sf::Vector2f(500+boardPos.x-20,100+boardPos.y-20));
    m_points[11].setPosition(middle, middle_right, sf::Vector2f(500+boardPos.x-20,300+boardPos.y-20));
    m_points[12].setPosition(middle, lower_right, sf::Vector2f(500+boardPos.x-20,500+boardPos.y-20));
    m_points[13].setPosition(middle, lower_middle, sf::Vector2f(300+boardPos.x-20,500+boardPos.y-20));
    m_points[14].setPosition(middle, lower_left, sf::Vector2f(100+boardPos.x-20,500+boardPos.y-20));
    m_points[15].setPosition(middle, middle_left, sf::Vector2f(100+boardPos.x-20,300+boardPos.y-20));

    m_points[16].setPosition(outer, upper_left, sf::Vector2f(50+boardPos.x-20,50+boardPos.y-20));
    m_points[17].setPosition(outer, upper_middle, sf::Vector2f(300+boardPos.x-20,50+boardPos.y-20));
    m_points[18].setPosition(outer, upper_right, sf::Vector2f(550+boardPos.x-20,50+boardPos.y-20));
    m_points[19].setPosition(outer, middle_right, sf::Vector2f(550+boardPos.x-20,300+boardPos.y-20));
    m_points[20].setPosition(outer, lower_right, sf::Vector2f(550+boardPos.x-20,550+boardPos.y-20));
    m_points[21].setPosition(outer, lower_middle, sf::Vector2f(300+boardPos.x-20,550+boardPos.y-20));
    m_points[22].setPosition(outer, lower_left, sf::Vector2f(50+boardPos.x-20,550+boardPos.y-20));
    m_points[23].setPosition(outer, middle_left, sf::Vector2f(50+boardPos.x-20,300+boardPos.y-20));

}
