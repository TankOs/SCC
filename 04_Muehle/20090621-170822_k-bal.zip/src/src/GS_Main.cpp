#include "GS_Main.h"
#include "GS_SelectAI.h"
#include "ResourceManager.h"
#include "Enums.h"
#include <sstream>

GS_Main::GS_Main(sf::RenderWindow* app) : sfw::GameState(app), m_playerWhite(white,50,80), m_playerBlack(black,50,80)
{

}
GS_Main::~GS_Main()
{

}

void GS_Main::init()
{
    m_playerBlack.setIsComputer(GS_SelectAI::instance(m_app)->getIsAI());
    m_playerWhite.setIsComputer(false);

    m_soundOn = true;

    startPhaseCounterWhite = 0;
    startPhaseCounterBlack = 0;

    m_board.SetImage(*sfw::ResourceManager::instance()->getImage("media/board.png"));
    m_board.SetPosition(212,84);
    m_board.updatePositions();
    m_gamePhase = start;
    m_inputState = whiteSelectOwn;

    m_inputStateString.SetPosition(200, 20);
    m_inputStateString.SetFont(*sfw::ResourceManager::instance()->getDefaultFont());
    m_inputStateString.SetText("White, it's your turn!");

    m_gamePhaseString.SetPosition(200, 720);
    m_gamePhaseString.SetFont(*sfw::ResourceManager::instance()->getDefaultFont());
    m_gamePhaseString.SetText("Position your units on the battlefield!");

    m_soundString.SetPosition(870, 630);
    m_soundString.SetFont(*sfw::ResourceManager::instance()->getDefaultFont());
    m_soundString.SetText("Press TAB to \ntoggle Sound.");

    m_marker.SetImage(*sfw::ResourceManager::instance()->getImage("media/marker.png"));
    m_marker.SetPosition(-100, -100);

    m_soundSprite.SetImage(*sfw::ResourceManager::instance()->getImage("media/soundon.png"));
    m_soundSprite.SetPosition(870, 700);

    m_stonePutSound.SetBuffer(*sfw::ResourceManager::instance()->getSoundBuffer("media/click.wav"));
}
void GS_Main::cleanUp()
{
    sfw::ResourceManager::instance()->stopSong("media/morris.ogg");

}

void GS_Main::pause()
{}
void GS_Main::resume()
{}

void GS_Main::handleEvents()
{
    sf::Event event;
    const sf::Input& input = m_app->GetInput();
    sf::Vector2f mousePos = sf::Vector2f(input.GetMouseX(), input.GetMouseY());

    while(m_app->GetEvent(event))
    {
        switch(event.Type)
        {
            case sf::Event::Closed:
            {
                m_app->Close();
                break;
            }
            case sf::Event::KeyPressed:
            {
                switch(event.Key.Code)
                {
                    case sf::Key::Escape:
                    {
                        m_app->Close();
                        break;
                    }
                    case sf::Key::Tab:
                    {
                        if(m_soundOn)
                        {
                            sfw::ResourceManager::instance()->pauseSong("media/morris.ogg");
                            m_soundSprite.SetImage(*sfw::ResourceManager::instance()->getImage("media/soundoff.png"));
                        }
                        else
                        {
                            sfw::ResourceManager::instance()->playSong("media/morris.ogg", true);
                            m_soundSprite.SetImage(*sfw::ResourceManager::instance()->getImage("media/soundon.png"));
                        }
                        m_soundOn = !m_soundOn;
                    }
                    default:
                    {
                        break;
                    }
                }
            }
            case sf::Event::MouseButtonPressed:
            {
                switch(event.MouseButton.Button)
                {
                    m_stonePutSound.Play();
                    case sf::Mouse::Left:
                    {
                        BoardPoint* clickedPoint = m_board.checkMouseButtonClick(mousePos);
                        static BoardPoint* selectedPoint;

                        sf::Vector2f markerOffset(-5, -13);

                        if(clickedPoint)
                        {
                            switch(m_gamePhase)
                            {
// ++++++++++++++++++++++++++++++++ start +++++++++++++++++++++++++++++++++++++
                                case start:
                                {


                                    switch(m_inputState)
                                    {
                                        case whiteSelectOwn:
                                        {

                                            if(!clickedPoint->setStone(m_playerWhite.m_stones[startPhaseCounterWhite]))
                                            {
                                                break;
                                            }
                                            if(m_board.checkMill(clickedPoint))
                                            {
                                                if(m_board.checkAllStonesInMill(black))
                                                {
                                                    m_inputState = blackSelectOwn;
                                                }
                                                else
                                                {
                                                    m_inputState = whiteSelectEnemy;
                                                }
                                            }
                                            else
                                            {
                                                m_inputState = blackSelectOwn;
                                            }
                                            ++startPhaseCounterWhite;
                                            break;
                                        }
                                        case whiteSelectEnemy:
                                        {
                                            if((clickedPoint->getOwner() == black) && (!m_board.checkMill(clickedPoint)))
                                            {
                                                clickedPoint->getStone()->m_isActive = false;
                                                clickedPoint->setStone(0);
                                                m_inputState = blackSelectOwn;
                                            }

                                            break;
                                        }
                                        case whiteSelected:
                                        {
                                            break;
                                        }
                                        case blackSelectOwn:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if(!clickedPoint->setStone(m_playerBlack.m_stones[startPhaseCounterBlack]))
                                                {
                                                    break;
                                                }
                                                if(m_board.checkMill(clickedPoint))
                                                {
                                                    if(m_board.checkAllStonesInMill(white))
                                                    {
                                                        m_inputState = whiteSelectOwn;
                                                    }
                                                    else
                                                    {
                                                        m_inputState = blackSelectEnemy;
                                                    }
                                                }
                                                else
                                                {
                                                    m_inputState = whiteSelectOwn;
                                                }
                                                ++startPhaseCounterBlack;

                                                if(startPhaseCounterBlack == 9)
                                                {
                                                    m_gamePhase = midgame;
                                                }
                                            }
                                            break;
                                        }
                                        case blackSelectEnemy:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if((clickedPoint->getOwner() == white) && (!m_board.checkMill(clickedPoint)))
                                                {
                                                    clickedPoint->getStone()->m_isActive = false;
                                                    clickedPoint->setStone(0);
                                                    m_inputState = whiteSelectOwn;
                                                }
                                            }
                                            break;
                                        }
                                        case blackSelected:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                            }
                                            break;
                                        }
                                    }
                                    break;
                                }
// ++++++++++++++++++++++++++++++++ midgame +++++++++++++++++++++++++++++++++++++
                                case midgame:
                                {

                                    switch(m_inputState)
                                    {
                                        case whiteSelectOwn:
                                        {
                                            if(clickedPoint->getOwner() == white)
                                            {
                                                m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);

                                                m_inputState = whiteSelected;
                                                selectedPoint = clickedPoint;
                                            }
                                            break;
                                        }
                                        case whiteSelectEnemy:
                                        {
                                            if((clickedPoint->getOwner() == black) && (!m_board.checkMill(clickedPoint)))
                                            {
                                                clickedPoint->getStone()->m_isActive = false;
                                                clickedPoint->setStone(0);

                                                if(m_playerBlack.getNumActiveStones() == 3)
                                                {
                                                    m_gamePhase = blackEndgame;
                                                    m_inputState = blackSelectOwn;
                                                }
                                                else
                                                {
                                                    m_inputState = blackSelectOwn;
                                                }
                                            }
                                            break;
                                        }
                                        case whiteSelected:
                                        {
                                            if(clickedPoint->getOwner() == white)
                                            {
                                                selectedPoint = clickedPoint;
                                                m_marker.SetPosition(selectedPoint->getPixelPosition()+markerOffset);
                                            }
                                            else if(clickedPoint->getOwner() == none)
                                            {
                                                if(selectedPoint->upperNeighbor)
                                                {
                                                    if(*clickedPoint == *selectedPoint->upperNeighbor)
                                                    {
                                                        clickedPoint->setStone(selectedPoint->getStone());
                                                        selectedPoint->setStone(0);
                                                        if(m_board.checkMill(clickedPoint))
                                                        {
                                                            if(m_board.checkAllStonesInMill(black))
                                                            {
                                                                m_inputState = blackSelectOwn;

                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectEnemy;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            m_inputState = blackSelectOwn;
                                                        }
                                                        m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                    }
                                                }
                                                if(selectedPoint->leftNeighbor)
                                                {
                                                    if(*clickedPoint == *selectedPoint->leftNeighbor)
                                                    {
                                                        clickedPoint->setStone(selectedPoint->getStone());
                                                        selectedPoint->setStone(0);
                                                        if(m_board.checkMill(clickedPoint))
                                                        {
                                                            if(m_board.checkAllStonesInMill(black))
                                                            {
                                                                m_inputState = blackSelectOwn;

                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectEnemy;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            m_inputState = blackSelectOwn;
                                                        }
                                                        m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                    }
                                                }
                                                if(selectedPoint->rightNeighbor)
                                                {
                                                    if(*clickedPoint == *selectedPoint->rightNeighbor)
                                                    {
                                                        clickedPoint->setStone(selectedPoint->getStone());
                                                        selectedPoint->setStone(0);
                                                        if(m_board.checkMill(clickedPoint))
                                                        {
                                                            if(m_board.checkAllStonesInMill(black))
                                                            {
                                                                m_inputState = blackSelectOwn;

                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectEnemy;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            m_inputState = blackSelectOwn;
                                                        }
                                                        m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                    }
                                                }
                                                if(selectedPoint->lowerNeighbor)
                                                {
                                                    if(*clickedPoint == *selectedPoint->lowerNeighbor)
                                                    {
                                                        clickedPoint->setStone(selectedPoint->getStone());
                                                        selectedPoint->setStone(0);
                                                        if(m_board.checkMill(clickedPoint))
                                                        {
                                                            if(m_board.checkAllStonesInMill(black))
                                                            {
                                                                m_inputState = blackSelectOwn;

                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectEnemy;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            m_inputState = blackSelectOwn;
                                                        }
                                                        m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                    }
                                                }
                                            }
                                        break;
                                        }
                                        case blackSelectOwn:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if(clickedPoint->getOwner() == black)
                                                {
                                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                    m_inputState = blackSelected;
                                                    selectedPoint = clickedPoint;
                                                }
                                            }
                                            break;
                                        }
                                        case blackSelectEnemy:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if((clickedPoint->getOwner() == white) && (!m_board.checkMill(clickedPoint)))
                                                {
                                                    clickedPoint->getStone()->m_isActive = false;
                                                    clickedPoint->setStone(0);

                                                    if(m_playerWhite.getNumActiveStones() == 3)
                                                    {
                                                        m_gamePhase = whiteEndgame;
                                                        m_inputState = whiteSelectOwn;
                                                    }
                                                    else
                                                    {
                                                        m_inputState = whiteSelectOwn;
                                                    }
                                                }
                                            }
                                            break;
                                        }
                                        case blackSelected:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if(clickedPoint->getOwner() == black)
                                                {
                                                    selectedPoint = clickedPoint;
                                                    m_marker.SetPosition(selectedPoint->getPixelPosition()+markerOffset);
                                                }
                                                else if(clickedPoint->getOwner() == none)
                                                {
                                                    if(selectedPoint->upperNeighbor)
                                                    {
                                                        if(*clickedPoint == *selectedPoint->upperNeighbor)
                                                        {
                                                            clickedPoint->setStone(selectedPoint->getStone());
                                                            selectedPoint->setStone(0);
                                                            if(m_board.checkMill(clickedPoint))
                                                            {
                                                                if(m_board.checkAllStonesInMill(white))
                                                                {
                                                                    m_inputState = whiteSelectOwn;

                                                                }
                                                                else
                                                                {
                                                                    m_inputState = blackSelectEnemy;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectOwn;
                                                            }
                                                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                        }
                                                    }
                                                    if(selectedPoint->leftNeighbor)
                                                    {
                                                        if(*clickedPoint == *selectedPoint->leftNeighbor)
                                                        {
                                                            clickedPoint->setStone(selectedPoint->getStone());
                                                            selectedPoint->setStone(0);
                                                            if(m_board.checkMill(clickedPoint))
                                                            {
                                                                if(m_board.checkAllStonesInMill(white))
                                                                {
                                                                    m_inputState = whiteSelectOwn;

                                                                }
                                                                else
                                                                {
                                                                    m_inputState = blackSelectEnemy;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectOwn;
                                                            }
                                                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                        }
                                                    }
                                                    if(selectedPoint->rightNeighbor)
                                                    {
                                                        if(*clickedPoint == *selectedPoint->rightNeighbor)
                                                        {
                                                            clickedPoint->setStone(selectedPoint->getStone());
                                                            selectedPoint->setStone(0);
                                                            if(m_board.checkMill(clickedPoint))
                                                            {
                                                                if(m_board.checkAllStonesInMill(white))
                                                                {
                                                                    m_inputState = whiteSelectOwn;

                                                                }
                                                                else
                                                                {
                                                                    m_inputState = blackSelectEnemy;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectOwn;
                                                            }
                                                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                        }
                                                    }
                                                    if(selectedPoint->lowerNeighbor)
                                                    {
                                                        if(*clickedPoint == *selectedPoint->lowerNeighbor)
                                                        {
                                                            clickedPoint->setStone(selectedPoint->getStone());
                                                            selectedPoint->setStone(0);
                                                            if(m_board.checkMill(clickedPoint))
                                                            {
                                                                if(m_board.checkAllStonesInMill(white))
                                                                {
                                                                    m_inputState = whiteSelectOwn;

                                                                }
                                                                else
                                                                {
                                                                    m_inputState = blackSelectEnemy;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectOwn;
                                                            }
                                                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                        }
                                                    }
                                                }
                                            }
                                            break;
                                        }
                                    }
                                    break;
                                }
// ++++++++++++++++++++++++++++++++ whiteEndgame +++++++++++++++++++++++++++++++++++++
                                case whiteEndgame:
                                {
                                    switch(m_inputState)
                                    {
                                        case whiteSelectOwn:
                                        {
                                            if(clickedPoint->getOwner() == white)
                                            {
                                                m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                m_inputState = whiteSelected;
                                                selectedPoint = clickedPoint;
                                            }
                                            break;
                                        }
                                        case whiteSelectEnemy:
                                        {
                                            if((clickedPoint->getOwner() == black) && (!m_board.checkMill(clickedPoint)))
                                            {
                                                clickedPoint->getStone()->m_isActive = false;
                                                clickedPoint->setStone(0);

                                                if(m_playerBlack.getNumActiveStones() == 3)
                                                {
                                                    m_gamePhase = endgame;
                                                    m_inputState = blackSelectOwn;
                                                }
                                                else
                                                {
                                                    m_inputState = blackSelectOwn;
                                                }
                                            }
                                            break;
                                        }
                                        case whiteSelected:
                                        {
                                            if(clickedPoint->getOwner() == black)
                                            {
                                                selectedPoint = clickedPoint;
                                                m_marker.SetPosition(selectedPoint->getPixelPosition()+markerOffset);
                                            }
                                            else if(clickedPoint->getOwner() == none)
                                            {
                                                clickedPoint->setStone(selectedPoint->getStone());
                                                selectedPoint->setStone(0);
                                                if(m_board.checkMill(clickedPoint))
                                                {
                                                    if(m_board.checkAllStonesInMill(black))
                                                    {
                                                        m_inputState = blackSelectOwn;
                                                    }
                                                    else
                                                    {
                                                        m_inputState = whiteSelectEnemy;
                                                    }
                                                }
                                                else
                                                {
                                                    m_inputState = blackSelectOwn;
                                                }
                                                m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                            }
                                            break;
                                        }
                                        case blackSelectOwn:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if(clickedPoint->getOwner() == black)
                                                {
                                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                    m_inputState = blackSelected;
                                                    selectedPoint = clickedPoint;
                                                }
                                            }
                                            break;
                                        }
                                        case blackSelectEnemy:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if((clickedPoint->getOwner() == white) && (!m_board.checkMill(clickedPoint)))
                                                {
                                                    clickedPoint->getStone()->m_isActive = false;
                                                    clickedPoint->setStone(0);

                                                    if(m_playerWhite.getNumActiveStones() < 3)
                                                    {
                                                        m_gamePhase = blackWin;
                                                    }
                                                    else
                                                    {
                                                        m_inputState = whiteSelectOwn;
                                                    }
                                                }
                                            }
                                            break;
                                        }
                                        case blackSelected:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if(clickedPoint->getOwner() == black)
                                                {
                                                    selectedPoint = clickedPoint;
                                                    m_marker.SetPosition(selectedPoint->getPixelPosition()+markerOffset);
                                                }
                                                else if(clickedPoint->getOwner() == none)
                                                {
                                                    if(selectedPoint->upperNeighbor)
                                                    {
                                                        if(*clickedPoint == *selectedPoint->upperNeighbor)
                                                        {
                                                            clickedPoint->setStone(selectedPoint->getStone());
                                                            selectedPoint->setStone(0);
                                                            if(m_board.checkMill(clickedPoint))
                                                            {
                                                                if(m_board.checkAllStonesInMill(white))
                                                                {
                                                                    m_inputState = whiteSelectOwn;

                                                                }
                                                                else
                                                                {
                                                                    m_inputState = blackSelectEnemy;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectOwn;
                                                            }
                                                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                        }
                                                    }
                                                    if(selectedPoint->leftNeighbor)
                                                    {
                                                        if(*clickedPoint == *selectedPoint->leftNeighbor)
                                                        {
                                                            clickedPoint->setStone(selectedPoint->getStone());
                                                            selectedPoint->setStone(0);
                                                            if(m_board.checkMill(clickedPoint))
                                                            {
                                                                if(m_board.checkAllStonesInMill(white))
                                                                {
                                                                    m_inputState = whiteSelectOwn;

                                                                }
                                                                else
                                                                {
                                                                    m_inputState = blackSelectEnemy;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectOwn;
                                                            }
                                                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                        }
                                                    }
                                                    if(selectedPoint->rightNeighbor)
                                                    {
                                                        if(*clickedPoint == *selectedPoint->rightNeighbor)
                                                        {
                                                            clickedPoint->setStone(selectedPoint->getStone());
                                                            selectedPoint->setStone(0);
                                                            if(m_board.checkMill(clickedPoint))
                                                            {
                                                                if(m_board.checkAllStonesInMill(white))
                                                                {
                                                                    m_inputState = whiteSelectOwn;

                                                                }
                                                                else
                                                                {
                                                                    m_inputState = blackSelectEnemy;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectOwn;
                                                            }
                                                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                        }
                                                    }
                                                    if(selectedPoint->lowerNeighbor)
                                                    {
                                                        if(*clickedPoint == *selectedPoint->lowerNeighbor)
                                                        {
                                                            clickedPoint->setStone(selectedPoint->getStone());
                                                            selectedPoint->setStone(0);
                                                            if(m_board.checkMill(clickedPoint))
                                                            {
                                                                if(m_board.checkAllStonesInMill(white))
                                                                {
                                                                    m_inputState = whiteSelectOwn;

                                                                }
                                                                else
                                                                {
                                                                    m_inputState = blackSelectEnemy;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectOwn;
                                                            }
                                                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                        }
                                                    }
                                                }
                                            }
                                            break;
                                        }
                                    }
                                    break;
                                }
// ++++++++++++++++++++++++++++++++ blackEndgame +++++++++++++++++++++++++++++++++++++
                                case blackEndgame:
                                {
                                    switch(m_inputState)
                                    {
                                        case whiteSelectOwn:
                                        {
                                            if(clickedPoint->getOwner() == white)
                                            {
                                                m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                m_inputState = whiteSelected;
                                                selectedPoint = clickedPoint;
                                            }
                                            break;
                                        }
                                        case whiteSelectEnemy:
                                        {
                                            if((clickedPoint->getOwner() == black) && (!m_board.checkMill(clickedPoint)))
                                            {
                                                clickedPoint->getStone()->m_isActive = false;
                                                clickedPoint->setStone(0);

                                                if(m_playerBlack.getNumActiveStones() < 3)
                                                {
                                                    m_gamePhase = whiteWin;
                                                }
                                                else
                                                {
                                                    m_inputState = blackSelectOwn;
                                                }
                                            }
                                            break;
                                        }
                                        case whiteSelected:
                                        {
                                            if(clickedPoint->getOwner() == white)
                                            {
                                                selectedPoint = clickedPoint;
                                                m_marker.SetPosition(selectedPoint->getPixelPosition()+markerOffset);
                                            }
                                            else if(clickedPoint->getOwner() == none)
                                            {
                                                if(selectedPoint->upperNeighbor)
                                                {
                                                    if(*clickedPoint == *selectedPoint->upperNeighbor)
                                                    {
                                                        clickedPoint->setStone(selectedPoint->getStone());
                                                        selectedPoint->setStone(0);
                                                        if(m_board.checkMill(clickedPoint))
                                                        {
                                                            if(m_board.checkAllStonesInMill(black))
                                                            {
                                                                m_inputState = blackSelectOwn;

                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectEnemy;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            m_inputState = blackSelectOwn;
                                                        }
                                                        m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                    }
                                                }
                                                if(selectedPoint->leftNeighbor)
                                                {
                                                    if(*clickedPoint == *selectedPoint->leftNeighbor)
                                                    {
                                                        clickedPoint->setStone(selectedPoint->getStone());
                                                        selectedPoint->setStone(0);
                                                        if(m_board.checkMill(clickedPoint))
                                                        {
                                                            if(m_board.checkAllStonesInMill(black))
                                                            {
                                                                m_inputState = blackSelectOwn;

                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectEnemy;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            m_inputState = blackSelectOwn;
                                                        }
                                                        m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                    }
                                                }
                                                if(selectedPoint->rightNeighbor)
                                                {
                                                    if(*clickedPoint == *selectedPoint->rightNeighbor)
                                                    {
                                                        clickedPoint->setStone(selectedPoint->getStone());
                                                        selectedPoint->setStone(0);
                                                        if(m_board.checkMill(clickedPoint))
                                                        {
                                                            if(m_board.checkAllStonesInMill(black))
                                                            {
                                                                m_inputState = blackSelectOwn;

                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectEnemy;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            m_inputState = blackSelectOwn;
                                                        }
                                                        m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                    }
                                                }
                                                if(selectedPoint->lowerNeighbor)
                                                {
                                                    if(*clickedPoint == *selectedPoint->lowerNeighbor)
                                                    {
                                                        clickedPoint->setStone(selectedPoint->getStone());
                                                        selectedPoint->setStone(0);
                                                        if(m_board.checkMill(clickedPoint))
                                                        {
                                                            if(m_board.checkAllStonesInMill(black))
                                                            {
                                                                m_inputState = blackSelectOwn;

                                                            }
                                                            else
                                                            {
                                                                m_inputState = whiteSelectEnemy;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            m_inputState = blackSelectOwn;
                                                        }
                                                        m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                    }
                                                }
                                            }
                                            break;
                                        }
                                        case blackSelectOwn:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if(clickedPoint->getOwner() == black)
                                                {
                                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                    m_inputState = blackSelected;
                                                    selectedPoint = clickedPoint;
                                                }
                                            }
                                            break;
                                        }
                                        case blackSelectEnemy:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if((clickedPoint->getOwner() == white) && (!m_board.checkMill(clickedPoint)))
                                                {
                                                    clickedPoint->getStone()->m_isActive = false;
                                                    clickedPoint->setStone(0);

                                                    if(m_playerWhite.getNumActiveStones() == 3)
                                                    {
                                                        m_gamePhase = endgame;
                                                        m_inputState = whiteSelectOwn;
                                                    }
                                                    else
                                                    {
                                                        m_inputState = whiteSelectOwn;
                                                    }
                                                }
                                            }
                                            break;
                                        }
                                        case blackSelected:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if(clickedPoint->getOwner() == black)
                                                {
                                                    selectedPoint = clickedPoint;
                                                    m_marker.SetPosition(selectedPoint->getPixelPosition()+markerOffset);
                                                }
                                                else if(clickedPoint->getOwner() == none)
                                                {
                                                    clickedPoint->setStone(selectedPoint->getStone());
                                                    selectedPoint->setStone(0);
                                                    if(m_board.checkMill(clickedPoint))
                                                    {
                                                        if(m_board.checkAllStonesInMill(white))
                                                        {
                                                            m_inputState = whiteSelectOwn;

                                                        }
                                                        else
                                                        {
                                                            m_inputState = blackSelectEnemy;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        m_inputState = whiteSelectOwn;
                                                    }
                                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                }
                                            }
                                            break;
                                        }
                                    }
                                    break;
                                }
// ++++++++++++++++++++++++++++++++ endgame +++++++++++++++++++++++++++++++++++++
                                case endgame:
                                {
                                    switch(m_inputState)
                                    {
                                        case whiteSelectOwn:
                                        {
                                            if(clickedPoint->getOwner() == white)
                                            {
                                                m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                m_inputState = whiteSelected;
                                                selectedPoint = clickedPoint;
                                            }
                                            break;
                                        }
                                        case whiteSelectEnemy:
                                        {
                                            if((clickedPoint->getOwner() == black) && (!m_board.checkMill(clickedPoint)))
                                            {
                                                clickedPoint->getStone()->m_isActive = false;
                                                clickedPoint->setStone(0);

                                                if(m_playerBlack.getNumActiveStones() < 3)
                                                {
                                                    m_gamePhase = whiteWin;
                                                }
                                                else
                                                {
                                                    m_inputState = blackSelectOwn;
                                                }
                                            }
                                            break;
                                        }
                                        case whiteSelected:
                                        {
                                            if(clickedPoint->getOwner() == black)
                                            {
                                                selectedPoint = clickedPoint;
                                                m_marker.SetPosition(selectedPoint->getPixelPosition()+markerOffset);
                                            }
                                            else if(clickedPoint->getOwner() == none)
                                            {
                                                clickedPoint->setStone(selectedPoint->getStone());
                                                selectedPoint->setStone(0);
                                                if(m_board.checkMill(clickedPoint))
                                                {
                                                    if(m_board.checkAllStonesInMill(black))
                                                    {
                                                        m_inputState = blackSelectOwn;

                                                    }
                                                    else
                                                    {
                                                        m_inputState = whiteSelectEnemy;
                                                    }
                                                }
                                                else
                                                {
                                                    m_inputState = blackSelectOwn;
                                                }
                                                m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                            }
                                            break;
                                        }
                                        case blackSelectOwn:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if(clickedPoint->getOwner() == black)
                                                {
                                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                    m_inputState = blackSelected;
                                                    selectedPoint = clickedPoint;
                                                }
                                            }
                                            break;
                                        }
                                        case blackSelectEnemy:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if((clickedPoint->getOwner() == white) && (!m_board.checkMill(clickedPoint)))
                                                {
                                                    clickedPoint->getStone()->m_isActive = false;
                                                    clickedPoint->setStone(0);

                                                    if(m_playerWhite.getNumActiveStones() < 3)
                                                    {
                                                        m_gamePhase = blackWin;
                                                    }
                                                    else
                                                    {
                                                        m_inputState = whiteSelectOwn;
                                                    }
                                                }
                                            }
                                            break;
                                        }
                                        case blackSelected:
                                        {
                                            if(!m_playerBlack.getIsComputer())
                                            {
                                                if(clickedPoint->getOwner() == black)
                                                {
                                                    selectedPoint = clickedPoint;
                                                    m_marker.SetPosition(selectedPoint->getPixelPosition()+markerOffset);
                                                }
                                                else if(clickedPoint->getOwner() == none)
                                                {
                                                    clickedPoint->setStone(selectedPoint->getStone());
                                                    selectedPoint->setStone(0);
                                                    if(m_board.checkMill(clickedPoint))
                                                    {
                                                        if(m_board.checkAllStonesInMill(white))
                                                        {
                                                            m_inputState = whiteSelectOwn;

                                                        }
                                                        else
                                                        {
                                                            m_inputState = blackSelectEnemy;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        m_inputState = whiteSelectOwn;
                                                    }
                                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                                }
                                            }
                                            break;
                                        }
                                    }
                                    break;
                                }
// ++++++++++++++++++++++++++++++++ whiteWin +++++++++++++++++++++++++++++++++++++
                                case whiteWin:
                                {
                                    break;
                                }
// ++++++++++++++++++++++++++++++++ blackWin +++++++++++++++++++++++++++++++++++++
                                case blackWin:
                                {
                                    break;
                                }
                            }
                        }
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
            }
            default:
            {
                break;
            }
        }
    }
}
void GS_Main::update()
{
    m_clock += m_app->GetFrameTime();

    /*

    AI- and Textupdating

    */
    BoardPoint* clickedPoint = m_board.getRandomPoint();
    static BoardPoint* selectedPoint;
    sf::Vector2f markerOffset(-5, -13);

    switch(m_gamePhase)
    {
        case start:
        {
            m_gamePhaseString.SetText("Place your stones on the board!");

            switch(m_inputState)
            {
                case whiteSelectOwn:
                {
                    m_inputStateString.SetText("White, it's your turn!");
                    break;
                }
                case whiteSelectEnemy:
                {
                    m_inputStateString.SetText("White, you are attacking!");
                    break;
                }
                case whiteSelected:
                {
                    m_inputStateString.SetText("White, where should your stone move to?");
                    break;
                }
                case blackSelectOwn:
                {
                    m_inputStateString.SetText("Black, it's your turn!");

                    // AI


                    if(m_playerBlack.getIsComputer())
                    {
                        if(!clickedPoint->setStone(m_playerBlack.m_stones[startPhaseCounterBlack]))
                        {
                            break;
                        }
                        if(m_board.checkMill(clickedPoint))
                        {
                            if(m_board.checkAllStonesInMill(white))
                            {
                                m_inputState = whiteSelectOwn;
                            }
                            else
                            {
                                m_inputState = blackSelectEnemy;
                            }
                        }
                        else
                        {
                            m_inputState = whiteSelectOwn;
                        }
                        ++startPhaseCounterBlack;

                        if(startPhaseCounterBlack == 9)
                        {
                            m_gamePhase = midgame;
                        }
                    }
                    // --

                    break;
                }
                case blackSelectEnemy:
                {
                    m_inputStateString.SetText("Black, you are attacking!");

                    // AI
                    clickedPoint = m_board.getRandomWhitePoint();

                    if(m_playerBlack.getIsComputer())
                    {
                        if((clickedPoint->getOwner() == white) && (!m_board.checkMill(clickedPoint)))
                        {
                            clickedPoint->getStone()->m_isActive = false;
                            clickedPoint->setStone(0);
                            m_inputState = whiteSelectOwn;
                        }
                    }

                    // --

                    break;
                }
                case blackSelected:
                {
                    m_inputStateString.SetText("Black, where should your stone move to?");

                    // AI

                    // --

                    break;
                }
            }
            break;

        }
        case midgame:
        {
            m_gamePhaseString.SetText("Move your stones on the board!");
            switch(m_inputState)
            {
                case whiteSelectOwn:
                {
                    m_inputStateString.SetText("White, it's your turn!");
                    break;
                }
                case whiteSelectEnemy:
                {
                    m_inputStateString.SetText("White, you are attacking!");
                    break;
                }
                case whiteSelected:
                {
                    m_inputStateString.SetText("White, where should your stone move to?");
                    break;
                }
                case blackSelectOwn:
                {
                    m_inputStateString.SetText("Black, it's your turn!");

                    // AI
                    clickedPoint = m_board.getRandomBlackPoint();

                    if(m_playerBlack.getIsComputer())
                    {
                        if(clickedPoint->getOwner() == black)
                        {
                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                            m_inputState = blackSelected;
                            selectedPoint = clickedPoint;
                        }
                    }
                    // --

                    break;
                }
                case blackSelectEnemy:
                {
                    m_inputStateString.SetText("Black, you are attacking!");

                    // AI
                    clickedPoint = m_board.getRandomWhitePoint();

                    if(m_playerBlack.getIsComputer())
                    {
                        if((clickedPoint->getOwner() == white) && (!m_board.checkMill(clickedPoint)))
                        {
                            clickedPoint->getStone()->m_isActive = false;
                            clickedPoint->setStone(0);

                            if(m_playerWhite.getNumActiveStones() == 3)
                            {
                                m_gamePhase = whiteEndgame;
                                m_inputState = whiteSelectOwn;
                            }
                            else
                            {
                                m_inputState = whiteSelectOwn;
                            }
                        }
                    }
                    // --

                    break;
                }
                case blackSelected:
                {
                    m_inputStateString.SetText("Black, where should your stone move to?");

                    // AI
                    if(m_board.checkStoneCanMove(selectedPoint))
                    {
                        clickedPoint = m_board.getRandomNeighbor(selectedPoint);
                    }
                    if(m_playerBlack.getIsComputer())
                    {
                        if(clickedPoint->getOwner() == black)
                        {
                            selectedPoint = clickedPoint;
                            m_marker.SetPosition(selectedPoint->getPixelPosition()+markerOffset);
                        }
                        else if(clickedPoint->getOwner() == none)
                        {
                            if(selectedPoint->upperNeighbor)
                            {
                                if(*clickedPoint == *selectedPoint->upperNeighbor)
                                {
                                    clickedPoint->setStone(selectedPoint->getStone());
                                    selectedPoint->setStone(0);
                                    if(m_board.checkMill(clickedPoint))
                                    {
                                        if(m_board.checkAllStonesInMill(white))
                                        {
                                            m_inputState = whiteSelectOwn;

                                        }
                                        else
                                        {
                                            m_inputState = blackSelectEnemy;
                                        }
                                    }
                                    else
                                    {
                                        m_inputState = whiteSelectOwn;
                                    }
                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                }
                            }
                            if(selectedPoint->leftNeighbor)
                            {
                                if(*clickedPoint == *selectedPoint->leftNeighbor)
                                {
                                    clickedPoint->setStone(selectedPoint->getStone());
                                    selectedPoint->setStone(0);
                                    if(m_board.checkMill(clickedPoint))
                                    {
                                        if(m_board.checkAllStonesInMill(white))
                                        {
                                            m_inputState = whiteSelectOwn;

                                        }
                                        else
                                        {
                                            m_inputState = blackSelectEnemy;
                                        }
                                    }
                                    else
                                    {
                                        m_inputState = whiteSelectOwn;
                                    }
                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                }
                            }
                            if(selectedPoint->rightNeighbor)
                            {
                                if(*clickedPoint == *selectedPoint->rightNeighbor)
                                {
                                    clickedPoint->setStone(selectedPoint->getStone());
                                    selectedPoint->setStone(0);
                                    if(m_board.checkMill(clickedPoint))
                                    {
                                        if(m_board.checkAllStonesInMill(white))
                                        {
                                            m_inputState = whiteSelectOwn;

                                        }
                                        else
                                        {
                                            m_inputState = blackSelectEnemy;
                                        }
                                    }
                                    else
                                    {
                                        m_inputState = whiteSelectOwn;
                                    }
                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                }
                            }
                            if(selectedPoint->lowerNeighbor)
                            {
                                if(*clickedPoint == *selectedPoint->lowerNeighbor)
                                {
                                    clickedPoint->setStone(selectedPoint->getStone());
                                    selectedPoint->setStone(0);
                                    if(m_board.checkMill(clickedPoint))
                                    {
                                        if(m_board.checkAllStonesInMill(white))
                                        {
                                            m_inputState = whiteSelectOwn;

                                        }
                                        else
                                        {
                                            m_inputState = blackSelectEnemy;
                                        }
                                    }
                                    else
                                    {
                                        m_inputState = whiteSelectOwn;
                                    }
                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                }
                            }
                        }
                    }
                    // --

                    break;
                }
            }
            break;
        }
        case whiteEndgame:
        {
            m_gamePhaseString.SetText("The white player may jump now!");

            switch(m_inputState)
            {
                case whiteSelectOwn:
                {
                    m_inputStateString.SetText("White, it's your turn! - You may jump!");
                    break;
                }
                case whiteSelectEnemy:
                {
                    m_inputStateString.SetText("White, you are attacking!");
                    break;
                }
                case whiteSelected:
                {
                    m_inputStateString.SetText("White, where should your stone move to?");
                    break;
                }
                case blackSelectOwn:
                {
                    m_inputStateString.SetText("Black, it's your turn!");

                    // AI
                    clickedPoint = m_board.getRandomBlackPoint();

                    if(m_playerBlack.getIsComputer())
                    {
                        if(clickedPoint->getOwner() == black)
                        {
                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                            m_inputState = blackSelected;
                            selectedPoint = clickedPoint;
                        }
                    }
                    // --

                    break;
                }
                case blackSelectEnemy:
                {
                    m_inputStateString.SetText("Black, you are attacking!");

                    // AI
                    clickedPoint = m_board.getRandomWhitePoint();

                    if(m_playerBlack.getIsComputer())
                    {
                        if((clickedPoint->getOwner() == white) && (!m_board.checkMill(clickedPoint)))
                        {
                            clickedPoint->getStone()->m_isActive = false;
                            clickedPoint->setStone(0);

                            if(m_playerWhite.getNumActiveStones() == 3)
                            {
                                m_gamePhase = whiteEndgame;
                                m_inputState = whiteSelectOwn;
                            }
                            else
                            {
                                m_inputState = whiteSelectOwn;
                            }
                        }
                    }
                    // --

                    break;
                }
                case blackSelected:
                {
                    m_inputStateString.SetText("Black, where should your stone move to?");

                    // AI
                    if(m_board.checkStoneCanMove(selectedPoint))
                    {
                        clickedPoint = m_board.getRandomNeighbor(selectedPoint);
                    }
                    if(m_playerBlack.getIsComputer())
                    {
                        if(clickedPoint->getOwner() == black)
                        {
                            selectedPoint = clickedPoint;
                            m_marker.SetPosition(selectedPoint->getPixelPosition()+markerOffset);
                        }
                        else if(clickedPoint->getOwner() == none)
                        {
                            if(selectedPoint->upperNeighbor)
                            {
                                if(*clickedPoint == *selectedPoint->upperNeighbor)
                                {
                                    clickedPoint->setStone(selectedPoint->getStone());
                                    selectedPoint->setStone(0);
                                    if(m_board.checkMill(clickedPoint))
                                    {
                                        if(m_board.checkAllStonesInMill(white))
                                        {
                                            m_inputState = whiteSelectOwn;

                                        }
                                        else
                                        {
                                            m_inputState = blackSelectEnemy;
                                        }
                                    }
                                    else
                                    {
                                        m_inputState = whiteSelectOwn;
                                    }
                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                }
                            }
                            if(selectedPoint->leftNeighbor)
                            {
                                if(*clickedPoint == *selectedPoint->leftNeighbor)
                                {
                                    clickedPoint->setStone(selectedPoint->getStone());
                                    selectedPoint->setStone(0);
                                    if(m_board.checkMill(clickedPoint))
                                    {
                                        if(m_board.checkAllStonesInMill(white))
                                        {
                                            m_inputState = whiteSelectOwn;

                                        }
                                        else
                                        {
                                            m_inputState = blackSelectEnemy;
                                        }
                                    }
                                    else
                                    {
                                        m_inputState = whiteSelectOwn;
                                    }
                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                }
                            }
                            if(selectedPoint->rightNeighbor)
                            {
                                if(*clickedPoint == *selectedPoint->rightNeighbor)
                                {
                                    clickedPoint->setStone(selectedPoint->getStone());
                                    selectedPoint->setStone(0);
                                    if(m_board.checkMill(clickedPoint))
                                    {
                                        if(m_board.checkAllStonesInMill(white))
                                        {
                                            m_inputState = whiteSelectOwn;

                                        }
                                        else
                                        {
                                            m_inputState = blackSelectEnemy;
                                        }
                                    }
                                    else
                                    {
                                        m_inputState = whiteSelectOwn;
                                    }
                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                }
                            }
                            if(selectedPoint->lowerNeighbor)
                            {
                                if(*clickedPoint == *selectedPoint->lowerNeighbor)
                                {
                                    clickedPoint->setStone(selectedPoint->getStone());
                                    selectedPoint->setStone(0);
                                    if(m_board.checkMill(clickedPoint))
                                    {
                                        if(m_board.checkAllStonesInMill(white))
                                        {
                                            m_inputState = whiteSelectOwn;

                                        }
                                        else
                                        {
                                            m_inputState = blackSelectEnemy;
                                        }
                                    }
                                    else
                                    {
                                        m_inputState = whiteSelectOwn;
                                    }
                                    m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                                }
                            }
                        }
                    }
                    // --

                    break;
                }
            }
            break;
        }
        case blackEndgame:
        {
            m_gamePhaseString.SetText("The black player may jump now!");

            switch(m_inputState)
            {
                case whiteSelectOwn:
                {
                    m_inputStateString.SetText("White, it's your turn!");
                    break;
                }
                case whiteSelectEnemy:
                {
                    m_inputStateString.SetText("White, you are attacking!");
                    break;
                }
                case whiteSelected:
                {
                    m_inputStateString.SetText("White, where should your stone move to?");
                    break;
                }
                case blackSelectOwn:
                {
                    m_inputStateString.SetText("Black, it's your turn! - You may jump!");

                    // AI
                    clickedPoint = m_board.getRandomBlackPoint();

                    if(m_playerBlack.getIsComputer())
                    {
                        if(clickedPoint->getOwner() == black)
                        {
                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                            m_inputState = blackSelected;
                            selectedPoint = clickedPoint;
                        }
                    }
                    // --

                    break;
                }
                case blackSelectEnemy:
                {
                    m_inputStateString.SetText("Black, you are attacking!");

                    // AI
                    clickedPoint = m_board.getRandomWhitePoint();

                    if(m_playerBlack.getIsComputer())
                    {
                        if((clickedPoint->getOwner() == white) && (!m_board.checkMill(clickedPoint)))
                        {
                            clickedPoint->getStone()->m_isActive = false;
                            clickedPoint->setStone(0);

                            if(m_playerWhite.getNumActiveStones() == 3)
                            {
                                m_gamePhase = whiteEndgame;
                                m_inputState = whiteSelectOwn;
                            }
                            else
                            {
                                m_inputState = whiteSelectOwn;
                            }
                        }
                    }
                    // --

                    break;
                }
                case blackSelected:
                {
                    m_inputStateString.SetText("Black, where should your stone move to?");

                    // AI
                    if(m_playerBlack.getIsComputer())
                    {
                        if(clickedPoint->getOwner() == black)
                        {
                            selectedPoint = clickedPoint;
                            m_marker.SetPosition(selectedPoint->getPixelPosition()+markerOffset);
                        }
                        else if(clickedPoint->getOwner() == none)
                        {
                            clickedPoint->setStone(selectedPoint->getStone());
                            selectedPoint->setStone(0);
                            if(m_board.checkMill(clickedPoint))
                            {
                                if(m_board.checkAllStonesInMill(white))
                                {
                                    m_inputState = whiteSelectOwn;

                                }
                                else
                                {
                                    m_inputState = blackSelectEnemy;
                                }
                            }
                            else
                            {
                                m_inputState = whiteSelectOwn;
                            }
                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                        }
                    }
                    // --

                    break;
                }
            }
            break;
        }
        case endgame:
        {
            m_gamePhaseString.SetText("Both players may jump now!");

            switch(m_inputState)
            {
                case whiteSelectOwn:
                {
                    m_inputStateString.SetText("White, it's your turn! - You may jump!");
                    break;
                }
                case whiteSelectEnemy:
                {
                    m_inputStateString.SetText("White, you are attacking!");
                    break;
                }
                case whiteSelected:
                {
                    m_inputStateString.SetText("White, where should your stone move to?");
                    break;
                }
                case blackSelectOwn:
                {
                    m_inputStateString.SetText("Black, it's your turn! - You may jump!");

                    // AI
                    clickedPoint = m_board.getRandomBlackPoint();

                    if(m_playerBlack.getIsComputer())
                    {
                        if(clickedPoint->getOwner() == black)
                        {
                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                            m_inputState = blackSelected;
                            selectedPoint = clickedPoint;
                        }
                    }
                    // --

                    break;
                }
                case blackSelectEnemy:
                {
                    m_inputStateString.SetText("Black, you are attacking!");

                    // AI
                    clickedPoint = m_board.getRandomWhitePoint();

                    if(m_playerBlack.getIsComputer())
                    {
                        if((clickedPoint->getOwner() == white) && (!m_board.checkMill(clickedPoint)))
                        {
                            clickedPoint->getStone()->m_isActive = false;
                            clickedPoint->setStone(0);

                            if(m_playerWhite.getNumActiveStones() == 3)
                            {
                                m_gamePhase = whiteEndgame;
                                m_inputState = whiteSelectOwn;
                            }
                            else
                            {
                                m_inputState = whiteSelectOwn;
                            }
                        }
                    }
                    // --

                    break;
                }
                case blackSelected:
                {
                    m_inputStateString.SetText("Black, where should your stone move to?");

                    // AI
                    if(m_playerBlack.getIsComputer())
                    {
                        if(clickedPoint->getOwner() == black)
                        {
                            selectedPoint = clickedPoint;
                            m_marker.SetPosition(selectedPoint->getPixelPosition()+markerOffset);
                        }
                        else if(clickedPoint->getOwner() == none)
                        {
                            clickedPoint->setStone(selectedPoint->getStone());
                            selectedPoint->setStone(0);
                            if(m_board.checkMill(clickedPoint))
                            {
                                if(m_board.checkAllStonesInMill(white))
                                {
                                    m_inputState = whiteSelectOwn;

                                }
                                else
                                {
                                    m_inputState = blackSelectEnemy;
                                }
                            }
                            else
                            {
                                m_inputState = whiteSelectOwn;
                            }
                            m_marker.SetPosition(clickedPoint->getPixelPosition()+markerOffset);
                        }
                    }
                    // --

                    break;
                }
            }
            break;
        }
        case whiteWin:
        {
            m_gamePhaseString.SetText("The white player is victorious!");
            m_inputStateString.SetText("White wins!");
            break;
        }
        case blackWin:
        {
            m_gamePhaseString.SetText("The black player is victorious!");
            m_inputStateString.SetText("Black wins!");
            break;
        }
    }
}
void GS_Main::render()
{
    m_app->Draw(m_board);

    m_app->Draw(m_marker);
    m_app->Draw(m_soundSprite);

    m_playerWhite.draw(*m_app);
    m_playerBlack.draw(*m_app);

    m_app->Draw(m_inputStateString);
    m_app->Draw(m_gamePhaseString);
    m_app->Draw(m_soundString);
}

GS_Main* GS_Main::instance(sf::RenderWindow* app)
{
    static GS_Main myInstance(app);
    return &myInstance;
}

