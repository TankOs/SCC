#include "MorrisGame.h"

int main()
{
    MorrisGame app(sf::VideoMode(1024, 768, 32), "Battle of Morris", sf::Style::Fullscreen);

    app.SetFramerateLimit(100);

    app.init();

    app.doMainLoop();

    app.cleanUp();


    return 0;
}
