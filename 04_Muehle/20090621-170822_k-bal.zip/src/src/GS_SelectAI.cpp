#include "GS_SelectAI.h"
#include "ResourceManager.h"
#include "MorrisGame.h"
#include "GS_Main.h"

GS_SelectAI::GS_SelectAI(sf::RenderWindow* app) : sfw::GameState(app), m_isAI(true)
{
    sfw::ResourceManager::instance()->playSong("media/morris.ogg", true);

    m_description1.SetFont(*sfw::ResourceManager::instance()->getDefaultFont());
    m_description1.SetPosition(50,50);
    m_description1.SetColor(sf::Color::White);
    m_description1.SetText
    (
        "Do you want to play against the Computer?\n\n"
        "- Use arrow keys to chose -"
    );

    m_description2.SetFont(*sfw::ResourceManager::instance()->getDefaultFont());
    m_description2.SetPosition(50,180);
    m_description2.SetColor(sf::Color::White);
    m_description2.SetText
    (
        "Yes ->"
    );
}
GS_SelectAI::~GS_SelectAI()
{

}

void GS_SelectAI::init()
{}
void GS_SelectAI::cleanUp()
{}

void GS_SelectAI::pause()
{}
void GS_SelectAI::resume()
{}

void GS_SelectAI::handleEvents()
{
    sf::Event event;

    while(m_app->GetEvent(event))
    {
        switch(event.Type)
        {
            case sf::Event::Closed:
            {
                m_app->Close();
                break;
            }
            case sf::Event::KeyPressed:
            {
                switch(event.Key.Code)
                {
                    case sf::Key::Escape:
                    {
                        static_cast<MorrisGame*>(m_app)->changeState(GS_Main::instance(m_app));
                        break;
                    }
                    case sf::Key::Return:
                    {
                        static_cast<MorrisGame*>(m_app)->changeState(GS_Main::instance(m_app));
                        break;
                    }
                    case sf::Key::Right:
                    {
                        if(m_isAI)
                        {
                            m_isAI = false;
                            m_description2.SetText
                            (
                                "<- No"
                            );
                        }
                        break;
                    }
                    case sf::Key::Left:
                    {
                        if(!m_isAI)
                        {
                            m_isAI = true;
                            m_description2.SetText
                            (
                                "Yes ->"
                            );
                        }
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
            }
            default:
            {
                break;
            }
        }
    }
}
void GS_SelectAI::update()
{
    m_clock += m_app->GetFrameTime();




    if(m_clock > 30.f)
    {
        static_cast<MorrisGame*>(m_app)->changeState(GS_Main::instance(m_app));
    }
}
void GS_SelectAI::render()
{
    m_app->Draw(m_description1);
    m_app->Draw(m_description2);
}

bool GS_SelectAI::getIsAI()
{
    return m_isAI;
}

GS_SelectAI* GS_SelectAI::instance(sf::RenderWindow* app)
{
    static GS_SelectAI myInstance(app);
    return &myInstance;
}

