#include "Stone.h"
#include "ResourceManager.h"

Stone::Stone(Owner owner, bool isKnight) : m_isKnight(isKnight), m_isActive(false), m_owner(owner)
{
    if(isKnight)
    {
        if(m_owner == white)
        {
            SetImage(*sfw::ResourceManager::instance()->getImage("media/whiteknight.png"));
        }
        else if(m_owner == black)
        {
            SetImage(*sfw::ResourceManager::instance()->getImage("media/blackknight.png"));
        }
    }
    else
    {
        if(m_owner == white)
        {
            SetImage(*sfw::ResourceManager::instance()->getImage("media/whitesoldier.png"));
        }
        else if(m_owner == black)
        {
            SetImage(*sfw::ResourceManager::instance()->getImage("media/blacksoldier.png"));
        }
    }
}

Stone::~Stone()
{}

void Stone::Render(sf::RenderTarget& Target) const
{
    if(m_isActive)
    {
        sf::Sprite::Render(Target);
    }
}
