#include "GS_Intro.h"
#include "ResourceManager.h"
#include "MorrisGame.h"
#include "GS_SelectAI.h"

GS_Intro::GS_Intro(sf::RenderWindow* app) : sfw::GameState(app)
{
    sfw::ResourceManager::instance()->playSong("media/morris.ogg", true);

    m_description1.SetFont(*sfw::ResourceManager::instance()->getDefaultFont());
    m_description1.SetPosition(50,50);
    m_description1.SetColor(sf::Color::Black);
    m_description1.SetScale(1.5f, 1.5f);
    m_description1.SetText(
    "Nine Men's Morris"
    );

    m_description2.SetFont(*sfw::ResourceManager::instance()->getDefaultFont());
    m_description2.SetPosition(50,180);
    m_description2.SetColor(sf::Color::Black);
    m_description2.SetText(
    "Goal: Try to decrease the number of enemy stones below three or block all enemy stones.\n\n"
    "Attacking: If you position three stones of yours in a row you are allowed to take a stone from the enemy.\n\n"
    );

    m_description3.SetFont(*sfw::ResourceManager::instance()->getDefaultFont());
    m_description3.SetPosition(50,300);
    m_description3.SetColor(sf::Color::Black);
    m_description3.SetText(
    "Start: Position your stones on the board. You are not allowed to move.\n"
    "Midgame: Move your units on the board. You are only allowed to move to neighboring points.\n"
    "Endgame: If you have three stones left you are allowed to jump all over the board.\n\n"
    "Controls: \n"
    "Left Mouse Button --- Select Stone / Select Movement Target\n"
    "Tabulator --- Toggle Sound on / off\n"
    "Escape --- Jump Menu / Exit Game"
    );
}
GS_Intro::~GS_Intro()
{

}

void GS_Intro::init()
{}
void GS_Intro::cleanUp()
{}

void GS_Intro::pause()
{}
void GS_Intro::resume()
{}

void GS_Intro::handleEvents()
{
    sf::Event event;

    while(m_app->GetEvent(event))
    {
        switch(event.Type)
        {
            case sf::Event::Closed:
            {
                m_app->Close();
                break;
            }
            case sf::Event::KeyPressed:
            {
                switch(event.Key.Code)
                {
                    case sf::Key::Escape:
                    {
                        static_cast<MorrisGame*>(m_app)->changeState(GS_SelectAI::instance(m_app));
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
            }
            default:
            {
                break;
            }
        }
    }
}
void GS_Intro::update()
{
    m_clock += m_app->GetFrameTime();

    float descr1 = 0.f;
    float descr2 = 2.f;
    float descr3 = 4.f;

    if((m_clock > descr1) && (m_description1.GetColor() != sf::Color::White))
    {
        m_description1.SetColor(sf::Color(50*(m_clock-descr1),50*(m_clock-descr1),50*(m_clock-descr1)));
    }
    if((m_clock > descr2) && (m_description2.GetColor() != sf::Color::White))
    {
        m_description2.SetColor(sf::Color(50*(m_clock-descr2),50*(m_clock-descr2),50*(m_clock-descr2)));
    }
    if((m_clock > descr3) && (m_description3.GetColor() != sf::Color::White))
    {
        m_description3.SetColor(sf::Color(50*(m_clock-descr3),50*(m_clock-descr3),50*(m_clock-descr3)));
    }


    if(m_clock > 30.f)
    {
        static_cast<MorrisGame*>(m_app)->changeState(GS_SelectAI::instance(m_app));
    }
}
void GS_Intro::render()
{
    m_app->Draw(m_description1);
    m_app->Draw(m_description2);
    m_app->Draw(m_description3);
}

GS_Intro* GS_Intro::instance(sf::RenderWindow* app)
{
    static GS_Intro myInstance(app);
    return &myInstance;
}
