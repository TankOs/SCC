#include "PlayerStatus.h"

PlayerStatus::PlayerStatus(Owner owner, const int startMoney, const int startMoral)
: m_money(startMoney), m_startMoney(startMoney), m_moral(startMoral), m_startMoral(startMoral), m_owner(owner)
{
    for(int i = 0; i < maxUnits; i++)
    {
        m_stones[i] = new Stone(owner, false);
    }
}

PlayerStatus::~PlayerStatus()
{
    for(int i = 0; i < maxUnits; i++)
    {
        delete m_stones[i];
    }
}

void PlayerStatus::update()
{

}
void PlayerStatus::draw(sf::RenderWindow& window)
{
    for(int i = 0; i < maxUnits; i++)
    {
        window.Draw(*m_stones[i]);
    }
}

unsigned int PlayerStatus::getNumActiveStones()
{
    unsigned int counter = 0;

    for(int i = 0; i < maxUnits; i++)
    {
        if(m_stones[i]->m_isActive)
        {
            ++counter;
        }
    }
    return counter;
}

bool PlayerStatus::getIsComputer()
{
    return m_isComputer;
}

void PlayerStatus::setIsComputer(bool isComputer)
{
    m_isComputer = isComputer;
}
