German SFML Community Contest 04

Nine Men's Morris by Mizar

a) Controls
You only need a mouse to play this game.
Place, move and select tokens with your
left mouse button.
If a player wins the game, press the
return-key to start a new game or the
escape-key to quit the game. You can
quit the game at any time.

b) Winconditions
If your opponent has less than 3 tokens
you win the game.
If your opponent cannot move one of his
tokens you win the game.