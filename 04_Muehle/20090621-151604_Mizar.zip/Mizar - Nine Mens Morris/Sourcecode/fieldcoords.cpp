//fieldcoords.cpp
#include "fieldcoords.h"
#include <SFML/Graphics.hpp>
#include <vector>

FieldCoords::CoordVec FieldCoords::Init(const sf::Vector2f &top_left, const sf::Vector2f &bottom_right)
{
	const sf::Vector2f mid_top_left((bottom_right.x - top_left.x) * (1.f/6.f) + top_left.x,
									(bottom_right.y - top_left.y) * (1.f/6.f) + top_left.y);
	const sf::Vector2f mid_bottom_right((bottom_right.x - top_left.x) * (5.f/6.f) + top_left.x,
										(bottom_right.y - top_left.y) * (5.f/6.f) + top_left.y);
	const sf::Vector2f inn_top_left((bottom_right.x - top_left.x) * (2.f/6.f) + top_left.x,
									(bottom_right.y - top_left.y) * (2.f/6.f) + top_left.y);
	const sf::Vector2f inn_bottom_right((bottom_right.x - top_left.x) * (4.f/6.f) + top_left.x,
										(bottom_right.y - top_left.y) * (4.f/6.f) + top_left.y);
	CoordVec coords;
	// outer ring
	coords.push_back(top_left);															// top left     [0]
	coords.push_back(sf::Vector2f((top_left.x + bottom_right.x) / 2.f, top_left.y));	// top mid      [1]
	coords.push_back(sf::Vector2f(bottom_right.x, top_left.y));							// top right    [2]
	coords.push_back(sf::Vector2f(bottom_right.x, (top_left.y + bottom_right.y) / 2.f));// mid right    [3]
	coords.push_back(bottom_right);														// bottom right [4]
	coords.push_back(sf::Vector2f((top_left.x + bottom_right.x) / 2.f, bottom_right.y));// bottom mid   [5]
	coords.push_back(sf::Vector2f(top_left.x, bottom_right.y));							// bottom left  [6]
	coords.push_back(sf::Vector2f(top_left.x, (top_left.y + bottom_right.y) / 2.f));	// mid left     [7]
	// middle ring
	coords.push_back(mid_top_left);																	// top left     [8]
	coords.push_back(sf::Vector2f((mid_top_left.x + mid_bottom_right.x) / 2.f, mid_top_left.y));	// top mid      [9]
	coords.push_back(sf::Vector2f(mid_bottom_right.x, mid_top_left.y));								// top right    [10]
	coords.push_back(sf::Vector2f(mid_bottom_right.x, (mid_top_left.y + mid_bottom_right.y) / 2.f));// mid right    [11]
	coords.push_back(mid_bottom_right);																// bottom right [12]
	coords.push_back(sf::Vector2f((mid_top_left.x + mid_bottom_right.x) / 2.f, mid_bottom_right.y));// bottom mid   [13]
	coords.push_back(sf::Vector2f(mid_top_left.x, mid_bottom_right.y));								// bottom left  [14]
	coords.push_back(sf::Vector2f(mid_top_left.x, (mid_top_left.y + mid_bottom_right.y) / 2.f));	// mid left     [15]
	// inner ring
	coords.push_back(inn_top_left);																	// top left     [16]
	coords.push_back(sf::Vector2f((inn_top_left.x + inn_bottom_right.x) / 2.f, inn_top_left.y));	// top mid      [17]
	coords.push_back(sf::Vector2f(inn_bottom_right.x, inn_top_left.y));								// top right    [18]
	coords.push_back(sf::Vector2f(inn_bottom_right.x, (inn_top_left.y + inn_bottom_right.y) / 2.f));// mid right    [19]
	coords.push_back(inn_bottom_right);																// bottom right [20]
	coords.push_back(sf::Vector2f((inn_top_left.x + inn_bottom_right.x) / 2.f, inn_bottom_right.y));// bottom mid   [21]
	coords.push_back(sf::Vector2f(inn_top_left.x, inn_bottom_right.y));								// bottom left  [22]
	coords.push_back(sf::Vector2f(inn_top_left.x, (inn_top_left.y + inn_bottom_right.y) / 2.f));	// mid left     [23]

	return coords;
}