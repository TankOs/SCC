//playfield.h
#ifndef MYITSAGAMEPLAYFIELD_H
#define MYITSAGAMEPLAYFIELD_H

#include "token.h"
#include "fieldcoords.h"
#include <SFML/Graphics.hpp>
#include <vector>

class Neighbor;

class PlayField {
public:
	typedef std::vector<Token>::size_type SizeType;
	// C'tor
	PlayField(const sf::Vector2f& top_left, const sf::Vector2f& bottom_right, const sf::Image& token_image,
			  const sf::Color& col = sf::Color::Black, const bool tokens_set = false):
	m_fieldcoords(top_left, bottom_right),
	m_size(m_fieldcoords.Size())
	{
		for(SizeType i(0); i != m_size; ++i)
			m_tokenvec.push_back(Token(token_image, m_fieldcoords.GetCoord(i), col, tokens_set));
	}
	// Setter
	void SetTokenColor(const SizeType& index, const sf::Color& col) { m_tokenvec[index].SetColor(col); }
	void SetTokenIsSet(const SizeType& index, const bool is_set) { m_tokenvec[index].SetIsSet(is_set); }
	// Getter
	SizeType GetNumberPoints() const { return m_size; }
	sf::Vector2f GetPointPosition(const SizeType& index) const { return m_fieldcoords.GetCoord(index); }
	sf::FloatRect GetTokenRectangle(const SizeType& index) const { return m_tokenvec[index].GetRectangle(); }
	sf::Color GetTokenColor(const SizeType& index) const { return m_tokenvec[index].GetColor(); }
	bool GetTokenIsSet(const SizeType& index) const { return m_tokenvec[index].GetIsSet(); }
	// Methods
	bool IsTokenInMill(const SizeType& index) const;
	void PossibleTokenMoves(const SizeType& index, Neighbor& neighbors) const;
	void Draw(sf::RenderWindow& window);
private:
	FieldCoords m_fieldcoords;
	SizeType m_size;
	std::vector<Token> m_tokenvec;
};

class Neighbor {
public:
	enum Dir {
		TOP,
		BOTTOM,
		LEFT,
		RIGHT
	};
	// C'tor
	Neighbor(const PlayField::SizeType& top = -1, const PlayField::SizeType& bottom = -1,
			 const PlayField::SizeType& left = -1, const PlayField::SizeType& right = -1):
	m_top(top),
	m_bottom(bottom),
	m_left(left),
	m_right(right)
	{ }
	// Setter
	void SetNeighbors(const PlayField::SizeType& top, const PlayField::SizeType& bottom, const PlayField::SizeType& left, const PlayField::SizeType& right);
	void SetNeighbors(const Neighbor::Dir direction, const PlayField::SizeType& value);
	// Getter
	PlayField::SizeType GetNeighbor(const Neighbor::Dir direction) const;
	// Methods
	bool PointEqualsANeighbor(const PlayField::SizeType& index) const;
	bool NoNeighbors() const;
private:
	PlayField::SizeType m_top,
						m_bottom,
						m_left,
						m_right;
};

#endif // MYITSAGAMEPLAYFIELD_H