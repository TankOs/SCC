//token.h
#ifndef MYTINYTOKEN_H
#define MYTINYTOKEN_H

#include <SFML/Graphics.hpp>

class Token {
public:
	// C'tor
	Token(const sf::Image& image, const sf::Vector2f& pos, const sf::Color& col, const bool is_set = false):
	m_sprite(image, pos, sf::Vector2f(1.f, 1.f), 0.f, col),
	m_set(is_set)
	{
		m_sprite.SetCenter(m_sprite.GetSize() / 2.f);
	}
	// Setter
	void SetPosition(const sf::Vector2f& pos) { m_sprite.SetPosition(pos); }
	void SetColor(const sf::Color& col) { m_sprite.SetColor(col); }
	void SetIsSet(const bool is_set) { m_set = is_set; }
	// Getter
	sf::Vector2f GetPosition() const { return m_sprite.GetPosition(); }
	sf::Color GetColor() const { return m_sprite.GetColor(); }
	bool GetIsSet() const { return m_set; }
	sf::FloatRect GetRectangle() const;
	// Methods
	void SwitchIsSet() { m_set = !m_set; }
	void Draw(sf::RenderWindow& window) { if(m_set) window.Draw(m_sprite); }
private:
	sf::Sprite m_sprite;
	bool m_set;
};

#endif // MYTINYTOKEN_H