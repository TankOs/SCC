//token.cpp
#include "token.h"
#include <SFML/Graphics.hpp>

sf::FloatRect Token::GetRectangle() const
{
	// Center of m_sprite is not the top-left corner of the image,
	// instead it's the center of the image (see C'tor)
	return sf::FloatRect(m_sprite.GetPosition().x - (m_sprite.GetSize().x / 2.f),
						 m_sprite.GetPosition().y - (m_sprite.GetSize().y / 2.f),
						 m_sprite.GetPosition().x + (m_sprite.GetSize().x / 2.f),
						 m_sprite.GetPosition().y + (m_sprite.GetSize().y / 2.f));
}