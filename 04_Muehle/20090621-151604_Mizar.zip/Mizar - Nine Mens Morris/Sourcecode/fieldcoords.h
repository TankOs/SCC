//fieldcoords.h
#ifndef MYFIELDCOORDINATES_H
#define MYFIELDCOORDINATES_H

#include <SFML/Graphics.hpp>
#include <vector>

class FieldCoords {
public:
	typedef std::vector<const sf::Vector2f> CoordVec;
	// C'tor
	FieldCoords(const sf::Vector2f& top_left, const sf::Vector2f& bottom_right):
	m_coords(Init(top_left, bottom_right)),
	m_size(m_coords.size())
	{ }
	// Getter
	CoordVec::size_type Size() const { return m_size; }
	sf::Vector2f GetCoord(const CoordVec::size_type& index) const { return m_coords[index]; }
private:
	// Member
	CoordVec m_coords;
	CoordVec::size_type m_size;
	// Helpmethods
	CoordVec Init(const sf::Vector2f& top_left, const sf::Vector2f& bottom_right);
};

#endif // MYFIELDCOORDINATES_H