//playfield.cpp
#include "playfield.h"
#include "token.h"
#include "fieldcoords.h"
#include <SFML/Graphics.hpp>
#include <vector>

bool PlayField::IsTokenInMill(const SizeType& index) const
{
	// See FieldCoords::Init-Function to find out which index equals which point on the playfield
	const sf::Color cur_color(m_tokenvec[index].GetColor());
	if(index % 2 == 0) {
		// index is a corner on the playfield
		SizeType l_neighbor, ll_neighbor;
		SizeType r_neighbor, rr_neighbor;
		switch(index) {
			case 0:
				l_neighbor = 7; ll_neighbor = 6;
				r_neighbor = index + 1; rr_neighbor = index + 2;
				break;
			case 8:
				l_neighbor = 15; ll_neighbor = 14;
				r_neighbor = index + 1; rr_neighbor = index + 2;
				break;
			case 16:
				l_neighbor = 23; ll_neighbor = 22;
				r_neighbor = index + 1; rr_neighbor = index + 2;
				break;
			case 6:
				l_neighbor = index - 1; ll_neighbor = index - 2;
				r_neighbor = index + 1; rr_neighbor = 0;
				break;
			case 14:
				l_neighbor = index - 1; ll_neighbor = index - 2;
				r_neighbor = index + 1; rr_neighbor = 8;
				break;
			case 22:
				l_neighbor = index - 1; ll_neighbor = index - 2;
				r_neighbor = index + 1; rr_neighbor = 16;
				break;
			default:
				l_neighbor = index - 1; ll_neighbor = index - 2;
				r_neighbor = index + 1; rr_neighbor = index + 2;
				break;
		}
		if(m_tokenvec[index].GetIsSet() && m_tokenvec[r_neighbor].GetIsSet() && m_tokenvec[rr_neighbor].GetIsSet())
			if(m_tokenvec[r_neighbor].GetColor() == cur_color && m_tokenvec[rr_neighbor].GetColor() == cur_color)
				return true;
		if(m_tokenvec[index].GetIsSet() && m_tokenvec[l_neighbor].GetIsSet() && m_tokenvec[ll_neighbor].GetIsSet())
			if(m_tokenvec[l_neighbor].GetColor() == cur_color && m_tokenvec[ll_neighbor].GetColor() == cur_color)
				return true;
	} else {
		// index is a point between two corners
		SizeType l_neighbor(index - 1);
		SizeType r_neighbor;
		switch(index) {
			case 7: r_neighbor = 0; break;
			case 15: r_neighbor = 8; break;
			case 23: r_neighbor = 16; break;
			default: r_neighbor = index + 1; break;
		}
		if(m_tokenvec[index].GetIsSet() && m_tokenvec[r_neighbor].GetIsSet() && m_tokenvec[l_neighbor].GetIsSet())
			if(m_tokenvec[r_neighbor].GetColor() == cur_color && m_tokenvec[l_neighbor].GetColor() == cur_color)
				return true;
		// check the line that goes from the outer "ring" to the inner "ring"
		SizeType out, mid, inn;
		switch(index % 8) { // find out which of the 4 lines has to be checked
			case 1: out = 1; mid = 9; inn = 17;	break;
			case 3:	out = 3; mid = 11; inn = 19; break;
			case 5:	out = 5; mid = 13; inn = 21; break;
			case 7:	out = 7; mid = 15; inn = 23; break;
			default: return false; break;
		}
		if(m_tokenvec[out].GetIsSet() && m_tokenvec[mid].GetIsSet() && m_tokenvec[inn].GetIsSet())
			if(m_tokenvec[out].GetColor() == m_tokenvec[mid].GetColor() && m_tokenvec[out].GetColor() == m_tokenvec[inn].GetColor())
				return true;
	}
	return false;
}

void PlayField::PossibleTokenMoves(const SizeType& index, Neighbor& neighbors) const
{
	switch(index) {
		case 0: neighbors.SetNeighbors(-1, 7, -1, 1); break;
		case 1: neighbors.SetNeighbors(-1, 9, 0, 2); break;
		case 2: neighbors.SetNeighbors(-1, 3, 1, -1); break;
		case 3: neighbors.SetNeighbors(2, 4, 11, -1); break;
		case 4: neighbors.SetNeighbors(3, -1, 5, -1); break;
		case 5: neighbors.SetNeighbors(13, -1, 6, 4); break;
		case 6: neighbors.SetNeighbors(7, -1, -1, 5); break;
		case 7: neighbors.SetNeighbors(0, 6, -1, 15); break;
		case 8: neighbors.SetNeighbors(-1, 15, -1, 9); break;
		case 9: neighbors.SetNeighbors(1, 17, 8, 10); break;
		case 10: neighbors.SetNeighbors(-1, 11, 9, -1); break;
		case 11: neighbors.SetNeighbors(10, 12, 19, 3); break;
		case 12: neighbors.SetNeighbors(11, -1, 13, -1); break;
		case 13: neighbors.SetNeighbors(21, 5, 14, 12); break;
		case 14: neighbors.SetNeighbors(15, -1, -1, 13); break;
		case 15: neighbors.SetNeighbors(8, 14, 7, 23); break;
		case 16: neighbors.SetNeighbors(-1, 23, -1, 17); break;
		case 17: neighbors.SetNeighbors(9, -1, 16, 18); break;
		case 18: neighbors.SetNeighbors(-1, 19, 17, -1); break;
		case 19: neighbors.SetNeighbors(18, 20, -1, 11); break;
		case 20: neighbors.SetNeighbors(19, -1, 21, -1); break;
		case 21: neighbors.SetNeighbors(-1, 13, 22, 20); break;
		case 22: neighbors.SetNeighbors(23, -1, -1, 21); break;
		case 23: neighbors.SetNeighbors(16, 22, 15, -1); break;
		default: neighbors.SetNeighbors(-1, -1, -1, -1); break;
	}
	if(neighbors.GetNeighbor(Neighbor::TOP) != -1)
		if(m_tokenvec[neighbors.GetNeighbor(Neighbor::TOP)].GetIsSet())
			neighbors.SetNeighbors(Neighbor::TOP, -1);
	if(neighbors.GetNeighbor(Neighbor::BOTTOM) != -1)
		if(m_tokenvec[neighbors.GetNeighbor(Neighbor::BOTTOM)].GetIsSet())
			neighbors.SetNeighbors(Neighbor::BOTTOM, -1);
	if(neighbors.GetNeighbor(Neighbor::LEFT) != -1)
		if(m_tokenvec[neighbors.GetNeighbor(Neighbor::LEFT)].GetIsSet())
			neighbors.SetNeighbors(Neighbor::LEFT, -1);
	if(neighbors.GetNeighbor(Neighbor::RIGHT) != -1)
		if(m_tokenvec[neighbors.GetNeighbor(Neighbor::RIGHT)].GetIsSet())
			neighbors.SetNeighbors(Neighbor::RIGHT, -1);
}

void PlayField::Draw(sf::RenderWindow &window)
{
	for(std::vector<Token>::iterator it(m_tokenvec.begin()), end(m_tokenvec.end()); it != end; ++it)
		it->Draw(window);
}


void Neighbor::SetNeighbors(const PlayField::SizeType& top, const PlayField::SizeType& bottom, const PlayField::SizeType& left, const PlayField::SizeType& right)
{
	m_top = top;
	m_bottom = bottom;
	m_left = left;
	m_right = right;
}

void Neighbor::SetNeighbors(const Neighbor::Dir direction, const PlayField::SizeType& value)
{
	switch(direction) {
		case TOP:
			m_top = value;
			break;
		case BOTTOM:
			m_bottom = value;
			break;
		case LEFT:
			m_left = value;
			break;
		case RIGHT:
			m_right = value;
			break;
		default:
			break;
	}
}

PlayField::SizeType Neighbor::GetNeighbor(const Neighbor::Dir direction) const
{
	switch(direction) {
		case TOP:
			return m_top;
			break;
		case BOTTOM:
			return m_bottom;
			break;
		case LEFT:
			return m_left;
			break;
		case RIGHT:
			return m_right;
			break;
		default:
			return -1;
			break;
	}
}

bool Neighbor::PointEqualsANeighbor(const PlayField::SizeType& index) const
{
	return (m_top == index || m_bottom == index || m_left == index || m_right == index);
}

bool Neighbor::NoNeighbors() const
{
	return (m_top == -1 && m_bottom == -1 && m_left == -1 && m_right == -1);
}