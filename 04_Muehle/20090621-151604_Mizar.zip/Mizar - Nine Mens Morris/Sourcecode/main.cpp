//main.cpp
#include "token.h"
#include "playfield.h"
#include "flashtext.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

enum GamePhase {
	GP_Init = 0,
	GP_Placing,
	GP_Moving,
	GP_Flying,
	GP_Win
};

bool AllTokenOfColorInMill(const PlayField& field, const sf::Color& color);
bool AllTokenOfColorNotMovable(const PlayField& field, const sf::Color& color);

int main()
{
	// load images
	sf::Image token_image, field_image;
	if(!token_image.LoadFromFile("img/token.png") || !field_image.LoadFromFile("img/field.png"))
		return 1;

	// load sounds
	sf::SoundBuffer placing_buffer, removing_buffer, win_buffer;
	if(!placing_buffer.LoadFromFile("sou/placing_token.ogg") || !removing_buffer.LoadFromFile("sou/removing_token.ogg") ||
	   !win_buffer.LoadFromFile("sou/win.ogg"))
	   return 1;

	// create the window
	sf::RenderWindow window(sf::VideoMode(800, 600, 32), "SCC04 - Nine Mens Morris by Mizar", sf::Style::Close);
	window.SetFramerateLimit(60);

	// token colors
	const sf::Color player1_col(sf::Color::Green);
	const sf::Color player2_col(sf::Color::Yellow);
	const sf::Color marker_col(255, 255, 255, 120);
	
	// create playfieldsprite
	field_image.SetSmooth(false);
	sf::Sprite field(field_image, sf::Vector2f(window.GetWidth() / 2.f, window.GetHeight() / 2.f));
	field.SetCenter(field.GetSize() / 2.f);

	// create playfield
	PlayField playfield(sf::Vector2f(100.f, 100.f), sf::Vector2f(700.f, 500.f), token_image);

	// create sounds
	sf::Sound win_sound(win_buffer);
	sf::Sound placing_sound(placing_buffer);
	sf::Sound removing_sound(removing_buffer);

	// mouse variables
	float mouse_x(0.f);
	float mouse_y(0.f);

	// additional vaiables
	PlayField::SizeType tokens_player_one(0), tokens_player_two(0);
	PlayField::SizeType tokensset_player_one(0), tokensset_player_two(0);
	PlayField::SizeType temp_token_index(0);
	Neighbor token_neighbors;
	bool player_ones_turn(true);
	bool remove_token(false);
	bool moving_token(false);
	bool flying_token(false);
	FlashText flash_text("Play", sf::Vector2f(window.GetWidth() / 2.f, window.GetHeight() / 2.f), 40.f, sf::Color::Red);
	flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
	GamePhase gamephase(GP_Placing);
	sf::String gamephase_text("", sf::Font::GetDefaultFont(), 40.f);
	gamephase_text.SetPosition(window.GetWidth() / 2.f, window.GetHeight() * 0.05f);
	sf::String players_turn_text("", sf::Font::GetDefaultFont(), 40.f);
	players_turn_text.SetPosition(window.GetWidth() / 2.f, window.GetHeight() * 0.9f);
	sf::String win_info_text("'Return' = new game   'Esc' = Quit", sf::Font::GetDefaultFont(), 40.f);
	win_info_text.SetCenter(win_info_text.GetRect().GetWidth() / 2.f, win_info_text.GetSize() / 2.f);
	win_info_text.SetPosition(window.GetWidth() / 2.f, window.GetHeight() * 0.65f);
	win_info_text.SetColor(sf::Color::Red);
	
	// mainloop
	while(window.IsOpened()) {

		// eventloop
		sf::Event input;
		while(window.GetEvent(input)) {
			if(input.Type == sf::Event::Closed || input.Type == sf::Event::KeyPressed && input.Key.Code == sf::Key::Escape)
				window.Close();

			// update mousecoordinates
			if(input.Type == sf::Event::MouseMoved) {
				mouse_x = static_cast<float>(window.GetInput().GetMouseX());
				mouse_y = static_cast<float>(window.GetInput().GetMouseY());
			}

			// handle events for the current gamephase
			switch(gamephase) {
				case GP_Placing:
					if(input.Type == sf::Event::MouseButtonPressed && input.MouseButton.Button == sf::Mouse::Left) {
						for(PlayField::SizeType i(0), e(playfield.GetNumberPoints()); i != e; ++i) {
							if(playfield.GetTokenRectangle(i).Contains(mouse_x, mouse_y)) {
								if(playfield.GetTokenIsSet(i) && remove_token) {
									if(AllTokenOfColorInMill(playfield, (player_ones_turn ? player2_col : player1_col)) &&
									   playfield.GetTokenColor(i) == (player_ones_turn ? player2_col : player1_col)) {
										playfield.SetTokenIsSet(i, false);
										player_ones_turn ? --tokens_player_two : --tokens_player_one;
										removing_sound.Play();
										remove_token = false;
										player_ones_turn = !player_ones_turn;
									} else if(playfield.GetTokenColor(i) == (player_ones_turn ? player2_col : player1_col)) {
										if(playfield.IsTokenInMill(i)) {
											flash_text.SetText("Remove tokens not in mill first");
											flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
										} else {
											playfield.SetTokenIsSet(i, false);
											player_ones_turn ? --tokens_player_two : --tokens_player_one;
											removing_sound.Play();
											remove_token = false;
											player_ones_turn = !player_ones_turn;
										}
									}
								} else if(playfield.GetTokenIsSet(i) && !remove_token) {
										flash_text.SetText("Cannot be placed");
										flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
								} else if(!remove_token) {
									playfield.SetTokenColor(i, (player_ones_turn ? player1_col : player2_col));
									playfield.SetTokenIsSet(i, true);
									placing_sound.Play();
									player_ones_turn ? ++tokens_player_one : ++tokens_player_two;
									player_ones_turn ? ++tokensset_player_one : ++tokensset_player_two;
									if(playfield.IsTokenInMill(i)) {
										remove_token = true;
										flash_text.SetText("Mill");
										flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
									} else {
										player_ones_turn = !player_ones_turn;
									}
								}
								break;
							}
						} // end of for-loop PLACING-CASE
					}
					break;
				case GP_Moving:
					if(input.Type == sf::Event::MouseButtonPressed && input.MouseButton.Button == sf::Mouse::Left) {
						for(PlayField::SizeType i(0), e(playfield.GetNumberPoints()); i != e; ++i) {
							if(playfield.GetTokenRectangle(i).Contains(mouse_x, mouse_y)) {
								if(playfield.GetTokenIsSet(i) && remove_token) {
									if(AllTokenOfColorInMill(playfield, (player_ones_turn ? player2_col : player1_col)) &&
									   playfield.GetTokenColor(i) == (player_ones_turn ? player2_col : player1_col)) {
										playfield.SetTokenIsSet(i, false);
										player_ones_turn ? --tokens_player_two : --tokens_player_one;
										removing_sound.Play();
										remove_token = false;
										player_ones_turn = !player_ones_turn;
									} else if(playfield.GetTokenColor(i) == (player_ones_turn ? player2_col : player1_col)) {
										if(playfield.IsTokenInMill(i)) {
											flash_text.SetText("Remove tokens not in mill first");
											flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
										} else {
											playfield.SetTokenIsSet(i, false);
											player_ones_turn ? --tokens_player_two : --tokens_player_one;
											removing_sound.Play();
											remove_token = false;
											player_ones_turn = !player_ones_turn;
										}
									}
								} else if(moving_token) {
									if(token_neighbors.PointEqualsANeighbor(i)) {
										playfield.SetTokenColor(i, (player_ones_turn ? player1_col : player2_col));
										playfield.SetTokenIsSet(i, true);
										playfield.SetTokenIsSet(temp_token_index, false);
										placing_sound.Play();
										moving_token = false;
										if(playfield.IsTokenInMill(i)) {
											remove_token = true;
											flash_text.SetText("Mill");
											flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
										} else {
											player_ones_turn = !player_ones_turn;
										}
									}
								} else if(playfield.GetTokenIsSet(i) && !moving_token && !remove_token) {
									if(playfield.GetTokenColor(i) == (player_ones_turn ? player1_col : player2_col)) {
										playfield.PossibleTokenMoves(i, token_neighbors);
										if(token_neighbors.NoNeighbors()) {
											flash_text.SetText("This token cannot be moved");
											flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
										} else {
											moving_token = true;
											temp_token_index = i;
											flash_text.SetText("Where to move this token?");
											flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
										}
									} else {
										flash_text.SetText("Select one of your tokens to move");
										flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
									}
								}
								break;
							}
						} // end of for-loop MOVING-CASE
					}
					break;
				case GP_Flying:
					if(input.Type == sf::Event::MouseButtonPressed && input.MouseButton.Button == sf::Mouse::Left) {
						for(PlayField::SizeType i(0), e(playfield.GetNumberPoints()); i != e; ++i) {
							if(playfield.GetTokenRectangle(i).Contains(mouse_x, mouse_y)) {
								if(playfield.GetTokenIsSet(i) && remove_token) {
									if(AllTokenOfColorInMill(playfield, (player_ones_turn ? player2_col : player1_col)) &&
									   playfield.GetTokenColor(i) == (player_ones_turn ? player2_col : player1_col)) {
										playfield.SetTokenIsSet(i, false);
										player_ones_turn ? --tokens_player_two : --tokens_player_one;
										removing_sound.Play();
										remove_token = false;
										player_ones_turn = !player_ones_turn;
									} else if(playfield.GetTokenColor(i) == (player_ones_turn ? player2_col : player1_col)) {
										if(playfield.IsTokenInMill(i)) {
											flash_text.SetText("Remove tokens not in mill first");
											flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
										} else {
											playfield.SetTokenIsSet(i, false);
											player_ones_turn ? --tokens_player_two : --tokens_player_one;
											removing_sound.Play();
											remove_token = false;
											player_ones_turn = !player_ones_turn;
										}
									}
								} else if(moving_token) {
									if(token_neighbors.PointEqualsANeighbor(i)) {
										playfield.SetTokenColor(i, (player_ones_turn ? player1_col : player2_col));
										playfield.SetTokenIsSet(i, true);
										playfield.SetTokenIsSet(temp_token_index, false);
										placing_sound.Play();
										moving_token = false;
										if(playfield.IsTokenInMill(i)) {
											remove_token = true;
											flash_text.SetText("Mill");
											flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
										} else {
											player_ones_turn = !player_ones_turn;
										}
									}
								} else if(flying_token) {
									if(playfield.GetTokenIsSet(i)) {
										flash_text.SetText("Cannot be placed");
										flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
									} else {
										playfield.SetTokenColor(i, (player_ones_turn ? player1_col : player2_col));
										playfield.SetTokenIsSet(i, true);
										playfield.SetTokenIsSet(temp_token_index, false);
										placing_sound.Play();
										flying_token = false;
										if(playfield.IsTokenInMill(i)) {
											remove_token = true;
											flash_text.SetText("Mill");
											flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
										} else {
											player_ones_turn = !player_ones_turn;
										}
									}
								} else if(playfield.GetTokenIsSet(i) && !flying_token && !moving_token && !remove_token) {
									if(playfield.GetTokenColor(i) == (player_ones_turn ? player1_col : player2_col)) {
										if((player_ones_turn ? tokens_player_one : tokens_player_two) == 3) {
												flying_token = true;
												temp_token_index = i;
												flash_text.SetText("Where to place this token?");
												flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
										} else {
											playfield.PossibleTokenMoves(i, token_neighbors);
											if(token_neighbors.NoNeighbors()) {
												flash_text.SetText("This token cannot be moved");
												flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
											} else {
												moving_token = true;
												temp_token_index = i;
												flash_text.SetText("Where to move this token?");
												flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
											}
										}
									} else {
										if((player_ones_turn ? tokens_player_one : tokens_player_two) == 3)
											flash_text.SetText("Select one of your tokens to place");
										else
											flash_text.SetText("Select one of your tokens to move");
										flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
									}
								}
								break;
							}
						} // end of for-loop FLYING-CASE
					}
				case GP_Win:
					if(input.Type == sf::Event::KeyPressed && input.Key.Code == sf::Key::Return)
						gamephase = GP_Init;
					break;
				default:
					break;
			}
		}

		// changing Gamephase
		if(gamephase == GP_Init) {
			// Unset the whole playfield
			for(PlayField::SizeType i(0), e(playfield.GetNumberPoints()); i != e; ++i)
				playfield.SetTokenIsSet(i, false);
			// Set variables back to their initiate values
			tokens_player_one = 0; tokens_player_two = 0;
			tokensset_player_one = 0; tokensset_player_two = 0;
			temp_token_index = 0;
			token_neighbors.SetNeighbors(-1, -1, -1, -1);
			player_ones_turn = true;
			remove_token = false;
			moving_token = false;
			flying_token = false;
			flash_text.SetText("Play");
			flash_text.SetCenter(flash_text.GetWidth() / 2.f, flash_text.GetHeight() / 2.f);
			gamephase = GP_Placing;
		} else if(gamephase == GP_Placing && tokensset_player_one >= 9 && tokensset_player_two >= 9) {
			gamephase = GP_Moving;
		} else if(gamephase == GP_Moving && tokens_player_one == 3 || gamephase == GP_Moving && tokens_player_two == 3) {
			gamephase = GP_Flying;
		} else if(gamephase == GP_Flying && tokens_player_one < 3 || gamephase == GP_Flying && tokens_player_two < 3) {
			gamephase = GP_Win;
			win_sound.Play();
		} else if(gamephase == GP_Moving && !remove_token && AllTokenOfColorNotMovable(playfield, player1_col) ||
				  gamephase == GP_Moving && !remove_token && AllTokenOfColorNotMovable(playfield, player2_col)) {
			gamephase = GP_Win;
			win_sound.Play();
		}

		// changing Gamephase text
		if(remove_token) {
			gamephase_text.SetText("Remove a token");
		} else {
			switch(gamephase) {
				case GP_Placing:
					gamephase_text.SetText("Placing");
					break;
				case GP_Moving:
					gamephase_text.SetText("Moving");
					break;
				case GP_Flying:
					gamephase_text.SetText("Flying");
					break;
				case GP_Win:
					if(tokens_player_one < 3)
						gamephase_text.SetText("Player 2 Wins!");
					else if(tokens_player_two < 3)
						gamephase_text.SetText("Player 1 Wins!");
					else if(AllTokenOfColorNotMovable(playfield, player1_col))
						gamephase_text.SetText("Player 2 Wins!");
					else if(AllTokenOfColorNotMovable(playfield, player2_col))
						gamephase_text.SetText("Player 1 Wins!");
					else
						gamephase_text.SetText("???");
					break;
				default:
					break;
			}
		}
		gamephase_text.SetCenter(gamephase_text.GetRect().GetWidth() / 2.f, gamephase_text.GetSize() / 2.f);
		
		// changing players turn text
		if(player_ones_turn) {
			players_turn_text.SetText("Player one, it's your turn");
			players_turn_text.SetColor(player1_col);
		} else {
			players_turn_text.SetText("Player two, it's your turn");
			players_turn_text.SetColor(player2_col);
		}
		players_turn_text.SetCenter(players_turn_text.GetRect().GetWidth() / 2.f, players_turn_text.GetSize() / 2.f);

		// draw
		window.Clear(sf::Color(100, 100, 255));
		window.Draw(field);
		playfield.Draw(window);
		window.Draw(gamephase_text);
		window.Draw(players_turn_text);
		flash_text.Draw(window);
		if(gamephase == GP_Win)
			window.Draw(win_info_text);
		window.Display();
	}

	return 0;
}

bool AllTokenOfColorInMill(const PlayField& field, const sf::Color& color)
{
	for(PlayField::SizeType i(0), e(field.GetNumberPoints()); i != e; ++i) {
		if(field.GetTokenIsSet(i) && field.GetTokenColor(i) == color)
			if(!field.IsTokenInMill(i))
				return false;
	}
	return true;
}

bool AllTokenOfColorNotMovable(const PlayField& field, const sf::Color& color)
{
	Neighbor neighbor;
	for(PlayField::SizeType i(0), e(field.GetNumberPoints()); i != e; ++i) {
		if(field.GetTokenIsSet(i) && field.GetTokenColor(i) == color) {
			field.PossibleTokenMoves(i, neighbor);
			if(!neighbor.NoNeighbors())
				return false;
		}
	}
	return true;
}