//flashtext.h
#ifndef MYFLASHTEXT_H
#define MYFLASHTEXT_H

#include <SFML/Graphics.hpp>
#include <string>

class FlashText {
public:
	// C'tor
	FlashText(const std::string& text, const sf::Vector2f& pos = sf::Vector2f(0.f, 0.f), const float& size = 30.f,
			  const sf::Color& col = sf::Color::White, const bool visible = true):
	m_string(text, sf::Font::GetDefaultFont(), size),
	m_color(col),
	m_alpha(visible ? 255 : 0),
	m_elapsedtime(0.f)
	{
		m_color.a = m_alpha;
		m_string.SetColor(m_color);
		m_string.SetPosition(pos);
	}
	// Setter
	void SetColor(const sf::Color& col);
	void SetPosition(const sf::Vector2f& pos) { m_string.SetPosition(pos); }
	void SetText(const std::string& text, const bool visible = true) { m_string.SetText(text); SetVisible(visible); }
	void SetVisible(const bool visible);
	void SetCenter(const float& CenterX, const float& CenterY) { m_string.SetCenter(CenterX, CenterY); }
	// Getter
	sf::Color GetColor() const { return m_string.GetColor(); }
	sf::Vector2f GetPosition() const { return m_string.GetPosition(); }
	float GetWidth() const { return m_string.GetRect().GetWidth(); }
	float GetHeight() const { return m_string.GetSize(); }
	// Methods
	void Draw(sf::RenderWindow& window);
private:
	sf::String m_string;
	sf::Color m_color;
	int m_alpha;
	float m_elapsedtime;
	static const float s_loweralphatime;
	static const int s_loweralphastep;
};

#endif // MYFLASHTEXT_H