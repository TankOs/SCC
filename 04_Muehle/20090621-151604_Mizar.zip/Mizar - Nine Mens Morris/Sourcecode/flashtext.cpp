//flashtext.cpp
#include "flashtext.h"
#include <SFML/Graphics.hpp>

const float FlashText::s_loweralphatime = 0.1f;
const int FlashText::s_loweralphastep = 10;

void FlashText::SetColor(const sf::Color& col)
{
	m_color = col;
	m_color.a = m_alpha;
	m_string.SetColor(m_color);
}

void FlashText::SetVisible(const bool visible)
{
	m_color.a = m_alpha = (visible ? 255 : 0);
	m_string.SetColor(m_color);
}

void FlashText::Draw(sf::RenderWindow &window)
{
	m_elapsedtime += window.GetFrameTime();
	if(m_alpha != 0 && m_elapsedtime > s_loweralphatime) {
		m_alpha - s_loweralphastep > 0 ? m_alpha -= s_loweralphastep : m_alpha = 0;
		m_color.a = m_alpha;
		m_string.SetColor(m_color);
		m_elapsedtime = 0.f;
	}
	if(m_elapsedtime < 0.f)
		m_elapsedtime = 0.f;
	window.Draw(m_string);
}