#include <SFML/Graphics.hpp>
#include <list>
#include "shot.h"
#include "enemy.h"
#include "collision.h"
#include "torpedo.h"

#ifndef FRAMEWORK_H
#define FRAMEWORK_H

class Framework
{
private:
	float score;
	int framecounter;
	sf::Image ShotImage;
	sf::Image ShotAnim;
	sf::Image EnemyImage;
	sf::Image EnemyAnim;
	sf::Image TorpedoSet;
	std::list<Shot> Shots;
	std::list<Enemy> Enemies;
	std::list<Torpedo> Torpedos;

public:
	Framework();
	void createShot(sf::Sprite &Player);
	void checkShots(sf::RenderWindow &App);
	void createEnemy();
	void checkEnemies(sf::Sprite &Player, sf::RenderWindow &App);
	bool checkTorpedos(sf::Sprite &Player, sf::RenderWindow &App);
	void checkCollision();
	float getScore() {return score;}
	void resetScore() {score=0;}
};


#endif