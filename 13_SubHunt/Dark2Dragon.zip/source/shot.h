#include <SFML/Graphics.hpp>

#ifndef SHOT_H
#define SHOT_H

class Shot
{
private:
	sf::Sprite ShotSprite;
	bool bIsHit;
	bool bIsDestroyed;
	int iAnimZaehler;
	int iAnimDestroyZaehler;
	int iFrameZaehler;

public:
	Shot();
	void setPos (sf::Sprite &sPlayer, sf::Image &ShotImage);
	void move();
	bool checkPos();
	void DestroyAnim(sf::Image &ShotAnim);
	void Hit() {bIsHit = true;}
	bool IsHit() {return bIsHit;}
	bool IsDestroyed() {return bIsDestroyed;}
	sf::Sprite GetSprite() {return ShotSprite;}
	void Draw(sf::RenderWindow &App) {App.Draw(ShotSprite);}
};


#endif