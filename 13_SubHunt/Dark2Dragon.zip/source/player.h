#include <SFML/Graphics.hpp>

#ifndef PLAYER_H
#define PLAYER_H

class Player
{
private:

	sf::Image PlayerImage;
	sf::Image hudImage;
	sf::Image LiveImage;
	sf::Image ShotsImage;
	sf::Sprite PlayerSprite;
	sf::Sprite hudSprite;
	sf::Sprite LiveSprite1;
	sf::Sprite LiveSprite2;
	sf::Sprite LiveSprite3;
	sf::Sprite ShotSprite1;
	sf::Sprite ShotSprite2;
	sf::Sprite ShotSprite3;
	sf::Sprite ShotSprite4;
	sf::Sprite ShotSprite5;
	int maxShots;
	int lives;
	bool spacedown;
	int iFramecounter;

public:
	Player();
	bool move(sf::RenderWindow &App);
	void Hit();
	int getlives() {return lives;}
	sf::Sprite GetPlayer() {return PlayerSprite;}
	void Draw(sf::RenderWindow &App); 
};


#endif