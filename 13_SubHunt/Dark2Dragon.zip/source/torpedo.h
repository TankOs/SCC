#include <SFML/Graphics.hpp>

#ifndef TORPEDO_H
#define TORPEDO_H

class Torpedo
{
private:
	sf::Sprite TorpedoSprite;
	bool bIsHit;
	bool bIsDestroyed;
	int iAnimDestroyZaehler;
	int iFrameZaehler;

public:
	Torpedo();
	void setPos (sf::Sprite &PlayerSprite,sf::Sprite &EnemySprite, sf::Image &Torpedo);
	void move();
	bool checkPos();
	void DestroyAnim(sf::Image &ShotAnim);
	void Hit() {bIsHit = true;}
	bool IsHit() {return bIsHit;}
	bool IsDestroyed() {return bIsDestroyed;}
	sf::Sprite GetSprite() {return TorpedoSprite;}
	void Draw(sf::RenderWindow &App) {App.Draw(TorpedoSprite);}
};


#endif