#include <SFML/Graphics.hpp>

#ifndef ENEMY_H
#define ENEMY_H

class Enemy
{
private:
	sf::Sprite EnemySprite;
	bool bLeftPos;
	bool bIsHit;
	bool bIsDestroyed;
	int Torpedos;
	int iAnimDestroyZaehler;
	int iFrameZaehler;

public:
	Enemy();
	void setPos (sf::Image &EnemyImage);
	void move();
	bool checkPos();
	void DestroyAnim(sf::Image &EnemyAnim);
	void Hit() {bIsHit = true;}
	bool IsHit() {return bIsHit;}
	bool IsDestroyed() {return bIsDestroyed;}
	void fire() {Torpedos++;}
	int fired() {return Torpedos;}
	sf::Sprite GetSprite() {return EnemySprite;}
	void Draw(sf::RenderWindow &App) {App.Draw(EnemySprite);}
};


#endif