#include "torpedo.h"

// Konstruktor
Torpedo::Torpedo() {
	bIsHit = false;
	bIsDestroyed = false;
	iAnimDestroyZaehler = 0;
}

void Torpedo::setPos (sf::Sprite &PlayerSprite, sf::Sprite &EnemySprite, sf::Image &Torpedo) {

	TorpedoSprite.SetImage(Torpedo);
	TorpedoSprite.SetPosition(EnemySprite.GetPosition().x + 75, EnemySprite.GetPosition().y);	

	TorpedoSprite.SetSubRect(sf::IntRect(0,0,25,25));

	iFrameZaehler=10;
}

void Torpedo::move() {

	TorpedoSprite.Move(0,-2);
}

bool Torpedo::checkPos() {
	if (TorpedoSprite.GetPosition().y < 230)
		return true;
	else
		return false;
}

void Torpedo::DestroyAnim(sf::Image &ShotAnim) {
	
	if (iFrameZaehler == 10) {
		TorpedoSprite.SetPosition(TorpedoSprite.GetPosition().x,221);
		iFrameZaehler = 0;
		TorpedoSprite.SetImage(ShotAnim);
		TorpedoSprite.SetSubRect(sf::IntRect(30*iAnimDestroyZaehler,0,30*(iAnimDestroyZaehler+1),30));
		iAnimDestroyZaehler++;

		if (iAnimDestroyZaehler == 8)
			bIsDestroyed = true;
	}

	iFrameZaehler++;
}