#include "framework.h"

Framework::Framework() {

	framecounter = 0;

	EnemyImage.LoadFromFile("gfx/uboot.png");
	EnemyImage.SetSmooth(false);
	
	EnemyAnim.LoadFromFile("gfx/enemyExplode.png");
	EnemyAnim.SetSmooth(false);
	
	ShotImage.LoadFromFile("gfx/fass.png");
	ShotImage.SetSmooth(false);

	ShotAnim.LoadFromFile("gfx/explosionAnim.png");
	ShotAnim.SetSmooth(false);

	TorpedoSet.LoadFromFile("gfx/torpedo.png");
	TorpedoSet.SetSmooth(false);
}


void Framework::createShot(sf::Sprite &Player) {
	Shot fass;
	fass.setPos(Player, ShotImage);
	Shots.push_back(fass);
}

void Framework::checkShots(sf::RenderWindow &App) {
	std::list<Shot>::iterator lIter;

	for (lIter=Shots.begin(); lIter!=Shots.end(); ) {
		
		// Bewegen wenn nicht zerst�rt
		if (lIter->IsHit() == false)
			lIter->move();
		else
			lIter->DestroyAnim(ShotAnim);

		// Draw Fass
		lIter->Draw(App);
		
		// Au�erhalb Screen?
		if (lIter->checkPos() == true || lIter->IsDestroyed() == true)
			lIter = Shots.erase(lIter);
		else
			lIter++;			
	}
}

void Framework::createEnemy() {

	if (framecounter == 200) {
		Enemy Sub;
		Sub.setPos(EnemyImage);
		Enemies.push_back(Sub);
		framecounter = 0;
	}

	framecounter++;
}

void Framework::checkEnemies(sf::Sprite &Player, sf::RenderWindow &App) {
	std::list<Enemy>::iterator lIter;

	for (lIter=Enemies.begin(); lIter!=Enemies.end(); ) {
		
		// Bewegen
		lIter->move();

		// Torpedo feuern
		if (lIter->fired() < 5 && sf::Randomizer::Random(0,200) == 5) {
			lIter->fire();
			Torpedo torp;
			torp.setPos(Player, lIter->GetSprite(), TorpedoSet);
			Torpedos.push_back(torp);
		}
		
		// Wenn Zerst�rt dann Anim
		if (lIter->IsHit() == true)
			lIter->DestroyAnim(EnemyAnim);

		// Draw
		lIter->Draw(App);

		if (lIter->IsDestroyed() == true)
			score = score+10;
		
		// L�schen wenn au�erhalb Screen oder Objekt zerst�rt
		if (lIter->checkPos() == true || lIter->IsDestroyed() == true)
			lIter = Enemies.erase(lIter);
		else
			lIter++;			
	}
}

void Framework::checkCollision() {
	std::list<Enemy>::iterator lEIter;
	std::list<Shot>::iterator lSIter;


	for (lEIter=Enemies.begin(); lEIter!=Enemies.end(); ) {
		for (lSIter=Shots.begin(); lSIter!=Shots.end(); ) {
			if (simpleCollision(lEIter->GetSprite(),lSIter->GetSprite()) != 0 && lEIter->IsHit() == false && lSIter->IsHit() == false) {
				lEIter->Hit();
				lSIter->Hit();
			}
			else
				lSIter++;	
		}
	lEIter++;

	}
}


bool Framework::checkTorpedos(sf::Sprite &Player, sf::RenderWindow &App) {
	std::list<Torpedo>::iterator lIter;
	bool ret = false;

	for (lIter=Torpedos.begin(); lIter!=Torpedos.end(); ) {
		
		if (simpleCollision(lIter->GetSprite(),Player) != 0 && lIter->IsHit() == false) {
			lIter->Hit();
			ret = true;
		}
		
		if (lIter->IsHit() == false)
			lIter->move();
			
		// Wenn Zerst�rt dann Anim
		if (lIter->IsHit() == true) 
			lIter->DestroyAnim(ShotAnim);

		// Draw
		lIter->Draw(App);
		
		// L�schen wenn au�erhalb Screen oder Objekt zerst�rt
		if ((lIter->checkPos() == true && lIter->IsHit() == false) || lIter->IsDestroyed() == true)
			lIter = Torpedos.erase(lIter);
		else
			lIter++;			
	}

	return ret;
}