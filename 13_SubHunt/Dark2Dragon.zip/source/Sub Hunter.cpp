////////////////////////////////////////////////////////////
// Sub Hunter
////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <sstream>
#include "player.h"
#include "framework.h"

int main()
{

	// ### Main Window ###
    sf::RenderWindow App(sf::VideoMode(1024, 768, 16), "Sub Hunter");

	App.SetFramerateLimit(60);
	App.ShowMouseCursor(false);

	// Font
	sf::Font MyFont;
	sf::String Score;
	sf::String GameOver;

	// Background
	sf::Image iBackground;
	sf::Sprite sBackground;

	iBackground.LoadFromFile("gfx/background.png");
	sBackground.SetImage(iBackground);
	sBackground.SetPosition(0,0);

	// Initialisierung
	Player pShip;
	Framework fEngine;
	
	// Score zur�cksetzen
	fEngine.resetScore();

	// Score Text
	std::stringstream sscore;
	MyFont.LoadFromFile("verdanab.ttf");
	Score.SetFont(MyFont);
	Score.SetSize(20);
	Score.SetPosition(170,3);
	Score.SetText("0");

	// Game Over Text
	GameOver.SetFont(MyFont);
	GameOver.SetSize(100);
	GameOver.SetText("GAME OVER");
	GameOver.SetPosition(200,330);
	GameOver.SetColor(sf::Color(128, 0, 0));


	// ### Start game loop ###
    while (App.IsOpened())
    {  

		// Process events
        sf::Event Event;
        while (App.GetEvent(Event))
        {
			// Close window: exit
            if (Event.Type == sf::Event::Closed)
                App.Close();

			// KeyEvents abfangen
			if (Event.Type == sf::Event::KeyPressed)
			{
				// Escape key: exit
                if (Event.Key.Code == sf::Key::Escape)
                    App.Close();				
			}	     
		}

		// +++ Lebt Spieler noch? +++
		if (pShip.getlives() != 0) {
			// Create Enemies
			fEngine.createEnemy();

			// Move
			if (pShip.move(App) == true) {
				fEngine.createShot(pShip.GetPlayer());
			}
			
			// Check Collisions
			fEngine.checkCollision();

			// Get Score			
			sscore.str("");
			sscore << fEngine.getScore();
			Score.SetText(sscore.str());
		}

		// DRAW

		App.Draw(sBackground);
		fEngine.checkEnemies(pShip.GetPlayer(),App);
		pShip.Draw(App);
		if (fEngine.checkTorpedos(pShip.GetPlayer(), App) == true && pShip.getlives() != 0)	pShip.Hit();
		fEngine.checkShots(App);
		App.Draw(Score);
		if (pShip.getlives() == 0) App.Draw(GameOver);
		

		App.Display();
	}

	return 0;
}