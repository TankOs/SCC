#include "enemy.h"

// Konstruktor
Enemy::Enemy() {
	bIsHit = false;
	bIsDestroyed = false;
	iAnimDestroyZaehler = 0;
	iFrameZaehler = 0;
}

void Enemy::setPos(sf::Image &EnemyImage) {
		
	EnemySprite.SetImage(EnemyImage);

	bLeftPos = sf::Randomizer::Random(0,1);

	if (bLeftPos == 0) {
		EnemySprite.FlipX(true);
		EnemySprite.SetPosition(1030, sf::Randomizer::Random(280, 741));
	}
	else {
		EnemySprite.SetPosition(-160, sf::Randomizer::Random(280, 741));
	}
}

void Enemy::move() {

	if (bLeftPos == 0)
		EnemySprite.Move(-2,0);
	else
		EnemySprite.Move(2,0);

	if (bIsHit == true) 
		EnemySprite.Move(0,1);
}

bool Enemy::checkPos() {

	if (EnemySprite.GetPosition().x < 1033 && EnemySprite.GetPosition().x > -163)
		return false;
	else
		return true;
}

void Enemy::DestroyAnim(sf::Image &EnemyAnim) {
	
	if (iFrameZaehler == 10) {
		iFrameZaehler = 0;
		EnemySprite.SetImage(EnemyAnim);
		EnemySprite.SetSubRect(sf::IntRect(0,50*iAnimDestroyZaehler,150,50*(iAnimDestroyZaehler+1)));
		iAnimDestroyZaehler++;

		if (iAnimDestroyZaehler == 7)
			bIsDestroyed = true;
	}

	iFrameZaehler++;
}

