#include "player.h"


Player::Player() {
	
	PlayerImage.LoadFromFile("gfx/player.png");
	PlayerImage.SetSmooth(false);

	hudImage.LoadFromFile("gfx/hud.png");
	hudImage.SetSmooth(false);

	LiveImage.LoadFromFile("gfx/live.png");
	LiveImage.SetSmooth(false);

	ShotsImage.LoadFromFile("gfx/shots.png");
	ShotsImage.SetSmooth(false);

	PlayerSprite.SetImage(PlayerImage);
	hudSprite.SetImage(hudImage);
	LiveSprite1.SetImage(LiveImage);
	LiveSprite2.SetImage(LiveImage);
	LiveSprite3.SetImage(LiveImage);
	ShotSprite1.SetImage(ShotsImage);
	ShotSprite2.SetImage(ShotsImage);
	ShotSprite3.SetImage(ShotsImage);
	ShotSprite4.SetImage(ShotsImage);
	ShotSprite5.SetImage(ShotsImage);

	spacedown = false;
	lives = 3;
	maxShots = 0;

	// Position setzen
	PlayerSprite.SetPosition(410, 187);

	LiveSprite1.SetPosition(850,7);
	LiveSprite2.SetPosition(870,7);
	LiveSprite3.SetPosition(890,7);

	ShotSprite1.SetPosition(490,7);
	ShotSprite2.SetPosition(510,7);
	ShotSprite3.SetPosition(530,7);
	ShotSprite4.SetPosition(550,7);
	ShotSprite5.SetPosition(570,7);

}


bool Player::move(sf::RenderWindow &App) {

	bool ret=false;

	if (App.GetInput().IsKeyDown(sf::Key::Left) && (PlayerSprite.GetPosition().x > 0))   {
		PlayerSprite.Move(-5,0);
	}

	if (App.GetInput().IsKeyDown(sf::Key::Right) && (PlayerSprite.GetPosition().x < 819)) {
		PlayerSprite.Move(5,0);
	}

	// Schussbegrenzung
	if (iFramecounter == 50) {
		if (maxShots != 0) maxShots--;
		iFramecounter = 0;
	}

	// Schuss
	if (App.GetInput().IsKeyDown(sf::Key::Space)) {
		if (spacedown == false && maxShots < 5) {
			iFramecounter = 0;
			maxShots++;
			ret = true;
			spacedown = true;
		}
	}
	else {
		spacedown = false;
	}

	iFramecounter++;

	return ret;
}

void Player::Hit() {

	lives--;
}

void Player::Draw(sf::RenderWindow &App) {
	App.Draw(PlayerSprite);
	App.Draw(hudSprite);

	if (lives > 2)
		App.Draw(LiveSprite1);
	if (lives > 1)
		App.Draw(LiveSprite2);
	if (lives > 0)
		App.Draw(LiveSprite3);

	if (maxShots < 5)
		App.Draw(ShotSprite1);
	if (maxShots < 4)
		App.Draw(ShotSprite2);
	if (maxShots < 3)
		App.Draw(ShotSprite3);
	if (maxShots < 2)
		App.Draw(ShotSprite4);
	if (maxShots < 1)
		App.Draw(ShotSprite5);

}