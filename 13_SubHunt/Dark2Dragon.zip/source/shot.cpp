#include "shot.h"

// Konstruktor
Shot::Shot() {
	bIsHit = false;
	bIsDestroyed = false;
	iAnimDestroyZaehler = 0;
}

void Shot::setPos (sf::Sprite &sPlayer, sf::Image &ShotImage) {
	ShotSprite.SetImage(ShotImage);
	ShotSprite.SetPosition(sPlayer.GetPosition().x + 102, sPlayer.GetPosition().y + 60);	
	
	ShotSprite.SetSubRect(sf::IntRect(0,0,15,15));

	iAnimZaehler=1;
	iFrameZaehler=0;
}

void Shot::move() {
	ShotSprite.Move(0,2);


	// ANIMATED
	if (iFrameZaehler == 10) {
		iFrameZaehler = 0;

		if (iAnimZaehler == 4)
			iAnimZaehler = 0;

		ShotSprite.SetSubRect(sf::IntRect(15*iAnimZaehler,0,15*(iAnimZaehler+1),15));

		iAnimZaehler++;
	}

	iFrameZaehler++;
}

bool Shot::checkPos() {
	if (ShotSprite.GetPosition().y > 768)
		return true;
	else
		return false;
}

void Shot::DestroyAnim(sf::Image &ShotAnim) {
	
	if (iFrameZaehler == 10) {
		iFrameZaehler = 0;
		ShotSprite.SetImage(ShotAnim);
		ShotSprite.SetSubRect(sf::IntRect(30*iAnimDestroyZaehler,0,30*(iAnimDestroyZaehler+1),30));
		iAnimDestroyZaehler++;

		if (iAnimDestroyZaehler == 8)
			bIsDestroyed = true;
	}

	iFrameZaehler++;
}