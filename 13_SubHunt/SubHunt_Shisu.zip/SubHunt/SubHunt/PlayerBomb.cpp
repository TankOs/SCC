#include "PlayerBomb.h"
#include "DivingEnemy.h"
#include "ImageManager.h"

extern ImageManager ImgMng;

/*Ich stelle eine PlayerBomb her*/
PlayerBomb::PlayerBomb( const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung )
	: Weapons( pPosition, pTempo, pBeschleunigung )
{
	TheBomb.SetImage( *ImgMng.getResource("Pictures/PlayerBomb.png") );
}

/*Ich sage aus, ob die PlayerBomb sich noch im Spielfeld befindet*/
bool PlayerBomb::flying(int pScreenheigh) const
{
	return GetPosition().y <= pScreenheigh;
	//if( GetPosition().y <= pScreenheigh )
	//{
	//	return true;
	//}
	//return false;
}

/*Ich zeichne die PlayerBomb*/
void PlayerBomb::Render( sf::RenderTarget& Target ) const
{
	Target.Draw( TheBomb );
}

/*Ich gebe die Breite einer PlayerBomb zur�ck*/
int PlayerBomb::GetBreite() const
{
	return ImgMng.getResource("Pictures/PlayerBomb.png")->GetWidth();
}

/*Ich gebe den Ort (Index) des Schiffes aus, das ich treffe. Wenn ich nichts treffe, dann gebe ich -1 zur�ck.*/
int PlayerBomb::Getroffen(std::vector<DivingEnemy> pZiele, int pLaenge)
{
	sf::Rect<int> Rechteck( GetPosition().x, GetPosition().y,
		GetPosition().x + ImgMng.getResource("Pictures/PlayerBomb.png")->GetWidth(), GetPosition().y + ImgMng.getResource("Pictures/PlayerBomb.png")->GetHeight() );
	for( int i = 0; i < pLaenge; ++i )
	{
		if( pZiele[i].Getroffen( Rechteck ) )
		{
			return i;
		}
	}
	return -1;
}

sf::Vector2f PlayerBomb::GetSize()
{
	return sf::Vector2f(ImgMng.getResource("Pictures/PlayerBomb.png")->GetWidth(), ImgMng.getResource("Pictures/PlayerBomb.png")->GetHeight());
}