#include <cmath>

#include "FlyingEnemy.h"
#include "ImageManager.h"

extern ImageManager ImgMng;
extern sf::Vector2f Screen;
extern void AddBombe( const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung );
extern float ShipPosX;
extern int Score;

/*Ich Bilde das FlyingEnemy dem Rendertarget ab*/
void FlyingEnemy::Render( sf::RenderTarget& Target ) const
{
	Target.Draw( TheShip );
}

/*Ich Konstruiere ein FlyingEnemy, d.h. ich bewege es und initialisiere Daten*/
FlyingEnemy::FlyingEnemy( int pRandTempo, bool pRandSide, int pRandHeigh, bool ExtraBomb )
	: Einheit( sf::Vector2f( 0, 0 ) ), Bomb( ExtraBomb ), BombIntell( true ), Abwurfstelle(sf::Randomizer::Random( 200, 824 ) )
{
	if( pRandSide )
	{
		SetPosition( -90, pRandHeigh );
		Tempo = pRandTempo;
		TheShip.SetImage( *ImgMng.getResource( "Pictures/FlyingEnemy.png" ) );
	}
	else
	{
		SetPosition( Screen.x+2, pRandHeigh );
		Tempo = -pRandTempo;
		TheShip.SetImage( *ImgMng.getResource( "Pictures/FlyingEnemy_inv.png" ) );
	}
}

/*Ich f�hre die Bewegung des FlyingEnemy aus*/
void FlyingEnemy::Drift( double pFaktor )
{
	Move( Tempo * pFaktor, 0 );
	if( (std::fabs( GetPosition().x - Abwurfstelle ) < 20 && Bomb ) )
	{
		if(Tempo > 0 )
		{
			::AddBombe( sf::Vector2f( GetPosition().x + ( ImgMng.getResource( "Pictures/FlyingEnemy.png" )->GetWidth() / 2 ), GetPosition().y ), sf::Vector2f( 0.01, 50 ), sf::Vector2f( 0.01, 1.007 ) );	//Position & Tempo
		}
		else if( Tempo < 0 )
		{
			::AddBombe( sf::Vector2f(GetPosition().x + ( ImgMng.getResource("Pictures/FlyingEnemy.png")->GetWidth()/2), GetPosition().y), sf::Vector2f( 0.01, 50 ), sf::Vector2f( 0.01, 1.007 ) );	//Position & Tempo
		}
		Bomb = false;
	}
	if( ( std::fabs( (GetPosition().x + ( ImgMng.getResource( "Pictures/FlyingEnemy.png" )->GetWidth() / 2 ) ) - ShipPosX ) < 20 && BombIntell ) )
	{
		if( Tempo > 0 )
		{
			::AddBombe( sf::Vector2f( GetPosition().x + ( ImgMng.getResource( "Pictures/FlyingEnemy.png" )->GetWidth() / 2 ), GetPosition().y ), sf::Vector2f( 0.01, 50 ), sf::Vector2f( 0.01, 1.007 ) );	//Position & Tempo
		}
		else if( Tempo < 0 )
		{
			::AddBombe( sf::Vector2f( GetPosition().x + ( ImgMng.getResource( "Pictures/FlyingEnemy.png" )->GetWidth() / 2 ), GetPosition().y ), sf::Vector2f( 0.01, 50 ), sf::Vector2f( 0.01, 1.007 ) );	//Position & Tempo
		}
		BombIntell = false;
	}

	if( ( std::fabs( GetPosition().x - Abwurfstelle ) < 20 && Bomb )
		|| ( std::fabs( ( GetPosition().x + ( ImgMng.getResource( "Pictures/FlyingEnemy.png" )->GetWidth() / 2 ) ) - ShipPosX ) < 20 && Bomb) )
	{
		if( Tempo > 0 )
		{
			::AddBombe( sf::Vector2f(GetPosition().x + ( ImgMng.getResource( "Pictures/FlyingEnemy.png" )->GetWidth() / 2 ), GetPosition().y ), sf::Vector2f( 0.01, 50 ), sf::Vector2f( 0.01, 1.007 ) );	//Position & Tempo
		}
		else if( Tempo < 0 )
		{
			::AddBombe( sf::Vector2f(GetPosition().x + ( ImgMng.getResource( "Pictures/FlyingEnemy.png" )->GetWidth() / 2 ), GetPosition().y ), sf::Vector2f( 0.01, 50 ), sf::Vector2f( 0.01, 1.007 ) );	//Position & Tempo
		}
		Bomb = false;
	}
}

/*Ich gebe die Breite eines FlyingEnemys zur�ck*/
int FlyingEnemy::GetBreite() const
{
	return ImgMng.getResource( "Pictures/FlyingEnemy.png" )->GetWidth();
}

/*Ich gebe zur�ck, ob das �bergebene Rechteck sich mit meinem schneidet*/
bool FlyingEnemy::Getroffen( const sf::Rect< int >& pRechteck_2 )
{
	sf::Rect< int > Rechteck( GetPosition().x, GetPosition().y,
		GetPosition().x + ImgMng.getResource( "Pictures/FlyingEnemy.png" )->GetWidth(), GetPosition().y + ImgMng.getResource( "Pictures/FlyingEnemy.png" )->GetHeight() );
	return Rechteck.Intersects( pRechteck_2 );
}