#include "Ship.h"
#include "ImageManager.h"

extern ImageManager ImgMng;
extern float ShipPosX;

/*Ich Bilde das Ship auf dem Rendertarget ab*/
void Ship::Render( sf::RenderTarget& Target ) const
{
	Target.Draw( TheShip );
}

/*Ich Konstruiere ein Ship, d.h. ich bewege es und initialisiere Daten*/
Ship::Ship( const sf::Vector2f& Position )
	: Einheit( Position ), BonusUhr( 0 )
{
	Tempo = NormalTempo;
	TheShip.SetImage( *ImgMng.getResource("Pictures/Ship2.png") );
}

/*Ich berechne die Bewegung des Ships und f�hre sie aus*/
void Ship::Drift( double pPos, double pFaktor )
{
	pPos = GetPosition().x - pPos;
	if( pPos + ( ImgMng.getResource("Pictures/Ship2.png")->GetWidth() / 2 ) > ( Tempo * pFaktor ) )
	{
		Move( ( -Tempo ) * pFaktor * ( ( pPos + ImgMng.getResource("Pictures/Ship2.png")->GetWidth() / 2 ) / 300 + 0.4 ),0 );
		//            ( 0  )     (  1  )       ( 2)   (             3                                    )     (4)   (5)
		/*Diese Funktion bewegt das Schiff mit dem (0) Tempo Tempo (Da der (1) Faktor herausmultipliziert wurde)
		  in Richtung links. Ein weiterer Faktor ist der (2) Abstand der Maus zum Mittelpunkt, weshalb die (3) halbe
		  Breite hinzuaddiert wird, der, damit es nicht �bersensibilisiert, durch einen (4) Nenner geteilt wird.
		  Damit nah an der Maus nicht zu schnell das Tempo 0 erreicht wird wird ein (5) Dezimalbruch hinzu addiert.*/
	}
	if( pPos + ( ImgMng.getResource("Pictures/Ship2.png")->GetWidth() / 2 ) < ( ( -Tempo ) * pFaktor ) )
	{
		Move( Tempo * pFaktor * ( ( -( pPos + ImgMng.getResource("Pictures/Ship2.png")->GetWidth() / 2 ) ) / 300 + 0.4 ),0 );
		//          ( 0 )   (  1  )          ( 2)   (             3                                    )       (4)   (5)
		/*Diese Funktion bewegt das Schiff mit dem (0) Tempo Tempo (Da der (1) Faktor herausmultipliziert wurde)
		  in Richtung rechts. Ein weiterer Faktor ist der (2) Abstand der Maus zum Mittelpunkt, weshalb die (3) halbe
		  Breite hinzuaddiert wird, der, damit es nicht �bersensibilisiert, durch einen (4) Nenner geteilt wird.
		  Damit nah an der Maus nicht zu schnell das Tempo 0 erreicht wird wird ein (5) Dezimalbruch hinzu addiert.*/
	}
	if( BonusUhr != 0 )
	{
		if( BonusUhr->GetElapsedTime() >= Bonusdauer )
		{
			Tempo = NormalTempo;
			delete BonusUhr;
			BonusUhr = 0;
		}
	}
	ShipPosX = (GetPosition().x+(ImgMng.getResource("Pictures/Ship2.png")->GetWidth()/2));
}

/*Ich starte das Bonustempo*/
void Ship::StarteBonustempo()
{
	if( BonusUhr == 0 )
	{
		BonusUhr = new sf::Clock;
		Tempo = BonusTempo;
	}
}

/*Ich gebe die Breite eines Ships zur�ck*/
int Ship::GetBreite() const
{
	return ImgMng.getResource("Pictures/Ship2.png")->GetWidth();
}