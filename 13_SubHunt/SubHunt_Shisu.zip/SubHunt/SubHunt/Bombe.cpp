#include "Bombe.h"
#include "ImageManager.h"

extern ImageManager ImgMng;

Bombe::Bombe( const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung )
	: Weapons( pPosition, pTempo, pBeschleunigung )
{
	TheBomb.SetImage( *ImgMng.getResource( "Pictures/Bombe.png" ) );
}

int Bombe::GetBreite() const
{
	return ImgMng.getResource( "Pictures/Bombe.png" )->GetWidth();
}

int Bombe::GetHoehe() const
{
	return ImgMng.getResource( "Pictures/Bombe.png" )->GetHeight();
}

void Bombe::Render( sf::RenderTarget& Target ) const
{
	Target.Draw( TheBomb );
}