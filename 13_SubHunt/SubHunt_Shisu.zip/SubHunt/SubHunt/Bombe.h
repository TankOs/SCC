#ifndef BOMB_H
#define BOMB_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

#include "Weapons.h"

/*Ich bin eine Bombe, d.h. eine Bombe eines FlyingEnemys, die auf das Ship abgeworfen wird*/
class Bombe : public Weapons
{
private:
	sf::Sprite TheBomb;
	void Render(sf::RenderTarget& Target) const;
public:
	Bombe(const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung);
	
	int GetBreite() const;
	int GetHoehe() const;
};

#endif