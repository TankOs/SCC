#include <iostream>
#include <sstream>

#include "Splash.h"
#include "ImageManager.h"

extern ImageManager ImgMng;

/*Ich stelle eine Explosion her*/
Splash::Splash( const sf::Vector2f &pPosition )
	: index(0), SplashSD(Spl), Played(false)
{
	Move( pPosition );
	Uhr.Reset();
	std::ostringstream Stream;
	for( int i = 0; i < 7; ++i )
	{
		Stream.str("");
		Stream<<"Pictures/Splash"<<i+1<<".png";
		TheSplash[i].SetImage( *ImgMng.getResource(Stream.str()) );
	}
	SplashSD.SetVolume(60);
}

/*Ich zeichne die Explosion und animiere sie*/
void Splash::Render( sf::RenderTarget& Target ) const
{
	if( index < 7 )
	{
		Target.Draw( TheSplash[index] );
	}
}

void Splash::Prozess()
{
	if(SplashSD.GetStatus() != sf::Sound::Playing && !Played)
	{
		SplashSD.Play();
		Played = true;
	}
	if( Uhr.GetElapsedTime() >= 0.1 )
	{
		Uhr.Reset();
		++index;
	}
}

/*Ich liefere den Animationsindex der Explosion zur�ck*/
int Splash::GetIndex() const
{
	return index;
}

bool Splash::Playing() const
{
	//if(SplashSD.GetStatus() == sf::Sound::Playing)
	//{
	//	return true;
	//}
	//else
	//{
	//	std::cerr<<"Ich bin feddich hier, kann ich jetz feierabend machn?"<<std::endl;
	//	return false;
	//}
	return SplashSD.GetStatus() == sf::Sound::Playing;
}