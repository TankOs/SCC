#include <iostream>
#include <sstream>

#include "Wolke.h"
#include "ImageManager.h"

extern ImageManager ImgMng;

Wolke::Wolke(sf::Vector2f pFlugraum, int index)
: Tempo(sf::Randomizer::Random(20, 60)), Wait(0), Flugraum(pFlugraum)
{
	std::ostringstream Stream;
	Stream<<"Pictures/Wolke"<<index<<".png";
	WolkeSP.SetImage( *ImgMng.getResource(Stream.str()) );
	Stream.str("");
	Stream<<index;
	Index = Stream.str();
	Flugraum.y -= ImgMng.getResource("Pictures/Wolke"+Index+".png")->GetHeight();
	SetPosition(1050, sf::Randomizer::Random(Flugraum.x, Flugraum.y));
}

void Wolke::Render(sf::RenderTarget& Target) const
{
	Target.Draw(WolkeSP);
}

void Wolke::Drift(double pFaktor)
{
	if((Uhr.GetElapsedTime() > Wait) || (Wait == 0))
	{
		Wait = 0;
		Move( -Tempo * pFaktor, 0 );
		if(Outside())
		{
			Wait = sf::Randomizer::Random(5, 20);
			SetPosition(1050, sf::Randomizer::Random(Flugraum.x, Flugraum.y));
			Uhr.Reset();
		}
	}
}

bool Wolke::Outside()
{
	return GetPosition().x + ImgMng.getResource("Pictures/Wolke"+Index+".png")->GetWidth() < 0;
}