#ifndef EH_H
#define EH_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

extern void AddExplosion(const sf::Vector2f& pPosition, bool pSpieler);

/*Ich bin die Einheit, d.h. der Vater aller Schiffe und Flugzeuge.*/
class Einheit : public sf::Drawable
{
protected:
	sf::Sprite TheShip;
	virtual void Render(sf::RenderTarget& Target) const = 0;
	int Tempo;
public:
	Einheit(const sf::Vector2f& pPosition);
	virtual int GetBreite() const =0;
	bool InBildschirm() const;
};

#endif