#ifndef EFLY_H
#define EFLY_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

#include "Einheit.h"

/*Ich bin das FlyingEnemy, d.h. das Flugzeug des Computers*/
class FlyingEnemy : public Einheit
{
private:
	void Render(sf::RenderTarget& Target) const;
	bool Bomb, BombIntell;
public:
	FlyingEnemy(int pRandTempo, bool pRandSide, int pRandHeigh, bool ExtraBomb = false);	//random zwischen 100 und 300
	void Drift(double pFaktor);
	bool ImBild(int pScreenwidth) const;
	int GetBreite() const;
	int Abwurfstelle;
	bool Getroffen(const sf::Rect<int>& pRechteck_2);
};

#endif