#include <sstream>

#include "Explosion.h"
#include "ImageManager.h"

extern ImageManager ImgMng;

/*Ich stelle eine Explosion her*/
Explosion::Explosion( const sf::Vector2f &pPosition, bool pSpieler )
	: index( 2 ), back( false ), ExplSD( Expl )
{
	Move( pPosition );
	Uhr.Reset();
	std::ostringstream Stream;
	for( int i = 0; i < 9; ++i )
	{
		Stream.str( "" );
		Stream<<"Pictures/Exp"<<i<<".png";
		TheExp[ i ].SetImage( *ImgMng.getResource( Stream.str() ) );
	}
	if( !pSpieler )
	{
		ExplSD.SetVolume( 60 );
	}
}

/*Ich zeichne die Explosion und animiere sie*/
void Explosion::Render( sf::RenderTarget& Target ) const
{
	if( index >= 0 )
	{
		Target.Draw( TheExp[ index ] );
	}
}

void Explosion::Prozess()
{
	if( ExplSD.GetStatus() != sf::Sound::Playing )
	{
		ExplSD.Play();
	}
	if( Uhr.GetElapsedTime() >= 0.1 )
	{
		Uhr.Reset();
		if( back )
		{
			--index;
		}
		else if( !back && index == 7 )
		{
			++index;
			back = true;
		}
		else if( !back )
		{
			++index;
		}
	}
}

/*Ich liefere den Animationsindex der Explosion zur�ck*/
int Explosion::GetIndex() const
{
	return index;
}