#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <sstream>
#include <SFML/Audio.hpp>

#include "Ship.h"
#include "DivingEnemy.h"
#include "FlyingEnemy.h"
#include "Weapons.h"
#include "PlayerBomb.h"
#include "PlayerMissile.h"
#include "Explosion.h"
#include "Torpedo.h"
#include "Bombe.h"
#include "Wolke.h"
#include "Splash.h"
#include "ImageManager.h"
#include "FontManager.h"

void AddExplosion( const sf::Vector2f& pPosition, bool pSpieler );
void AddTorpedo( const sf::Vector2f& pPosition, const sf::Vector2f& pTempo = sf::Vector2f( 0.999, 1.02 ) );
void AddBombe( const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung );
void Reset( std::vector<DivingEnemy>& ESvec, std::vector<FlyingEnemy>& EFvec, std::vector<PlayerBomb>& PBvec,
		   std::vector<PlayerMissile>& PMvec, std::vector<Splash>& Svec, sf::Clock& U1, sf::Clock& U2,
		   std::vector<Wolke>& Wolken, Ship& Ship );

ImageManager ImgMng;
FontManager FntMng;

sf::SoundBuffer Explosion::Expl;
sf::SoundBuffer Splash::Spl;

int Score = 0;
int lives = 5;
unsigned int DeadShips = 0;
unsigned int DeadFlys = 0;
unsigned int Spielzeit = 0;
const int Strafe = 20;
const unsigned int BantimeRakete = 3;
const unsigned char BanAnzahlRakete = 1;
const float BanFrequenceRakete = 0.4;
const unsigned int BantimeBombe = 3;
const unsigned char BanAnzahlBombe = 1;
const float BanFrequenceBombe = 0.4;
float ShipPosX;

std::vector< Explosion > Explosionen;
std::vector< Torpedo > Torpedos;
std::vector< Bombe > Bomben;
sf::Vector2f Screen;

/* Dieses Programm stellt eine Simulation des Spieles "SubHunt" dar. Es ist ein Beitrag
   zum Contest der deutschen SFML-Community. (Programmiert by Dennis Marschner aka Shisu)
   
   Verbesserungen:	Wolken�hnliches f�r Unterwasser?
					Aufsteigende Punktzahlen?
					Sounds im Allgemeinen
					Alle Zahlen klein halten! (Int zu Char oder unsigned)*/
int main()
{
	Screen.x = 1024;
	Screen.y = 768;
	sf::RenderWindow App( sf::VideoMode( 1024, 768, 32 ), "SubHunt by Dennis Marschner", sf::Style::Fullscreen );
	App.UseVerticalSync( true );
	sf::SoundBuffer Fail_1;
	Fail_1.LoadFromFile( "Sounds/fail1.wav" );
	sf::Sound Fail_1SD( Fail_1 );
	Explosion::LoadSound();
	Splash::LoadSound();
	sf::Sprite Hintergrund( *ImgMng.getResource( "Pictures/Hintergrund.png" ) );
	sf::Sprite ScoreSP( *ImgMng.getResource( "Pictures/Score.png" ) );
	ScoreSP.SetPosition( 890, 735 );
	sf::Sprite Lives[ 5 ];
	for( short i = 0; i < 5; ++i )
	{
		Lives[ i ].SetImage( *ImgMng.getResource( "Pictures/Leben.png" ) );
		Lives[ i ].SetPosition( 850 - ( i * 20 ), 740 );
	}
	sf::Sprite Speed[ 4 ];
	for( short i = 0; i < 4; ++i )
	{
		Speed[ i ].SetImage( *ImgMng.getResource( "Pictures/Speed.png" ) );
		Speed[ i ].SetPosition( 745 - ( i * 20 ), 740 );
	}

	//sf::Font Font_1;
	//Font_1.LoadFromFile( "Fonts/Pocket.ttf" );
	//sf::Font Font_2;
	//Font_2.LoadFromFile( "Fonts/Walshes.ttf" );
	sf::String ScoreST( "", *FntMng.getResource("Fonts/Pocket.ttf"), 22 );
	ScoreST.SetPosition( 892, 731 );

	Ship newShip( sf::Vector2f( ( Screen.x / 2 ) - 55, ( Screen.y / 2 ) - 16 ) );

	std::vector< Wolke > Wolken;
	std::vector< DivingEnemy > AllDivingEnemys;
	std::vector< FlyingEnemy > AllFlyingEnemys;
	std::vector< PlayerBomb > PlayerBombs;
	std::vector< PlayerMissile > PlayerMissiles;
	std::vector< Splash > Splashes;

	sf::Clock Uhr;
	sf::Clock GesUhr;
Anfang:;
	{
		sf::Sprite KeysSP( *ImgMng.getResource("Pictures/Keys.png") );
		sf::Sprite BereitSP( *ImgMng.getResource("Pictures/Begin.png") );
		sf::Sprite LinieSP_1( *ImgMng.getResource("Pictures/Linie.png") );
		sf::Sprite LinieSP_2( *ImgMng.getResource("Pictures/Linie.png") );
		sf::Sprite ZahlenSP[ 3 ];
		ZahlenSP[ 0 ].SetImage( *ImgMng.getResource("Pictures/Countdown_3.png") );
		ZahlenSP[ 1 ].SetImage( *ImgMng.getResource("Pictures/Countdown_2.png") );
		ZahlenSP[ 2 ].SetImage( *ImgMng.getResource("Pictures/Countdown_1.png") );
		LinieSP_1.SetPosition( 0, newShip.GetPosition().y - 40 );
		LinieSP_2.SetPosition( 0, newShip.GetPosition().y + 70 );
		KeysSP.SetPosition( 50, 550 );
		BereitSP.SetPosition( sf::Vector2f( ( Screen.x / 2 ) - ( ImgMng.getResource("Pictures/Begin.png")->GetWidth() / 2 ), 100 ) );
		for( short i = 0; i < 3; ++i )
		{
			ZahlenSP[ i ].SetPosition( sf::Vector2f( ( Screen.x / 2 ) - ( ImgMng.getResource("Pictures/Countdown_3.png")->GetWidth() / 2 ), 220 ) );
		}
		sf::Clock Schalteruhr;
		bool Schalter = false;
		while( App.IsOpened() && GesUhr.GetElapsedTime() < 8 )
		{
			sf::Event Event;
			while( App.GetEvent( Event ) )
			{
				if( ( Event.Type == sf::Event::Closed ) || ( ( Event.Type == sf::Event::KeyPressed ) && ( Event.Text.Unicode == sf::Key::Escape ) ) )
				{
					App.Close();
				}
			}
			App.Clear( sf::Color::Blue );
			App.Draw( Hintergrund );
			App.Draw( newShip );
			if( GesUhr.GetElapsedTime() < 5 )
			{	}
			else if( GesUhr.GetElapsedTime() < 6 )
			{
				App.Draw( ZahlenSP[ 0 ] );
			}
			else if( GesUhr.GetElapsedTime() < 7 )
			{
				App.Draw( ZahlenSP[ 1 ] );
			}
			else if( GesUhr.GetElapsedTime() < 8 )
			{
				App.Draw( ZahlenSP[ 2 ] );
			}
			App.Draw( BereitSP );
			if( Schalteruhr.GetElapsedTime() > 0.35 )
			{
				Schalter = !Schalter;
				Schalteruhr.Reset();
			}
			if(Schalter)
			{
				App.Draw( LinieSP_1 );
				App.Draw( LinieSP_2 );
			}
			App.Draw( KeysSP );
			App.Display();
		}
	}
	//return (0);
	sf::Clock *BanUhrBombe = 0, *BanUhrRakete = 0;
	sf::Clock FrequenzUhrBombe, FrequenzUhrRakete;
	char CounterBombe = 0, CounterRakete = 0;
	bool WriteLadehemmungRakete = false;
	bool WriteLadehemmungBombe = false;
	sf::String LadehemmungRakete("Ladehemmung! Du schie�t zu schnell!", *FntMng.getResource("Fonts/Pocket.ttf"), 30);
	sf::String LadehemmungBombe("Ladehemmung! Du schie�t zu schnell!", *FntMng.getResource("Fonts/Pocket.ttf"), 30);
	LadehemmungRakete.SetColor(sf::Color(255, 0, 0));
	LadehemmungBombe.SetColor(sf::Color(255, 0, 0));
	LadehemmungRakete.SetPosition(5, 5);
	LadehemmungBombe.SetPosition(5, 700);
	GesUhr.Reset();
	std::ostringstream Stringstream;
	sf::Event Event;
	char BoostCounter = 0;

	while( App.IsOpened() )
	{
		while( App.IsOpened() && lives > 0 )
		{
			while ( App.GetEvent( Event ) )
			{
				switch ( Event.Type )
				{
				case sf::Event::Closed:
					{
						App.Close();
						break;
					}
				case sf::Event::MouseButtonPressed:
					{
						::Score -= Strafe;
						if( App.GetInput().GetMouseY() > ( Screen.y / 2 ) + 40 )
						{
							if( FrequenzUhrBombe.GetElapsedTime() < BanFrequenceBombe && CounterBombe < BanAnzahlBombe && BanUhrBombe == 0 )
							{
								PlayerBombs.push_back( PlayerBomb( sf::Vector2f( newShip.GetPosition().x + ( newShip.GetBreite() / 2 ) - ( ImgMng.getResource( "Pictures/PlayerBomb.png" )->GetWidth() / 2 ), newShip.GetPosition().y + 20 )
									, sf::Vector2f( 0, 40 ), sf::Vector2f( 0, 1.003 ) ) );
								++CounterBombe;
								FrequenzUhrBombe.Reset();
							}
							else if( FrequenzUhrBombe.GetElapsedTime() > BanFrequenceBombe && CounterBombe < BanAnzahlBombe && BanUhrBombe == 0 )
							{
								PlayerBombs.push_back( PlayerBomb( sf::Vector2f( newShip.GetPosition().x + ( newShip.GetBreite() / 2 ) - ( ImgMng.getResource( "Pictures/PlayerBomb.png" )->GetWidth() / 2 ), newShip.GetPosition().y + 20 )
									, sf::Vector2f( 0, 40 ), sf::Vector2f( 0, 1.003 ) ) );
								CounterBombe = 0;
								FrequenzUhrBombe.Reset();
							}
							else if( FrequenzUhrBombe.GetElapsedTime() < BanFrequenceBombe && CounterBombe >= BanAnzahlBombe && BanUhrBombe == 0 )
							{
								::Score += Strafe;
								BanUhrBombe = new sf::Clock;
								WriteLadehemmungBombe = true;
								CounterBombe = 0;
								Fail_1SD.Play();
							}
							else if( BanUhrBombe != 0 && BanUhrBombe->GetElapsedTime() < BantimeBombe )
							{
								::Score += Strafe;
								WriteLadehemmungBombe = true;
								Fail_1SD.Play();
							}
							else
							{
								delete BanUhrBombe;
								BanUhrBombe = 0;
								CounterBombe = 0;
								WriteLadehemmungBombe = false;
							}
						}
						else if( App.GetInput().GetMouseY() < ( Screen.y / 2 ) - 70 )
						{
							if( FrequenzUhrRakete.GetElapsedTime() < BanFrequenceRakete && CounterRakete < BanAnzahlRakete && BanUhrRakete == 0 )
							{
								PlayerMissiles.push_back( PlayerMissile( sf::Vector2f( newShip.GetPosition().x + ( newShip.GetBreite() / 2 ) - ( ImgMng.getResource( "Pictures/PlayerMissile.png" )->GetWidth() / 2 ), newShip.GetPosition().y )
									, sf::Vector2f( 0, -40 ), sf::Vector2f( 0, 1.003 ) ) );
								++CounterRakete;
								FrequenzUhrRakete.Reset();
							}
							else if( FrequenzUhrRakete.GetElapsedTime() > BanFrequenceRakete && CounterRakete < BanAnzahlRakete && BanUhrRakete == 0 )
							{
								PlayerMissiles.push_back( PlayerMissile( sf::Vector2f( newShip.GetPosition().x + ( newShip.GetBreite() / 2 ) - ( ImgMng.getResource( "Pictures/PlayerMissile.png" )->GetWidth() / 2 ), newShip.GetPosition().y )
									, sf::Vector2f( 0, -40 ), sf::Vector2f( 0, 1.003 ) ) );
								CounterRakete = 0;
								FrequenzUhrRakete.Reset();
							}
							else if( FrequenzUhrRakete.GetElapsedTime() < BanFrequenceRakete && CounterRakete >= BanAnzahlRakete && BanUhrRakete == 0 )
							{
								::Score += Strafe;
								BanUhrRakete = new sf::Clock;
								WriteLadehemmungRakete = true;
								CounterRakete = 0;
								Fail_1SD.Play();
							}
							else if( BanUhrRakete != 0 && BanUhrRakete->GetElapsedTime() < BantimeRakete )
							{
								::Score += Strafe;
								WriteLadehemmungRakete = true;
								Fail_1SD.Play();
							}
							else
							{
								delete BanUhrRakete;
								BanUhrRakete = 0;
								CounterRakete = 0;
								WriteLadehemmungRakete = false;
							}
						}
						break;
					}
				case sf::Event::MouseMoved:
					{
						break;
					}
				case sf::Event::KeyPressed:
					{
						if( Event.Text.Unicode == sf::Key::Space )
						{
							if( BoostCounter < 4 )
							{
								newShip.StarteBonustempo();
								Score -= 100;
								BoostCounter++;
							}
							else
							{
								Fail_1SD.Play();
							}
						}
						if( Event.Text.Unicode == sf::Key::Escape )
						{
							App.Close();
						}
						break;
					}
				}
			}

			
			if( BanUhrRakete != 0 && BanUhrRakete->GetElapsedTime() >= BantimeRakete )
			{
				delete BanUhrRakete;
				BanUhrRakete = 0;
				CounterRakete = 0;
				WriteLadehemmungRakete = false;
				FrequenzUhrRakete.Reset();
			}
			if( BanUhrBombe != 0 && BanUhrBombe->GetElapsedTime() >= BantimeBombe )
			{
				delete BanUhrBombe;
				BanUhrBombe = 0;
				CounterBombe = 0;
				WriteLadehemmungBombe = false;
				FrequenzUhrBombe.Reset();
			}
			
			if( ( GesUhr.GetElapsedTime() > 5 ) && ( Wolken.empty() ) )
			{
				Wolken.push_back( Wolke( sf::Vector2f( -20, newShip.GetPosition().y ), 1 ) );
			}

			if( ( GesUhr.GetElapsedTime() > 50 ) && ( Wolken.size() == 1 ) )
			{
				Wolken.push_back( Wolke( sf::Vector2f( -20, newShip.GetPosition().y ), 2 ) );
			}

			if( ( GesUhr.GetElapsedTime() > 130 ) && ( Wolken.size() == 2 ) )
			{
				Wolken.push_back( Wolke( sf::Vector2f( -20, newShip.GetPosition().y ), 3 ) );
			}

			Stringstream.str( "" );
			Stringstream<<Score;
			ScoreST.SetText( Stringstream.str() );

			/* Im Folgenden wird (0.I) alle 0,5 Sekunden gepr�ft, ob (1) 150 Sekunden vergangen sind. Ist dies der Fall, werden
			   Schiffe & Flugzeuge immer dann (2) Hergestellt, wenn (3) eine Zufallszahl zwischen 0 und 4 eins ist.
			   Ist die Zeit (0.II) kleiner als 70, so wird in einer (4) von der Zeit abh�ngigen Formel die Chance berechnet und dann
			   erst (5) ein Schiff bzw. Flugzeug hergestellt.*/
			if( Uhr.GetElapsedTime() >= 0.5 )	// (0.I)
			{
				Uhr.Reset();
				if( GesUhr.GetElapsedTime() >= 200 )
				{
					if( sf::Randomizer::Random( 0, 3 ) == 1 )	// (3)
					{
						AllDivingEnemys.push_back( DivingEnemy( sf::Randomizer::Random( 50, 120 ), sf::Randomizer::Random( 0, 1 ), sf::Randomizer::Random( ( int )( Screen.y / 2 ) + 50, ( int )Screen.y - 40 ) ) );	// (2)
					}
					if( sf::Randomizer::Random( 0, 3 ) == 1 )	// (3)
					{
						AllFlyingEnemys.push_back( FlyingEnemy( sf::Randomizer::Random( 50, 120 ), sf::Randomizer::Random( 0, 1 ), sf::Randomizer::Random( 40, ( int )( Screen.y / 2 ) - 50 ), true ) );	// (2)
					}
				}
				else if( GesUhr.GetElapsedTime() >= 150 )	// (1)
				{
					if( sf::Randomizer::Random( 0, 3 ) == 1 )	// (3)
					{
						AllDivingEnemys.push_back( DivingEnemy( sf::Randomizer::Random( 50, 120 ), sf::Randomizer::Random( 0, 1 ), sf::Randomizer::Random( ( int )( Screen.y / 2 ) + 50, ( int )Screen.y - 40 ) ) );	// (2)
					}
					if( sf::Randomizer::Random( 0, 3 ) == 1 )	// (3)
					{
						AllFlyingEnemys.push_back( FlyingEnemy( sf::Randomizer::Random( 50, 120 ), sf::Randomizer::Random( 0, 1 ), sf::Randomizer::Random( 40, ( int )( Screen.y / 2 ) - 50 ) ) );	// (2)
					}
				}
				else	// (0.II)
				{
					if( (sf::Randomizer::Random( 0, ( int )( 160 - GesUhr.GetElapsedTime() ) / 4 ) == 1) || (AllDivingEnemys.empty() && AllFlyingEnemys.empty()) )	// (4)
					{
						AllDivingEnemys.push_back( DivingEnemy( sf::Randomizer::Random( 50, 120 ), sf::Randomizer::Random( 0, 1 ), sf::Randomizer::Random( ( int )( Screen.y / 2 ) + 50, ( int )Screen.y - 40 ) ) );	// (5)
					}
					if( (sf::Randomizer::Random(0, ( int )( 160 - GesUhr.GetElapsedTime() ) / 4 ) == 1) || (AllDivingEnemys.empty() && AllFlyingEnemys.empty()) )	// (4)
					{
						AllFlyingEnemys.push_back( FlyingEnemy( sf::Randomizer::Random( 50, 120 ), sf::Randomizer::Random( 0, 1 ), sf::Randomizer::Random( 40, ( int )( Screen.y / 2 ) - 50 ) ) );	// (5)
					}
				}
			}

			/* Im Folgenden wird die Liste aller PlayerBombs und PlayerMissiles (0) durchlaufen und (1) bewegt sowie
			   (3) gel�scht.*/
			for( unsigned int i = 0; i < PlayerBombs.size(); i++ )	// (0)
			{
				PlayerBombs[ i ].Drift( App.GetFrameTime() );	// (1)
				if( !( PlayerBombs[ i ].flying( App.GetHeight() ) ) )
				{
					PlayerBombs.erase( PlayerBombs.begin() + i );	// (3)
					i--;
				}
			}
			for( unsigned int i = 0; i < PlayerMissiles.size(); i++ )	// (0)
			{
				PlayerMissiles[ i ].Drift( App.GetFrameTime() );	// (1)
				if( !( PlayerMissiles[ i ].flying() ) )
				{
					PlayerMissiles.erase( PlayerMissiles.begin() + i );	// (3)
					i--;
				}
			}

			App.Clear( sf::Color::Blue );

			/* Im Folgenden werden alle Zeichenbaren Elemente (0) durchiteriert und dann jeweils (1) bewegt und (2) gezeichnet.*/
			App.Draw( Hintergrund );
			for( std::vector<Bombe>::iterator it = Bomben.begin(); it != Bomben.end(); ++it )	// (0)
			{
				it->Drift( App.GetFrameTime() );	// (1)
				if( it->GetPosition().y >= ( Screen.y / 2) - 10)
				{
					if( it->GetPosition().x < newShip.GetPosition().x + newShip.GetBreite()
						&& it->GetPosition().x + it->GetBreite() > newShip.GetPosition().x )
					{
						::AddExplosion( sf::Vector2f( newShip.GetPosition().x - 15, newShip.GetPosition().y ), true );
						--::lives;
					}
					else
					{
						Splashes.push_back( Splash( sf::Vector2f( it->GetPosition().x - 40, newShip.GetPosition().y - 30 ) ) );
					}
					Bomben.erase( it );
					break;
				}
				App.Draw( *it );	// (2)
			}
			for( std::vector< Torpedo >::iterator it = Torpedos.begin(); it != Torpedos.end(); ++it )	// (0)
			{
				it->Drift( App.GetFrameTime() );	// (1)
				if( ( it->GetPosition().y <= ( Screen.y / 2 ) + 20 && ( it->GetTempo() < 0 ) )
					|| ( it->GetPosition().y <= ( Screen.y / 2 + 40 ) && ( it->GetTempo() > 0 ) ) )
				{
					if( it->GetPosition().x < newShip.GetPosition().x + newShip.GetBreite()
						&& it->GetPosition().x + it->GetHoehe() > newShip.GetPosition().x )
					{
						::AddExplosion( sf::Vector2f( newShip.GetPosition().x - 15, newShip.GetPosition().y ), true );
						--::lives;
					}
					else
					{
						Splashes.push_back( Splash( sf::Vector2f( it->GetPosition().x - 48, newShip.GetPosition().y - 30 ) ) );
					}
					Torpedos.erase( it );
					break;
				}
				it->Prozess();
				App.Draw( *it );	// (2)
			}
			for( std::vector< PlayerBomb >::iterator it = PlayerBombs.begin(); it != PlayerBombs.end(); ++it )	// (0)
			{
				int temp = it->Getroffen( AllDivingEnemys, AllDivingEnemys.size() );
				if( temp > -1 )
				{
					::AddExplosion( AllDivingEnemys[ temp ].GetPosition(), false );
					if( ( AllDivingEnemys[ temp ].GetPosition().y) >= ( ( Screen.y / 6 ) * 5) )
					{
						::Score += 120;
					}
					else
					{
						::Score += 80;
					}
					AllDivingEnemys.erase( AllDivingEnemys.begin() + temp );
					++DeadShips;
					PlayerBombs.erase( it );
					break;
				}
				App.Draw( *it );	// (2)
			}
			for( std::vector< PlayerMissile >::iterator it = PlayerMissiles.begin(); it != PlayerMissiles.end(); ++it )	// (0)
			{
				int temp = it->Getroffen( AllFlyingEnemys, AllFlyingEnemys.size() );
				if( temp > -1 )
				{
					::AddExplosion( AllFlyingEnemys[ temp ].GetPosition(), false );
					if( ( AllFlyingEnemys[ temp ].GetPosition().y ) <= ( Screen.y / 6 ) )
					{
						::Score += 120;
					}
					else
					{
						::Score += 80;
					}
					AllFlyingEnemys.erase( AllFlyingEnemys.begin() + temp );
					++DeadFlys;
					PlayerMissiles.erase( it );
					break;
				}
				App.Draw( *it );	// (2)
			}
			for( std::vector< DivingEnemy >::iterator it = AllDivingEnemys.begin(); it != AllDivingEnemys.end(); ++it )	// (0)
			{
				it->Drift( App.GetFrameTime() );	// (1)
				App.Draw( *it );	// (2)
			}
			for( std::vector< FlyingEnemy >::iterator it = AllFlyingEnemys.begin(); it != AllFlyingEnemys.end(); ++it )	// (0)
			{
				it->Drift( App.GetFrameTime() );	// (1)
				App.Draw( *it );	// (2)
			}
			for( std::vector< DivingEnemy >::iterator it = AllDivingEnemys.begin(); it != AllDivingEnemys.end(); ++it )	// (0)
			{
				if( it->GetPosition().x < -150 || it->GetPosition().x > 1200 )
				{
					AllDivingEnemys.erase( it );
					break;
				}
			}
			for( std::vector< FlyingEnemy >::iterator it = AllFlyingEnemys.begin(); it != AllFlyingEnemys.end(); ++it )	// (0)
			{
				if( it->GetPosition().x < -150 || it->GetPosition().x > 1200 )
				{
					AllFlyingEnemys.erase( it );
					break;
				}
			}
			newShip.Drift( App.GetInput().GetMouseX(), App.GetFrameTime() );	// (1)
			for( unsigned int i = 0; i < Splashes.size(); ++i )
			{
				if( Splashes[ i ].GetIndex() == 7 && !Splashes[ i ].Playing() )
				{
					Splashes.erase( Splashes.begin() + i );
				}
				else
				{
					Splashes[ i ].Prozess();
					App.Draw( Splashes[ i ] );
				}
			}
			App.Draw( newShip );
			for( unsigned int i = 0; i < Explosionen.size(); ++i )	// (0)
			{
				if( Explosionen[ i ].GetIndex() == ( -1 ) )
				{
					Explosionen.erase( Explosionen.begin() + i );
					if( i >= 0 )
					{
						--i;
						continue;
					}
				}
				Explosionen[ i ].Prozess();
				App.Draw( Explosionen[ i ] );	// (2)
			}
			for(std::vector< Wolke >::iterator it = Wolken.begin(); it != Wolken.end(); ++it)
			{
				it->Drift( App.GetFrameTime() );
			}
			
			App.Draw( ScoreSP );
			App.Draw( ScoreST );
			if( lives > 0 )
			{
				for( unsigned char i = 0; i < lives; ++i )
				{
					App.Draw( Lives[ i ] );
				}
			}
			if( 4 - BoostCounter > 0 )
			{
				for( unsigned char i = BoostCounter; i < 4; ++i )
				{
					App.Draw( Speed[ i ] );
				}
			}
			for( std::vector< Wolke >::iterator it = Wolken.begin(); it != Wolken.end(); ++it )
			{
				App.Draw( *it );
			}
			if( WriteLadehemmungRakete )
			{
				App.Draw( LadehemmungRakete );
			}
			if( WriteLadehemmungBombe )
			{
				App.Draw( LadehemmungBombe );
			}
			App.Display();
		}
		if( BanUhrRakete != 0 )
		{
			delete BanUhrRakete;
			BanUhrRakete = 0;
		}
		if( BanUhrBombe != 0 )
		{
			delete BanUhrBombe;
			BanUhrRakete = 0;
		}
		Spielzeit = GesUhr.GetElapsedTime();

		bool Goon = false;
		sf::Image EndIMG;
		EndIMG.LoadFromFile( "Pictures/Ende.png" );
		sf::Sprite End( EndIMG );
		sf::String GameOver( "GAME OVER", *FntMng.getResource("Fonts/Walshes.ttf"), 70 );
		GameOver.SetPosition( 400, 30 );
		std::ostringstream Stream;
		unsigned int Sekunden = Spielzeit % 60;
		Spielzeit -= Sekunden;
		unsigned int Minuten = Spielzeit / 60;
		Stream<<Minuten<<" Minuten,\n"<<Sekunden<<" Sekunden";
		sf::String Zeit( Stream.str(), *FntMng.getResource("Fonts/Walshes.ttf"), 40 );
		Zeit.SetPosition( 250, 150 );
		Stream.str( "" );
		Stream<<( DeadFlys + DeadShips )<<" besiegte Gegner";
		sf::String Enemys( Stream.str(), *FntMng.getResource("Fonts/Walshes.ttf"), 40 );
		Enemys.SetPosition( 250, 280 );
		Stream.str( "" );
		Stream<<Score<<" Punkte";
		sf::String MyScore( Stream.str(), *FntMng.getResource("Fonts/Walshes.ttf"), 55 );
		MyScore.SetPosition( 250, 400 );
		sf::String Weiter( "Press 'Enter' to replay, press 'ESC' to quit", *FntMng.getResource("Fonts/Walshes.ttf"), 32 );
		Weiter.SetPosition( 90, 650 );
		
		sf::Event Event;
		while( App.IsOpened() && !Goon )
		{
			while( App.GetEvent( Event ) )
			{
				switch( Event.Type )
				{
				case sf::Event::Closed:
					{
						App.Close();
						break;
					}
				case sf::Event::KeyPressed:
					{
						if( Event.Text.Unicode == sf::Key::Return )
						{
							Goon = true;
						}
						if( Event.Text.Unicode == sf::Key::Escape )
						{
							App.Close();
						}
					}
				}
			}
			// Bildschirm darstellen. Bei einem "nein": App.Close();
			// Bei einem "ja": Reset(); und Goon = true;
			App.Clear();
			App.Draw( End );
			App.Draw( GameOver );
			App.Draw( Zeit );
			App.Draw( Enemys );
			App.Draw( MyScore );
			App.Draw( Weiter );
			App.Display();
		}
		::Reset( AllDivingEnemys, AllFlyingEnemys, PlayerBombs, PlayerMissiles, Splashes, Uhr, GesUhr,
			Wolken, newShip );
		goto Anfang;
	}

	return (0);
}

void AddBombe( const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung )
{
	Bomben.push_back( Bombe( pPosition, pTempo, pBeschleunigung ) );
}

void AddExplosion( const sf::Vector2f& pPosition, bool pSpieler )
{
	Explosionen.push_back( Explosion( sf::Vector2f( pPosition.x - 40, pPosition.y - 34 ), pSpieler ) );
}

void AddTorpedo( const sf::Vector2f& pPosition, const sf::Vector2f& pTempo )
{
	Torpedos.push_back( Torpedo( sf::Vector2f( pPosition.x + 40, pPosition.y + 10 ), pTempo, sf::Vector2f( 0.999, 1.02 ) ) );
}

void Reset( std::vector<DivingEnemy>& ESvec, std::vector<FlyingEnemy>& EFvec, std::vector<PlayerBomb>& PBvec,
		   std::vector<PlayerMissile>& PMvec, std::vector<Splash>& Svec, sf::Clock& U1, sf::Clock& U2,
		   std::vector<Wolke>& Wolken, Ship& Ship )
{
	Score = 0;
	lives = 5;
	DeadShips = 0;
	DeadFlys = 0;
	Spielzeit = 0;
	while( !ESvec.empty() )
	{
		ESvec.pop_back();
	}
	while( !EFvec.empty() )
	{
		EFvec.pop_back();
	}
	while( !PBvec.empty() )
	{
		PBvec.pop_back();
	}
	while( !PMvec.empty() )
	{
		PMvec.pop_back();
	}
	while( !Svec.empty() )
	{
		Svec.pop_back();
	}
	while( !Wolken.empty() )
	{
		Wolken.pop_back();
	}
	U1.Reset();
	U2.Reset();
	Ship.SetPosition( sf::Vector2f( ( Screen.x / 2 ) - 55, ( Screen.y / 2 ) - 16 ) );
	while( !Explosionen.empty() )
	{
		Explosionen.pop_back();
	}
	while( !Torpedos.empty() )
	{
		Torpedos.pop_back();
	}
	while( !Bomben.empty() )
	{
		Bomben.pop_back();
	}
}