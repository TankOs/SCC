#include "PlayerMissile.h"
#include "FlyingEnemy.h"
#include "ImageManager.h"

extern ImageManager ImgMng;

/*Ich stelle eine PlayerBomb her*/
PlayerMissile::PlayerMissile( const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung )
	: Weapons( pPosition, pTempo, pBeschleunigung )
{
	TheMissile.SetImage( *ImgMng.getResource("Pictures/PlayerMissile.png") );
}

/*Ich sage aus, ob die PlayerBomb sich noch im Spielfeld befindet*/
bool PlayerMissile::flying() const
{
	if( GetPosition().y >= -30 )
	{
		return true;
	}
	return false;
}

/*Ich zeichne die PlayerBomb*/
void PlayerMissile::Render( sf::RenderTarget& Target ) const
{
	Target.Draw( TheMissile );
}

/*Ich gebe die Breite einer PlayerBomb zur�ck*/
int PlayerMissile::GetBreite() const
{
	return ImgMng.getResource("Pictures/PlayerMissile.png")->GetWidth();
}

/*Ich gebe den Ort (Index) des Flugzeugeuges aus, das ich treffe. Wenn ich nichts treffe, dann gebe ich -1 zur�ck.*/
int PlayerMissile::Getroffen(std::vector<FlyingEnemy> pZiele, int pLaenge)
{
	sf::Rect<int> Rechteck( GetPosition().x, GetPosition().y,
		GetPosition().x + ImgMng.getResource("Pictures/PlayerMissile.png")->GetWidth(), GetPosition().y + ImgMng.getResource("Pictures/PlayerMissile.png")->GetHeight() );
	for( int i = 0; i < pLaenge; ++i )
	{
		if( pZiele[i].Getroffen( Rechteck ) )
		{
			return i;
		}
	}
	return -1;
}

sf::Vector2f PlayerMissile::GetSize()
{
	return sf::Vector2f(ImgMng.getResource("Pictures/PlayerMissile.png")->GetWidth(), ImgMng.getResource("Pictures/PlayerMissile.png")->GetHeight());
}