#include "Einheit.h"

/*Ich stelle eine Einheit her*/
Einheit::Einheit( const sf::Vector2f& pPosition )
{
	Move( pPosition );
}

/*Ich gebe aus, ob sich die einheit noch im Bildschirm befindet*/
bool Einheit::InBildschirm() const
{
	if( GetPosition().x < ( -100 ) || GetPosition().x > ( 1100 ) )
	{
		return false;
	}
	return true;
}