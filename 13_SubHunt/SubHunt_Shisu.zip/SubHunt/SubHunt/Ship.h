#ifndef SHIP_H
#define SHIP_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

#include "Einheit.h"

/*Ich bin das Ship, d.h. das Schiff des Spielers*/
class Ship : public Einheit
{
private:
	sf::Clock* BonusUhr;
	void Render(sf::RenderTarget& Target) const;
	static const int NormalTempo = 120;
	static const int BonusTempo = 300;
	static const int Bonusdauer = 5;
public:
	Ship(const sf::Vector2f& pPosition);
	void Drift(double pPos, double pFaktor);
	void StarteBonustempo();
	int GetBreite() const;
};

#endif