#ifndef EXPL_H
#define EXPL_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

class Explosion : public sf::Drawable
{
private:
	void Render(sf::RenderTarget& Target) const;
	sf::Clock Uhr;
	sf::Sprite TheExp[9];
	bool back;
	char index;
	sf::Sound ExplSD;
	static sf::SoundBuffer Expl;
public:
	static void LoadSound()
	{
		Explosion::Expl.LoadFromFile("Sounds/explosion.wav");
	}
	void Prozess();
	Explosion(const sf::Vector2f& pPosition, bool pSpieler = false);
	int GetIndex() const;
};

#endif