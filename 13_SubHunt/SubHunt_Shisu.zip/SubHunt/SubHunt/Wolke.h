#ifndef WOLKE_H
#define WOLKE_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

class Wolke : public sf::Drawable
{
private:
	sf::Sprite WolkeSP;
	int Tempo;
	unsigned int Wait;
	sf::Clock Uhr;
	sf::Vector2f Flugraum;
	std::string Index;

	void Render(sf::RenderTarget& Target) const;
public:
	Wolke(sf::Vector2f pFlugraum, int index);
	void Drift(double pFaktor);
	bool Outside();
};

#endif