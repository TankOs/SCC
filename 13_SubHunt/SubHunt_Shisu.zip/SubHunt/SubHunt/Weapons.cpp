#include "Weapons.h"

/*Ich stelle eine Weapons her*/
Weapons::Weapons( const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung )
	: Tempo( pTempo ), Beschleunigung( pBeschleunigung )
{
	Move( pPosition );
}

/*Ich bewege die Weapons*/
void Weapons::Drift( double pFaktor )
{
	Tempo.x *= Beschleunigung.x;
	Tempo.y *= Beschleunigung.y;
	Move( Tempo.x * pFaktor, Tempo.y * pFaktor );
}