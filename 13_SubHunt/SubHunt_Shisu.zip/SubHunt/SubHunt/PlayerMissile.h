#ifndef PLM_H
#define PLM_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

#include "Weapons.h"

class FlyingEnemy;

/*Ich bin die PlayerMittile, d.h. die Rakete, die der Spieler in die Luft feuert*/
class PlayerMissile : public Weapons
{
private:
	sf::Vector2f Tempo;
	sf::Vector2f Beschleunigung;
	sf::Sprite TheMissile;
	void Render(sf::RenderTarget& Target) const;
public:
	sf::Vector2f GetSize();
	PlayerMissile(const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung);
	bool flying() const;
	int GetBreite() const;
	int Getroffen(std::vector<FlyingEnemy> pZiele, int pLaenge);
};

#endif