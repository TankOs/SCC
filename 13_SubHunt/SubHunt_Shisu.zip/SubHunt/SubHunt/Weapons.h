#ifndef Weapons_H
#define Weapons_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

/*Ich bin die Weapons, d.h. der Vater aller Projektile*/
class Weapons : public sf::Drawable
{
protected:
	sf::Vector2f Tempo;
	sf::Vector2f Beschleunigung;
	virtual void Render(sf::RenderTarget& Target) const = 0;
public:
	Weapons(const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung);
	void Drift(double pFaktor);
	virtual int GetBreite() const =0;
};

#endif