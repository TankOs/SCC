#include <iostream>
#include <cmath>

#include "DivingEnemy.h"
#include "ImageManager.h"

extern ImageManager ImgMng;
extern void AddTorpedo( const sf::Vector2f& pPosition, const sf::Vector2f& pTempo );
extern double ShipPosX;
extern int Score;

/*Ich Bilde das DivingEnemy auf dem Rendertarget ab*/
void DivingEnemy::Render( sf::RenderTarget& Target ) const
{
	Target.Draw( TheShip );
}

/*Ich Konstruiere ein DivingEnemy, d.h. ich bewege es und initialisiere Daten*/
DivingEnemy::DivingEnemy( int pRandTempo, bool pRandSide, int pRandHeigh )
: Einheit( sf::Vector2f( 0, 0 ) ), Abwurfstelle(sf::Randomizer::Random( 200, 824 ) ), Bomb( true )
{
	if( pRandSide )
	{
		SetPosition( -90, pRandHeigh );
		Tempo = pRandTempo;
		TheShip.SetImage( *ImgMng.getResource( "Pictures/DivingEnemy.png" ) );
	}
	else
	{
		SetPosition( 1100, pRandHeigh );
		Tempo = -pRandTempo;
		TheShip.SetImage( *ImgMng.getResource( "Pictures/DivingEnemy_inv.png" ) );
	}
}

/*Ich f�hre die Bewegung des DivingEnemy aus*/
void DivingEnemy::Drift( double pFaktor )
{
	Move( Tempo * pFaktor, 0 );
	if((std::fabs( GetPosition().x - Abwurfstelle ) < 20 && Bomb) )
	{
		if( Tempo<0 )
		{
			::AddTorpedo( GetPosition(), sf::Vector2f( -100, -5 ) );	//Position & Tempo
		}
		else if( Tempo > 0 )
		{
			::AddTorpedo( GetPosition(), sf::Vector2f( 100, -5 ) );	//Position & Tempo
		}
		Bomb = false;
	}
}

/*Ich gebe die Breite des AllDivingEnemys zur�ck*/
int DivingEnemy::GetBreite() const
{
	return ImgMng.getResource( "Pictures/DivingEnemy.png" )->GetWidth();
}

/*Ich gebe zur�ck, ob das �bergebene Rechteck sich mit meinem schneidet*/
bool DivingEnemy::Getroffen( const sf::Rect< int >& pRechteck_2 )
{
	sf::Rect< int > Rechteck( GetPosition().x, GetPosition().y,
		GetPosition().x + ImgMng.getResource( "Pictures/DivingEnemy.png" )->GetWidth(), GetPosition().y + ImgMng.getResource( "Pictures/DivingEnemy.png" )->GetHeight() );
	return Rechteck.Intersects( pRechteck_2 );
}

int DivingEnemy::getTempo() const
{
	return Tempo;
}