#include <cmath>

#include "Torpedo.h"
#include "ImageManager.h"

extern ImageManager ImgMng;

/*Ich stelle einen Torpedo her*/
Torpedo::Torpedo( const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung )
	: Weapons( pPosition, pTempo, pBeschleunigung ), Schalter( false )
{
	if( ( pTempo.x > 0 && pTempo.y > 0 ) || ( pTempo.x < 0 && pTempo.y < 0 ) )
	{
		Counterclockwise = false;
	}
	else if( ( pTempo.x > 0 && pTempo.y < 0 ) || ( pTempo.x < 0 && pTempo.y > 0 ) )
	{
		Counterclockwise = true;
	}
	if( Tempo.x > 0 )
	{
		TheTorp.SetImage( *ImgMng.getResource("Pictures/Torpedo1.png") );
		TheTorp_2.SetImage( *ImgMng.getResource("Pictures/Torpedo2.png") );
	}
	else if( Tempo.x < 0 )
	{
		TheTorp.SetImage( *ImgMng.getResource("Pictures/Torpedo1_inv.png") );
		TheTorp_2.SetImage( *ImgMng.getResource("Pictures/Torpedo2_inv.png") );
	}
	Uhr.Reset();
}

/*Ich zeichne und drehe den Torpedo*/
void Torpedo::Render( sf::RenderTarget& Target ) const
{
	if( Schalter )
	{
		Target.Draw( TheTorp );
	}
	else
	{
		Target.Draw( TheTorp_2 );
	}
}

void Torpedo::Prozess()
{
	if( Counterclockwise )
	{
		if( std::fabs( Tempo.y ) / std::fabs( Tempo.x ) > 1 )
		{
			TheTorp.SetRotation( 90 );
			TheTorp_2.SetRotation( 90 );
		}
		else
		{
			TheTorp.SetRotation( ( ( std::fabs( Tempo.y ) / std::fabs( Tempo.x ) ) * 90 ) );
			TheTorp_2.SetRotation( ( ( std::fabs( Tempo.y ) / std::fabs( Tempo.x ) ) * 90 ) );
		}
	}
	else
	{
		if( std::fabs( Tempo.y ) / std::fabs( Tempo.x ) > 1 )
		{
			TheTorp.SetRotation( -90 );
			TheTorp_2.SetRotation( -90 );
		}
		else
		{
			TheTorp.SetRotation( -( ( std::fabs( Tempo.y ) / std::fabs( Tempo.x ) ) * 90 ) );
			TheTorp_2.SetRotation( -( ( std::fabs( Tempo.y ) / std::fabs( Tempo.x ) ) * 90 ) );
		}
	}

	if( Uhr.GetElapsedTime() >= 0.1 )
	{
		Uhr.Reset();
		Schalter = !Schalter;
	}
}

/*Ich gebe die Breite des Torpedos zur�ck*/
int Torpedo::GetBreite() const
{
	return ImgMng.getResource("Pictures/Torpedo1.png")->GetWidth();
}

/*Ich gebe die H�he des Torpedos zur�ck*/
int Torpedo::GetHoehe() const
{
	return ImgMng.getResource("Pictures/Torpedo1.png")->GetHeight();
}

int Torpedo::GetTempo() const
{
	return Tempo.x;
}