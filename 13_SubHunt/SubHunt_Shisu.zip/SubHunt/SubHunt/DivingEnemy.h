#ifndef ESHIP_H
#define ESHIP_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

#include "Einheit.h"

/*Ich bin das DivingEnemy, d.h. das Schiff des Computers*/
class DivingEnemy : public Einheit
{
private:
	void Render(sf::RenderTarget& Target) const;
public:
	DivingEnemy( int pRandTempo, bool pRandSide, int pRandHeigh );	//random zwischen 100 und 300
	void Drift(double pFaktor);
	bool ImBild(int pScreenwidth) const;
	int GetBreite() const;
	int Abwurfstelle;
	bool Bomb;
	bool Getroffen(const sf::Rect<int>& pRechteck_2);
	int getTempo() const;
};

#endif