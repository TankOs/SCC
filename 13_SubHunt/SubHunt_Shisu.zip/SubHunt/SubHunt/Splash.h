#ifndef SPLASH_H
#define SPLASH_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

class Splash : public sf::Drawable
{
private:
	void Render(sf::RenderTarget& Target) const;
	sf::Clock Uhr;
	sf::Sprite TheSplash[9];
	int index;
	sf::Sound SplashSD;
	static sf::SoundBuffer Spl;
	bool Played;
public:
	static void LoadSound()
	{
		Splash::Spl.LoadFromFile("Sounds/splash.wav");
	}
	void Prozess();
	Splash( const sf::Vector2f& pPosition );
	int GetIndex() const;
	bool Playing() const;
};

#endif