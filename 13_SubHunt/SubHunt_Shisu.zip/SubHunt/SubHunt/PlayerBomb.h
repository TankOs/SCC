#ifndef PLB_H
#define PLB_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

#include "Weapons.h"

class DivingEnemy;

/*Ich bin die PlayerBomb, d.h. die Bombe, die der Spieler ins Wasser sinken l�sst*/
class PlayerBomb : public Weapons
{
private:
	sf::Vector2f Tempo;
	sf::Vector2f Beschleunigung;
	sf::Sprite TheBomb;
	void Render(sf::RenderTarget& Target) const;
public:
	sf::Vector2f GetSize();
	PlayerBomb(const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung);
	bool flying(int pScreenheigh) const;
	int GetBreite() const;
	int Getroffen(std::vector<DivingEnemy> pZiele, int pLaenge);
};

#endif