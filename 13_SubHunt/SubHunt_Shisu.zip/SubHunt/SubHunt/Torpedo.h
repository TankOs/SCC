#ifndef TORP_H
#define TORP_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

#include "Weapons.h"

/*Ich bin ein Torpedo, d.h. eine Rakete eines AllDivingEnemys, das auf das Ship abgefeuert wird*/
class Torpedo : public Weapons
{
private:
	sf::Sprite TheTorp;
	sf::Sprite TheTorp_2;
	sf::Clock Uhr;
	bool Schalter;
	bool Counterclockwise;

	void Render(sf::RenderTarget& Target) const;
public:
	void Prozess();
	Torpedo(const sf::Vector2f& pPosition, const sf::Vector2f& pTempo, const sf::Vector2f& pBeschleunigung);
	int GetBreite() const;
	int GetHoehe() const;
	int GetTempo() const;
};

#endif