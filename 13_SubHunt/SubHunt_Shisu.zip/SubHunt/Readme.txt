 _____        _____ _   _         
| __  |_ _   |   __| |_|_|___ _ _ 
| __ -| | |  |__   |   | |_ -| | |
|_____|_  |  |_____|_|_|_|___|___|
      |___|                       
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Dies ist ein Wettbewerbsbeitrag f�r die deutsche SFML-Community
von Dennis Marschner aka Shisu.


- Steuerung -

Maus bewegen		Das Schiff folgt
Mausklick oben		Rakete feuern
Mausklick unten		Mine werfen
Leertaste		Geschwindigkeits-Bonus (4x Anwendbar)
ESC			Beenden


- Credits -

Code Programmiert von		Dennis Marschner
Grafiken erstellt von		Dennis Marschner
Audiodateien erhalten von	http://www.freesound.org/
Lizenz der Audiodateien		http://creativecommons.org/licenses/sampling+/1.0/
Fonts erhalten von		http://www.dafont.com/
Lizenz der Fonts		Free


- Daten -

Genutzte SFML-Version:		1.6


- Bei Absturz mit Fehlermeldung -

VCredist:			http://www.microsoft.com/downloads/details.aspx?familyid=A5C84275-3B97-4AB7-A40D-3802B2AF5FC2&displaylang=en