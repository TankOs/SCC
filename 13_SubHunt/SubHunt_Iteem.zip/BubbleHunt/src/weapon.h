#ifndef WEAPON_H
#define WEAPON_H

#include <SFML/Graphics.hpp>
#include "enemie.h"

class Weapon : public sf::Drawable
{
    public:
        Weapon(sf::Vector2f Pos);
        ~Weapon(){};
        static bool init(void){return redBubbleImage.LoadFromFile("data/bubble_red.png");};
        void update(float elapsedTime);
        float GetY(void) const {return redBubble.GetPosition().y;};
        bool coolide(const Enemie &enemie) const;
    private:
        virtual void Render(sf::RenderTarget& target, sf::Renderer& renderer) const;
        static sf::Image redBubbleImage;
        sf::Sprite redBubble;
};

#endif // WEAPON_H
