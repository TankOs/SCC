#include "weapon.h"

sf::Image Weapon::redBubbleImage;

const float Speed = 100.f;

Weapon::Weapon(sf::Vector2f Position)
{
    redBubble.SetImage(redBubbleImage);
    redBubble.Resize(15.f, 15.f);
    redBubble.SetPosition(Position);
    redBubble.SetOrigin(redBubbleImage.GetWidth() / 2, redBubbleImage.GetHeight() / 2);
}

bool Weapon::coolide(const Enemie &enemie) const
{
    float x = enemie.GetPos().x - redBubble.GetPosition().x;
    float y = enemie.GetPos().y - redBubble.GetPosition().y;
    return 25*25 > x*x + y*y;
}

void Weapon::update(float elapsedTime)
{
    redBubble.Move(0, Speed * elapsedTime);
}

void Weapon::Render(sf::RenderTarget& target, sf::Renderer& renderer) const
{
    target.Draw(redBubble);
}
