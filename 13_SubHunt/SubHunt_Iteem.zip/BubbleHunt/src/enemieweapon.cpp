#include "enemieweapon.h"

sf::Image EnemieWeapon::orangeBubbleImage;

EnemieWeapon::EnemieWeapon(sf::Vector2f Pos, sf::Vector2f direction) :
myDirection(direction)
{
    orangeBubble.SetImage(orangeBubbleImage);
    orangeBubble.Resize(10.f, 10.f);
    orangeBubble.SetPosition(Pos);
    orangeBubble.SetOrigin(orangeBubbleImage.GetWidth() / 2, orangeBubbleImage.GetHeight() / 2);
}

void EnemieWeapon::Render(sf::RenderTarget& target, sf::Renderer& renderer) const
{
    target.Draw(orangeBubble);
}

void EnemieWeapon::update(float elapsedTime)
{
    orangeBubble.Move(myDirection* elapsedTime);
}

bool EnemieWeapon::coolide(const Player &player) const
{
    float x = player.GetPos().x - orangeBubble.GetPosition().x;
    float y = player.GetPos().y - orangeBubble.GetPosition().y;
    return 42.5*42.5 > x*x + y*y;
}
