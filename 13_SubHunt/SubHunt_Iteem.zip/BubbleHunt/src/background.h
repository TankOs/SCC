#ifndef BACKGROUND_H_INCLUDED
#define BACKGROUND_H_INCLUDED

#include <SFML/Graphics.hpp>

class Background : public sf::Drawable
{
    public:
        Background(void);
        virtual ~Background(void){};
    private:
        virtual void Render(sf::RenderTarget& target, sf::Renderer& renderer) const;
        sf::Shape water;
        sf::Shape sky;
};

#endif // BACKGROUND_H_INCLUDED
