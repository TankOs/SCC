#include "enemie.h"

sf::Image Enemie::bubbleImage;

Enemie::Enemie(float YPosition, float speed, Direction direction)
: mySpeed(speed)
{
    bubble.SetImage(bubbleImage);
    bubble.Resize(40, 40);
    bubble.SetOrigin(bubbleImage.GetWidth() / 2, bubbleImage.GetHeight() / 2);
    if(direction == FromRight)
    {
        bubble.SetX(800);
        mySpeed *= -1;
    }
    else
    {
        bubble.SetX(0);
    }
    bubble.SetY(YPosition);
}

void Enemie::Render(sf::RenderTarget& target, sf::Renderer& renderer) const
{
    target.Draw(bubble);
}

void Enemie::update(float elapsedTime)
{
    bubble.Move(mySpeed * elapsedTime, 0);
}
