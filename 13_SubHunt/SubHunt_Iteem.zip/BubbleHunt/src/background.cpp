#include "background.h"

Background::Background(void)
{
    //create a shape looks like water
    water.AddPoint(  0, 200, sf::Color(112, 141, 220));
    water.AddPoint(800, 200, sf::Color(112, 141, 220));
    water.AddPoint(800, 600, sf::Color( 37,  53, 150));
    water.AddPoint(  0, 600, sf::Color( 37,  53, 150));

    //and one looks like a evening sky
    sky.AddPoint(  0,   0, sf::Color( 22,  13,  18));
    sky.AddPoint(800,   0, sf::Color( 22,  13,  18));
    sky.AddPoint(800, 200, sf::Color(239,  82,  31));
    sky.AddPoint(  0, 200, sf::Color(239,  82,  31));
}

void Background::Render(sf::RenderTarget& target, sf::Renderer& renderer) const
{
    target.Draw(sky);
    target.Draw(water);
}
