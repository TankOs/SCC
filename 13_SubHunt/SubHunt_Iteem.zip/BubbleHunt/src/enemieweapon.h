#ifndef ENEMIEWEAPON_H
#define ENEMIEWEAPON_H

#include <SFML/Graphics.hpp>

#include "player.h"

class EnemieWeapon : public sf::Drawable
{
    public:
        EnemieWeapon(sf::Vector2f Pos, sf::Vector2f direction);
        ~EnemieWeapon(){};
        static bool init(void){return orangeBubbleImage.LoadFromFile("data/bubble_orange.png");};
        void update(float elapsedTime);
        sf::Vector2f GetPos(void) const {return orangeBubble.GetPosition();};
        bool coolide(const Player &player) const;
    private:
        virtual void Render(sf::RenderTarget& target, sf::Renderer& renderer) const;
        static sf::Image orangeBubbleImage;
        sf::Sprite orangeBubble;
        sf::Vector2f myDirection;
};

#endif // ENEMIEWEAPON_H
