#ifndef ENEMIE_H
#define ENEMIE_H

#include <SFML/Graphics.hpp>

enum Direction
{
    FromLeft,
    FromRight
};

class Enemie : public sf::Drawable
{
    public:
        Enemie(float XPosition, float Speed, Direction direction);
        ~Enemie(){};
        void update(float elapsedTime);
        sf::Vector2f GetPos(void) const {return bubble.GetPosition();};
        static bool init(){return bubbleImage.LoadFromFile("data/bubble.png");};
    private:
        virtual void Render(sf::RenderTarget& target, sf::Renderer& renderer) const;
        float mySpeed;
        static sf::Image bubbleImage;
        sf::Sprite bubble;
};

#endif // ENEMIE_H
