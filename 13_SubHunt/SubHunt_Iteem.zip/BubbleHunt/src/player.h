#ifndef PLAYER_H
#define PLAYER_H

#include <SFML/Graphics.hpp>

class Player : public sf::Drawable
{
    public:
        Player();
        ~Player(){};
        void update(float elapsedTime, float mouseX);
        sf::Vector2f GetPos(void) const {return bubble.GetPosition();};
    private:
        virtual void Render(sf::RenderTarget& target, sf::Renderer& renderer) const;
        sf::Image bubbleImage;
        sf::Sprite bubble;
        float timer;
};

#endif // PLAYER_H
