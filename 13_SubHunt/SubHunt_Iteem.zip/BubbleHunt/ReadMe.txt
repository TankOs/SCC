BubbleHunt

Steuerung: Mit der Maus, Linksklick f�r einen Schuss

Eine .exe f�r Windows liegt bei, kann jedoch einfach mit SFML 2
auch selbst kompilert werden(z.B f�r Linux, lief bei mir unter
Ubuntu 10.04 ohne Probleme)

Font ist frei, Rest ist selbst erstellt und darf (miss)braucht
werden.

Iteem(unter Zeitdruck geschrieben ;) )