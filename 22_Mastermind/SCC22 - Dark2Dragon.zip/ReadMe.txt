Master of the Planets
=====================

SFML-Version: 1.6

Steuerung:
Die unteren Planeten k�nnen per Drag & Drop auf die schwarzen L�cher gezogen werden.
Nach dem setzen der ersten Reihe wird die zweite freigeschalten.

Nachdem eine Reihe fertig ist, werden rechts unterschiedlich farbige Punkte angezeigt:

- Rot bedeutet, dass ein richtiger Planet an der falschen Stelle platziert ist
- Wei� bedeutet, dass ein richter Planet an der richtigen Stelle platziert ist


Innerhalb von 10 Runden muss die gesuchte Kombination erraten werden (klassisches Master-Mind).

Planeten k�nnen in einer Reihe nachtr�glich ge�ndert werden, indem ein anderer Planet auf den bereits vorhandenen geschoben wird. Dies ist nur m�glich, solange die Reihe nicht mit vier Planeten gef�llt ist.

Viel Spa� beim testen!

[09.10.2011 / Dark2Dragon]

