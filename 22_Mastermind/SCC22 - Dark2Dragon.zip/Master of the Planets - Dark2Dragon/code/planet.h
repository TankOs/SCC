#include <SFML/Graphics.hpp>

#ifndef PLANET_H
#define PLANET_H


class planet {

private:

	sf::Sprite me;
	
	int Start_xPos;
	int Start_yPos;
	
	int New_xPos;
	int New_yPos;
	
	int gamma;
	bool dragged;
	bool newPos;
	
public:
	planet(sf::Image &myPicture, int xPos, int yPos);
	~planet() {}
	sf::Sprite &getSprite() {return me;}
	void setDrag(bool drag) {dragged = drag;}
	bool isDrag() {return dragged;} 
	bool SlideBack(float FrameTime);
	bool isOnNewPos() {return newPos;}
	void ReturnToPlace(int port, int level, int state);
	void draw(sf::RenderWindow &App) {App.Draw(me);}	
		
private:
	void goBack();

};

#endif