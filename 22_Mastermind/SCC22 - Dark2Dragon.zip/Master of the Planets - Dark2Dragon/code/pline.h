#include <SFML/Graphics.hpp>

#ifndef PLINE_H
#define PLINE_H


class pline {

private:
	const sf::Image &planet1;
	const sf::Image &planet2;
	const sf::Image &planet3;
	const sf::Image &planet4;
	const sf::Image &planet5;
	const sf::Image &planet6;
		
	const sf::Image &pin1;
	const sf::Image &pin2;	

	const sf::Image &default_planet;
	
	sf::Sprite p_sockel_1;
	sf::Sprite p_sockel_2;
	sf::Sprite p_sockel_3;
	sf::Sprite p_sockel_4;
	
	sf::Sprite c_sockel_1;
	sf::Sprite c_sockel_2;
	sf::Sprite c_sockel_3;
	sf::Sprite c_sockel_4;
		
	int slot;
	
public:
	pline(int yPos, sf::Image &p1, sf::Image &p2,sf::Image &p3, sf::Image &p4, sf::Image &p5, sf::Image &p6, sf::Image &pi1, sf::Image &pi2, sf::Image &db);
	~pline() {}
	int checkPlanet(sf::Sprite &planet, int value);
	void setSlot(int new_slot) {slot = new_slot;}
	void setPlanet(int value);
	sf::Sprite &getPlanetSprite(int sockel);
	void showChecked(int *values);
	void draw(sf::RenderWindow &App);
	bool checkCollision(sf::Sprite &Object1, sf::Sprite &Object2);
	void setXpos(int p1_Xpos, int p2_Xpos, int p3_Xpos, int p4_Xpos);
	void pinVisible(int gamma);

private:
	void setPin(int pin_number, int value);
	void setImageP(sf::Sprite &sockel, int value);
	void setImageC(sf::Sprite &sockel, int value);

};

#endif