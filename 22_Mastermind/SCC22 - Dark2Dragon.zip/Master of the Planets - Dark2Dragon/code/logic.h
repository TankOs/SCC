#include <SFML/System.hpp>

#ifndef LOGIC_H
#define LOGIC_H


class logic {

private:
	int soll[4];
	int ist[4];
	
public:
	logic();
	~logic() {}
	void createNew(int difficult);
	void setValue(int pos, int value) {ist[pos-1] = value;}
	bool allSet();
	void check(int *ret);
	int getSoll(int pos) {return soll[pos];} 

};

#endif