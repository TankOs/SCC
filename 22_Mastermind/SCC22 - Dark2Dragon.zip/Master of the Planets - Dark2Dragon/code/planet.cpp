#include "planet.h"

planet::planet(sf::Image &myPicture, int xPos, int yPos)
{
	me.SetImage(myPicture);
	me.SetPosition(xPos, yPos);
	Start_xPos = xPos;
	Start_yPos = yPos;
	gamma = 255;
	dragged = false;
	
	New_xPos = 0;
	New_yPos = 0;
	newPos = false;
}

bool planet::SlideBack(float FrameTime)
{
	int x_move = 0;
	int y_move = 0;
	bool setPlanet = false;
	
	if (dragged == false && (Start_xPos != me.GetPosition().x || Start_yPos != me.GetPosition().y) && newPos == false)
	{	
		if (me.GetPosition().x > Start_xPos)
			x_move = -100*FrameTime;
		if (me.GetPosition().x < Start_xPos)
			x_move = 100*FrameTime;
			
		if (me.GetPosition().y > Start_yPos)
			y_move = -100*FrameTime;
		if (me.GetPosition().y < Start_yPos)
			y_move = 100*FrameTime;

		me.Move(x_move, y_move);
	}
	
	if (newPos == true) 
	{
		if (me.GetPosition().x > New_xPos)
			x_move = -1;
		if (me.GetPosition().x < New_xPos)
			x_move = 1;
			
		if (me.GetPosition().y > New_yPos)
			y_move = -1;
		if (me.GetPosition().y < New_yPos)
			y_move = 1;

		me.Move(x_move, y_move);

		if (me.GetPosition().x == New_xPos && me.GetPosition().y == New_yPos)
		{
			newPos = false;
			goBack();
			setPlanet = true;
		}
	}
		
	// bei Transparenz
	if (gamma < 255)
	{
		gamma=gamma+5;
		me.SetColor(sf::Color(255, 255, 255, gamma));
	}
	
	return setPlanet;
}

void planet::ReturnToPlace(int port, int level, int state)
{
	if (state == 1)
	{
		newPos = true;
		New_xPos = port * 100;				
		New_yPos = (9-level) * 60 + 35;	
	}
}

void planet::goBack()
{
	newPos = false;
	gamma = 0;
	me.SetColor(sf::Color(255, 255, 255, gamma));
	me.SetPosition(Start_xPos, Start_yPos);
}