#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

#ifndef DRAGNDROP_H
#define DRAGNDROP_H


class dragndrop {

private:
	sf::RenderWindow &App;			// App
	sf::Sprite *Object;				// Object
	bool drag;						// drag something?
	
public:
	dragndrop(sf::RenderWindow &window);
	~dragndrop();
	bool MousePressed(sf::Sprite &Obj, bool enable);
	void MouseReleased() {drag = false;}
	void MouseFollow();
	bool DragSomething() {return drag;}

};

#endif