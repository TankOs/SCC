#include <list>
#include <SFML/Graphics.hpp>


#ifndef STARFIELD_H
#define STARFIELD_H


class starfield {

private:
	sf::RenderWindow &App;								// App Zeiger
	std::list<sf::Shape> Stars;		// Sterne
	
public:
	starfield(sf::RenderWindow &window);
	~starfield() {}
	void create();
	void run();
	void draw();

};

#endif