#include "framework.h"


// Konstruktor
framework::framework(sf::RenderWindow &window) : App(window)
{
	ports_enabled = false;	
	state_machine = 0;
	mouse = new dragndrop(App); 
	level = 0;
	difficult = 2;
	dragValue = 0;
	values[0] = 0;
	values[1] = 0;
	values[2] = 0;
	values[3] = 0;
	level_while_set = 0;
	color = 255;
	switch_color = false;
	sfx_enable = true;
	music_enable = true;
	show_help = false;
	
	stars = new starfield(App);

	Iearth.LoadFromFile("gfx\\Earth.png");
	Isun.LoadFromFile("gfx\\Sun.png");
	Imars.LoadFromFile("gfx\\Mars.png");
	Ijupiter.LoadFromFile("gfx\\Jupiter.png");
	Ineptun.LoadFromFile("gfx\\Neptune.png");
	Iiris.LoadFromFile("gfx\\Iris.png");	
	I_black.LoadFromFile("gfx\\black.png");
	I_white.LoadFromFile("gfx\\white.png");
	I_fog.LoadFromFile("gfx\\fog3.png");
	I_background.LoadFromFile("gfx\\background.png");
	I_button.LoadFromFile("gfx\\new_game.png");;
	I_klappe.LoadFromFile("gfx\\klappe.png");
	I_mouse_norm.LoadFromFile("gfx\\hand1.png");
	I_mouse_drag.LoadFromFile("gfx\\hand2.png");
	I_win_lose.LoadFromFile("gfx\\win_lose.png");
	I_sfx.LoadFromFile("gfx\\sfx.png");
	I_music.LoadFromFile("gfx\\music.png");
	I_btHelp.LoadFromFile("gfx\\bt_hilfe.png");
	I_help.LoadFromFile("gfx\\Hilfe.png");

	Iearth.SetSmooth(false);
	Isun.SetSmooth(false);
	Imars.SetSmooth(false);
	Ijupiter.SetSmooth(false);
	Ineptun.SetSmooth(false);
	Iiris.SetSmooth(false);
	I_black.SetSmooth(false);
	I_white.SetSmooth(false);
	I_fog.SetSmooth(false);
	I_background.SetSmooth(false);
	I_button.SetSmooth(false);
	I_klappe.SetSmooth(false);
	I_mouse_norm.SetSmooth(false);
	I_mouse_drag.SetSmooth(false);
	I_win_lose.SetSmooth(false);
	I_sfx.SetSmooth(false);
	I_music.SetSmooth(false);
	I_btHelp.SetSmooth(false);
	I_help.SetSmooth(false);

	earth = new planet(Iearth, 50, 700);
	sun = new planet(Isun, 145, 700);
	mars = new planet(Imars, 240, 700);
	jupiter = new planet(Ijupiter, 335, 700);
	neptun = new planet(Ineptun, 430, 700);
	iris = new planet(Iiris, 525, 700);
	
	planet_line[0] = 0;
	planet_line[1] = 0;
	planet_line[2] = 0;
	planet_line[3] = 0;
	planet_line[4] = 0;
	planet_line[5] = 0;
	planet_line[6] = 0;
	planet_line[7] = 0;
	planet_line[8] = 0;
	planet_line[9] = 0;
	
	result_line = new pline (350, Iearth, Isun, Imars, Ijupiter, Ineptun, Iiris, I_black, I_white, I_fog);
	result_line->pinVisible(0);
	result_line->setXpos(650, 750, 850, 950);

	background.SetImage(I_background);
	background.SetPosition(624, 0);

	button.SetImage(I_button);
	button.SetPosition(722, 244);
	
	klappe.SetImage(I_klappe);
	klappe.SetPosition(637, 237);

	win_lose.SetImage(I_win_lose);
	win_lose.SetPosition(706, 430);

	s_bsfx.SetImage(I_sfx);
	s_bsfx.SetPosition(722, 590);

	s_bmusic.SetImage(I_music);
	s_bmusic.SetPosition(722, 650);

	s_mouse.SetImage(I_mouse_norm);

	s_btHelp.SetImage(I_btHelp);
	s_btHelp.SetPosition(722, 530);

	help.SetImage(I_help);
	help.SetPosition(112, 84);

	HydrBuffer.LoadFromFile("sfx\\hydraulic.ogg");
	sfx_hydr.SetBuffer(HydrBuffer);
	SlideBuffer.LoadFromFile("sfx\\slide.ogg");
	sfx_slide.SetBuffer(SlideBuffer);
	resultBuffer.LoadFromFile("sfx\\result.ogg");
	sfx_result.SetBuffer(resultBuffer);
	LoopBuffer.LoadFromFile("sfx\\loop.ogg");
	sfx_loop.SetBuffer(LoopBuffer);
}

framework::~framework()
{	
	for (int i=0; i<10; i++)
		delete planet_line[i];

	delete result_line;
	
	delete earth;
	delete sun;
	delete mars;
	delete jupiter;
	delete neptun;
	delete iris;	
	
	delete stars;
}


void framework::run()
{
	sfx_loop.Play();
	sfx_loop.SetLoop(true);

	while(App.IsOpened())
	{
		// Planeten zur�ckschicken
		check_planets();

		switch(state_machine)
		{
			// New Game
			case 0:
				
				level = 0;
				restart();

				if (klappe.GetPosition().y == 237)
					if (sfx_enable==true) sfx_hydr.Play();

				if (klappe.GetPosition().y == 328)
				{
					// Ergebnis
					for (int i=1; i<5; i++)
					{
						result_line->setSlot(i);
						result_line->setPlanet(logic_planets.getSoll(i-1));
					}
							
					state_machine = 1;
					ports_enabled = true;
				}
				else
				{
					klappe.Move(0, 1);
				}
				break;
				
			// Game Started	
			case 1:

				// Linie pr�fen
				if (logic_planets.allSet() == true)
				{
					logic_planets.check(values);
					if (sfx_enable==true) sfx_result.Play();
					
					if (values[0] == 2 && values[1] == 2 &&
						  values[2] == 2 && values[3] == 2)
					{
						// Spiel vorbei [Gewonnen]
						state_machine=2;
						if (sfx_enable==true) sfx_hydr.Play();
						win_lose.SetSubRect(sf::IntRect(0,0, 236, 60));
					}
					
					planet_line[level]->showChecked(values);	

					level++;
					
					if (level > 9) 
					{
						// Spiel vorbei [Verloren]
						state_machine=3;
						if (sfx_enable==true)  sfx_hydr.Play();
						win_lose.SetSubRect(sf::IntRect(0, 60, 236, 120));
					}
				}
				break;
			
			// Ohter...	
			default:
				if (klappe.GetPosition().y != 237)
					klappe.Move(0,-1);

				// Farbreihenfolge
				if (color > 0 && switch_color == false)
					color=color-5;
				else
					switch_color = true;
				
				if (color < 254 && switch_color == true)
					color=color+5;
				else
					switch_color = false;

				if (state_machine == 2)
					win_lose.SetColor(sf::Color(color, 255, 0, 255));

				if (state_machine == 3)
					win_lose.SetColor(sf::Color(color, color, 0, 255));

				break;
		}
		
		// Eingaben
		while (App.GetEvent(Event))
			getInput();
		
		// Hintergrund bewegen
		stars->run();
		
		// Mauszeiger
		s_mouse.SetPosition(App.GetInput().GetMouseX()-25, App.GetInput().GetMouseY()-25);

		// Zeichnen
		draw();
	}

}



void framework::getInput()
{
	// port
	int port=0;
	
	
	// Close window: exit
	if (Event.Type == sf::Event::Closed)
		App.Close();

	// KeyEvents abfangen
	if (Event.Type == sf::Event::KeyPressed)
	{
		// Escape key: exit
		if (Event.Key.Code == sf::Key::Escape)
			App.Close();				
	}	     
	
	
	
	// ButtonLeft Down
	if (App.GetInput().IsMouseButtonDown(sf::Mouse::Left))
	{
		// Mauszeiger �ndern
		s_mouse.SetImage(I_mouse_drag);

		// Help deaktivieren
		if (show_help == true) show_help = false;

		// New Game Button
		if (App.GetInput().GetMouseX() > button.GetPosition().x && App.GetInput().GetMouseX() < button.GetPosition().x + button.GetSize().x &&
			App.GetInput().GetMouseY() > button.GetPosition().y && App.GetInput().GetMouseY() < button.GetPosition().y + button.GetSize().y)
				state_machine = 0;

		// Audio An/Aus
		if (App.GetInput().GetMouseX() > s_bsfx.GetPosition().x && App.GetInput().GetMouseX() < s_bsfx.GetPosition().x + s_bsfx.GetSize().x &&
			App.GetInput().GetMouseY() > s_bsfx.GetPosition().y && App.GetInput().GetMouseY() < s_bsfx.GetPosition().y + s_bsfx.GetSize().y)
		{
			if (sfx_enable == true)
			{
				sfx_enable = false;
				s_bsfx.SetColor(sf::Color(0, 0, 0, 255));
			}
			else
			{
				sfx_enable = true;
				s_bsfx.SetColor(sf::Color(255, 255, 255, 255));
			}
		}

		// Musik An/Aus
		if (App.GetInput().GetMouseX() > s_bmusic.GetPosition().x && App.GetInput().GetMouseX() < s_bmusic.GetPosition().x + s_bmusic.GetSize().x &&
			App.GetInput().GetMouseY() > s_bmusic.GetPosition().y && App.GetInput().GetMouseY() < s_bmusic.GetPosition().y + s_bmusic.GetSize().y)
		{
			if (music_enable == true)
			{
				music_enable = false;
				sfx_loop.Stop();
				s_bmusic.SetColor(sf::Color(0, 0, 0, 255));
			}
			else
			{
				music_enable = true;
				sfx_loop.Play();
				sfx_loop.SetLoop(true);
				s_bmusic.SetColor(sf::Color(255, 255, 255, 255));
			}
		}

		// Show Help
		if (App.GetInput().GetMouseX() > s_btHelp.GetPosition().x && App.GetInput().GetMouseX() < s_btHelp.GetPosition().x + s_btHelp.GetSize().x &&
			App.GetInput().GetMouseY() > s_btHelp.GetPosition().y && App.GetInput().GetMouseY() < s_btHelp.GetPosition().y + s_btHelp.GetSize().y)
				show_help = true;

		// Planeten DragnDrop
		if (mouse->DragSomething() == false)
		{
			if (mouse->MousePressed(earth->getSprite(), earth->isOnNewPos()) == true) 
			{
				earth->setDrag(true);
				dragValue = 1;
			}
			
			if (mouse->MousePressed(sun->getSprite(),sun->isOnNewPos()) == true) 
			{
				sun->setDrag(true);
				dragValue = 2;
			}
			
			if (mouse->MousePressed(mars->getSprite(), mars->isOnNewPos()) == true) 
			{
				mars->setDrag(true);
				dragValue = 3;
			}
						
			if (mouse->MousePressed(jupiter->getSprite(), jupiter->isOnNewPos()) == true) 
			{	
				jupiter->setDrag(true);
				dragValue = 4;
			}
			
			if (difficult > 0)
			{ 
				if (mouse->MousePressed(neptun->getSprite(), neptun->isOnNewPos()) == true) 
				{	
					neptun->setDrag(true);
					dragValue = 5;
				}
			}
			
			if (difficult > 1)
			{
				if (mouse->MousePressed(iris->getSprite(), iris->isOnNewPos()) == true) 
				{
					iris->setDrag(true);
					dragValue = 6;
				}
			}
		}
		else
			mouse->MouseFollow();
	}

	// MouseBuffonLeft Up
	if (App.GetInput().IsMouseButtonDown(sf::Mouse::Left) == false)
	{
		//Mauszeiger �ndern
		s_mouse.SetImage(I_mouse_norm);
	}

	// MouseButtonLeft Up + DragSomething
	if (App.GetInput().IsMouseButtonDown(sf::Mouse::Left) == false && mouse->DragSomething() == true)
	{
		mouse->MouseReleased();

		if (earth->isDrag() == true)
		{
			earth->setDrag(false);
			port = planet_line[level]->checkPlanet(earth->getSprite(), 1);
			if (port > 0)
			{
				if (sfx_enable==true) sfx_slide.Play();
				level_while_set = level;
				earth->ReturnToPlace(port, level, state_machine);
				logic_planets.setValue(port, 1);
			}
		}
		
		if (sun->isDrag() == true)
		{	
			sun->setDrag(false);
			port = planet_line[level]->checkPlanet(sun->getSprite(), 2);
			if (port > 0)
			{
				if (sfx_enable==true) sfx_slide.Play();
				level_while_set = level;
				sun->ReturnToPlace(port, level, state_machine);
				logic_planets.setValue(port, 2);
			}
		}
		
		if (mars->isDrag() == true)
		{
			mars->setDrag(false);
			port = planet_line[level]->checkPlanet(mars->getSprite(), 3);
			if (port > 0)
			{
				if (sfx_enable==true) sfx_slide.Play();
				level_while_set = level;
				mars->ReturnToPlace(port, level, state_machine);
				logic_planets.setValue(port, 3);
			}
		}
		
		if (jupiter->isDrag() == true)
		{
			jupiter->setDrag(false);
			port = planet_line[level]->checkPlanet(jupiter->getSprite(), 4);
			if (port > 0)
			{
				if (sfx_enable==true) sfx_slide.Play();
				level_while_set = level;
				jupiter->ReturnToPlace(port, level, state_machine);
				logic_planets.setValue(port, 4);
			}
		}
		
		if (neptun->isDrag() == true)
		{	
			neptun->setDrag(false);
			port = planet_line[level]->checkPlanet(neptun->getSprite(), 5);
			if (port > 0)
			{
				if (sfx_enable==true) sfx_slide.Play();
				level_while_set = level;
				neptun->ReturnToPlace(port, level, state_machine);
				logic_planets.setValue(port, 5);
			}
		}
		
		if (iris->isDrag() == true)
		{	
			iris->setDrag(false);	
			port = planet_line[level]->checkPlanet(iris->getSprite(), 6);
			if (port > 0)
			{
				if (sfx_enable==true) sfx_slide.Play();
				level_while_set = level;
				iris->ReturnToPlace(port, level, state_machine);
				logic_planets.setValue(port, 6);
			}
		}		
	}
}

void framework::draw()
{
	stars->draw();
	
	result_line->draw(App);

	App.Draw(klappe);
	App.Draw(background);
	App.Draw(button);
	App.Draw(s_bsfx);
	App.Draw(s_bmusic);
	App.Draw(s_btHelp);

	if (state_machine > 1)
	{
		App.Draw(win_lose);
	}

	for (int i=0; i<10; i++)
		planet_line[i]->draw(App);
	
	earth->draw(App);
	sun->draw(App);
	mars->draw(App);
	jupiter->draw(App);
	neptun->draw(App);
	iris->draw(App);

	if (show_help == true)
		App.Draw(help);

	App.Draw(s_mouse);

	App.Display();
	App.Clear();	
}

void framework::check_planets()
{
	if (earth->SlideBack(App.GetFrameTime()) == true)
	{
		if (ports_enabled == true) planet_line[level_while_set]->setPlanet(1);
		if (state_machine != 1)	ports_enabled = false;
	}

	if (sun->SlideBack(App.GetFrameTime()) == true)
	{
		if (ports_enabled == true) planet_line[level_while_set]->setPlanet(2);
		if (state_machine != 1)	ports_enabled = false;
	}

	if (mars->SlideBack(App.GetFrameTime()) == true)
	{
		if (ports_enabled == true) planet_line[level_while_set]->setPlanet(3);
		if (state_machine != 1)	ports_enabled = false;
	}

	if (jupiter->SlideBack(App.GetFrameTime()) == true)
	{
		if (ports_enabled == true) planet_line[level_while_set]->setPlanet(4);
		if (state_machine != 1)	ports_enabled = false;
	}

	if (neptun->SlideBack(App.GetFrameTime()) == true)
	{
		if (ports_enabled == true) planet_line[level_while_set]->setPlanet(5);
		if (state_machine != 1)	ports_enabled = false;
	}

	if (iris->SlideBack(App.GetFrameTime()) == true)
	{
		if (ports_enabled == true) planet_line[level_while_set]->setPlanet(6);
		if (state_machine != 1)	ports_enabled = false;
	}
}

void framework::restart()
{
	logic_planets.createNew(difficult);
	
	for (int i=0; i<10; i++)
		delete planet_line[i];
	
	planet_line[0] = new pline(575, Iearth, Isun, Imars, Ijupiter, Ineptun, Iiris, I_black, I_white, I_fog);
	planet_line[1] = new pline(515, Iearth, Isun, Imars, Ijupiter, Ineptun, Iiris, I_black, I_white, I_fog);
	planet_line[2] = new pline(455, Iearth, Isun, Imars, Ijupiter, Ineptun, Iiris, I_black, I_white, I_fog);
	planet_line[3] = new pline(395, Iearth, Isun, Imars, Ijupiter, Ineptun, Iiris, I_black, I_white, I_fog);
	planet_line[4] = new pline(335, Iearth, Isun, Imars, Ijupiter, Ineptun, Iiris, I_black, I_white, I_fog);
	planet_line[5] = new pline(275, Iearth, Isun, Imars, Ijupiter, Ineptun, Iiris, I_black, I_white, I_fog);
	planet_line[6] = new pline(215, Iearth, Isun, Imars, Ijupiter, Ineptun, Iiris, I_black, I_white, I_fog);
	planet_line[7] = new pline(155, Iearth, Isun, Imars, Ijupiter, Ineptun, Iiris, I_black, I_white, I_fog);
	planet_line[8] = new pline(95, Iearth, Isun, Imars, Ijupiter, Ineptun, Iiris, I_black, I_white, I_fog);
	planet_line[9] = new pline(35, Iearth, Isun, Imars, Ijupiter, Ineptun, Iiris, I_black, I_white, I_fog);
}