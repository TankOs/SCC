#include "pline.h"

pline::pline(int yPos, sf::Image &p1, sf::Image &p2,sf::Image &p3, sf::Image &p4, sf::Image &p5, sf::Image &p6, sf::Image &pi1, sf::Image &pi2, sf::Image &dp) 
				: planet1(p1), planet2(p2), planet3(p3), planet4(p4), planet5(p5), planet6(p6),pin1(pi1), pin2(pi2), default_planet(dp)
{
	p_sockel_1.SetPosition(100, yPos);
	p_sockel_2.SetPosition(200, yPos);
	p_sockel_3.SetPosition(300, yPos);
	p_sockel_4.SetPosition(400, yPos);
	
	// TODO
	c_sockel_1.SetPosition(500, yPos);
	c_sockel_2.SetPosition(525, yPos);
	c_sockel_3.SetPosition(500, yPos+25);
	c_sockel_4.SetPosition(525, yPos+25);

	c_sockel_1.SetColor(sf::Color(255, 255, 255, 0));
	c_sockel_2.SetColor(sf::Color(255, 255, 255, 0));
	c_sockel_3.SetColor(sf::Color(255, 255, 255, 0));
	c_sockel_4.SetColor(sf::Color(255, 255, 255, 0));

	// TODO
	p_sockel_1.SetImage(dp);
	p_sockel_2.SetImage(dp);
	p_sockel_3.SetImage(dp);
	p_sockel_4.SetImage(dp);
			
	slot = 0;	
}

int pline::checkPlanet(sf::Sprite &planet, int value)
{
	int port=0;

	if (checkCollision(planet, p_sockel_1) == true)
		port = 1;
	
	if (checkCollision(planet, p_sockel_2) == true)
		port = 2;
		
	if (checkCollision(planet, p_sockel_3) == true)
		port = 3;
		
	if (checkCollision(planet, p_sockel_4) == true)
		port = 4;

	if (port > 0)
	{
		slot = port;
	}
	
	return port;
}

void pline::showChecked(int *values)
{
	if (values[0] > 0)
		setPin(1, values[0]);
	if (values[1] > 0)
		setPin(2, values[1]);
	if (values[2] > 0)
		setPin(3, values[2]);
	if (values[3] > 0)
		setPin(4, values[3]);
}

void pline::setPlanet(int value)
{
	switch(slot)
	{
		case 1:
			setImageP(p_sockel_1, value);
			break;
		case 2:
			setImageP(p_sockel_2, value);
			break;
		case 3:
			setImageP(p_sockel_3, value);
			break;
		case 4:
			setImageP(p_sockel_4, value);
			break;
	}
}

sf::Sprite &pline::getPlanetSprite(int sockel)
{
	switch(sockel)
	{
		case 1:
			return p_sockel_1;
		case 2:
			return p_sockel_2;
		case 3:
			return p_sockel_3;
		case 4:
			return p_sockel_4;
	}
}

void pline::setXpos(int p1_Xpos, int p2_Xpos, int p3_Xpos, int p4_Xpos)
{
	p_sockel_1.SetPosition(p1_Xpos, p_sockel_1.GetPosition().y);
	p_sockel_2.SetPosition(p2_Xpos, p_sockel_1.GetPosition().y);
	p_sockel_3.SetPosition(p3_Xpos, p_sockel_1.GetPosition().y);
	p_sockel_4.SetPosition(p4_Xpos, p_sockel_1.GetPosition().y);
}

void pline::pinVisible(int gamma)
{
	c_sockel_1.SetColor(sf::Color(255, 255, 255, gamma));
	c_sockel_2.SetColor(sf::Color(255, 255, 255, gamma));
}


bool pline::checkCollision(sf::Sprite &Object1, sf::Sprite &Object2)
{
	bool ret = false;
	
 	if (Object1.GetPosition().x + Object1.GetSize().x > Object2.GetPosition().x && 
		Object1.GetPosition().x < Object2.GetPosition().x + Object2.GetSize().x &&
		Object1.GetPosition().y + Object1.GetSize().y > Object2.GetPosition().y &&
		Object1.GetPosition().y < Object2.GetPosition().y + Object2.GetSize().y)
		ret = true;
 			
	
	return ret;
}

void pline::draw(sf::RenderWindow &App)
{
	App.Draw(p_sockel_1);
	App.Draw(p_sockel_2);
	App.Draw(p_sockel_3);
	App.Draw(p_sockel_4);

	App.Draw(c_sockel_1);
	App.Draw(c_sockel_2);
	App.Draw(c_sockel_3);
	App.Draw(c_sockel_4);
}

void pline::setPin(int pin_number, int value)
{
	switch(pin_number)
	{
		case 1:
			c_sockel_1.SetColor(sf::Color(255, 255, 255, 255));
			setImageC(c_sockel_1, value);
			break;
		case 2:
			c_sockel_2.SetColor(sf::Color(255, 255, 255, 255));
			setImageC(c_sockel_2, value);
			break;
		case 3:
			c_sockel_3.SetColor(sf::Color(255, 255, 255, 255));
			setImageC(c_sockel_3, value);
			break;
		case 4:
			c_sockel_4.SetColor(sf::Color(255, 255, 255, 255));
			setImageC(c_sockel_4, value);
			break;
	}
}

void pline::setImageP(sf::Sprite &sockel, int value)
{
	switch (value)
	{
		case 0:
			//sockel.SetColor();
		case 1:
			sockel.SetImage(planet1);
			break;
		case 2:
			sockel.SetImage(planet2);
			break;
		case 3:
			sockel.SetImage(planet3);
			break;
		case 4:
			sockel.SetImage(planet4);
			break;
		case 5:
			sockel.SetImage(planet5);
			break;
		case 6:
			sockel.SetImage(planet6);
			break;		
	}	
}


void pline::setImageC(sf::Sprite &sockel, int value)
{
	if (value == 1)
		sockel.SetImage(pin1);
	
	if (value == 2)
		sockel.SetImage(pin2);
}