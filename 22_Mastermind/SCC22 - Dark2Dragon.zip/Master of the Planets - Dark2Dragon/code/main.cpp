// MASTERMIND
// BY DARK2DRAGON


#include <SFML/Window.hpp>
#include "framework.h"


int main()
{
	// ### Main Window ###
	sf::RenderWindow App(sf::VideoMode(1024, 768, 32), "Master of the Planets", sf::Style::Close);

	App.SetFramerateLimit(60);
	App.ShowMouseCursor(false);

	sf::Image I_loading;
	sf::Sprite loading;

	I_loading.LoadFromFile("gfx//loading.png");
	I_loading.SetSmooth(false);
	loading.SetImage(I_loading);

	// Loading screen
	App.Clear();
	App.Draw(loading);
	App.Display();

	
	
	framework Engine(App);
	
	// run
	Engine.run();

	return 0;
}


