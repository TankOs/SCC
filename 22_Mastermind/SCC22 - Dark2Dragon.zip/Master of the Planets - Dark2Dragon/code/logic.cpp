#include "logic.h"


	logic::logic() 
	{
		for(int i=0; i<4; i++)
		{
			soll[i] = 0;
			ist[i] = 0;
		}
		
	}

	void logic::createNew(int difficult) 
	{
		soll[0] = sf::Randomizer::Random(1, 4+difficult);
		soll[1] = sf::Randomizer::Random(1, 4+difficult);
		soll[2] = sf::Randomizer::Random(1, 4+difficult);
		soll[3] = sf::Randomizer::Random(1, 4+difficult);
	}
		
		
	void logic::check(int *ret) 
	{
		int c=0;

		int pos0 = soll[0];
		int pos1 = soll[1];
		int pos2 = soll[2];
		int pos3 = soll[3];

		// values l�schen & Werte direkt vergleichen
		for (int u=0; u<4; u++)
		{
			ret[u] = 0;
			if (soll[u] == ist[u])
			{
				soll[u] = 0;
				ist[u] = 0;
				ret[c] = 2;
				c++;
			}
		}

		// Eingaben checken
		for (int i=0; i<4; i++)
		{
			for (int j=0; j<4; j++)
			{
				if (soll[i] == ist[j] && soll[i] != 0)
				{
					soll[i] = 0;
					ist[j] = 0;
					ret[c] = 1;					
					c++;
					j = 4;
				}
			}
		}
		
		// Ist l�schen	
		for (int k=0; k<4; k++)
			ist[k] = 0;

		// Soll Werte setzen
		soll[0] = pos0;
		soll[1] = pos1;
		soll[2] = pos2;
		soll[3] = pos3;
	}
	
	
	bool logic::allSet()
	{
		bool ret = false;
		
		if (ist[0] > 0 && ist[1] > 0 &&
			ist[2] > 0 && ist[3] > 0)
				ret = true;
		
		return ret;
	}