#include <fstream>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "dragndrop.h"
#include "logic.h"
#include "pline.h"
#include "planet.h"

#include "starfield.h"


#ifndef FRAMEWORK_H
#define FRAMEWORK_H


class framework {

private:
	
	sf::RenderWindow &App;			// App
	sf::Event Event;				// Events
	dragndrop *mouse;				// Drag and Drop 4Mouse	
	
	bool ports_enabled;				// Drop m�glich?
	bool sfx_enable;				// SFX an?
	bool music_enable;				// Musik an?
	bool show_help;
	int state_machine;				// State Machine
	int dragValue;					// Wert des Planeten	
	int difficult;					// Schwierigkeitsgrad
	int level;						// Level
	int level_while_set;			// Level, bei dem Wert gesetzt wurde
	int color;						// Farbwerte
	bool switch_color;				// Umschaltwert
	int values[4];					// R�ckgabewerte
	starfield *stars;				// Hintergund
	
	logic logic_planets;
	pline *planet_line[10];
	pline *result_line;
	
	planet *earth;
	planet *sun;
	planet *mars;
	planet *jupiter;
	planet *neptun;
	planet *iris;
	
	// Images
	sf::Image Iearth;
	sf::Image Isun;
	sf::Image Imars;
	sf::Image Ijupiter;
	sf::Image Ineptun;
	sf::Image Iiris;		
	sf::Image I_black;
	sf::Image I_white;
	sf::Image I_fog;
	sf::Image I_background;
	sf::Image I_button;
	sf::Image I_klappe;
	sf::Image I_mouse_norm;
	sf::Image I_mouse_drag;
	sf::Image I_win_lose;
	sf::Image I_help;
	sf::Image I_btHelp;
	sf::Image I_sfx;
	sf::Image I_music;

	// Sprites
	sf::Sprite background;
	sf::Sprite button;
	sf::Sprite klappe;
	sf::Sprite win_lose;
	sf::Sprite s_mouse;
	sf::Sprite s_bsfx;
	sf::Sprite s_bmusic;
	sf::Sprite s_btHelp;
	sf::Sprite help;

	// Audio
	sf::SoundBuffer HydrBuffer;
	sf::Sound sfx_hydr;
	sf::SoundBuffer SlideBuffer;
	sf::Sound sfx_slide;
	sf::SoundBuffer resultBuffer;
	sf::Sound sfx_result;
	sf::SoundBuffer LoopBuffer;
	sf::Sound sfx_loop;

public:
	framework(sf::RenderWindow &window);
	~framework();
	void run();

private:
	void restart();
	void getInput();
	void draw();
	void check_planets();
};

#endif