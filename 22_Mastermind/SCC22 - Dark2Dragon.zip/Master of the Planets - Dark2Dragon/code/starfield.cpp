#include "starfield.h"

starfield::starfield(sf::RenderWindow &window) : App(window)
{
	create();
}


void starfield::create()
{
	sf::Shape star = sf::Shape::Circle(0, 0, 1, sf::Color::White);
	
	for (int i=0; i<9; i++)
	{
		for (int j=0; j<7; j++)
		{
			star.SetPosition(128*i+sf::Randomizer::Random(0, 100), 128*j+sf::Randomizer::Random(0, 100));
			Stars.push_back(star);
		}
	}
}	
	
void starfield::run()
{
	std::list<sf::Shape>::iterator i;
		
	for (i=Stars.begin(); i != Stars.end(); ++i)
	{
		i->Move(-1,-1);
		
		if (i->GetPosition().x < 0)
			i->SetPosition(App.GetWidth()+1, i->GetPosition().y);
		
		if (i->GetPosition().y < 0)
			i->SetPosition(i->GetPosition().x, App.GetHeight()+1);
		
	}
}	
	
void starfield::draw()
{
	std::list<sf::Shape>::iterator i;
		
	for (i=Stars.begin(); i != Stars.end(); ++i)
		App.Draw(*i);
}