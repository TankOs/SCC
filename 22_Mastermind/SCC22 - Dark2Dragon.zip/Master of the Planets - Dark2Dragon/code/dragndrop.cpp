#include "dragndrop.h"

dragndrop::dragndrop(sf::RenderWindow &window) : App(window)
{
		drag = false;
}

dragndrop::~dragndrop() 
{
	delete Object;
}

bool dragndrop::MousePressed(sf::Sprite &Obj, bool enable)
{
		if (App.GetInput().GetMouseX() > Obj.GetPosition().x && App.GetInput().GetMouseX() < Obj.GetPosition().x + Obj.GetSize().x &&
			  App.GetInput().GetMouseY() > Obj.GetPosition().y && App.GetInput().GetMouseY() < Obj.GetPosition().y + Obj.GetSize().y && enable == false)
		{
			Object = &Obj;
			drag = true;
			return true;
		}	  
		else
			return false;
}

void dragndrop::MouseFollow() 
{
	if (drag == true)
	{
		int xPos = App.GetInput().GetMouseX() - Object->GetSize().x/2;
		int yPos = App.GetInput().GetMouseY() - Object->GetSize().y/2;
		
		Object->SetPosition(xPos, yPos);
	}
}