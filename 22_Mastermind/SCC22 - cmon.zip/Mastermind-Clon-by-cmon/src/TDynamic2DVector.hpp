#ifndef TDYNAMIC2DVECTOR_HPP
#define TDYNAMIC2DVECTOR_HPP

#include <vector>

template <typename T>
class TDynamic2DVector
{
public:
    TDynamic2DVector()
    {
    }
//---------------------------------------------------------------------------------------
    TDynamic2DVector(int rows, int cols):_array(rows, std::vector<T>(cols))
    {
    }
//---------------------------------------------------------------------------------------
    inline std::vector<T> & operator[](int i)
    {
        return _array[i];
    }
//---------------------------------------------------------------------------------------
    inline const std::vector<T> & operator[] (int i) const
    {
        return _array[i];
    }
//---------------------------------------------------------------------------------------
    void resize(int rows, int cols)
    {
        _array.resize(rows);
        for(int i = 0;i < rows;++i)
            _array[i].resize(cols);
    }
//---------------------------------------------------------------------------------------
    int getSizeX()
    {
        return _array.size();
    }
//---------------------------------------------------------------------------------------
    int getSizeY()
    {
        return _array[0].size();
    }

private:
    std::vector<std::vector<T> > _array;
};






#endif // TDYNAMIC2DVECTOR_HPP
