#include "CTextBox.hpp"
#include <iostream>

const std::string allowedchar = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_()[]";

//-----------------------------------------------------------------------------
CTextBox::CTextBox(int posx, int posy, int sizex, int sizey, std::string name, std::string leer):_leertext(leer),
                                                                                                 _inhalt(name),
                                                                                                 _posx(posx),
                                                                                                 _posy(posy),
                                                                                                 _sizex(sizex),
                                                                                                 _sizey(sizey)
{
    _rahmen = sf::Shape::Rectangle(0,0,sizex,sizey,sf::Color(150,150,150),2.f,sf::Color::Black);
    _rahmen.SetPosition(posx,posy);

    _name.SetPosition(posx,posy-2);
    _name.SetSize(sizey-4);

    if(name != "")
    {
        _name.SetColor(sf::Color::Black);
        _name.SetText(name.c_str());
    }
    else
    {
        _name.SetColor(sf::Color(255,255,255,150));
        _name.SetText(leer.c_str());
    }
}
//-----------------------------------------------------------------------------
void CTextBox::draw(sf::RenderWindow &window)
{
    window.Draw(sf::Shape::Rectangle(_posx-50,0,_posx+_sizex+50,window.GetHeight(),sf::Color(0,0,0,200)));
    window.Draw(_rahmen);
    window.Draw(_name);
}
//-----------------------------------------------------------------------------
void CTextBox::addtext(char c)
{
    if(c == 8)
    {
        if(_inhalt.length() > 0)
        {
            _inhalt.erase(_inhalt.length()-1,1);
        }
    }
    else if(allowedchar.find(c) != -1)
    {
        if(_inhalt.length() < 6)
        {
            _inhalt +=c;
        }
    }
    if(_inhalt != "")
    {
        _name.SetColor(sf::Color::Black);
        _name.SetText(_inhalt.c_str());
    }
    else
    {
        _name.SetColor(sf::Color(255,255,255,150));
        _name.SetText(_leertext.c_str());
    }
}
//-----------------------------------------------------------------------------
bool CTextBox::isempty()
{
    return _inhalt=="";
}
//-----------------------------------------------------------------------------
std::string CTextBox::gettext()
{
    return _inhalt;
}
//-----------------------------------------------------------------------------
void CTextBox::clear()
{
    _inhalt = "";
    _name.SetText(_leertext.c_str());
    _name.SetColor(sf::Color(255,255,255,150));
}
