#ifndef CFELD_HPP
#define CFELD_HPP

#include <SFML/Graphics.hpp>

class CFeld
{
protected:

public:
    CFeld();
    void draw(sf::RenderWindow &window);
};

#endif // CFELD_HPP
