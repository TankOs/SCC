#ifndef CAUSWAHL_HPP
#define CAUSWAHL_HPP

#include <SFML/Graphics.hpp>
#include <vector>

class CAuswahl
{
protected:
    sf::Shape *_rahmen;
    std::vector<sf::Shape*> _listeauswahl;
    sf::Color *_color;
    int _posx, _posy, _sizex, _sizey;

    sf::Rect<int>  getRect();
public:
    CAuswahl();
    CAuswahl(int posx, int posy, int sizex, int sizey);
    void draw(sf::RenderWindow &window);
    bool onClick(int posx, int posy);
    void setColor(int nr);
    sf::Color getcolor();
};

#endif // CAUSWAHL_HPP
