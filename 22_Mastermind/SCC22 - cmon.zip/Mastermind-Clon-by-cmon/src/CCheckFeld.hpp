#ifndef CCHECKFELD_HPP
#define CCHECKFELD_HPP

#include <SFML/Graphics.hpp>

class CCheckFeld
{
protected:
    sf::Shape *_rahmen;
    sf::Shape *_lineX;
    sf::Shape *_lineY;
    sf::Shape *_points  [4];
    int _posx, _posy, _size;

public:
    CCheckFeld();
    CCheckFeld(int posx, int posy, int size);
    void draw(sf::RenderWindow &window);
    void setBGColor();
    void setPinCode(int weis, int rot);

};

#endif // CCHECKFELD_HPP
