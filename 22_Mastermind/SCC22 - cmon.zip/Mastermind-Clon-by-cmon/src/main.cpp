#include <SFML/Graphics.hpp>
#include "CBoard.hpp"
#include "CAuswahl.hpp"
#include <iostream>
#include "CSpielStatus.hpp"
#include "CTime.hpp"
#include "CTextBox.hpp"
#include "CHighcoreManager.hpp"



int main(int argc, char *argv[])
{
    sf::RenderWindow *window = new sf::RenderWindow(sf::VideoMode(600,600),"Mastermind-Clone-by-cmon");
    sf::Event event;

    CTime time;
    CSpielStatus *status = new CSpielStatus();
    CBoard *board = new CBoard(180,10,status);
    CAuswahl *auswahl = new CAuswahl(180,525,250,50);
    CTextBox *box = new CTextBox(180,530,250,30);
    CHighcoreManager *highscore = new CHighcoreManager();

    while(window->IsOpened())
    {
        while(window->GetEvent(event))
        {
            if(event.Type == sf::Event::Closed)
            {
                window->Close();
                highscore->saveHighscore();
            }
            if(status->getSpielStatus() == start)
            {
                if(event.Type == sf::Event::KeyReleased)
                {
                    if(event.Key.Code == sf::Key::Escape)
                    {
                            window->Close();
                            highscore->saveHighscore();
                     }

                    time.reset();
                    status->setStatus(play);
                }
            }
            else if(status->getSpielStatus() == play)
            {
                if(event.Type == sf::Event::KeyReleased)
                {
                    if(event.Key.Code == sf::Key::Escape)
                            window->Close();
                    else if(event.Key.Code == sf::Key::F1)
                        auswahl->setColor(1);
                    else if(event.Key.Code == sf::Key::F2)
                        auswahl->setColor(2);
                    else if(event.Key.Code == sf::Key::F3)
                        auswahl->setColor(3);
                    else if(event.Key.Code == sf::Key::F4)
                        auswahl->setColor(4);
                    else if(event.Key.Code == sf::Key::F5)
                        auswahl->setColor(5);
                    else if(event.Key.Code == sf::Key::Num1)
                        board->addPin(0,auswahl->getcolor());
                    else if(event.Key.Code == sf::Key::Num2)
                        board->addPin(1,auswahl->getcolor());
                    else if(event.Key.Code == sf::Key::Num3)
                        board->addPin(2,auswahl->getcolor());
                    else if(event.Key.Code == sf::Key::Num4)
                        board->addPin(3,auswahl->getcolor());
                    else if(event.Key.Code == sf::Key::Return)
                        board->check();
                }
            }
            else if(status->getSpielStatus() == win)
            {
                if((event.Key.Code == sf::Key::Return) && (event.Type == sf::Event::KeyReleased))
                {
                    status->setStatus(score);
                }
            }
            else if(status->getSpielStatus() == lose)
            {
                if((event.Key.Code == sf::Key::Return) && (event.Type == sf::Event::KeyReleased))
                {
                    delete board;
                    board = new CBoard(180,10,status);
                    status->setStatus(start);
                    time.reset();
                }

            }
            else if(status->getSpielStatus() == scoreadd)
            {
                if((event.Key.Code == sf::Key::Return) && (event.Type == sf::Event::KeyReleased))
                {
                    delete board;
                    board = new CBoard(180,10,status);
                    status->setStatus(start);
                    time.reset();
                }
            }
            else if(status->getSpielStatus() == score)
            {
                    if((event.Key.Code == sf::Key::Return) && (event.Type == sf::Event::KeyReleased) )
                    {
                        if(!box->isempty())
                        {
                           highscore->addScore(box->gettext(),time.getlasttime());
                           status->setStatus(scoreadd);
                        }
                    }
                    else if(event.Type == sf::Event::TextEntered)
                    {
                        box->addtext(static_cast<char>(event.Text.Unicode));
                    }
            }
        }


        window->Clear(sf::Color(200,200,200));

        board->draw(*window);
        auswahl->draw(*window);
        time.draw(*window);
        if(status->getSpielStatus() == play)
        {
            time.update();
        }
        else if(status->getSpielStatus() == win)
        {
            sf::String t("Win");
            t.SetColor(sf::Color::Black);
            t.SetPosition(200,200);
            window->Draw(t);
        }
        else if(status->getSpielStatus() == lose)
        {
            sf::String t("Lose");
            t.SetPosition(200,200);
            t.SetColor(sf::Color::Black);
            window->Draw(t);
        }
        else if(status->getSpielStatus() == score)
        {
            box->draw(*window);
            highscore->draw(*window);
        }
        else if(status->getSpielStatus() == scoreadd)
        {
             window->Draw(sf::Shape::Rectangle(180-50,0,180+250+50,window->GetHeight(),sf::Color(0,0,0,200)));
             highscore->draw(*window);
             box->clear();
        }
        window->Display();
    }
}
