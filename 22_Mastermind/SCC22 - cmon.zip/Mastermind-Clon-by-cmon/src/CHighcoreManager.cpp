#include "CHighcoreManager.hpp"
#include <sstream>
#include <stdlib.h>
#include <iostream>
#include <fstream>

CHighcoreManager::CHighcoreManager()
{
    loadHighscore();
}
//-----------------------------------------------------------------------------
CHighcoreManager::~CHighcoreManager()
{
    saveHighscore();
}
//-----------------------------------------------------------------------------
void CHighcoreManager::addScore(std::string name, float zeit)
{
    std::stringstream ss;
    ss << (int)zeit;

    eintrag e;
    e.name = name;
    e.zeit = ss.str();

    if(_liste.size()==0)
    {
        _liste.push_back(e);
    }
    else
    {
        bool added = false;
        for(int i = 0;i<_liste.size();i++)
        {
            if(atof(e.zeit.c_str())<atol(_liste[i].zeit.c_str()))
            {
                added = true;
                _liste.insert(_liste.begin()+i,e);
                break;
            }
        }
        if(!added)
        {
            _liste.push_back(e);
        }
    }
}
//-----------------------------------------------------------------------------
void CHighcoreManager::draw(sf::RenderWindow &window)
{

    sf::String title;
    sf::String name;
    sf::String zeit;
    sf::String rank;

    rank.SetColor(sf::Color::Cyan);
    title.SetColor(sf::Color::Green);
    name.SetColor(sf::Color::Cyan);
    zeit.SetColor(sf::Color::Cyan);


    title.SetPosition(150,20);


    title.SetText("Rank      Name     Zeit");
    for(int i=0;i<_liste.size(); i++)
    {
        std::stringstream ss;
        rank.SetPosition(170,60+(i*35));
        name.SetPosition(270,60+(i*35));
        zeit.SetPosition(390,60+(i*35));

        name.SetText(_liste[i].name.c_str());
        zeit.SetText(_liste[i].zeit.c_str());
        ss << (int)i+1;
        rank.SetText(ss.str());
        window.Draw(name);
        window.Draw(zeit);
        window.Draw(rank);

    }
    window.Draw(title);

    window.Draw(sf::Shape::Line(180-50,60,480,60,2.f,sf::Color::Blue));
}
//-----------------------------------------------------------------------------
void CHighcoreManager::saveHighscore()
{
    std::ofstream out("data/score.dat");
    out << _liste.size() << std::endl;
    for(int i=0; i<_liste.size();i++)
    {
        out << _liste[i].name << std::endl;

        if(i==_liste.size()-1)
            out << _liste[i].zeit;
        else
            out << _liste[i].zeit << std::endl;


    }
    out.close();
}

void CHighcoreManager::loadHighscore()
{
    _liste.clear();

    std::string line;
    std::ifstream in("data/score.dat");

    getline(in,line);

    if(line!="0")
    {
        while(in.good())
        {
            eintrag e;

            getline(in,line);
            e.name = line;

            getline(in,line);
            e.zeit = line;

            _liste.push_back(e);
        }
    }
    in.close();
}
