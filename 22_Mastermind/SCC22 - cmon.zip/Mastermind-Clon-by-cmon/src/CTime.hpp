#ifndef CTIME_HPP
#define CTIME_HPP
#include <SFML/Graphics.hpp>
class CTime
{
protected:
    sf::Clock _clock;
    sf::String _time;
    float _lasttime;
public:
    CTime();
    void draw(sf::RenderWindow &window);
    void update();
    void reset();
    float getlasttime();
};

#endif // CTIME_HPP
