#ifndef CSPIELSTATUS_HPP
#define CSPIELSTATUS_HPP
    enum ESpielStatus{start, play, win, lose, score, scoreadd, wait};


class CSpielStatus
{
protected:
    ESpielStatus _spielstatus;
public:
    CSpielStatus();
    void setStatus(ESpielStatus s);
    ESpielStatus getSpielStatus();
};

#endif // CSPIELSTATUS_HPP
