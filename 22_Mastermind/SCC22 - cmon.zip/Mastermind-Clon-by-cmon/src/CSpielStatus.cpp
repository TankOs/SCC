#include "CSpielStatus.hpp"

CSpielStatus::CSpielStatus():_spielstatus(start)
{
}
//-----------------------------------------------------------------------------
void CSpielStatus::setStatus(ESpielStatus s)
{
    _spielstatus = s;
}
//-----------------------------------------------------------------------------
ESpielStatus CSpielStatus::getSpielStatus()
{
    return _spielstatus;
}
