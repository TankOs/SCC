#include "CAuswahl.hpp"

CAuswahl::CAuswahl()
{
}
//-----------------------------------------------------------------------------
CAuswahl::CAuswahl(int posx, int posy, int sizex, int sizey): _listeauswahl(6),
                                                              _posx(posx),
                                                              _posy(posy),
                                                              _sizex(sizex),
                                                              _sizey(sizey)
{
    _color = new sf::Color();
    *_color = sf::Color::Red;
    _rahmen = new sf::Shape();

    *_rahmen = sf::Shape::Rectangle(0,0,sizex,sizey,sf::Color(100,100,100),2.f,sf::Color::Black);
    _rahmen->SetPosition(posx,posy);


    sf::Shape *f;
    f = new sf::Shape();
    *f = sf::Shape::Circle(0,0,10,sf::Color::Red,0.f,sf::Color::Black);
    f->SetPosition(posx+(sizex/6),posy+(sizey/2));
    f->SetOutlineWidth(2.f);
    _listeauswahl[0] = f;

    f = new sf::Shape();
    *f = sf::Shape::Circle(0,0,10,sf::Color::Green,0.f,sf::Color::Black);
    f->SetPosition(posx+(sizex/6)*2,posy+(sizey/2));
    _listeauswahl[1] = f;

    f = new sf::Shape();
    *f = sf::Shape::Circle(0,0,10,sf::Color::Blue,0.f,sf::Color::Black);
    f->SetPosition(posx+(sizex/6)*3,posy+(sizey/2));
    _listeauswahl[2] = f;

    f = new sf::Shape();
    *f = sf::Shape::Circle(0,0,10,sf::Color::Cyan,0.f,sf::Color::Black);
    f->SetPosition(posx+(sizex/6)*4,posy+(sizey/2));
    _listeauswahl[3] = f;

    f = new sf::Shape();
    *f = sf::Shape::Circle(0,0,10,sf::Color::Yellow,0.f,sf::Color::Black);
    f->SetPosition(posx+(sizex/6)*5,posy+(sizey/2));
    _listeauswahl[4] = f;

}
//-----------------------------------------------------------------------------
void CAuswahl::draw(sf::RenderWindow &window)
{
    window.Draw(*_rahmen);

    for(int i=0; i<6;i++)
    {
        sf::Shape *s = _listeauswahl[i];
        if(s != 0)
            window.Draw(*s);
    }
}
//-----------------------------------------------------------------------------
bool CAuswahl::onClick(int posx, int posy)
{
    sf::Rect<int> r= this->getRect();

    if(posx > r.Left && posx < r.Right &&
       posy > r.Top  && posy < r.Bottom)
    {
        return true;
    }
    return false;
}
//-----------------------------------------------------------------------------
sf::Rect<int>  CAuswahl::getRect()
{
    return sf::Rect<int>(_posx,_posy,_posx+_sizex,_posy+_sizey);
}
//-----------------------------------------------------------------------------
void CAuswahl::setColor(int nr)
{
    for(int i=0;i<4;i++)
        _listeauswahl[i]->SetOutlineWidth(0.f);
    switch(nr)
    {
    case(1):
        *_color = sf::Color::Red;
        _listeauswahl[0]->SetOutlineWidth(2.f);
        break;
    case(2):
        *_color = sf::Color::Green;
        _listeauswahl[1]->SetOutlineWidth(2.f);
        break;
     case(3):
        *_color = sf::Color::Blue;
        _listeauswahl[2]->SetOutlineWidth(2.f);
        break;
    case(4):
        *_color = sf::Color::Cyan;
        _listeauswahl[3]->SetOutlineWidth(2.f);
        break;
    case(5):
        *_color = sf::Color::Yellow;
        _listeauswahl[4]->SetOutlineWidth(2.f);
        break;
    }
}
//-----------------------------------------------------------------------------
sf::Color CAuswahl::getcolor()
{
    return *_color;
}
