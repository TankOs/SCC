#include "CSpielFeld.hpp"
#include <iostream>

CSpielFeld::CSpielFeld()
{
}
//-----------------------------------------------------------------------------
CSpielFeld::CSpielFeld(int posx, int posy, int size): _posx(posx),
                                                      _posy(posy),
                                                      _size(size),
                                                      _pincolor(0)
{
    _Rahmen = new sf::Shape();
    _Punkt  = new sf::Shape();

    *_Rahmen = sf::Shape::Rectangle(0,0,size,size,sf::Color(255,255,255,255),2.f,sf::Color::Black);
    _Rahmen->SetPosition(posx,posy);

    *_Punkt = sf::Shape::Circle(0,0,(size/2)-10,sf::Color(255,255,255),1.f,sf::Color::Black);
    _Punkt->SetColor(sf::Color(150,150,150));
    _Punkt->SetPosition((size/2)+posx,(size/2)+posy);
}
//-----------------------------------------------------------------------------
void CSpielFeld::Draw(sf::RenderWindow &window)
{
   window.Draw(*_Rahmen);
   window.Draw(*_Punkt);
}
//-----------------------------------------------------------------------------
void CSpielFeld::setBGColor()
{
    _Rahmen->SetColor(sf::Color(255,255,0));
}
//-----------------------------------------------------------------------------
sf::Rect<int> CSpielFeld::getRect()
{
    return sf::Rect<int>(_posx,_posy,_posx+_size,_posy+_size);
}
//-----------------------------------------------------------------------------
void CSpielFeld::setcolorPin(sf::Color c)
{
    if(c == sf::Color::Red)
        _pincolor = 1;
    else if(c == sf::Color::Green)
        _pincolor = 2;
    else if(c == sf::Color::Blue)
        _pincolor = 3;
    else if(c == sf::Color::Cyan)
        _pincolor = 4;
    else if(c == sf::Color::Yellow)
        _pincolor = 5;

    _Punkt->SetColor(c);
}
//-----------------------------------------------------------------------------
int CSpielFeld::getPinColor()
{
    return _pincolor;
}
