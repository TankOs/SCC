#ifndef CBOARD_HPP
#define CBOARD_HPP

#include <SFML/Graphics.hpp>
#include <vector>
#include "TDynamic2DVector.hpp"
#include "CSpielFeld.hpp"
#include "CCheckFeld.hpp"
#include "CSpielStatus.hpp"
class CBoard
{
protected:
    TDynamic2DVector<CSpielFeld*>  _feld;
    std::vector<CCheckFeld*> _checkfeld;
    std::vector<int> _code;
    int _aktiveline;
    int _codesize;
    CSpielStatus *status;
    //--
    void genCode();
public:
    CBoard();
    CBoard(int posx, int posy, CSpielStatus *s);
    CBoard(int posx, int posy, CSpielStatus *s, int codesize);
    void draw(sf::RenderWindow &window);
    bool onClick(int posx, int posy);
    void addPin(int pos, sf::Color c);
    void check();

};

#endif // CBOARD_HPP
