#ifndef CSPIELFELD_HPP
#define CSPIELFELD_HPP

#include <SFML/Graphics.hpp>

class CSpielFeld
{
protected:
    sf::Shape *_Rahmen;
    sf::Shape *_Punkt;
    int _posx, _posy, _size;
    int _pincolor;
public:
    CSpielFeld();
    CSpielFeld(int posx, int posy, int size);
    void Draw(sf::RenderWindow &window);
    void setBGColor();
    void setcolorPin(sf::Color c);
    int getPinColor();

    sf::Rect<int> getRect();
};

#endif // CSPIELFELD_HPP
