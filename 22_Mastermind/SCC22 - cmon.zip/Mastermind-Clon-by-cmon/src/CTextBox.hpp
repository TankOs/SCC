#ifndef CTEXTBOX_HPP
#define CTEXTBOX_HPP

#include <SFML/Graphics.hpp>

class CTextBox
{
protected:
    sf::Shape _rahmen;
    sf::String _name;
    std::string _leertext;
    std::string _inhalt;
    int _posx, _posy, _sizex, _sizey;
public:
    CTextBox(int posx,int posy,int sizex,int sizey,std::string name=std::string(""),std::string leer=std::string("Bitte Name eigeben"));
    void draw(sf::RenderWindow &window);
    void addtext(char c);
    bool isempty();
    std::string gettext();
    void clear();

};

#endif // CTEXTBOX_HPP
