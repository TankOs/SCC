#include "CTime.hpp"
#include <sstream>
CTime::CTime()
{
    _time = sf::String("Zeit: 0",sf::Font::GetDefaultFont(), 15.f);
    _time.SetPosition(450,15);
}
//-----------------------------------------------------------------------------
void CTime::draw(sf::RenderWindow &window)
{
    window.Draw(_time);
}
//-----------------------------------------------------------------------------
void CTime::update()
{
    std::stringstream tmp;
    tmp << "Zeit: " << (int)_clock.GetElapsedTime();
    _lasttime = _clock.GetElapsedTime();
    _time.SetText(tmp.str());
}
//-----------------------------------------------------------------------------
void CTime::reset()
{
    _clock.Reset();
}

float CTime::getlasttime()
{
    return _lasttime;
}
