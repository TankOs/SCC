#include "CBoard.hpp"
#include "CSpielStatus.hpp"
#include <iostream>
CBoard::CBoard()
{
}
//-----------------------------------------------------------------------------
CBoard::CBoard(int posx, int posy, CSpielStatus *s): _feld(10,4),
                                                     _checkfeld(10),
                                                     _code(4),
                                                     _aktiveline(9),
                                                     status(s)
{
    int size = 50;
    for(int i=9; i>=0;i--)
    {
        CCheckFeld *d = new CCheckFeld(posx+200,posy+(i*size),size);
        _checkfeld[i] = d;

        for(int j=0;j<4;j++)
        {
            CSpielFeld *f;
            f = new CSpielFeld(posx+(j*size),posy+(i*size),size);
            _feld[i][j] = f;
        }
    }

    for(int i=0; i<4; i++)
    {
        _feld[_aktiveline][i]->setBGColor();
    }
    _checkfeld[_aktiveline]->setBGColor();

    this->genCode();

}
//-----------------------------------------------------------------------------
/*CBoard::CBoard(int posx, int posy, CSpielStatus *s, int codesize): _feld(10,4),
                                                                    _checkfeld(10),
                                                                    _code(4),
                                                                    _aktiveline(9),
                                                                    _codesize(codesize),
                                                                    status(s)
{
    int size = 50;
    for(int i=9; i>=0;i--)
    {
        CCheckFeld *d = new CCheckFeld(posx+size*codesize,posy+(i*size),size);
        _checkfeld[i] = d;

        for(int j=0;j<codesize;j++)
        {
            CSpielFeld *f;
            f = new CSpielFeld(posx+(j*size),posy+(i*size),size);
            _feld[i][j] = f;
        }
    }

    for(int i=0; i<codesize; i++)
    {
        _feld[_aktiveline][i]->setBGColor();
    }
    _checkfeld[_aktiveline]->setBGColor();

    this->genCode();
}*/
//-----------------------------------------------------------------------------
void CBoard::draw(sf::RenderWindow &window)
{
    for(int i=0; i<10;i++)
    {
        CCheckFeld *f =_checkfeld[i];
        f->draw(window);

        for(int j=0;j<4;j++)
        {
            _feld[i][j]->Draw(window);
        }
    }
}
//-----------------------------------------------------------------------------
bool CBoard::onClick(int posx, int posy)
{
    for(int i=0; i<10;i++)
    {
        for(int j=0;j<4;j++)
        {
            sf::Rect<int> r= _feld[i][j]->getRect();
            if(posx > r.Left && posx < r.Right &&
               posy > r.Top  && posy < r.Bottom)
                return true;
        }
    }

    return false;

}
//-----------------------------------------------------------------------------
void CBoard::addPin(int pos, sf::Color c)
{
    _feld[_aktiveline][pos]->setcolorPin(c);
}
//-----------------------------------------------------------------------------
void CBoard::check()
{

    for(int i=0; i<4;i++)
    {
        if(_feld[_aktiveline][i]->getPinColor() == 0)
            return;
    }


    int rot = 0;
    int weis = 0;
    int test[4], test2[2];
    for(int i=0;i<4;i++)
    {
        test[i] =0;
        test2[i] =0;
    }

    for(int i=0; i<4;i++)
    {
        if(_feld[_aktiveline][i]->getPinColor() == _code[i])
        {
            weis++;
            test[i]=1;
            test2[i]=1;
        }
    }

    for(int i=0;i<4;i++)
    {
        if(test[i] == 0)
        {
            for(int j=0; j<4;j++)
            {
                if(test2[j] == 0 && _feld[_aktiveline][j]->getPinColor() == _code[i])
                {
                    rot++;
                    test[i]=1;
                    test2[j]=1;
                }
            }
        }
    }
    _checkfeld[_aktiveline]->setPinCode(weis, rot);

    if(weis == 4)
    {
        status->setStatus(win);
        return;
    }

    if(_aktiveline-- > 0)
    {
        for(int i=0; i<4; i++)
            _feld[_aktiveline][i]->setBGColor();
        _checkfeld[_aktiveline]->setBGColor();
    }
    else
    {
        status->setStatus(lose);
    }
}
//-----------------------------------------------------------------------------
void CBoard::genCode()
{
    _code[0] = sf::Randomizer::Random(1, 5);
    _code[1] = sf::Randomizer::Random(1, 5);
    _code[2] = sf::Randomizer::Random(1, 5);
    _code[3] = sf::Randomizer::Random(1, 5);

    std::cout << _code[0] << "/"
              << _code[1] << "/"
              << _code[2] << "/"
              << _code[3] << std::endl;
}
