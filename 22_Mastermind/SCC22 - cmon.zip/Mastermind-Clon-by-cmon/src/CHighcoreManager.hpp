#ifndef CHIGHCOREMANAGER_HPP
#define CHIGHCOREMANAGER_HPP

#include <string>
#include <vector>
#include <SFML/Graphics.hpp>

class CHighcoreManager
{
public:
    struct eintrag
    {
        std::string name;
        std::string zeit;
    };
protected:
    std::vector<eintrag> _liste;

public:
    CHighcoreManager();
    ~CHighcoreManager();
    void addScore(std::string name, float zeit);
    void draw(sf::RenderWindow &window);
    void saveHighscore();
    void loadHighscore();
};

#endif // CHIGHCOREMANAGER_HPP
