#include "CCheckFeld.hpp"

CCheckFeld::CCheckFeld()
{
}
//-----------------------------------------------------------------------------
CCheckFeld::CCheckFeld(int posx, int posy, int size): _posx(posx),
                                                      _posy(posy),
                                                      _size(size)
{
    _rahmen = new sf::Shape();
    _lineX  = new sf::Shape();
    _lineY  = new sf::Shape();

    *_rahmen = sf::Shape::Rectangle(0,0,size,size,sf::Color(255,255,255),2.f,sf::Color::Black);
    _rahmen->SetPosition(posx,posy);

    *_lineX = sf::Shape::Line(0,0,size,0,1.f,sf::Color::Black);
    _lineX->SetPosition(posx,posy+(size/2));

    *_lineY = sf::Shape::Line(0,0,0,size,1.f,sf::Color::Black);
    _lineY->SetPosition(posx+(size/2),posy);

    for(int i=0; i<4;i++)
        _points[i] = new sf::Shape();

}
//-----------------------------------------------------------------------------
void CCheckFeld::draw(sf::RenderWindow &window)
{

    window.Draw(*_rahmen);
    window.Draw(*_lineX);
    window.Draw(*_lineY);
    for(int i=0; i<4;i++)
        window.Draw(*_points[i]);

}
//-----------------------------------------------------------------------------
void CCheckFeld::setBGColor()
{
    _rahmen->SetColor(sf::Color(255,255,0,255));
}
//-----------------------------------------------------------------------------
void CCheckFeld::setPinCode(int weis, int rot)
{
    for(int i=0; i<weis;i++)
        *_points[i] = sf::Shape::Circle(0,0,5,sf::Color::White);
    for(int i=0; i<rot;i++)
        *_points[i+weis] = sf::Shape::Circle(0,0,5,sf::Color::Red);

    _points[0]->SetPosition(_posx+(_size/4),_posy+(_size/4));
    _points[1]->SetPosition(_posx+(_size/4)*3,_posy+(_size/4));

    _points[2]->SetPosition(_posx+(_size/4),_posy+(_size/4)*3);
    _points[3]->SetPosition(_posx+(_size/4)*3,_posy+(_size/4)*3);
}
