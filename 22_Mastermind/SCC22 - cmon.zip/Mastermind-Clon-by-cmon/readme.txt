So hier ist mein Beitrag, er ist zwar nicht besonders gewurden, bin aber froh das ich das was jetzt drin ist überhaupt zusammen bekommen habe.

Steuerung:
Leider keine Maus Steuerung :(
Auswahl der Farben F1 - F5
Platzieren mit 1,2,3,4
Wenn eine Reihe voll ist mit "return" check starten.

rot: Bedeute richtige Farbe, falsche Stelle
weiß: Farbe richtig und Stelle richtig
Code wird in der Konsole angezeigt, die Zahl steht für die "F"-Taste

SFML-Version: 1.6

