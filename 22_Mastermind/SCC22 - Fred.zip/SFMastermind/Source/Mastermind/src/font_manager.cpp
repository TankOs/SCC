/*************************************************
** file:	font_manager.cpp					**
** date:	2011-08-09							**
** author:	Frederik Simon						**
*************************************************/
#include "pch.h"
#include "font_manager.h"

font_manager::font_manager() : fonts_(), resource_directories_()
{
}

font_manager::~font_manager()
{
    fonts_.clear();
    resource_directories_.clear();
}

const sf::Font& font_manager::get_font( const std::string& filename )
{
	std::cout << "GAME_INFO: Loading font " << filename << ".\n";

    // Check, whether the font already exists
	for( std::map<std::string, sf::Font>::const_iterator it = fonts_.begin();
         it != fonts_.end(); 
         ++it)
    {
        if( filename == it->first )
        {
            //std::cout << "DEBUG_MESSAGE: " << filename << " using existing font.\n";
            return it->second;
        }
    }

    // The font doesen't exists. Create it and save it.
	sf::Font font;

    // Search project's main directory
    if( font.LoadFromFile( filename ) )
    {
		fonts_[filename] = font;
        return fonts_[filename];
    }


    // If the font has still not been found, search all registered directories
    for( std::vector< std::string >::iterator it = resource_directories_.begin();
         it != resource_directories_.end();
         ++it )
    {
        if( font.LoadFromFile( (*it) + filename ) )
        {
            fonts_[filename] = font;
            return fonts_[filename];
        }

    }

    std::cout << "GAME_ERROR: font was not found.\n";
    fonts_[filename] = font;
    return fonts_[filename];
}

void font_manager::delete_font( const sf::Font& font )
{
    for( std::map<std::string, sf::Font>::const_iterator it = fonts_.begin();
         it != fonts_.end(); 
         ++it)
    {
        if( &font == &it->second )
        {
            fonts_.erase( it );
                        return;
        }
    }
}

void font_manager::delete_font( const std::string& filename )
{
    std::map<std::string, sf::Font>::const_iterator it = fonts_.find( filename );
    if( it != fonts_.end() )
        fonts_.erase( it );
}

void font_manager::add_resource_directory( const std::string& directory )
{
    // Check whether the path already exists
    for( std::vector<std::string>::const_iterator it  = resource_directories_.begin();
         it != resource_directories_.end();
        ++it )
    {
        // The path exists. So it isn't necessary to add id once more.
        if( directory == (*it) )
            return;
    }

    // insert the directory
    resource_directories_.push_back( directory );
}

void font_manager::remove_resource_directory( const std::string& directory )
{
    for( std::vector<std::string>::const_iterator it  = resource_directories_.begin();
         it != resource_directories_.end(); )
    {
        // The path exists. So it isn't necessary to add id once more.
        if( directory == (*it) )
            it = resource_directories_.erase( it );
        else
            ++it;
    }
}