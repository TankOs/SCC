/*************************************************
** file:	gs_game.cpp							**
** date:	2011-09-18							**
** author:	Frederik Simon						**
*************************************************/
#include "pch.h"
#include "gs_game.h"

gs_game::gs_game( game_manager* game_manager, game_environment& game_env ) : game_state( *game_manager, game_env, "game" ), scale_(), bg_sprite_(), bg_question_(), bg_end_(), time_text_(), end_first_line_(), end_second_line_(), end_third_line_(), current_player_text_(), game_over_( false ), bg_trials_(), buttons_(), solution_(), active_line_(0), remaining_time_(120000), current_player_(PL_FIRST), game_mode_(GM_STD), all_games_count_(1), won_games_count_(0)
{
	current_time_[0] = 0;
	current_time_[1] = 0;

	std::srand( std::time(0) );

	// initialise background
	bg_sprite_.SetTexture( game_env_.texture_manager.get_texture( "bg.png" ) );

	scale_ = sf::Vector2f( sf::Vector2f( static_cast<float>( game_env_.window.GetHeight() ) / bg_sprite_.GetSize().y , static_cast<float>( game_env_.window.GetHeight() ) / bg_sprite_.GetSize().y ) );

	bg_sprite_.SetScale( scale_ );
	bg_sprite_.SetPosition( -(bg_sprite_.GetSize().x - game_env_.window.GetWidth())/2.0f  , -(bg_sprite_.GetSize().y - game_env_.window.GetHeight())/2.0f );

	bg_question_.SetTexture( game_env_.texture_manager.get_texture( "question.png" ) );
	bg_question_.SetScale( scale_ );
	bg_question_.SetPosition( -(bg_question_.GetSize().x - game_env_.window.GetWidth())/2.0f  , 0.0f );

	bg_end_.SetTexture( game_env_.texture_manager.get_texture( "win.png" ) );
	bg_end_.SetScale( scale_ );
	bg_end_.SetPosition( (game_env_.window.GetWidth() - bg_end_.GetSize().x )/2.0f  , ( game_env_.window.GetHeight() - bg_end_.GetSize().y )/2.0f );

	end_first_line_.SetCharacterSize( 70 );
	end_first_line_.SetScale( scale_ );
	end_first_line_.SetString( "Code geknackt!" );
	end_first_line_.SetPosition( bg_end_.GetPosition().x + ( bg_end_.GetSize().x - end_first_line_.GetRect().Width)/2.0f , bg_end_.GetPosition().y + 30.0f * scale_.y );

	end_second_line_.SetCharacterSize( 65 );
	end_second_line_.SetScale( scale_ );
	end_second_line_.SetString( "in" );
	end_second_line_.SetPosition( bg_end_.GetPosition().x + ( bg_end_.GetSize().x - end_second_line_.GetRect().Width)/2.0f , bg_end_.GetPosition().y + 150.0f * scale_.y );

	end_third_line_.SetCharacterSize( 70 );
	end_third_line_.SetScale( scale_ );
	end_third_line_.SetString( "00:00 Minuten" );
	end_third_line_.SetPosition( bg_end_.GetPosition().x + ( bg_end_.GetSize().x - end_third_line_.GetRect().Width)/2.0f , bg_end_.GetPosition().y + 240.0f * scale_.y );

	current_player_text_.SetCharacterSize( 50 );
	current_player_text_.SetScale( scale_ );
	current_player_text_.SetString( "Spieler 1" );
	current_player_text_.SetPosition( 10.0f, 10.0f );

	//time_text_.SetFont( game_env_.font_manager.get_font( "arial.ttf" ));
	time_text_.SetString( "00:00" );
	time_text_.SetColor( sf::Color( 30, 30, 30 ) );
	time_text_.SetPosition( game_env_.window.GetWidth() - time_text_.GetRect().Width - 20.0f, 10.0f );

	// initialise background-trial-bars
	for( int i = 0; i < 7; ++i )
	{
		sf::Sprite sp;
		sp.SetTexture( game_env_.texture_manager.get_texture( "next.png" ) );
		sp.SetScale( scale_ );
		sp.SetPosition( -(sp.GetSize().x - game_env_.window.GetWidth())/2.0f, (930 - i * 130.0f) * scale_.y );
		bg_trials_.push_back( sp );
	}
}

gs_game::~gs_game()
{
	this->destroy_buttons();
}

void gs_game::on_enter( const parameter_map& params )
{
	game_over_ = false;
	current_time_[0] = 0;
	current_time_[1] = 0;
	current_player_ = PL_FIRST;
	current_player_text_.SetString( "Spieler 1" );

	params_ = parameter_map::empty;

	std::string game_mode = params.get_parameter( "game_mode" );
	if( game_mode == "time" )
	{
		game_mode_ = GM_TIME;
	}
	else if( game_mode == "multi" )
	{
		game_mode_ = GM_MULTI;
	}
	else
	{
		game_mode_ = GM_STD;
	}

	this->generate_new_game();
}

void gs_game::on_leave()
{
	this->destroy_buttons();
}

void gs_game::on_resume( const parameter_map& params )
{
	params_ = parameter_map::empty;
}

void gs_game::on_pause()
{
	this->destroy_buttons();
}

void gs_game::update()
{
	// computate time in seconds
	unsigned int time = (game_mode_ == GM_TIME) ? (remaining_time_ - current_time_[current_player_])/1000 : current_time_[current_player_]/1000;
	unsigned int minutes = time / 60;
	unsigned int seconds = time % 60;
	// update time text
	std::stringstream time_stream;
	time_stream << ((minutes < 10) ? "0" : "") << minutes << ":" << ((seconds < 10) ? "0" : "") << seconds;
	time_text_.SetString( time_stream.str() );


	for( int i = 0; i < sf::Keyboard::KeyCount; ++i )
	{
		if( sf::Keyboard::IsKeyPressed( sf::Keyboard::Key(i) ) && key_states_[i] == KS_NONE )
			key_states_[i] = KS_PRESSED;
		else if(sf::Keyboard::IsKeyPressed( sf::Keyboard::Key(i) ) && key_states_[i] == KS_PRESSED )
			key_states_[i] = KS_DOWN;
		else if( !sf::Keyboard::IsKeyPressed( sf::Keyboard::Key(i) ) && ( key_states_[i] == KS_PRESSED || key_states_[i] == KS_DOWN ) )
			key_states_[i] = KS_RELEASED;
		else if( !sf::Keyboard::IsKeyPressed( sf::Keyboard::Key(i) ) )
			key_states_[i] = KS_NONE;
	}

	if( this->get_key_state( sf::Keyboard::Escape ) == KS_PRESSED )
		this->exit_game();

	/* You shall not cheat ;-)
	if( this->get_key_state( sf::Keyboard::H ) == KS_PRESSED )
	{
		for( int i = 0; i < solution_.size(); ++i )
		{
			solution_[i].second.SetTexture( game_env_.texture_manager.get_texture( button::color_to_filename( solution_[i].first ) ) );
		}
	}*/

	if( !game_over_ )
	{
		if( this->get_key_state( sf::Keyboard::Return ) == KS_PRESSED )
			this->check_solution();
	

		for( unsigned int j = 0; j < buttons_[active_line_].size(); ++j )
		{
			buttons_[active_line_][j]->update( game_env_.window);
		}

		current_time_[current_player_] += game_env_.window.GetFrameTime();

		if( game_mode_ == GM_TIME && (remaining_time_ - current_time_[current_player_]) <= 0 )
		{
			if( static_cast<float>(won_games_count_) / static_cast<float>(all_games_count_) < 0.75 )
				bg_end_.SetTexture( game_env_.texture_manager.get_texture( "lose.png" ) );
			bg_end_.SetPosition( (game_env_.window.GetWidth() - bg_end_.GetSize().x )/2.0f  , ( game_env_.window.GetHeight() - bg_end_.GetSize().y )/2.0f );

			end_first_line_.SetCharacterSize( 70 );
			end_first_line_.SetString( "Zeit abgelaufen!" );
			end_first_line_.SetPosition( bg_end_.GetPosition().x + ( bg_end_.GetSize().x - end_first_line_.GetRect().Width)/2.0f , bg_end_.GetPosition().y + 30.0f * scale_.y);

			std::stringstream text;
			text << won_games_count_ << " von " << all_games_count_;

			end_second_line_.SetCharacterSize( 100 );
			end_second_line_.SetString( text.str() );
			end_second_line_.SetPosition( bg_end_.GetPosition().x + ( bg_end_.GetSize().x - end_second_line_.GetRect().Width)/2.0f , bg_end_.GetPosition().y + 110.0f * scale_.y );

			end_third_line_.SetCharacterSize( 70 );
			end_third_line_.SetString( "Codes geknackt" );
			end_third_line_.SetPosition( bg_end_.GetPosition().x + ( bg_end_.GetSize().x - end_third_line_.GetRect().Width)/2.0f , bg_end_.GetPosition().y + 240.0f * scale_.y );

			game_over_ = true;
		}
	}
	else
	{
		if( this->get_key_state( sf::Keyboard::Return ) == KS_PRESSED )
			this->exit_game();
	}
}

void gs_game::draw()
{
	// Draw background
	game_env_.window.Draw( bg_sprite_ );
	game_env_.window.Draw( bg_question_ );

	for( unsigned int i = 0; i < bg_trials_.size(); ++i )
	{
		game_env_.window.Draw( bg_trials_[i] );
	}

	for( unsigned int i = 0; i < solution_.size(); ++i )
	{
		game_env_.window.Draw( solution_[i].second );
	}

	for( unsigned int i = 0; i < buttons_.size(); ++i )
	{
		for( unsigned int j = 0; j < buttons_[i].size(); ++j )
		{
			buttons_[i][j]->draw( game_env_.window );
		}
	}

	game_env_.window.Draw( time_text_ );

	if( game_mode_ == GM_MULTI )
	{
		game_env_.window.Draw( current_player_text_ );
	}

	if( game_over_ )
	{
		game_env_.window.Draw( bg_end_ );
		game_env_.window.Draw( end_first_line_ );
		game_env_.window.Draw( end_second_line_ );
		game_env_.window.Draw( end_third_line_ );
	}
}

const key_state& gs_game::get_key_state( const sf::Keyboard::Key& key ) const
{
	return key_states_[ key ];
}

void gs_game::exit_game()
{
	state_continue_flag_ = SCF_QUIT;
}

void gs_game::check_solution()
{
	// Check the solution
	bool correct = true;
	// copy correct colors to prevent that the original data is manipulated
	std::vector< color > solution_colors;
	for( unsigned int i = 0; i < solution_.size(); ++i )
	{
		solution_colors.push_back( solution_[i].first );
	}
	unsigned int correct_stones = 0;
	unsigned int correct_color = 0;
	for( unsigned int i = 0; i < buttons_[active_line_].size() && i < solution_.size(); ++i )
	{
		if( buttons_[active_line_][i]->get_color() == BLACK )
		{
			return;
		}
		if( buttons_[active_line_][i]->get_color() == solution_colors[i] )
		{
			// Color and position is correct. Add a black stone
			++correct_stones;
			solution_colors[i] = color( solution_colors[i] + RED_SOLVED );
		}
	}
	for( unsigned int i = 0; i < buttons_[active_line_].size() && i < solution_.size(); ++i )
	{
		if( buttons_[active_line_][i]->get_color() != solution_[i].first )
		{
			correct = false;

			// Search solution to check, whether color is correct at wrong position
			for( unsigned int j = 0; j < solution_.size(); ++j )
			{
				// Position is not correct, but maybe the color.
				if( buttons_[active_line_][i]->get_color() == solution_colors[j] && j != i)
				{
					++correct_color;
					solution_colors[j] = color( solution_colors[i] + RED_SOLVED );
					break;
				}
			}
		}
	}

	// Update line to show what the result is
	for( int i = 0; i < correct_stones; ++i )
	{
		buttons_[active_line_][i]->set_texture_filename( button::color_to_filename( color( buttons_[active_line_][i]->get_color() + RED_DARK ) ) );
	}
	for( int i = correct_stones; i < correct_stones + correct_color; ++i )
	{
		buttons_[active_line_][i]->set_texture_filename( button::color_to_filename( color( buttons_[active_line_][i]->get_color() + RED_WHITE ) ) );
	}


	if( correct && game_mode_ == GM_STD )
	{
		for( int i = 0; i < solution_.size(); ++i )
		{
			solution_[i].second.SetTexture( game_env_.texture_manager.get_texture( button::color_to_filename( solution_[i].first ) ) );
		}

		end_third_line_.SetString( time_text_.GetString() + " Minuten" );
		game_over_ = true;
	}
	else if( correct && game_mode_ == GM_TIME )
	{
		++all_games_count_;
		++won_games_count_;
		this->generate_new_game();
		return;
	}
	else if( correct && game_mode_ == GM_MULTI )
	{
		if( all_games_count_ >= 3 && current_player_ == PL_SECOND )
		{
			end_first_line_.SetCharacterSize( 70 );
			end_first_line_.SetString( "Codes geknackt!" );
			end_first_line_.SetPosition( bg_end_.GetPosition().x + ( bg_end_.GetSize().x - end_first_line_.GetRect().Width)/2.0f , bg_end_.GetPosition().y + 30.0f * scale_.y);

			std::stringstream text;
			text << "Spieler " << ((current_time_[0] < current_time_[1]) ? "1" : "2") ;
			if( current_time_[0] == current_time_[1] )
			{
				text.clear();
				text << "Keiner";
			}

			end_second_line_.SetCharacterSize( 100 );
			end_second_line_.SetString( text.str() );
			end_second_line_.SetPosition( bg_end_.GetPosition().x + ( bg_end_.GetSize().x - end_second_line_.GetRect().Width)/2.0f , bg_end_.GetPosition().y + 110.0f * scale_.y );

			end_third_line_.SetCharacterSize( 70 );
			end_third_line_.SetString( "war der Schnellste" );
			end_third_line_.SetPosition( bg_end_.GetPosition().x + ( bg_end_.GetSize().x - end_third_line_.GetRect().Width)/2.0f , bg_end_.GetPosition().y + 240.0f * scale_.y );

			game_over_ = true;
		}
		else
		{
			if( current_player_ == PL_SECOND )
			{
				++all_games_count_;
				current_player_ = PL_FIRST;
				current_player_text_.SetString( "Spieler 1" );
				this->generate_new_game();
				return;
			}
			else
			{
				current_player_ = PL_SECOND;
				current_player_text_.SetString( "Spieler 2" );
				this->generate_new_game();
				return;
			}
		}
	}

	if( active_line_ < bg_trials_.size() - 1 )
	{
		// Go to the next line
		bg_trials_[active_line_].SetTexture( game_env_.texture_manager.get_texture( "past.png" ) );
		++active_line_;
		bg_trials_[active_line_].SetTexture( game_env_.texture_manager.get_texture( "active.png" ) );
	}
	else if( game_mode_ != GM_TIME )
	{
		// Game is over
		//game_over_ = true;
		std::vector< button* > new_buttons = buttons_.front();
		buttons_.pop_front();
		for( unsigned int i = 0; i < buttons_.size(); ++i )
		{
			for( unsigned int j = 0; j < buttons_[i].size(); ++j )
			{
				buttons_[i][j]->move( sf::Vector2f( 0.0f, 130.0f * scale_.y ) );
			}
		}

		for( unsigned int i = 0; i < new_buttons.size(); ++i )
		{
			new_buttons[i]->move( sf::Vector2f( 0.0f, -(6.0f * 130.0f * scale_.y) ) );
			new_buttons[i]->set_color( BLACK );
		}
		buttons_.push_back( new_buttons );
	}
	else
	{
		++all_games_count_;
		this->generate_new_game();
	}
}

void gs_game::generate_new_game()
{
	for( unsigned int i = 0; i < bg_trials_.size(); ++i )
	{
		bg_trials_[i].SetTexture( game_env_.texture_manager.get_texture( "next.png" ) );
	}

	active_line_ = 0;
	bg_trials_[active_line_].SetTexture( game_env_.texture_manager.get_texture( "active.png" ) );

	// initialise buttons
	destroy_buttons();
	for( unsigned int i = 0; i < bg_trials_.size(); ++i )
	{
		std::vector< button* > buttons;
		sf::Vector2f button_size =  sf::Vector2f(  game_env_.texture_manager.get_texture( "black.png" ).GetWidth() *  scale_.x, game_env_.texture_manager.get_texture( "black.png" ).GetHeight() * scale_.y );
		sf::Vector2f pos = bg_trials_[i].GetPosition();
		pos.y += ( (bg_trials_[i].GetSize().y - button_size.y )/2.0f );
		pos.x = ((game_env_.window.GetWidth() - (button_size.x + 10.0f) * 4.0f)/2.0f - (button_size.x + 10.0f));
		for( int j = 0; j < 4; ++j )
		{
			pos.x += (button_size.x + 10.0f);
			button* bu = new button( game_env_, pos, BLACK, scale_ );
			buttons.push_back( bu );
		}
		buttons_.push_back( buttons );
	}

	for( int i = 0; i < sf::Keyboard::KeyCount; ++i )
	{
		key_states_[i] = KS_NONE;
	}

	std::vector< color > colors;
	for( int i = 0; i < BLACK; ++i )
	{
		colors.push_back( color( i ) );
	}
	std::random_shuffle( colors.begin(), colors.end() );

	// generate solution
	for( int i = 0; i < 4; ++i )
	{
		sf::Sprite sp;
		sp.SetTexture( game_env_.texture_manager.get_texture( "black.png" /* button::color_to_filename( color(col) ) */) );
		sp.SetScale( scale_ );
		sp.SetPosition( ((game_env_.window.GetWidth() - (sp.GetSize().x + 10.0f) * 4.0f )/2.0f + i * (sp.GetSize().x + 10.0f)), 10.0f * scale_.y );
		solution_.push_back( std::make_pair( colors[i], sp ) );

		//std::cout << colors[i] << "\t";
	}
}

void gs_game::destroy_buttons()
{
	for( unsigned int i = 0; i < buttons_.size(); ++i )
	{
		for( unsigned int j = 0; j < buttons_[i].size(); ++j )
		{
			delete buttons_[i][j];
		}
	}
	buttons_.clear();

	solution_.clear();
}