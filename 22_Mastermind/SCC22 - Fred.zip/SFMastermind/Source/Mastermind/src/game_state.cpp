/*************************************************
** file:	game_state.cpp						**
** date:	2011-08-09							**
** author:	Frederik Simon						**
*************************************************/
#include "pch.h"
#include "game_state.h"

unsigned int game_state::screenshot_number_ = 0;

game_state::game_state( game_manager& game_manager, 
						game_environment& game_env, 
						const std::string& state_name ) :	game_env_( game_env ),
															is_paused_( false ),
															params_( parameter_map::empty ),
															state_continue_flag_( SCF_CONTINUE )
{
	// register game state in game-manager
	game_manager.register_game_state( state_name, this );

	std::cout << "GAME_INFO: Game-State " << state_name << " was successfully registered." << std::endl;

	// Count existing screenshots
	unsigned int screenshots_num = 0;
	screenshot_number_ = screenshots_num;
}

game_state::~game_state()
{
	std::cout << "GAME_INFO: Game-State has been destroyed" << std::endl;
}

void game_state::on_enter( const parameter_map& params )
{
}

void game_state::on_leave()
{
}

void game_state::on_pause()
{
}

void game_state::on_resume( const parameter_map &params )
{
}

void game_state::update()
{
}

void game_state::draw()
{
}

parameter_map game_state::get_parameter_map() const
{
	return params_;
}

const state_continue_flags& game_state::get_state_continue_flag() const
{
	return state_continue_flag_;
}

void game_state::set_state_continue_flag( const state_continue_flags& new_flag )
{
	state_continue_flag_ = new_flag;
}