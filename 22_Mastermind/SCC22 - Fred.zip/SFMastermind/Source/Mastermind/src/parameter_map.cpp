/*************************************************
** file:	parameter_map.cpp					**
** date:	2011-08-09							**
** author:	Frederik Simon						**
*************************************************/
#include "pch.h"
#include "parameter_map.h"

parameter_map parameter_map::empty;

parameter_map::parameter_map() : parameter_()
{
}

parameter_map::parameter_map(const parameter_map &param_map) : parameter_(param_map.parameter_)
{
}

parameter_map::~parameter_map()
{
	parameter_.clear();
}

parameter_map& parameter_map::operator =(const parameter_map &param_map)
{
	parameter_ = param_map.parameter_;
	return *this;
}

parameter_map& parameter_map::operator =(const std::map<std::string,std::string> std_map)
{
	parameter_ = std_map;
	return *this;
}

void parameter_map::set_parameter(std::string parameter, std::string value)
{
	parameter_[parameter] = value;
}

std::string parameter_map::get_parameter( const std::string& parameter) const
{
	std::map<std::string, std::string>::const_iterator param_it = parameter_.find(parameter);
	return param_it == parameter_.end() ? "" : param_it->second;
}

bool parameter_map::exists_parameter( const std::string& parameter) const
{
	std::map<std::string, std::string>::const_iterator param_it = parameter_.find(parameter);
	return param_it == parameter_.end() ? false : true;
}