/*************************************************
** file:	fade_manager.cpp					**
** date:	2011-09-21							**
** author:	Frederik Simon						**
*************************************************/
#include "pch.h"
#include "fade_manager.h"

fade_manager::fade_manager( game_environment& game_env ) : game_env_( game_env ), fading_objects_()
{
}

fade_manager::~fade_manager()
{
	fading_objects_.clear();
}

void fade_manager::update()
{
	for( std::vector< std::pair< unsigned int, sf::Sprite* > >::iterator it = fading_objects_.begin();
		 it != fading_objects_.end(); )
	{
		if( it->second->GetColor().a > it->first - 5 && it->second->GetColor().a < it->first + 5 )
		{
			it->second->SetColor( sf::Color( 255, 255, 255, it->first ) );
			it = fading_objects_.erase( it );
		}
		else
		{
			if( it->second->GetColor().a < it->first )
			{
				it->second->SetColor( sf::Color( 255, 255, 255, it->second->GetColor().a + 0.5 * game_env_.window.GetFrameTime() ) );
			}
			else
			{
				if( it->second->GetColor().a - 0.5 * game_env_.window.GetFrameTime() < 0 )
				{
					it->second->SetColor( sf::Color( 255, 255, 255, it->first ) );
					it = fading_objects_.erase( it );
					continue;
				}
				else
					it->second->SetColor( sf::Color( 255, 255, 255, it->second->GetColor().a - 0.5 * game_env_.window.GetFrameTime() ) );
			}
			++it;
		}
	}
}

void fade_manager::add_object( sf::Sprite* sprite, unsigned int opacity )
{
	fading_objects_.push_back( std::make_pair( opacity, sprite ) );
}