/*************************************************
** file:	game_manager.cpp					**
** date:	2011-08-09							**
** author:	Frederik Simon						**
*************************************************/
#include "pch.h"
#include "game_manager.h"
#include "game_state.h"
#include "gs_game.h"
#include "gs_main_menu.h"
#include "game_environment.h"
#include "texture_manager.h"
#include "font_manager.h"

game_manager::game_manager( const std::string& game_title ) : game_title_( game_title ),
															  game_env_(),
															  texture_manager_(),
															  font_manager_(),
															  window_(),
															  registered_game_states_(),
															  active_game_states_()
{
}

game_manager::~game_manager()
{
	registered_game_states_.clear();
	active_game_states_.clear();

	delete game_env_;
	delete texture_manager_;
	delete font_manager_;
	delete window_;
}

void game_manager::run( unsigned int width, unsigned int height, bool fullscreen )
{
	this->initialize( width, height, fullscreen );
	this->update();
}

bool game_manager::register_game_state( const std::string& state_name, game_state* state )
{
	if( this->get_game_state_by_name( state_name ) )
	{
		std::cout << "GAME_WARNING: game state " << state_name << " has already been registered.\n";
		return false;
	}

	// Spielzustand registrieren
	registered_game_states_[state_name] = state;

	std::cout << "GAME_INFO: game state " << state_name << " was successfully registered.\n";
	return true;
}

bool game_manager::unregister_game_state( const std::string& state_name )
{
	if( !get_game_state_by_name( state_name ) )
	{
		std::cout << "GAME_WARNING: game state " << state_name << " was not found. Hence it is not necessary to delete it.\n";
		return false;
	}

	// Spielzustand l�schen
	registered_game_states_.erase( state_name );

	std::cout << "GAME_INFO: game state " << state_name << " was successfully removed.\n";
	return true;
}

bool game_manager::change_state( const std::string& new_state_name, const parameter_map& params )
{
	// Gibt es einen solchen Spielzustand?
	game_state* new_state = get_game_state_by_name( new_state_name );
	if(!new_state)
	{
		std::cout << "GAME_WARNING: game state " << new_state_name << " was not found. It is not possible to load the new state.\n";
		return false;
	}

	// leave old game state
	if(!active_game_states_.empty())
	{
		active_game_states_.back()->on_leave();
		active_game_states_.pop_back();
	}

	// Neuen Spielzustand aktivieren
	active_game_states_.push_back( new_state );
	active_game_states_.back()->on_enter( params );

	return true;
}

bool game_manager::push_state( const std::string new_state_name, const parameter_map& params )
{
	// Gibt es einen solchen Spielzustand?
	game_state* new_state = get_game_state_by_name( new_state_name );
	if(!new_state)
	{
		std::cout << "GAME_WARNING: game state " << new_state_name << " was not found. It is not possible to load the new state.\n";
		return false;
	}

	// pause old game state
	if(!active_game_states_.empty())
	{
		active_game_states_.back()->on_pause();
	}

	// Neuen Spielzustand aktivieren
	active_game_states_.push_back( new_state );
	active_game_states_.back()->on_enter(params);

	return true;
}

bool game_manager::pop_state()
{
	// leave active state
	if(!active_game_states_.empty())
	{
		active_game_states_.back()->on_leave();
		active_game_states_.pop_back();
	}

	// If there is still another old state, resume it.
	if(!active_game_states_.empty())
	{
		active_game_states_.back()->on_resume( );
	}

	return true;
}

game_state* game_manager::get_game_state_by_name( const std::string& state_name )
{
	std::map<std::string, game_state*>::const_iterator it = registered_game_states_.find( state_name );
	return it == registered_game_states_.end() ? 0 : it->second;
}

void game_manager::initialize( unsigned int width, unsigned int height, bool fullscreen )
{
	if( width == 0 )
		window_ = new sf::RenderWindow( sf::VideoMode::GetDesktopMode(), game_title_, !fullscreen ? sf::Style::Fullscreen : sf::Style::Default, sf::ContextSettings( 24, 8, 16, 2, 0 ) );
	else
		window_ = new sf::RenderWindow( sf::VideoMode( width, height, 32 ), game_title_, fullscreen ? sf::Style::Fullscreen : sf::Style::Default, sf::ContextSettings( 24, 8, 16, 2, 0 ) );
	texture_manager_ = new texture_manager();
	font_manager_ = new font_manager();

	font_manager_->add_resource_directory( "media/fonts/" );
	texture_manager_->add_resource_directory( "media/" );
	texture_manager_->add_resource_directory( "media/bg/" );
	texture_manager_->add_resource_directory( "media/buttons/" );
	
	game_env_ = new game_environment( *texture_manager_, *font_manager_, *window_ );
}

void game_manager::update()
{

	window_->SetFramerateLimit( 60 );

	gs_game game( this, *game_env_ );
	gs_main_menu main_menu( this, *game_env_ );

	this->push_state( "main_menu" );

	while( !active_game_states_.empty() && window_->IsOpened() )
	{
		sf::Event current_event;
		while( window_->PollEvent( current_event ) )
		{
			// Close the window
			if( current_event.Type == sf::Event::Closed )
			{
				window_->Close();
				active_game_states_.back()->set_state_continue_flag( SCF_QUIT_ALL );
			}
		}

		window_->Clear();

		// update active game state
		active_game_states_.back()->update();

		// Draw active game state
		active_game_states_.back()->draw();

		window_->Display();

		const game_state& state = (*active_game_states_.back());

		// Check whether the current state may continue
		if( state.get_state_continue_flag() == SCF_PAUSE && state.get_parameter_map().exists_parameter("new_state") )
		{
			std::string new_state = state.get_parameter_map().get_parameter( "new_state" );
			push_state( new_state, state.get_parameter_map() );
		}
		else if( state.get_state_continue_flag() == SCF_QUIT )
		{
			parameter_map params = state.get_parameter_map();
			if( params.exists_parameter("new_state") )
				push_state( state.get_parameter_map().get_parameter( "new_state" ), state.get_parameter_map() );
			else
				pop_state();
		}
		else if( state.get_state_continue_flag() == SCF_QUIT_ALL )
		{
			while( !active_game_states_.empty() )
			{
				pop_state();
			}
		}

		if( !active_game_states_.empty() )
			active_game_states_.back()->set_state_continue_flag( SCF_CONTINUE );
	}
}