/*************************************************
** file:	gs_main_menu.cpp					**
** date:	2011-09-19							**
** author:	Frederik Simon						**
*************************************************/
#include "pch.h"
#include "game_environment.h"
#include "game_manager.h"
#include "gs_main_menu.h"
#include "menu_button.h"
#include "overlay.h"

gs_main_menu::gs_main_menu( game_manager* game_manager, game_environment& game_env ) : game_state( *game_manager, game_env, "main_menu" ), bg_sprite_(), bg_title_(), bg_fade_(), first_button_(), second_button_(), third_button_(), help_button_(), credits_button_(), quit_button_(), help_overlay_(), credits_overlay_(), mastermind_text_(), fade_manager_( game_env_ )
{	
	// initialise background
	bg_sprite_.SetTexture( game_env_.texture_manager.get_texture( "bg.png" ) );

	sf::Vector2f scale = sf::Vector2f( sf::Vector2f( static_cast<float>( game_env_.window.GetHeight() ) / bg_sprite_.GetSize().y , static_cast<float>( game_env_.window.GetHeight() ) / bg_sprite_.GetSize().y ) );

	bg_sprite_.SetScale( scale );
	bg_sprite_.SetPosition( -(bg_sprite_.GetSize().x - game_env_.window.GetWidth())/2.0f  , -(bg_sprite_.GetSize().y - game_env_.window.GetHeight())/2.0f );
	
	bg_title_.SetTexture( game_env_.texture_manager.get_texture( "question.png" ) );
	bg_title_.SetScale( scale );
	bg_title_.SetPosition( -(bg_title_.GetSize().x - game_env_.window.GetWidth())/2.0f  , 0.0f );

	bg_fade_.SetTexture( game_env_.texture_manager.get_texture( "fade.png" ) );
	bg_fade_.SetColor( sf::Color( 0, 0, 0, 0 ) );

	first_button_ = new menu_button( *this, game_env );
	first_button_->set_texture( "menu_first.png" );
	first_button_->set_hover_texture( "menu_first_hover.png" );
	first_button_->set_on_click_func( &gs_main_menu::start_game );
	first_button_->set_scale( scale );
	first_button_->set_position( sf::Vector2f( (game_env_.window.GetWidth() - first_button_->get_size().x)/2.0f, 250.0f * scale.y ) );
	// Text of the button
	sf::Text text;
	text.SetString( "Zeitspiel" );
	text.SetCharacterSize( 40 );
	first_button_->set_text( text );

	second_button_ = new menu_button( *this, game_env );
	second_button_->set_texture( "menu_second.png" );
	second_button_->set_hover_texture( "menu_second_hover.png" );
	second_button_->set_on_click_func( &gs_main_menu::start_time_trial );
	second_button_->set_scale( scale );
	second_button_->set_position(  sf::Vector2f( (game_env_.window.GetWidth() - second_button_->get_size().x)/2.0f, 380.0f * scale.y ) );
	text.SetString( "Kampf gegen die Zeit" );
	second_button_->set_text( text );

	third_button_ = new menu_button( *this, game_env );
	third_button_->set_texture( "menu_third.png" );
	third_button_->set_hover_texture( "menu_third_hover.png" );
	third_button_->set_on_click_func( &gs_main_menu::start_multiplayer );
	third_button_->set_scale( scale );
	third_button_->set_position(  sf::Vector2f( (game_env_.window.GetWidth() - third_button_->get_size().x)/2.0f, 520.0f * scale.y ) );
	text.SetString( "Kopf an Kopf" );
	third_button_->set_text( text );

	help_button_ = new menu_button( *this, game_env );
	help_button_->set_texture( "button_footer.png" );
	help_button_->set_hover_texture( "button_footer_hover.png" );
	help_button_->set_on_click_func( &gs_main_menu::start_help );
	help_button_->set_scale( scale );
	help_button_->set_position( sf::Vector2f( (game_env_.window.GetWidth() - help_button_->get_size().x)/2.0f, 740.0f * scale.y ));
	text.SetString( "Spielanleitung" );
	help_button_->set_text( text );

	credits_button_ = new menu_button( *this, game_env );
	credits_button_->set_texture( "button_footer.png" );
	credits_button_->set_hover_texture( "button_footer_hover.png" );
	credits_button_->set_on_click_func( &gs_main_menu::start_credits );
	credits_button_->set_scale( scale );
	credits_button_->set_position( sf::Vector2f( (game_env_.window.GetWidth() - credits_button_->get_size().x)/2.0f, 865.0f * scale.y ));
	text.SetString( "Credits" );
	credits_button_->set_text( text );

	quit_button_ = new menu_button( *this, game_env );
	quit_button_->set_texture( "button_footer.png" );
	quit_button_->set_hover_texture( "button_footer_hover.png" );
	quit_button_->set_on_click_func( &gs_main_menu::exit_main_menu );
	quit_button_->set_scale( scale );
	quit_button_->set_position( sf::Vector2f( (game_env_.window.GetWidth() - quit_button_->get_size().x)/2.0f, 990.0f * scale.y ));
	text.SetString( "Spiel Beenden" );
	quit_button_->set_text( text );

	help_overlay_ = new overlay( game_env_, "overlay.png", scale );
	help_overlay_->set_title( "Mastermind - Anleitung" );
	help_overlay_->set_text( "Aufgabe ist es einen Code zu knacken, den der Computer generiert. Dieser Code besteht aus 4 von 6 verschiedenen Farben. Im Spielbildschirm sind mehrere Leisten mit Schwarzen Buttons zu sehen. Die aktive Leiste ist durch ein sehr helles gr�n gekennzeichnet. In dieser Leiste kann man durch einen Klick mit der linken bzw. rechten Maustaste, eine Farbe vor bzw. zur�ck schalten und so die entsprechende Farbkombination ausw�hlen. Mit der Enter-Taste best�tigt man seine Auswahl. Anschlie�end ver�ndert sich die Farbe des Unterteils der Button. Ein schwarzer Button bedeutet, dass es einen Button gibt, dessen Farbe und Position korrekt ist. Ein wei�es Unterteil bedeutet, dass zwar die Farbe eines Buttons korrekt ist, aber seine Position falsch ist. Wichtig zu wissen ist, dass die untere Buttonfarbe dann in keiner Relation zur oberen Buttonfarbe stehen. Ein schwarzes Unterteil sagt also lediglich aus, dass ein beliebiger Stein korrekt sitzt, aber nicht, dass genau dieser korrekt ist." );

	credits_overlay_ = new overlay( game_env_, "overlay.png", scale );
	credits_overlay_->set_title( "Credits" );
	credits_overlay_->set_text( "Game Design: Frederik Simon\nProgrammierung: Frederik Simon\nGrafik: Frederik Simon\nF�r dieses Spiel kam die \"Simple and Fast Media Library\"(SFML) zum Einsatz.\nBei der Entwicklung dieses Spiels kamen keine Tiere zu Schanden." );

	mastermind_text_.SetString( "Simple Fancy Mastermind" );
	//mastermind_text_.SetFont( game_env_.font_manager.get_font( "CharlemagneStd.otf" ) );
	mastermind_text_.SetCharacterSize( 70 );
	mastermind_text_.SetScale( scale );
	mastermind_text_.SetColor( sf::Color( 22, 45, 80 ) );
	mastermind_text_.SetPosition( (game_env_.window.GetWidth() - mastermind_text_.GetRect().Width) / 2.0f, 5.0f * scale.y );
}

gs_main_menu::~gs_main_menu()
{
	delete first_button_;
	delete second_button_;
	delete third_button_;
	delete help_button_;
	delete credits_button_;
	delete quit_button_;
	delete help_overlay_;
	delete credits_overlay_;
}

void gs_main_menu::on_enter( const parameter_map& params )
{
	params_ = parameter_map::empty;
}

void gs_main_menu::on_leave()
{
}

void gs_main_menu::on_resume( const parameter_map& params )
{
	params_ = parameter_map::empty;
}

void gs_main_menu::on_pause()
{
}

void gs_main_menu::update()
{
	if( sf::Keyboard::IsKeyPressed( sf::Keyboard::Back ) )
		this->exit_main_menu();
	else if( sf::Keyboard::IsKeyPressed( sf::Keyboard::Return ))
		this->start_game();

	if( !help_overlay_->is_visible() && !credits_overlay_->is_visible() )
	{
		first_button_->update();
		second_button_->update();
		third_button_->update();
		help_button_->update();
		credits_button_->update();
		quit_button_->update();
	}

	help_overlay_->update();
	credits_overlay_->update();

	if( help_overlay_->get_current_state() == OS_MOVE_NOW_OUT || credits_overlay_->get_current_state() == OS_MOVE_NOW_OUT )
	{
		fade_manager_.add_object( &bg_fade_, 0 );
	}

	fade_manager_.update();
}

void gs_main_menu::draw()
{
	game_env_.window.Draw( bg_sprite_ );
	game_env_.window.Draw( bg_title_ );
	game_env_.window.Draw( mastermind_text_ );

	first_button_->draw();
	second_button_->draw();
	third_button_->draw();
	help_button_->draw();
	credits_button_->draw();
	quit_button_->draw();

	game_env_.window.Draw( bg_fade_ );

	help_overlay_->draw();
	credits_overlay_->draw();
}

void gs_main_menu::exit_main_menu()
{
	state_continue_flag_ = SCF_QUIT;
}

void gs_main_menu::start_game()
{
	state_continue_flag_ = SCF_PAUSE;
	params_.set_parameter( "new_state", "game" );
	params_.set_parameter( "game_mode", "std" );
}

void gs_main_menu::start_time_trial()
{
	state_continue_flag_ = SCF_PAUSE;
	params_.set_parameter( "new_state", "game" );
	params_.set_parameter( "game_mode", "time" );
}

void gs_main_menu::start_multiplayer()
{
	state_continue_flag_ = SCF_PAUSE;
	params_.set_parameter( "new_state", "game" );
	params_.set_parameter( "game_mode", "multi" );
}

void gs_main_menu::start_help()
{
	help_overlay_->set_visible( true );
	fade_manager_.add_object( &bg_fade_, 150 );
}

void gs_main_menu::start_credits()
{
	credits_overlay_->set_visible( true );
	fade_manager_.add_object( &bg_fade_, 150 );
}