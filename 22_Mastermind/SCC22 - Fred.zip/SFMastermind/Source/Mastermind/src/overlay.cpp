/*************************************************
** file:	overlay.cpp							**
** date:	2011-09-20							**
** author:	Frederik Simon						**
*************************************************/
#include "pch.h"
#include "overlay.h"

overlay::overlay( game_environment& game_env, const std::string& overlay_texture, const sf::Vector2f& scale ) : game_env_( game_env ), overlay_(), title_(), text_(), target_position_( sf::Vector2f(0,0) ), state_( OS_INVISIBLE )
{
	overlay_.SetTexture( game_env_.texture_manager.get_texture( overlay_texture ) );
	overlay_.SetScale( scale );
	overlay_.SetPosition( (game_env_.window.GetWidth() - overlay_.GetSize().x)/2.0f, game_env_.window.GetHeight() );
	target_position_ = sf::Vector2f( (game_env_.window.GetWidth() - overlay_.GetSize().x)/2.0f, game_env_.window.GetHeight() - overlay_.GetSize().y );

	title_.SetCharacterSize( 50 );
	title_.SetPosition( overlay_.GetPosition() + sf::Vector2f( 40.0f, 5.0f ) );

	text_.SetCharacterSize( 30 );
	text_.SetPosition( overlay_.GetPosition() + sf::Vector2f( 50.0f, 80.0f ) );

	target_position_ = sf::Vector2f( (game_env_.window.GetWidth() - overlay_.GetSize().x)/2.0f, game_env_.window.GetHeight() - (100.0f + text_.GetRect().Height ) );
}

overlay::~overlay()
{
}

void overlay::update()
{
	if( state_ == OS_MOVE_IN )
	{
		if( overlay_.GetPosition().y > target_position_.y - 8.0f && overlay_.GetPosition().y < target_position_.y + 8.0f )
		{
			overlay_.SetPosition( target_position_ );
			state_ = OS_SHOW;
		}
		else
		{
			overlay_.Move( 0.0f, -0.8f * game_env_.window.GetFrameTime() );
		}

		title_.SetPosition( overlay_.GetPosition() + sf::Vector2f( 40.0f, 5.0f ) );
		text_.SetPosition( overlay_.GetPosition() + sf::Vector2f( 50.0f, 70.0f ) );
	}
	else if( state_ == OS_MOVE_OUT || state_ == OS_MOVE_NOW_OUT  )
	{
		if( overlay_.GetPosition().y > game_env_.window.GetHeight() - 8.0f && overlay_.GetPosition().y < game_env_.window.GetHeight() + 8.0f )
		{
			overlay_.SetPosition( overlay_.GetPosition().x, game_env_.window.GetHeight() );
			state_ = OS_INVISIBLE;
		}

		else
		{
			overlay_.Move( 0.0f, 0.8f * game_env_.window.GetFrameTime() );
		}

		title_.SetPosition( overlay_.GetPosition() + sf::Vector2f( 40.0f, 5.0f ) );
		text_.SetPosition( overlay_.GetPosition() + sf::Vector2f( 50.0f, 70.0f ) );

		if( state_ == OS_MOVE_NOW_OUT )
			state_ = OS_MOVE_OUT;
	}

	if( state_ == OS_SHOW )
	{
		float object_x = overlay_.GetPosition().x;
		float object_y = overlay_.GetPosition().y;
		float object_width = overlay_.GetSize().x;
		float object_height = overlay_.GetSize().y;
		float mouse_x = sf::Mouse::GetPosition( game_env_.window ).x;
		float mouse_y = sf::Mouse::GetPosition( game_env_.window ).y;

		if( (mouse_x < object_x || mouse_x > (object_x + object_width) || mouse_y < object_y || mouse_y > object_y + object_height) && sf::Mouse::IsButtonPressed( sf::Mouse::Left ) )
		{
			state_ = OS_MOVE_NOW_OUT;
		}
	}
}

void overlay::draw()
{
	if( state_ != OS_INVISIBLE )
	{
		game_env_.window.Draw( overlay_ );
		game_env_.window.Draw( title_ );
		game_env_.window.Draw( text_ );
	}
}

void overlay::set_visible( bool visible )
{
	if( visible )
		state_ = OS_MOVE_IN;
	else
		state_ = OS_INVISIBLE;
}

bool overlay::is_visible() const
{
	return (state_ != OS_INVISIBLE);
}

void overlay::set_text( const std::string& text )
{
	// List for all words of the text
	std::deque< std::string > words;

	// find words and push them to the lis
	unsigned int start_pos = 0;
	unsigned int pos = text.find_first_of(' ', 0);
	while( pos <= text.size() )
	{
		words.push_back( text.substr( start_pos, pos - start_pos ) );
		start_pos = pos + 1;
		pos = text.find_first_of(' ', start_pos );
	}
	// last word
	words.push_back( text.substr( start_pos ) );
	
	std::string text_stream;
	
	while( !words.empty() )
	{
		// Put the next word to the text
		text_.SetString( text_stream + words.front() + " " );
		// Check, whether the text still fits to the overlay
		if( text_.GetRect().Width <= overlay_.GetSize().x - 100.0f )
		{
			text_stream += words.front() + " ";
			words.pop_front();
		}
		else
		{
			// if not -> new line
			text_stream += "\n";
		}
	}

	target_position_ = sf::Vector2f( (game_env_.window.GetWidth() - overlay_.GetSize().x)/2.0f, game_env_.window.GetHeight() - (100.0f + text_.GetRect().Height ) );

}

void overlay::set_title( const std::string& title )
{
	title_.SetString( title );
}

const overlay_state& overlay::get_current_state() const
{
	return state_;
}

void overlay::set_state( const overlay_state& state )
{
	state_ = state;
}