/*************************************************
** file:	button.cpp							**
** date:	2011-09-18							**
** author:	Frederik Simon						**
*************************************************/
#include "pch.h"
#include "button.h"

button::button( game_environment& game_env, const sf::Vector2f& position, const color& col, const sf::Vector2f& scale ) : game_env_( game_env ), sprite_(), color_( col ), clicked_( false )
{
	sprite_.SetTexture( game_env_.texture_manager.get_texture( button::color_to_filename( col ) ) );
	sprite_.SetScale( scale );
	sprite_.SetPosition( position );
}

button::~button()
{
}

const std::string button::color_to_filename( const color& col )
{
	switch( col )
	{
		case RED:
			return "red.png";
		case BLUE:
			return "blue.png";
		case GREEN:
			return "green.png";
		case BROWN:
			return "brown.png";
		case CYAN:
			return "cyan.png";
		case PINK:
			return "pink.png";
		case RED_DARK:
			return "red_dark.png";
		case BLUE_DARK:
			return "blue_dark.png";
		case GREEN_DARK:
			return "green_dark.png";
		case BROWN_DARK:
			return "brown_dark.png";
		case CYAN_DARK:
			return "cyan_dark.png";
		case PINK_DARK:
			return "pink_dark.png";
		case RED_WHITE:
			return "red_white.png";
		case BLUE_WHITE:
			return "blue_white.png";
		case GREEN_WHITE:
			return "green_white.png";
		case BROWN_WHITE:
			return "brown_white.png";
		case CYAN_WHITE:
			return "cyan_white.png";
		case PINK_WHITE:
			return "pink_white.png";
		case BLACK:
		default:
			return "black.png";
			break;
	}
}

void button::update( sf::RenderWindow& window )
{
	float object_x = sprite_.GetPosition().x;
	float object_y = sprite_.GetPosition().y;
	float object_width = sprite_.GetSize().x;
	float object_height = sprite_.GetSize().y;
	float mouse_x = sf::Mouse::GetPosition( window ).x;
	float mouse_y = sf::Mouse::GetPosition( window ).y;

	if( sf::Mouse::IsButtonPressed( sf::Mouse::Left ) )
	{
		if( mouse_x > object_x && mouse_x < (object_x + object_width) && mouse_y > object_y && mouse_y < (object_y + object_height) && !clicked_ )
		{
			clicked_ = true;
			this->on_left_click();
		}
	}
	else if ( sf::Mouse::IsButtonPressed( sf::Mouse::Right ) )
	{
		if( mouse_x > object_x && mouse_x < (object_x + object_width) && mouse_y > object_y && mouse_y < (object_y + object_height) && !clicked_ )
		{
			clicked_ = true;
			this->on_right_click();
		}
	}
	else
		clicked_ = false;
}

void button::draw( sf::RenderWindow& window )
{
	window.Draw( sprite_ );
}

void button::set_color( const color& col )
{
	if( color_ != col )
	{
		color_ = col;
		sprite_.SetTexture( game_env_.texture_manager.get_texture( button::color_to_filename( col ) ) );
	}
}

const color& button::get_color() const
{
	return color_;
}

void button::set_texture_filename( const std::string& texture_filename )
{
	sprite_.SetTexture( game_env_.texture_manager.get_texture( texture_filename ) );
}

void button::move( const sf::Vector2f& offset)
{
	sprite_.Move( offset ); 
}

void button::on_left_click()
{
	int col = color_ + 1;
	if( col >= BLACK )
		col = 0;
	this->set_color( color( col ) );
}

void button::on_right_click()
{
	int col = color_ - 1;
	if( col < 0 )
		col = BLACK - 1;
	this->set_color( color( col ) );
}