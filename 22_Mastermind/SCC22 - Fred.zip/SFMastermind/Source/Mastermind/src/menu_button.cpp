/*************************************************
** file:	menu_button.cpp						**
** date:	2011-09-19							**
** author:	Frederik Simon						**
*************************************************/
#include "pch.h"
#include "menu_button.h"

menu_button::menu_button( gs_main_menu& main_menu, game_environment& game_env ) : game_env_( game_env ), sprite_(), button_text_(), hover_texture_(""), original_texture_(""), clicked_(false ), hover_(false), main_menu_( main_menu )
{
}

menu_button::~menu_button()
{
}

void menu_button::update()
{
	float object_x = sprite_.GetPosition().x;
	float object_y = sprite_.GetPosition().y;
	float object_width = sprite_.GetSize().x;
	float object_height = sprite_.GetSize().y;
	float mouse_x = sf::Mouse::GetPosition( game_env_.window ).x;
	float mouse_y = sf::Mouse::GetPosition( game_env_.window ).y;

	if( mouse_x > object_x && mouse_x < (object_x + object_width) && mouse_y > object_y && mouse_y < (object_y + object_height) && !clicked_ )
	{
		if( sf::Mouse::IsButtonPressed( sf::Mouse::Left ) )
		{
			clicked_ = true;
			this->on_left_click();
		}
		else if( !hover_ )
		{
			clicked_ = false;
			this->on_hover();
		}
	}
	else if( hover_ )
	{
		sprite_.SetTexture( game_env_.texture_manager.get_texture( original_texture_ ));
		clicked_ = false;
		hover_ = false;
	}
	else
		clicked_ = false;
}

void menu_button::draw()
{
	game_env_.window.Draw( sprite_ );
	game_env_.window.Draw( button_text_ );
}

void menu_button::set_scale( const sf::Vector2f& scale )
{
	sprite_.SetScale( scale );
}

void menu_button::set_texture( const std::string& texture_filename )
{
	original_texture_ = texture_filename;
	sprite_.SetTexture( game_env_.texture_manager.get_texture( original_texture_ ));
}

void menu_button::set_hover_texture( const std::string& texture_filename )
{
	hover_texture_ = texture_filename;
}

void menu_button::set_position( const sf::Vector2f& position )
{
	sprite_.SetPosition( position );
}

void menu_button::set_on_click_func( void (gs_main_menu::*on_click)() )
{
	on_click_func = on_click;
}

void menu_button::set_text( sf::Text& text )
{
	text.SetPosition( (game_env_.window.GetWidth() - text.GetRect().Width)/2.0f, sprite_.GetPosition().y + (sprite_.GetSize().y - text.GetRect().Height) / 2.0f );
	button_text_ = text;
}

sf::Text& menu_button::get_text()
{
	return button_text_;
}

sf::Vector2f menu_button::get_size() const
{
	return sprite_.GetSize();
}

void menu_button::on_left_click()
{
	(main_menu_.*on_click_func)();
}

void menu_button::on_hover()
{
	sprite_.SetTexture( game_env_.texture_manager.get_texture( hover_texture_ ));
	hover_ = true;
}