/*************************************************
** file:	main.cpp							**
** date:	2011-09-04							**
** author:	Frederik Simon						**
*************************************************/
#include "pch.h"
#include "game_manager.h"

int main( int argc, char* argv[] )
{
	unsigned int width = 0;
	unsigned int height = 0;
	bool fullscreen = false;

	std::stringstream args;

	if( argc > 2 )
	{
		args << argv[1];
		int i;
		args >> i;
		if( i > 1 )
		{
			width = i;		
			args.str("");
			args.clear();
			args << argv[2];
			args >> i;
			if( i > 1 )
				height = i;
			else
			{
				width = 0;
				height = 0;
			}
		}
		else
		{
			width = 0;
			height = 0;
		}

		if( argc > 3 )
		{
			args.str("");
			args.clear();
			args << argv[3];
			if( args.str() == "-f" )
			{
				fullscreen = true;
			}
		}
	}
	else if( argc > 1 )
	{
		args.str("");
		args.clear();
		args << argv[1];
		if( args.str() == "-w" )
		{
			// yes it will start windowed ;-)
			fullscreen = true;
		}
	}


	game_manager mmorpg("WOW2 - ehm... simple fancy mastermind");
	mmorpg.run( width, height, fullscreen );
	return 0;
}