/*************************************************
** file:	game_manager.h						**
** date:	2011-08-09							**
** author:	Frederik Simon						**
*************************************************/
#ifndef GAME_MANAGER_H_
#define GAME_MANAGER_H_

#include "parameter_map.h"

class game_state;
struct game_environment;
class texture_manager;
class font_manager;
class game_manager
{
public:
	game_manager( const std::string& game_title = "game" );
	~game_manager();

private:
	// Don't mess around with the copy-ctor
	game_manager( const game_manager& );
	game_manager& operator =( const game_manager& );

public:
	// will be called by the main-function and will call initialize and update methods.
	void		run( unsigned int width = 1024, unsigned int height = 768, bool fullscreen = false );

	// register a game state
	bool		register_game_state( const std::string& state_name, game_state* state );

	// unregister a game state
	bool		unregister_game_state( const std::string& state_name );

	// change game state - old state will be unloaded
	bool		change_state( const std::string& new_state_name, const parameter_map& parameters = parameter_map::empty );

	// change game state - old state will be  paused
	bool		push_state( const std::string new_state_name, const parameter_map& parameters = parameter_map::empty );

	// quit current state
	bool		pop_state();

	// Get a game game state by its name
	game_state* get_game_state_by_name( const std::string& state_name );

private:
	void initialize( unsigned int width, unsigned int height, bool fullscreen );
	void update();

private:
	const std::string game_title_;

	game_environment* game_env_;
	texture_manager* texture_manager_;
	font_manager* font_manager_;
	sf::RenderWindow* window_;

	std::map< std::string, game_state* > registered_game_states_;
	std::vector< game_state* > active_game_states_;

};

#endif