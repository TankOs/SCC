/*************************************************
** file:	pch.h								**
** date:	2011-09-18							**
** author:	Frederik Simon						**
*************************************************/

#ifndef PCH_H_
#define PCH_H_

// Standardbibliotheken
#include <iostream>
#include <string>
#include <sstream>
#include <list>
#include <map>
#include <vector>
#include <deque>
#include <algorithm>

// Externe Bibliotheken
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

// Libs
#ifndef _DEBUG
#pragma comment(lib, "sfml-main.lib")
#pragma comment(lib, "sfml-graphics.lib")
#pragma comment(lib, "sfml-window.lib")
#pragma comment(lib, "sfml-system.lib")
#else
#pragma comment(lib, "sfml-main-d.lib")
#pragma comment(lib, "sfml-graphics-d.lib")
#pragma comment(lib, "sfml-window-d.lib")
#pragma comment(lib, "sfml-system-d.lib")
#endif

#endif