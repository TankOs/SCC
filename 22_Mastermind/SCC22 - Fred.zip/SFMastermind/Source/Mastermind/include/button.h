/*************************************************
** file:	button.h							**
** date:	2011-09-18							**
** author:	Frederik Simon						**
*************************************************/
#ifndef BUTTON_H_
#define BUTTON_H_
#include "game_environment.h"

enum color
{
	RED,
	GREEN,
	BLUE,
	BROWN,
	CYAN,
	PINK,

	BLACK,

	RED_DARK,
	GREEN_DARK,
	BLUE_DARK,
	BROWN_DARK,
	CYAN_DARK,
	PINK_DARK,

	RED_WHITE,
	GREEN_WHITE,
	BLUE_WHITE,
	BROWN_WHITE,
	CYAN_WHITE,
	PINK_WHITE,

	RED_SOLVED,
	GREEN_SOLVED,
	BLUE_SOLVED,
	BROWN_SOLVED,
	CYAN_SOLVED,
	PINK_SOLVED
};

class button
{
public:
	button( game_environment& game_env, const sf::Vector2f& position, const color& col, const sf::Vector2f& scale );
	~button();

public:
	static const std::string	color_to_filename( const color& col );

public:
	void			update( sf::RenderWindow& window );
	void			draw( sf::RenderWindow& window );

	void			set_color( const color& col );
	const color&	get_color() const;

	void			set_texture_filename( const std::string& texture_filename );

	void			move( const sf::Vector2f& move );

private:
	void			on_left_click();
	void			on_right_click();

private:
	sf::Sprite sprite_;
	color color_;
	game_environment& game_env_;
	bool clicked_;
};

#endif