/*************************************************
** file:	fade_manager.h						**
** date:	2011-09-21							**
** author:	Frederik Simon						**
*************************************************/
#ifndef FADE_MANAGER_H_
#define FADE_MANAGER_H_

#include "game_environment.h"

class fade_manager
{
public:
	fade_manager( game_environment& game_env );
	~fade_manager();

public:
	void update();
	
	void add_object( sf::Sprite* sprite, unsigned int opacity = 255 );

private:
	game_environment& game_env_;
	std::vector< std::pair< unsigned int, sf::Sprite* > > fading_objects_;
};

#endif