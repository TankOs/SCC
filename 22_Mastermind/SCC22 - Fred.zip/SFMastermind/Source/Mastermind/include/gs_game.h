/*************************************************
** file:	gs_game.h							**
** date:	2011-09-18							**
** author:	Frederik Simon						**
*************************************************/
#ifndef GS_GAME_H_
#define GS_GAME_H_
#include "game_state.h"
#include "parameter_map.h"
#include "button.h"

class map;
enum key_state
{
	KS_NONE,
	KS_PRESSED,
	KS_RELEASED,
	KS_DOWN
};

enum game_mode
{
	GM_STD,
	GM_TIME,
	GM_MULTI
};

class gs_game : public game_state
{
public:
	gs_game( game_manager* game_manager, game_environment& game_env );
	~gs_game();

private:
	gs_game( const gs_game& );
	gs_game& operator =( const gs_game& );

public:
	void	on_enter( const parameter_map& params = parameter_map::empty);
	void	on_leave();
	void	on_resume( const parameter_map& params = parameter_map::empty );
	void	on_pause();

	void	update();
	void	draw();

public:
	const key_state& get_key_state( const sf::Keyboard::Key& key ) const;


private:
	void	exit_game();
	void	check_solution();
	void	generate_new_game();
	void	destroy_buttons();

public:
	enum player
	{
		PL_FIRST,
		PL_SECOND
	};

private:
	sf::Vector2f scale_;

	sf::Sprite bg_sprite_;
	sf::Sprite bg_question_;
	sf::Sprite bg_end_;
	sf::Text time_text_;
	sf::Text end_first_line_;
	sf::Text end_second_line_;
	sf::Text end_third_line_;
	sf::Text current_player_text_;
	bool game_over_;
	std::vector< sf::Sprite > bg_trials_;
	std::deque < std::vector< button* > > buttons_;
	std::vector< std::pair< color, sf::Sprite > > solution_;
	unsigned int active_line_;
	key_state key_states_[sf::Keyboard::KeyCount];
	long current_time_[2];
	player current_player_;
	
	game_mode game_mode_;
	long remaining_time_;
	unsigned int all_games_count_;
	unsigned int won_games_count_;
};

#endif