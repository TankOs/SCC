/*************************************************
** file:	parameter_map.h						**
** date:	2011-08-09							**
** author:	Frederik Simon						**
*************************************************/
#ifndef PARAMETER_MAP_H_
#define PARAMETER_MAP_H_

class parameter_map
{
public:
	parameter_map();
	parameter_map( const parameter_map& param_map );
	~parameter_map();

public:
	// Operator: = parameter_map
	parameter_map& operator =(const parameter_map& param_map);

	// Operator: = std::map
	parameter_map& operator =(const std::map<std::string, std::string> std_map);

public:
	static parameter_map empty;
	
public:
	void				set_parameter(std::string parameter, std::string value);
	std::string			get_parameter(const std::string& parameter) const;

	// Check whether a parameter exists
	bool				exists_parameter( const std::string& parameter ) const;

private:
	std::map<std::string, std::string> parameter_;
};

#endif