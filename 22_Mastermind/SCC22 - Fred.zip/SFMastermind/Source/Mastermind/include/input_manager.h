/*************************************************
** file:	input_manager.h						**
** date:	2011-08-09							**
** author:	Frederik Simon						**
*************************************************/
#ifndef INPUT_MANAGER_H_
#define INPUT_MANAGER_H_
class input_map;
class input_manager
{
public: 
	input_manager( sf::RenderWindow& window );
	~input_manager();

private:
	// The input-manager ist not supposed to be copied
	input_manager( const input_manager& );
	input_manager& operator =( const input_manager& );

public:
	// Check user input
	void				process_input();

	// Add an input map to the list
	void				register_input_map( const input_map& map );

	// Remove the input map which was last added.
	void				unregister_last_input_map();

	// Remove a certain input map
	void				unregister_input_map( const input_map& map );

	// Remove an input map with a certain name
	void				unregister_input_map( const std::string& name );

	// Remove all input maps
	void				unregister_all_input_maps();

private:
	sf::RenderWindow& window_;

	bool mouse_button_pressed_[sf::Mouse::ButtonCount];
	bool key_pressed_[sf::Keyboard::KeyCount];

	std::list< input_map > input_maps_;

};
#endif