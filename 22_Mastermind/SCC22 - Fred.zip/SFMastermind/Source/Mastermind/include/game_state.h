/*************************************************
** file:	game_state.h						**
** date:	2011-08-09							**
** author:	Frederik Simon						**
*************************************************/
#ifndef GAME_STATE_H_
#define GAME_STATE_H_

#include "game_environment.h"
#include "game_manager.h"
#include "parameter_map.h"

enum state_continue_flags
{
	SCF_CONTINUE,
	SCF_PAUSE,
	SCF_QUIT,
	SCF_QUIT_ALL
};

class game_state 
{
public:
	game_state( game_manager& game_manager, game_environment& game_env, const std::string& state_name );
	virtual ~game_state();

public:
	// Is called, if the game state is entered
	virtual void				on_enter( const parameter_map& params = parameter_map::empty );

	// Is called, if the game state is left
	virtual void				on_leave();
	
	// Is called, if the game state is paused
	virtual void				on_pause();

	// Is called if the game state is reentered again after a pause
	virtual void				on_resume( const parameter_map &params = parameter_map::empty );

	// update the game state
	virtual void				update();

	// draw the game state
	virtual void				draw();

	// Get the current parameters of the game state
	parameter_map				get_parameter_map() const;

	// Get current continue-flag of this game state
	const state_continue_flags&	get_state_continue_flag() const;

	// Set the current continue-flag of this state
	void						set_state_continue_flag( const state_continue_flags& new_flag );


protected:
	static unsigned int screenshot_number_;
	game_environment& game_env_;
	bool is_paused_;
	parameter_map params_;
	state_continue_flags state_continue_flag_;
};
#endif