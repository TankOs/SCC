/*************************************************
** file:	game_environment.h					**
** date:	2011-08-09							**
** author:	Frederik Simon						**
*************************************************/

#ifndef GAME_ENVIRONMENT_H_
#define GAME_ENVIRONMENT_H_

#include "texture_manager.h"
#include "font_manager.h"
#include "pch.h"

struct game_environment
{
	game_environment( texture_manager& texture_manager, font_manager& font_manager, sf::RenderWindow& window ) : texture_manager(texture_manager ),
																												 font_manager( font_manager ),
																												 window( window )
	{
	}

	texture_manager& texture_manager;
	font_manager& font_manager;
	sf::RenderWindow& window;
};

#endif