/*************************************************
** file:	menu_button.h						**
** date:	2011-09-19							**
** author:	Frederik Simon						**
*************************************************/
#ifndef MENU_BUTTON_H_
#define MENU_BUTTON_H_
#include "game_environment.h"
#include "gs_main_menu.h"

class menu_button
{
public:
	menu_button( gs_main_menu& main_menu, game_environment& game_env );
	~menu_button();

public:
	void				update();
	void				draw();

public:
	void				set_scale( const sf::Vector2f& scale );
	void				set_texture( const std::string& texture_filename );
	void				set_hover_texture( const std::string& hover_filename );
	void				set_position( const sf::Vector2f& position );
	void				set_on_click_func( void (gs_main_menu::*on_click)() );
	void				set_text( sf::Text& text );

	sf::Text&			get_text();
	sf::Vector2f		get_size() const;	
	
private:
	void			on_left_click();
	void			on_hover();

private:
	game_environment& game_env_;
	sf::Sprite sprite_;
	sf::Text button_text_;
	std::string hover_texture_;
	std::string original_texture_;
	bool clicked_;
	bool hover_;

	void (gs_main_menu::*on_click_func)();

	gs_main_menu& main_menu_;
};

#endif