/*************************************************
** file:	texture_manager.h					**
** date:	2011-08-09							**
** author:	Frederik Simon						**
*************************************************/

#ifndef TEXTURE_MANAGER_H_
#define TEXTURE_MANAGER_H_
class texture_manager
{
public:
	texture_manager();
	~texture_manager();

private:
	texture_manager( const texture_manager& );
	texture_manager& operator =( const texture_manager& );

public:
	const sf::Texture&	get_texture( const std::string& filename );
	void				delete_texture( const sf::Texture& texture );
	void				delete_texture( const std::string& filename );
	void				add_resource_directory( const std::string& directory );
	void				remove_resource_directory( const std::string& directory );

private:
	std::map< std::string, sf::Texture > textures_;
	std::vector< std::string > resource_directories_;
};
#endif