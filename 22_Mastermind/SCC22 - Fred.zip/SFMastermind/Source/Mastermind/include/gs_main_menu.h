/*************************************************
** file:	gs_main_menu.h						**
** date:	2011-09-19							**
** author:	Frederik Simon						**
*************************************************/
#ifndef GS_MAIN_MENU_H_
#define GS_MAIN_MENU_H_
#include "game_state.h"
#include "parameter_map.h"
#include "fade_manager.h"

class menu_button;
class overlay;
class gs_main_menu : public game_state
{
public:
	gs_main_menu( game_manager* game_manager, game_environment& game_env );
	~gs_main_menu();

private:
	gs_main_menu( const gs_main_menu& );
	gs_main_menu& operator =( const gs_main_menu& );

public:
	void	on_enter( const parameter_map& params = parameter_map::empty);
	void	on_leave();
	void	on_resume( const parameter_map& params = parameter_map::empty );
	void	on_pause();

	void	update();
	void	draw();

private:
	void	exit_main_menu();
	void	start_game();
	void	start_time_trial();
	void	start_multiplayer();
	void	start_credits();
	void	start_help();

private:
	sf::Sprite bg_sprite_;
	sf::Sprite bg_title_;
	
	sf::Sprite bg_fade_;

	menu_button* first_button_;
	menu_button* second_button_;
	menu_button* third_button_;
	menu_button* help_button_;
	menu_button* credits_button_;
	menu_button* quit_button_;

	overlay* help_overlay_;
	overlay* credits_overlay_;

	sf::Text mastermind_text_;

	fade_manager fade_manager_;
	

};

#endif

