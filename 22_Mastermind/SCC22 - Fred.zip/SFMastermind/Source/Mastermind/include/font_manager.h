/*************************************************
** file:	font_manager.h						**
** date:	2011-08-09							**
** author:	Frederik Simon						**
*************************************************/

#ifndef FONT_MANAGER_H_
#define FONT_MANAGER_H_
class font_manager
{
public:
	font_manager();
	~font_manager();

private:
	font_manager( const font_manager& );
	font_manager& operator =( const font_manager& );

public:
	const sf::Font&		get_font( const std::string& filename );
	void				delete_font( const sf::Font& font );
	void				delete_font( const std::string& filename );
	void				add_resource_directory( const std::string& directory );
	void				remove_resource_directory( const std::string& directory );

private:
	std::map< std::string, sf::Font > fonts_;
	std::vector< std::string > resource_directories_;
};
#endif