/*************************************************
** file:	overlay.h							**
** date:	2011-09-20							**
** author:	Frederik Simon						**
*************************************************/
#ifndef OVERLAY_H_
#define OVERLAY_H_
#include "game_environment.h"

enum overlay_state
{
	OS_INVISIBLE,
	OS_SHOW,
	OS_MOVE_IN,
	OS_MOVE_OUT,
	OS_MOVE_NOW_OUT
};

class overlay
{
public:
	overlay( game_environment& game_env_, const std::string& overlay_texture, const sf::Vector2f& scale );
	~overlay();

public:
	void					update();
	void					draw();
	void					set_visible( bool visible );
	bool					is_visible() const;
	void					set_text( const std::string& string );
	void					set_title( const std::string& title );
	const overlay_state&	get_current_state() const;
	void					set_state( const overlay_state& state );

private:
	game_environment& game_env_;

	sf::Sprite overlay_;
	sf::Text title_;
	sf::Text text_;

	sf::Vector2f target_position_;

	overlay_state state_;
};

#endif