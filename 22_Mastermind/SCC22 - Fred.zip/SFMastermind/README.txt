SFML-Community-Contest 22 Mastermind
Simple Fancy Mastermind(SFM) 
von Frederik Simon � 2011

Lizenz: GPLv3
Verwendete Bibliotheken: SFML 2 commit d6a40cf06202de4d05fb83e08844ebec6a6b8b43

Kurze Anleitung:
	Einfacher Mastermind-Klon. Aufgabe ist es einen Code zu knacken, den der Computer generiert. Dieser Code besteht aus 4 von 6 verschiedenen Farben. 
	Im Spielbildschirm sind mehrere Leisten mit Schwarzen Buttons zu sehen. Die aktive Leiste ist durch ein sehr helles gr�n gekennzeichnet. In dieser Leiste kann man durch einen Klick mit der linken bzw. rechten Maustaste, eine Farbe vor bzw. zur�ck schalten und so die entsprechende Farbkombination ausw�hlen. Mit der Enter-Taste best�tigt man seine Auswahl. Anschlie�end ver�ndert sich die Farbe des Unterteils der Button. Ein schwarzer Button bedeutet, dass es einen Button gibt, dessen Farbe und Position korrekt ist. Ein wei�es Unterteil bedeutet, dass zwar die Farbe eines Buttons korrekt ist, aber seine Position falsch ist.
	Wichtig zu wissen ist, dass die untere Buttonfarbe dann in keiner Relation zur oberen Buttonfarbe stehen. Ein schwarzes Unterteil sagt also lediglich aus, dass ein beliebiger Stein korrekt sitzt, aber nicht, dass genau dieser korrekt ist.
	Es gibt weiterhin 3 Spielmodi:
		Zeitspiel: Der Spieler versucht m�glichst schnell einen Code zu knacken, hat aber beliebig viele Versuche.
		Kampf gegen die Zeit: Der Spieler versucht so viele Codes wie m�glich in 2 Minuten zu knacken, hat f�r jeden Code aber maximal 7 Versuche.
		Kopf an Kopf: Dieser Spielmodus ist eine Art Hotseat-Modus. Hierbei treten zwei Spieler gegeneinander an. Es m�ssen 3 Codes geknackt werden. Immer abwechselnd. Derjenige, der am schnellsten ist gewinnt.
		
Anmerkung zur Verwendung:
	Das Spiel wurde mit Visual Studio 2010 programmiert und kompiliert. Daher ist es notwendig, um die Windows-Binaries ausf�hren zu k�nnen, 
	das Microsoft Visual C++ 2010 Redistributable Package herunter zu laden und zu installieren. Zu finden ist dieses unter folgenden Links:
	x64:
		http://www.microsoft.com/downloads/de-de/details.aspx?FamilyID=bd512d9e-43c8-4655-81bf-9350143d5867 
	x86:
		http://www.microsoft.com/download/en/details.aspx?id=5555
		
Anmerkung zum Start des Spiels:
	Ich habe im Spiel die M�glichkeit implementiert, das Spiel durch die Kommandozeile mit verschiedenen Argumenten zu starten.
		mastermind.exe width height [-f]
	Mit width und height kann man eine eigene Bildschirmaufl�sung angeben. Mit -f bestimmt man, ob das Spiel in dieser Aufl�sung im Vollbildmodus ausgef�hrt wird.
	Gibt man keine Argumente an, startet das Spiel standardm��ig im Vollbildmodus mit der aktuellen Bildschirmaufl�sung. Es ist jedoch auch folgendes m�glich:
		mastermind.exe -w
	Hierdurch gibt man explizit an, dass das Spiel im Fenstermodus gestartet werden soll(mit dem aktuellen Desktop-Video-Mode).
	In den Windows-Binaries befinden sich eine Verkn�pfung, mit der man das Spiel automatisch in 1024x768 im Fenstermodus ausf�hren kann.
	Das Spiel unterst�tzt auch h�here Aufl�sungen und sollte daher unter den meisten g�ngigen Aufl�sungen korrekt dargestellt werden. Auch hier bitte ich darum,
	sich bei fehlerhafter Darstellung an mich zu wenden: kontakt@fsoftworks.de
		
Anmerkung zur Version des Spiels:
	Man k�nnte dieses Spiel noch um beliebig viele Features erweitern, wie etwa einen Online-Highscore. Hierzu fehlte im Rahmen des Wettbewerbs jedoch die Zeit. 
	Dennoch befindet sich das Spiel in einem gut spielbaren Zustand und sollte funktionsf�hig sein. Es war mir zeitlich leider auch nicht m�glich eine intensive
	Testphase durchzuf�hren. 
	Folglich fungiert die Wettbewerbs-Jury gleichzeitig als Beta-Tester. Jeder, der dieses Spiel nun also spielt und einen Fehler findet, ist gebeten, mir diesen Fehler mit zu teilen.
	Per Mail an: kontakt@fsoftworks.de
	
Anmerkung zum Code:
	Es befindet sich in diesem Ordner nat�rlich auch der Quellcode des Spiels. Hierzu m�chte ich jedoch einige Anmerkungen machen. 
	Zum einen hat mich die Einschr�nkung, dass keine externen Bibliotheken verwendet werden d�rfen und auch keine Teile des C++11-Standards,
	etwas eingeschr�nkt. Diese Regeln sind selbstverst�ndlich gut und wichtig, normalerweise arbeite ich jedoch mit boost und C++11 und 
	daher wurden einige Punkte, die vorher eleganter gel�st waren, durch simple Workarounds ersetzt. Zum anderen ist mir aufgefallen, wie 
	effektiv man mit Zeitdruck arbeiten kann. Leider hat das nat�rlich zur Folge, dass man sich �ber manche Design-Punkte keine Gedanken macht,
	sondern lediglich schnell etwas zusammenbastelt, was funktioniert. Dies wirkt sich nat�rlich negativ auf den Code aus, ist aber in einem
	solchen Wettbewerb nicht anders m�glich.

	
Vielen Dank f�r das Herunterladen und Spielen und viel Spa� dabei.