#ifndef FontManager_h__
#define FontManager_h__

#include "ResourceManager.h"
#include <sfml/Graphics.hpp>

class FontManager : public ResourceManager<std::string, sf::Font>
{
protected:
	virtual sf::Font* Load(const std::string FileName);
};
#endif // FontManager_h__
