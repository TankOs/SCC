#include "Game.h"
#include "MainGameState.h"
#include <iostream>

//////////////////////////////////////////////////////////////////////////
Game::Game()
	: m_isRunning(true),
	m_window(sf::VideoMode(500, 600), "Puzzle Game"),
	m_stateManager(new MainGameState(*this))
{
	
}

//////////////////////////////////////////////////////////////////////////
void Game::Run()
{
	while(m_isRunning && m_window.IsOpened())
	{
		sf::Event event;
		while(m_window.PollEvent(event))
		{
			if (event.Type == sf::Event::Closed)
			{
				m_isRunning = false;
			}
			m_stateManager.ProcessEvent(event);
		}

		m_stateManager.Update();
		m_audioManager.Update();

		m_window.Clear(sf::Color::Black);
		m_stateManager.Draw();
		m_window.Display();
	}
}

//////////////////////////////////////////////////////////////////////////
void Game::Exit()
{
	m_isRunning = false;
}

//////////////////////////////////////////////////////////////////////////
StateManager& Game::GetStateManager()
{
	return m_stateManager;
}

//////////////////////////////////////////////////////////////////////////
TextureManager& Game::GetTextureManager()
{
	return m_textureManager;
}
//////////////////////////////////////////////////////////////////////////
AudioManager& Game::GetAudioManager()
{
	return m_audioManager;
}
//////////////////////////////////////////////////////////////////////////
FontManager& Game::GetFontManager()
{
	return m_fontManager;
}

//////////////////////////////////////////////////////////////////////////
sf::RenderWindow& Game::GetWindow()
{
	return m_window;
}

