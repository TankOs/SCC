#include "ImageManager.h"

sf::Texture* TextureManager::Load(const std::string FileName)
{
	// Neues Bild erstellen
	sf::Texture* texture = new sf::Texture();

	// Bild Laden
	if(!texture->LoadFromFile(FileName)) 
	{
		// Bild L�schen
		delete texture;
		texture = NULL;
		Logfile::GetInstance() << Warning << "Das Bild " << FileName << " konnte nicht geladen werden. Eine Ausnahme wird ausgeworfen!" << NewLine;
		THROW_EXCEPTION("Das Bild " + FileName + " konnte nicht geladen werden")
	}
	Logfile::GetInstance() << Info << "Das Bild " << FileName << " wurde erfolgreich geladen." << NewLine;
	return texture;
}
