#include "AudioManager.h"

//////////////////////////////////////////////////////////////////////////
AudioManager::~AudioManager()
{
	for(std::list<sf::Sound>::iterator It = m_Souds.begin(); It != m_Souds.end(); ++It)
	{
		It->Stop();
	}
	m_Souds.clear();
}

sf::SoundBuffer* AudioManager::Load( const std::string FileName )
{
	// Neuen Soundbuffer erstellen
	sf::SoundBuffer* SoundBuffer = new sf::SoundBuffer();

	// Soundbuffer laden
	if(!SoundBuffer->LoadFromFile(FileName)) 
	{
		// Bild L�schen
		delete SoundBuffer;
		SoundBuffer = NULL;
		Logfile::GetInstance() << Warning << "Der Sound " << FileName << " konnte nicht geladen werden. Eine Ausnahme wird ausgeworfen!" << NewLine;
		THROW_EXCEPTION("Der Sound " + FileName + " konnte nicht geladen werden")

	}
	Logfile::GetInstance() << Info << "Der Sound " << FileName << " wurde erfolgreich geladen." << NewLine;
	return SoundBuffer;
}

void AudioManager::PlaySound( const std::string& FileName, float Volume )
{
	sf::Sound Sound;
	m_Souds.push_back(Sound);
	m_Souds.back().SetVolume(Volume);
	m_Souds.back().SetBuffer(*GetResource(FileName));		
	m_Souds.back().Play();
}

void AudioManager::Update()
{
	for(std::list<sf::Sound>::iterator It = m_Souds.begin(); It != m_Souds.end(); ++It)
	{
		if (It->GetStatus() == sf::Sound::Stopped)
		{
			It = m_Souds.erase(It);
			if (It == m_Souds.end())
			{
				break;
			}
		}
	}
}

