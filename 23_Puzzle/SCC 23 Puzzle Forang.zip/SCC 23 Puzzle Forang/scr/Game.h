#ifndef Game_h__
#define Game_h__

#include <sfml/Graphics.hpp>
#include "StateManager.h"
#include "ImageManager.h"
#include "AudioManager.h"
#include "StateManager.h"
#include "FontManager.h"

class Game
{
public:
	Game();
	void Run();
	void Exit();
	sf::RenderWindow& GetWindow();
	StateManager& GetStateManager();
	TextureManager& GetTextureManager();
	AudioManager& GetAudioManager();
	FontManager& GetFontManager();
private:
	bool m_isRunning;
	sf::RenderWindow m_window;

	TextureManager m_textureManager;
	AudioManager m_audioManager;
	FontManager m_fontManager;
	 
	
	StateManager m_stateManager; 
};

#endif // Game_h__

