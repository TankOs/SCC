#ifndef ImageManager_h__
#define ImageManager_h__

#include "ResourceManager.h"
#include <sfml/Graphics.hpp>

class TextureManager : public ResourceManager<std::string, sf::Texture>
{
protected:
	virtual sf::Texture* Load(const std::string FileName);
};

#endif // ImageManager_h__