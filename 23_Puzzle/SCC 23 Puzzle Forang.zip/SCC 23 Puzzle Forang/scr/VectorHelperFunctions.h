#ifndef VectorHelperFunctions_h__
#define VectorHelperFunctions_h__

#include <SFML/System/Vector2.hpp>
#include <SFML/System/Vector3.hpp>
#include "Logfile.h"

#ifndef PI
#define PI (3.14159265358979323846)
#endif

template <typename T>
sf::Vector2<T> operator *(const sf::Vector2<T>& left, const sf::Vector2<T>& right)
{
	return sf::Vector2f(left.x * right.x, left.y * right.y);
}
template <typename T>
sf::Vector2<T> operator *(const sf::Vector3<T>& left, const sf::Vector3<T>& right);
template <typename T>
sf::Vector2<T> operator /(const sf::Vector2<T>& left, const sf::Vector2<T>& right);
template <typename T>
sf::Vector2<T> operator /(const sf::Vector3<T>& left, const sf::Vector3<T>& right);

float RADTODEG(const float Radians);
float DEGTORAD(const float Degrees);
	
// F�llt ein Vektor mit Nullen
template <class T>
void Zero(sf::Vector3<T> &vec) { vec.x = vec.y = vec.z = 0; }
template <class T>
void Zero(sf::Vector2<T> &vec) { vec.x = vec.y = 0; }
	
		
// Gibt die L�nge des Vektors zur�ck
template <class T>
float Length(const sf::Vector3<T> &vec){ return sqrt(vec.x * vec.x + vec.y * vec.y + vec.z * vec.z);	}
template <class T>
float Length(const sf::Vector2<T> &vec){ return sqrt(vec.x * vec.x + vec.y * vec.y);	}

// Gibt die Distanz zwischen 2 Vektoren zur�ck
template <class T>
float Distance(const sf::Vector2<T> &v1, const sf::Vector2<T> &v2){ return Length(v1 -v2);	}
template <class T>
float Distance(const sf::Vector3<T> &v1, const sf::Vector3<T> &v2){ return Length(v1 -v2);	}
	
// Normalisiert den Vektor
template <class T>
sf::Vector3<T> Normalize(sf::Vector3<T> &vec){ return vec /= Length(vec); }
template <class T>
sf::Vector2<T> Normalize(sf::Vector2<T> &vec){ return vec/= Length(vec); }
	
// Rotiert einen Vektor (nur f�r 2D verf�gbar) 
template <class T>
void Rotate(sf::Vector2<T> &vec, float angleInDegrees)
{
	float temp = DEGTORAD(angleInDegrees);
	float sin1 = sin(temp);
	float cos1 = cos(temp);
	float tempx = (vec.x * cos1) - (vec.y * sin1);
	vec.y = (vec.y * cos1) + (vec.x * sin1);
	vec.x = tempx;
}
	
// Berechnet den Winkel zwischen zwei Vektoren in Bogenma�
template <class T>
float AngleBetweenR(const sf::Vector3<T> &v1, const sf::Vector3<T> &v2)
{
	float len1 = Length(v1);
	float len2 = Length(v2);
	if (!len1 || !len2)
		return 0;
	float angle = acosf(Dot(v1, v2) / (len1 * len2));
	if ( std::numeric_limits(angle))
		return 0;
	return angle;
}
template <class T>
float AngleBetweenR(const sf::Vector2<T> &v1, const sf::Vector2<T> &v2)
{
	return acos( Dot(v1, v2) );
}
	
// Berechnet den Winkel zwischen zwei Vektoren in Grad
template <class T>
float AngleBetweenD(const sf::Vector3<T> &v1, const sf::Vector3<T> &v2)
{
	return RADTODEG(AngleBetweenR(v1, v2));
}

template <class T>
float AngleBetweenD(const sf::Vector2<T> &v1, const sf::Vector2<T> &v2)
{
	return RADTODEG(AngleBetweenR(v1, v2));
}

// Berechnet das Punktprodukt von 2 Vektoren
template <class T>
float Dot(const sf::Vector3<T> &v1, const sf::Vector3<T> &v2)
{
	return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
}
template <class T>
float Dot(const sf::Vector2<T> &v1, const sf::Vector2<T> &v2)
{
	return v1.x * v2.x + v1.y * v2.y;
}
	
// Berechnet das Punktprodukt von 2 Vektoren
template <class T>
sf::Vector3<T> Cross(const sf::Vector3<T> &v1, const sf::Vector3<T> &v2)
{
	sf::Vector3<T> Result;
	Result.x = v1.y * v2.z - v1.z * v2.y;
	Result.y = v1.z * v2.x - v1.x * v2.z;
	Result.z = v1.x * v2.y - v1.y * v2.x;
	return Result;
}
template <class T>
float Cross(const sf::Vector2<T> &v1, const sf::Vector2<T> &v2)
{
	return((v1.x * v2.y) - ( v1.y * v2.x ));
}
	
// Operator um einen Vektor direkt ins Logfile zu schreiben
template <class T>
Logfile& operator<<(Logfile& Log, sf::Vector3<T>& Vec)
{
	return Log << "Vektor( " << Vec.x << " | " << Vec.y << " | " << Vec.z " )";		 
}
template <class T>
Logfile& operator<<(Logfile& Log, sf::Vector2<T>& Vec)
{
	return Log << "Vektor( " << Vec.x << " | " << Vec.y << " )";		 
}

#endif // VectorHelperFunctions_h__
