#ifndef MainGameState_h__
#define MainGameState_h__

#include "BaseState.h"
#include "GemField.h"


class MainGameState : public IBaseState
{
public:
	MainGameState(Game& game);
	virtual IBaseState* Update();
	virtual void Draw();
	virtual void ProcessEvent(const sf::Event& event);
private:
	Game& m_game;

	GemField m_gemField;
	sf::Music m_music;

};
#endif // MainGameState_h__