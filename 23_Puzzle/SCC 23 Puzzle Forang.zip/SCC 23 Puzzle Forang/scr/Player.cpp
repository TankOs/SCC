#include "Player.h"
#include "VectorHelperFunctions.h"
#include "Game.h"
#include "Pistol.h"

//////////////////////////////////////////////////////////////////////////
Player::Player(Game& game, int fieldWidth, int fieldHeight)
	: m_window(game.GetWindow()),
	m_Sprite(*game.GetTextureManager().GetResource("Player.png"))
{
	m_Sprite.SetOrigin(20, 40);
	m_Sprite.SetPosition(fieldWidth / 2, fieldHeight / 2);

	m_pistol = new Pistol(m_shotManager);
}

//////////////////////////////////////////////////////////////////////////
void Player::Update()
{
	m_shotManager.Update(m_window.GetFrameTime() / 1000.0f);
}

//////////////////////////////////////////////////////////////////////////
void Player::Draw() const
{
	m_window.Draw(m_Sprite);
	m_shotManager.Draw(m_window);
}

//////////////////////////////////////////////////////////////
void Player::OnMouseMove(sf::Vector2f mousePosition)
{
	// Zum Mauscursor drehen
	float rotation = AngleBetweenD(sf::Vector2f(0, -1), Normalize(mousePosition - m_Sprite.GetPosition()));
	if (mousePosition.x < m_Sprite.GetPosition().x)
	{
		rotation = 360 - rotation;
	}
	m_Sprite.SetRotation(rotation);
	
}

//////////////////////////////////////////////////////////////////////////
void Player::OnMouseButtonPressed( sf::Vector2f mousePosition )
{
	m_pistol->OnMouseClick(mousePosition, m_Sprite.TransformToGlobal(sf::Vector2f(20, 0)));
}

