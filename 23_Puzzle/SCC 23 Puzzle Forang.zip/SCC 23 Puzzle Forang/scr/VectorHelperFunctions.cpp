#include "VectorHelperFunctions.h"


template <typename T>
sf::Vector2<T> operator*( const sf::Vector3<T>& left, const sf::Vector3<T>& right )
{
	return sf::Vector2f(left.x * right.x, left.y * right.y, left.z * right.z);
}

template <typename T>
sf::Vector2<T> operator/( const sf::Vector2<T>& left, const sf::Vector2<T>& right )
{
	return sf::Vector2f(left.x / right.x, left.y / right.y);
}

template <typename T>
sf::Vector2<T> operator/( const sf::Vector3<T>& left, const sf::Vector3<T>& right )
{
	return sf::Vector2f(left.x / right.x, left.y / right.y, left.z / right.z);
}

float RADTODEG(const float Radians)	{return static_cast<float>(Radians * 180.0f / PI);}
float DEGTORAD(const float Degrees) { return static_cast<float>(Degrees * PI / 180.0f);}

