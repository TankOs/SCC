#include "Exception.h"
#include <sstream>

Exception::Exception( const std::string& Description ) : std::exception(Description.c_str()), m_Line(0)
{}

Exception::Exception( const std::string& Description, const char* File, long Line ) : std::exception(Description.c_str()), m_FileName(File), m_Line(Line)
{}


const std::string Exception::GetFullDescription() const
{
		std::stringstream Description;

		Description <<  "Exception ";
		if(m_Line > 0)
		{
			Description << "in der Datei " << m_FileName << " in Zeile " << m_Line;
		}
		Description << " \nFehlermeldung :" << std::exception::what() << "\n";

		return Description.str();
}
