#include "Gem.h"
#include "Game.h"
#include "VectorHelperFunctions.h"

float Gem::m_GemSpeed = 250;
int Gem::m_numGemMoves = 0;

sf::Shader Gem::m_highlightShader;
bool Gem::m_shaderLoaded = false;
bool Gem::m_CanUseShader;

//////////////////////////////////////////////////////////////////////////
Gem::Gem(Game& game, sf::Vector2i Position, int size)
	:m_game(game),
	m_destination(Position),
	m_isSelected(false)
{
	if (!m_shaderLoaded)
	{
		m_CanUseShader = sf::Shader::IsAvailable();
		if (m_CanUseShader)
		{
			if (!m_highlightShader.LoadFromFile("Highlight.sfx"))
			{
				exit(-1);
			}		
		}		
		m_shaderLoaded = true;
	}

	RandomType();

	m_gemSprite.SetPosition(static_cast<sf::Vector2f>(Position));
	m_gemSprite.Resize(static_cast<float>(size), static_cast<float>(size));

	
}
//////////////////////////////////////////////////////////////////////////
void Gem::Update(float deltaTime)
{
	if (m_gemSprite.GetPosition() != m_destination)
	{
		m_gemSprite.Move(Normalize(m_destination - m_gemSprite.GetPosition()) * deltaTime * m_GemSpeed);
		if (Length(m_gemSprite.GetPosition() - m_destination) <= 1)
		{
			m_gemSprite.SetPosition(m_destination);
			--m_numGemMoves;
			
		}
	}
}
//////////////////////////////////////////////////////////////////////////
void Gem::Draw(sf::RenderTarget& target)
{
	if (m_isSelected && m_CanUseShader)
	{
		target.Draw(m_gemSprite, m_highlightShader);
	}
	else
	{
		target.Draw(m_gemSprite);
	}
	
}

//////////////////////////////////////////////////////////////////////////
void Gem::MoveToPosition( sf::Vector2f position)
{
	++m_numGemMoves;
	m_destination = position;
}

//////////////////////////////////////////////////////////////////////////
bool Gem::CheckCollisionWithPoint( sf::Vector2f point )
{
	return	point.x > m_gemSprite.GetPosition().x && 
			point.y > m_gemSprite.GetPosition().y &&
			point.x < m_gemSprite.GetPosition().x + m_gemSprite.GetSize().x &&
			point.y < m_gemSprite.GetPosition().y + m_gemSprite.GetSize().y;
}

//////////////////////////////////////////////////////////////////////////
void Gem::Select()
{
	m_isSelected = true;
	if (!m_CanUseShader)
	{
		m_gemSprite.SetColor(sf::Color(100, 100, 100));
	}
}

//////////////////////////////////////////////////////////////////////////
void Gem::Deselect()
{
	m_isSelected = false;
	if (!m_CanUseShader)
	{
		m_gemSprite.SetColor(sf::Color(255, 255, 255));
	}
}

//////////////////////////////////////////////////////////////////////////
Gem::Type Gem::GetType()
{
	return m_type;
}

//////////////////////////////////////////////////////////////////////////
void Gem::RandomType()
{
	m_type = static_cast<Type>(rand() % TYPE_COUNT);
	switch(m_type)
	{
	case TYPE_RED:
		m_gemSprite.SetTexture(*m_game.GetTextureManager().GetResource("Red_Gem.png"));
		break;
	case TYPE_YELLOW:
		m_gemSprite.SetTexture(*m_game.GetTextureManager().GetResource("Yellow_Gem.png"));
		break;
	case TYPE_PURPLE:
		m_gemSprite.SetTexture(*m_game.GetTextureManager().GetResource("Purple_Gem.png"));
		break;
	case TYPE_BLUE:
		m_gemSprite.SetTexture(*m_game.GetTextureManager().GetResource("Blue_Gem.png"));
		break;
	case TYPE_GREEN:
		m_gemSprite.SetTexture(*m_game.GetTextureManager().GetResource("Green_Gem.png"));
		break;
	case TYPE_WHITE:
		m_gemSprite.SetTexture(*m_game.GetTextureManager().GetResource("White_Gem.png"));
		break;
	case TYPE_ORANGE:
		m_gemSprite.SetTexture(*m_game.GetTextureManager().GetResource("Orange_Gem.png"));
		break;
	}
}



