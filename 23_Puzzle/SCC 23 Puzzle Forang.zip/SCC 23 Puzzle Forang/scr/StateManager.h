#pragma once

#include <sfml/Window/Event.hpp>

class IBaseState;

class StateManager
{
public:
	StateManager(IBaseState* State);
	void Update();
	void Draw();
	void ProcessEvent(const sf::Event& event);
private:
	IBaseState* m_currentState;
};