#pragma once

#include "Game.h"

class IBaseState
{
public:
	virtual IBaseState* Update() = 0;
	virtual void Draw() = 0;

	virtual void ProcessEvent(const sf::Event& event){};
};