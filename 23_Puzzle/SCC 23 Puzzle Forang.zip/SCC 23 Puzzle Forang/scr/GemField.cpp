#include <assert.h>
#include <functional>
#include <sstream>
#include "Game.h"
#include "GemField.h"
#include "Gem.h"

using namespace std::tr1::placeholders;

//////////////////////////////////////////////////////////////////////////
GemField::GemField(Game& game)
	: m_game(game),
	m_gemsSwapping(false),
	m_gemsFall(false),
	m_selectedGemPosition(-1,-1),
	m_scoreText("", *game.GetFontManager().GetResource("44v2.ttf"), 50)
{
	m_scoreText.SetPosition(50, m_fieldHeight * m_GemSize + 20);

	for(size_t y = 0; y < m_fieldHeight; ++y)
	{
		for (size_t x = 0; x < m_fieldWidth; ++x)
		{
			SetGem(x, y, GemPtr(new Gem(m_game, sf::Vector2i(x * m_GemSize, y * m_GemSize), m_GemSize)));
		}
	}

	std::vector<sf::Vector2i> GemsToRemove;
	CheckField(GemsToRemove);

	while (!GemsToRemove.empty())
	{
		for (auto It = GemsToRemove.begin(); It != GemsToRemove.end(); ++It)
		{
			GetGem(It->x, It->y)->RandomType();
		}
		GemsToRemove.clear();
		CheckField(GemsToRemove);
	}
	m_comboMultiplier = 1;
	m_score = 0;
}

//////////////////////////////////////////////////////////////////////////
void GemField::Update()
{
	if ((m_gemsFall || m_gemsSwapping) && !Gem::GemsMoving())
	{
		m_gemsFall = false;
		if(!RemoveCombos())
		{
			if (m_gemsSwapping)
			{
				// Wenn nach dem Tauschen keine Steine entfert wurden wird wieder zur�ck getauscht
				SwapGems(m_swappedGems.first.x, m_swappedGems.first.y, m_swappedGems.second.x, m_swappedGems.second.y);	
			}
			else
			{
				m_comboMultiplier = 0;
			}
		}
		++m_comboMultiplier;
		m_gemsSwapping = false;
	}
	// Alle Steine aktualisieren
	std::for_each(m_gems.begin(), m_gems.end(), std::tr1::bind(&Gem::Update, _1, m_game.GetWindow().GetFrameTime() / 1000.0f));

	std::stringstream sstream;
	sstream << m_score;
	m_scoreText.SetString(sstream.str());
}


//////////////////////////////////////////////////////////////////////////
void GemField::Render( sf::RenderTarget& target, sf::Renderer& renderer ) const
{
	// Alle Steine rendern
	//std::for_each(m_gems.begin(), m_gems.end(), std::bind(&Gem::Draw, _1, std::tr1::ref(target))); ---------> Funktioniert mit std::tr1::ref nicht ??????
	for (auto It = m_gems.begin(); It != m_gems.end(); ++It)
	{
		(*It)->Draw(m_game.GetWindow());
	}
	target.Draw(m_scoreText);
}

//////////////////////////////////////////////////////////////////////////
void GemField::ProcessEvent(const sf::Event& event )
{
	if (event.Type == sf::Event::MouseButtonPressed)
	{
		if (event.MouseButton.Button == sf::Mouse::Left)
		{
			OnLeftClick(static_cast<sf::Vector2i>(TransformToLocal(static_cast<sf::Vector2f>(sf::Vector2i(event.MouseButton.X, event.MouseButton.Y)))));
		}
	}

	
}

//////////////////////////////////////////////////////////////////////////
// private Methoden
//////////////////////////////////////////////////////////////////////////
void GemField::CheckPosition( size_t x, size_t y )
{
	// �berpr�fung ob die Position im g�ltig Bereich ist
	assert(x >= 0 && x < m_fieldWidth && y >= 0 && y < m_fieldHeight);
}

//////////////////////////////////////////////////////////////////////////
GemField::GemPtr GemField::GetGem( size_t x, size_t y )
{
	// Position pr�fen
	CheckPosition(x, y);
	// Index im array aus der Position berechnen
	return m_gems[y * m_fieldWidth + x];

}

//////////////////////////////////////////////////////////////////////////
void GemField::SetGem( size_t x, size_t y, GemPtr gem )
{
	// Position pr�fen
	CheckPosition(x, y);
	// Index im array aus der Position berechnen
	m_gems[y * m_fieldWidth + x] = gem;
}

//////////////////////////////////////////////////////////////////////////
void GemField::MoveGemDown( size_t x, size_t y, size_t deltaY )
{
	GemPtr Gem = GetGem(x, y);
	// Den Stein auf die neue Position bewegen
	SetGem(x, y + deltaY, Gem);
	Gem->MoveToPosition(sf::Vector2f(x * m_GemSize, (y + deltaY) * m_GemSize));
	// Die alte Position des Steins auf NULL setzen
	SetGem(x, y, NULL);
}

//////////////////////////////////////////////////////////////////////////
void GemField::SwapGems( size_t x1, size_t y1, size_t x2, size_t y2 )
{
	GemPtr Gem1 = GetGem(x1, y1);
	Gem1->Deselect();

	GemPtr Gem2 = GetGem(x2, y2);
	Gem2->Deselect();
	
	Gem1->MoveToPosition(sf::Vector2f(x2 * m_GemSize, y2 * m_GemSize));	
	Gem2->MoveToPosition(sf::Vector2f(x1 * m_GemSize, y1 * m_GemSize));
	

	// Stein 2 auf die Position von Stein 1 setzen
	SetGem(x1, y1, Gem2);

	// Stein 1 auf die Position von Stein 2 setzen
	SetGem(x2, y2, Gem1);
}

//////////////////////////////////////////////////////////////////////////
void GemField::OnLeftClick(sf::Vector2i MousePosition)
{
	if (Gem::GemsMoving())
	{
		return;
	}

	// Angeklickten Stein ausw�hlen.
	// Wenn zwei benachbarte Steine ausgew�hlt wurden, dann werden diese getauscht

	// Alle Steine durchlaufen
	for(size_t y = 0; y < m_fieldHeight; ++y)
	{
		for (size_t x = 0; x < m_fieldWidth; ++x)
		{
			// Stein an der aktuellen Position abfragen
			GemPtr currentGem = GetGem(x, y);

			// �berpr�fen ob dieser Stein angeklickt wurde
			if (currentGem->CheckCollisionWithPoint(static_cast<sf::Vector2f>(MousePosition)))
			{
				// Stein wurde angeklickt!

				// �berpr�fen ob es bereits einen ausgew�hlten Stein gibt ( wenn kein Stein ausgew�hlt ist dann ist m_activatedGemPosition.x negativ)
				if (m_selectedGemPosition.x < 0)
				{
					// Falls es noch keinen ausgew�hlten Stein gibt, wird der angeklickte Stein ausgew�hlt.
					m_selectedGemPosition.x = x;
					m_selectedGemPosition.y = y;
					currentGem->Select();
				}
				else
				{
					// Da es schon einen ausgew�hlten Stein gibt, wird �berpr�ft ob der angeklickte Stein neben diesem liegt 
					if (m_selectedGemPosition == sf::Vector2i(x+1,y) || 
						m_selectedGemPosition == sf::Vector2i(x-1,y) ||
						m_selectedGemPosition == sf::Vector2i(x,y+1) ||
						m_selectedGemPosition == sf::Vector2i(x,y-1))
					{
						// Die beiden Steine liegen nebeneinander. Sie werden getauscht.
						SwapGems(x, y, m_selectedGemPosition.x , m_selectedGemPosition.y);
						m_gemsSwapping = true;
						m_swappedGems = std::make_pair(sf::Vector2i(x, y), sf::Vector2i(m_selectedGemPosition.x, m_selectedGemPosition.y));

						m_selectedGemPosition.x = -1;
						return;
					}
					else
					{
						// Falls der angeklickte Stein nicht neben dem ausgew�hlten Stein liegt, wird der angeklickte Stein ausgew�hlt
						GetGem(m_selectedGemPosition.x , m_selectedGemPosition.y)->Deselect();
						m_selectedGemPosition.x = x;
						m_selectedGemPosition.y = y;
						currentGem->Select();						
					}
				}
			}	

		}
	}
}


//////////////////////////////////////////////////////////////////////////
void GemField::CheckFieldEx(std::vector<sf::Vector2i>& resultVec, bool horizontal)
{
	size_t iMax = horizontal ? m_fieldHeight : m_fieldWidth;
	size_t jMax = horizontal ? m_fieldWidth : m_fieldHeight;

	for(size_t i = 0; i < iMax; ++i)
	{
		Gem::Type lastGemType = Gem::TYPE_COUNT; // TYPE_COUNT gilt als undefinierter Typ
		int counter = 0;

		for (size_t j = 0; j < jMax; ++j)
		{
			GemPtr currentGem(GetGem(horizontal ? j : i, horizontal ? i : j));

			// Ist der aktuelle Stein vom selben Type wie der Letzte?
			if (lastGemType == currentGem->GetType())
			{				
				++counter; 
			}

			// Ist der aktuelle Stein nicht vom selben Type wie der letzte?
			// Oder ist es der Letzte Stein in dieser Reihe/Splate?
			if (lastGemType != currentGem->GetType() || (j == jMax - 1 && ++j))
			{
				// �berpr�fen ob mindestens 3 Steine des selben Typs nebeneinander waren
				if (counter >= 3)
				{
					m_score += counter * 20 * m_comboMultiplier;
					
					// Steine die entfernt werden sollen in den vector eintragen
					while(counter > 0)
					{
						if (horizontal)
						{
							resultVec.push_back(sf::Vector2i(j - counter, i));
						}
						else
						{
							resultVec.push_back(sf::Vector2i(i, j - counter));
						}
						--counter;
					}
				}
				lastGemType = currentGem->GetType();
				counter = 1;
			}
		}
	}
}

bool compare(sf::Vector2i vec1, sf::Vector2i vec2)
{
	if (vec1.x < vec2.x)
	{
		return true;
	}
	else if (vec1.x > vec2.x)
	{
		return false;
	}
	else
	{
		return vec1.y > vec2.y;
	}
}

//////////////////////////////////////////////////////////////////////////
void GemField::CheckField( std::vector<sf::Vector2i>& resultVec)
{
	CheckFieldEx(resultVec, true);
	CheckFieldEx(resultVec, false);

	std::sort(resultVec.begin(), resultVec.end(), compare);
	std::unique(resultVec.begin(), resultVec.end());
}

//////////////////////////////////////////////////////////////////////////
bool GemField::RemoveCombos()
{
	std::vector<sf::Vector2i> GemsToRemove;
	CheckField(GemsToRemove);

	if (GemsToRemove.empty())
	{
		return false;
	}

	std::vector<sf::Vector2i>::iterator It = GemsToRemove.begin();
	for(size_t x = 0; x < m_fieldWidth; ++x)
	{
		// Speichert wie viele Steine in der Splate fehlen
		int Counter = 0;

		// Alte Steine nach unten verschieben wenn unter ihnen ein Stein fehlt
		for (int y = m_fieldWidth-1; y > -1; --y)
		{
			if (It != GemsToRemove.end() && *It == sf::Vector2i(x, y))
			{
				++Counter;
				++It;
				SetGem(x, y, NULL);					
			}
			else
			{
				if (Counter > 0)
				{
					MoveGemDown(x, y, Counter);
				}					
			}
		}

		// Splate mit neuen Steinen auff�llen;
		for(int c = Counter; c > 0; --c)
		{
			GemPtr NewGem(new Gem(m_game, sf::Vector2i(x * m_GemSize, -c * m_GemSize), m_GemSize));
			NewGem->MoveToPosition(sf::Vector2f(x * m_GemSize, (-c + Counter) * m_GemSize));
			SetGem(x, -c + Counter, NewGem);
		}	
	}
	m_gemsFall = true;
	return true;
}


