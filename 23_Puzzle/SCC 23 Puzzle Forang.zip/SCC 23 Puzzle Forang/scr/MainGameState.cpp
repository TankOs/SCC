#include "MainGameState.h"

//////////////////////////////////////////////////////////////////////////
MainGameState::MainGameState(Game& game)
	:m_game(game),
	m_gemField(game)
{
	m_gemField.SetPosition(0.0f, 0.0f);
	m_music.OpenFromFile("Fighting For Freedom.ogg");
	m_music.SetLoop(true);
	m_music.Play();
}

//////////////////////////////////////////////////////////////////////////
IBaseState* MainGameState::Update()
{
	m_gemField.Update();
	return nullptr;
}

//////////////////////////////////////////////////////////////////////////
void MainGameState::Draw()
{
	m_game.GetWindow().Draw(m_gemField);
}

//////////////////////////////////////////////////////////////////////////
void MainGameState::ProcessEvent(const sf::Event& event)
{
	m_gemField.ProcessEvent(event);
}
