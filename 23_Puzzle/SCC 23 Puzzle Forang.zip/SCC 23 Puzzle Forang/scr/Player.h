#pragma once

#include <sfml/Graphics.hpp>
#include "ShotManager.h"

class Game;
class Pistol;

class Player
{
public:
	Player(Game& game, int fieldWidth, int fieldHeight);

	void Update();

	void Draw() const;

	void OnMouseButtonPressed(sf::Vector2f mousePosition);
	void OnMouseMove(sf::Vector2f mousePosition);

private:
	sf::RenderWindow& m_window;
	sf::Sprite m_Sprite;

	ShotManager m_shotManager;
	// Waffen
	Pistol* m_pistol;
};