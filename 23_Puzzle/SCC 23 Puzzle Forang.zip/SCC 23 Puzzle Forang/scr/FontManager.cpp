#include "FontManager.h"

//////////////////////////////////////////////////////////////////////////
sf::Font* FontManager::Load( const std::string FileName )
{
	// Neues Bild erstellen
	sf::Font* font = new sf::Font();

	// Bild Laden
	if(!font->LoadFromFile(FileName)) 
	{
		// Bild L�schen
		delete font;
		font = NULL;
		Logfile::GetInstance() << Warning << "Die Schriftdatei " << FileName << " konnte nicht geladen werden. Eine Ausnahme wird ausgeworfen!" << NewLine;
		THROW_EXCEPTION("Das Bild " + FileName + " konnte nicht geladen werden")
	}
	Logfile::GetInstance() << Info << "DDie Schriftdatei " << FileName << " wurde erfolgreich geladen." << NewLine;
	return font;
}
