#include "StateManager.h"
#include "BaseState.h"

//////////////////////////////////////////////////////////////////////////
StateManager::StateManager( IBaseState* State )
{
	m_currentState = State;
}

//////////////////////////////////////////////////////////////////////////
void StateManager::Update()
{
	IBaseState* newState = m_currentState->Update();
	if (newState != nullptr)
	{
		delete m_currentState;
		m_currentState = newState;
	}
	
}

//////////////////////////////////////////////////////////////////////////
void StateManager::Draw()
{
	m_currentState->Draw();
}

//////////////////////////////////////////////////////////////////////////
void StateManager::ProcessEvent(const sf::Event& event)
{
	m_currentState->ProcessEvent(event);
}
