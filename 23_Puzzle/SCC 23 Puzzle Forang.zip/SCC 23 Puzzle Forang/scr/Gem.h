#ifndef Gem_h__
#define Gem_h__

#include <sfml/Graphics.hpp>
#include <sfml/Audio.hpp>

class Game;

class Gem
{
public:
	enum Type
	{
		TYPE_RED,
		TYPE_YELLOW,
		TYPE_PURPLE,
		TYPE_BLUE,
		TYPE_GREEN,
		TYPE_WHITE,
		TYPE_ORANGE,

		TYPE_COUNT
	};

public:
	Gem(Game& game, sf::Vector2i Position, int size);
	void Update(float deltaTime);
	void Draw(sf::RenderTarget& target);
	void MoveToPosition(sf::Vector2f position);
	void Select();
	void Deselect();
	bool CheckCollisionWithPoint(sf::Vector2f point);
	Type GetType();
	void RandomType();

	static bool GemsMoving(){return m_numGemMoves != 0;}
private:
	static float m_GemSpeed;
	static int m_numGemMoves;

	static bool m_shaderLoaded;
	static sf::Shader m_highlightShader;
	static bool m_CanUseShader;

	Game& m_game;
	sf::Sprite m_gemSprite;
	Type m_type;
	sf::Vector2f m_destination;
	bool m_isSelected;
};

#endif // Gem_h__