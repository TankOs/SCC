#ifndef GemField_h__
#define GemField_h__

#include <array>
#include <sfml/Graphics.hpp>
#include <vector>


class Game;
class Gem;

class GemField : public sf::Drawable
{
public:
	GemField(Game& game);
	void Update();
	void ProcessEvent(const sf::Event& event);
private:
	virtual void Render(sf::RenderTarget& target, sf::Renderer& renderer) const;

	void OnLeftClick(sf::Vector2i MousePosition);
	void CheckFieldEx(std::vector<sf::Vector2i>& resultVec, bool horizontal);
	void CheckField(std::vector<sf::Vector2i>& resultVec);
	bool RemoveCombos(); // gibt true zur�ck wenn Steine entfernt wurden
	typedef std::tr1::shared_ptr<Gem> GemPtr;

	//////////////////////////////////////////////////////////////////////////
	// Zugriffsmethoden auf die Steine
	//////////////////////////////////////////////////////////////////////////
	void CheckPosition( size_t x, size_t y );
	GemPtr GetGem(size_t x, size_t y);	
	void SetGem(size_t x, size_t y, GemPtr gem);
	void MoveGemDown(size_t x, size_t y, size_t deltaY);
	void SwapGems(size_t x1, size_t y1, size_t x2, size_t y2);
	//////////////////////////////////////////////////////////////////////////

	static const int m_fieldWidth = 10;
	static const int m_fieldHeight = 10;
	static const int m_GemSize = 50;


	Game& m_game;
	std::tr1::array<GemPtr, m_fieldWidth * m_fieldHeight> m_gems;
	sf::Vector2i m_selectedGemPosition;
	bool m_gemsFall;
	bool m_gemsSwapping;
	std::pair<sf::Vector2i, sf::Vector2i> m_swappedGems;
	int m_comboMultiplier;
	int m_score;
	sf::Text m_scoreText;
};
#endif // GemField_h__