#ifndef ResourceManager_h__
#define ResourceManager_h__

#include "SFML/System.hpp"
#include "Logfile.h"
//#include "ZipArchiver.h"
#include "Exception.h"
#include <map>

template<typename Key,  class T >
class ResourceManager 
{
public:
	typedef std::map<Key, std::tr1::shared_ptr<T>> ResourceMap;
	
	virtual ~ResourceManager() 
	{

	}
	T* GetResource(const Key& TheKey)
	{
		// Pr�fen ob die Resource schon geladen ist
		T* Resource = Find(TheKey);
		if(Resource == NULL)
		{
			Resource = Load(TheKey);								
			// Wenn die Ressource erfolgreich geladen wurde 
			m_Resource.insert(std::make_pair( TheKey, std::tr1::shared_ptr<T>(Resource)));
	
		}
		return Resource;
	}
	
protected:
	virtual T* Load(const Key FileName) = 0;
			
private:
	
	ResourceMap m_Resource;
	
	T* Find( const Key& FileName)
	{
		// Nach der Ressource suchen
		typename ResourceMap::iterator it = m_Resource.find(FileName);
		if(it != m_Resource.end())
		{
			// Eintrag gefunden! Zur�ckgeben!
			return it->second.get();
		}
		else
		{
			// Eintrag nicht gefunden! Null zur�ckgeben
			return NULL;
		}
	}
};
#endif // ResourceManager_h__