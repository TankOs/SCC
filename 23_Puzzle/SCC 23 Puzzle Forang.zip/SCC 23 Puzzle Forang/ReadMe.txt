SFML 2.0 61adc51

Musik: Fighting For Freedom.ogg von e-reggae (http://e-reggae.bandcamp.com/)

Anleitung:
F�r mehr als ein simpler bejeweled klon hat es nicht mehr gereicht :D
Mit der Maus m�ssen 2 Steine ausgew�hlt werden, die nebeneinander liegen.
Diese werden dann getauscht. Entsteht nun horizontal oder vertikal eine Reihe von mindestens 3 gleichfarbigen Steinen,
so verschwinden diese und man bekommt Punkte.
Es gibt mehr Punkte wenn mehr als 3 Steine in einer Reihe sind und wenn mehrere Reihen hintereinander entstehen(Combo)
Das Spiel ist zu ende wenn es keinen g�ltigen Spielzug mehr gibt.