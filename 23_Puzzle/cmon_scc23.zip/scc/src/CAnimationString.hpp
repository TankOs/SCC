#ifndef CANIMATIONSTRING_HPP
#define CANIMATIONSTRING_HPP

#include <SFML/Graphics.hpp>
#include <string>
#include "Templates/TAnimationHelper.hpp"

class CAnimationString
{
public:
    CAnimationString(const std::string &text, bool visible, sf::RenderWindow &window);
    CAnimationString(const std::string &text, const sf::Vector2f &start, const sf::Vector2f &end, bool visible, sf::RenderWindow &window);
    void draw();
    sf::Rect<float> GetRect();
    void SetPosition(const sf::Vector2f &pos);
    bool isVisible();
    void setVisible(bool visible);
    void setStart(const sf::Vector2f &start);
    void setEnd(const sf::Vector2f &end);
    void resetAnimation();
    bool playLoadAnimation();
    bool playCloseAnimation();
    void setColor(const sf::Color &color);

protected:
    sf::String _string;
    sf::Vector2f _start;
    sf::Vector2f _end;
    bool _visible;
    sf::RenderWindow &_window;
    TAnimationHelper<sf::String>  _loadAnimation;
    TAnimationHelper<sf::String>  _closeAnimation;

};

#endif // CANIMATIONSTRING_HPP
