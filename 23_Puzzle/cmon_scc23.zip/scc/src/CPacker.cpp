#include "CPacker.hpp"
#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <string.h>

CPacker::CPacker():_aktiveFileBuffer(0)
{
}

CPacker::~CPacker()
{
    if(_aktiveFileBuffer != 0)
        delete (_aktiveFileBuffer);
}

bool CPacker::Create(std::vector<std::string> files, std::string destination)
{
    //A file entry in order to push it in the object's std::vector
    SFileEntry entry;
    //An input file stream to read each file included
    std::ifstream file;
    //An output file stream to write our DAT file
    std::ofstream datfile;
    //The buffer used to read/write the DAT file
    char buffer[1];

    //DATHeader
    //We start by filling it with 0
    memset (&_PackeHeader, 0, sizeof(_PackeHeader));
    //Then we copy the ID
    memcpy (_PackeHeader.uniqueID, "JGDAT", 5);
    //Then the version
    memcpy (_PackeHeader.version, "0.1", 3);
    //Then the number of files to include
    _PackeHeader.nb_files = files.size();

    //Next, we open each file in orderto create the File Entries Table
    for (unsigned int i = 0; i<files.size(); i++)
    {
        file.open (files[i].c_str(), std::ifstream::in | std::ifstream::binary);
        if (file.is_open())
        {
            //Filling the FileEntry with 0
            memset (&entry, 0, sizeof(SFileEntry));
            //We keep the file name
            memcpy (entry.name, files[i].c_str(), strlen ( files[i].c_str() ) );
            //We calculate its size
            file.seekg (0, std::ios::end);
            entry.size = file.tellg();
            //Since we don't know exactly its final position in the DAT file, let's use 0
            entry.offset = 0;
            //We finished with this file
            file.close();

            //Finally, we add this File Entry in our std::vector
            _fileList.push_back(entry);
        }
        else
        {
            //Simple error track
            std::cout<<"File "<<files[i]<<" raise an error."<<std::endl;
            return (false);
        }
    }

    //Now, we know everything about our files, we can update offsets
    long actual_offset = 0;
    actual_offset += sizeof(SPackerHeader);
    actual_offset += _PackeHeader.nb_files * sizeof(SFileEntry);
    for (unsigned int i=0;i<_fileList.size();i++)
    {
        _fileList[i].offset = actual_offset;
        actual_offset += _fileList[i].size;
    }

    //And finally, we are writing the DAT file
    datfile.open (destination.c_str(), std::ofstream::out | std::ofstream::binary);

    //First, we write the header
    datfile.write ((char*)&_PackeHeader, sizeof(SPackerHeader) );

    //Then, the File Entries Table
    for (unsigned int i=0;i<_fileList.size();i++)
    {
        datfile.write ((char*)&_fileList[i], sizeof(SFileEntry) );
    }

    //Finally, we write each file
    for (unsigned int i = 0; i<_fileList.size(); i++)
    {
        file.open (_fileList[i].name, std::ifstream::in | std::ifstream::binary);
        if (file.is_open())
        {
            file.seekg (0, std::ios::beg);
            while (file.read (buffer, 1))
            {
                datfile.write (buffer, 1);
            }
            file.close();
        }
        file.clear();
    }
    //And it's finished
    datfile.close();
    return (true);
}

void CPacker::Read(std::string source)
{
    //The input file stream from which we want informations
    std::ifstream datfile;
    //A file entry in order to push it in the object's std::vector
    SFileEntry entry;

    //Filling the header with 0
    memset (&_PackeHeader, 0, sizeof(_PackeHeader));
    //We open the DAT file to read it
    datfile.open (source.c_str(), std::ifstream::in | std::ifstream::binary);

    if (datfile.is_open())
    {
        //Getting to the Header position
        datfile.seekg (0, std::ios::beg);
        //Reading the DAT Header
        datfile.read ((char*)&_PackeHeader, sizeof(SPackerHeader));
        //Next we are reading each file entry
        for (unsigned int i=0;i<_PackeHeader.nb_files;i++)
        {
            //Reading a File Entry
            datfile.read ((char*)&entry, sizeof(SFileEntry));
            //Pushing it in our std::vector
            _fileList.push_back(entry);
        }
        //Since all seems ok, we keep the DAT file name
        m_datfile = source;
    }
    else
    {
        _statusFlag = fail;
    }
    //Closing the DAT file
    datfile.close();
}

char* CPacker::GetFile(std::string filename)
{
    //The input file stream from which we want information
    std::ifstream datfile;

    //Cleaning properly an ancient file loaded
    if (_aktiveFileBuffer != NULL)
    {
        delete (_aktiveFileBuffer);
        _aktiveFileBuffer = NULL;
    }

    //First, we have to find the file needed
    for (unsigned int i=0; i<_PackeHeader.nb_files;i++)
    {
        //If we found it
        if (_fileList[i].name == filename)
        {
            //We are allocating memory to the buffer
            _aktiveFileBuffer = new char[(_fileList[i].size)];
            //Simple error catch
            if (_aktiveFileBuffer==NULL)
                return (NULL);
            //Opening the DAT file ot read the file datas needed
            datfile.open (m_datfile.c_str(), std::ifstream::in | std::ifstream::binary);
            if (datfile.is_open())
            {
                //Going to the right position
                datfile.seekg (_fileList[i].offset, std::ios::beg);
                //Reading
                datfile.read (_aktiveFileBuffer, _fileList[i].size);
                //We can close the DAT file
                datfile.close();
                //Returning the buffer
                return (_aktiveFileBuffer);
            }
        }
    }
    //Finally, there is no such file in our DAT file
    return (NULL);
}

long int CPacker::GetFileSize(std::string filename)
{
    //First, we have to find the file needed
    for (unsigned int i=0; i<_PackeHeader.nb_files;i++)
    {
        //If we found it
        if (_fileList[i].name == filename)
        {
            //Returning the size of the file found
            return (_fileList[i].size);
        }
    }
    return (0);
}

int CPacker::getStatus()
{
    return _statusFlag;
}

void CPacker::testausgabe()
{
    for(int i=0; i<_fileList.size();i++)
        std::cout << _fileList[i].name << std::endl;
}
