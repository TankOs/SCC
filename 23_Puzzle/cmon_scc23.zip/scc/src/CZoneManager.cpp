#include "CZoneManager.hpp"

#include <fstream>
#include <iostream>

CZoneManager::CZoneManager()
{
}

CZoneManager::CZoneManager(CPacker &packer)
{
    loadFromPacker(packer);
}

void CZoneManager::loadFromPacker(CPacker &packer)
{
    std::stringstream file;
    file << packer.GetFile("zonen");
    std::string line;
    for(getline(file,line);file.eof() == false;getline(file,line))
    {
        //std::cout << line << std::endl;
        std::stringstream zoneFile;
        zoneFile <<packer.GetFile(line.c_str());
        addZone(line,zoneFile);
    }
}

void CZoneManager::addZone(const std::string &name, std::stringstream &file)
{
    _zoneListe[name] = new CZone(file);
}

CZone* CZoneManager::getZone(std::string name)
{
    return _zoneListe[name];
}
