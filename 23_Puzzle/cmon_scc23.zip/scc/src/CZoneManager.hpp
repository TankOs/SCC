#ifndef CZONEMANAGER_HPP
#define CZONEMANAGER_HPP
#include <map>
#include "CZone.hpp"
#include "CPacker.hpp"
#include <sstream>
class CZoneManager
{

public:
    CZoneManager();
    CZoneManager(CPacker &packer);
    CZoneManager(sf::Vector2f &pos, CPacker &packer);
    void loadFromPacker(CPacker &packer);
    CZone *getZone(std::string name);

protected:
    void addZone(const std::string &name,std::stringstream &file);


protected:
    std::map<std::string,CZone*> _zoneListe;
};

#endif // CZONEMANAGER_HPP
