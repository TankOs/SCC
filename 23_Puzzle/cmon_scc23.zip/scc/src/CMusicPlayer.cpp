#include "CMusicPlayer.hpp"
#include <iostream>
CMusicPlayer::CMusicPlayer(sf::String &musicTitle):_musicTitle(musicTitle)
{
    STrackInformation *track = new STrackInformation;
    track->artist ="Epic Soul Factory";
    track->trackname = "La búsqueda de Ianna";
    track->filename = "sound/Epic Soul Factory - La búsqueda de Ianna.ogg";

    _musicListe.push_back(track);
    track = new STrackInformation;

    track->artist = "Stefano mocini";
    track->trackname = "Rebirth";
    track->filename = "sound/Stefano_mocini-Rebirth";


    //_musicListe.push_back("sound/Epic Soul Factory - La búsqueda de Ianna.ogg");
    //_musicListe.push_back("sound/Stefano_mocini-Rebirth.ogg");
    //_musicListe.push_back("sound/Epic Soul Factory - La búsqueda de Ianna.mp3");

    _aktiveMusic = _musicListe.begin();

    track = (*_aktiveMusic);
    _aktiveTrack.OpenFromFile(track->filename);
    _aktiveTrack.Play();

    _musicTitle.SetText(track->artist + " - " + track->trackname);
}

CMusicPlayer::~CMusicPlayer()
{
    _aktiveTrack.Stop();

}

void CMusicPlayer::Run()
{
    while(1)
    {
        if(_aktiveTrack.GetStatus()==sf::Music::Stopped)
        {
            std::cout << "ende" << std::endl;
            _aktiveMusic++;
            if(_aktiveMusic == _musicListe.end())
                _aktiveMusic = _musicListe.begin();

            STrackInformation *track = (*_aktiveMusic);
            _aktiveTrack.OpenFromFile(track->filename);
            _aktiveTrack.Play();

            _musicTitle.SetText(track->artist + " - " + track->trackname);
        }
        sf::Sleep(1.f);
    }

}

void CMusicPlayer::increaseVolumen()
{
    std::cout << "lauter" << std::endl;
    _aktiveTrack.SetVolume(_aktiveTrack.GetVolume()+1);
}
void CMusicPlayer::decreaseVolumen()
{
    std::cout << "leise" << std::endl;
    _aktiveTrack.SetVolume(_aktiveTrack.GetVolume()-1   );
}

