///////////////////////////////////////////////////////////////////////////////
///
/// multi maze v0.2
/// Copyright (C) 2011 by cmon
///
///////////////////////////////////////////////////////////////////////////////

#include <SFML/Graphics.hpp>
#include <iostream>
#include <fstream>

#include "CMenu.hpp"
#include "CStateManager.hpp"
#include "CPacker.hpp"
#include "CLevelManager.hpp"
#include "CMusicPlayer.hpp"
#include "helperfunctions.hpp"



int main(int argc, char **argv)
{
    CPacker *packer = new CPacker();
    packer->Read("level.pak");
    if(packer->getStatus() == 2)
    {
        std::cout << "Packe konnte nicht geöffnet werden " << std::endl;
        return 0;
    }
    CLevelManager *levelManager = new CLevelManager(*packer);
    levelManager->SetPosition(sf::Vector2f(100,100));

    std::string lastlevel;

    sf::String musicTitle;
    musicTitle.SetPosition(200,450);
    musicTitle.SetSize(10.f);

    CMusicPlayer *mPlayer = new CMusicPlayer(musicTitle);
    mPlayer->Launch();

    std::ifstream file;
    file.open("player");
    getline(file,lastlevel);
    std::string tmp;
    getline(file,tmp);
    int zahl = StringToInt(tmp);
    levelManager->setMoves(zahl);
    file.close();

    sf::RenderWindow  *app = new sf::RenderWindow(sf::VideoMode(500,500),"multi maze V0.2",sf::Style::Close);
    CStateManager *state = new CStateManager("Menu");

    CMenu *menu = new CMenu(sf::Vector2f(100,0),sf::Vector2f(300,500),*app,lastlevel);


    while(app->IsOpened())
    {
        sf::Event event;
        while(app->GetEvent(event))
        {
            if(event.Type == sf::Event::Closed)
                app->Close();
            if(event.Type == sf::Event::KeyPressed)
            {
                if(event.Key.Code == sf::Key::A)
                    mPlayer->increaseVolumen();
                else if(event.Key.Code == sf::Key::Q)
                    mPlayer->decreaseVolumen();
            }
            ///////////////////////////////////////////////////////////////////////
            /// Event
            ///////////////////////////////////////////////////////////////////////
            if(state->getAktiveState() == "Menu")
            {
                menu->event(event);
            }
            else if(state->getAktiveState() == "Play")
            {
                levelManager->event(event);
            }

        }
        ///////////////////////////////////////////////////////////////////////
        /// Logic
        ///////////////////////////////////////////////////////////////////////
        if(state->getAktiveState() == "Menu")
        {
            menu->logic();
        }
        else if(state->getAktiveState() == "Play")
        {
            levelManager->logic(*app);
        }


        app->Clear();

        ///////////////////////////////////////////////////////////////////////
        /// Draw
        ///////////////////////////////////////////////////////////////////////
        if(state->getAktiveState() == "Menu")
        {
            menu->draw();

        }
        else if(state->getAktiveState() == "Play")
        {
            levelManager->drawAktiveLevel(*app);
        }
        app->Draw(musicTitle);
        app->Display();
        ///////////////////////////////////////////////////////////////////////
        /// State change
        ///////////////////////////////////////////////////////////////////////

        if(state->getAktiveState() == "Menu")
        {
            std::string test  =menu->getNewState();
            if(test == "Exit")
                app->Close();
            else if(test == "Play")
            {
                state->changeState("Play");
                levelManager->loadLevel("");
                levelManager->onLoadState();

            }
            else if(test == "Con")
            {
                levelManager->loadLevel(lastlevel);
                state->changeState("Play");
                levelManager->onLoadState();
            }
        }
        else if(state->getAktiveState() == "Play")
        {
            if(levelManager->getNewState() == "Menu")
            {
                state->changeState("Menu");
                lastlevel = levelManager->getAktiveLevel();
                std::cout << lastlevel << std::endl;
                menu->onLoadState();
            }
            else if(levelManager->getNewState() == "GameOver")
            {
                state->changeState("Menu");
                lastlevel = "";
                menu->onLoadState();
            }
        }


    }

    std::ofstream outfile;
    outfile.open("player");
    outfile.write(levelManager->getAktiveLevel().c_str(), levelManager->getAktiveLevel().size());
    std::cout <<levelManager->getAktiveLevel().c_str() << "  "<< levelManager->getAktiveLevel().size() <<  std::endl;
    std::stringstream ss;
    outfile << std::endl;
    ss << levelManager->getMoves();
    outfile.write(ss.str().c_str(),ss.str().size());

}
