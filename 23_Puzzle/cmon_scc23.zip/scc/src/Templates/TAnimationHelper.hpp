#ifndef TANIMATIONHELPER_HPP
#define TANIMATIONHELPER_HPP
#include <SFML/Graphics.hpp>
template<class T>
class TAnimationHelper
{
public:
    TAnimationHelper();
    bool Animation(sf::RenderWindow &window);
    void setAnimation(T *zone,sf::Vector2f start, sf::Vector2f end);
protected:
    bool moveX(sf::RenderWindow &window);
    bool moveY(sf::RenderWindow &window);
    sf::Vector2f interpolateX();
    sf::Vector2f interpolateY();
    void setSpeed(float start, float end);


protected:
    T *_zone;
    float _factorX;
    float _factorY;
    float _speed;
    sf::Vector2f _start;
    sf::Vector2f _end;


};

template<class T>
TAnimationHelper<T>::TAnimationHelper()
{
}
//-----------------------------------------------------------------------------
template<class T>
void TAnimationHelper<T>::setAnimation(T *zone, sf::Vector2f start, sf::Vector2f end)
{
    _speed = 0.5;
    _zone = zone;
    _start = start;
    _end = end;
    _factorX = 0.0;
    _factorY = 0.0;

    setSpeed(_start.x,_end.x);
    //_zone->reset();

}
//-----------------------------------------------------------------------------
template<class T>
bool TAnimationHelper<T>::Animation(sf::RenderWindow &window)
{
    if(_start == _end)
    {
        return false;
    }
    else if(!moveX(window))
    {
        setSpeed(_start.y,_end.y);
        if(!moveY(window))
            return false;
    }

    return true;
}
//-----------------------------------------------------------------------------
template<class T>
bool TAnimationHelper<T>::moveX(sf::RenderWindow &window)
{
    _factorX+=(window.GetFrameTime()*_speed);
    //std::cout << "X: " << interpolateY().x << std::endl;
    if(interpolateX().x == _end.x)
    {
        _zone->SetPosition(interpolateX());
        return false;
    }
    else
        _zone->SetPosition(interpolateX());

    return true;
}
//-----------------------------------------------------------------------------
template<class T>
sf::Vector2f TAnimationHelper<T>::interpolateX()
{
    if(_factorX > 1.f)
        _factorX = 1.f;
    else if(_factorX < 0.f)
        _factorX = 0.f;

    sf::Vector2f r;

    r.x = _start.x +(_end.x - _start.x ) * _factorX;
    r.y = _start.y;
    return r;
}
//-----------------------------------------------------------------------------
template<class T>
bool TAnimationHelper<T>::moveY(sf::RenderWindow &window)
{
    _factorY+=(window.GetFrameTime()*_speed);
    //std::cout << "Y: " << interpolateY().y << std::endl;
    if(interpolateY().y == _end.y)
    {
        _zone->SetPosition(interpolateY());
        return false;
    }
    else
        _zone->SetPosition(interpolateY());

    return true;
}

template<class T>
sf::Vector2f TAnimationHelper<T>::interpolateY()
{
    if(_factorY > 1.f)
        _factorY = 1.f;
    else if(_factorY < 0.f)
        _factorY = 0.f;

    sf::Vector2f r;

    r.y = _start.y +(_end.y - _start.y ) * _factorY;
    r.x = _end.x;
    return r;
}
//-----------------------------------------------------------------------------
template<class T>
void TAnimationHelper<T>::setSpeed(float start, float end)
{
    if((end - start) < 0.0)
        _speed  = (0.5*400)/(-1*(end - start));
    else
        _speed  = (0.5*400)/(end - start );
}



#endif // TANIMATIONHELPER_HPP
