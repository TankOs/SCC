#ifndef CSTATEMANAGER_HPP
#define CSTATEMANAGER_HPP

#include <string>
//enum EGameState {PlayAnimation, nextlevel, no, play, Menu, undev, start};


class CStateManager{
public:
    CStateManager();
    CStateManager(const std::string &state);
    std::string getAktiveState() const;
    std::string getPrevState() const;
    void changeState(const std::string &state);

protected:
    std::string _aktiveState;
    std::string _prevState;
};

#endif // CSTATEMANAGER_HPP
