#ifndef HELPERFUNCTIONS_HPP
#define HELPERFUNCTIONS_HPP
#include <string>
#include <sstream>
#include <SFML/Graphics.hpp>


int StringToInt(std::string value);
int StringToInt(char &value);

sf::Vector2f Interpolate(sf::Vector2f &pointA, sf::Vector2f &pointB, float factor);

#endif // HELPERFUNCTIONS_HPP
