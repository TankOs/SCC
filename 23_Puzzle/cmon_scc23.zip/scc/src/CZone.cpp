#include "CZone.hpp"

#include <iostream>
#include <fstream>
#include <sstream>
#include "helperfunctions.hpp"


CZone::CZone(std::stringstream &file):_pos(0,0)
{
    loadFromStream(file);
}

void CZone::loadFromStream(std::stringstream &file)
{
    std::string line;
    std::string tmp;
    //std::ifstream file(name.c_str());

    size_t pos;

    getline(file,line);
    pos =  line.find("/");

    tmp = line.substr(0,pos);
    int x;
    x = StringToInt(tmp);

    tmp = line.substr(pos+1);
    int y;
    y = StringToInt(tmp);

    _feld.resize(x,y);
    //std::cout << pos << " " << line << " "<< x << " "<< y  << std::endl;
    //std::cout << "x: " << _feld.getSizeX() << " y: "<< _feld.getSizeY() << std::endl;
    for(int i=0;i<y;i++)
    {
        getline(file,line);
        for(int j=0; j<x; j++)
        {
          //  std::cout << StringInt(line[j]);
            if(StringToInt(line[j]) != 2)
                _feld[j][i] = StringToInt(line[j]);
            else
            {
                _feld[j][i] = 0;
                _playerPos.x = j;
                _playerPos.y = i;
                _playerStartPos.x = j;
                _playerStartPos.y = i;
            }

        }
        //std::cout << std::endl;
     }
}
//-----------------------------------------------------------------------------
void CZone::draw(sf::RenderWindow &window)
{
    for(int i=0; i<_feld.getSizeX();i++)
    {
        for(int j=0; j<_feld.getSizeY();j++)
        {
            if(_feld[i][j] == wall)
                window.Draw(sf::Shape::Rectangle(_pos.x+15*i,_pos.y+15*j,_pos.x+15+15*i,_pos.y+15+15*j,sf::Color::White,1.f,sf::Color::Black));
            else if(_feld[i][j] == ziel)
                window.Draw(sf::Shape::Rectangle(_pos.x+15*i+3,_pos.y+15*j+3,_pos.x+15+15*i-3,_pos.y+15+15*j-3,sf::Color::Black,1.f,sf::Color::White));

        }
    }
    window.Draw(sf::Shape::Rectangle(_pos.x+15*_playerPos.x+3,_pos.y+15*_playerPos.y+3,
                                     _pos.x+15+15*_playerPos.x-3,_pos.y+15+15*_playerPos.y-3,
                                     sf::Color::White,1.f,sf::Color::Black));
}

void CZone::SetPosition(sf::Vector2f a)
{
    _pos = a;
}

void CZone::SetPosition(float offsetX, float offsetY)
{
    _pos.x += offsetX;
    _pos.y += offsetY;
}

sf::Vector2f CZone::getPos()
{
    return _pos;
}

sf::Rect<float> CZone::getRect()
{
    return sf::Rect<float>(_pos.x,_pos.y,_pos.x+_feld.getSizeX()*15,_pos.y+_feld.getSizeY()*15);
}

bool CZone::win()
{
    return _feld[_playerPos.x][_playerPos.y] == ziel;
}

bool CZone::playerMove(int richtung)
{
    if(richtung == 0)
    {
        if(_feld[_playerPos.x][_playerPos.y-1] == path || _feld[_playerPos.x][_playerPos.y-1] == ziel)
        {
            _playerPos.y -=1;
            return true;
        }
    }
    else if(richtung == 1)
    {
        if(_feld[_playerPos.x+1][_playerPos.y] == path || _feld[_playerPos.x+1][_playerPos.y] == ziel)
        {
            _playerPos.x +=1;
            return true;
        }
    }
    else if(richtung == 2)
    {
        if(_feld[_playerPos.x][_playerPos.y+1] == path || _feld[_playerPos.x][_playerPos.y+1] ==  ziel)
        {
            _playerPos.y +=1;
            return true;
        }
    }
    else if(richtung == 3)
    {
        if(_feld[_playerPos.x-1][_playerPos.y] == path || _feld[_playerPos.x-1][_playerPos.y] == ziel)
        {
            _playerPos.x -=1;
            return true;
        }
    }
    return false;
}

void CZone::reset()
{
    _playerPos = _playerStartPos;
}




