#ifndef CMENU_HPP
#define CMENU_HPP

enum EMenuState{LoadAnimation,CloseAnimation, Non,Close};

///////////////////////////////////////////////////////////////////////////////
/// Headers
///////////////////////////////////////////////////////////////////////////////
#include <SFML/Graphics.hpp>
#include <string>
#include <list>
//#include <map>
#include "CAnimationString.hpp"



//enum EMenu{Animation,loadAnimation,closeAnimation,end,non};
typedef std::list< std::pair<std::string,CAnimationString*> >::iterator listiter;

class CMenu
{    
///////////////////////////////////////////////////////////////////////////////
/// Public Methoden
///////////////////////////////////////////////////////////////////////////////
public:
    CMenu(const sf::Vector2f &pos, const sf::Vector2f &size, sf::RenderWindow &window);
    CMenu(const sf::Vector2f &pos, const sf::Vector2f &size, sf::RenderWindow &window, std::string &lastlevel);
    void draw();
    void logic();
    void event(sf::Event event);
    bool isMenuOpen();
    void onLoadState();
    std::string getNewState();


protected:
    void load();

///////////////////////////////////////////////////////////////////////////////
/// Public Membervaribalen
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
/// protected Membervaribalen
///////////////////////////////////////////////////////////////////////////////
protected:
    sf::Vector2f _pos;
    sf::Vector2f _size;
    sf::RenderWindow &_window;
    EMenuState _state;
    std::string *_lastlevel;
    std::list< std::pair<std::string,CAnimationString*> > _menuEntry;
    std::list< std::pair<std::string,CAnimationString*> >::iterator _aktiveEntry;
    //std::map<std::string,CAnimationString*> _menuEntry;
    //std::map<std::string,CAnimationString*>::iterator _aktiveEntry;
};

#endif // CMENU_HPP
