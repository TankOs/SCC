#include "CAnimationString.hpp"

CAnimationString::CAnimationString(const std::string &text, bool visible, sf::RenderWindow &window):_string(text),
                                                                                                    _visible(visible),
                                                                                                    _window(window)
{
    _string.SetColor(sf::Color::Green);
    _string.SetSize(20.f);

}

CAnimationString::CAnimationString(const std::string &text, const sf::Vector2f &start, const sf::Vector2f &end, bool visible, sf::RenderWindow &window):_string(text),
                                                                                                                                                        _start(start),
                                                                                                                                                        _end(end),
                                                                                                                                                        _visible(visible),
                                                                                                                                                        _window(window)
{
    _string.SetPosition(_end);
    _string.SetColor(sf::Color::Green);
}

void CAnimationString::draw()
{
    _window.Draw(_string);
}

sf::Rect<float> CAnimationString::GetRect()
{
    return _string.GetRect();
}

void CAnimationString::SetPosition(const sf::Vector2f &pos)
{
    _string.SetPosition(pos);
}

bool CAnimationString::isVisible()
{
    return _visible;
}

void CAnimationString::setVisible(bool visible)
{
    _visible = visible;
}

void CAnimationString::setStart(const sf::Vector2f &start)
{
    _start = start;
}

void CAnimationString::setEnd(const sf::Vector2f &end)
{
    _end = end;
}

void CAnimationString::resetAnimation()
{
    _loadAnimation.setAnimation(&_string,_start,_end);
    _closeAnimation.setAnimation(&_string,_end,_start);
}

bool CAnimationString::playLoadAnimation()
{
   return _loadAnimation.Animation(_window);
}

bool CAnimationString::playCloseAnimation()
{
    return _closeAnimation.Animation(_window);
}

void CAnimationString::setColor(const sf::Color &color)
{
    _string.SetColor(color);
}
