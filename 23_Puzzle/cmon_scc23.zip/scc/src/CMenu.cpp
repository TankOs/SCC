#include "CMenu.hpp"
#include <iostream>

CMenu::CMenu(const sf::Vector2f &pos, const sf::Vector2f &size, sf::RenderWindow &window):_pos(pos),
                                                                                          _size(size),
                                                                                          _window(window),
                                                                                          _state(LoadAnimation),
                                                                                          _lastlevel(0)
{
    load();
    if((*_lastlevel) == "")
    {
        for(listiter iter = _menuEntry.begin(); iter != _menuEntry.end(); iter++)
            if(iter->first == "Con")
                iter->second->setVisible(false);

    }

}

CMenu::CMenu(const sf::Vector2f &pos, const sf::Vector2f &size, sf::RenderWindow &window, std::string &lastlevel):_pos(pos),
                                                                                          _size(size),
                                                                                          _window(window),
                                                                                          _state(LoadAnimation),
                                                                                          _lastlevel(&lastlevel)

{
    load();
    if((*_lastlevel) == "   ")
    {
        for(listiter iter = _menuEntry.begin(); iter != _menuEntry.end(); iter++)
            if(iter->first == "Con")
                iter->second->setVisible(false);

    }
}

void CMenu::load()
{
    CAnimationString *entry;
    sf::Vector2f start;
    sf::Vector2f ende;

    entry = new CAnimationString("Play",true,_window);

    ende.x = ((_size.x/2)+_pos.x)- (entry->GetRect().GetWidth()/2);
    ende.y = 210;
    start.x = ende.x -1;
    start.y = 0-entry->GetRect().GetHeight();
    entry->setStart(start);
    entry->setEnd(ende);
    entry->resetAnimation();
    _menuEntry.push_back(std::pair<std::string,CAnimationString*>("Play",entry));
    //_menuEntry["1Play"] = entry;


    entry = new CAnimationString("Contiune old Game",true,_window);

    ende.x = ((_size.x/2)+_pos.x)- (entry->GetRect().GetWidth()/2);
    ende.y = 240;
    start.x = 0-entry->GetRect().GetWidth();
    start.y = ende.y;
    entry->setStart(start);
    entry->setEnd(ende);
    entry->resetAnimation();
    _menuEntry.push_back(std::pair<std::string,CAnimationString*>("Con",entry));

  // _menuEntry["2Con"] = entry;
    entry = new CAnimationString("Exit",true,_window);

    ende.x = ((_size.x/2)+_pos.x)- (entry->GetRect().GetWidth()/2);
    ende.y = 270;

    start.x = ende.x -1;
    start.y = 500;
    entry->setStart(start);
    entry->setEnd(ende);
    entry->resetAnimation();
    _menuEntry.push_back(std::pair<std::string,CAnimationString*>("Exit",entry));

//_menuEntry["3Exit"] = entry;
}
//-----------------------------------------------------------------------------
void CMenu::draw()
{
    _window.Draw(sf::Shape::Rectangle(_pos,(_pos+_size),sf::Color(155,155,155,100)));
    //_window.Draw(sf::Shape::Line((_size.x/2)+_pos.x,0,(_size.x/2)+_pos.x,_size.y,4.f,sf::Color::Red));

    for(listiter iter = _menuEntry.begin(); iter != _menuEntry.end(); iter++)
        if(iter->second->isVisible())
            iter->second->draw();
//    for(unsigned int i=0; i<_menuEntry.size();i++)
//        if(_menuEntry[i]->isVisible())
//            _menuEntry[i]->draw();
}

void CMenu::logic()
{
    int playAnimation = _menuEntry.size();
    if(_state == LoadAnimation)
    {
        for(listiter iter = _menuEntry.begin(); iter != _menuEntry.end(); iter++)
        {
            if(iter->second->playLoadAnimation() == false)
                playAnimation--;
        }
        if(playAnimation == 0)
        {
            std::cout << "State gleich non" << std::endl;
            _state = Non;
           // _menuEntry["1Play"]->setColor(sf::Color::Blue);
            _aktiveEntry = _menuEntry.begin();
            _aktiveEntry->second->setColor(sf::Color::Blue);
        }
    }
    else if(_state == CloseAnimation)
    {
        for(listiter iter = _menuEntry.begin(); iter != _menuEntry.end(); iter++)
        {
            if(iter->second->playCloseAnimation() == false)
                playAnimation--;
        }
        if(playAnimation == 0)
        {
            std::cout << "State gleich close" << std::endl;
            _state = Close;
        }

    }
}

void CMenu::event(sf::Event event)
{
    if(_state == Non && event.Type == sf::Event::KeyPressed)
    {
        if(event.Key.Code == sf::Key::Return)
            _state = CloseAnimation;
        else if(event.Key.Code == sf::Key::Up)
        {
            if(_aktiveEntry != _menuEntry.begin())
            {
                listiter iter = _aktiveEntry;
                for(;iter!=_menuEntry.begin();)
                {
                    iter--;
                    if(iter->second->isVisible())
                        break;
                }

                _aktiveEntry->second->setColor(sf::Color::Green);
                _aktiveEntry = iter;
                _aktiveEntry->second->setColor(sf::Color::Blue);
            }
        }
        else if(event.Key.Code == sf::Key::Down)
        {
            listiter iter = _aktiveEntry;
            for(iter++; iter!=_menuEntry.end();iter++)
            {
                if(iter->second->isVisible())
                {

                    _aktiveEntry->second->setColor(sf::Color::Green);
                    _aktiveEntry = iter;
                    _aktiveEntry->second->setColor(sf::Color::Blue);
                    break;
                }
            }
        }
    }
}

bool CMenu::isMenuOpen()
{
    return !(_state == Close);
}

///Noch nicht implemtiert
std::string CMenu::getNewState()
{
    if(isMenuOpen() == false)
    {

        return _aktiveEntry->first;
    }
    else
        return "";
}

void CMenu::onLoadState()
{
    _state = LoadAnimation;
    for(listiter iter = _menuEntry.begin(); iter != _menuEntry.end(); iter++)
    {
        iter->second->resetAnimation();

    }
    _aktiveEntry->second->setColor(sf::Color::Green);
    if((*_lastlevel) == "")
        {
            for(listiter iter = _menuEntry.begin(); iter != _menuEntry.end(); iter++)
                if(iter->first == "Con")
                    iter->second->setVisible(false);

        }
        else
        {
            if(_lastlevel == 0)
            {
                for(listiter iter = _menuEntry.begin(); iter != _menuEntry.end(); iter++)
                    if(iter->first == "Con")
                        iter->second->setVisible(true)        ;
            }
        }
//    if((*_lastlevel) == "")
//        _menuEntry["Con"]->setVisible(false);
//    else
//        _menuEntry["2Con"]->setVisible(true);
}
