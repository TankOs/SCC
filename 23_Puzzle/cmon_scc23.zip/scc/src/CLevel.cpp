#include "CLevel.hpp"
#include <string>
#include "helperfunctions.hpp"
#include <iostream>
CLevel::CLevel()
{
}

CLevel::CLevel(std::stringstream &file, CZoneManager &zoneManager, const sf::Vector2f &size):_size(size)
{
    loadFromStream(file,zoneManager);
}

void CLevel::loadFromStream(std::stringstream &file, CZoneManager &zoneManager)
{
    std::string line;

    for(getline(file,line);file.eof()==false; getline(file,line))
    {
        SZoneInformation zone;
        zone.zone = zoneManager.getZone(line);
        getline(file,line);
        zone.startpos.x = StringToInt(line);
        getline(file,line);
        zone.startpos.y = StringToInt(line);
        getline(file,line);
        zone.endpos.x = StringToInt(line);
        getline(file,line);
        zone.endpos.y = StringToInt(line);
        zone.visible = true;

        zone.animator.setAnimation(zone.zone,zone.startpos,zone.endpos);
        zone.zone->SetPosition(zone.startpos);
        _liste.push_back(zone);
    }
}

void CLevel::drawLevel(sf::RenderWindow &window)
{
    for(std::list<SZoneInformation>::iterator iter=_liste.begin();iter!=_liste.end();iter++)
    {
        if(iter->visible == true)
            iter->zone->draw(window);
    }
    //sf::Rect<float> helper(100,100,300,300);

    //window.Draw(sf::Shape::Rectangle(100,100,300,300,sf::Color(100,100,100,20)));
}

bool CLevel::playerMove(int richtung)
{
    bool r = false;
    for(std::list<SZoneInformation>::iterator iter=_liste.begin();iter!=_liste.end();iter++)
    {
        if(iter->visible == true)
            if(iter->zone->playerMove(richtung) == true)
                r = true;
    }
    return r;
}

void CLevel::resetPlayer()
{
    for(std::list<SZoneInformation>::iterator iter=_liste.begin();iter!=_liste.end();iter++)
    {
        iter->zone->reset();
    }
}

void CLevel::SetPosition(sf::Vector2f &pos)
{
    _pos = pos;
    for(std::list<SZoneInformation>::iterator iter=_liste.begin();iter!=_liste.end();iter++)
    {
        iter->startpos += pos;
        iter->endpos   += pos;
        iter->animator.setAnimation(iter->zone,iter->startpos,iter->endpos);
        iter->visible = true;
    }
}

bool CLevel::move(sf::RenderWindow &window)
{
    for(std::list<SZoneInformation>::iterator iter=_liste.begin();iter!=_liste.end();iter++)
    {
        if(iter->animator.Animation(window) == true)
            return true;
    }
        intersect();
    return false;
}

bool CLevel::win()
{
    for(std::list<SZoneInformation>::iterator iter=_liste.begin();iter!=_liste.end();iter++)
    {
        if(iter->visible == true && iter->zone->win() == false)
            return false;
    }
    return true;
}

void CLevel::resetAnimation()
{

    for(std::list<SZoneInformation>::iterator iter = _liste.begin();iter!=_liste.end();iter++)
    {
        iter->zone->SetPosition(iter->startpos);
        iter->animator.setAnimation(iter->zone,iter->startpos,iter->endpos);
        iter->visible = true;
    }
}

bool CLevel::intersect()
{
    sf::Rect<float> helper(_pos.x,_pos.y,_pos.x+_size.x,_pos.y+_size.y);
    for(std::list<SZoneInformation>::iterator iter = _liste.begin();iter!=_liste.end();iter++)
    {
     SZoneInformation tmp=  (*iter);
     sf::Rect<float> zoneR = tmp.zone->getRect();
     if(zoneR.Intersects(helper) == false)
     {
         std::cout << "entferen" << std::endl;
         iter->visible = false;
//         _liste.erase(iter);
//         iter = _liste.begin();
     }
    }

}
