#include "CStateManager.hpp"

CStateManager::CStateManager()
{
    _aktiveState = "";
    _prevState = "";
}

CStateManager::CStateManager(const std::string &state)
{
    _aktiveState = state;
    _prevState = "";
}

std::string CStateManager::getAktiveState() const
{
    return _aktiveState;
}

std::string CStateManager::getPrevState() const
{
    return _prevState;
}

void CStateManager::changeState(const std::string &state)
{
    _prevState = _aktiveState;
    _aktiveState = state;
}
