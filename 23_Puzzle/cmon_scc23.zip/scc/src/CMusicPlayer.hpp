#ifndef CMUSICPLAYER_HPP
#define CMUSICPLAYER_HPP
#include <SFML/Audio.hpp>
#include <SFML/System.hpp>
#include <list>
#include <string>
#include <SFML/Graphics.hpp>

struct STrackInformation
{
    std::string folder;
    std::string artist;
    std::string trackname;
    std::string filename;
};
class CMusicPlayer: public sf::Thread
{
public:
    CMusicPlayer(sf::String &musicTitle);
    ~CMusicPlayer();
    virtual void Run();
    void increaseVolumen();
    void decreaseVolumen();


protected:
    std::list<STrackInformation*> _musicListe;
    std::list<STrackInformation*>::iterator _aktiveMusic;
    //std::list<std::string> _musicListe;
    //std::list<std::string>::iterator _aktiveMusic;
    sf::String &_musicTitle;
    sf::Music _aktiveTrack;
};

#endif // CMUSICPLAYER_HPP
