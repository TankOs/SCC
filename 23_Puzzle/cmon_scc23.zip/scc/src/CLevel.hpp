#ifndef CLEVEL_HPP
#define CLEVEL_HPP

#include <SFML/Graphics.hpp>
#include <list>
#include <sstream>

#include "CZone.hpp"
#include "SFML/Graphics.hpp"
#include "Templates/TAnimationHelper.hpp"
#include "CZoneManager.hpp"


struct SZoneInformation{
    CZone *zone;
    sf::Vector2f startpos;
    sf::Vector2f endpos;
    TAnimationHelper<CZone> animator;
    bool visible;
};

class CLevel
{
public:
    CLevel();
    CLevel(std::stringstream &file,CZoneManager &zoneManager, const sf::Vector2f &size);
    void loadFromStream(std::stringstream &file,CZoneManager &zoneManager);
    void drawLevel(sf::RenderWindow &window);
    bool playerMove(int richtung);
    void resetPlayer();
    void SetPosition(sf::Vector2f &pos);
    void resetAnimation();
    bool move(sf::RenderWindow &window);
    bool win();
    bool intersect();

protected:
    std::list<SZoneInformation> _liste;
    sf::Vector2f _pos;
    sf::Vector2f _size;

};

#endif // CLEVEL_HPP
