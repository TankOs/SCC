#ifndef CLEVELMANAGER_HPP
#define CLEVELMANAGER_HPP
#include <map>
#include <string>
#include "CLevel.hpp"
#include "CPacker.hpp"
#include "CZoneManager.hpp"
#include <SFML/Graphics.hpp>
enum ELevelState{playAnimation,play,end,levelcomplet,MENU,gameover};
class CLevelManager
{
public:
    CLevelManager();
    CLevelManager(CPacker &packer);

    void event(sf::Event &event);
    void logic(sf::RenderWindow &window);
    void drawAktiveLevel(sf::RenderWindow &window);
    std::string getNewState();
    void onLoadState();

    void loadLevel(std::string name);
    void loadFromPacker(CPacker &packer);
    void SetPosition(const sf::Vector2f &pos);
    std::string getAktiveLevel();
    void setMoves(int moves);
    int getMoves();

protected:
    bool win();
    bool loadNextLevel();
    void updateMoves();


protected:
    std::map<std::string,CLevel*> _levelListe;
    std::map<std::string,CLevel*>::iterator _aktiveLevel;
    CZoneManager *_zoneManager;
    sf::Vector2f _pos;
    sf::Vector2f _size;
    ELevelState _state;
    sf::String _Smoves;
    int _Imoves;
    int _Ilevelmoves;
};

#endif // CLEVELMANAGER_HPP
