#ifndef CZONE_HPP
#define CZONE_HPP

#include <string>
#include <SFML/Graphics.hpp>
#include "Templates/TDynamic2DVector.hpp"
#include <sstream>
#include "CPacker.hpp"
enum ERichtung{up=0,right=1,down=2,left=3};
enum EFeldTyp{path=0,wall=1,player=2,ziel=3,win=5};

class CZone
{
public:
    CZone(std::stringstream &file);
    void draw(sf::RenderWindow &window);
    void SetPosition(float offsetX, float offsetY);
    void SetPosition(sf::Vector2f);
    sf::Vector2f getPos();
    sf::Rect<float> getRect();
    bool win();
    void reset();
    bool playerMove(int richtug);
protected:
    void loadFromStream(std::stringstream &file);


protected:
    TDynamic2DVector<int> _feld;
    sf::Vector2f _pos;
    sf::Vector2i _playerPos;
    sf::Vector2i _playerStartPos;
}   ;

#endif // CZONE_HPP
