#include <string>
#include <sstream>
#include <SFML/Graphics.hpp>


int StringToInt(std::string value)
{
    std::stringstream stream(value);
    int iReturn;
    stream >> iReturn;
    return iReturn;
}

int StringToInt(char &value)
{
    std::stringstream stream;
    stream << value;
    int iReturn;
    stream >> iReturn;
    return iReturn;
}

sf::Vector2f Interpolate(sf::Vector2f &pointA, sf::Vector2f &pointB, float factor)
{
   if( factor > 1.f )
        factor = 1.f;

   else if( factor < 0.f )
        factor = 0.f;

   return pointA + (pointB - pointA) * factor;
}




