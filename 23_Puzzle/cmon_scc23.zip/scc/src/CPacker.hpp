#ifndef CPACKER_HPP
#define CPACKER_HPP

#include <string>
#include <vector>
#include <sstream>
enum SFlag{non=0,open=1,fail=2};
struct SPackerHeader
{
    char uniqueID[5]; /// Unique ID used to know if this file is a DAT File from this class
    char version[3]; /// Version of the DAT file format
    unsigned int nb_files; /// Number of files in the DAT file
};

struct SFileEntry
{
    char name[300]; /// Name of the data file
    long size; /// Size of the data file
    long offset; /// Offset, in the DAT file where the file is
};



class CPacker
{
public:
    CPacker();
    ~CPacker ();
    bool Create (std::vector<std::string> files, std::string destination);
    void Read (std::string source);
    char* GetFile (std::string filename);
    long int GetFileSize (std::string filename);
    int getStatus();
    void testausgabe();
protected:
    std::string m_datfile; /// name of the DAT file
    SPackerHeader _PackeHeader; /// file header
    std::vector<SFileEntry> _fileList; /// vector of files entries
    char* _aktiveFileBuffer; /// Buffer pointing on a file in memory
    int _statusFlag;

};

#endif // CPACKER_HPP
