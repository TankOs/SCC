#include "CLevelManager.hpp"
#include <sstream>
#include <iostream>

CLevelManager::CLevelManager():_state(playAnimation),_size(300,300)
{
    _zoneManager = new CZoneManager();
}

CLevelManager::CLevelManager(CPacker &packer):_state(playAnimation),_size(300,300),_Imoves(0),_Ilevelmoves(0)
{
    _zoneManager = new CZoneManager(packer);
    loadFromPacker(packer);
    _aktiveLevel = _levelListe.begin();
    _Smoves.SetText("moves: 0");
    _Smoves.SetSize(20);
    _Smoves.SetPosition(100,50);
}

void CLevelManager::loadFromPacker(CPacker &packer)
{
    std::string line;
    std::stringstream file;
    file << packer.GetFile("level");
    for(getline(file,line);file.eof() == false; getline(file,line))
    {
        std::cout << line << std::endl;
        std::stringstream levelFile;
        levelFile <<packer.GetFile(line);
        _levelListe[line] =  new CLevel(levelFile,*_zoneManager,_size);
    }
}

void CLevelManager::drawAktiveLevel(sf::RenderWindow &window)
{
    _aktiveLevel->second->drawLevel(window);
    window.Draw(sf::Shape::Rectangle(_pos,sf::Vector2f(400,400),sf::Color(0,0,0,0),2.f,sf::Color::Green));
    if(_state == end)
    {
        sf::String Swin("Game Over");
        Swin.SetPosition(_pos);
        Swin.SetColor(sf::Color::Red);
        window.Draw(Swin);
    }
    window.Draw(sf::Shape::Rectangle(0,0,window.GetWidth(),_pos.y,sf::Color::Black));
    window.Draw(sf::Shape::Rectangle(0,_pos.y+300,window.GetWidth(),window.GetHeight(),sf::Color::Black));
    window.Draw(sf::Shape::Rectangle(0,_pos.y,_pos.x,_pos.y+300,sf::Color::Black));
    window.Draw(sf::Shape::Rectangle(_pos.x+300,_pos.y,window.GetWidth(),_pos.y+300,sf::Color::Black));
    window.Draw(_Smoves);
}

void CLevelManager::event(sf::Event &event)
{
    if(_state == play && event.Type == sf::Event::KeyReleased)
    {
        if(event.Key.Code == sf::Key::Up)
        {
            if(_aktiveLevel->second->playerMove(0) == true)
                _Ilevelmoves++;
        }
        else if(event.Key.Code == sf::Key::Down)
        {
            if(_aktiveLevel->second->playerMove(2) == true)
                _Ilevelmoves++;
        }
        else if(event.Key.Code == sf::Key::Left)
        {
            if(_aktiveLevel->second->playerMove(3) == true)
                _Ilevelmoves++;
        }
        else if(event.Key.Code == sf::Key::Right)
        {
            if(_aktiveLevel->second->playerMove(1))
                _Ilevelmoves++;
        }
        else if(event.Key.Code == sf::Key::R)
        {
            _Ilevelmoves = 0;
            _aktiveLevel->second->resetPlayer();
        }
        if(event.Key.Code == sf::Key::Escape)
        {
            _Ilevelmoves = 0;
            _state = MENU;
        }
        updateMoves();
    }
    else if(_state == end && event.Type ==sf::Event::KeyReleased)
    {
        if(event.Key.Code== sf::Key::Return)
            _state = gameover;
    }
}

void CLevelManager::SetPosition(const sf::Vector2f &pos)
{
    _pos =pos;
    for( std::map<std::string,CLevel*>::iterator iter = _levelListe.begin(); iter != _levelListe.end();iter++)
    {
        iter->second->SetPosition(_pos);
    }
}

void CLevelManager::logic(sf::RenderWindow &window)
{
    if(_state == playAnimation)
    {
        if(_aktiveLevel->second->move(window) == false)
            _state = play;
    }
    else if(_state == play)
    {
        if(win())
        {
            _Imoves += _Ilevelmoves;
            _Ilevelmoves = 0;
            if(loadNextLevel() == true)
                _state = playAnimation;
            else
                _state = end;
        }
    }
}

void CLevelManager::loadLevel(std::string name)
{
    if(name == "")
    {
        _aktiveLevel = _levelListe.begin();
        _Imoves = 0;
    }
    else
    {
        _aktiveLevel = _levelListe.find(name);
    }

    _aktiveLevel->second->resetAnimation();
    _aktiveLevel->second->resetPlayer();
}

bool CLevelManager::win()
{
    return _aktiveLevel->second->win();
}

bool CLevelManager::loadNextLevel()
{
    _aktiveLevel++;
    if(_aktiveLevel == _levelListe.end())
    {
        _aktiveLevel--;
        return false;
    }

    _aktiveLevel->second->resetAnimation();
    _aktiveLevel->second->resetPlayer();

    return true;
}
std::string CLevelManager::getAktiveLevel()
{
    return (*_aktiveLevel).first;
}

std::string CLevelManager::getNewState()
{
    if(_state == MENU)
        return "Menu";
    else if(_state== gameover)
        return "GameOver";
    else
        return "";
}

void CLevelManager::onLoadState()
{
    _state=playAnimation;
    _aktiveLevel->second->resetAnimation();
}

void CLevelManager::updateMoves()
{
    std::stringstream ss;
    ss << "moves: " << _Imoves + _Ilevelmoves;
    _Smoves.SetText(ss.str());
}

void CLevelManager::setMoves(int moves)
{
    _Imoves = moves;
    updateMoves();
}

int CLevelManager::getMoves()
{
    return _Imoves;
}
