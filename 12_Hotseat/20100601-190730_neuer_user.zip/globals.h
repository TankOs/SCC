#ifndef GLOBALS_H
#define GLOBALS_H

#include <SFML/Graphics.hpp>

class Globals
{
public: sf::Vector2i screen;
public: std::string title;
public:
    Globals();
};

#endif // GLOBALS_H
