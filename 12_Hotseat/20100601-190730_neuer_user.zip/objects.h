#ifndef OBJECTS_H
#define OBJECTS_H

#include <SFML/Graphics.hpp>
#include <vector>
#include "globals.h"

class Objects
{
public: sf::Image image;
public: sf::Sprite sprite;
public: Globals globals;
};

class Stone : public Objects
{
public:
    Stone(sf::Vector2f position);
};

class Spieler : public Objects
{
public: int dir;
public: float speed;
private: std::vector<Stone> stones;
public:
    Spieler(std::vector<Stone> steine);
    bool collision();
    void move();
    void changeDirection(int i);
    void update();
};

class Weihnachtsmann : public Objects
{
public: std::vector<char> dirs;
public: int dir;
public: float speed;
public:
    Weihnachtsmann();
    bool collision();
    void move();
    void changeDirection();
    void update();
};

#endif // OBJECTS_H