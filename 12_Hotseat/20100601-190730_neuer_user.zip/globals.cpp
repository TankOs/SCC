#include "globals.h"

Globals::Globals()
{
    screen = sf::Vector2i(800, 600);
    title = "Hotsead";
}
