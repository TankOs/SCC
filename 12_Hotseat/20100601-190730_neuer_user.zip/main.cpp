#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <sstream>
#include "objects.h"
#include "globals.h"

//std::vector<Stone> stones;
//Spieler player1(stones);
//Spieler player2(stones);
Weihnachtsmann weihnachtsmann;
Globals globals;
sf::RenderWindow window;
sf::Image backgroundImg,stoneImg,spielerImg;
sf::Sprite background;
sf::Font font;
sf::String string;
bool pause;

void init()
{
std::vector<Stone> stones;
    for(int i = 0;i < sf::Randomizer::Random(5, 10);i++)
    {
	stones.push_back(Stone(getRandomVector()));
	stones.at(i).image = stoneImg;
    }

Spieler player1(stones);
Spieler player2(stones);
}

sf::Vector2f getRandomVector()
{
    return sf::Vector2f(sf::Randomizer::Random(0.0, (float)globals.screen.x), sf::Randomizer::Random(0.0, (float)globals.screen.y));
}

void getEvents()
{
    sf::Event event;
    window.GetEvent(event);

    switch(event.Type)
    {
	default:
	{
	    break;
	}
	case sf::Event::Closed:
	{
	    window.Close();
	    break;
	}
	case sf::Event::KeyPressed:
	{
	    switch(event.Key.Code)
	    {
		default:
		{
		    break;
		}
		case sf::Key::Escape:
		{
		    window.Close();
		    break;
		}
		case sf::Key::Pause:
		{
		    if(pause)
			pause = false;
		    else
			pause = true;
		    break;
		}
		//Spieler 1
		case sf::Key::W:
		{
		    player1.changeDirection(0);
		    break;
		}
		case sf::Key::S:
		{
		    player1.changeDirection(1);
		    break;
		}
		case sf::Key::A:
		{
		    player1.changeDirection(2);
		    break;
		}
		case sf::Key::D:
		{
		    player1.changeDirection(3);
		    break;
		}
		//Spieler 2
		case sf::Key::Up:
		{
		    player2.changeDirection(0);
		    break;
		}
		case sf::Key::Down:
		{
		    player2.changeDirection(1);
		    break;
		}
		case sf::Key::Left:
		{
		    player2.changeDirection(2);
		    break;
		}
		case sf::Key::Right:
		{
		    player2.changeDirection(3);
		    break;
		}
	    }
	    break;
	}
    }
}

void update()
{
    window.Clear(sf::Color::White);

    window.Draw(background);
    for(int i = 0;i < stones.size();i++)
    {
	window.Draw(stones.at(i).sprite);
    }
    window.Draw(player1.sprite);
    window.Draw(player2.sprite);
    window.Draw(weihnachtsmann.sprite);
    window.Draw(string);

    window.Display();
}

int main()
{
    window.Create(sf::VideoMode(globals.screen.x, globals.screen.y, 32), globals.title, sf::Style::Close, sf::WindowSettings(32, 0, 4));

    font.LoadFromFile("arial.ttf");
    string = sf::String("", font, 24);

    stoneImg.LoadFromFile("stone.png");
    weihnachtsmann.image.LoadFromFile("_weihnachtsmann_l_u.png");
    spielerImg.LoadFromFile("spieler.png");

    player1.image = spielerImg;
    player2.image = spielerImg;

    init();

    std::ostringstream ostd;
    ostd<<stones.size()<<"\n"<<stones.at(0).sprite.GetPosition().x<<" x "<<stones.at(0).sprite.GetPosition().y;
    string.SetText(ostd.str());
    string.SetColor(sf::Color::Blue);

    pause = false;

    while(window.IsOpened())
    {
	getEvents();

	if(!pause)
	{
	    weihnachtsmann.update();
	    player1.update();
	    player2.update();
	    update();
	}
    }

    return 0;
}