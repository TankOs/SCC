#include "objects.h"

Weihnachtsmann::Weihnachtsmann()
{
    sprite = sf::Sprite();
    sprite.SetImage(image);
    sprite.SetSubRect(sf::IntRect(0, 0, 50, 50));

    dirs.push_back('u');
    dirs.push_back('d');
    dirs.push_back('l');
    dirs.push_back('r');

    dir = 0;

    speed = 0.1;
}

bool Weihnachtsmann::collision()
{
    switch(dir)
    {
	default:
	{
	    break;
	}
	case 0:
	{
	    if(sprite.GetPosition().y <= 0)
		return true;
	    break;
	}
	case 1:
	{
	    if(sprite.GetPosition().y+50 >= globals.screen.y)
		return true;
	    break;
	}
	case 2:
	{
	    if(sprite.GetPosition().x <= 0)
		return true;
	    break;
	}
	case 3:
	{
	    if(sprite.GetPosition().x+50 >= globals.screen.x)
		return true;
	    break;
	}
    }
    return false;
}

void Weihnachtsmann::move()
{
    switch(dirs.at(dir))
    {
	default:
	{
	    break;
	}
	case 'u':
	{
	    sprite.SetPosition(sprite.GetPosition().x, sprite.GetPosition().y-speed);
	    break;
	}
	case 'd':
	{
	    sprite.SetPosition(sprite.GetPosition().x, sprite.GetPosition().y+speed);
	    break;
	}
	case 'l':
	{
	    sprite.SetPosition(sprite.GetPosition().x-speed, sprite.GetPosition().y);
	    break;
	}
	case 'r':
	{
	    sprite.SetPosition(sprite.GetPosition().x+speed, sprite.GetPosition().y);
	    break;
	}
    }
}

void Weihnachtsmann::changeDirection()
{
    switch(dir)
    {
	default:
	{
	    break;
	}
	case 0:
	{
	    switch(sf::Randomizer::Random(0, 2))
	    {
		default:
		{
		    break;
		}
		case 0:
		{
		    dir = 1;
		    break;
		}
		case 1:
		{
		    dir = 2;
		    break;
		}
		case 2:
		{
		    dir = 3;
		    break;
		}
	    }
	    break;
	}
	case 1:
	{
	    switch(sf::Randomizer::Random(0, 2))
	    {
		default:
		{
		    break;
		}
		case 0:
		{
		    dir = 0;
		    break;
		}
		case 1:
		{
		    dir = 2;
		    break;
		}
		case 2:
		{
		    dir = 3;
		    break;
		}
	    }
	    break;
	}
	case 2:
	{
	    switch(sf::Randomizer::Random(0, 2))
	    {
		default:
		{
		    break;
		}
		case 0:
		{
		    dir = 0;
		    break;
		}
		case 1:
		{
		    dir = 1;
		    break;
		}
		case 2:
		{
		    dir = 3;
		    break;
		}
	    }
	    break;
	}
	case 3:
	{
	    switch(sf::Randomizer::Random(0, 2))
	    {
		default:
		{
		    break;
		}
		case 0:
		{
		    dir = 0;
		    break;
		}
		case 1:
		{
		    dir = 1;
		    break;
		}
		case 2:
		{
		    dir = 2;
		    break;
		}
	    }
	    break;
	}
    }
}

void Weihnachtsmann::update()
{
    if(sf::Randomizer::Random(0, 699) == 99 || collision())
    {
	changeDirection();
    }
    move();
}

Spieler::Spieler(std::vector<Stone> steine)
{
    stones = steine;
    sprite = sf::Sprite();
    sprite.SetImage(image);
    sprite.SetSubRect(sf::IntRect(0, 0, 50, 50));

    dir = 0;

    speed = 0.1;
}

bool Spieler::collision()
{
    switch(dir)
    {
	default:
	{
	    break;
	}
	case 0:
	{
	    if(sprite.GetPosition().y <= 0)
		return true;
	    break;
	}
	case 1:
	{
	    if(sprite.GetPosition().y+50 >= globals.screen.y)
		return true;
	    break;
	}
	case 2:
	{
	    if(sprite.GetPosition().x <= 0)
		return true;
	    break;
	}
	case 3:
	{
	    if(sprite.GetPosition().x+50 >= globals.screen.x)
		return true;
	    break;
	}
    }

    for(int i = 0;i < stones.size();i++)
    {
	if(sprite.GetPosition().x > stones.at(i).sprite.GetPosition().x-50 && sprite.GetPosition().x < stones.at(i).sprite.GetPosition().x+50 && sprite.GetPosition().y > stones.at(i).sprite.GetPosition().y-50 && sprite.GetPosition().y < stones.at(i).sprite.GetPosition().y+50)
	{
	    return true;
	}
    }

    return false;
}

void Spieler::move()
{
    if(collision())
	return;

    switch(dir)
    {
	default:
	{
	    break;
	}
	case 0:
	{
	    sprite.SetPosition(sprite.GetPosition().x, sprite.GetPosition().y-speed);
	    break;
	}
	case 1:
	{
	    sprite.SetPosition(sprite.GetPosition().x, sprite.GetPosition().y+speed);
	    break;
	}
	case 2:
	{
	    sprite.SetPosition(sprite.GetPosition().x-speed, sprite.GetPosition().y);
	    break;
	}
	case 3:
	{
	    sprite.SetPosition(sprite.GetPosition().x+speed, sprite.GetPosition().y);
	    break;
	}
    }
}

void Spieler::changeDirection(int i)
{
    dir = i;
}

void Spieler::update()
{
    move();
}

Stone::Stone(sf::Vector2f position)
{
    sprite = sf::Sprite();
    sprite.SetImage(image);
    sprite.SetPosition(position);
    sprite.SetSubRect(sf::IntRect(0, 0, 50, 50));
    sprite.SetColor(sf::Color::Black);
}