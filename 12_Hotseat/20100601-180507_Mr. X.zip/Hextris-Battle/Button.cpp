#include "Button.h"

bool Button::IsClicked(sf::Vector2i MousePosition) const {
	MousePosition.x -= static_cast<int>(GetPosition().x);
	MousePosition.y -= static_cast<int>(GetPosition().y);
	if(MousePosition.x > Rand.GetPointPosition(0).x && MousePosition.x < Rand.GetPointPosition(2).x && MousePosition.y > Rand.GetPointPosition(0).y && MousePosition.y < Rand.GetPointPosition(2).y) {
		OnClick();
		return(true);
	}
	return(false);
}
Button::Button(const sf::String& sText, const sf::Vector2f& Position, const sf::Vector2f& Size, std::tr1::function<void(void)> onClick) : sf::Drawable(Position), Text(sText) {
	OnClick += onClick;
	float Border = 4;
	Text.SetCharacterSize(20);
	Text.SetColor(sf::Color::White);
	Text.SetPosition((int)((Size.x - Text.GetRect().Width) / 2), (int)((Size.y - Text.GetRect().Height) / 2));
	Rand = sf::Shape::Rectangle(0, 0, Size.x, Size.y, sf::Color(0,0,0,0), Border, sf::Color(255, 255, 255, 155));
}

void Button::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(Rand);
	Target.Draw(Text);
}
