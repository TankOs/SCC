#include "Spieler.h"

bool MultiForm = false;

void Spieler::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.SetView(Vorschau);
	for(uint8_t i = 0; i < n�chsteSteine.size(); i++) {
		Target.Draw(*n�chsteSteine[i]);
	}
	Target.SetView(Target.GetDefaultView());
	if(Verloren) {
		Target.Draw(VerlorenT);
	}
}

Spieler::Spieler(Direction id) : VerlorenT("Verloren"), ID(id), curSteine(4), n�chsteSteine(4), Verloren(0), Vorschau(sf::FloatRect(0.f, 0.f, Aufl�sung.Width, Aufl�sung.Height)) {
	VerlorenT.SetCharacterSize(65);
	VerlorenT.SetColor(sf::Color(255, 0, 0, 200));
	N�chste();
	if(ID == RECHTS) {
		Vorschau.Move(-static_cast<float>(Aufl�sung.Width/2+96-14), -30);
		VerlorenT.SetPosition(Aufl�sung.Width/2.f, Aufl�sung.Height/2.f);
	}
	else {
		Vorschau.Move(-static_cast<float>(Aufl�sung.Width/2-96-14), -30);
		VerlorenT.SetPosition(Aufl�sung.Width/2.f - VerlorenT.GetRect().Width, Aufl�sung.Height/2.f);
	}
}
void Spieler::N�chste() {
	n�chsteFormation = static_cast<uint8_t>(sf::Randomizer::Random(0, MultiForm?6:0));
	for(uint8_t i = 0; i < curSteine.size(); i++) {
		if(curSteine[i] != 0) {
			curSteine[i]->Besitzer = NICHTS;
			curSteine[i]->Richtung = NICHTS;
		}
		if(n�chsteSteine[i] != 0) {
			curSteine[i] = n�chsteSteine[i];
		}
		n�chsteSteine[i] = new Stein(ID);
	}
	switch(n�chsteFormation) {
		case 0:
			n�chsteSteine[0]->SetPosition(-42, 0);
			n�chsteSteine[1]->SetPosition(-14, 0);
			n�chsteSteine[2]->SetPosition(14, 0);
			n�chsteSteine[3]->SetPosition(42, 0);
			break;
		case 1:
			n�chsteSteine[0]->SetPosition(-28, 24);
			n�chsteSteine[1]->SetPosition(-14, 0);
			n�chsteSteine[2]->SetPosition(14, 0);
			n�chsteSteine[3]->SetPosition(28, 24);
			break;
		case 2:
			n�chsteSteine[0]->SetPosition(-21, 24);
			n�chsteSteine[1]->SetPosition(-7, 0);
			n�chsteSteine[2]->SetPosition(7, 24);
			n�chsteSteine[3]->SetPosition(21, 0);
			break;
		case 3:
			n�chsteSteine[0]->SetPosition(-21, 0);
			n�chsteSteine[1]->SetPosition(-7, 24);
			n�chsteSteine[2]->SetPosition(7, 0);
			n�chsteSteine[3]->SetPosition(21, 24);
			break;
		case 4:
			n�chsteSteine[0]->SetPosition(-21, 72);
			n�chsteSteine[1]->SetPosition(-7, 48);
			n�chsteSteine[2]->SetPosition(7, 24);
			n�chsteSteine[3]->SetPosition(21, 0);
			break;
		case 5:
			n�chsteSteine[0]->SetPosition(-21, 0);
			n�chsteSteine[1]->SetPosition(-7, 24);
			n�chsteSteine[2]->SetPosition(7, 48);
			n�chsteSteine[3]->SetPosition(21, 72);
			break;
		default:
			n�chsteSteine[0]->SetPosition(-14, 24);
			n�chsteSteine[1]->SetPosition(0, 0);
			n�chsteSteine[2]->SetPosition(14, 24);
			n�chsteSteine[3]->SetPosition(0, 48);
			break;
	}
}
void Spieler::Links() {
	for(std::vector<Stein*>::iterator i = curSteine.begin(); i != curSteine.end(); ++i) {
		if(*i != 0) {
			if((*i)->Richtung == RECHTS)
				(*i)->Richtung = NICHTS;
			else
				(*i)->Richtung = LINKS;
		}
	}
}
void Spieler::Rechts() {
	for(std::vector<Stein*>::iterator i = curSteine.begin(); i != curSteine.end(); ++i) {
		if(*i != 0) {
			if((*i)->Richtung == LINKS)
				(*i)->Richtung = NICHTS;
			else
				(*i)->Richtung = RECHTS;
		}
	}
}
Spieler::~Spieler() {
	for(uint32_t i = 0; i < n�chsteSteine.size(); ++i) {
		delete n�chsteSteine[i];
	}
}