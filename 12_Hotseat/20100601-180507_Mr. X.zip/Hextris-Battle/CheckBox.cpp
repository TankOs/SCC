#include "Checkbox.h"

CheckBox::CheckBox(const sf::String& text, sf::Vector2f Position, std::tr1::function<void(bool)> onChecked, Direction Align, bool CheckState) : sf::Drawable(Position), Checked(CheckState), Text(text) {
	OnChecked += onChecked;
	float Size = 18.f;
	Text.SetColor(sf::Color::White);
	Text.SetCharacterSize(20);
	Line1 = sf::Shape::Line(1.f, Size/2.f, Size/2-1.f, Size-1.f, 2.f, sf::Color::White);
	Line2 = sf::Shape::Line(Size/2.f-1.f, Size-1.f, Size-1.f, 1.f, 2.f, sf::Color::White);
	if(Align == LINKS) {
		Rand = sf::Shape::Rectangle(0.f, 0.f, Size, Size, sf::Color(0,0,0,0), 2.f, sf::Color(255, 255, 255, 155));
		Text.SetPosition(Size+5.f, (int)(Size/2.f - Text.GetRect().Height/2.f));
	}
	else {
		Line1.Move(-Size, 0);
		Line2.Move(-Size, 0);
		Rand = sf::Shape::Rectangle(-Size, 0.f, Size, Size, sf::Color(0,0,0,0), 2.f, sf::Color(255, 255, 255, 155));
		Text.SetPosition(-Text.GetRect().Width - Size-5.f, (int)(Size/2.f - Text.GetRect().Height/2.f) - 2.f);
	}
	OnChecked(Checked);
}
void CheckBox::Clicked(sf::Vector2i MousePosition) {
	MousePosition.x -= static_cast<int>(GetPosition().x);
	MousePosition.y -= static_cast<int>(GetPosition().y);
	if(MousePosition.x > Rand.GetPointPosition(0).x && MousePosition.x < Rand.GetPointPosition(2).x && MousePosition.y > Rand.GetPointPosition(0).y && MousePosition.y < Rand.GetPointPosition(2).y) {
		Checked = !Checked;
		OnChecked(Checked);
	}
}
bool CheckBox::IsChecked() const {
	return(Checked);
}
void CheckBox::Check(bool b) {
	Checked = b;
	OnChecked(Checked);
}
void CheckBox::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	if(Checked) {
		Target.Draw(Line1);
		Target.Draw(Line2);
	}
	Target.Draw(Rand);
	Target.Draw(Text);
}
