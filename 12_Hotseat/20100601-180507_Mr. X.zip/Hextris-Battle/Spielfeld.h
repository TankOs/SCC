#ifndef SPIELFELD_H
#define SPIELFELD_H

#include "Stein.h"
#include "Spieler.h"
#include <list>

class Spielfeld : public sf::Drawable {
	static sf::Image Image;

	sf::Sprite Sprite;

	std::vector<std::vector<Stein*>> Feld;
	
	Spieler& SpielerL;
	Spieler& SpielerR;

	void Bewegen(int8_t x, int8_t y);

	void falle(int8_t x, int8_t y);
	bool kannGerade(int8_t x, int8_t y, int8_t xl, int8_t xr);
	void fallGerade(int8_t x, int8_t y);
	bool kannLinks(int8_t x, int8_t y, int8_t xl, int8_t xr);
	void fallLinks(int8_t x, int8_t y, int8_t xl);
	bool kannRechts(int8_t x, int8_t y, int8_t xl, int8_t xr);
	void fallRechts(int8_t x, int8_t y, int8_t xr);

	virtual void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	mutable sf::Mutex Protector;
	bool GameOver;

	Spielfeld(Spieler& R, Spieler& L);

	void InsertStein(Direction Player, sf::Vector2i dest, Stein* source);
	void neueSteine(Direction Player);
	void NextStep();

	void Einzelnachbar(int8_t x, int8_t y, std::list<sf::Vector2<int8_t>>& nachbarn, uint8_t Farbe);
	void Nachbarn(int8_t x, int8_t y, std::list<sf::Vector2<int8_t>>& nachbarn);
	~Spielfeld();

	static void LoadImages();
};

#endif
