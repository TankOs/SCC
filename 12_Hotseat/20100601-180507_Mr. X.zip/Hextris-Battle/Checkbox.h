#ifndef CHECKBOX_H
#define CHECKBOX_H

#include "Global.h"
#include <SFML/Graphics.hpp>

class CheckBox : public sf::Drawable {
private:
	sf::Text Text;
	sf::Shape Rand;
	sf::Shape Line1, Line2;
	bool Checked;
	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	EventHandler<bool> OnChecked;
	CheckBox(const sf::String& text, sf::Vector2f Position, std::tr1::function<void(bool)> onChecked, Direction Align, bool CheckState = true);
	void Clicked(sf::Vector2i MousePosition);
	bool IsChecked() const;
	void Check(bool b);
};

#endif
