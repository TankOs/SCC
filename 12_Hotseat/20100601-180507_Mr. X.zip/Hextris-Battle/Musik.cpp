#include "Musik.h"

void Player::Run() {
	current = Playlist.begin();
	while(Playlist.size() > 0 && Running) {
		(*current)->SetVolume(0);
		(*current)->Play();
		for(uint8_t i = 0; i < 100; ++i) {
			sf::Sleep(0.05f);
			(*current)->SetVolume(i*1+1);
		}
		sf::Sleep((*current)->GetDuration()-10);
		for(uint8_t i = 0; i < 100; ++i) {
			(*current)->SetVolume(99 - i*1);
			sf::Sleep(0.05f);
		}
		sf::Sleep(4);
		++current;
		if(current == Playlist.end()) {
			current = Playlist.begin();
		}
	}
}
void Player::Load(const std::string& filename) {
	Playlist.push_back(new sf::Music());
	if(!Playlist.back()->OpenFromFile(filename)) {
		Playlist.pop_back();
	}
}
void Player::Stop() {
	if(Running) {
		Running = false;
		(*current)->Stop();
		Terminate();
	}
}
void Player::Start() {
	if(!Running) {
		Running = true;
		Launch();
	}
}

Player::~Player() {
	for(std::vector<sf::Music*>::iterator i = Playlist.begin(); i != Playlist.end(); ++i) {
		delete *i;
	}
}
