#ifndef MUSIK_H
#define MUSIK_H

#include <SFML/Audio.hpp>
#include "Global.h"

class Player : sf::Thread {
	std::vector<sf::Music*> Playlist;
	std::vector<sf::Music*>::iterator current;
	bool Running;
	virtual void Run();
public:
	void Load(const std::string& filename);
	void Stop();
	void Start();
	~Player();
};

#endif
