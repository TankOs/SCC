#ifndef STEIN_H
#define STEIN_H

#include "Global.h"
#include <SFML/Graphics.hpp>

class Stein : public sf::Drawable {
	static sf::Image Images[5];
	sf::Sprite Sprite;

	virtual void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	bool bewegt;
	bool geprueft;
	uint8_t Farbe;
	Direction Richtung;
	Direction Besitzer;

	Stein(Direction besitzer);

	static void LoadImages();
};

#endif
