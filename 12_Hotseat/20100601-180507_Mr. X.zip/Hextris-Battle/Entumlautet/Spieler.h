#ifndef SPIELER_H
#define SPIELER_H

#include "Global.h"
#include "Stein.h"

extern bool MultiForm;

class Spieler : public sf::Drawable, sf::NonCopyable {
	const Direction ID;
	sf::Text VerlorenT;
	sf::View Vorschau;
	virtual void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	bool Verloren;
	uint8_t naechsteFormation;
	std::vector<Stein*> naechsteSteine;
	std::vector<Stein*> curSteine;
	bool bewegt;

	Spieler(Direction id);
	void Naechste();
	void Links();
	void Rechts();

	~Spieler();
};

#endif
