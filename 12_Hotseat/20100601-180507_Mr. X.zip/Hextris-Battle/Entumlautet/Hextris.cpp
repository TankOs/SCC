#include "Global.h"
#include "Spielfeld.h"
#include "Spieler.h"
#include "Musik.h"
#include "Checkbox.h"
#include "Button.h"
#include <ctime>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

bool Running = true;
bool Paused = false;
bool Verloren = false;

void NeuesSpielClicked();

class HextrisBattle : sf::Thread, public sf::Drawable {
	virtual void Render(sf::RenderTarget& Target, sf::Renderer&) const {
		Target.Draw(Feld);
		Target.Draw(SpielerL);
		Target.Draw(SpielerR);
	}
	virtual void Run() {
		// Thread steuert zeitliche Abfolge und Teile der Spiellogik
		sf::Randomizer::SetSeed(~(static_cast<uint32_t>(std::time(NULL)))); // ~ fuer in jedem Thread "garantiert" verschiedene Seeds (sonst 2 mal gleiche Steine)

		sf::Clock Uhr;
		while(Running) {
			if(SpielerR.Verloren || SpielerL.Verloren) {
				for(int i = 0; i < 100 && Running; ++i) {
					sf::Sleep(0.1f);
				}
				Verloren = true;
			}
			else {
				sf::Sleep(0.55f - Uhr.GetElapsedTime()); // Rechenzeit sparen...
				Uhr.Reset();
				if(!Paused) {
					Feld.NextStep();
				}
			}
		}
	}
public:
	Spieler SpielerL;
	Spieler SpielerR;
	Spielfeld Feld;
	HextrisBattle() : SpielerL(LINKS), SpielerR(RECHTS), Feld(SpielerR, SpielerL) {
		Launch();
	}
	void Process(const sf::Input& IP) {
		if(Verloren) {
			NeuesSpielClicked();
			return;
		}
		Feld.Protector.Lock();
		if(IP.IsKeyDown(sf::Key::Left)) {
			SpielerR.Links();
		}
		if(IP.IsKeyDown(sf::Key::Right)) {
			SpielerR.Rechts();
		}
		if(IP.IsKeyDown(sf::Key::A)) {
			SpielerL.Links();
		}
		if(IP.IsKeyDown(sf::Key::S)) {
			SpielerL.Rechts();
		}
		Feld.Protector.Unlock();
	}
	~HextrisBattle() {
		Wait();
	}
};

HextrisBattle* Game;

Player MusicPlayer;

void MusicChecked(bool checked) {
	if(checked)
		MusicPlayer.Start();
	else
		MusicPlayer.Stop();
}
void ExitClicked() {
	Running = false;
	delete Game;
	MusicPlayer.Stop();
	exit(0);
}
void NeuesSpielClicked() {
	Running = false;
	delete Game;
	Running = true;
	Paused = false;
	Verloren = false;
	Game = new HextrisBattle();
}
void PauseChecked(bool checked) {
	Paused = checked;
}
void SteinformationenChecked(bool checked) {
	MultiForm = checked;
}

sf::RenderWindow RW;

void VollbildChecked(bool checked) {
	if(checked) {
		RW.Create(Aufloesung, "Hextris-Battle 1.0 - Weihnachtsmann-Edition", sf::Style::Fullscreen);
	}
	else {
		RW.Create(Aufloesung, "Hextris-Battle 1.0 - Weihnachtsmann-Edition", sf::Style::Titlebar | sf::Style::Close);
	}
}

int main() {
	// Ressourcen laden
	sf::Image iHintergrund;
	iHintergrund.LoadFromFile("Grafik/Hintergrund.png");
	Stein::LoadImages();
	Spielfeld::LoadImages();
	
	MusicPlayer.Load("Musik/Nikolaus.ogg");
	MusicPlayer.Load("Musik/Tannebaum.ogg");
	MusicPlayer.Load("Musik/Alle Jahre.ogg");


	RW.SetFramerateLimit(60);

	// Events und Input
	sf::Event EV;

	// Sprites initiieren
	sf::Sprite Hintergrund(iHintergrund);

	// GUI initiieren
	CheckBox Vollbild("Vollbild", sf::Vector2f(7.f, Aufloesung.Height - 52.f), &VollbildChecked, LINKS, false);
	CheckBox Music("Musik abspielen", sf::Vector2f(7.f, Aufloesung.Height - 25.f), &MusicChecked, LINKS);
	Button Exit("Beenden", sf::Vector2f(Aufloesung.Width/2.f - 110, Aufloesung.Height - 33.f), sf::Vector2f(95, 25), &ExitClicked);
	Button NeuesSpiel("Neues Spiel", sf::Vector2f(Aufloesung.Width/2.f, Aufloesung.Height - 33.f), sf::Vector2f(120, 25), &NeuesSpielClicked);
	CheckBox Pause("Pausiert", sf::Vector2f(Aufloesung.Width - 7.f, Aufloesung.Height - 52.f), &PauseChecked, RECHTS, false);
	CheckBox Steinformationen("Steinformationen", sf::Vector2f(Aufloesung.Width - 7.f, Aufloesung.Height - 25.f), &SteinformationenChecked, RECHTS, false);

	Game = new HextrisBattle();

	while(Running) {
		while(RW.GetEvent(EV)) {
			switch(EV.Type) {
				case sf::Event::Closed:
					RW.Close();
					Running = false;
					break;
				case sf::Event::KeyPressed:
					switch(EV.Key.Code) {
						case sf::Key::Escape:
							RW.Close();
							Running = false;
							break;
						case sf::Key::Pause:
							Pause.Check(!Pause.IsChecked());
							break;
						default:
							break;
					}
					break;
				case sf::Event::MouseButtonPressed:
					if(EV.MouseButton.Button == sf::Mouse::Left) {
						Music.Clicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y));
						Exit.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y));
						if(NeuesSpiel.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
							Pause.Check(false);
						}
						Pause.Clicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y));
						Vollbild.Clicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y));
						Steinformationen.Clicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y));
					}
					break;
				default:
					break;
			}
		}
		Game->Process(RW.GetInput());
		RW.Clear();
		RW.Draw(Hintergrund);
		RW.Draw(*Game);
		RW.Draw(Music);
		RW.Draw(Exit);
		RW.Draw(NeuesSpiel);
		RW.Draw(Pause);
		RW.Draw(Vollbild);
		RW.Draw(Steinformationen);
		RW.Display();
	}
	ExitClicked();
	return(0);
}
