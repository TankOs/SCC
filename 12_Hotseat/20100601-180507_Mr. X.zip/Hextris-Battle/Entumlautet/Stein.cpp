#include "Stein.h"

sf::Image Stein::Images[5];
void Stein::LoadImages() {
	Images[0].LoadFromFile("Grafik/Hexagon0_w.png");
	Images[1].LoadFromFile("Grafik/Hexagon1_w.png");
	Images[2].LoadFromFile("Grafik/Hexagon2_w.png");
	Images[3].LoadFromFile("Grafik/Hexagon3_w.png");
	Images[4].LoadFromFile("Grafik/Hexagon4_w.png");
}

Stein::Stein(Direction besitzer) : Farbe(static_cast<uint8_t>(sf::Randomizer::Random(0, 4))), Richtung(NICHTS), Besitzer(besitzer), geprueft(false), bewegt(false) {
	Sprite.SetImage(Images[Farbe]);
}

void Stein::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(Sprite);
}
