#include "Spielfeld.h"
#include <algorithm>

using std::min;

sf::Image Spielfeld::Image;
void Spielfeld::LoadImages() {
	Image.LoadFromFile("Grafik/Spielfeld.png");
}


Spielfeld::Spielfeld(Spieler& R, Spieler& L) : SpielerR(R), SpielerL(L), Sprite(Image), GameOver(false) {
	Feld.resize(16);
	for(uint8_t x = 0; x < 16; ++x) {
		for(uint8_t y = 0; y < 15; y++) {
			Feld[x].push_back(nullptr);
		}
	}
	SetPosition((Aufloesung.Width - Sprite.GetSize().x) / 2, (Aufloesung.Height - Sprite.GetSize().y) / 2 + 50);
	Sprite.SetPosition(-2, -2);
	//Form des Feldes festlegen
	//Spitze mitte oben
	Feld[6][0] = (Stein*)(1);
	Feld[7][0] = (Stein*)(1);
	Feld[8][0] = (Stein*)(1);
	Feld[7][1] = (Stein*)(1);
	Feld[8][1] = (Stein*)(1);
	Feld[7][2] = (Stein*)(1);
	//Spitze mitte unten
	Feld[6][14] = (Stein*)(1);
	Feld[7][14] = (Stein*)(1);
	Feld[8][14] = (Stein*)(1);
	Feld[7][13] = (Stein*)(1);
	Feld[8][13] = (Stein*)(1);
	Feld[7][12] = (Stein*)(1);
	for(size_t y = 0; y < Feld.back().size(); y+=2) {
		Feld.back()[y] = (Stein*)(1);
	}
}

void Spielfeld::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(Sprite);
	Protector.Lock(); // Schuetzt gegen �nderungen waehrend des Zeichens -> Kein "zerrissenes" Bild
	for(uint8_t x = 0; x < Feld.size(); x++) {
		for(uint8_t y = 0; y < Feld[x].size(); y++) {
			if(Feld[x][y] > (Stein*)(1)) {
				if(y%2 == 0) {
					Feld[x][y]->SetPosition(x*28.f+14.f, y*24.f);
				}
				else { // Reihe eingerueckt
					Feld[x][y]->SetPosition(x*28.f, y*24.f);
				}
				Target.Draw(*Feld[x][y]);
			}
		}
	}
	Protector.Unlock();
}
void Spielfeld::InsertStein(Direction Player, sf::Vector2i dest, Stein* source) {
	if(Feld[dest.x][dest.y] != 0) {
		if(Player == RECHTS) {
			SpielerR.Verloren = true;
		}
		else {
			SpielerL.Verloren = true;
		}
		delete source;
	}
	else {
		Feld[dest.x][dest.y] = source;
	}
}
void Spielfeld::neueSteine(Direction Player) {
	Spieler* curSpieler;
	int lAnchor;
	if(Player == RECHTS) {
		lAnchor = 9;
		curSpieler = &SpielerR;
	}
	else {
		lAnchor = 2;
		curSpieler = &SpielerL;
	}
	switch(curSpieler->naechsteFormation) {
		case 0:
			InsertStein(Player, sf::Vector2i(lAnchor+0, 0), curSpieler->naechsteSteine[0]);
			InsertStein(Player, sf::Vector2i(lAnchor+1, 0), curSpieler->naechsteSteine[1]);
			InsertStein(Player, sf::Vector2i(lAnchor+2, 0), curSpieler->naechsteSteine[2]);
			InsertStein(Player, sf::Vector2i(lAnchor+3, 0), curSpieler->naechsteSteine[3]);
			break;
		case 1:
			InsertStein(Player, sf::Vector2i(lAnchor+1, 1), curSpieler->naechsteSteine[0]);
			InsertStein(Player, sf::Vector2i(lAnchor+1, 0), curSpieler->naechsteSteine[1]);
			InsertStein(Player, sf::Vector2i(lAnchor+2, 0), curSpieler->naechsteSteine[2]);
			InsertStein(Player, sf::Vector2i(lAnchor+3, 1), curSpieler->naechsteSteine[3]);
			break;
		case 2:
			InsertStein(Player, sf::Vector2i(lAnchor+1, 1), curSpieler->naechsteSteine[0]);
			InsertStein(Player, sf::Vector2i(lAnchor+1, 0), curSpieler->naechsteSteine[1]);
			InsertStein(Player, sf::Vector2i(lAnchor+2, 1), curSpieler->naechsteSteine[2]);
			InsertStein(Player, sf::Vector2i(lAnchor+2, 0), curSpieler->naechsteSteine[3]);
			break;
		case 3:
			InsertStein(Player, sf::Vector2i(lAnchor+1, 0), curSpieler->naechsteSteine[0]);
			InsertStein(Player, sf::Vector2i(lAnchor+2, 1), curSpieler->naechsteSteine[1]);
			InsertStein(Player, sf::Vector2i(lAnchor+2, 0), curSpieler->naechsteSteine[2]);
			InsertStein(Player, sf::Vector2i(lAnchor+3, 1), curSpieler->naechsteSteine[3]);
			break;
		case 4:
			InsertStein(Player, sf::Vector2i(lAnchor+1, 3), curSpieler->naechsteSteine[0]);
			InsertStein(Player, sf::Vector2i(lAnchor+1, 2), curSpieler->naechsteSteine[1]);
			InsertStein(Player, sf::Vector2i(lAnchor+2, 1), curSpieler->naechsteSteine[2]);
			InsertStein(Player, sf::Vector2i(lAnchor+2, 0), curSpieler->naechsteSteine[3]);
			break;
		case 5:
			InsertStein(Player, sf::Vector2i(lAnchor+1, 0), curSpieler->naechsteSteine[0]);
			InsertStein(Player, sf::Vector2i(lAnchor+2, 1), curSpieler->naechsteSteine[1]);
			InsertStein(Player, sf::Vector2i(lAnchor+2, 2), curSpieler->naechsteSteine[2]);
			InsertStein(Player, sf::Vector2i(lAnchor+3, 3), curSpieler->naechsteSteine[3]);
			break;
		default:
			InsertStein(Player, sf::Vector2i(lAnchor+1, 1), curSpieler->naechsteSteine[0]);
			InsertStein(Player, sf::Vector2i(lAnchor+1, 0), curSpieler->naechsteSteine[1]);
			InsertStein(Player, sf::Vector2i(lAnchor+2, 1), curSpieler->naechsteSteine[2]);
			InsertStein(Player, sf::Vector2i(lAnchor+1, 2), curSpieler->naechsteSteine[3]);
			break;
	}
	
	curSpieler->Naechste();
}

bool Spielfeld::kannGerade(int8_t x, int8_t y, int8_t xl, int8_t xr) {
	return(y+2 < Feld[x].size() && xl >= 0 && xr < Feld.size() && Feld[x][y+2] == 0 && Feld[xl][y+1] == 0 && Feld[xr][y+1] == 0);
}
bool Spielfeld::kannLinks(int8_t x, int8_t y, int8_t xl, int8_t xr) {
	return(xl >= 0 && Feld[xl][y+1] == 0 && ((x-1 >= 0 && Feld[x-1][y] == 0) || (xr < Feld.size() && Feld[xr][y+1] == 0)));
}
bool Spielfeld::kannRechts(int8_t x, int8_t y, int8_t xl, int8_t xr) {
	return(xr < Feld.size() && Feld[xr][y+1] == 0 && ((x+1 < Feld.size() && Feld[x+1][y] == 0) || (xl >= 0 && Feld[xl][y+1] == 0)));
}
void Spielfeld::falle(int8_t x, int8_t y) {
	Feld[x][y]->bewegt = true;
	if(Feld[x][y]->Besitzer == LINKS) {
		SpielerL.bewegt = true;
	}
	else if(Feld[x][y]->Besitzer == RECHTS) {
		SpielerR.bewegt = true;
	}
}
void Spielfeld::fallGerade(int8_t x, int8_t y) {
	falle(x, y);
	Feld[x][y+2] = Feld[x][y];
	Feld[x][y] = 0;
}
void Spielfeld::fallLinks(int8_t x, int8_t y, int8_t xl) {
	falle(x, y);
	Feld[xl][y+1] = Feld[x][y];
	Feld[x][y] = 0;
}
void Spielfeld::fallRechts(int8_t x, int8_t y, int8_t xr) {
	falle(x, y);
	Feld[xr][y+1] = Feld[x][y];
	Feld[x][y] = 0;
}

void Spielfeld::Bewegen(int8_t x, int8_t y) {
	Direction Richtung = Feld[x][y]->Richtung;
	Feld[x][y]->Richtung = NICHTS;

	int8_t xl;
	int8_t xr;
	if(y%2 == 0) { // Reihe eingerueckt
		xl = x;
		xr = x+1;
	}
	else {
		xl = x-1;
		xr = x;
	}

	bool links = kannLinks(x, y, xl, xr);
	bool rechts = kannRechts(x, y, xl, xr);
	// Gerader Fall
	if(kannGerade(x, y, xl, xr)) {
		if(Richtung == LINKS && kannLinks(x, y, xl, xr))
			fallLinks(x, y, xl);
		else if(Richtung == RECHTS && kannRechts(x, y, xl, xr))
			fallRechts(x, y, xr);
		else
			fallGerade(x, y);
	}
	else {
		if(links && rechts) {
			if(Richtung == LINKS)
				fallLinks(x, y, xl);
			else if(Richtung == RECHTS)
				fallRechts(x, y, xr);
			else if(sf::Randomizer::Random(0, 1) == 0)
				fallLinks(x, y, xl);
			else
				fallRechts(x, y, xr);
		}
		else if(links)
			fallLinks(x, y, xl);
		else if(rechts)
			fallRechts(x, y, xr);
	}
}

void Spielfeld::Einzelnachbar(int8_t x, int8_t y, std::list<sf::Vector2<int8_t>>& nachbarn, uint8_t Farbe) {
	if(x < Feld.size() && x >= 0 && y < Feld[x].size() && y >= 0 && // Rahmen pruefen
			Feld[x][y] > (Stein*)(1) && Feld[x][y]->Besitzer == NICHTS && !Feld[x][y]->geprueft && Farbe == Feld[x][y]->Farbe) { // Eigenschaften pruefen
		nachbarn.push_back(sf::Vector2<int8_t>(x, y));
		Nachbarn(x, y, nachbarn);
	}
}

void Spielfeld::Nachbarn(int8_t x, int8_t y, std::list<sf::Vector2<int8_t>>& nachbarn) {
	Feld[x][y]->geprueft = true;
	int8_t xl;
	int8_t xr;
	if(y%2 == 0) { // Reihe eingerueckt
		xl = x;
		xr = x+1;
	}
	else {
		xl = x-1;
		xr = x;
	}

	Einzelnachbar(x+1, y, nachbarn, Feld[x][y]->Farbe); // Rechts
	Einzelnachbar(x-1, y, nachbarn, Feld[x][y]->Farbe); // Links
	Einzelnachbar(xr, y+1, nachbarn, Feld[x][y]->Farbe); // Rechts unten
	Einzelnachbar(xr, y-1, nachbarn, Feld[x][y]->Farbe); // Rechts oben
	Einzelnachbar(xl, y+1, nachbarn, Feld[x][y]->Farbe); // Links unten
	Einzelnachbar(xl, y-1, nachbarn, Feld[x][y]->Farbe); // Links oben
}

void Spielfeld::NextStep() {
	Protector.Lock();

	SpielerL.bewegt = false;
	SpielerR.bewegt = false;
	// Zuruecksetzen
	for(std::vector<std::vector<Stein*>>::iterator x = Feld.begin(); x != Feld.end(); ++x) {
		for(std::vector<Stein*>::iterator y = x->begin(); y != x->end(); ++y) {
			if(*y > (Stein*)(1)) {
				(*y)->bewegt = false; // Schutz gegen doppelte Bewegung
				(*y)->geprueft = false; // Schutz gegen mehrfache Gruppierung
			}
		}
	}
	bool b = sf::Randomizer::Random(0, 1) == 0; // Ungerechtigkeiten zwischen R und L vermeide
	if(b) goto LR;
RL:
	// Bewegen L-R
	for(uint8_t x = 0; x < Feld.size(); ++x) {
		for(int8_t y = Feld[x].size()-2; y >= 0; --y) { // Von unten nach oben, unterste Reihe weglassen, da unbeweglich.
			if(Feld[x][y] <= (Stein*)(1) || Feld[x][y]->bewegt) continue;
			Bewegen(x, y);
		}
	}
	if(b) goto END;
LR:
	// Bewegen R-L
	for(int8_t x = Feld.size()-1; x >= 0; --x) {
		for(int8_t y = Feld[x].size()-2; y >= 0; --y) { // Von unten nach oben, unterste Reihe weglassen, da unbeweglich.
			if(Feld[x][y] <= (Stein*)(1) || Feld[x][y]->bewegt) continue;
			Bewegen(x, y);
		}
	}
	if(b) goto RL;
END:

	
	for(uint8_t x = 0; x < Feld.size(); ++x) {
		for(uint8_t y = 0; y < Feld[x].size() ; ++y) {
			if(Feld[x][y] <= (Stein*)(1) || Feld[x][y]->geprueft) continue;
			std::list<sf::Vector2<int8_t>> Temp;
			Temp.push_back(sf::Vector2<int8_t>(x, y));
			Nachbarn(x, y, Temp);
			if(Temp.size() > 3) {
				for(std::list<sf::Vector2<int8_t>>::const_iterator i = Temp.begin(); i != Temp.end(); i++) {
					delete Feld[i->x][i->y];
					Feld[i->x][i->y] = 0;
				}
			}
		}
	}
	
	if(!SpielerL.bewegt) {
		neueSteine(LINKS);
	}
	if(!SpielerR.bewegt) {
		neueSteine(RECHTS);
	}

	Protector.Unlock();
}
Spielfeld::~Spielfeld() {
	Protector.Lock();
	for(std::vector<std::vector<Stein*>>::iterator x = Feld.begin(); x != Feld.end(); ++x) {
		for(std::vector<Stein*>::iterator y = x->begin(); y != x->end(); ++y) {
			if(*y != (Stein*)(1))
				delete *y;
		}
	}
	Protector.Unlock();
}