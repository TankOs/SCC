#include "Global.h"

sf::VideoMode Aufloesung(800, 600, 32);

void EventHandler<void>::operator+=(std::tr1::function<void(void)> Func) {
	Funcs.insert(Funcs.end(), Func);
}
void EventHandler<void>::operator()() const {
	for(std::list<std::tr1::function<void(void)> >::const_iterator i = Funcs.begin(); i != Funcs.end(); ++i) {
		(*i)();
	}
}
