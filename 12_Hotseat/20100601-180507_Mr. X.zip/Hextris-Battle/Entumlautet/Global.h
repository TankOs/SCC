#ifndef GLOBAL_H
#define GLOBAL_H

#include <cstdint>
#include <SFML/Window.hpp>
#ifdef _MSC_VER
	#include <functional>
#else
	#include <tr1/functional>
#endif
#include <list>

enum Direction {NICHTS, RECHTS, LINKS};

extern sf::VideoMode Aufloesung;

template<typename T>
class EventHandler {
	std::list<std::tr1::function<void(const T&)> > Funcs;
public:
	void operator+=(std::tr1::function<void(const T&)> Func) {
		Funcs.insert(Funcs.end(), Func);
	}
	void operator()(const T& Args) const {
		for(typename std::list<std::tr1::function<void(const T&)> >::const_iterator i = Funcs.begin(); i != Funcs.end(); ++i) {
			(*i)(Args);
		}
	}
};
template<>
class EventHandler<void> {
	std::list<std::tr1::function<void(void)> > Funcs;
public:
	void operator+=(std::tr1::function<void(void)> Func);
	void operator()() const;
};

#endif
