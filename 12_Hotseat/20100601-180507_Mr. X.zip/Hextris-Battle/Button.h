#ifndef BUTTON_H
#define BUTTON_H

#include "Global.h"
#include <SFML/Graphics.hpp>

class Button : public sf::Drawable {
private:
	sf::Shape Rand;
	sf::Text Text;
protected:
	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	EventHandler<void> OnClick;
	bool IsClicked(sf::Vector2i MousePosition) const;
	Button(const sf::String& sText, const sf::Vector2f& Position, const sf::Vector2f& Size, std::tr1::function<void(void)> onClick);
};

#endif
