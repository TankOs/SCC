#include "game.h"

Game::Game()
{
    windowSize = sf::Vector2i(800, 600);
    window.Create(sf::VideoMode(windowSize.x, windowSize.y), "", sf::Style::Close, sf::WindowSettings(24, 8, 0));
    window.ShowMouseCursor(false);
    window.SetFramerateLimit(60);

    /**/
    mouse_down = false;         //!
    drag = false;
    /**/

    loadImages();

    for(int i = 0;i < weapon_sprites.size();i++)
    {
        menu_weapons.push_back(weapon_sprites[i]);
        menu_weapons[i].SetPosition(690, 200+i*50);
    }

    weapon_price.push_back(10);
    weapon_price.push_back(30);
    weapon_price.push_back(80);

    for(int i = 0;i < weapon_price.size();i++)
    {
        std::ostringstream temp;
        temp<<weapon_price[i];
        weapon_price_string.push_back(sf::String(temp.str() ,font, 14));
        weapon_price_string[i].SetColor(sf::Color(255, 136, 200));
        weapon_price_string[i].SetPosition(740, menu_weapons[i].GetPosition().y+(menu_weapons[i].GetSize().y/2));
    }

    font.LoadFromFile("Vera.ttf");

    start_button.string = sf::String("Start", font, 18.f);
    start_button.string.SetPosition(start_button.sprite.GetPosition());
    close_button.string = sf::String("Beenden", font, 18.f);
    close_button.string.SetPosition(close_button.sprite.GetPosition());
    help_button.string = sf::String("Hilfe", font, 18.f);
    help_button.string.SetPosition(help_button.sprite.GetPosition());

    loadSounds();

    init();
}

float Game::pyth(float k1, float k2)
{
    return sqrt(pow(k1, 2)+pow(k2, 2));
}

bool Game::outOfScreen(sf::Vector2f &position)
{
    if(position.x < 0 || position.x > windowSize.x || position.y < 0 || position.y > windowSize.y)
        return true;
    else
        return false;
}

bool Game::collision(sf::Sprite &obj1, sf::Sprite &obj2)
{
    if(obj2.GetPosition().x < obj1.GetPosition().x+obj1.GetSize().x && obj2.GetPosition().x+obj2.GetSize().x > obj1.GetPosition().x)
    {
        if(obj2.GetPosition().y < obj1.GetPosition().y+obj1.GetSize().y && obj2.GetPosition().y+obj2.GetSize().y > obj1.GetPosition().y)
        {
            return true;
        }
    }
    return false;
}

void Game::addEnemy()
{
    enemies.push_back(Enemy());
    for(int i = 0;i < pfad.size();i++)
    {
        enemies[enemies.size()-1].path.push_back(sf::Vector2f(sf::Randomizer::Random(pfad[i].x-8, pfad[i].x+8), sf::Randomizer::Random(pfad[i].y-8, pfad[i].y+8)));
    }
    enemies[enemies.size()-1].position = enemies[enemies.size()-1].path[0];
}

void Game::loadImages()
{
    bg_image.LoadFromFile("images/background.jpg");
    bg_image.SetSmooth(false);
    background.SetImage(bg_image);

    cursor_image.LoadFromFile("images/cursor.png");
    cursor_image.SetSmooth(false);
    cursor.SetImage(cursor_image);

    button_image.LoadFromFile("images/button.png");
    button_image.SetSmooth(false);
    start_button.sprite.SetImage(button_image);
    start_button.sprite.SetPosition(690, 10);
    help_button.sprite.SetImage(button_image);
    help_button.sprite.SetPosition(690, windowSize.y-20-2*help_button.sprite.GetSize().y);
    close_button.sprite.SetImage(button_image);
    close_button.sprite.SetPosition(690, windowSize.y-10-close_button.sprite.GetSize().y);

    cursor_image.LoadFromFile("images/cursor.png");
    cursor.SetImage(cursor_image);

    tower_image.LoadFromFile("images/tower.png");
    tower_image.SetSmooth(false);
    tower.SetImage(tower_image);

    sf::Image temp_img;
    sf::Sprite temp_spr;

    temp_img.LoadFromFile("images/wp_1.png");
    weapon_images.push_back(temp_img);
    temp_img.LoadFromFile("images/wp_2.png");
    weapon_images.push_back(temp_img);
    temp_img.LoadFromFile("images/wp_3.png");
    weapon_images.push_back(temp_img);

    temp_spr.SetImage(weapon_images[0]);
    temp_spr.SetSubRect(sf::IntRect(0, 0, weapon_images[0].GetWidth(), weapon_images[0].GetHeight()));
    weapon_sprites.push_back(temp_spr);
    temp_spr.SetImage(weapon_images[1]);
    temp_spr.SetSubRect(sf::IntRect(0, 0, weapon_images[1].GetWidth(), weapon_images[1].GetHeight()));
    weapon_sprites.push_back(temp_spr);
    temp_spr.SetImage(weapon_images[2]);
    temp_spr.SetSubRect(sf::IntRect(0, 0, weapon_images[2].GetWidth(), weapon_images[2].GetHeight()));
    weapon_sprites.push_back(temp_spr);

    shot_img.LoadFromFile("images/shot.png");
    shot.SetImage(shot_img);

    enemy_img.LoadFromFile("images/enemy.png");
    enemy_spr.SetImage(enemy_img);

    volume_minus_img.LoadFromFile("images/sound_min.png");
    volume_plus_img.LoadFromFile("images/sound_max.png");

    volume_minus.SetImage(volume_minus_img);
    volume_minus.SetPosition(help_button.sprite.GetPosition()+sf::Vector2f(0, -20));
    volume_plus.SetImage(volume_plus_img);
    volume_plus.SetPosition(help_button.sprite.GetPosition()+sf::Vector2f(help_button.sprite.GetSize().x-15, -20));

    help_sprite_img.LoadFromFile("images/help_bg.jpg");
    help_sprite.SetImage(help_sprite_img);
}

void Game::loadSounds()
{
    error_soundbuffer.LoadFromFile("sound/error.ogg");
    error_sound.SetBuffer(error_soundbuffer);
    hover_sound_buffer.LoadFromFile("sound/hover.ogg");
    hover_sound.SetBuffer(hover_sound_buffer);
    musicbuffer.LoadFromFile("sound/music.ogg");
    music.SetBuffer(musicbuffer);
    music.SetLoop(true);
}

void Game::init()
{
    running = false;
    paused = false;
    helped = false;
    level = 1;
    loadMap();
    lives = 50;
    rand_enemy = 65;
    points = 20;
    std::ostringstream temp;
    temp<<points<<" Punkte\nLevel "<<level;
    info_string = sf::String(temp.str() ,font, 12);
    start_button.string.SetText("Start");
    music.Stop();
    enemies.clear();
    weapons.clear();
    info_string.SetColor(sf::Color(255, 136, 20));
    info_string.SetPosition(700, 430);
    volume = sf::String("", font, 17);
    volume.SetPosition(volume_minus.GetPosition()+sf::Vector2f(18, -2));
    std::ostringstream vol;
    vol<<(int)music.GetVolume()<<"%";
    volume.SetText(vol.str());
    help_string = sf::String("", font, 22);
    help_string.SetColor(sf::Color::White);
    help_string.SetPosition(10, 10);
    help_string.SetText("Erkl�rung...");
}

void Game::loadMap()
{
    pfad.clear();

    std::ostringstream temp;
    temp<<"maps/level"<<level<<".l";
    std::ifstream file(temp.str().c_str());
    int x,y;
    while(!file.eof())
    {
        file >> x;
        file >> y;

        pfad.push_back(sf::Vector2f(x, y));
    }
    tower.SetPosition(pfad[pfad.size()-1]-sf::Vector2f(tower.GetSize().x/2, tower.GetSize().y/2));
}

void Game::show_help(bool help)
{
    helped = help;

    if(helped)
        paused = true;
    else
        paused = false;
}

void Game::getEvents()
{
    while(window.GetEvent(event))
    {
        switch(event.Type)
        {
            case sf::Event::Closed:
            {
                window.Close();
                break;
            }
            case sf::Event::KeyPressed:
            {
                switch(event.Key.Code)
                {
                    case sf::Key::Escape:
                    {
                        window.Close();
                        break;
                    }
                    default:
                        break;
                }

                break;
            }
            default:
                break;
        }
    }
}

void Game::updateAll()
{
    cursor.SetPosition(window.GetInput().GetMouseX(), window.GetInput().GetMouseY());
    if(window.GetInput().IsMouseButtonDown(sf::Mouse::Left))
    {
        if(!mouse_down)
        {
            if(collision(cursor, start_button.sprite))
            {
                if(running)
                {
                    init();
                }
                else
                {
                    running = true;
                    music.Play();
                    start_button.string.SetText("Stop");
                }
            }
            else if(collision(cursor, close_button.sprite))
            {
                //close
                window.Close();
            }
            else if(collision(cursor, help_button.sprite))
            {
                //help
                if(!helped)
                    show_help(true);
                else
                    show_help(false);
            }
            else if(collision(cursor, volume_minus))
            {
                float temp;
                temp = music.GetVolume();
                 if(temp > 0)
                     temp-=10;
                 if(temp < 0)
                     temp = 0;
                 music.SetVolume(temp);
                 std::ostringstream vol;
                 vol<<(int)temp<<"%";
                 volume.SetText(vol.str());
            }
            else if(collision(cursor, volume_plus))
            {
                float temp;
                temp = music.GetVolume();
                 if(temp < 100)
                     temp+=10;
                 if(temp > 100)
                     temp = 100;
                 music.SetVolume(temp);
                 std::ostringstream vol;
                 vol<<(int)temp<<"%";
                 volume.SetText(vol.str());
            }

            if(running && !paused)
            {
                for(int i = 0;i < menu_weapons.size();i++)
                {
                    if(collision(cursor, menu_weapons[i]))
                    {
                        if(weapon_price[i] <= points)
                        {
                            drag = true;
                            drag_weapon = i+1;
                            cursor.SetImage(weapon_images[i]);
                        }
                        else
                        {
                            error_sound.Play();
                        }
                    }
                }
            }
        }
        mouse_down = true;
    }
    else
    {
        if(mouse_down)
        {
            if(running && !paused)
            {
                if(drag)
                {
                    cursor.SetImage(cursor_image);
                    if(!collision(cursor, tower) && cursor.GetPosition().x < 640)
                    {
                        points -= weapon_price[drag_weapon-1];
                        weapons.push_back(Weapon(drag_weapon, sf::Vector2f(window.GetInput().GetMouseX(), window.GetInput().GetMouseY())));
                    }
                    drag = false;
                }
            }
        }
        else
        {
            hover_sound.Play();
        }
        mouse_down = false;
    }

    if(running && !paused)
    {
        if(random.Random(0, (int)rand_enemy) == (int)(rand_enemy/2))
        {
            addEnemy();
        }
        for(int i = 0;i < enemies.size();i++)
        {
            enemies[i].move();
        }

        for(int i = 0;i < weapons.size();i++)
        {
            switch(weapons[i].type)
            {
                case 1:
                {
                    for(int e = 0;e < enemies.size();e++)
                    {
                        enemy_spr.SetPosition(enemies[e].position);
                        weapon_sprites[i].SetPosition(weapons[i].position);
                        if(collision(weapon_sprites[i], enemy_spr))
                        {
                            enemies.erase(enemies.begin()+e);
                            rand_enemy -= 0.5f;
                            hits++;
                            points+=2;
                            weapons[i].hits++;
                            if(weapons[i].hits >= 5)
                            {
                                weapons.erase(weapons.begin()+i);
                                break;
                            }
                        }
                    }
                    break;
                }
                case 2:
                {
                    for(int e = 0;e < enemies.size();e++)
                    {
                        if(!enemies[e].hit)
                        {
                            enemies[e].hit = true;
                            enemy_spr.SetPosition(enemies[e].position);
                            weapon_sprites[i].SetPosition(weapons[i].position);
                            if(collision(weapon_sprites[i], enemy_spr))
                            {
                                enemies[e].speed = 0.1f;
                                rand_enemy -= 0.5f;
                                hits++;
                                points+=2;
                                weapons[i].hits++;
                                if(weapons[i].hits >= 12)
                                {
                                    weapons.erase(weapons.begin()+i);
                                    break;
                                }
                            }
                        }
                    }
                    break;
                }
                case 3:
                {
                    for(int e = 0;e < enemies.size();e++)
                    {
                        enemy_spr.SetPosition(enemies[e].position);
                        if(!weapons[i].shot)
                        {
                            weapon_sprites[i].SetPosition(weapons[i].position);

                            float temp;
                            temp = pyth(weapons[i].position.x-enemies[e].position.x, weapons[i].position.y-enemies[e].position.y);
                            if(temp <= 130 && temp >= 37 && weapons[i].clk.GetElapsedTime() >= 1.6f)
                            {
                                weapons[i].shot_steps = pyth(weapons[i].position.x-enemies[e].position.x, weapons[i].position.y-enemies[e].position.y);
                                weapons[i].shot_step_vector = sf::Vector2f((enemies[e].position.x-weapons[i].position.x)/weapons[i].shot_steps, (enemies[e].position.y-weapons[i].position.y)/weapons[i].shot_steps);
                                weapons[i].shoot();
                            }
                        }
                        else
                        {
                            shot.SetPosition(weapons[i].shot_position);
                            if(collision(shot, enemy_spr))
                            {
                                rand_enemy -= 0.5f;
                                hits++;
                                points+=2;
                                weapons[i].hits++;
                                if(weapons[i].hits >= 2)
                                    weapons[i].shot = false;
                                weapons[i].clk.Reset();
                                enemies.erase(enemies.begin()+e);
                            }
                            else if(outOfScreen(weapons[i].shot_position))
                            {
                                weapons[i].shot = false;
                            }
                        }
                    }
                    break;
                }
                default:
                    break;
            }

            if(weapons[i].shot)
            {
                weapons[i].move_shot();
            }
        }

        for(int i = 0;i < enemies.size();i++)
        {
            enemy_spr.SetPosition(enemies[i].position);
            if(collision(tower, enemy_spr))
            {
                enemies.erase(enemies.begin()+i);
                lives--;
            }
        }
    }

    if(rand_enemy < 20)
        rand_enemy = 30;

    if(hits >= 10)
    {
        level++;
        hits = 0;
        points+=10;
        weapons.clear();
        enemies.clear();
        loadMap();
    }

    if(lives <= 0)
    {
        //lost_game();
    }

    std::ostringstream temp;
    temp<<points<<" Punkte\nLevel "<<level<<"\n"<<lives<<" Leben";
    info_string.SetText(temp.str());
}

void Game::drawWindow()
{
    window.Clear();

    window.Draw(background);

    window.Draw(start_button.sprite);
    window.Draw(close_button.sprite);
    window.Draw(help_button.sprite);
    //
    window.Draw(start_button.string);
    window.Draw(close_button.string);
    window.Draw(help_button.string);

    window.Draw(info_string);

    window.Draw(volume);
    window.Draw(volume_minus);
    window.Draw(volume_plus);

    for(int i = 0;i < menu_weapons.size();i++)
    {
        window.Draw(menu_weapons[i]);
    }
    for(int i = 0;i < weapon_price_string.size();i++)
    {
        window.Draw(weapon_price_string[i]);
    }

    if(running && !helped)
    {
        for(int i = 0;i < weapons.size();i++)
        {
            weapon_sprites[weapons[i].type-1].SetPosition(weapons[i].position);
            window.Draw(weapon_sprites[weapons[i].type-1]);

            if(weapons[i].type == 3)
            {
                if(weapons[i].shot)
                {
                    shot.SetPosition(weapons[i].shot_position);
                    window.Draw(shot);
                }
            }
        }

        for(int i = 0;i < enemies.size();i++)
        {
            enemy_spr.SetPosition(enemies[i].position);
            window.Draw(enemy_spr);
        }

        window.Draw(tower);
    }

    if(helped)
    {
        window.Draw(help_sprite);
        window.Draw(help_string);
    }


    window.Draw(cursor);

    window.Display();
}

void Game::loop()
{
    while(window.IsOpened())
    {
        getEvents();
        updateAll();
        drawWindow();
    }
}
