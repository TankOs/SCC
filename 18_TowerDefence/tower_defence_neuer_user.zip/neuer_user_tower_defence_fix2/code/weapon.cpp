#include "weapon.h"

Weapon::Weapon(int typ, sf::Vector2f pos)
{
    type = typ;
    position = pos;
    hits = 0;
    shot_speed = 2.0f;
    shot = false;
}

void Weapon::shoot()
{
    shot = true;
    shot_position = position;
}

void Weapon::move_shot()
{
    shot_position = sf::Vector2f(shot_position.x+shot_step_vector.x*shot_speed, shot_position.y+shot_step_vector.y*shot_speed);
}
