#ifndef WEAPON_H
#define WEAPON_H

#include "SFML/Graphics.hpp"

class Weapon
{
public:
    bool shot;
    int type,hits;
    float shot_steps,shot_speed;
    sf::Vector2f position,shot_step_vector,shot_position;
    sf::Clock clk;
    Weapon(int typ, sf::Vector2f pos);
    void shoot();
    void move_shot();
};

#endif // WEAPON_H
