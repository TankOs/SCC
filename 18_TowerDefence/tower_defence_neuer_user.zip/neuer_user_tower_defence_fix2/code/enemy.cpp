#include "enemy.h"

Enemy::Enemy()
{
    temp = 0;
    speed = 1;
    hit = false;
}

float Enemy::move()
{
    if(temp == (int)steps)
    {
        path.pop_front();
        steps = sqrt(pow(position.x-path[0].x, 2)+pow(position.y-path[0].y, 2));
        step_vector = sf::Vector2f((path[0].x-position.x)/steps, (path[0].y-position.y)/steps);
        temp = 0;
    }

    temp++;

    position.x += step_vector.x*speed;
    position.y += step_vector.y*speed;

    return steps;
}
