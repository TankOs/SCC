#ifndef BUTTON_H
#define BUTTON_H

#include <SFML/Graphics.hpp>

class Button
{
public:
    sf::Sprite sprite;
    sf::String string;
    Button();
    void init();
};

#endif // BUTTON_H
