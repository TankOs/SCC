#ifndef ENEMY_H
#define ENEMY_H

#include <SFML/Graphics.hpp>

class Enemy
{
public:
    bool hit;
    int temp;
    float steps;
    float speed;
    sf::Vector2f position;
    sf::Vector2f step_vector;
    std::deque<sf::Vector2f> path;
    Enemy();
    float move();
};

#endif // ENEMY_H
