#ifndef GAME_H
#define GAME_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <fstream>
#include <sstream>
#include <deque>
#include "collision.h"
#include "enemy.h"
#include "button.h"
#include "weapon.h"

class Game
{
public:
    Game();
    void loop();
private:
    bool mouse_down,drag,running,paused,helped;
    int level,points,drag_weapon,hits,lives;
    float rand_enemy;
    sf::Vector2i windowSize;
    sf::RenderWindow window;
    sf::Event event;
    sf::Font font;
    sf::String info_string,help_string,volume;
    sf::Image bg_image,cursor_image,button_image,button_hover_image,enemy_img,tower_image,shot_img,help_sprite_img,volume_plus_img,volume_minus_img;
    sf::Sprite background,cursor,enemy_spr,tower,shot,help_sprite,volume_plus,volume_minus;
    sf::SoundBuffer error_soundbuffer,hover_sound_buffer,musicbuffer;
    sf::Sound error_sound,music,hover_sound;
    sf::Randomizer random;
    std::vector<sf::Image> weapon_images;
    std::vector<sf::Sprite> weapon_sprites;
    std::vector<sf::Sprite> menu_weapons;
    std::vector<int> weapon_price;
    std::vector<sf::String> weapon_price_string;
    std::vector<sf::Vector2f> pfad;
    std::deque<Weapon> weapons;
    std::deque<Enemy> enemies;
    Button start_button,help_button,close_button;
    float pyth(float k1, float k2);
    bool outOfScreen(sf::Vector2f &position);
    bool collision(sf::Sprite &obj1, sf::Sprite &obj2);
    void addEnemy();
    void loadImages();
    void loadSounds();
    void init();
    void loadMap();
    void show_help(bool help);
    void getEvents();
    void updateAll();
    void drawWindow();
};

#endif // GAME_H
