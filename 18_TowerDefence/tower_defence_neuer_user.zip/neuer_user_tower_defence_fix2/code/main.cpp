#include "game.h"

Game game;

int main()
{
    game.loop();

    return 0;
}
