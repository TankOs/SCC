#ifndef MainGameState_h__
#define MainGameState_h__

#include "GameState.h"
#include "Level.h"
#include "EnemyManager.h"
#include "TowerManager.h"
#include "BulletManager.h"
#include "Button.h"
#include "DrawableContainer.h"
#include "FireTower.h"
#include "PoisonTower.h"
#include "MissileTower.h"
#include "LaserTower.h"
#include <sstream>
#include <sfml/Audio.hpp>

// Interface f�r einen Zustand/State
class MainGameState : public Gamestate
{
public:
	MainGameState(sf::RenderWindow& Window, StateManager& TheStateManager);

	// Virtueller Destruktor
	virtual ~MainGameState(); 

	// Initialisiert den Zustand
	// Parameter: Zeiger auf Daten die der Spielzustand �bergeben bekommen soll (z.B �bergibt der Hauptspielzustand dem Highscorezustand die Punktzahl die der Spieler erreicht hat)
	virtual void Init(void* InitializationData);

	// F�hrt den Spielzustand herunter
	virtual void Exit();

	// Aktualisiert den Spielzustand
	// Parameter : Vergangangene Zeit seit dem letztdem Frame
	virtual void Update();

	// Malt den Spielzustand
	virtual void Draw();

	virtual void HandleEvent(const sf::Event& Event);
	
private:
	void OpenSideBar();
	
	void AddTower(TowerTypes Type);
	void ShowTowerDescribtion(TowerTypes Type);
	void UpgradeTower();
	void PlayBuildSound();

	bool m_IsGamestateActive;
	Level m_Level;
	BulletManager m_BulletManager;
	EnemyManager m_EnemyManager;
	TowerManager m_TowerManager;
	BaseTower* m_TempTower;
	DrawableContainer m_SideBar;
	int m_SidebarScrollStatus;
	sf::Text* m_WaveText;
	sf::Text* m_TowerDescription;
	Button* m_UpgradeButton;
	int m_Money;
	sf::Text m_MoneyText;
	int m_Life;
	sf::Text m_LifeText;
	sf::Sound m_NotEnoughMoneySound;
	sf::Music m_Backgroundmusic;
};
#endif // MainGameState_h__