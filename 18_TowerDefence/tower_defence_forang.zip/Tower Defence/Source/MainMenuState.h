#ifndef MainMenuState_h__
#define MainMenuState_h__


#include "GameState.h"
#include "DrawableContainer.h"
#include "Button.h"
#include <sfml/Audio.hpp>


enum AnimationStates
{
	Nothing,
	In,
	Out,
};

// Interface f�r einen Zustand/State
class MainMenuState : public Gamestate
{
public:
	MainMenuState(sf::RenderWindow& Window, StateManager& TheStateManager);

	// Virtueller Destruktor
	virtual ~MainMenuState(); 

	// Initialisiert den Zustand
	// Parameter: Zeiger auf Daten die der Spielzustand �bergeben bekommen soll (z.B �bergibt der Hauptspielzustand dem Highscorezustand die Punktzahl die der Spieler erreicht hat)
	virtual void Init(void* InitializationData);

	// F�hrt den Spielzustand herunter
	virtual void Exit();

	// Aktualisiert den Spielzustand
	// Parameter : Vergangangene Zeit seit dem letztdem Frame
	virtual void Update();

	// Malt den Spielzustand
	virtual void Draw();

	virtual void HandleEvent(const sf::Event& Event);

private:
	void StartGame()
	{
		m_AnimationState = Out;
		m_NextContainer = NULL;
	}
	void GotoDifficultySelection()
	{
		m_AnimationState = Out;
		m_NextContainer = &m_DifficultyElements;
	}
	void GotoLevelSelection(const std::string& Difficulty)
	{
		m_Difficulty = Difficulty;
		m_AnimationState = Out;
		m_NextContainer = NULL;
	}
	DrawableContainer m_MainMenuElements;
	DrawableContainer m_DifficultyElements;
	DrawableContainer m_LevelSelectElements;
	AnimationStates m_AnimationState;
	DrawableContainer* m_CurrentContainer;
	DrawableContainer* m_NextContainer;
	sf::Shape m_Fade;
	float m_Alpha;
	std::string m_Difficulty;
	sf::Sprite m_Background;
	sf::Music m_BackgroundMusic;
};
#endif // MainMenuState_h__
