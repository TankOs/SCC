#ifndef Bullet_h__
#define Bullet_h__


#include <sfml/Graphics.hpp>
#include "EnemyManager.h"

class Bullet
{
public:
	Bullet(sf::RenderWindow& RenderWindow, EnemyManager& TheEnemyManager, const sf::Sprite& Sprite, int Level) 
		: m_Window(RenderWindow), m_EnemyManager(TheEnemyManager), m_Sprite(Sprite), m_Dead(false), m_Level(Level)
	{}

	virtual ~Bullet(){};

	void Update()
	{
		OnUpdate();
		Enemy* Temp = m_EnemyManager.TestCollision(m_Sprite);
		if (Temp)
		{
			OnHit(Temp);
			return;
		}
		if (m_Sprite.GetPosition().x < -50 || m_Sprite.GetPosition().x > 850 || m_Sprite.GetPosition().y < -50 || m_Sprite.GetPosition().y > 650)
		{
			m_Dead = true;
			return;
		}
	}

	virtual void Draw() = 0;

	bool IsDead()
	{
		return m_Dead;
	}

protected:
	virtual void OnUpdate() = 0;
	virtual void OnHit(Enemy* TheEnemy) = 0;

	sf::RenderWindow& m_Window;
	EnemyManager& m_EnemyManager;
	sf::Sprite m_Sprite;
	bool m_Dead;
	int m_Level;
};
#endif // Bullet_h__