#ifndef FireBullet_h__
#define FireBullet_h__


#include "Bullet.h"

class FireBullet : public Bullet
{
public:
	FireBullet(sf::RenderWindow& RenderWindow, EnemyManager& TheEnemyManager, sf::Vector2f Position, sf::Vector2f Direction, int Level);


	virtual void Draw();

private:
	virtual void OnUpdate();
	virtual void OnHit(Enemy* TheEnemy);
	sf::Vector2f m_Direction;

};
#endif // FireBullet_h__