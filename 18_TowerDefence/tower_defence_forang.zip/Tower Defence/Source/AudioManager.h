#ifndef AudioManager_h__
#define AudioManager_h__

#include "ResourceManager.h"
#include <sfml/Audio.hpp>
#include <list>
#include "Singleton.h"

class AudioManager : public ResourceManager<std::string, sf::SoundBuffer>, public TSingleton<AudioManager>
{
public:

	void PlaySound(const std::string& FileName, float Volume);
	void Update();
protected:
	virtual sf::SoundBuffer* Load(const std::string FileName);
private:
	std::list<sf::Sound> m_Souds;
};
#endif // AudioManager_h__
