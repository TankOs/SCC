#include "LaserTower.h"
#include "ImageManager.h"
#include "VectorHelperFunctions.h"
#include "AudioManager.h"

LaserTower::LaserTower( sf::RenderWindow& TheWindow, EnemyManager& TheEnemyManager, sf::Vector2f Position )
	: BaseTower(TheWindow, sf::Sprite(*ImageManager::GetInstance().GetResource("Data/Tower/LaserTower.png"),Position), 150),
	m_EnemyManager(TheEnemyManager),
	m_Direction(0,-1),
	m_LaserSound(*AudioManager::GetInstance().GetResource("Data/Sounds/Laser.wav"), true)
{
	m_Sprite.SetOrigin(m_Sprite.GetSize()/2.0f);
	SetMaxUpgradeLevel(3);
	m_DamagePerSecond = 10;
}

void LaserTower::Update()
{
	Enemy* Target = m_EnemyManager.GetFirstEnemyInRange(m_Sprite.GetPosition(), GetRange());
	if (Target != NULL)
	{
		if (m_LaserSound.GetStatus() == sf::Sound::Stopped)
		{
			m_LaserSound.Play();
		}
		sf::Vector2f EnemyPosition(Target->GetPosition());	
		sf::Vector2f m_Direction(EnemyPosition - m_Sprite.GetPosition());
		Normalize(m_Direction);
		float Angle = AngleBetweenD(sf::Vector2f(0,-1), m_Direction);
		if (EnemyPosition.x <= m_Sprite.GetPosition().x)
		{
			m_Sprite.SetRotation(Angle);
		}
		else
		{
			m_Sprite.SetRotation(360 - Angle);
		}

		m_Laser = sf::Shape::Line(m_Sprite.TransformToGlobal(sf::Vector2f(25, 0.0f)), Target->GetPosition(), m_DamagePerSecond/2.0f, sf::Color(255,0,0,150));

		Target->Damage(m_DamagePerSecond*m_Window.GetFrameTime());
	}
	else
	{
		m_LaserSound.Stop();
		m_Laser = sf::Shape::Line(sf::Vector2f(0.0f, 0.0f), sf::Vector2f(0.0f, 0.0f), 5, sf::Color(255,0,0,150));
	}
}

void LaserTower::Draw()
{
	m_Window.Draw(m_Sprite);
	m_Window.Draw(m_Laser);
}

sf::String LaserTower::GetDescription()
{
	std::stringstream StringStream;
	switch (m_UpgradeLevel)
	{
	case 0:
		StringStream << "Name: Laserturm\n"
			<< "Kosten: " << GetPrice() << "\n"
			<< "Beschreibung:\nSchie�t mit einem\nLaserstrahl";
		break;
	case 1:
		StringStream << "Laserturm Upgrade 1\n"
			<< "Kosten: " << GetPrice() << "\n"
			<< "Die Reichweite\n wird erh�ht";
		break;
	case 2:
		StringStream << "Laserturm Upgrade 2\n"
			<< "Kosten: " << GetPrice() << "\n"
			<< "Der Turm macht mehr\nSchaden pro Sekunde";
		break;
	case 3:
		StringStream << "Laserturm Upgrade 3\n"
			<< "Kosten: " << GetPrice() << "\n"
			<< "Die Reichweite wird\nnochmals erh�ht.";
		break;
	default:
		StringStream << "Laserturm Max\n"
			<< "Upgrade Kosten: -------\n"
			<< "Der Laserturm ist auf\nder h�chsten Stufe.";
	}

	return StringStream.str();
}

int LaserTower::GetPrice()
{
	switch(m_UpgradeLevel)
	{
	case 0:
		return 230;
		break;
	case 1:
		return 100;
		break;
	case 2:
		return 250;
		break;
	case 3:
		return 350;
		break;
	default:
		return 100;
		break;
	}
}

void LaserTower::OnUpgrade()
{
	switch(m_UpgradeLevel)
	{
	case 0:

		break;
	case 1:
		SetRange(190);
		break;
	case 2:
		m_DamagePerSecond = 17;
		break;
	case 3:
		SetRange(230);
		break;
	default:
		break;
	}
}
