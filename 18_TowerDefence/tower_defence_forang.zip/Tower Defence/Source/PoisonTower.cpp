#include "PoisonTower.h"
#include "ImageManager.h"
#include "VectorHelperFunctions.h"
#include "PoisonBullet.h"
#include <sstream>

PoisonTower::PoisonTower( sf::RenderWindow& TheWindow, BulletManager& TheBulletManager, EnemyManager& TheEnemyManager, sf::Vector2f Position )
	: BaseTower(TheWindow, sf::Sprite(*ImageManager::GetInstance().GetResource("Data/Tower/PoisonTower.png"),Position), 170),
	m_BulletManager(TheBulletManager),
	m_EnemyManager(TheEnemyManager),
	m_Direction(0,-1),
	m_Firerate(2)
{
	m_Sprite.SetOrigin(m_Sprite.GetSize()/2.0f);
	SetMaxUpgradeLevel(4);
}

void PoisonTower::Update()
{
	Enemy* Target;
	if (m_UpgradeLevel >= 5)
	{
		Target = m_EnemyManager.GetFirstEnemyUncontaminated(m_Sprite.GetPosition(), GetRange());
	}
	else
	{
		Target = m_EnemyManager.GetFirstEnemyInRange(m_Sprite.GetPosition(), GetRange());
	}
	if (Target != NULL)
	{
		sf::Vector2f EnemyPosition(Target->GetPosition());	
		sf::Vector2f m_Direction(EnemyPosition - m_Sprite.GetPosition());
		Normalize(m_Direction);
		float Angle = AngleBetweenD(sf::Vector2f(0,-1), m_Direction);
		if (EnemyPosition.x <= m_Sprite.GetPosition().x)
		{
			m_Sprite.SetRotation(Angle);
		}
		else
		{
			m_Sprite.SetRotation(360 - Angle);
		}
		if (m_ShootTimer.GetElapsedTime() > m_Firerate)
		{
			m_BulletManager.AddBullet(new PoisonBullet(m_Window, m_EnemyManager, m_Sprite.TransformToGlobal(sf::Vector2f(37.0f, 0.0f)), m_Direction, m_UpgradeLevel));
			m_ShootTimer.Reset();
		}
	}	
}

void PoisonTower::Draw()
{
	m_Window.Draw(m_Sprite);
}

sf::String PoisonTower::GetDescription()
{
	std::stringstream StringStream;
	switch (m_UpgradeLevel)
	{
	case 0:
		StringStream << "Name: Giftturm\n"
			<< "Kosten: " << GetPrice() << "\n"
			<< "Beschreibung:\nTurm der Gegner Ver-\ngiften kann.";
		break;
	case 1:
		StringStream << "Giftturm Upgrade 1\n"
			<< "Upgrade Kosten: " << GetPrice() << "\n"
			<< "Der Giftschaden\n wird erh�ht";
		break;
	case 2:
		StringStream << "Giftturm Upgrade 2\n"
			<< "Upgrade Kosten: " << GetPrice() << "\n"
			<< "Die Reichweite\n wird erh�ht";
		break;
	case 3:
		StringStream << "Giftturm Upgrade 3\n"
			<< "Upgrade Kosten: " << GetPrice() << "\n"
			<< "Der Turm\nschie�t schneller.";
		break;
	case 4:
		StringStream << "Giftturm Upgrade 4\n"
			<< "Upgrade Kosten: " << GetPrice() << "\n"
			<< "Der Turm schie�t\nnur auf Gegner die\nnoch nicht vergiftet sind.";
		break;
	default:
		StringStream << "Giftturm Max\n"
			<< "Upgrade Kosten: -------\n"
			<< "Der Giftturm ist auf\nder h�chsten Stufe";
		break;
	}

	return StringStream.str();
}

int PoisonTower::GetPrice()
{
	switch(m_UpgradeLevel)
	{
	case 0:
		return 205;
		break;
	case 1:
		return 200;
		break;
	case 2:
		return 250;
		break;
	case 3:
		return 250;
		break;
	case 4:
		return 450;
		break;
	default:
		return 100;
		break;
	}
}


void PoisonTower::OnUpgrade()
{
	switch(m_UpgradeLevel)
	{
	case 0:
		break;
	case 1:
		break;
	case 2:
		SetRange(220);
	case 3:
		m_Firerate = 1;
	case 4:
		m_Sprite.SetImage(*ImageManager::GetInstance().GetResource("Data/Tower/PoisonTower2.png"));
		break;
	default:
		break;
	}
}
