#ifndef MissileTower_h__
#define MissileTower_h__

#include "BaseTower.h"
#include "EnemyManager.h"
#include "BulletManager.h"
#include "Missile.h"

class MissileTower : public BaseTower
{
public:
	MissileTower(sf::RenderWindow& TheWindow, BulletManager& TheBulletManager, EnemyManager& TheEnemyManager, sf::Vector2f Position);

	virtual void Update();

	virtual void Draw();

	virtual sf::String GetDescription();
	virtual int GetPrice();
private:
	BulletManager& m_BulletManager;
	EnemyManager& m_EnemyManager;
	sf::Clock m_ShootTimer;
	sf::Vector2f m_Direction;
	std::size_t m_MaxNumWaitingMissiles;
	std::vector<Missile*> m_WaitingMissiles;

	virtual void OnUpgrade();
};
#endif // MissileTower_h__