#ifndef EnemyManager_h__
#define EnemyManager_h__

#include "Enemy.h"
#include <list>
#include <queue>
#include <xfunctional>

class EnemyManager
{
public:
	EnemyManager(sf::RenderWindow& Window, const Level& TheLevel)
		: m_Window(Window), m_Level(TheLevel),
		m_Difficult("Easy"), m_NextWaveIndex(1),
		m_GameOver(false), m_EarndeMoney(0), 
		m_EnemiesFinishedLevel(0)
	{

	}

	~EnemyManager();

	void Reset(float m_TimeUntilFirstWave);
	void SetDifficulty(const std::string& Difficult);
	const std::string& GetDifficulty();
	void StartNextWave();

	void Udpdate();

	void Draw();

	bool PlayerWinGame()
	{
		return m_GameOver;
	}

	int GetCurrentWave()
	{
		return m_NextWaveIndex-1;
	}


	Enemy* GetFirstEnemyInRange(sf::Vector2f Position, float Range);
	Enemy* EnemyManager::GetFirstEnemyUncontaminated( sf::Vector2f Position, float Range );

	Enemy* TestCollision(const sf::Sprite& Sprite);

	
	int GetEarnedMoney()
	{
		int Money = m_EarndeMoney;
		m_EarndeMoney = 0;
		return Money;
	}

	int GetEnemiesFinishedLevel()
	{
		int EnemiesFinishedLevel = m_EnemiesFinishedLevel;
		m_EnemiesFinishedLevel = 0;
		return EnemiesFinishedLevel;
	}

	bool GameOver()
	{
		return m_GameOver && m_Enemies.size() == NULL && m_NextEnemies.size() == 0;
	}

private:
	sf::RenderWindow& m_Window;
	const Level& m_Level;
	std::list<Enemy*> m_Enemies;
	std::priority_queue<std::pair<float,Enemy*>, std::vector<std::pair<float,Enemy*>>, std::greater<std::pair<float,Enemy*>>> m_NextEnemies;
	sf::Clock m_GlobalSpawnTimer;
	std::string m_Difficult;
	float m_TimeUntilNextWave;
	sf::Clock m_WaveTimer;
	int m_NextWaveIndex;
	bool m_GameOver;
	int m_EarndeMoney;
	int m_EnemiesFinishedLevel;
	bool m_FirstEnemy;
};
#endif // EnemyManager_h__
