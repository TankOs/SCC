#include "FireBullet.h"
#include "ImageManager.h"
#include "VectorHelperFunctions.h"

FireBullet::FireBullet( sf::RenderWindow& RenderWindow, EnemyManager& TheEnemyManager, sf::Vector2f Position, sf::Vector2f Direction, int Level )
	: Bullet(RenderWindow, TheEnemyManager, sf::Sprite(*ImageManager::GetInstance().GetResource("Data/Bullets/FireBullet.png"), Position), Level),
	m_Direction(Normalize(Direction))
{
	if (Level >= 4)
	{
		m_Sprite.Scale(1.5f,1.5f);
	}
	
	float Angle = AngleBetweenD(sf::Vector2f(0,-1), m_Direction);
	if (m_Direction.x < 0)
	{
		m_Sprite.SetRotation(Angle);
	}
	else
	{
		m_Sprite.SetRotation(360 - Angle);
	}

}

void FireBullet::OnUpdate()
{
	m_Sprite.Move(m_Direction * 700.0f * m_Window.GetFrameTime());
}

void FireBullet::Draw()
{
	m_Window.Draw(m_Sprite);
}

void FireBullet::OnHit( Enemy* TheEnemy )
{
	if(m_Level >= 4)
		TheEnemy->Damage(25);
	else if(m_Level >= 2)
		TheEnemy->Damage(10);
	else
		TheEnemy->Damage(5);
	m_Dead = true;
}
