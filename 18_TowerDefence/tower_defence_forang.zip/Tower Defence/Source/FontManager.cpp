#include "FontManager.h"

	sf::Font* FontManager::Load( const std::string FileName )
	{
		// Neues Schrift erstellen
		sf::Font* Font = new sf::Font();

		// Bild Laden
		if(!Font->LoadFromFile(FileName)) 
		{
			// Bild L�schen
			delete Font;
			Font = NULL;
			Logfile::GetInstance() << Warning << "Die Font " << FileName << " konnte nicht geladen werden. Eine Ausnahme wird ausgeworfen!" << NewLine;
			THROW_EXCEPTION("Das Bild " + FileName + " konnte nicht geladen werden")
		}
		Logfile::GetInstance() << Info << "Die Font " << FileName << " wurde erfolgreich geladen." << NewLine;
		return Font;
	}

// 	sf::Font* FontManager::Load( void* Data, size_t Size )
// 	{
// 		// Neues Schrift erstellen
// 		sf::Font* Font = new sf::Font();
// 
// 		// Bild Laden
// 		if(!Font->LoadFromMemory(Data, Size)) 
// 		{
// 			// Bild L�schen
// 			delete Font;
// 			Font = NULL;
// 			Logfile::GetInstance() << Warning << "Beim Laden einer Font aus dem Speicher ist ein Fehler aufgetreten" << NewLine;
// 			THROW_EXCEPTION("Font konnte nicht aus dem �bergebenen Speicherbereich erstellt werden!")
// 		}
// 		return Font;
// 	}

