#include "Missile.h"
#include "VectorHelperFunctions.h"
#include "ImageManager.h"

Missile::Missile( sf::RenderWindow& RenderWindow, EnemyManager& TheEnemyManager, Enemy* Target, sf::Vector2f Position, int Level)
	: Bullet(RenderWindow, TheEnemyManager, sf::Sprite(*ImageManager::GetInstance().GetResource("Data/Bullets/Missile.png"), Position), Level),
	m_Direction(Normalize(Target->GetPosition() - Position)),
	m_Target(Target),
	m_IsWaiting(false)
{
	m_Sprite.Scale(1.0f,1.0f);
	float Angle = AngleBetweenD(sf::Vector2f(0,-1), m_Direction);
	if (m_Direction.x < 0)
	{
		m_Sprite.SetRotation(Angle);
	}
	else
	{
		m_Sprite.SetRotation(360 - Angle);
	}

}

Missile::Missile( sf::RenderWindow& RenderWindow, EnemyManager& TheEnemyManager, sf::Vector2f Position , float Radius, int Level)
	: Bullet(RenderWindow, TheEnemyManager, sf::Sprite(*ImageManager::GetInstance().GetResource("Data/Bullets/Missile.png"), Position), Level),
	m_Direction(0,0),
	m_Target(NULL),
	m_IsWaiting(true),
	m_Radius(Radius),
	m_Rotation(0),
	m_StartPosition(Position)
{

}

void Missile::Draw()
{
	m_Window.Draw(m_Sprite);
}

void Missile::OnUpdate()
{
	if (m_IsWaiting)
	{
		m_Rotation += 270 * m_Window.GetFrameTime();

		sf::Vector2f NewPosition(m_Radius*cos(DEGTORAD(m_Rotation)), m_Radius*sin(DEGTORAD(m_Rotation)));
		NewPosition += m_StartPosition;


		m_Direction = Normalize(NewPosition - m_Sprite.GetPosition());
		float Angle = AngleBetweenD(sf::Vector2f(0,-1), m_Direction);
		if (m_Direction.x < 0)
		{
			m_Sprite.SetRotation(Angle);
		}
		else
		{
			m_Sprite.SetRotation(360 - Angle);
		}

		m_Sprite.SetPosition(NewPosition);
	}
	else
	{
		if (m_Target)
		{
			if (m_Target->ReadyToDestroy())
			{
				m_Target = NULL;
			}
			else
			{
				m_Direction = Normalize(m_Target->GetPosition() - m_Sprite.GetPosition());
				float Angle = AngleBetweenD(sf::Vector2f(0,-1), m_Direction);
				if (m_Direction.x < 0)
				{
					m_Sprite.SetRotation(Angle);
				}
				else
				{
					m_Sprite.SetRotation(360 - Angle);
				}
			}
		}
		m_Sprite.Move(m_Direction * 150.0f * m_Window.GetFrameTime());
	}
}

void Missile::OnHit( Enemy* TheEnemy )
{
	if (m_Level >= 3)
	{
		TheEnemy->Damage(30);
	}
	else
	{
		TheEnemy->Damage(20);
	}
	m_Dead = true;
}

void Missile::StopWaiting( Enemy* Target )
{
	m_Direction = Normalize(Target->GetPosition() - m_Sprite.GetPosition());
	m_Target = Target;
	m_IsWaiting = false;

	float Angle = AngleBetweenD(sf::Vector2f(0,-1), m_Direction);
	if (m_Direction.x < 0)
	{
		m_Sprite.SetRotation(Angle);
	}
	else
	{
		m_Sprite.SetRotation(360 - Angle);
	}
}
