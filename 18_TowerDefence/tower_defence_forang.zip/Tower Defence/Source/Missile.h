#ifndef Missile_h__
#define Missile_h__


#include "Bullet.h"

class Missile : public Bullet
{
public:
	Missile(sf::RenderWindow& RenderWindow, EnemyManager& TheEnemyManager, Enemy* Target, sf::Vector2f Position, int Level);

	Missile(sf::RenderWindow& RenderWindow, EnemyManager& TheEnemyManager, sf::Vector2f Position, float Radius, int Level);

	virtual void Draw();

	void StopWaiting(Enemy* Target);

private:
	virtual void OnUpdate();
	virtual void OnHit(Enemy* TheEnemy);
	sf::Vector2f m_Direction;
	Enemy* m_Target;
	bool m_IsWaiting;
	float m_Radius;
	float m_Rotation;
	sf::Vector2f m_StartPosition;
};
#endif // Missile_h__
