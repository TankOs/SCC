#include "FireTower.h"
#include "ImageManager.h"
#include "VectorHelperFunctions.h"
#include "FireBullet.h"
#include "AudioManager.h"

FireTower::FireTower( sf::RenderWindow& TheWindow, BulletManager& TheBulletManager, EnemyManager& TheEnemyManager, sf::Vector2f Position ) 
	: BaseTower(TheWindow, sf::Sprite(*ImageManager::GetInstance().GetResource("Data/Tower/FireTower.png"),Position), 180),
	m_BulletManager(TheBulletManager),
	m_EnemyManager(TheEnemyManager),
	m_Direction(0,-1),
	m_Firerate(1)
{
	m_Sprite.SetOrigin(m_Sprite.GetSize()/2.0f);
	SetMaxUpgradeLevel(3);
}

void FireTower::Update()
{
	Enemy* Target = m_EnemyManager.GetFirstEnemyInRange(m_Sprite.GetPosition(), GetRange());
	if (Target != NULL)
	{
		sf::Vector2f EnemyPosition(Target->GetPosition());	
		sf::Vector2f m_Direction(EnemyPosition - m_Sprite.GetPosition());
		Normalize(m_Direction);
		float Angle = AngleBetweenD(sf::Vector2f(0,-1), m_Direction);
		if (EnemyPosition.x <= m_Sprite.GetPosition().x)
		{
			m_Sprite.SetRotation(Angle);
		}
		else
		{
			m_Sprite.SetRotation(360 - Angle);
		}

		if (m_ShootTimer.GetElapsedTime() > m_Firerate)
		{
			m_BulletManager.AddBullet(new FireBullet(m_Window, m_EnemyManager, m_Sprite.TransformToGlobal(sf::Vector2f(23.5, 0.0f)), m_Direction, m_UpgradeLevel));
			AudioManager::GetInstance().PlaySound("Data/Sounds/Shoot.wav",30);
			m_ShootTimer.Reset();
		}
	}	
}

void FireTower::Draw()
{
	m_Window.Draw(m_Sprite);
}

sf::String FireTower::GetDescription()
{
	std::stringstream StringStream;
	switch (m_UpgradeLevel)
	{
	case 0:
		StringStream << "Name: Feuerturm\n"
			<< "Kosten: " << GetPrice() << "\n"
			<< "Beschreibung:\nTurm der mit Feuer-\ngeschossen schie�t.";
		break;
	case 1:
		StringStream << "Feuerturm Upgrade 1\n"
			<< "Upgrade Kosten: " << GetPrice() << "\n"
			<< "Die Reichweite\nund der Schaden\nwerden verbessert.";
		break;
	case 2:
		StringStream << "Feuerturm Upgrade 2\n"
			<< "Upgrade Kosten: " << GetPrice() << "\n"
			<< "Der Turm\nschie�t schneller.";
		break;
	case 3:
		StringStream << "Teufelsturm Upgrade 3\n"
			<< "Upgrade Kosten: " << GetPrice() << "\n"
			<< "Gr��ere Geschosse\n,die den Schaden\nsehr erh�hen.";
		break;
	default:
		StringStream << "Feuerturm Max\n"
			<< "Upgrade Kosten: -------\n"
			<< "Der Feuerturm ist auf\nder h�chsten Stufe.";
	}

	return StringStream.str();
}

int FireTower::GetPrice()
{
	switch(m_UpgradeLevel)
	{
	case 0:
		return m_Price;
		break;
	case 1:
		return 150;
		break;
	case 2:
		return 288;
		break;
	case 3:
		return 666;
		break;
	default:
		return 100;
		break;
	}
}

// Wird aufgerufen wenn der Turm geupgradet wird
void FireTower::OnUpgrade()
{
	switch(m_UpgradeLevel)
	{
	case 0:
		m_Price += 50;
		break;
	case 1:
		SetRange(230);
		break;
	case 2:
		m_Firerate = 0.5;
		break;
	case 3:
		break;
	default:
		break;
	}
}

float FireTower::m_Price = 100;
