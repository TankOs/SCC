#include "MainGameState.h"
#include <sstream>
#include "AudioManager.h"
#include "GameState.h"
#include "Game.h"


MainGameState::MainGameState( sf::RenderWindow& Window, StateManager& TheStateManager )
	: Gamestate(Window, TheStateManager), m_IsGamestateActive(false), m_Level(), m_BulletManager(), m_EnemyManager(m_Window, m_Level), m_TempTower(NULL), m_SidebarScrollStatus(-1), m_Money(0),
	m_MoneyText("5000"), m_Life(10), m_NotEnoughMoneySound(*AudioManager::GetInstance().GetResource("Data/Sounds/Speech/Kein Geld.wav"))
{
	m_MoneyText.SetPosition(10,10);
	m_MoneyText.SetColor(sf::Color(255,255,255,200));

	m_LifeText.SetPosition(10,550);
	m_LifeText.SetColor(sf::Color(255,255,255,200));

	m_SideBar.SetPosition(785,0);
	
	// Hintergrund der Sidebar
	sf::Shape* SidebarBackground = new sf::Shape;
	*SidebarBackground = sf::Shape::Rectangle(sf::FloatRect(15,0,200,800), sf::Color(50,50,50,100));
	m_SideBar.AddDrawable(SidebarBackground);

	// Button zum �ffnen der Sidebar
	Button* TempButton = new Button(m_Window.GetInput(), sf::Vector2f(0,0), 600, 15, "", "Data/Gui/SidebarButton.png", NULL, &m_SideBar); //, std::tr1::bind(&MainGameState::OpenSideBar, this), &m_SideBar);
	TempButton->SetButtonEnteredCallback(std::tr1::bind(&MainGameState::OpenSideBar, this));
	m_SideBar.AddDrawable(TempButton);

	m_WaveText = new sf::Text("Wave 1", sf::Font::GetDefaultFont(), 30);
	m_WaveText->SetPosition(50,5);
	m_SideBar.AddDrawable(m_WaveText);

	m_SideBar.AddDrawable(new Button(m_Window.GetInput(), sf::Vector2f(30,50), 40, 150, "NextWave", "", std::tr1::bind(&EnemyManager::StartNextWave, &m_EnemyManager), &m_SideBar));

	// Feuerturm
	TempButton = new Button(m_Window.GetInput(), sf::Vector2f(30,100), 50, 50, "", "Data/Gui/FireTowerButton.png", std::tr1::bind(&MainGameState::AddTower, this, Tower_Fire), &m_SideBar);
	TempButton->SetButtonEnteredCallback(std::tr1::bind(&MainGameState::ShowTowerDescribtion, this, Tower_Fire));
	m_SideBar.AddDrawable(TempButton);

	// Giftturm
	TempButton = new Button(m_Window.GetInput(), sf::Vector2f(100,100), 50, 50, "", "Data/Gui/PoisonTowerButton.png", std::tr1::bind(&MainGameState::AddTower, this, Tower_Poison), &m_SideBar);
	TempButton->SetButtonEnteredCallback(std::tr1::bind(&MainGameState::ShowTowerDescribtion, this, Tower_Poison));
	m_SideBar.AddDrawable(TempButton);

	// Lasertower
	TempButton = new Button(m_Window.GetInput(), sf::Vector2f(30,170), 50, 50, "", "Data/Gui/LaserTowerButton.png", std::tr1::bind(&MainGameState::AddTower, this, Tower_Laser), &m_SideBar);
	TempButton->SetButtonEnteredCallback(std::tr1::bind(&MainGameState::ShowTowerDescribtion, this, Tower_Laser));
	m_SideBar.AddDrawable(TempButton);

	// Missiletower
	TempButton = new Button(m_Window.GetInput(), sf::Vector2f(100,170), 50, 50, "", "Data/Gui/MissileTowerButton.png", std::tr1::bind(&MainGameState::AddTower, this, Tower_Missile), &m_SideBar);
	TempButton->SetButtonEnteredCallback(std::tr1::bind(&MainGameState::ShowTowerDescribtion, this, Tower_Missile));
	m_SideBar.AddDrawable(TempButton);

	m_TowerDescription = new sf::Text("", sf::Font::GetDefaultFont(), 15);
	m_TowerDescription->SetPosition(30,300);
	m_SideBar.AddDrawable(m_TowerDescription);

	m_UpgradeButton =  new Button(m_Window.GetInput(), sf::Vector2f(30,400), 40, 100, "Upgrade", "", std::tr1::bind(&MainGameState::UpgradeTower, this), &m_SideBar);
	m_UpgradeButton->SetVisible(false);
	m_SideBar.AddDrawable(m_UpgradeButton);
}

MainGameState::~MainGameState()
{

}

void MainGameState::Init( void* InitializationData )
{
	m_Level.LoadLevel("Level1");
	m_EnemyManager.Reset(30);
	const std::string* Difficulty = (std::string*)InitializationData;
	if (Difficulty == NULL)
	{
		Difficulty = &m_EnemyManager.GetDifficulty();
	}
	m_EnemyManager.SetDifficulty(*Difficulty);
	m_IsGamestateActive = true;
	m_Money = 250;
	AudioManager::GetInstance().PlaySound("Data/Sounds/Speech/Start.wav", 100);

	if ((*Difficulty) == "Hard")
	{
		m_Backgroundmusic.OpenFromFile("Data/Music/Ingame Theme 2.ogg");
		
	}
	else
	{
		m_Backgroundmusic.OpenFromFile("Data/Music/Ingame Theme 1.ogg");
	}
	m_Backgroundmusic.SetLoop(true);
	m_Backgroundmusic.Play();
	m_TempTower = NULL;
	
	m_SidebarScrollStatus = -1;
	m_Life = 10;
	
	FireTower::ResetPrice();
}

void MainGameState::Exit()
{
	m_IsGamestateActive = false;
	m_Backgroundmusic.Stop();
	m_NotEnoughMoneySound.Stop();
	m_BulletManager.Reset();
	m_TowerManager.Reset();
}

void MainGameState::Update()
{
	m_Money += m_EnemyManager.GetEarnedMoney();
	m_Life -= m_EnemyManager.GetEnemiesFinishedLevel();
	if (m_Life <= 0)
	{
		GameOverStruct Data;
		Data.PlayerWin = false;
		Data.Wave = m_EnemyManager.GetCurrentWave();
		m_StateManager.ChangeGamestate("GameOverState", &Data);
	}
	if (m_EnemyManager.GameOver())
	{
		GameOverStruct Data;
		Data.PlayerWin = true;
		Data.Wave = m_EnemyManager.GetCurrentWave();
		m_StateManager.ChangeGamestate("GameOverState", &Data);
	}
	if (m_SidebarScrollStatus > 0)
	{
		m_SideBar.Move(-600 * m_Window.GetFrameTime(),0);
		if (m_SideBar.GetPosition().x <= 600)
		{
			m_SidebarScrollStatus = 0;
			m_SideBar.SetPosition(600,0);
		}
	}
	else if (m_SidebarScrollStatus == 0)
	{
		if (m_Window.GetInput().GetMouseX() < 600 && !m_TowerManager.TowerSelected())
		{
			m_SidebarScrollStatus = -1;
		}
	}
	else if (m_SidebarScrollStatus < 0)
	{
		m_SideBar.Move(600 * m_Window.GetFrameTime(),0);
		if (m_SideBar.GetPosition().x >= 785)
		{
			m_SidebarScrollStatus = 0;
			m_SideBar.SetPosition(785,0);
		}
	}
	std::stringstream StringStream;
	StringStream << "Wave " << m_EnemyManager.GetCurrentWave();
	m_WaveText->SetString(StringStream.str());
	if (m_TempTower)
	{
		m_TempTower->SetPosition(sf::Vector2f(m_Window.GetInput().GetMouseX(), m_Window.GetInput().GetMouseY()));
	}
	m_BulletManager.Update();
	m_EnemyManager.Udpdate();
	m_TowerManager.Update();
	

	StringStream.str("");
	StringStream << "Geld : " << m_Money;
	m_MoneyText.SetString(StringStream.str());

	StringStream.str("");
	StringStream << "Leben : " << m_Life;
	m_LifeText.SetString(StringStream.str());
}

void MainGameState::Draw()
{
	m_Level.Draw(m_Window);
	m_BulletManager.Draw();
	m_EnemyManager.Draw();
	m_TowerManager.Draw();
	if (m_TempTower)
	{
		if (m_TempTower->GetSprite().GetPosition().x >= 785 || m_Level.TestCollisionWithPath(m_TempTower->GetSprite()) || m_TowerManager.TestCollision(m_TempTower->GetSprite()))
		{
			m_TempTower->DrawWithRange(sf::Color::Red);
		}
		else
		{
			m_TempTower->DrawWithRange(sf::Color::Green);
		}
		
	}
	m_Window.Draw(m_SideBar);
	m_Window.Draw(m_MoneyText);
	m_Window.Draw(m_LifeText);
}

void MainGameState::HandleEvent( const sf::Event& Event )
{
	if (Event.Type == sf::Event::MouseButtonPressed)
	{
		if (Event.MouseButton.X < m_SideBar.GetPosition().x)
		{
			if (Event.MouseButton.Button == sf::Mouse::Left)
			{
				if (Event.MouseButton.X < 785)
				{
					if (m_TowerManager.SelectTowerAtPosition(sf::Vector2f(Event.MouseButton.X, Event.MouseButton.Y)))
					{
						m_SidebarScrollStatus = 1;
						m_TowerDescription->SetString(m_TowerManager.GetSelectedTowerDescription());
						if (m_TowerManager.SlectedTowerHasMoreUpgrades())
						{
							m_UpgradeButton->SetVisible(true);
						}						
					}
					else
					{
						m_TowerDescription->SetString("");
						m_UpgradeButton->SetVisible(false);
					}
					if (m_TempTower)
					{
						if (!m_Level.TestCollisionWithPath(m_TempTower->GetSprite()) && !m_TowerManager.TestCollision(m_TempTower->GetSprite()))
						{
							m_Money -= m_TempTower->GetPrice();
							m_TowerManager.AddTower(std::tr1::shared_ptr<BaseTower>(m_TempTower));
							PlayBuildSound();
							m_TempTower = NULL;					
						}
					}
				}
			}
		}
	}
	else if (Event.Type == sf::Event::KeyPressed)
	{
		if (Event.Key.Code == sf::Key::Escape)
		{
			if (m_TempTower)
			{
				delete m_TempTower;
				m_TempTower = NULL;
			}
			else if (m_TowerManager.TowerSelected())
			{
				m_TowerManager.SelectNoTower();
				m_TowerDescription->SetString("");
				m_UpgradeButton->SetVisible(false);
			}
		}
	}	
}

void MainGameState::OpenSideBar()
{
	if (m_IsGamestateActive)
	{
		if (m_SideBar.GetPosition().x >= 785)
		{
			m_SidebarScrollStatus = 1;
		}
	}
}

void MainGameState::AddTower( TowerTypes Type )
{
	switch(Type)
	{
	case Tower_Fire:
		m_TempTower = new FireTower(m_Window, m_BulletManager, m_EnemyManager, sf::Vector2f(m_Window.GetInput().GetMouseX(), m_Window.GetInput().GetMouseY()));
		break;
	case Tower_Poison:
		m_TempTower = new PoisonTower(m_Window, m_BulletManager, m_EnemyManager, sf::Vector2f(m_Window.GetInput().GetMouseX(), m_Window.GetInput().GetMouseY()));
		break;
	case Tower_Laser:
		m_TempTower = new LaserTower(m_Window, m_EnemyManager, sf::Vector2f(m_Window.GetInput().GetMouseX(), m_Window.GetInput().GetMouseY()));
		break;
	case Tower_Missile:
		m_TempTower = new MissileTower(m_Window, m_BulletManager, m_EnemyManager, sf::Vector2f(m_Window.GetInput().GetMouseX(), m_Window.GetInput().GetMouseY()));
		break;
	}
	if (m_TempTower->GetPrice() > m_Money)
	{
		if (m_NotEnoughMoneySound.GetStatus() == sf::Sound::Stopped)
		{
			m_NotEnoughMoneySound.Play();
		}
		m_TempTower = NULL;
		return;
	}	
	m_SidebarScrollStatus = -1;
	m_TowerManager.SelectNoTower();
}

void MainGameState::ShowTowerDescribtion( TowerTypes Type )
{
	m_TowerManager.SelectNoTower();
	m_UpgradeButton->SetVisible(false);
	BaseTower* Temp = NULL;
	switch(Type)
	{
	case Tower_Fire:
		Temp = new FireTower(m_Window, m_BulletManager, m_EnemyManager, sf::Vector2f(m_Window.GetInput().GetMouseX(), m_Window.GetInput().GetMouseY()));
		break;
	case Tower_Poison:
		Temp = new PoisonTower(m_Window, m_BulletManager, m_EnemyManager, sf::Vector2f(m_Window.GetInput().GetMouseX(), m_Window.GetInput().GetMouseY()));
		break;
	case Tower_Laser:
		Temp = new LaserTower(m_Window, m_EnemyManager, sf::Vector2f(m_Window.GetInput().GetMouseX(), m_Window.GetInput().GetMouseY()));
		break;
	case Tower_Missile:
		Temp = new MissileTower(m_Window, m_BulletManager, m_EnemyManager, sf::Vector2f(m_Window.GetInput().GetMouseX(), m_Window.GetInput().GetMouseY()));
		break;
	default:
		return;
	}

	m_TowerDescription->SetString(Temp->GetDescription());
	delete Temp;
}

void MainGameState::UpgradeTower()
{
	m_TowerManager.UpgradeSelectedTower(m_Money);
	m_TowerDescription->SetString(m_TowerManager.GetSelectedTowerDescription());
	if (!m_TowerManager.SlectedTowerHasMoreUpgrades())
	{
		m_UpgradeButton->SetVisible(false);
	}
}

void MainGameState::PlayBuildSound()
{
	std::stringstream StringStream;
	StringStream << "Data/Sounds/Build" << sf::Randomizer::Random(1,4) << ".wav";
	AudioManager::GetInstance().PlaySound(StringStream.str(),80);
}
