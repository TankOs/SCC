#include "Button.h"
#include "ImageManager.h"
#include "Collision.h"
#include "AudioManager.h"

std::string Button::m_DefaultImageName = "Data/GUI/button.png";

Button::Button(const sf::Input& Input,  sf::Vector2f Position, float Height, float Width, const sf::String& Text /*= ""*/, const std::string& ImageName, std::tr1::function<void ()> OnButtonRelease, const DrawableContainer* MyContainer)
	: sf::Drawable(Position),
	m_Input(Input),
	m_Sprite(*ImageManager::GetInstance().GetResource(ImageName.empty() ? m_DefaultImageName : ImageName)),
	m_Text(Text, sf::Font::GetDefaultFont()),
	m_CursorInButton(false),
	m_IsPressed(false),
	m_ButtonReleasedCallback(OnButtonRelease),
	m_Container(MyContainer),
	m_Visible(true)
{
	// Die Schrift ist halb so gro� wie die Schaltfal�che
	m_Text.SetCharacterSize(static_cast<unsigned int>(Height / 2));

	if (Width < m_Text.GetRect().Width)
	{
		Width = m_Text.GetRect().Width;
		// Auf der y Achse ist der Text genau in der Mitte. Auf der x Achse ist der Text um ein Zehntel der Breite nach rechts verschoben
		m_Text.SetPosition(Width / 10, Height / 5 );
	}
	else
	{
		float Offset = (Width - m_Text.GetRect().Width) / 2;
		m_Text.SetPosition(Offset, Height / 5 );
	}
	// Je nach gr��e der Schaltfl�che wird skaliert
	m_Sprite.Resize(Width, Height);
	m_Sprite.SetColor(sf::Color(170, 170, 170, 255));
}

void Button::Render( sf::RenderTarget& Target, sf::Renderer& Renderer ) const
{
	if (m_Visible)
	{
		Target.Draw(m_Sprite);
		Target.Draw(m_Text);
	}
}

void Button::OnEvent( const sf::Event& Event )
{
	if (m_Visible)
	{
		if (m_CursorInButton)
		{
			if (Event.Type == sf::Event::MouseButtonPressed && Event.MouseButton.Button == sf::Mouse::Left)
			{
				m_Sprite.SetColor(sf::Color(110, 110, 110,255));
			}
			else if (Event.Type == sf::Event::MouseButtonReleased && Event.MouseButton.Button == sf::Mouse::Left)
			{
				sf::Vector2f MousePosition(static_cast<float>(Event.MouseButton.X), static_cast<float>(Event.MouseButton.Y));
				MousePosition = TransformToLocal(MousePosition);
				if (m_Container)
				{
					MousePosition = m_Container->TransformToLocal(MousePosition);
				}
				if(!Collision::PixelPerfectTest(m_Sprite, MousePosition))
				{
					m_CursorInButton = false;
					m_Sprite.SetColor(sf::Color(170, 170, 170, 255));
					return;
				}
				// Knopf wurde gedr�ckt
				if (!m_ButtonReleasedCallback._Empty())
				{
					m_ButtonReleasedCallback();
				}
				AudioManager::GetInstance().PlaySound("Data/Sounds/click.wav", 100);
				m_Sprite.SetColor(sf::Color(255, 255, 255, 255));
			}
			else if(Event.Type == sf::Event::MouseMoved)
			{
				sf::Vector2f MousePosition(static_cast<float>(Event.MouseMove.X), static_cast<float>(Event.MouseMove.Y));
				MousePosition = TransformToLocal(MousePosition);
				if (m_Container)
				{
					MousePosition = m_Container->TransformToLocal(MousePosition);
				}
				if(!Collision::PixelPerfectTest(m_Sprite, MousePosition))
				{
					m_CursorInButton = false;
					m_Sprite.SetColor(sf::Color(170, 170, 170, 255));
				}
			}
		}
		else
		{
			if(Event.Type == sf::Event::MouseMoved)
			{
				sf::Vector2f MousePosition(static_cast<float>(Event.MouseMove.X), static_cast<float>(Event.MouseMove.Y));
				MousePosition = TransformToLocal(MousePosition);
				if (m_Container)
				{
					MousePosition = m_Container->TransformToLocal(MousePosition);
				}
				if(Collision::PixelPerfectTest(m_Sprite, MousePosition))
				{
					m_CursorInButton = true;
					if (!m_ButtonEnteredCallback._Empty())
					{
						m_ButtonEnteredCallback();
					}				
					if (m_Input.IsMouseButtonDown(sf::Mouse::Left))
					{
						m_Sprite.SetColor(sf::Color(110, 110, 110,255));
					}
					else
					{
						m_Sprite.SetColor(sf::Color(255, 255, 255, 255));
					}
				}
			}
		}
	}
}

void Button::SetVisible( bool Visible )
{
	m_Visible = Visible;
	if (m_Visible)
	{
		sf::Vector2f MousePosition(static_cast<float>(m_Input.GetMouseX()), static_cast<float>(m_Input.GetMouseY()));
		MousePosition = TransformToLocal(MousePosition);
		if (m_Container)
		{
			MousePosition = m_Container->TransformToLocal(MousePosition);
		}
		if(Collision::PixelPerfectTest(m_Sprite, MousePosition))
		{
			m_CursorInButton = true;
		}
		else
		{
			m_CursorInButton = false;
		}
	}
}
