#include "PoisonBullet.h"
#include "ImageManager.h"
#include "VectorHelperFunctions.h"

PoisonBullet::PoisonBullet( sf::RenderWindow& RenderWindow, EnemyManager& TheEnemyManager, sf::Vector2f Position, sf::Vector2f Direction, int Level )
	: Bullet(RenderWindow, TheEnemyManager, sf::Sprite(*ImageManager::GetInstance().GetResource("Data/Bullets/PoisonBullet.png"), Position), Level),
	m_Direction(Normalize(Direction))
{
	m_Sprite.Scale(1.0f,1.0f);
	float Angle = AngleBetweenD(sf::Vector2f(0,-1), m_Direction);
	if (m_Direction.x < 0)
	{
		m_Sprite.SetRotation(Angle);
	}
	else
	{
		m_Sprite.SetRotation(360 - Angle);
	}
}

void PoisonBullet::OnUpdate()
{
	m_Sprite.Move(m_Direction * 600.0f * m_Window.GetFrameTime());
}

void PoisonBullet::Draw()
{
	m_Window.Draw(m_Sprite);
}

void PoisonBullet::OnHit( Enemy* TheEnemy )
{
	if (m_Level >= 2)
	{
		TheEnemy->Poison(5);
	}
	else
	{
		TheEnemy->Poison(3.2);
	}
	TheEnemy->Damage(4);
	
	m_Dead = true;
}
