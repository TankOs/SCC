#include "Level.h"
#include <fstream>
#include "ImageManager.h"

Level::Level()
{

}

void Level::LoadLevel( const std::string& LevelName )
{
	m_WayPoints.clear();
	std::fstream File(std::string("Data/Level/") + LevelName + std::string("/Path.txt"));
	while(File.good())
	{
		sf::Vector2f WayPoint;
		File >> WayPoint.x;
		File >> WayPoint.y;
		m_WayPoints.push_back(WayPoint);
	}
	File.close();

	m_Background.SetImage(*ImageManager::GetInstance().GetResource(std::string("Data/Level/") + LevelName + std::string("/Background.png")));
	m_Path.SetImage(*ImageManager::GetInstance().GetResource(std::string("Data/Level/") + LevelName + std::string("/Path.png")));
}

void Level::Draw( sf::RenderTarget& Target )
{
	Target.Draw(m_Background);
	Target.Draw(m_Path);
}

