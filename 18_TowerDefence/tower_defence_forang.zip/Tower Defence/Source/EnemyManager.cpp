#include "EnemyManager.h"
#include "Collision.h"
#include <sstream>
#include <fstream>
#include "AudioManager.h"


EnemyManager::~EnemyManager()
{
	Reset(0);
}

void EnemyManager::Reset( float m_TimeUntilFirstWave )
{
	for (auto It = m_Enemies.begin(); It != m_Enemies.end(); ++It)
	{
		delete *It;
	}
	m_Enemies.clear();
	while(!m_NextEnemies.empty())
	{
		delete m_NextEnemies.top().second;
		m_NextEnemies.pop();
	}
	m_TimeUntilNextWave = m_TimeUntilFirstWave;
	m_NextWaveIndex = 1;
	m_GameOver = false;
	m_WaveTimer.Reset();
	m_GlobalSpawnTimer.Reset();
	m_FirstEnemy = true;
}

void EnemyManager::SetDifficulty( const std::string& Difficult )
{
	m_Difficult = Difficult;
}

const std::string& EnemyManager::GetDifficulty()
{
	return m_Difficult;
}


void EnemyManager::StartNextWave()
{
	std::stringstream StringStream;
	StringStream << "Data/Waves/" << m_Difficult << "/Wave" << m_NextWaveIndex << ".txt";
	std::fstream File(StringStream.str());	
	if (!File)
	{
		m_GameOver = true;
		return;
	}
	
	if (m_NextWaveIndex == 1)
	{
		AudioManager::GetInstance().PlaySound("Data/Sounds/Speech/First_Wave.wav", 100);
	}
	else
	{
		std::stringstream StringStream;
		StringStream << "Data/Sounds/Speech/Next Wave_" << sf::Randomizer::Random(1,4) << ".wav";
		AudioManager::GetInstance().PlaySound(StringStream.str(), 100);
	}
	
	File >> m_TimeUntilNextWave;
	while(!File.eof())
	{
		float Time, Speed, Life;
		int Money;
		bool IsFlying;
		std::string ImageName;
		File >> Time >> ImageName >> Speed >> Life >> Money >> IsFlying;
		m_NextEnemies.push(std::make_pair(m_GlobalSpawnTimer.GetElapsedTime() + Time, new Enemy(m_Window, m_Level, ImageName, Speed, Life, Money, IsFlying)));
		if (ImageName == "EnemyBoss.png")
		{
			AudioManager::GetInstance().PlaySound("Data/Sounds/LaughDevilish.wav", 100);
		}
	}
	File.close();
	m_WaveTimer.Reset();
	++m_NextWaveIndex;
}

void EnemyManager::Udpdate()
{
	while(!m_NextEnemies.empty() && m_GlobalSpawnTimer.GetElapsedTime() >= m_NextEnemies.top().first)
	{
		m_Enemies.push_back(m_NextEnemies.top().second);
		m_NextEnemies.pop();
	}
	if (m_WaveTimer.GetElapsedTime() >= m_TimeUntilNextWave)
	{
		StartNextWave();
	}
	for (auto It = m_Enemies.begin(); It != m_Enemies.end(); ++It)
	{
		(*It)->Update();
		if ((*It)->ReadyToDestroy())
		{
			if ((*It)->FinishedLevel())
			{
				if (m_FirstEnemy)
				{
					AudioManager::GetInstance().PlaySound("Data/Sounds/Speech/Hit_1.wav", 100);
					m_FirstEnemy = false;
				}
				else
				{
					if (sf::Randomizer::Random(1,5) == 1)
					{
						AudioManager::GetInstance().PlaySound("Data/Sounds/Speech/Hit_2.wav", 100);
					}
				}
				++m_EnemiesFinishedLevel;
			}
			else
			{
				m_EarndeMoney += (*It)->GetMoney();
			}
			delete *It;
			It = m_Enemies.erase(It);
			if (It == m_Enemies.end())
			{
				break;
			}
		}
	}
}

void EnemyManager::Draw()
{
	std::for_each(m_Enemies.begin(), m_Enemies.end(), std::mem_fun(&Enemy::Draw));
}

Enemy* EnemyManager::GetFirstEnemyInRange( sf::Vector2f Position, float Range )
{
	for (auto It = m_Enemies.begin(); It != m_Enemies.end(); ++It)
	{
		if (Collision::CircleTest((*It)->GetPosition(), (*It)->GetBoundingCircleRadius(), Position, Range))
		{
			return *It;
		}
	}
	return NULL;
}

Enemy* EnemyManager::GetFirstEnemyUncontaminated( sf::Vector2f Position, float Range )
{
	for (auto It = m_Enemies.begin(); It != m_Enemies.end(); ++It)
	{
		if (Collision::CircleTest((*It)->GetPosition(), (*It)->GetBoundingCircleRadius(), Position, Range))
		{
			if (!(*It)->IsContaminated())
			{
				return *It;
			}			
		}
	}
	return GetFirstEnemyInRange(Position,Range);
}

Enemy* EnemyManager::TestCollision( const sf::Sprite& Sprite )
{
	for (auto It = m_Enemies.begin(); It != m_Enemies.end(); ++It)
	{
		if ((*It)->TestCollision(Sprite))
		{
			return (*It);
		}			
	}
	return NULL;
}