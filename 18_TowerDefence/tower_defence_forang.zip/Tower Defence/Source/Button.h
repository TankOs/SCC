#ifndef Button_h__
#define Button_h__


#include <sfml/Graphics.hpp>
#include "EventListener.h"
#include <functional>
#include "DrawableContainer.h"


class Button : public sf::Drawable, public WindowEventListener
{
public:
	Button(const sf::Input& Input, sf::Vector2f Position, float Height, float Width, const sf::String& Text = "", const std::string& ImageName = "", std::tr1::function<void ()> OnButtonRelease = NULL, const DrawableContainer* MyContainer = NULL);

	virtual void Render(sf::RenderTarget& Target, sf::Renderer& Renderer) const;

	virtual void OnEvent(const sf::Event& Event);

	void SetButtonReleasedCallback(std::tr1::function<void ()> OnButtonRelease)
	{
		m_ButtonReleasedCallback = OnButtonRelease;
	}

	void SetButtonEnteredCallback(std::tr1::function<void ()> OnButtonEntered)
	{
		m_ButtonEnteredCallback = OnButtonEntered;
	}
	void SetVisible(bool Visible);
private:
	static std::string m_DefaultImageName;
	const sf::Input& m_Input;
	sf::Sprite m_Sprite;
	sf::Text m_Text;
	bool m_CursorInButton;
	bool m_IsPressed;
	std::tr1::function<void ()> m_ButtonReleasedCallback;
	std::tr1::function<void ()> m_ButtonEnteredCallback;
	const DrawableContainer* m_Container;
	bool m_Visible;
};
#endif // Button_h__