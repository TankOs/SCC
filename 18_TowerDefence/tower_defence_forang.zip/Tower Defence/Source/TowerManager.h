#ifndef TowerManager_h__
#define TowerManager_h__

#include "BaseTower.h"
#include <list>
#include "Collision.h"
#include <sstream>
#include "AudioManager.h"

class TowerManager
{
public:
	TowerManager() : m_SelectedTower(NULL)
	{}
	
	void AddTower(std::tr1::shared_ptr<BaseTower> Tower);

	void Update();

	void Draw();

	void Reset()
	{
		m_Towers.clear();
		m_SelectedTower = NULL;
	}

	bool TestCollision(const sf::Sprite& Sprite);
	bool SelectTowerAtPosition(sf::Vector2f Point);

	bool TowerSelected()
	{
		return m_SelectedTower != NULL;
	}

	void UpgradeSelectedTower(int& Money)
	{
		if (Money >= m_SelectedTower->GetPrice())
		{
			Money -= m_SelectedTower->GetPrice();
			m_SelectedTower->Upgrade();
			std::stringstream StringStream;
			StringStream << "Data/Sounds/Speech/Upgrade_"<< sf::Randomizer::Random(1,2) << ".wav";
			AudioManager::GetInstance().PlaySound(StringStream.str(), 100);
		}
		else
		{
			AudioManager::GetInstance().PlaySound("Data/Sounds/Speech/Kein Geld.wav", 100);
		}
	}

	bool SlectedTowerHasMoreUpgrades()
	{
		return m_SelectedTower->GetUpgradeLevel() < m_SelectedTower->GetMaxUpgradeLevel()+1;
	}

	void SelectNoTower()
	{
		m_SelectedTower = NULL;
	}

	sf::String GetSelectedTowerDescription()
	{
		if (TowerSelected())
		{
			return m_SelectedTower->GetDescription();
		}		
		return std::string("");
	}
private:
	std::list<std::tr1::shared_ptr<BaseTower>> m_Towers;
	BaseTower* m_SelectedTower;
};
#endif // TowerManager_h__
