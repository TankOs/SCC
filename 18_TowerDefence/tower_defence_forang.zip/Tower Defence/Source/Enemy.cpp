#include "Enemy.h"
#include "VectorHelperFunctions.h"
#include "ImageManager.h"

Enemy::Enemy( sf::RenderWindow& Window, const Level& TheLevel, const std::string& ImageName, float MoveSpeed, int Life, int Money, bool IsFlying) 
	: m_Window(Window),
	m_Level(TheLevel),
	m_Sprite(*ImageManager::GetInstance().GetResource(std::string("Data/Enemies/") + ImageName), m_Level.GetWayPoint(0)),
	m_WayPointIndex(IsFlying ? TheLevel.GetNumWayPoints()-1 : 1),
	m_LastWayPoint(m_Level.GetWayPoint(0)),
	m_Direction(m_Level.GetWayPoint(m_WayPointIndex)-m_Sprite.GetPosition()),
	m_Distance(Length(m_Direction)),
	m_MoveSpeed(MoveSpeed),
	m_Life(Life),
	m_ReadyToDestroy(false),
	m_FinishedLevel(false),
	m_MaxLife(Life),
	m_LifeBar(sf::Shape::Rectangle(sf::FloatRect(0,0,50,5), sf::Color::Green)),
	m_PoisonDamage(0),
	m_Money(Money),
	m_IsFlying(IsFlying)
{
	m_Sprite.SetOrigin(m_Sprite.GetSize()/2.0f);
	Normalize(m_Direction);
	float Angle = AngleBetweenD(sf::Vector2f(0,-1), m_Direction);
	if (m_Direction.x < 0)
	{
		m_Sprite.SetRotation(Angle);
	}
	else
	{
		m_Sprite.SetRotation(360 - Angle);
	}
}

void Enemy::Update()
{
	if (!m_ReadyToDestroy)
	{
		Damage(m_PoisonDamage*m_Window.GetFrameTime());
		m_Sprite.Move(m_Direction*m_MoveSpeed*m_Window.GetFrameTime());
		if (Distance(m_Sprite.GetPosition(), m_LastWayPoint) >= m_Distance)
		{
			m_Sprite.SetPosition(m_Level.GetWayPoint(m_WayPointIndex));
			m_LastWayPoint = m_Sprite.GetPosition();
			++m_WayPointIndex;
			if (m_WayPointIndex == m_Level.GetNumWayPoints())
			{
				m_ReadyToDestroy = true;
				m_FinishedLevel = true;
				return;
			}
			m_Direction = m_Level.GetWayPoint(m_WayPointIndex) - m_Sprite.GetPosition();
			m_Distance = Length(m_Direction);
			Normalize(m_Direction);
			float Angle = AngleBetweenD(sf::Vector2f(0,-1), m_Direction);
			if (m_Direction.x < 0)
			{
				m_Sprite.SetRotation(Angle);
			}
			else
			{
				m_Sprite.SetRotation(360 - Angle);
			}
		}
		m_LifeBar.SetPosition(m_Sprite.GetPosition()-m_Sprite.GetSize() / 2.0f+sf::Vector2f(-1,-5));
	}
}

void Enemy::Draw()
{
	m_Window.Draw(m_Sprite);
	m_Window.Draw(m_LifeBar);
}
