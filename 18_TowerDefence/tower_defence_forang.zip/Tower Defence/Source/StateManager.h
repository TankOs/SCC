#ifndef StateManager_h__
#define StateManager_h__

#include <string>
#include <map>
#include <SFML/Window.hpp>

class Gamestate;

class StateManager
{
public:
	StateManager();

	~StateManager();

	// F�gt einen Gamestate hinzu
	// Parameter 1: Name des Gamestate
	// Parameter 2: Zeiger auf eine Instanz des Gamestates (mit new erzeugt)
	void AddGamestate(const std::string Name, Gamestate* Gamestate);

	// Wechselt den Gamestate
	void ChangeGamestate(const std::string Name, void* InitializationData = NULL);

	// Aktualisiert den aktuellen Gamestate
	void Update();

	// Malte den aktuellen Gamestate
	void Draw();

	void HandleEvent(const sf::Event& Event);

private:
	std::map<std::string, Gamestate*> m_States;
	Gamestate * m_CurrentGamestate;
};

#endif // StateManager_h__