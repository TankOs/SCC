#ifndef FireTower_h__
#define FireTower_h__

#include "BaseTower.h"
#include "EnemyManager.h"
#include "BulletManager.h"
#include <sstream>

class FireTower : public BaseTower
{
public:
	FireTower(sf::RenderWindow& TheWindow, BulletManager& TheBulletManager, EnemyManager& TheEnemyManager, sf::Vector2f Position);

	virtual void Update();

	virtual void Draw();

	virtual sf::String GetDescription();
	virtual int GetPrice();

	static void ResetPrice()
	{
		m_Price = 100;
	}
private:
	BulletManager& m_BulletManager;
	EnemyManager& m_EnemyManager;
	sf::Clock m_ShootTimer;
	sf::Vector2f m_Direction;
	float m_Firerate;
	static float m_Price;

	virtual void OnUpgrade();
};
#endif // FireTower_h__