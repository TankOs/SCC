#ifndef BaseTower_h__
#define BaseTower_h__


#include <sfml//Graphics.hpp>

enum TowerTypes
{
	Tower_Fire,
	Tower_Poison,
	Tower_Laser,
	Tower_Missile
};

class BaseTower
{
public:
	BaseTower(sf::RenderWindow& TheWindow, const sf::Sprite& TowerSprite, float Range) : m_Window(TheWindow), m_Sprite(TowerSprite), m_Range(Range), m_RangeShape(sf::Shape::Circle(sf::Vector2f(0,0), Range, sf::Color(255,255,255,100)))
	{
		m_UpgradeLevel = 0;
		m_MaxUpgradeLevel = 0;
		//m_RangeShape.SetOrigin(Range, Range);
	}

	virtual ~BaseTower(){}

	virtual void Update() = 0;

	virtual void Draw() = 0;

	void DrawWithRange(sf::Color Color)
	{
		m_RangeShape.SetColor(Color);
		m_RangeShape.SetPosition(m_Sprite.GetPosition());
		m_Window.Draw(m_RangeShape);
		Draw();
	}

	void SetPosition(sf::Vector2f Position)
	{
		m_Sprite.SetPosition(Position);
	}

	const sf::Sprite& GetSprite() const
	{
		return m_Sprite;
	}

	virtual sf::String GetDescription() = 0;
	virtual int GetPrice() = 0;

	void Upgrade()
	{
		OnUpgrade();
		++m_UpgradeLevel;
	}
	int GetUpgradeLevel()
	{
		return m_UpgradeLevel;
	}
	int GetMaxUpgradeLevel()
	{
		return m_MaxUpgradeLevel;
	}


protected:
	void SetMaxUpgradeLevel(int MaxUpgradeLevel)
	{
		m_MaxUpgradeLevel = MaxUpgradeLevel;
	}
	float GetRange(){return m_Range;}
	void SetRange(float Range)
	{
		m_Range = Range;
		m_RangeShape = sf::Shape::Circle(sf::Vector2f(0,0), Range, sf::Color(255,255,255,100));
	}

	sf::RenderWindow& m_Window;
	sf::Sprite m_Sprite;
	
	sf::Shape m_RangeShape;
	int m_MaxUpgradeLevel;
	int m_UpgradeLevel;

private:
	float m_Range;
	virtual void OnUpgrade(){}
};
#endif // BaseTower_h__