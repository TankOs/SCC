#ifndef ImageManager_h__
#define ImageManager_h__


#endif // ImageManager_h__
#include "ResourceManager.h"
#include <sfml/Graphics.hpp>
#include "Singleton.h"

class ImageManager : public ResourceManager<std::string, sf::Image>, public TSingleton<ImageManager>
{

protected:
	virtual sf::Image* Load(const std::string FileName);
};
