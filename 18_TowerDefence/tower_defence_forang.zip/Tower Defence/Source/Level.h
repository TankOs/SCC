#ifndef Level_h__
#define Level_h__


#include <string>
#include <vector>
#include <sfml/Graphics.hpp>
#include "Collision.h"

class Level
{
public:
	Level();

	void LoadLevel(const std::string& LevelName);

	void Draw(sf::RenderTarget& Target);

	sf::Vector2f GetWayPoint(std::size_t Index) const
	{
		return m_WayPoints[Index];
	}

	std::size_t GetNumWayPoints() const
	{
		return m_WayPoints.size();
	}

	bool TestCollisionWithPath(const sf::Sprite& Sprite)
	{
		return Collision::PixelPerfectTest(Sprite, m_Path);
	}
private:
	std::vector<sf::Vector2f> m_WayPoints;
	sf::Sprite m_Background;
	sf::Sprite m_Path;
};
#endif // Level_h__
