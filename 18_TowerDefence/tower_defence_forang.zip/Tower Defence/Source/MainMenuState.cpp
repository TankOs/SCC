#include "MainMenuState.h"
#include "Button.h"
#include "StateManager.h"
#include "ImageManager.h"

MainMenuState::MainMenuState( sf::RenderWindow& Window, StateManager& TheStateManager )
	: Gamestate(Window, TheStateManager), m_CurrentContainer(NULL),
	m_Background(*ImageManager::GetInstance().GetResource("Data/Level/Level1/Background.png"))
{
	m_MainMenuElements.AddDrawable(new Button(m_Window.GetInput(), sf::Vector2f(325,150), 50, 150, "Start", "", std::tr1::bind(&MainMenuState::GotoDifficultySelection, this), &m_MainMenuElements));
	m_MainMenuElements.AddDrawable(new Button(m_Window.GetInput(), sf::Vector2f(325,250), 50, 150, "Beenden", "", std::tr1::bind(&sf::Window::Close, &m_Window), &m_MainMenuElements));

	m_DifficultyElements.AddDrawable(new Button(m_Window.GetInput(), sf::Vector2f(350,150), 50, 100, "Leicht", "", std::tr1::bind(&MainMenuState::GotoLevelSelection, this, "Easy"), &m_DifficultyElements));
	m_DifficultyElements.AddDrawable(new Button(m_Window.GetInput(), sf::Vector2f(350,250), 50, 100, "Normal", "", std::tr1::bind(&MainMenuState::GotoLevelSelection, this, "Normal"), &m_DifficultyElements));
	m_DifficultyElements.AddDrawable(new Button(m_Window.GetInput(), sf::Vector2f(350,350), 50, 100, "Hart", "", std::tr1::bind(&MainMenuState::GotoLevelSelection, this, "Hard"), &m_DifficultyElements));

	m_Fade = sf::Shape::Rectangle(sf::FloatRect(0,0,800,600),sf::Color(255,255,255,255));

	m_BackgroundMusic.OpenFromFile("Data/Music/Menu Theme.ogg");
}

MainMenuState::~MainMenuState()
{}

void MainMenuState::Init( void* InitializationData )
{
	m_CurrentContainer = &m_MainMenuElements;
	m_NextContainer = m_CurrentContainer;
	m_MainMenuElements.SetPosition(0,0);
	m_DifficultyElements.SetPosition(0,-600);
	m_Fade.SetColor(sf::Color(0,0,0,0));
	m_Alpha = 0;
	m_BackgroundMusic.Play();
}

void MainMenuState::Exit()
{
	m_BackgroundMusic.Stop();
} 

void MainMenuState::Update()
{
	switch(m_AnimationState)
	{
	case Out:
		m_CurrentContainer->Move(0,-800*m_Window.GetFrameTime());
		m_Alpha += 270 * m_Window.GetFrameTime();
		if (m_CurrentContainer->GetPosition().y <= -600)
		{
			m_AnimationState = Nothing;
		}
		m_Fade.SetColor(sf::Color(0,0,0,m_Alpha));
		break;
	case In:
		m_CurrentContainer->Move(0,800*m_Window.GetFrameTime());
		m_Alpha -= 255 * m_Window.GetFrameTime();
		if (m_CurrentContainer->GetPosition().y >= 0)
		{
			m_AnimationState = Nothing;
		}
		m_Fade.SetColor(sf::Color(0,0,0,m_Alpha));
		break;
	}
	if (m_NextContainer != m_CurrentContainer && m_AnimationState == Nothing)
	{
		if (m_NextContainer == NULL)
		{
			m_StateManager.ChangeGamestate("MainGameState", &m_Difficulty);
		}
		else
		{
			m_CurrentContainer = m_NextContainer;
			m_AnimationState = In;
		}
		
	}
}

void MainMenuState::Draw()
{
	m_Window.Draw(m_Background);
	m_Window.Draw(m_MainMenuElements);
	m_Window.Draw(m_DifficultyElements);
	m_Window.Draw(m_LevelSelectElements);
	m_Window.Draw(m_Fade);
}

void MainMenuState::HandleEvent( const sf::Event& Event )
{

}
