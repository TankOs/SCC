#ifndef PoisonTower_h__
#define PoisonTower_h__



#include "BaseTower.h"
#include "BulletManager.h"
#include "EnemyManager.h"

class PoisonTower : public BaseTower
{
public:
	PoisonTower(sf::RenderWindow& TheWindow, BulletManager& TheBulletManager, EnemyManager& TheEnemyManager, sf::Vector2f Position);

	virtual void Update();

	virtual void Draw();

	virtual sf::String GetDescription() ;
	virtual int GetPrice();

private:
	virtual void OnUpgrade();

	BulletManager& m_BulletManager;
	EnemyManager& m_EnemyManager;
	sf::Clock m_ShootTimer;
	sf::Vector2f m_Direction;
	float m_Firerate;
};
#endif // PoisonTower_h__