#ifndef LaserTower_h__
#define LaserTower_h__

#include "BaseTower.h"
#include "EnemyManager.h"
#include "BulletManager.h"
#include <sstream>
#include <sfml/Audio.hpp>

class LaserTower : public BaseTower
{
public:
	LaserTower(sf::RenderWindow& TheWindow, EnemyManager& TheEnemyManager, sf::Vector2f Position);

	~LaserTower()
	{
		m_LaserSound.Stop();
	}

	virtual void Update();

	virtual void Draw();

	virtual sf::String GetDescription();
	virtual int GetPrice();
private:
	EnemyManager& m_EnemyManager;
	sf::Vector2f m_Direction;
	sf::Shape m_Laser;
	float m_DamagePerSecond;
	sf::Sound m_LaserSound;

	virtual void OnUpgrade();
};
#endif // LaserTower_h__
