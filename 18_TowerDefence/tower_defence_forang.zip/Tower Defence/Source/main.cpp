#include "Game.h"
#include <iostream>
#include "Exception.h"


int main()
{	
	try
	{
		Game TheGame;
		TheGame.Run();
	}
	catch (Exception& e)
	{
		std::cout << e.what() << std::endl;
		Logfile::GetInstance() << Error << e.GetFullDescription() << NewLine;
		std::cin.get();
	}
};