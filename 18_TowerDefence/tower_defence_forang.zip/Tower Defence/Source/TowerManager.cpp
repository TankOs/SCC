#include "TowerManager.h"
#include <functional>

using namespace std;
void TowerManager::AddTower( std::tr1::shared_ptr<BaseTower> Tower )
{
	Tower->Upgrade();
	m_Towers.push_back(Tower);
}

void TowerManager::Update()
{
	for (auto It = m_Towers.begin(); It != m_Towers.end(); ++It)
	{
		(*It)->Update();
	}
}

void TowerManager::Draw()
{
	for (auto It = m_Towers.begin(); It != m_Towers.end(); ++It)
	{
		if ((*It).get() == m_SelectedTower)
		{
			(*It)->DrawWithRange(sf::Color::Green);
		}
		else
		{
			(*It)->Draw();
		}		
	}
}

bool TowerManager::TestCollision( const sf::Sprite& Sprite )
{
	for (auto It = m_Towers.begin(); It != m_Towers.end(); ++It)
	{
		if (Collision::CircleTest(Sprite, (*It)->GetSprite()))
		{
			return true;
		}
	}
	return false;
}

bool TowerManager::SelectTowerAtPosition( sf::Vector2f Point )
{
	for (auto It = m_Towers.begin(); It != m_Towers.end(); ++It)
	{
		if (Collision::PixelPerfectTest((*It)->GetSprite(), Point))
		{
			m_SelectedTower = (*It).get();
			return true;
		}
	}
	m_SelectedTower = NULL;
	return false;
}
