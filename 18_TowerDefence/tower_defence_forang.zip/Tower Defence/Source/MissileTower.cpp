#include "MissileTower.h"
#include "ImageManager.h"
#include <sstream>
#include "VectorHelperFunctions.h"
#include "Missile.h"

MissileTower::MissileTower( sf::RenderWindow& TheWindow, BulletManager& TheBulletManager, EnemyManager& TheEnemyManager, sf::Vector2f Position )
	: BaseTower(TheWindow, sf::Sprite(*ImageManager::GetInstance().GetResource("Data/Tower/MissileTower.png"),Position), 210),
	m_BulletManager(TheBulletManager),
	m_EnemyManager(TheEnemyManager),
	m_Direction(0,-1),
	m_MaxNumWaitingMissiles(2)
{
	m_Sprite.SetOrigin(m_Sprite.GetSize()/2.0f);
	SetMaxUpgradeLevel(3);

}


void MissileTower::Update()
{
	Enemy* Target = m_EnemyManager.GetFirstEnemyInRange(m_Sprite.GetPosition(), GetRange());
	if (Target != NULL)
	{
		sf::Vector2f EnemyPosition(Target->GetPosition());	
		sf::Vector2f m_Direction(EnemyPosition - m_Sprite.GetPosition());
		Normalize(m_Direction);
		float Angle = AngleBetweenD(sf::Vector2f(0,-1), m_Direction);
		if (EnemyPosition.x <= m_Sprite.GetPosition().x)
		{
			m_Sprite.SetRotation(Angle);
		}
		else
		{
			m_Sprite.SetRotation(360 - Angle);
		}
		if (m_WaitingMissiles.size() > 0)
		{
			m_ShootTimer.Reset();
		}
		while(m_WaitingMissiles.size() > 0)
		{
			m_WaitingMissiles.back()->StopWaiting(Target);
			m_WaitingMissiles.erase(m_WaitingMissiles.end()-1);
		}
		if (m_ShootTimer.GetElapsedTime() > 1.5)
		{
			m_BulletManager.AddBullet(new Missile(m_Window, m_EnemyManager, Target, m_Sprite.TransformToGlobal(sf::Vector2f(29.0f, 0.0f)), m_UpgradeLevel));
			m_ShootTimer.Reset();
		}
	}
	else
	{
		if (m_ShootTimer.GetElapsedTime() > 2)
		{
			if (m_WaitingMissiles.size() < m_MaxNumWaitingMissiles)
			{
				m_WaitingMissiles.push_back(new Missile(m_Window, m_EnemyManager, m_Sprite.GetPosition(), 50, m_UpgradeLevel));
				m_BulletManager.AddBullet(m_WaitingMissiles.back());
				m_ShootTimer.Reset();
			}
		}
	}
}

void MissileTower::Draw()
{
	m_Window.Draw(m_Sprite);
}

sf::String MissileTower::GetDescription()
{
	std::stringstream StringStream;
	switch (m_UpgradeLevel)
	{
	case 0:
		StringStream << "Name: Arkaner Turm\n"
			<< "Kosten: " << GetPrice() << "\n"
			<< "Beschreibung:\nTurm der mit ziel-\nverfolgenden Geschossen\nschie�t.";
		break;
	case 1:
		StringStream << "Arkaner Turm Upgrade 1\n"
			<< "Upgrade Kosten: " << GetPrice() << "\n"
			<< "Die Reichweite\n wird verbessert.";
		break;
	case 2:
		StringStream << "Arkaner Turm Upgrade 2\n"
			<< "Upgrade Kosten: " << GetPrice() << "\n"
			<< "Der Turm macht\n mehr Schaden.";
		break;
	case 3:
		StringStream << "Arkaner Turm Upgrade 3\n"
			<< "Upgrade Kosten: " << GetPrice() << "\n"
			<< "Der Turm kann\n3 Geschosse um sich\nhaben.";
		break;
	default:
		StringStream << "Arkaner Turm Max\n"
			<< "Upgrade Kosten: -------\n"
			<< "Der arkane Turm ist auf\nder h�chsten Stufe.";
		break;
	}

	return StringStream.str();
}

int MissileTower::GetPrice()
{
	switch(m_UpgradeLevel)
	{
	case 0:
		return 500;
		break;
	case 1:
		return 300;
		break;
	case 2:
		return 300;
		break;
	case 3:
		return 700;
		break;
	default:
		return 100;
		break;
	}
}

void MissileTower::OnUpgrade()
{
	switch(m_UpgradeLevel)
	{
	case 0:
		break;
	case 1:
		SetRange(260);
		break;
	case 2:
		break;
	case 3:
		m_MaxNumWaitingMissiles = 3;
	default:
		break;
	}
}
