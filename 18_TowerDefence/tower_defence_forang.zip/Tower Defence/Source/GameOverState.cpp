#include "GameOverState.h"
#include "Game.h"
#include "AudioManager.h"

GameOverState::GameOverState( sf::RenderWindow& Window, StateManager& TheStateManager )
	: Gamestate(Window, TheStateManager),
	m_GotoMainMenuButton(Window.GetInput(), sf::Vector2f(75,500), 50, 300, "Zur�ck zum Hauptmen�"),
	m_TryAgainButton(Window.GetInput(), sf::Vector2f(425,500), 50, 300, "Noch einmal probieren")
{
	m_GameOverText.SetCharacterSize(80);
	m_GameOverText.SetColor(sf::Color::Red);
	m_GameOverText.SetPosition(50,150);

	m_GotoMainMenuButton.SetButtonReleasedCallback(std::tr1::bind(&StateManager::ChangeGamestate, &m_StateManager, "MainMenuState", (void*)NULL));
	m_GotoMainMenuButton.SetVisible(false);
	m_TryAgainButton.SetButtonReleasedCallback(std::tr1::bind(&StateManager::ChangeGamestate, &m_StateManager, "MainGameState", (void*)NULL));
	m_TryAgainButton.SetVisible(false);
}

GameOverState::~GameOverState()
{

}

void GameOverState::Init( void* InitializationData )
{
	GameOverStruct Data = *static_cast<GameOverStruct*>(InitializationData);
	if (Data.PlayerWin)
	{
		m_GameOverText.SetString("Du hast Gewonnen!");
		AudioManager::GetInstance().PlaySound("Data/Sounds/Speech/Gewonnen.wav", 100);
	}
	else 
	{
		m_GameOverText.SetString("Du hast Verloren!");
		AudioManager::GetInstance().PlaySound("Data/Sounds/Speech/Verloren.wav", 100);
	}
	m_GotoMainMenuButton.SetVisible(true);
	m_TryAgainButton.SetVisible(true);
}

void GameOverState::Exit()
{
	m_GotoMainMenuButton.SetVisible(false);
	m_TryAgainButton.SetVisible(false);
}

void GameOverState::Update()
{

}

void GameOverState::Draw()
{
	m_Window.Draw(m_GameOverText);
	m_Window.Draw(m_GotoMainMenuButton);
	m_Window.Draw(m_TryAgainButton);
}

void GameOverState::HandleEvent( const sf::Event& Event )
{

}
