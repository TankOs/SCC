#ifndef Enemy_h__
#define Enemy_h__


#include <sfml/Graphics.hpp>
#include "Level.h"
#include "Collision.h"

class Enemy
{
public:
	Enemy(sf::RenderWindow& Window, const Level& TheLevel, const std::string& ImageName, float MoveSpeed, int Life, int Money, bool IsFlying);

	void Update();

	void Draw();

	void Damage(float Damage)
	{
		if (Damage == 0)
		{
			return;
		}
		m_Life -= Damage;
		if (m_Life <= 0)
		{
			m_ReadyToDestroy = true;
		}
 		m_LifeBar = sf::Shape::Rectangle(sf::FloatRect(0,0,m_Life/m_MaxLife*50,5), sf::Color::Green);
		m_LifeBar.SetPosition(m_Sprite.GetPosition()-m_Sprite.GetSize() / 2.0f+sf::Vector2f(-1,-5));
	}

	bool ReadyToDestroy()
	{
		return m_ReadyToDestroy;
	}

	bool FinishedLevel()
	{
		return m_FinishedLevel;
	}

	sf::Vector2f GetPosition() const
	{
		return m_Sprite.GetPosition();
	}

	void Poison(float DamagePerSecond)
	{
		if (DamagePerSecond > m_PoisonDamage)
		{
			m_PoisonDamage = DamagePerSecond;
		}	
	}
	bool IsContaminated()
	{
		return m_PoisonDamage > 0;
	}
	float GetBoundingCircleRadius()
	{
		return (m_Sprite.GetSize().x + m_Sprite.GetSize().y) / 4;
	}

	bool TestCollision(const sf::Sprite& Sprite)
	{
		return Collision::PixelPerfectTest(Sprite, m_Sprite);
	}

	int GetMoney()
	{
		return m_Money;
	}
private:
	sf::RenderWindow& m_Window;
	const Level& m_Level;
	sf::Sprite m_Sprite;
	std::size_t m_WayPointIndex;
	sf::Vector2f m_LastWayPoint;
	sf::Vector2f m_Direction;
	float m_Distance;
	float m_MoveSpeed;
	float m_Life;
	bool m_ReadyToDestroy;
	bool m_FinishedLevel;
	float m_MaxLife;
	sf::Shape m_LifeBar;
	int m_PoisonDamage;
	int m_Money;
	bool m_IsFlying;
};
#endif // Enemy_h__