
#ifndef DrawableContainer_h__
#define DrawableContainer_h__

#include <sfml/Graphics.hpp>
#include <list>

class DrawableContainer : public sf::Drawable
{
public:
	DrawableContainer(){}
	~DrawableContainer()
	{
		for (auto It = m_Drawables.begin(); It != m_Drawables.end(); ++It)
		{
			delete *It;
		}
	}

	virtual void Render(sf::RenderTarget& target, sf::Renderer& renderer) const
	{
		for (auto It = m_Drawables.begin(); It != m_Drawables.end(); ++It)
		{
			target.Draw(**It);
		}
	}

	void AddDrawable(sf::Drawable* Drawable)
	{
		m_Drawables.push_back(Drawable);
	}

private:
	std::list<sf::Drawable*> m_Drawables;
};
#endif // DrawableContainer_h__