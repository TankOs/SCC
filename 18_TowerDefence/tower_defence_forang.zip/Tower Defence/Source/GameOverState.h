#ifndef GameOverState_h__
#define GameOverState_h__

#include "GameState.h"
#include "Button.h"

class GameOverState : public Gamestate
{
public:
	GameOverState(sf::RenderWindow& Window, StateManager& TheStateManager);

	// Virtueller Destruktor
	virtual ~GameOverState(); 

	// Initialisiert den Zustand
	// Parameter: Zeiger auf Daten die der Spielzustand �bergeben bekommen soll (z.B �bergibt der Hauptspielzustand dem Highscorezustand die Punktzahl die der Spieler erreicht hat)
	virtual void Init(void* InitializationData);

	// F�hrt den Spielzustand herunter
	virtual void Exit();

	// Aktualisiert den Spielzustand
	// Parameter : Vergangangene Zeit seit dem letztdem Frame
	virtual void Update();

	// Malt den Spielzustand
	virtual void Draw();

	virtual void HandleEvent(const sf::Event& Event);

private:
	sf::Text m_GameOverText;
	Button m_GotoMainMenuButton;
	Button m_TryAgainButton;
};
#endif // GameOverState_h__
