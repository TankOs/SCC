#ifndef BulletManager_h__
#define BulletManager_h__


#include "Bullet.h"
#include <list>

class BulletManager
{
public:
	BulletManager()
	{}

	~BulletManager();

	void AddBullet(Bullet* TheBullet);

	void Update();

	void Draw();

	void Reset();

private:
	
	std::list<Bullet*> m_Bullets;
};
#endif // BulletManager_h__