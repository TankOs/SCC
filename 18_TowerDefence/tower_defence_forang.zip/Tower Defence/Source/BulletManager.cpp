#include "BulletManager.h"

BulletManager::~BulletManager()
{
	Reset();
}

void BulletManager::AddBullet( Bullet* TheBullet )
{
	m_Bullets.push_back(TheBullet);
}

void BulletManager::Update()
{
	for (auto It = m_Bullets.begin(); It != m_Bullets.end(); ++It)
	{
		(*It)->Update();
		if((*It)->IsDead())
		{
			delete *It;
			It = m_Bullets.erase(It);
			if (It == m_Bullets.end())
			{
				break;
			}
		}
	}	
}

void BulletManager::Draw()
{
	std::for_each(m_Bullets.begin(), m_Bullets.end(), std::mem_fun(&Bullet::Draw));
}

void BulletManager::Reset()
{
	for (auto It = m_Bullets.begin(); It != m_Bullets.end(); ++It)
	{
		delete *It;
	}
}
