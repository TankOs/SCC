#ifndef PoisonBullet_h__
#define PoisonBullet_h__


#include "Bullet.h"

class PoisonBullet : public Bullet
{
public:
	PoisonBullet(sf::RenderWindow& RenderWindow, EnemyManager& TheEnemyManager, sf::Vector2f Position, sf::Vector2f Direction, int Level);


	virtual void Draw();

private:
	virtual void OnUpdate();
	virtual void OnHit(Enemy* TheEnemy);
	sf::Vector2f m_Direction;

};
#endif // PoisonBullet_h__