#pragma once

#include "ResourceManager.h"
#include <sfml/Graphics.hpp>
#include "Singleton.h"

class FontManager : public ResourceManager<std::string, sf::Font>, public TSingleton<FontManager>
{
	friend class ManagerSingletoon;

protected:
	virtual sf::Font* Load(const std::string FileName);
//	virtual sf::Font* Load(void* Data, size_t Size);

private:
	FontManager(){};
};

