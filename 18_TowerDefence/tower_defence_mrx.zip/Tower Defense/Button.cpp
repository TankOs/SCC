#include "Button.h"


Button::Button(const sf::FloatRect& Rect, const std::string& text)
	: Text(text), Size(Rect.Width,Rect.Height), Border(sf::Shape::Rectangle(sf::FloatRect(0,0,Rect.Width,Rect.Height), sf::Color(0,0,0,0), 5, sf::Color::White))
{
	SetPosition(Rect.Left, Rect.Top);
	Text.SetPosition(Rect.Width/2-Text.GetRect().Width/2, Rect.Height/2-Text.GetRect().Height/2);
	Text.SetColor(sf::Color::White);

	OnRender += std::bind(&Button::Render, this, std::placeholders::_1);
}

void Button::Render(sf::RenderTarget& Target) const {
	Target.Draw(Text);
	Target.Draw(Border);
}

void Button::SetText(const std::string& text) {
	Text.SetString(text);
	Text.SetPosition(GetRect().Width/2-Text.GetRect().Width/2, GetRect().Height/2-Text.GetRect().Height/2);
}

sf::FloatRect Button::GetRect() const {
	return(sf::FloatRect(GetPosition(), Size));
}
