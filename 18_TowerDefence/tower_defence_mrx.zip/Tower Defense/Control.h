#ifndef CONTROL_H
#define CONTROL_H

#include "Global.h"
#include "EventHandler.h"
#include "ControlContainer.h"


class Control : public sf::Drawable {
	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	EventHandler<sf::RenderTarget&, void> OnRender;
	EventHandler<const sf::Vector2i&, sf::Mouse::Button> OnMouseButtonDown;
	EventHandler<const sf::Vector2i&, sf::Mouse::Button> OnMouseButtonUp;
	EventHandler<const sf::Vector2i&, void> OnMouseMove;

	virtual sf::FloatRect GetRect() const = 0;
};


#endif
