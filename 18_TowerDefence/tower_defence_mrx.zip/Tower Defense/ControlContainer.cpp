#include "ControlContainer.h"
#include "Control.h"


void ControlContainer::DrawChilds(sf::RenderTarget& Target) const {
	for(auto i = Childs.cbegin(); i != Childs.cend(); ++i) {
		Target.Draw(**i);
	}
}

void ControlContainer::operator+=(Control* c) {
	Childs.push_back(c);
}

void ControlContainer::operator+=(Control& c) {
	Childs.push_back(&c);
}

void ControlContainer::ClearChilds() {
	Childs.clear();
}
