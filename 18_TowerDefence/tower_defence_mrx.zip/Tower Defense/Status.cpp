#include "Status.h"


static STATUS Status = MEN�;

STATUS GetStatus() {
	return(Status);
}

void SetStatus(STATUS s) {
	Status = s;
}