#ifndef STATUS_H
#define STATUS_H

#include "Global.h"


enum STATUS {
	MEN�, BAUPAUSE, LEVEL, VERLOREN, DURCHGESPIELT, ENDE
};

STATUS GetStatus();
void SetStatus(STATUS s);


#endif
