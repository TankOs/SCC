#ifndef CONTROLCONTAINER_H
#define CONTROLCONTAINER_H

#include "Global.h"
#include "EventHandler.h"
#include <list>


class Control;
class ControlContainer {
protected:
	std::list<Control*> Childs;

	void DrawChilds(sf::RenderTarget& Target) const;
public:
	void operator+=(Control* c);
	void operator+=(Control& c);
	void ClearChilds();
};


#endif
