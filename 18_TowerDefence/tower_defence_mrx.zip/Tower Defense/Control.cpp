#include "Control.h"


void Control::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	OnRender(Target);
}
