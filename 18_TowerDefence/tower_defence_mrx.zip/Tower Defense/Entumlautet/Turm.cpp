#include "Turm.h"
#include "Ressourcen.h"
#include <cmath>
#include "SoundPlayer.h"

Turm Turm::Tuerme[4] = {Turm(RM().Get<sf::Image>("Grafik/t1.png"), RM().Get<sf::Image>("Grafik/t1g.png"), RM().Get<sf::SoundBuffer>("Sound/t1.ogg"), sf::Vector2f(15.f,15.f), 40, 80, 2.15f, 200, 3, 10),		// Kanone
					   Turm(RM().Get<sf::Image>("Grafik/t2.png"), RM().Get<sf::Image>("Grafik/t2g.png"), RM().Get<sf::SoundBuffer>("Sound/t2.ogg"), sf::Vector2f(12.f,12.f), 40, 60, 1.1f, 100, 1, 0, 0.75f),	// Kleber
                       Turm(RM().Get<sf::Image>("Grafik/t3.png"), RM().Get<sf::Image>("Grafik/t3g.png"), RM().Get<sf::SoundBuffer>("Sound/t3.ogg"), sf::Vector2f(13.f,13.f), 100, 90, 0.15f, 300, 1, 1),		// Maschinengewehr
                       Turm(RM().Get<sf::Image>("Grafik/t4.png"), RM().Get<sf::Image>("Grafik/t4g.png"), RM().Get<sf::SoundBuffer>("Sound/t4.ogg"), sf::Vector2f(12.f,12.f), 200, 150, 1.3f, 500, 10, 5)};		// Laser


Turm::Turm(const sf::Image& Img, const sf::Image& gImg, const sf::SoundBuffer& schuss, const sf::Vector2f& Mitte, uint16_t preis, uint16_t reichweite, float ladezeit, uint16_t schussgeschw, uint16_t durchschlag, uint16_t schaden, float verlangsamung)
	: Sp(Img), GImg(gImg), Schuss(schuss), Preis(preis), Reichweite(reichweite), Ladezeit(ladezeit), Schussgeschw(schussgeschw), Durchschlag(durchschlag), Schaden(schaden), Verlangsamung(verlangsamung),
	  Kreis(new sf::Shape(sf::Shape::Circle(0.f,0.f,reichweite, sf::Color(0,0,0,0), 2.f, sf::Color(200,200,200,200))))
{
	Sp.SetOrigin(Mitte);
}

Turm::Turm(uint16_t Typ)
	: sf::Drawable(Tuerme[Typ].GetPosition()), Sp(Tuerme[Typ].Sp), GImg(Tuerme[Typ].GImg), Schuss(Tuerme[Typ].Schuss), Reichweite(Tuerme[Typ].Reichweite), Durchschlag(Tuerme[Typ].Durchschlag),
	Schaden(Tuerme[Typ].Schaden), Verlangsamung(Tuerme[Typ].Verlangsamung), Preis(Tuerme[Typ].Preis), Kreis(nullptr), Ladezeit(Tuerme[Typ].Ladezeit), Schussgeschw(Tuerme[Typ].Schussgeschw)
{
}

Geschoss* Turm::Schiesse(sf::Vector2i Ziel) {
	if(CircleCollision(static_cast<sf::Vector2f>(Ziel), Reichweite, GetPosition(), 0.f) && Ladeuhr.GetElapsedTime() > Ladezeit) {
		Ladeuhr.Reset();
		float bWinkel = atan2(Ziel.y - GetPosition().y, Ziel.x-GetPosition().x);
		SetRotation(90.f+radtodeg(bWinkel));
		sPlayer += Schuss;
		return(new Geschoss(GImg, GetPosition(), bWinkel, Schussgeschw, Schaden, Durchschlag, Verlangsamung));
	}
	return(nullptr);
}

void Turm::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(Sp);
	if(Kreis != nullptr)
		Target.Draw(*Kreis);
}
