#ifndef EVENTHANDLER_H
#define EVENTHANDLER_H

#include "Global.h"
#include <functional>
#include <list>


template<typename T, typename U>
class EventHandler {
	std::list<std::function<void(T, U)>> Funcs;
public:
	void operator+=(std::function<void(T, U)> Func) {
		Funcs.push_back(Func);
	}
	void operator()(T param1, U param2) const {
		for(auto i = Funcs.cbegin(); i != Funcs.cend(); ++i)
			(*i)(param1, param2);
	}
};

template<typename T>
class EventHandler<T, void> {
	std::list<std::function<void(T)>> Funcs;
public:
	void operator+=(std::function<void(T)> Func) {
		Funcs.push_back(Func);
	}
	void operator()(T param1) const {
		for(auto i = Funcs.cbegin(); i != Funcs.cend(); ++i)
			(*i)(param1);
	}
};

template<>
class EventHandler<void, void> {
	std::list<std::function<void()>> Funcs;
public:
	void operator+=(std::function<void()> Func) {
		Funcs.push_back(Func);
	}
	void operator()() const {
		for(auto i = Funcs.cbegin(); i != Funcs.cend(); ++i)
			(*i)();
	}
};


#endif
