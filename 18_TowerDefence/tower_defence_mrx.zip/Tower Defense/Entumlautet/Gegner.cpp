#include "Gegner.h"
#include "Ressourcen.h"
#include <cmath>


Gegner Gegner::v1(2, 10*2);
Gegner Gegner::v2(4, 10*3);
Gegner Gegner::v3(6, 10*5);
Gegner Gegner::v4(12, 10*6);
Gegner Gegner::v5(25, 10*2);
uint8_t Gegner::Initialisiert = 6;

void Gegner::Init() {
	v1.SetImage(RM().Get<sf::Image>("Grafik/g1.png"));
	v2.SetImage(RM().Get<sf::Image>("Grafik/g2.png"));
	v2.AddKind(v1);
	v3.SetImage(RM().Get<sf::Image>("Grafik/g3.png"));
	v3.AddKind(v2);
	v4.SetImage(RM().Get<sf::Image>("Grafik/g4.png"));
	v4.AddKind(v3);
	v4.AddKind(v3);
	v5.SetImage(RM().Get<sf::Image>("Grafik/g5.png"));
	v5.AddKind(v4);
	v5.AddKind(v3);
	v5.AddKind(v3);
	v5.AddKind(v2);
	v5.AddKind(v2);
	v5.AddKind(v2);
	v5.AddKind(v1);
	v5.AddKind(v1);
	v5.AddKind(v1);
	v5.AddKind(v1);
	Initialisiert = 0;
}


Gegner::Gegner(uint16_t leben, uint16_t geschwindigkeit)
	: Leben(leben), Geschwindigkeit(geschwindigkeit)
{
	if(Initialisiert > 1) Initialisiert--;
	if(Initialisiert == 1) Init();
}

Gegner::Gegner(const Gegner& Vorlage, const PfadElem* Start)
	: sf::Drawable(static_cast<sf::Vector2f>(Start->Pos)), Position(Start), Next(Position->GetRandomNext()), Status(0.f),
	  Leben(Vorlage.Leben), Geschwindigkeit(Vorlage.Geschwindigkeit), Kinder(Vorlage.Kinder), Sp(*Vorlage.Sp.GetImage()) // Von Vorlage "geerbt"
{
	SetOrigin(Sp.GetImage()->GetWidth()/2.f, Sp.GetImage()->GetHeight()/2.f);
}

void Gegner::AddKind(const Gegner& g) {
	Gegner G = g; // Kopie erzeugen
	G.SetPosition(GetPosition());
	Kinder.push_back(G);
}

bool Gegner::IsTunnel() const {
	return(Position->Typ == PfadElem::TUNNEL || Position->Typ == PfadElem::TUNNELEA);
}

void Gegner::SetImage(const sf::Image& Img) {
	Sp.SetImage(Img);
}

bool Gegner::Run(float Frametime) {
	Status += Frametime*Geschwindigkeit;
	if(Next->Pos.x == Position->Pos.x || Next->Pos.y == Position->Pos.y) { // Gerade Bewegung
		if(Status >= 1.f) { // Eins weiter
			Position = Next;
			Next = Position->GetRandomNext();
			if(Next == nullptr) // Ziel erreicht
				return(true);
			SetPosition(static_cast<sf::Vector2f>(Position->Pos));
			Status -= 1.f;
		}
	}
	else { // Schraege Bewegung
		if(Status >= std::sqrt(2.f)) { // Eins weiter
			Position = Next;
			Next = Position->GetRandomNext();
			if(Next == nullptr) // Ziel erreicht
				return(true);
			SetPosition(static_cast<sf::Vector2f>(Position->Pos));
			Status -= std::sqrt(2.f);
		}
	}
	return(false);
}

bool Gegner::Treffer(uint16_t Schaden, float Verlangsamung) {
	Geschwindigkeit *= Verlangsamung;
	if(Schaden >= Leben) {
		for(auto i = Kinder.begin(); i != Kinder.end(); ++i) { // Kinder vorbereiten
			i->Position = Position;
			i->Next = Next;
			i->Status = Status;
			i->SetOrigin(GetOrigin());
		}
		return(true);
	}
	Leben -= Schaden;
	return(false);
}

uint16_t Gegner::GetValue() const {
	uint16_t Wert = 1;
	for(auto i = Kinder.cbegin(); i != Kinder.cend(); ++i) {
		Wert += i->GetValue();
	}
	return(Wert);
}

float Gegner::GetRadius() const {
	return(Sp.GetImage()->GetWidth()/2.f);
}

void Gegner::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	if(!IsTunnel())
		Target.Draw(Sp);
}
