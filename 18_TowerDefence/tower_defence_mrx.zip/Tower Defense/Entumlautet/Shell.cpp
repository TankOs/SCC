#include "Shell.h"
#include "Status.h"
#include <iostream>
#include <fstream>



Shell::Shell(const std::string& folder, const std::string& Welcome, const std::string& prompt)
	: Prompt(prompt), Folder(folder), Thr(std::bind(&Shell::Run, this))
{
	std::cout << Welcome << std::endl << std::endl;
	Thr.Launch();
}

Shell::~Shell() {
	Thr.Terminate();
}

void Shell::Run() const {
	std::string command;
	for(;;) {
		std::cout << std::endl << std::endl << Prompt;

		std::cin >> command;

		(*this)(command);
	}
}

void Shell::DisplayText(const std::string& name) const {
	std::ifstream ifs(Folder + "/" + name + ".txt");
	if(!ifs.good()) throw 0; // File not found -> unknown text

	std::string Text = std::string(std::istreambuf_iterator<char>(ifs), std::istreambuf_iterator<char>());
	std::cout << std::endl << Text << std::endl;
}

void Shell::Execute(const std::string& command) const {
	CommandTable.at(command)();
}

void Shell::operator()(const std::string& command) const {
	try { // Funktion ausfuehren
		Execute(command);
	}
	catch(...) {
		try { // Text anzeigen
			DisplayText(command);
		}
		catch(...) {
			std::cout << "Den Befehl \"" << command << "\" gibt es nicht.";
		}
	}
}

const Shell& Shell::operator<<(const std::string& string) const {
	std::cout << std::endl << std::endl << string << std::endl << std::endl;
	return(*this);
}

void Shell::AddCommand(const std::string& command, std::function<void(void)> func) {
	CommandTable[command] = func;
}
