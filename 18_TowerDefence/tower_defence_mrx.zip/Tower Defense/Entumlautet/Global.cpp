#include "Global.h"


#define PI 3.14159265358979323846f


float radtodeg(float f) {
	return(180.0f*f/PI);
}

bool CircleCollision(sf::Vector2f P1, float R1, sf::Vector2f P2, float R2) {
	P1 -= P2;
	return(std::sqrt(P1.x*P1.x+P1.y*P1.y) <= (R1+R2));
}
