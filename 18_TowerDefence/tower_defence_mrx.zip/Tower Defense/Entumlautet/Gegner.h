#ifndef GEGNER_H
#define GEGNER_H

#include "Global.h"
#include "Pfad.h"
#include <list>


class Gegner : public sf::Drawable {
	sf::Sprite Sp;

	const PfadElem* Position;
	const PfadElem* Next;
	float Status;

	static uint8_t Initialisiert;
	static void Init();

	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
	Gegner(uint16_t leben, uint16_t geschwindigkeit);
public:
	uint16_t Leben;
	uint16_t Geschwindigkeit;
	std::list<Gegner> Kinder;

	Gegner(const Gegner& Vorlage, const PfadElem* Start);
	bool Run(float Frametime);
	bool Treffer(uint16_t Schaden, float Verlangsamung);
	void AddKind(const Gegner& g);
	void SetImage(const sf::Image& Img);
	bool IsTunnel() const;
	uint16_t GetValue() const;
	float GetRadius() const;

	static Gegner v1, v2, v3, v4, v5;
};


#endif
