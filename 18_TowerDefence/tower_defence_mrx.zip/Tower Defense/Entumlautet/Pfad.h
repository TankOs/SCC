#ifndef PFAD_H
#define PFAD_H

#include "Global.h"
#include <vector>


class PfadElem {
	std::vector<PfadElem*> Nachfolger;
public:
	sf::Vector2<unsigned int> Pos;
	enum TYP {NORMAL, TUNNELEA, TUNNEL} Typ;

	PfadElem(int x = 0, int y = 0, PfadElem::TYP typ = NORMAL);
	void operator+=(PfadElem* Elem);
	const PfadElem* GetRandomNext() const;
	void FindNachfolger(const sf::Color& Col);
	sf::Color FindAnfangsfarbe(const sf::Image& Img) const;
	~PfadElem();
};


class PfadKarte {
public:
	PfadElem Start;
	const sf::Image* Img;

	void Load(const sf::Image& Img);
};


#endif
