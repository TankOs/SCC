#include "Window.h"
#include "Control.h"


Window::Window(sf::VideoMode mode, const sf::String& title, unsigned long style)
	: sf::RenderWindow(mode, title, style)
{
	EnableVerticalSync(true);
}

void Window::HandleEvents() {
	sf::Event EV;
	while(PollEvent(EV)) {
		switch(EV.Type) {
			case sf::Event::Closed:
				OnClose();
				Close();
				break;
			case sf::Event::MouseMoved:
			{
				sf::Vector2i Point(EV.MouseMove.X, EV.MouseMove.Y);
				for(auto i = Childs.crbegin(); i != Childs.crend(); ++i) {
					if((*i)->GetRect().Contains(static_cast<sf::Vector2f>(Point))) {
						(*i)->OnMouseMove(Point);
						break;
					}
				}
				break;
			}
			case sf::Event::MouseButtonPressed:
			{
				sf::Vector2i Point(EV.MouseButton.X, EV.MouseButton.Y);
				for(auto i = Childs.crbegin(); i != Childs.crend(); ++i) {
					if((*i)->GetRect().Contains(static_cast<sf::Vector2f>(Point))) {
						(*i)->OnMouseButtonDown(Point, EV.MouseButton.Button);
						break;
					}
				}
				break;
			}
			case sf::Event::MouseButtonReleased:
			{
				sf::Vector2i Point(EV.MouseButton.X, EV.MouseButton.Y);
				for(auto i = Childs.crbegin(); i != Childs.crend(); ++i) {
					if((*i)->GetRect().Contains(static_cast<sf::Vector2f>(Point))) {
						(*i)->OnMouseButtonUp(Point, EV.MouseButton.Button);
						break;
					}
				}
				break;
			}
			case sf::Event::KeyPressed:
				OnKeyDown(EV.Key.Code);
				break;
			case sf::Event::KeyReleased:
				OnKeyUp(EV.Key.Code);
				break;
		}
	}
}

void Window::Display() {
	DrawChilds(*this);
	sf::RenderWindow::Display();
	Clear();
}
