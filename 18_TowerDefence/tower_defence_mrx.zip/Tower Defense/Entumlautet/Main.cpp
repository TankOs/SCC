#include "Status.h"
#include "Spiel.h"
#include "Button.h"
#include "Window.h"
#include "Label.h"
#include "ValueBoundLabel.h"
#include "Shell.h"
#include <cstdlib>
#include <fstream>


Spiel* TowerDefense = nullptr;

Window RW(sf::VideoMode(800,600), "Tower Defense", sf::Style::Close);
Button bSpeichern(sf::FloatRect(180,310,230,75), "Spiel speichern");
Button bSchliessen(sf::FloatRect(430,310,190,75), "Schlie�en");
Button bSpielNeu(sf::FloatRect(190,210,200,75), "Neues Spiel");
Button bSpielLaden(sf::FloatRect(410,210,200,75), "Spiel laden");
Button bMenue(sf::FloatRect(665,60,120,50), "Men�");
Button bStart(sf::FloatRect(15, 535, 120, 50), "Start");
ValueBoundLabel<int16_t> vLeben(Leben, "Leben: ");
ValueBoundLabel<uint16_t> vGeld(Geld, "Geld: "), vLevel(Level, "Level: ");
Label Verloren("Verloren");
Label Gewonnen("Gewonnen");

Shell shell("Hilfe", "Willkommen in der Kommandozeilenhilfeschnittstelle von Tower Defense.\n\nGeben Sie \"?\" ein, um weitere Informationen zu bekommen.");

void SetVBLPos() {
	vGeld.SetPosition(525-vGeld.GetRect().Width/2, 5);
	vLevel.SetPosition(800-15-vGeld.GetRect().Width, 5);
}

void Close() {
	SetStatus(ENDE);
	RW.Close();
	delete TowerDefense;
	exit(0); // HACK
}

void Schliessen(const sf::Vector2i&, sf::Mouse::Button) {
	Close();
}

void Speichern(const sf::Vector2i&, sf::Mouse::Button) {
	std::ofstream ofs("Level/Level.Status");
	ofs << Level << std::endl;
	ofs << Geld << std::endl;
	ofs << Leben;
}

void NeuesSpiel() {
	delete TowerDefense;
	TowerDefense = new Spiel();
	RW.ClearChilds();
	bStart.SetText("Start");
	RW += TowerDefense;
	RW += bMenue;
	RW += bStart;
	RW += vLeben;
	RW += vGeld;
	RW += vLevel;
}

void Pause() {
	if(GetStatus() == LEVEL) {
		if(TowerDefense->IsPaused()) {
			TowerDefense->Continue();
			bStart.SetText("Pause");
		}
		else {
			TowerDefense->Pause();
			bStart.SetText("Weiter");
		}
	}
}

void Start(const sf::Vector2i&, sf::Mouse::Button) {
	if(GetStatus() == LEVEL) {
		Pause();
	}
	else {
		SetStatus(LEVEL);
		bStart.SetText("Pause");
		TowerDefense->Continue();
	}
}

void SpielNeu(const sf::Vector2i&, sf::Mouse::Button) {
	Level = 1;
	Leben = 25;
	Geld = 50;
	NeuesSpiel();
}

void SpielLaden(const sf::Vector2i&, sf::Mouse::Button) {
	Level = 0;
	NeuesSpiel();
}

void Menue() {
	SetStatus(MENUE);
	RW.ClearChilds();
	RW += bSpeichern;
	RW += bSchliessen;
	RW += bSpielNeu;
	RW += bSpielLaden;
	RW += vLeben;
	RW += vGeld;
	RW += vLevel;
	delete TowerDefense;
	TowerDefense = 0;
}

void fMenue(const sf::Vector2i&, sf::Mouse::Button) {
	Menue();
}

void KeyUp(sf::Key::Code Key) {
	switch(Key) {
		case sf::Key::Escape:
			Close();
			break;
		case sf::Key::M:
			if(GetStatus() != MENUE)
				Menue();
			break;
		case sf::Key::Pause:
			Pause();
			break;
		default:
			if(TowerDefense != nullptr)
				TowerDefense->KeyPressed(Key);
			break;
	}
}


int main() {
	std::srand(static_cast<unsigned int>(std::time(nullptr)));

	shell.AddCommand("?", std::bind(&Shell::operator(), &shell, "Hilfe"));
	shell.AddCommand("Beenden", &Close);

	Verloren.SetColor(sf::Color::Red);
	Verloren.SetPosition(400,300);
	Gewonnen.SetColor(sf::Color::Green);
	Gewonnen.SetPosition(400,300);

	RW.OnClose += &Close;
	RW.OnKeyUp += &KeyUp;
	
	bSchliessen.OnMouseButtonUp += &Schliessen;
	bSpeichern.OnMouseButtonUp += &Speichern;
	bSpielNeu.OnMouseButtonUp += &SpielNeu;
	bSpielLaden.OnMouseButtonUp += &SpielLaden;
	bMenue.OnMouseButtonUp += &fMenue;
	bStart.OnMouseButtonUp += &Start;

	vLeben.SetPosition(250,5);
	vGeld.OnTextUpdate += &SetVBLPos;
	vLevel.OnTextUpdate += &SetVBLPos;
	SetVBLPos();

	Menue();

	while(GetStatus() != ENDE) {
		RW.HandleEvents();

		if(GetStatus() == LEVEL && !TowerDefense->IsPaused()) {
			if(TowerDefense->Run(RW.GetFrameTime())) {
				if(!TowerDefense->NextLevel()) { // DURCHGESPIELT
					RW.ClearChilds();
					RW += bMenue;
					RW += Gewonnen;
				}
				else {
					Geld += 25;
					bStart.SetText("Start");
				}
			}
			if(GetStatus() == VERLOREN) { // Gesetzt durch TowerDefense->Run
				RW.ClearChilds();
				RW += bMenue;
				RW += Verloren;
			}
		}

		if(GetStatus() != ENDE)
			RW.Display();
	}

	return(0);
}
