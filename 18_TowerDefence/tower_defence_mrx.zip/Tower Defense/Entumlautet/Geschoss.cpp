#include "Geschoss.h"


Geschoss::Geschoss(const sf::Image& Img, const sf::Vector2f& Position, float richtung, float geschwindigkeit, uint16_t schaden, uint16_t durchschlag, float verlangsamung)
	: sf::Drawable(Position), Sp(Img), Bewegung(std::cos(richtung) * geschwindigkeit, std::sin(richtung) * geschwindigkeit), Schaden(schaden), Verlangsamung(verlangsamung), Durchschlag(durchschlag)
{
	SetOrigin(Img.GetWidth()/2.f, Img.GetHeight()/2.f);
	SetRotation(90.f+radtodeg(richtung));
}

bool Geschoss::Run(float Frametime) {
	if(GetPosition().x < 0 || GetPosition().x > 800 || GetPosition().y < 0 || GetPosition().y > 600)
		return(false);
	Move(Frametime*Bewegung);
	return(true);
}

bool Geschoss::Treffer() {
	Durchschlag--;
	return(Durchschlag == 0);
}

void Geschoss::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(Sp);
}

float Geschoss::GetRadius() const {
	return(Sp.GetImage()->GetWidth()/2.f);
}
