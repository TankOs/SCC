#include "Label.h"


Label::Label(const std::string& text)
	: Text(text)
{
	Text.SetCharacterSize(80);
	Text.SetOrigin(Text.GetRect().Width/2, Text.GetRect().Height/2);
	OnRender += std::bind(&Label::Render, this, std::placeholders::_1);
}

void Label::Render(sf::RenderTarget& Target) const {
	Target.Draw(Text);
}

sf::FloatRect Label::GetRect() const {
	return(Text.GetRect());
}
