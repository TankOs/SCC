#ifndef SHELL_H
#define SHELL_H

#include "Global.h"
#include <map>
#include <functional>
#include <string>
#include <iostream>


class Shell {
	std::string Prompt;
	std::string Folder;
	std::map<std::string, std::function<void(void)>> CommandTable;
	sf::Thread Thr;

	void Run() const;
	void DisplayText(const std::string& name) const;
	void Execute(const std::string& command) const;
public:
	Shell(const std::string& folder, const std::string& Welcome, const std::string& prompt = "$> ");
	~Shell();
	void operator()(const std::string& command) const;
	const Shell& operator<<(const std::string& string) const;
	void AddCommand(const std::string& command, std::function<void(void)> func);
};


#endif
