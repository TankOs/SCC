#include "Ressourcen.h"


Resourcemanager& RM() {
	static Resourcemanager RM;
	return(RM);
}


// Resource
Resource::Resource()
	: Type(NONE)
{
}

template<>
void Resource::Load<sf::Image>(const std::string& path) {
	if(Type == NONE)
	{
		Type = IMAGE;
		Image = new sf::Image();
		Image->LoadFromFile(path);
	}
}
template<>
void Resource::Load<sf::SoundBuffer>(const std::string& path) {
	if(Type == NONE)
	{
		Type = SOUND;
		Sound = new sf::SoundBuffer();
		Sound->LoadFromFile(path);
	}
}
template<>
void Resource::Load<sf::Font>(const std::string& path) {
	if(Type == NONE)
	{
		Type = FONT;
		Font = new sf::Font();
		Font->LoadFromFile(path);
	}
}

template<>
sf::Image& Resource::Get<sf::Image>() const {
	if(Type != IMAGE) throw 0;
	return(*Image);
}
template<>
sf::SoundBuffer& Resource::Get<sf::SoundBuffer>() const {
	if(Type != SOUND) throw 0;
	return(*Sound);
}
template<>
sf::Font& Resource::Get<sf::Font>() const {
	if(Type != FONT) throw 0;
	return(*Font);
}

Resource::~Resource() {
	switch(Type) {
		case IMAGE:
			delete Image;
			break;
		case SOUND:
			delete Sound;
			break;
		case FONT:
			delete Font;
			break;
		default:
			break;
	}
}
