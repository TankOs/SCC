#ifndef WINDOW_H
#define WINDOW_H

#include "Global.h"
#include "ControlContainer.h"
#include "EventHandler.h"
#include <list>


class Window : public sf::RenderWindow, public ControlContainer {
public:
	EventHandler<void,void> OnClose;
	EventHandler<sf::Key::Code, void> OnKeyDown;
	EventHandler<sf::Key::Code, void> OnKeyUp;

	Window(sf::VideoMode mode, const sf::String& title, unsigned long style = sf::Style::Default);
	void HandleEvents();
	void Display();
};


#endif
