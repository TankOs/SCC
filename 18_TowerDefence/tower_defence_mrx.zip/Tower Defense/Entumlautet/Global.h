#ifndef GLOBAL_H
#define GLOBAL_H

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <cstdint>


float radtodeg(float f);
bool CircleCollision(sf::Vector2f P1, float R1, sf::Vector2f P2, float R2);


#endif
