#ifndef RESSOURCEN_H
#define RESSOURCEN_H

#include "Global.h"
#include <map>
#include <string>


namespace sf {
	class Image;
	class SoundBuffer;
	class Font;
}

class Resource {
	enum TYPE {NONE, IMAGE, SOUND, FONT};
	TYPE Type;
	union {
		sf::Image* Image;
		sf::SoundBuffer* Sound;
		sf::Font* Font;
	};
public:
	//Default constructor
	//______________________
	Resource();

	//Loads a resource. Specialized for the different kinds of resources.
	//	path: Path of the resource to be loaded
	//______________________
	template<typename T>
	void Load(const std::string& path);

	//Returns a reference to the resource. Specialized for the different kinds of resources
	//______________________
	template<typename T>
	T& Get() const;

	//Destructor
	//______________________
	~Resource();
};

class Resourcemanager {
	std::map<std::string, Resource> Resourcen;
public:
	Resourcemanager() {} // Just provided for MinGW

	//Returns a reference to the resource object. Takes the type of the resource as template parameter. If the resource object is not already loaded from file, it is loaded
	//	path: Path of the resource
	//______________________
	template<typename T>
	T& Get(const std::string& path);
};


Resourcemanager& RM();


#include "Ressourcen.inl"

#endif
