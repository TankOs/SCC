#ifndef STATUS_H
#define STATUS_H

#include "Global.h"


enum STATUS {
	MENUE, BAUPAUSE, LEVEL, VERLOREN, DURCHGESPIELT, ENDE
};

STATUS GetStatus();
void SetStatus(STATUS s);


#endif
