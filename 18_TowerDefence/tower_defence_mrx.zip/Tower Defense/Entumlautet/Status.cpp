#include "Status.h"


static STATUS Status = MENUE;

STATUS GetStatus() {
	return(Status);
}

void SetStatus(STATUS s) {
	Status = s;
}