#ifndef TURM_H
#define TURM_H

#include "Global.h"
#include "Geschoss.h"


class Turm : public sf::Drawable {
	sf::Sprite Sp;
	sf::Shape* Kreis;
	sf::Clock Ladeuhr;

	uint16_t Reichweite;
	float Verlangsamung;
	float Ladezeit;
	uint16_t Durchschlag;
	uint16_t Schussgeschw;
	const sf::Image& GImg;
	const sf::SoundBuffer& Schuss;

	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
	Turm(const sf::Image& Img, const sf::Image& gImg, const sf::SoundBuffer& schuss, const sf::Vector2f& Mitte, uint16_t preis, uint16_t reichweite, float ladezeit, uint16_t schussgeschw, uint16_t durchschlag, uint16_t schaden, float verlangsamung = 1.f);
public:
	uint16_t Preis;
	uint16_t Schaden;

	Turm(uint16_t Typ);
	Geschoss* Schiesse(sf::Vector2i Ziel);

	static Turm Tuerme[4];
};


#endif
