#ifndef LABEL_H
#define LABEL_H

#include "Global.h"
#include "Control.h"


class Label : public Control {
	sf::Text Text;

	void Render(sf::RenderTarget& Target) const;
public:
	Label(const std::string& text);

	sf::FloatRect GetRect() const;
};


#endif
