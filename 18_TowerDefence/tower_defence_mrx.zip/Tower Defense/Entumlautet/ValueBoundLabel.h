#ifndef VALUEBOUNDLABEL_H
#define VALUEBOUNDLABEL_H

#include "Global.h"
#include "Control.h"
#include "EventHandler.h"


template<typename T>
class ValueBoundLabel : public Control {
	mutable sf::Text Text;
	mutable T oldValue;
	const T& Value;
	std::string Prefix, Postfix;

	void Render(sf::RenderTarget& Target) const;
	void UpdateText() const;
public:
	EventHandler<void, void> OnTextUpdate;

	ValueBoundLabel(const T& v, const std::string& prefix = "", const std::string& postfix = "");

	sf::FloatRect GetRect() const;
};


#include "ValueBoundLabel.inl"

#endif
