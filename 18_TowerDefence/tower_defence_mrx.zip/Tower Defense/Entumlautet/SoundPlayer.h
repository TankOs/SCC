#ifndef SOUNDPLAYER_H
#define SOUNDPLAYER_H

#include "Global.h"
#include <list>


class SoundPlayer {
	std::list<sf::Sound> Sounds;
public:
	void operator+=(const sf::SoundBuffer& buf);
};

extern SoundPlayer sPlayer;


#endif
