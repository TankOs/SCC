#include "SoundPlayer.h"


SoundPlayer sPlayer;


void SoundPlayer::operator+=(const sf::SoundBuffer& buf) {
	Sounds.push_back(sf::Sound(buf));
	Sounds.back().Play();
	for(auto i = Sounds.begin(); i != Sounds.end();) {
		if(i->GetStatus() != sf::Sound::Playing)
			i = Sounds.erase(i);
		else
			++i;
	}
}
