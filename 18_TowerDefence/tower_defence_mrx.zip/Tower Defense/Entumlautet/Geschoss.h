#ifndef GESCHOSS_H
#define GESCHOSS_H

#include "Global.h"


class Geschoss : public sf::Drawable {
	sf::Vector2f Bewegung;
	sf::Sprite Sp;

	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	float Verlangsamung;
	uint16_t Schaden;
	uint16_t Durchschlag;

	Geschoss(const sf::Image& Img, const sf::Vector2f& Position, float richtung, float geschwindigkeit, uint16_t schaden, uint16_t durchschlag, float verlangsamung);
	bool Run(float Frametime);
	bool Treffer();
	float GetRadius() const;
};


#endif
