#include "Pfad.h"

bool CompRGB(const sf::Color& l, const sf::Color& r, uint32_t vTyp) {
	switch(vTyp) {
		case PfadElem::NORMAL: // Ignoriere Alpha
			return(l.a >= 254 && l.r == r.r && l.b == r.b && l.g == r.g);
		case PfadElem::TUNNELEA: // Alpha muss 253 oder 255 sein
			return((l.a == 253 || l.a == 255) && l.r == r.r && l.b == r.b && l.g == r.g);
		case PfadElem::TUNNEL: // Alpha muss 253 oder 254 sein
			return((l.a == 253 || l.a == 254) && l.r == r.r && l.b == r.b && l.g == r.g);
	}
	return(false);
}

PfadElem::TYP AlphaToTyp(uint8_t alpha) {
	switch(alpha) {
		case 255:
			return(PfadElem::NORMAL);
		case 254:
			return(PfadElem::TUNNELEA);
		case 253:
			return(PfadElem::TUNNEL);
	}
	return(PfadElem::NORMAL);
}


PfadElem::PfadElem(int x, int y, PfadElem::TYP typ)
	: Pos(x, y), Typ(typ)
{
}

std::set<PfadElem*> Deleted;
PfadElem::~PfadElem() {
	for(auto i = Nachfolger.begin(); i != Nachfolger.end(); ++i) {
		if(Deleted.find(*i) == Deleted.end()) {
			Deleted.insert(*i);
			delete *i;
		}
	}
}

const sf::Image* gImg = nullptr;
std::vector<PfadElem*> Knotenliste;

void PfadElem::FindNachfolger(const sf::Color& Col) {
	sf::Color Next(Col.r+64, Col.g+64, Col.b+64);
	if(Col.b == 192) 
		Next = sf::Color::Black;

	for(auto i = Knotenliste.cbegin(); i != Knotenliste.end(); ++i) {
		if((*i)->Pos == this->Pos) { // Zum wiederholten Male an einem Knoten angekommen -> Ring schlie�en
			for(auto j = (*i)->Nachfolger.cbegin(); j != (*i)->Nachfolger.cend(); ++j) {
				Nachfolger.push_back(*j);
			}
			return;
		}
	}

	std::vector<PfadElem*> PfadElems;
	if(Pos.x > 0 && CompRGB(gImg->GetPixel(Pos.x-1, Pos.y), Col, Typ)) {
		PfadElem* E = new PfadElem(Pos.x-1, Pos.y, AlphaToTyp(gImg->GetPixel(Pos.x-1, Pos.y).a));
		PfadElems.push_back(E);
	}
	if(Pos.x+1<gImg->GetWidth() && CompRGB(gImg->GetPixel(Pos.x+1, Pos.y), Col, Typ)) {
		PfadElem* E = new PfadElem(Pos.x+1, Pos.y, AlphaToTyp(gImg->GetPixel(Pos.x+1, Pos.y).a));
		PfadElems.push_back(E);
	}
	if(Pos.y > 0 && CompRGB(gImg->GetPixel(Pos.x, Pos.y-1), Col, Typ)) {
		PfadElem* E = new PfadElem(Pos.x, Pos.y-1, AlphaToTyp(gImg->GetPixel(Pos.x, Pos.y-1).a));
		PfadElems.push_back(E);
	}
	if(Pos.y+1<gImg->GetHeight() && CompRGB(gImg->GetPixel(Pos.x, Pos.y+1), Col, Typ)) {
		PfadElem* E = new PfadElem(Pos.x, Pos.y+1, AlphaToTyp(gImg->GetPixel(Pos.x, Pos.y+1).a));
		PfadElems.push_back(E);
	}
	if(Pos.x > 0 && Pos.y+1<gImg->GetHeight() && CompRGB(gImg->GetPixel(Pos.x-1, Pos.y+1), Col, Typ)) {
		PfadElem* E = new PfadElem(Pos.x-1, Pos.y+1, AlphaToTyp(gImg->GetPixel(Pos.x-1, Pos.y+1).a));
		PfadElems.push_back(E);
	}
	if(Pos.x+1<gImg->GetWidth() && Pos.y > 0 && CompRGB(gImg->GetPixel(Pos.x+1, Pos.y-1), Col, Typ)) {
		PfadElem* E = new PfadElem(Pos.x+1, Pos.y-1, AlphaToTyp(gImg->GetPixel(Pos.x+1, Pos.y-1).a));
		PfadElems.push_back(E);
	}
	if(Pos.x > 0 && Pos.y > 0 && CompRGB(gImg->GetPixel(Pos.x-1, Pos.y-1), Col, Typ)) {
		PfadElem* E = new PfadElem(Pos.x-1, Pos.y-1, AlphaToTyp(gImg->GetPixel(Pos.x-1, Pos.y-1).a));
		PfadElems.push_back(E);
	}
	if(Pos.x+1<gImg->GetWidth() && Pos.y+1<gImg->GetHeight() && CompRGB(gImg->GetPixel(Pos.x+1, Pos.y+1), Col, Typ)) {
		PfadElem* E = new PfadElem(Pos.x+1, Pos.y+1, AlphaToTyp(gImg->GetPixel(Pos.x+1, Pos.y+1).a));
		PfadElems.push_back(E);
	}

	if(PfadElems.size() > 1) {// Knoten gefunden
		Knotenliste.push_back(this);
	}
	for(auto i = PfadElems.begin(); i != PfadElems.end(); ++i) {
		*this += *i;
		(*i)->FindNachfolger(Next);
	}
}

void PfadElem::operator+=(PfadElem* Elem) {
	Nachfolger.push_back(Elem);
}

const PfadElem* PfadElem::GetRandomNext() const {
	if(Nachfolger.empty())
		return(nullptr);
	return(Nachfolger[std::rand()%Nachfolger.size()]);
}

sf::Color PfadElem::FindAnfangsfarbe(const sf::Image& Img) const {
	if(Pos.x > 0 && Img.GetPixel(Pos.x-1, Pos.y) != sf::Color(0,0,0,0))
		return(Img.GetPixel(Pos.x-1, Pos.y));
	if(Pos.x < Img.GetWidth()-1 && Img.GetPixel(Pos.x+1, Pos.y) != sf::Color(0,0,0,0))
		return(Img.GetPixel(Pos.x+1, Pos.y));
	if(Pos.y > 0 && Img.GetPixel(Pos.x, Pos.y-1) != sf::Color(0,0,0,0))
		return(Img.GetPixel(Pos.x, Pos.y-1));
	if(Pos.y < Img.GetHeight()-1 && Img.GetPixel(Pos.x, Pos.y+1) != sf::Color(0,0,0,0))
		return(Img.GetPixel(Pos.x, Pos.y+1));

	return(sf::Color::Black);
}

void PfadKarte::Load(const sf::Image& img) {
	Knotenliste.clear();
	Deleted.clear();
	Img = &img;
	gImg = &img;

	// Anfangspunkte finden.
	for(uint16_t i = 0; i < img.GetWidth(); i++) {
		if(img.GetPixel(i, 0) == sf::Color::Red) {
			PfadElem* E = new PfadElem(i, 0);
			Start += E;
			E->FindNachfolger(E->FindAnfangsfarbe(img));
		}
		if(img.GetPixel(i, img.GetHeight()-1) == sf::Color::Red) {
			PfadElem* E = new PfadElem(i, img.GetHeight()-1);
			Start += E;
			E->FindNachfolger(E->FindAnfangsfarbe(img));
		}
	}
	for(uint16_t i = 1; (uint16_t)(i+1) < img.GetHeight(); i++) {
		if(img.GetPixel(0, i) == sf::Color::Red) {
			PfadElem* E = new PfadElem(0, i);
			Start += E;
			E->FindNachfolger(E->FindAnfangsfarbe(img));
		}
		if(img.GetPixel(img.GetWidth()-1, i) == sf::Color::Red) {
			PfadElem* E = new PfadElem(img.GetWidth()-1, i);
			Start += E;
			E->FindNachfolger(E->FindAnfangsfarbe(img));
		}
	}
}


