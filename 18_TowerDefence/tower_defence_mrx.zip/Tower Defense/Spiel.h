#ifndef SPIEL_H
#define SPIEL_H

#include "Global.h"
#include "Gegner.h"
#include "Pfad.h"
#include "Control.h"
#include "Turm.h"


extern uint16_t Level;
extern uint16_t Geld;
extern int16_t Leben;


class Spiel : public Control {
	sf::Thread Pusher;
	bool LevelFertig;
	std::list<Gegner> gegner;
	PfadKarte* pKarte;
	bool Paused;
	sf::Mutex Pauser;
	sf::Sprite Hintergrund;

	uint16_t Gew�hlterTurmtyp;
	std::list<Turm> T�rme;
	std::list<Geschoss*> Geschosse;

	void Render(sf::RenderTarget& Target) const;
	sf::FloatRect GetRect() const;
	void MouseMove(const sf::Vector2i& Pos);
	void MouseButtonUp(const sf::Vector2i&, sf::Mouse::Button Button);

	void fPusher();
public:
	Spiel();
	~Spiel();
	bool Run(float Frametime);
	bool NextLevel();
	void Pause();
	void Continue();
	bool IsPaused() const;
	void KeyPressed(sf::Key::Code Taste);
};


#endif
