#include "Spiel.h"
#include "Ressourcen.h"
#include "Status.h"
#include <fstream>
#include <functional>
#include <cstdlib>


uint16_t Level = 0;
uint16_t Geld = 50;
int16_t Leben = 25;


Spiel::Spiel() : Pusher(std::bind(&Spiel::fPusher, this)), Paused(true), Gew�hlterTurmtyp(0), LevelFertig(false), pKarte(new PfadKarte()) {
	SetStatus(BAUPAUSE);

	if(Level == 0) {
		std::ifstream ifs("Level/Level.Status");
		if(ifs.good()) {
			ifs >> Level;
			ifs >> Geld;
			ifs >> Leben;
		}
		else {
			Level = 1;
			Geld = 50;
			Leben = 25;
		}
	}
	std::ifstream ifs("Level/" + std::to_string((long long)Level) + ".Level");
	std::string Pfad;
	ifs >> Pfad;
	ifs >> Pfad;
	pKarte->Load(RM().Get<sf::Image>("Level/" + Pfad));
	ifs >> Pfad;
	Hintergrund.SetImage(RM().Get<sf::Image>("Level/" + Pfad));

	Pauser.Lock();
	Pusher.Launch();

	OnRender += std::bind(&Spiel::Render, this, std::placeholders::_1);
	OnMouseMove += std::bind(&Spiel::MouseMove, this, std::placeholders::_1);
	OnMouseButtonUp += std::bind(&Spiel::MouseButtonUp, this, std::placeholders::_1, std::placeholders::_2);
}

Spiel::~Spiel() {
	Pusher.Terminate();
	for(auto i = Geschosse.begin(); i != Geschosse.end(); ++i)
		delete *i;
}

void Spiel::fPusher() {
	std::srand(static_cast<unsigned int>(std::time(nullptr)));

	std::ifstream ifs("Level/" + std::to_string((long long)Level) + ".Level");
	std::string temp;
	ifs >> temp;
	ifs >> temp;
	ifs >> temp;
	do {
		Pauser.Lock();
		Pauser.Unlock();
		char c = 0;
		ifs.get(c);
		switch(c) {
			case '1':
				gegner.push_back(Gegner(Gegner::v1, pKarte->Start.GetRandomNext()));
				break;
			case '2':
				gegner.push_back(Gegner(Gegner::v2, pKarte->Start.GetRandomNext()));
				break;
			case '3':
				gegner.push_back(Gegner(Gegner::v3, pKarte->Start.GetRandomNext()));
				break;
			case '4':
				gegner.push_back(Gegner(Gegner::v4, pKarte->Start.GetRandomNext()));
				break;
			case '5':
				gegner.push_back(Gegner(Gegner::v5, pKarte->Start.GetRandomNext()));
				break;
			case '#':
				sf::Sleep(4.f);
				break;
			case '\n':
				sf::Sleep(0.8f);
				break;
		}
		if(!ifs.good())
			LevelFertig = true;
		sf::Sleep(0.4f);
	} while(GetStatus() == LEVEL);
}

bool Spiel::NextLevel() {
	Gew�hlterTurmtyp = 0;
	SetStatus(BAUPAUSE);
	Level++;
	LevelFertig = false;
	
	for(auto i = Geschosse.begin(); i != Geschosse.end(); ++i)
		delete *i;
	Geschosse.clear();

	std::ifstream ifs("Level/" + std::to_string((long long)Level) + ".Level");
	if(!ifs.good()) {
		SetStatus(DURCHGESPIELT);
		return(false);
	}
	std::string Pfad;
	ifs >> Pfad;
	if(Pfad != "0") T�rme.clear();
	ifs >> Pfad;
	delete pKarte;
	pKarte = new PfadKarte();
	pKarte->Load(RM().Get<sf::Image>("Level/" + Pfad));
	ifs >> Pfad;
	Hintergrund.SetImage(RM().Get<sf::Image>("Level/" + Pfad));

	Pauser.Lock();
	Pusher.Launch();
	return(true);
}

sf::FloatRect Spiel::GetRect() const {
	static sf::FloatRect R(0,0,800,600);
	return(R);
}

void Spiel::Render(sf::RenderTarget& Target) const {
	Target.Draw(Hintergrund);
	for(auto i = T�rme.cbegin(); i != T�rme.cend(); ++i)
		Target.Draw(*i);
	for(auto i = Geschosse.cbegin(); i != Geschosse.cend(); ++i)
		Target.Draw(**i);
	for(auto i = gegner.cbegin(); i != gegner.cend(); ++i)
		Target.Draw(*i);
	if(Gew�hlterTurmtyp != 0 && pKarte->Img->GetPixel(Turm::T�rme[Gew�hlterTurmtyp-1].GetPosition().x, Turm::T�rme[Gew�hlterTurmtyp-1].GetPosition().y) == sf::Color::Green)
		Target.Draw(Turm::T�rme[Gew�hlterTurmtyp-1]);
}

void Spiel::MouseMove(const sf::Vector2i& Pos) {
	if(Gew�hlterTurmtyp != 0)
		Turm::T�rme[Gew�hlterTurmtyp-1].SetPosition(static_cast<sf::Vector2f>(Pos));
}

void Spiel::MouseButtonUp(const sf::Vector2i&, sf::Mouse::Button Button) {
	if(Gew�hlterTurmtyp != 0) {
		if(Button == sf::Mouse::Left) {
			if(Geld >= Turm::T�rme[Gew�hlterTurmtyp-1].Preis && pKarte->Img->GetPixel(Turm::T�rme[Gew�hlterTurmtyp-1].GetPosition().x, Turm::T�rme[Gew�hlterTurmtyp-1].GetPosition().y) == sf::Color::Green) {
				Geld -= Turm::T�rme[Gew�hlterTurmtyp-1].Preis;
				T�rme.push_back(Turm(Gew�hlterTurmtyp-1));
				Gew�hlterTurmtyp = 0;
			}
		}
		else if(Button == sf::Mouse::Right) {
			Gew�hlterTurmtyp = 0;
		}
	}
}

void Spiel::KeyPressed(sf::Key::Code Taste) {
	switch(Taste) {
		case sf::Key::Num1:
			Gew�hlterTurmtyp = 1;
			break;
		case sf::Key::Num2:
			Gew�hlterTurmtyp = 2;
			break;
		case sf::Key::Num3:
			Gew�hlterTurmtyp = 3;
			break;
		case sf::Key::Num4:
			Gew�hlterTurmtyp = 4;
			break;
	}
}

bool Spiel::Run(float Frametime) {
	for(auto i = gegner.begin(); i != gegner.end();) {
		if(!i->IsTunnel()) {
			sf::Vector2i Pos(i->GetPosition());
			for(auto j = T�rme.begin(); j != T�rme.end(); ++j) {
				if(i->Geschwindigkeit > 10 || j->Schaden != 0) {
					Geschoss* G = j->Schie�e(Pos);
					if(G != nullptr) {
						Geschosse.push_back(G);
						continue;
					}
				}
			}
		}
		bool gel�scht = false;
		for(auto j = Geschosse.begin(); j != Geschosse.end();) {
			if((i->Geschwindigkeit > 10 || (*j)->Schaden != 0) && CircleCollision((*j)->GetPosition(), (*j)->GetRadius(), i->GetPosition(), i->GetRadius())) {
				if(i->Treffer((*j)->Schaden, (*j)->Verlangsamung)) {
					gegner.insert(gegner.begin(), i->Kinder.cbegin(), i->Kinder.cend());
					gel�scht = true;
					i = gegner.erase(i);
					Geld++;
				}
				if((*j)->Treffer()) {
					delete *j;
					j = Geschosse.erase(j);
				}
				if(gel�scht)
					break;
			}
			else
				++j;
		}
		if(!gel�scht && i->Run(Frametime)) { // Ziel erreicht
			Leben -= i->GetValue();
			i = gegner.erase(i);
		}
		else if(!gel�scht)
			++i;
	}
	for(auto i = Geschosse.begin(); i != Geschosse.end();) {
		if((*i)->Run(Frametime))
			++i;
		else
			i = Geschosse.erase(i);
	}
	if(Leben < 0) {
		SetStatus(VERLOREN);
		return(false);
	}
	return(LevelFertig && gegner.empty());
}

void Spiel::Pause() {
	Pauser.Lock();
	Paused = true;
}

void Spiel::Continue() {
	Pauser.Unlock();
	Paused = false;
}

bool Spiel::IsPaused() const {
	return(Paused);
}
