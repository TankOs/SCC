#ifndef BUTTON_H
#define BUTTON_H

#include "Global.h"
#include "Control.h"


class Button : public Control {
	sf::Vector2f Size;
	sf::Shape Border;
	sf::Text Text;

	void Render(sf::RenderTarget& Target) const;
public:
	Button(const sf::FloatRect& Rect, const std::string& text);

	void SetText(const std::string& text);
	sf::FloatRect GetRect() const;
};


#endif
