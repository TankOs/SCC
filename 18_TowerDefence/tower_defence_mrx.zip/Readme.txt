HINWEISE/FEHLERQUELLEN:
Dieses Spiel wurde mit SFML 2, Commit 7498b5bc275774752747 getestet und gelinkt.
Um die mitgelieferten Windows-Binaries auszuf�hren, muss auf dem Zielrechner das VCredist 2010 Sp1 installiert sein.
Download: -x64: http://www.microsoft.com/downloads/en/details.aspx?FamilyID=c68ccbb6-75ef-4c9d-a326-879eab4fcdf8
          -x86: http://www.microsoft.com/downloads/en/details.aspx?FamilyID=c32f406a-f8fc-4164-b6eb-5328b8578f03
Falls unter Linux Fehler auftreten oder seltsame Grafiken angezeigt werden, versuchen Sie die Ausf�hrung unter Wine oder Windows. Die Runtime-DLLs wurden f�r die Verwendung unter Wine beigelegt.


Weitere Informationen und eine Anleitung f�r das Spiel finden Sie in der Hilfekonsole des Spiels. Falls Sie keine Konsole sehen, versuchen Sie, die Executable �ber die Kommandozeile auszuf�hren.


Viel Spa�!