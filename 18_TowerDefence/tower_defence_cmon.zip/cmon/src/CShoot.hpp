#ifndef CSHOOT_HPP
#define CSHOOT_HPP

#include <SFML/Graphics.hpp>
class CDefences;
class CShoot
{
protected:
    sf::Shape _Shoot;
    sf::Vector2f _RV;
    int _fire;
    CDefences &App;
public:
    CShoot(int x, int y, int fire ,sf::Vector2f RV, CDefences &App_);
    void move();
    void draw(sf::RenderWindow &App);
    sf::Rect<float> getRect();
    int getFire();
};

#endif // CSHOOT_HPP
