#ifndef CTOWER_HPP
#define CTOWER_HPP

#include <SFML/Graphics.hpp>
#include "CShoot.hpp"
class CDefences;
class CTower
{
protected:
    sf::Shape _Tower;
    sf::Shape _Field;
    CDefences &App;
    sf::Clock _rate;
    int _Fire;
    int _Level;
public:
    CTower(CDefences &App);
    void draw(sf::RenderWindow &App);
    void drawTower();
    sf::Rect<float> getRectField();
    sf::Rect<float> getRectTower();
    void setPos(int x, int y);
    void setY(int y);
    CShoot shoot(sf::Vector2f posEnemy);
    bool canShoot();
    void upDate();
};

#endif // CTOWER_HPP
