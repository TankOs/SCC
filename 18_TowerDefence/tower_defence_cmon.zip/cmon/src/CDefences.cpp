#include "CDefences.hpp"
#include <iostream>
#include <sstream>
CDefences::CDefences(sf::VideoMode vMode,const std::string &title):_map(*this),_tmpTower(*this)
{
    this->Create(vMode,title);
    _GameStatus = build;
    _GameStatus2 = wait;

    _Panel = sf::Shape::Rectangle(0,0,800,100,sf::Color(150,150,150));

    _SMoney= sf::String("",sf::Font::GetDefaultFont(),15.0f);
    _SMoney.SetColor(sf::Color(255,0,0));
    _SMoney.SetPosition(10,10);

    _SWave= sf::String("",sf::Font::GetDefaultFont(),15.0f);
    _SWave.SetColor(sf::Color(255,0,0));
    _SWave.SetPosition(10,30);

    _SWaveTime= sf::String("",sf::Font::GetDefaultFont(),15.0f);
    _SWaveTime.SetColor(sf::Color(255,0,0));
    _SWaveTime.SetPosition(100,30);

    _IMoney = 1000;
    _IWave = 1;
    _Wave.Reset();
    _focus = false;
}
//-------------------------------------------------------------------
void CDefences::run()
{

    while(this->IsOpened())
    {
        if(_Enemy.size() == 0 && 10-_Wave.GetElapsedTime()<0 && _GameStatus2 == wait)
        {
            this->createEnemy();
            _GameStatus2 = wave;
        }
        if(_Enemy.size() ==0 && _GameStatus2 == wave)
        {
            _Wave.Reset();
            _GameStatus2= wait;
            _IWave++;
            for(std::list<CShoot>::iterator it=_Shoot.begin(); it!=_Shoot.end();it++ )
                it=_Shoot.erase(it);
        }


        for(std::list<CEnemy>::iterator it=_Enemy.begin(); it != _Enemy.end();it++)
            it->move();

        for(std::list<CShoot>::iterator it=_Shoot.begin();it != _Shoot.end();it++)
            it->move();


        this->enemyIntersectsTower();
        this->shootIntersectsEnemy();

        if(_GameStatus == build)
            this->Tower();


        this->eventHandling();

        this->Clear(sf::Color(0,0,0));
        _map.draw(*this);

        for(std::list<CShoot>::iterator it=_Shoot.begin();it != _Shoot.end();it++)
            it->draw(*this);

        for(std::list<CTower>::iterator it= _Tower.begin();it != _Tower.end();it++)
            it->drawTower();

        if(_GameStatus == build)
            _tmpTower.draw(*this);

        if(_focus == true && _GameStatus == play)
        {
            _itFocus->draw(*this);
        }


        for(std::list<CEnemy>::iterator it=_Enemy.begin(); it != _Enemy.end();it++)
            it->draw(*this);
        this->drawInfoPanel();
        this->Display();
    }
}
//-------------------------------------------------------------------
void CDefences::Tower()
{
    const sf::Input &input = this->GetInput();
    _tmpTower.setPos(input.GetMouseX(),input.GetMouseY());
    if(_map.intersects(_tmpTower.getRectTower()))
    {
        _map.setTower(_tmpTower);
    }
}
//-------------------------------------------------------------------
void CDefences::buildTower()
{
    if(_IMoney-200>=0)
    {
        _Tower.push_back(_tmpTower);
        _IMoney -= 200;
    }
}
//-------------------------------------------------------------------
void CDefences::enemyIntersectsTower()
{
    for(std::list<CTower>::iterator it=_Tower.begin(); it != _Tower.end(); it++)
    {

            for(std::list<CEnemy>::iterator itEnemy = _Enemy.begin(); itEnemy != _Enemy.end(); itEnemy++)
            {
                if(itEnemy->getRect().Intersects(it->getRectField()))
                {

                     if(it->canShoot())
                         _Shoot.push_back(it->shoot(itEnemy->getPos()));
                }
            }

    }
}
//-------------------------------------------------------------------
void CDefences::shootIntersectsEnemy()
{
    for(std::list<CShoot>::iterator itShoot=_Shoot.begin(); itShoot != _Shoot.end(); itShoot++)
    {
        for(std::list<CEnemy>::iterator itEnemy = _Enemy.begin(); itEnemy != _Enemy.end(); itEnemy++)
        {
            if(itShoot->getRect().Intersects(itEnemy->getRect()))
            {
                itEnemy->hit(itShoot->getFire());
                itShoot = _Shoot.erase(itShoot);
                if(itEnemy->haveLive()==false)
                {
                    _IMoney += 100;
                    itEnemy = _Enemy.erase(itEnemy);
                }
            }
        }
    }
}
//-------------------------------------------------------------------
void CDefences::createEnemy()
{
    int j=0;
    for(int i=10;i>0;i--,j++)
    {
        _Enemy.push_back(CEnemy(0-(40)*i,300,5+_IWave*5, *this));
    }
}
//-------------------------------------------------------------------
void CDefences::drawInfoPanel()
{
    std::stringstream tmp;

    tmp << "Money: " << _IMoney;
    _SMoney.SetText(tmp.str());

    tmp.str("");
    tmp << "Wave: " << _IWave;
    _SWave.SetText(tmp.str());

    if(10 - _Wave.GetElapsedTime()>0)
    {
        tmp.str("");
        tmp << "Naechste Wave in: " << 10  - _Wave.GetElapsedTime();
        _SWaveTime.SetText(tmp.str());
    }
    else
        _SWaveTime.SetText("");

    this->Draw(_Panel);
    this->Draw(_SMoney);
    this->Draw(_SWave);
    this->Draw(_SWaveTime);

}
//-------------------------------------------------------------------
void CDefences::focus()
{
    const sf::Input &input = this->GetInput();
    sf::Rect<float> mouse(input.GetMouseX()-10,input.GetMouseY()-10,input.GetMouseX(),input.GetMouseY());
    for(std::list<CTower>::iterator it = _Tower.begin(); it != _Tower.end(); it++ )
    {
        if(mouse.Intersects(it->getRectTower()))
        {
            _itFocus = it;
            _focus = true;
            return;
        }
    }
    _focus = false;
}
//-------------------------------------------------------------------
void CDefences::updateTower()
{
    if(_IMoney - 500 >=0)
    {
        _IMoney -= 500;
        _itFocus->upDate();
    }
}
//-------------------------------------------------------------------
void CDefences::eventHandling()
{
    sf::Event event;
    while(this->GetEvent(event))
    {
        if(event.Type == sf::Event::Closed)
            this->Close();
        else if(event.Type == sf::Event::KeyPressed)
        {
            if(event.Key.Code == sf::Key::Escape)
                this->Close();
            else if(event.Key.Code == sf::Key::S)
            {
                _focus = false;
                if(_GameStatus == build)
                    _GameStatus = play;
                else
                    _GameStatus = build;
            }
            else if(event.Key.Code == sf::Key::F1)
            {
                 if(_focus == true)
                    this->updateTower();
            }
            else if(event.Key.Code == sf::Key::R)
            {
                if(_focus == true)
                {
                    _itFocus = _Tower.erase(_itFocus);
                    _focus = false;
                }
            }
        }
        else if(event.Type == sf::Event::MouseButtonPressed)
        {
            if(_GameStatus == build)
            {
                this->buildTower();
                _focus = false;
            }
            else if(_GameStatus == play)
            {
                this->focus();
            }
        }
    }

}
