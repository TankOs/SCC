#include "CTower.hpp"
#include "iostream"
#include <math.h>
#include "CDefences.hpp"
CTower::CTower(CDefences &App_):App(App_)
{
    _Tower = sf::Shape::Rectangle(0,0,30,30,sf::Color(255,255,0));
    _Field = sf::Shape::Rectangle(0,0,170,170,sf::Color(100,100,100,200));
    _Tower.Move(70,70);
    _Tower.Move(190,30);
    _Field.Move(190,30);
    _Fire = 10;
    _Level = 1;
    _rate.Reset();
}
//-------------------------------------------------------------------
void CTower::draw(sf::RenderWindow &App)
{
    App.Draw(_Field);
    App.Draw(_Tower);

}
//-------------------------------------------------------------------
sf::Rect<float> CTower::getRectField()
{
    return sf::Rect<float>(_Field.GetPosition().x,_Field.GetPosition().y,_Field.GetPosition().x+170,_Field.GetPosition().y+170);
}
//-------------------------------------------------------------------
void CTower::setPos(int x, int y)
{
    _Field.SetPosition(x,y);
    _Tower.SetPosition(x,y);
    _Field.Move(-70,-70);
}
//-------------------------------------------------------------------
sf::Rect<float> CTower::getRectTower()
{
    return sf::Rect<float>(_Tower.GetPosition().x,_Tower.GetPosition().y,_Tower.GetPosition().x+30,_Tower.GetPosition().y+30);
}
//-------------------------------------------------------------------
void CTower::setY(int y)
{
    _Tower.SetY(y-30);
    _Field.SetY(y-100);
}
//-------------------------------------------------------------------
CShoot CTower::shoot(sf::Vector2f posEnemy)
{
    sf::Vector2f v;
    v.x = posEnemy.x - this->_Tower.GetPosition().x;
    v.y = posEnemy.y - this->_Tower.GetPosition().y;

    double lenght = sqrt(v.x*v.x + v.y*v.y);
    v.x = v.x/lenght;
    v.y = v.y/lenght;

    _rate.Reset();
    return CShoot(this->_Tower.GetPosition().x, this->_Tower.GetPosition().y,_Fire,v,App);
}
//-------------------------------------------------------------------
bool CTower::canShoot()
{
    if(_rate.GetElapsedTime()>1)
        return true;
    else
        return false;
}
//-------------------------------------------------------------------
void CTower::drawTower()
{
    App.Draw(this->_Tower);
}
//-------------------------------------------------------------------
void CTower::upDate()
{
    _Fire +=5;
}
