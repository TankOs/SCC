#include "CMap.hpp"

CMap::CMap(CDefences &App_):App(App_)
{
    _way = sf::Shape::Rectangle(0,260,800,340,sf::Color(0,255,0));
}
//-------------------------------------------------------------------
void CMap::draw(sf::RenderWindow &App)
{
    App.Draw(_way);
}
//-------------------------------------------------------------------
bool CMap::intersects(sf::Rect<float> tower)
{
    return tower.Intersects(this->getRect());
}
//-------------------------------------------------------------------
sf::Rect<float> CMap::getRect()
{
    return sf::Rect<float>(0,260,800,340);
}
//-------------------------------------------------------------------
void CMap::setTower(CTower &tower)
{
    sf::Rect<float> t = tower.getRectTower();
    if(t.Bottom < 300)
        tower.setY(260);
    else
        tower.setY(340+30);
}
