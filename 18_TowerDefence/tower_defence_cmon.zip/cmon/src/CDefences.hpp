#ifndef CDEFENCES_HPP
#define CDEFENCES_HPP

#include <SFML/Graphics.hpp>
#include <string>
#include <list>
#include "CTower.hpp"
#include "CEnemy.hpp"
#include "CMap.hpp"
#include "CShoot.hpp"

enum EGameStatus{wait, build, play,wave};

class CDefences: public sf::RenderWindow
{
public:
    CDefences(sf::VideoMode vMode,const std::string &title);
    void run();
protected:
    bool _focus;
    std::list<CTower>::iterator _itFocus;
    std::list<CTower> _Tower;
    std::list<CShoot> _Shoot;
    std::list<CEnemy> _Enemy;
    CMap _map;
    CTower _tmpTower;
    EGameStatus _GameStatus;
    EGameStatus _GameStatus2;
    int _IMoney;
    int _IWave;
    sf::String _SMoney;
    sf::String _SWave;
    sf::String _SWaveTime;
    sf::Shape _Panel;
    sf::Clock _Wave;
    void Tower();
    void buildTower();
    void enemyIntersectsTower();
    void shootIntersectsEnemy();
    void createEnemy();
    void drawInfoPanel();
    void focus();
    void updateTower();
    void eventHandling();
};

#endif // CDEFENCES_HPP
