#ifndef CMAP_HPP
#define CMAP_HPP

#include <SFML/Graphics.hpp>
#include "CTower.hpp"
class CDefences;

class CMap
{
protected:
    sf::Shape _way;
    sf::Rect<float> getRect();
    CDefences &App;
public:
    CMap(CDefences &App_);
    void draw(sf::RenderWindow &App);
    bool intersects(sf::Rect<float> tower);
    void setTower(CTower &tower);
};

#endif // CMAP_HPP
