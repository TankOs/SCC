#include "CEnemy.hpp"
#include <iostream>
#include <SFML/Graphics.hpp>
#include "CDefences.hpp"

CEnemy::CEnemy(int x, int y, int live, CDefences &App_):App(App_)
{
    radius = 15;
    this->live = live;
    _enemy = sf::Shape::Circle(0,0,15,sf::Color(0,0,255));
    _enemy.Move(x,y);
    _RV.x=50;
    _RV.y=0;
}
//-------------------------------------------------------------------
void CEnemy::draw(sf::RenderWindow &App)
{
    App.Draw(_enemy);
}
//-------------------------------------------------------------------
sf::Rect<float> CEnemy::getRect()
{
    return sf::Rect<float>(_enemy.GetPosition().x-radius,_enemy.GetPosition().y-radius,_enemy.GetPosition().x+radius,_enemy.GetPosition().y+radius);
}
//-------------------------------------------------------------------
void CEnemy::move()
{

    _enemy.Move(_RV.x*App.GetFrameTime(),_RV.y*App.GetFrameTime());
}
//-------------------------------------------------------------------
void CEnemy::hit(int fire)
{
    this->live = live -fire;
}
//-------------------------------------------------------------------
bool CEnemy::haveLive()
{
    if(live>0)
        return true;
    else
        return false;
}
//-------------------------------------------------------------------
sf::Vector2f CEnemy::getPos()
{
    return this->_enemy.GetPosition();
}
//-------------------------------------------------------------------
void CEnemy::setPosition(int x, int y)
{
    this->_enemy.SetPosition(x,y);
}
