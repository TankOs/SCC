#include "CShoot.hpp"
#include <iostream>
#include "CDefences.hpp"
CShoot::CShoot(int x, int y,int fire, sf::Vector2f RV, CDefences &App_):App(App_)
{
    _Shoot = sf::Shape::Circle(0,0,10,sf::Color(255,0,0));
    _Shoot.SetPosition(x,y);
    _RV = RV;
    _fire = fire;
}
//-------------------------------------------------------------------
void CShoot::move()
{
    _Shoot.Move(_RV.x*300*App.GetFrameTime(),_RV.y*300*App.GetFrameTime());
}
//-------------------------------------------------------------------
void CShoot::draw(sf::RenderWindow &App)
{
    App.Draw(_Shoot);
}
//-------------------------------------------------------------------
sf::Rect<float> CShoot::getRect()
{
    return sf::Rect<float>(this->_Shoot.GetPosition().x,this->_Shoot.GetPosition().y,this->_Shoot.GetPosition().x+10,this->_Shoot.GetPosition().y+10);
}
//-------------------------------------------------------------------
int CShoot::getFire()
{
    return _fire;
}

