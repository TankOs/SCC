#include "CDefences.hpp"
#include <SFML/Graphics.hpp>

int main(int argc, char *argv[])
{
    CDefences game(sf::VideoMode(800,600),"test");
    game.run();
}
