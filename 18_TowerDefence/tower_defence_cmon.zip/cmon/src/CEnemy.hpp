#ifndef CENEMY_HPP
#define CENEMY_HPP

#include <SFML/Graphics.hpp>
class CDefences;

class CEnemy
{
protected:
    sf::Shape _enemy;
    int radius;
    int live;
    sf::Vector2f _RV;
    CDefences &App;
public:
    CEnemy(int x,int y,int live,CDefences &App_);
    void draw(sf::RenderWindow &App);
    sf::Rect<float> getRect();
    void move();
    void hit(int fire);
    bool haveLive();
    sf::Vector2f getPos();
    void setPosition(int x, int y);
};

#endif // CENEMY_HPP
