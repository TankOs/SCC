//////////////////////////////////////////////////////////////
// Highscore Manager Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#include "HighscoreManager.h"

CHighscoreManager *HighscoreManager = NULL;

//////////////////////////////////////////////////////////////
CHighscoreManager::CHighscoreManager(const string &sFile)
{
	DEBUG_PRINTF(("CHighscoreManager::Construct(%x)",this));

	this->ClearList();
	this->LoadFile(sFile);
}

//////////////////////////////////////////////////////////////
CHighscoreManager::~CHighscoreManager()
{
	DEBUG_PRINTF(("CHighscoreManager::Destruct(%x)",this));

	this->SaveFile(this->psFile);
}

//////////////////////////////////////////////////////////////
int  CHighscoreManager::GetEntryCount()
{
	for (int i=0; i < this->MAXENTRYCOUNT; ++i)
		if (!this->plEntryList[i].name[0])
			return (i+1);

	return 0;
}

//////////////////////////////////////////////////////////////
bool CHighscoreManager::GetEntry(const int &idx, string &name, unsigned int &points)
{
	if (idx < this->MAXENTRYCOUNT)
	{
		if (this->plEntryList[idx].name[0])
		{
			name   = string(this->plEntryList[idx].name, MAXNAMELEN);
			points = this->plEntryList[idx].points;
			return true;
		}
	}

	return false;
}

//////////////////////////////////////////////////////////////
int CHighscoreManager::CheckHighscore(const unsigned int score)
{
	for (int i=0; i < this->MAXENTRYCOUNT; ++i)
	{
		if (this->plEntryList[i].name[0])
		{
			if (this->plEntryList[i].points < score)
				return (i+1);
		}
		else
			return (i+1);
	}

	return 0;
}

//////////////////////////////////////////////////////////////
int CHighscoreManager::AddHighscore(const string &name, const unsigned int score)
{
	int rang = this->CheckHighscore(score);
	if (rang)
	{
		for(int i=this->MAXENTRYCOUNT-1; i >= rang; --i)
			this->plEntryList[i] = this->plEntryList[i-1];

		int len = sizeof(char) * MAXNAMELEN;
		if (int(name.length() * sizeof(char)) < len)
			len = int(name.length() * sizeof(char));

		memcpy(this->plEntryList[rang-1].name, name.c_str(), len);
		this->plEntryList[rang-1].points = score;
	}
	return rang;
}

//////////////////////////////////////////////////////////////
void CHighscoreManager::ClearList()
{
	memset(this->plEntryList, 0, sizeof(this->plEntryList));
}

//////////////////////////////////////////////////////////////
bool CHighscoreManager::Loaded()
{
	return this->pbLoaded;
}

//////////////////////////////////////////////////////////////
bool CHighscoreManager::LoadFile(const string &sFile)
{
	fstream file(sFile.c_str(), ios::in | ios::binary);
	if (!file.fail())
	{
		char			cMagicID[4];
		unsigned int	iCount;
		unsigned int	iSize;

		// Get File Size
		file.seekg(0, ios::end);
		iSize = (unsigned int)file.tellg();
		file.seekp(0);

		// Check Data
		file >> cMagicID;
		if (!memcmp(cMagicID, "CHL",3))
		{
			file.read((char*)&iCount, sizeof(iCount));
			if (iSize == 3 + sizeof(iCount) + sizeof(this->plEntryList))
			{
				file.read((char*)&this->plEntryList, sizeof(this->plEntryList));
				this->pbLoaded = true;
			}
			else
				this->pbLoaded = false;
		}
		else
			this->pbLoaded = false;
	}
	else
	{
		DEBUG_PRINTF(("CHighscoreManager::LoadFile(\"%s\") not found",sFile.c_str()));
		this->pbLoaded = false;
	}

	this->psFile = sFile;
	return this->pbLoaded;
}

//////////////////////////////////////////////////////////////
bool CHighscoreManager::SaveFile(const string &sFile)
{
	fstream file(sFile.c_str(), ios::out | ios::binary);

	if (!file.fail())
	{
		int iMaxEntryCount = this->MAXENTRYCOUNT;
		file << "CHL";
		file.write((char*)&iMaxEntryCount,		sizeof(iMaxEntryCount));
		file.write((char*)&this->plEntryList,   sizeof(this->plEntryList));
		return true;
	}

	return false;
}
