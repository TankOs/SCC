//////////////////////////////////////////////////////////////
// Information Scene Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#include "InfoScene.h"
#include "MainScene.h"
#include "MaterialManager.h"

//////////////////////////////////////////////////////////////
CInfoScene::CInfoScene(sf::RenderWindow &Parent) : CBasicScene(Parent)
{
	DEBUG_PRINTF((" CInfoScene::Constructor(%x)",this));

	// setup working variables
	this->iAnimationAction = -1;
	this->fAnimationIndex  = 0.0f;

	// setup background sprite
	{
		this->spriteBackground.SetImage(Materials->imgBackground);
		this->spriteOverlay	  .SetImage(Materials->imgOverlay);
		this->spriteLogo	  .SetImage(Materials->imgLogo);
		this->spriteLogo.SetPosition((Parent.GetWidth() - this->spriteLogo.GetSubRect().GetWidth()) / 2.f, 50.f);
	}

	// setup menu sprites
	{
		this->spriteMenuBack.SetImage(Materials->imgMenuItems);
		this->SetSpriteMenuIndex(this->spriteMenuBack, 8);
		this->spriteMenuBack.SetPosition((Parent.GetWidth() - this->spriteMenuBack.GetSubRect().GetWidth()) / 2.f, 520.f);

		this->spriteTitle.SetImage(Materials->imgMenuItems);
		this->SetSpriteMenuIndex(this->spriteTitle, 4+1);
		this->spriteTitle.SetPosition((Parent.GetWidth() - this->spriteTitle.GetSubRect().GetWidth()) / 2.f, 100.f);
	}
}

//////////////////////////////////////////////////////////////
CInfoScene::~CInfoScene(void)
{
	DEBUG_PRINTF((" CInfoScene::Destructor(%x)",this));
}

//////////////////////////////////////////////////////////////
CBasicScene* CInfoScene::EventHandler(sf::Event &event)
{
	int			 iAction = 0;
	sf::Vector2i mousepos;

	// check mouse event
	if (event.Type == sf::Event::MouseMoved)
	{
		iAction = 1;
		mousepos = sf::Vector2i(event.MouseMove.X, event.MouseMove.Y);
	}
	else
	if ((event.Type == sf::Event::MouseButtonPressed) && (event.MouseButton.Button == sf::Mouse::Left))
	{
		iAction = 2;
		mousepos = sf::Vector2i(event.MouseButton.X, event.MouseButton.Y);
	}

	// process event
	if (iAction > 0)
	{
		int state;
		int pushButton = 0;

		// determinate button states
		state = this->isPointOverSprite(mousepos, this->spriteMenuBack);
		this->SetSpriteMenuIndex(this->spriteMenuBack, 8 + state);
		if (state) pushButton = 1;

		// action selector switch
		if ((iAction > 1) && (pushButton>0))
		{
			Materials->sndClick.Play();
			switch (pushButton)
			{
				case 1:								// Zur�ck!
					this->iAnimationAction = 1;
					this->fAnimationIndex = 255.0f;
					this->iSelected = pushButton;
				break;
				default:
					DEBUG_PRINTF((" CInfoScene::EventHandler(int) unknown Action id:%d",pushButton));
			}
		}

	}
	return NULL;
}

//////////////////////////////////////////////////////////////
CBasicScene* CInfoScene::Render()
{
	CBasicScene *NewScene = NULL;
	this->ParentWindow->Clear();


	switch (this->iAnimationAction)
	{
		case -1:							// < scene start, fade in Animation
			this->fAnimationIndex += 5.f;
			if (this->fAnimationIndex > 255.0f)
				this->fAnimationIndex = 255.0f;

			this->spriteTitle	.SetColor(sf::Color(255,255,255, sf::Uint8(this->fAnimationIndex)));
			this->spriteMenuBack.SetColor(sf::Color(255,255,255, sf::Uint8(this->fAnimationIndex)));
		break;
		case 1:								// < Menu select, move out animation
		{
			const float STEP   = -20.f;

			// fade out title and score items
			{
				this->fAnimationIndex -= 25.f;
				if (this->fAnimationIndex < 0.f)
					this->fAnimationIndex = 0.f;
				this->spriteTitle.SetColor(sf::Color(255,255,255, sf::Uint8(this->fAnimationIndex)));
			}
			
			// move menu items out
			this->spriteMenuBack.Move(STEP, 0.f);
			if (this->spriteMenuBack.GetPosition().x < 0.f)
			{
				switch (this->iSelected)
				{
					case 1:		//Back
						NewScene = new CMainScene(*(this->ParentWindow));
						break;
					default:
						DEBUG_PRINTF(("CHighscoreScene::Render() unknown Action id:%d",this->iSelected));
				}
			}
		}
	}

	// draw background
	this->ParentWindow->Draw(this->spriteBackground);
	this->ParentWindow->Draw(this->spriteOverlay);
	this->ParentWindow->Draw(this->spriteLogo);

	// draw title
	this->ParentWindow->Draw(this->spriteTitle);

	// draw back menu
	this->ParentWindow->Draw(this->spriteMenuBack);

	return NewScene;
}