//////////////////////////////////////////////////////////////
// Material Manager Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#include "MaterialManager.h"
CMaterialManager *Materials = NULL;

//////////////////////////////////////////////////////////////
#define MatLoadFromFile(obj, file) if(obj.LoadFromFile(file)) DEBUG_PRINTF(("  Loading \"%s\" succesfully",file))
#define MatOpenFromFile(obj, file) if(obj.OpenFromFile(file)) DEBUG_PRINTF(("  Loading \"%s\" succesfully",file))

	//////////////////////////////////////////////////////////////
	CMaterialManager::CMaterialManager(void)
	{
		DEBUG_PRINTF(("CMaterialManager::Construct(%x)",this));

		// loading and setup images
		MatLoadFromFile(imgBackground, "media/background_a.jpg");
		MatLoadFromFile(imgOverlay, "media/background_b.png");
		MatLoadFromFile(imgLogo, "media/logo.png");
		MatLoadFromFile(imgMenuItems, "media/menuitems.png");
		MatLoadFromFile(imgField, "media/field.png");

		imgBackground.SetSmooth(false);
		imgOverlay   .SetSmooth(false);
		imgLogo		 .SetSmooth(false);
		imgMenuItems .SetSmooth(false);
		imgField	 .SetSmooth(false);

		// loading and setup musik/sounds
		MatOpenFromFile(musBackground, "media/background_m.ogg");
		MatLoadFromFile(sndBufClick, "media/click.wav");

		musBackground.SetLoop(true);
		sndClick.SetBuffer(sndBufClick);
	}

	//////////////////////////////////////////////////////////////
	CMaterialManager::~CMaterialManager(void)
	{
		DEBUG_PRINTF(("CMaterialManager::Destruct(%x)",this));

		// nothing to do, because all objects are "semistatic" and will be released automatically, if this class will be destroyed
	}

//////////////////////////////////////////////////////////////
#undef MatLoadFromFile
#undef MatOpenFromFile