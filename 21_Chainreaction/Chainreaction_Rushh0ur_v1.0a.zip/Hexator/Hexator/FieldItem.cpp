//////////////////////////////////////////////////////////////
// Field Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#include "FieldItem.h"
#include "BasicScene.h"
#include "MaterialManager.h"

#include <iostream>
#include <sstream>
#include <string>
using namespace std;

//////////////////////////////////////////////////////////////
CFieldItem::CFieldItem(void)
{
	this->SetImage(Materials->imgField);
	this->SetCenter(Materials->imgField.GetWidth()/2.f, 23.f);

	this->iEffekt   = 0;
	this->iIsValue  = 0;
	this->iMustValue= 0;
	this->iMember	= 0;
	this->bHidden	= false;

	this->strText.SetSize(24.f);

	this->UpdateState();
	this->SetImageIndex(0);
}

//////////////////////////////////////////////////////////////
CFieldItem::~CFieldItem(void)
{
					
}

//////////////////////////////////////////////////////////////
void CFieldItem::SetImageIndex(int iIndex)
{
	sf::IntRect tRect(	0, 
						2*46+iIndex*46, 
						Materials->imgField.GetWidth(), 
						2*46+iIndex*46+46
					 );
	this->SetSubRect(tRect);
}

//////////////////////////////////////////////////////////////
void CFieldItem::Paint(sf::RenderWindow &RenderWindow)
{
	RenderWindow.Draw(*this);
	RenderWindow.Draw(this->strText);
}

//////////////////////////////////////////////////////////////
void CFieldItem::InitData(int iLevel)
{
	switch (iLevel)
	{
		case 1:
				this->bHidden    = false;
				this->iEffekt	 = 0;
			break;
		case 2:
				this->bHidden    = false;
				this->iEffekt	 = sf::Randomizer::Random(0, 100) > 60 ?		sf::Randomizer::Random(-9, 9)		: 0; 
			break;
		case 3:
				this->bHidden    = sf::Randomizer::Random(0, 100) > 80;
				this->iEffekt	 = sf::Randomizer::Random(0, 100) > 60 ?		sf::Randomizer::Random(-20, 20)		: 0; 
			break;
	}

	this->UpdateState();	
}


//////////////////////////////////////////////////////////////
void CFieldItem::UpdateState()
{

	if (this->bHidden)
		this->strText.SetText("?");
	else
	{
		if (this->iEffekt)
		{
			ostringstream stringStream;
			stringStream << this->iEffekt;
			this->strText.SetText(string(stringStream.str()));
		}
		else
			this->strText.SetText("");
	}


	sf::Vector2f pos = (*this).GetPosition();
	pos.x -= this->strText.GetRect().GetWidth()/2;
	pos.y -= this->strText.GetRect().GetHeight() * 0.6f;
	this->strText.SetPosition(pos);
}

//////////////////////////////////////////////////////////////
bool CFieldItem::IsOver(sf::Vector2i &Position)
{
	// must be optimized via mask check
	return CBasicScene::isPointOverSprite(Position, *this);
}