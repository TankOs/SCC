//////////////////////////////////////////////////////////////
// Field Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#ifndef __FIELDITEM_H__
#define __FIELDITEM_H__

#include "main.h"

class CFieldItem : public sf::Sprite
{
private:
	sf::String	strText;
	int			iMember;
	int			iEffekt;
	int			iIsValue;
	int			iMustValue;
	bool		bHidden;
private:
	void SetImageIndex(int iIndex);
public:
	CFieldItem(void);
	~CFieldItem(void);
	void Paint(sf::RenderWindow &RenderWindow);
	void InitData(int iLevel);
	void UpdateState();
	bool IsOver(sf::Vector2i &Position);
};

#endif // __FIELDITEM_H__
