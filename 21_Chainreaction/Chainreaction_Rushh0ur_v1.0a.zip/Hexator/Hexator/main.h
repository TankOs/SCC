//////////////////////////////////////////////////////////////
// Application Entry Point Unit
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////

#ifndef __MAIN_H__
#define __MAIN_H__

	// C++ Standart Library
	#include <iostream>
	#include <string>

	// C Standart Library
	#include <time.h>

	// SFML Library
	#include <SFML/System.hpp>
	#include <SFML/Graphics.hpp>
	#include <SFML/Audio.hpp>

    ////////////////////////////////////////////////////////////
    /// Application Entry Point
	///
    /// \return		Status code
	///
    ////////////////////////////////////////////////////////////
	int main();

    ////////////////////////////////////////////////////////////
    /// Application Debug Output Routine
	///
    /// \param format	format string, see printf for details
	/// \param ...		Extended parameters, depends on format string
	///
    ////////////////////////////////////////////////////////////
	void debug_printf(const char *format, ...);

	#if (!defined(_DEBUG))
		#define DEBUG_PRINTF(arg)
		#define PAUSE()
	#else
		#define DEBUG_PRINTF(arg) debug_printf arg
		#define PAUSE() system("PAUSE")
	#endif

#endif // __MAIN_H__