//////////////////////////////////////////////////////////////
// Basic Scene Manager Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#include "BasicScene.h"
#include "MaterialManager.h"

//////////////////////////////////////////////////////////////
CBasicScene::CBasicScene(sf::RenderWindow &Parent)
{
	DEBUG_PRINTF(("CBasicScene::Construct(%x)",this));
	this->ParentWindow = &Parent;
}

//////////////////////////////////////////////////////////////
CBasicScene::~CBasicScene()
{
	DEBUG_PRINTF(("CBasicScene::Destructor(%x)",this));
}

//////////////////////////////////////////////////////////////
CBasicScene* CBasicScene::EventHandler(sf::Event &event)
{
	return NULL;
}

//////////////////////////////////////////////////////////////
CBasicScene* CBasicScene::Render()
{
	this->ParentWindow->Clear(sf::Color(0,127,255));

	sf::String  Text("CBasicScene Class", sf::Font::GetDefaultFont(), 30.0f);
	Text.SetPosition((this->ParentWindow->GetWidth() -  Text.GetRect().GetWidth()) / 2.0f, 20.0f);
	this->ParentWindow->Draw(Text);

	Text.SetText("Warning: Don't use CBasicScene directly.");
	Text.SetPosition((this->ParentWindow->GetWidth() -  Text.GetRect().GetWidth()) / 2.0f, 80.0f);
	this->ParentWindow->Draw(Text);

	return NULL;
}

//////////////////////////////////////////////////////////////
void CBasicScene::SetSpriteMenuIndex(sf::Sprite &Sprite, int Index)
{
	sf::IntRect iRect(
						0, 
						Index*34, 
						Materials->imgMenuItems.GetWidth(), 
						Index*34+34
					 );
	Sprite.SetSubRect(iRect);
}

//////////////////////////////////////////////////////////////
bool CBasicScene::isPointOverSprite(const sf::Vector2i Position, const sf::Sprite &Sprite)
{
	if (!(&Sprite))  
	{
		DEBUG_PRINTF(("Error in isPointOverSprite(Vector2i, Sprite), Sprite is Zero"));
		return false;
	}
   return   (Position.x < Sprite.GetPosition().x + Sprite.GetSize().x) && (Sprite.GetPosition().x < Position.x) &&
			(Position.y < Sprite.GetPosition().y + Sprite.GetSize().y) && (Sprite.GetPosition().y < Position.y);
}