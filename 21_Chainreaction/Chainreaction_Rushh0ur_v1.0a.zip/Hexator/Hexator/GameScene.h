//////////////////////////////////////////////////////////////
// Game Scene Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#ifndef __GAMESCENE_H__
#define __GAMESCENE_H__

#include "BasicScene.h"
#include "FieldItem.h"

const int FIELD_WIDTH  = 10;
const int FIELD_HEIGHT = 18;

class CGameScene : public CBasicScene
{
private:
	sf::Sprite spriteBackground;
	sf::Sprite spriteLogo;

	sf::String strPlayerScore;
	sf::String strCompScore;
	sf::String strLives;

	CFieldItem *matField[FIELD_WIDTH][FIELD_HEIGHT];
	CFieldItem  nextItems[3];

	int			iFieldCount;
	int			iLives;
	int			iLevel;

	int		   iAnimationAction;
	float	   fAnimationIndex;

	long	   lIsPlayerScore;
	long	   lMustPlayerScore;
	long	   lIsCompScore;
	long	   lMustCompScore;

private:
	void		BuildField();
	void		DestroyField();
public:
	CGameScene(sf::RenderWindow &Parent);
	virtual ~CGameScene(void);
	virtual CBasicScene* EventHandler(sf::Event &event);
	virtual CBasicScene* Render();
};

#endif //__GAMESCENE_H__