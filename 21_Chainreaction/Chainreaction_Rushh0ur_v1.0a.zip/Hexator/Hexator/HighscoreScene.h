//////////////////////////////////////////////////////////////
// Highscore Scene Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#ifndef __HIGHSCORESCENE_H__
#define __HIGHSCORESCENE_H__

#include "BasicScene.h"
#include "HighscoreManager.h"

class CHighscoreScene : public CBasicScene
{
private:
	sf::Sprite spriteBackground;
	sf::Sprite spriteOverlay;
	sf::Sprite spriteLogo;
	sf::Sprite spriteTitle;
	sf::Sprite spriteMenuBack;
	int		   iAnimationAction;
	float	   fAnimationIndex;
	int		   iSelected;
	sf::String strPlayerNames[CHighscoreManager::MAXENTRYCOUNT];
	sf::String strPlayerPoints[CHighscoreManager::MAXENTRYCOUNT];
public:
	CHighscoreScene(sf::RenderWindow &Parent);
	virtual ~CHighscoreScene(void);
	virtual CBasicScene* EventHandler(sf::Event &event);
	virtual CBasicScene* Render();
};

#endif //__HIGHSCORESCENE_H__