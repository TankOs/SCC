//////////////////////////////////////////////////////////////
// MainMenu Scene Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#include "MainScene.h"
#include "GameScene.h"
#include "InfoScene.h"
#include "HighscoreScene.h"
#include "MaterialManager.h"

//////////////////////////////////////////////////////////////
CMainScene::CMainScene(sf::RenderWindow &Parent) : CBasicScene(Parent)
{
	DEBUG_PRINTF((" CMainScene::Constructor(%x)",this));

	// setup working variables
	this->iAnimationAction = -1;
	this->fAnimationIndex  = 0.0f;

	// setup background sprite
	{
		this->spriteBackground.SetImage(Materials->imgBackground);
		this->spriteOverlay	  .SetImage(Materials->imgOverlay);
		this->spriteLogo	  .SetImage(Materials->imgLogo);
		this->spriteLogo.SetPosition((Parent.GetWidth() - this->spriteLogo.GetSubRect().GetWidth()) / 2.f, 50.f);
	}

	// setup menu sprites
	{
		float pos   = 90.0f;
		float pstep = 75.0f;

		this->spriteMenuStart.SetImage(Materials->imgMenuItems);
		this->SetSpriteMenuIndex(this->spriteMenuStart, 0);
		this->spriteMenuStart.SetPosition((Parent.GetWidth() - this->spriteMenuStart.GetSubRect().GetWidth()) / 2.f, pos += pstep);

		this->spriteMenuHighscore.SetImage(Materials->imgMenuItems);
		this->SetSpriteMenuIndex(this->spriteMenuHighscore, 2);
		this->spriteMenuHighscore.SetPosition((Parent.GetWidth() - this->spriteMenuHighscore.GetSubRect().GetWidth()) / 2.f, pos += pstep);

		this->spriteMenuInfo.SetImage(Materials->imgMenuItems);
		this->SetSpriteMenuIndex(this->spriteMenuInfo, 4);
		this->spriteMenuInfo.SetPosition((Parent.GetWidth() - this->spriteMenuInfo.GetSubRect().GetWidth()) / 2.f, pos += pstep);
		
		this->spriteMenuClose.SetImage(Materials->imgMenuItems);
		this->SetSpriteMenuIndex(this->spriteMenuClose, 6);
		this->spriteMenuClose.SetPosition((Parent.GetWidth() - this->spriteMenuClose.GetSubRect().GetWidth()) / 2.f, pos += pstep);
	}
}

//////////////////////////////////////////////////////////////
CMainScene::~CMainScene()
{
	DEBUG_PRINTF((" CMainScene::Destructor(%x)",this));
}

//////////////////////////////////////////////////////////////
CBasicScene* CMainScene::EventHandler(sf::Event &event)
{
	int			 iAction = 0;
	sf::Vector2i mousepos;

	// check mouse event
	if (event.Type == sf::Event::MouseMoved)
	{
		iAction = 1;
		mousepos = sf::Vector2i(event.MouseMove.X, event.MouseMove.Y);
	}
	else
	if ((event.Type == sf::Event::MouseButtonPressed) && (event.MouseButton.Button == sf::Mouse::Left))
	{
		iAction = 2;
		mousepos = sf::Vector2i(event.MouseButton.X, event.MouseButton.Y);
	}
	
	// process event
	if (iAction > 0)
	{
		int state;
		int pushButton = 0;

		// determinate button states
		state = this->isPointOverSprite(mousepos, this->spriteMenuStart);
		this->SetSpriteMenuIndex(this->spriteMenuStart, 0 + state);
		if (state) pushButton = 1;

		state = this->isPointOverSprite(mousepos, this->spriteMenuHighscore);
		this->SetSpriteMenuIndex(this->spriteMenuHighscore, 2 + state);
		if (state) pushButton = 2;

		state = this->isPointOverSprite(mousepos, this->spriteMenuInfo);
		this->SetSpriteMenuIndex(this->spriteMenuInfo, 4 + state);
		if (state) pushButton = 3;

		state = this->isPointOverSprite(mousepos, this->spriteMenuClose);
		this->SetSpriteMenuIndex(this->spriteMenuClose, 6 + state);
		if (state) pushButton = 4;

		// action selector switch
		if ((iAction > 1) && (pushButton>0))
		{
			Materials->sndClick.Play();
			switch (pushButton)
			{
				case 1:								// Play!
				case 2:								// Highscore
				case 3:								// Information
					this->iAnimationAction = 1;
					this->iSelected = pushButton;
				break;
				case 4:								// Exit
					this->clkAnimation.Reset();
					this->iAnimationAction = 4;
				break;
				default:
					DEBUG_PRINTF((" CMainScene::EventHandler(int) unknown Action id:%d",pushButton));
			}
		}
	}

	return NULL;
}

//////////////////////////////////////////////////////////////
CBasicScene* CMainScene::Render()
{
	CBasicScene *NewScene = NULL;

	this->ParentWindow->Clear();

	switch (this->iAnimationAction)
	{
		case -1:							// < Programm start, fade in Animation
			this->fAnimationIndex += 5.f;
			if (this->fAnimationIndex > 255.0f)
			{
				this->fAnimationIndex = 255.0f;
				this->iAnimationAction = 0;
			}

			this->spriteMenuStart	 .SetColor(sf::Color(255,255,255, sf::Uint8(this->fAnimationIndex)));
			this->spriteMenuHighscore.SetColor(sf::Color(255,255,255, sf::Uint8(this->fAnimationIndex)));
			this->spriteMenuInfo	 .SetColor(sf::Color(255,255,255, sf::Uint8(this->fAnimationIndex)));
			this->spriteMenuClose	 .SetColor(sf::Color(255,255,255, sf::Uint8(this->fAnimationIndex)));
		break;
		case 1:								// < Menu select, move out animation
		{
			const float STEP   = -20.f;
			const float MINPOS = 100.f;

			// fade out overlay
			if (this->iSelected == 1)
			{
				this->fAnimationIndex -= 5.f;
				if (this->fAnimationIndex < 0.f)
					this->fAnimationIndex = 0.f;
				this->spriteOverlay.SetColor(sf::Color(255,255,255, sf::Uint8(this->fAnimationIndex)));
			}

			// move menu items out
			this->spriteMenuClose.Move(STEP, 0.f);
			if (this->spriteMenuClose.GetPosition().x < MINPOS)
			{
				this->spriteMenuInfo.Move(STEP, 0.f);
				if (this->spriteMenuInfo.GetPosition().x < MINPOS)
				{
					this->spriteMenuHighscore.Move(STEP, 0.f);
					if (this->spriteMenuHighscore.GetPosition().x < MINPOS)
					{
						this->spriteMenuStart.Move(STEP, 0.f);
						if (this->spriteMenuStart.GetPosition().x < -20.f)
						{
							switch (this->iSelected)
							{
								case 1:		//Play!
									NewScene = new CGameScene(*(this->ParentWindow));
									break;
								case 2:		//Highscore
									NewScene = new CHighscoreScene(*(this->ParentWindow));
									break;
								case 3:		//Information
									NewScene = new CInfoScene(*(this->ParentWindow));
									break;
								default:
									DEBUG_PRINTF(("CMainScene::Render() unknown Action id:%d",this->iSelected));
							}
						}
					}
				}
			}
	
		}		
		break;								// < Close select, no animation, just play click sound and exit
		case 4:
			if (this->clkAnimation.GetElapsedTime() > 0.25f)
				this->ParentWindow->Close();
		break;
	}

	// draw background
	this->ParentWindow->Draw(this->spriteBackground);
	this->ParentWindow->Draw(this->spriteOverlay);
	this->ParentWindow->Draw(this->spriteLogo);

	// draw menu
	this->ParentWindow->Draw(this->spriteMenuStart);
	this->ParentWindow->Draw(this->spriteMenuHighscore);
	this->ParentWindow->Draw(this->spriteMenuInfo);
	this->ParentWindow->Draw(this->spriteMenuClose);

	return NewScene;
}