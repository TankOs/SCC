//////////////////////////////////////////////////////////////
// Information Scene Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#ifndef __INFOSCENE_H__
#define __INFOSCENE_H__

#include "BasicScene.h"

class CInfoScene : public CBasicScene
{
private:
	sf::Sprite spriteBackground;
	sf::Sprite spriteOverlay;
	sf::Sprite spriteLogo;
	sf::Sprite spriteTitle;
	sf::Sprite spriteMenuBack;
	int		   iAnimationAction;
	float	   fAnimationIndex;
	int		   iSelected;
public:
	CInfoScene(sf::RenderWindow &Parent);
	virtual ~CInfoScene(void);
	virtual CBasicScene* EventHandler(sf::Event &event);
	virtual CBasicScene* Render();
};

#endif //__INFOSCENE_H__