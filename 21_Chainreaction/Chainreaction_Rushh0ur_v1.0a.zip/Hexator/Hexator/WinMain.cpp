//////////////////////////////////////////////////////////////
// Windows Entry Point Wrapper
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#if ( (defined(_WIN32) || defined(__WIN32__)) && (!defined(_CONSOLE)))	
	#pragma warning( disable : 4390)

	#include <windows.h>
	#include "main.h"

    ////////////////////////////////////////////////////////////
    /// Windows Entry Point
    /// \return Status code
    ////////////////////////////////////////////////////////////
	int CALLBACK WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
	{
		return main();
	}
#endif