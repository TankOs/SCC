//////////////////////////////////////////////////////////////
// Material Manager Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#ifndef __MATERIALMANAGER_H__
#define __MATERIALMANAGER_H__

#include "main.h"

class CMaterialManager
{
public:
	sf::Image			imgBackground;
	sf::Image			imgOverlay;
	sf::Image			imgLogo;
	sf::Image			imgMenuItems;
	sf::Image			imgField;
	sf::Music			musBackground;
	sf::SoundBuffer		sndBufClick;
	sf::Sound			sndClick;
public:
	CMaterialManager(void);
	~CMaterialManager(void);
};

extern CMaterialManager *Materials;

#endif //__MATERIALMANAGER_H__