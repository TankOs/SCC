//////////////////////////////////////////////////////////////
// Game Scene Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#include "GameScene.h"
#include "MaterialManager.h"

#include <iostream>
#include <sstream>
#include <string>
using namespace std;

const string STRSCORE_POINTS(" Punkte");	
const string STRSCORE_COMP  ("CPU:  ");
const string STRSCORE_PLAYER("Spieler:  ");
const string STRSCORE_LIVES ("Versuche: ");

//////////////////////////////////////////////////////////////
CGameScene::CGameScene(sf::RenderWindow &Parent) : CBasicScene(Parent)
{
	DEBUG_PRINTF((" CGameScene::Constructor(%x)",this));

	// setup working variables
	this->fAnimationIndex  = 0.f;
	this->iAnimationAction = -1;

	this->lIsPlayerScore	= 0;
	this->lMustPlayerScore	= 0;
	this->lIsCompScore		= 0;
	this->lMustCompScore	= 0;
	this->iLives			= 3;
	this->iLevel			= 1;
	
	// setup background sprite
	{
		this->spriteBackground.SetImage(Materials->imgBackground);
		this->spriteLogo	  .SetImage(Materials->imgLogo);
		this->spriteLogo.SetPosition((Parent.GetWidth() - this->spriteLogo.GetSubRect().GetWidth()) / 2.f, 50.f);
	}

	// setup player and score strings
	{
		this->strPlayerScore.SetText(STRSCORE_PLAYER + "0" + STRSCORE_POINTS);
		this->strPlayerScore.SetColor(sf::Color(255, 0, 0, 0));
		this->strPlayerScore.SetSize(24.f);
		this->strPlayerScore.SetPosition(780.f - this->strPlayerScore.GetRect().GetWidth(),  30.f);
	
		this->strCompScore  .SetText(STRSCORE_COMP   + "0" + STRSCORE_POINTS);
		this->strCompScore  .SetColor(sf::Color(0, 0, 255, 0));
		this->strCompScore  .SetSize(24.f);
		this->strCompScore  .SetPosition(780.f - this->strCompScore.GetRect().GetWidth(),  54.f);

		this->strLives		.SetText(STRSCORE_LIVES + "3");
		this->strLives		.SetColor(sf::Color(255, 0, 0));
		this->strLives		.SetSize(24.f);
		this->strLives		.SetPosition(400.f - this->strLives.GetRect().GetWidth()/2.f,  -20.f);
	}

	// setup field options
	{
		memset(matField, 0, sizeof(CFieldItem*) * FIELD_WIDTH * FIELD_HEIGHT);
		this->BuildField();
	}
}

//////////////////////////////////////////////////////////////
CGameScene::~CGameScene(void)
{
	DEBUG_PRINTF((" CGameScene::Destructor(%x)",this));

	this->DestroyField();
}

//////////////////////////////////////////////////////////////
CBasicScene* CGameScene::EventHandler(sf::Event &event)
{
	return NULL;
}

//////////////////////////////////////////////////////////////
CBasicScene* CGameScene::Render()
{
	CBasicScene *NewScene = NULL;
	this->ParentWindow->Clear();


	// check player and cpu score
	{
		const int SCORESTEP = 2;

		// 
		if (this->lIsPlayerScore < this->lMustPlayerScore)
		{
			this->lIsPlayerScore += SCORESTEP;
			if (this->lIsPlayerScore > this->lMustPlayerScore)
				this->lIsPlayerScore = this->lMustPlayerScore;

			ostringstream streamString;
			streamString << STRSCORE_PLAYER << this->lIsPlayerScore << STRSCORE_POINTS;
			this->strPlayerScore.SetText(string(streamString.str()));
			this->strPlayerScore.SetPosition(780 - this->strPlayerScore.GetRect().GetWidth(),  30);
		}

		// cpu score
		if (this->lIsCompScore < this->lMustCompScore)
		{
			this->lIsCompScore += SCORESTEP;
			if (this->lIsCompScore > this->lMustCompScore)
				this->lIsCompScore = this->lMustCompScore;

			ostringstream streamString;
			streamString << STRSCORE_COMP << this->lIsCompScore << STRSCORE_POINTS;
			this->strCompScore.SetText(string(streamString.str()));
			this->strCompScore.SetPosition(780 - this->strCompScore.GetRect().GetWidth(),  54);
		}
	}




	// animation state
	switch (this->iAnimationAction)
	{
		case -1:							// < scene start, move game loge to left cornor
			if (this->spriteLogo.GetPosition().x > 20.f)
				this->spriteLogo.Move(-20.f, 0.f);
			else
			{
				sf::Vector2f pos = this->spriteLogo.GetPosition();
				pos.x = 20.f;
				this->spriteLogo.SetPosition(pos);
			}

			if (this->strLives.GetPosition().y < 30.f)
				this->strLives.Move(0.f, 5.f);
			else
			{
				sf::Vector2f pos = this->strLives.GetPosition();
				pos.y = 30.f;
				this->strLives.SetPosition(pos);
			}

			this->fAnimationIndex += 10.f;
			if (this->fAnimationIndex > 255.0f)
			{
				this->fAnimationIndex  = 255.f;
				this->iAnimationAction = 0;
			}
			this->strPlayerScore.SetColor(sf::Color(255, 0, 0, sf::Uint8(this->fAnimationIndex)));
			this->strCompScore  .SetColor(sf::Color(0, 0, 255, sf::Uint8(this->fAnimationIndex)));
		break;
	}




	// draw background
	this->ParentWindow->Draw(this->spriteBackground);
	this->ParentWindow->Draw(this->spriteLogo);

	// draw player and cpu stats
	this->ParentWindow->Draw(this->strPlayerScore);
	this->ParentWindow->Draw(this->strCompScore);
	this->ParentWindow->Draw(this->strLives);

	// draw field
	{
		for (int y=0; y<FIELD_HEIGHT; ++y)
			for (int x=0; x<FIELD_WIDTH; ++x)
			{
				if (matField[x][y])
					matField[x][y]->Paint(*this->ParentWindow);	
			}
	}

	return NewScene;
}

//////////////////////////////////////////////////////////////
void CGameScene::BuildField()
{
	DEBUG_PRINTF((" CGameScene::BuildField(%x)", this));

	// calcualte random map, *must be optimized
	{
		this->iFieldCount = int( float(this->iLevel) * (sf::Randomizer::Random(8.f, 12.f)) );

		sf::Vector2i pos( sf::Randomizer::Random(0, FIELD_WIDTH-1),
						  sf::Randomizer::Random(0, FIELD_HEIGHT-1)
						);

		for (int iCount = 0; iCount < this->iFieldCount; ++iCount)
		{
			//create item
			matField[pos.x][pos.y] = new CFieldItem;
			matField[pos.x][pos.y]->InitData(this->iLevel);
			
			do 
			{
				pos.x += sf::Randomizer::Random(-1, 1);
				pos.y += sf::Randomizer::Random(-1, 1);

				if (pos.x <  0)				pos.x = 0;
				if (pos.x >= FIELD_WIDTH)	pos.x = FIELD_WIDTH-1;

				if (pos.y <  0)				pos.y = 0;
				if (pos.y >= FIELD_HEIGHT)	pos.y = FIELD_HEIGHT-1;
			}
			while (matField[pos.x][pos.y]);
		}
	}


	// arange visible items
	{
		const float LEFTCORNER = 20.f + Materials->imgField.GetWidth()/2.f;
		const float TOPMCORNER = 130.f;
		
		for (int y=0; y<FIELD_HEIGHT; ++y)
			for (int x=0; x<FIELD_WIDTH; ++x)
			{
				if (matField[x][y])
				{
					float xpos = LEFTCORNER + x*(48.f+26.f);
					float ypos = TOPMCORNER + y*21.f;

					if (y%2)
						xpos += 37.f;

					matField[x][y]->SetPosition(xpos, ypos);
					matField[x][y]->UpdateState();
				}	
			}
	}

}

//////////////////////////////////////////////////////////////
void CGameScene::DestroyField()
{
	DEBUG_PRINTF((" CGameScene::DestroyField(%x)", this));

	for (int y=0; y<FIELD_HEIGHT; ++y)
		for (int x=0; x<FIELD_WIDTH; ++x)
		{
			if (matField[x][y])
				delete matField[x][y];
		}

	memset(matField, 0, sizeof(CFieldItem*) * FIELD_WIDTH * FIELD_HEIGHT);	
}