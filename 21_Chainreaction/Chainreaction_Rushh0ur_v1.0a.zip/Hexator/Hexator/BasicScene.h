//////////////////////////////////////////////////////////////
// Basic Scene Manager Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#ifndef __BASICSCENE_H__
#define __BASICSCENE_H__

#include "main.h"

class CBasicScene
{
protected:
	sf::RenderWindow *ParentWindow;
public:
	static void SetSpriteMenuIndex(sf::Sprite &Sprite, int Index);
	   
	////////////////////////////////////////////////////////////
    /// Function checks if the point is in the Sprite
	/// \param Position Vector2f Position to check
	/// \Sprite Sprite Object for check
    /// \return true if the Vector Point is inside the Sprite
    ////////////////////////////////////////////////////////////
	static bool isPointOverSprite(const sf::Vector2i Position, const sf::Sprite &Sprite);
public:
	CBasicScene(sf::RenderWindow &Parent);
	virtual ~CBasicScene(void);
	virtual CBasicScene* EventHandler(sf::Event &event);
	virtual CBasicScene* Render();
};

#endif // __BASICSCENE_H__