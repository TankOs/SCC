//////////////////////////////////////////////////////////////
// MainMenu Scene Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#ifndef __MAINSCENE_H__
#define __MAINSCENE_H__

#include "BasicScene.h"

class CMainScene : public CBasicScene
{
private:
	sf::Sprite spriteBackground;
	sf::Sprite spriteOverlay;
	sf::Sprite spriteLogo;
	sf::Sprite spriteMenuStart;
	sf::Sprite spriteMenuHighscore;
	sf::Sprite spriteMenuInfo;
	sf::Sprite spriteMenuClose;
	int		   iAnimationAction;
	int		   iSelected;
	float	   fAnimationIndex;
	sf::Clock  clkAnimation;
public:
	CMainScene(sf::RenderWindow &Parent);
	virtual ~CMainScene(void);
	virtual CBasicScene* EventHandler(sf::Event &event);
	virtual CBasicScene* Render();
};

#endif //__MAINSCENE_H__