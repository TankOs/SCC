//////////////////////////////////////////////////////////////
// Application Entry Point Unit
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#include "main.h"
#include "MainScene.h"
#include "GameScene.h"
#include "BasicScene.h"
#include "MaterialManager.h"
#include "HighscoreManager.h"

////////////////////////////////////////////////////////////
/// Function checks if a new Scene is present and destroy the old scene
///
/// \param NewScene The old game scene
/// \param OldScene The new game scene, NULL if no new scene is present
///
////////////////////////////////////////////////////////////
static void CheckNewScene(CBasicScene **NewScene, CBasicScene **OldScene);


//////////////////////////////////////////////////////////////
int main()
{
	DEBUG_PRINTF(("Initialize Application"));

	// initialize materials
	Materials = new CMaterialManager();	

	// initialize highscore data
	HighscoreManager = new CHighscoreManager("media/highscore.dat");

	// initialize render window
	sf::RenderWindow AppWindow(sf::VideoMode(800, 600), "Hexator v1.0 by Rushh0ur", sf::Style::Close);	
	AppWindow.SetFramerateLimit(60);			

	// initialize main scene
	CBasicScene	*Scene	  = new CMainScene(AppWindow);								// < main scene


		// Start the game loop
		Materials->musBackground.Play();
		while (AppWindow.IsOpened())
		{
			sf::Event	 event;
			CBasicScene *NewScene = NULL;
			 // Process events
			 
			 while (AppWindow.GetEvent(event))
			 {
				 if (event.Type == sf::Event::Closed) AppWindow.Close();	// < Check global event
				 if (Scene)	NewScene = Scene->EventHandler(event);			// < Call current scene event handle
				 CheckNewScene(&NewScene, &Scene);
			 }
	 
			 // Update the window
			 if (Scene)	NewScene = Scene->Render();
			 AppWindow.Display();
			 CheckNewScene(&NewScene, &Scene);
		}
		Materials->musBackground.Stop();


	// finalize Objects
	delete Scene;
	delete HighscoreManager;
	delete Materials;

	DEBUG_PRINTF(("Shutdown Application"));
	PAUSE();
	return 0;
}


//////////////////////////////////////////////////////////////
void debug_printf(const char *format, ...)
{
	time_t rawtime;
	tm	  *timeinfo;

	time				 ( &rawtime );
	timeinfo = localtime ( &rawtime );

	printf("%02d:%02d:%02d: ", timeinfo->tm_hour, timeinfo->tm_min, timeinfo->tm_sec);
		va_list args;
		va_start(args, format);
		vprintf(format, args);
		va_end(args);
	printf("\r\n");
}

//////////////////////////////////////////////////////////////
void CheckNewScene(CBasicScene **NewScene, CBasicScene **OldScene)
{
	if (*NewScene)
	{
		delete (*OldScene);
		*OldScene = *NewScene;
	}
}
