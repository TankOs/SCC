//////////////////////////////////////////////////////////////
// Game Scene Class
// Copyright (C) 2011 subZero aka Rushh0ur
//////////////////////////////////////////////////////////////
#include "HighscoreScene.h"
#include "MaterialManager.h"
#include "MainScene.h"

#include <iostream>
#include <sstream>
#include <string>
using namespace std;

//////////////////////////////////////////////////////////////
CHighscoreScene::CHighscoreScene(sf::RenderWindow &Parent) : CBasicScene(Parent)
{
	DEBUG_PRINTF((" CHighscoreScene::Constructor(%x)",this));

	// setup working variables
	this->iAnimationAction = -2;
	this->fAnimationIndex  = 0.0f;

	// setup background sprite
	{
		this->spriteBackground.SetImage(Materials->imgBackground);
		this->spriteOverlay	  .SetImage(Materials->imgOverlay);
		this->spriteLogo	  .SetImage(Materials->imgLogo);
		this->spriteLogo.SetPosition((Parent.GetWidth() - this->spriteLogo.GetSubRect().GetWidth()) / 2.f, 50.f);
	}

	// setup menu sprites
	{
		this->spriteMenuBack.SetImage(Materials->imgMenuItems);
		this->SetSpriteMenuIndex(this->spriteMenuBack, 8);
		this->spriteMenuBack.SetPosition((Parent.GetWidth() - this->spriteMenuBack.GetSubRect().GetWidth()) / 2.f, 520.f);

		this->spriteTitle.SetImage(Materials->imgMenuItems);
		this->SetSpriteMenuIndex(this->spriteTitle, 2+1);
		this->spriteTitle.SetPosition((Parent.GetWidth() - this->spriteTitle.GetSubRect().GetWidth()) / 2.f, 100.f);
	}

	// setup highscore stats
	for (int i=0; i<CHighscoreManager::MAXENTRYCOUNT; ++i)
	{
		{
			string strName	= "- Nicht Belegt -";
			string strScore = "0";
			unsigned int points = 0;

			// get items from highscore manager
			if (HighscoreManager->GetEntry(i, strName, points))
			{	
				ostringstream streamString;

				streamString << (i+1);
				strName = string(streamString.str()) + ". " + strName;	

				streamString.str(std::string());
				streamString << points;
				strScore = string(streamString.str());
			}

			this->strPlayerNames[i] .SetText(strName);
			this->strPlayerPoints[i].SetText(strScore);
			this->strPlayerNames[i] .SetColor(sf::Color(0,0,0,0));
			this->strPlayerPoints[i].SetColor(sf::Color(0,0,0,0));
		}


		// arange highscore items
		const float LEFTBORDER  = 100.f;
		const float RIGHTBORDER = 100.f;
		const float TOPBORDER   = 140.f;
		const float STEP	    = 34.f;

		this->strPlayerNames[i].SetPosition(LEFTBORDER, TOPBORDER + i*STEP);
		this->strPlayerPoints[i].SetPosition(800.f - RIGHTBORDER - this->strPlayerPoints[i].GetRect().GetWidth(), TOPBORDER + i*STEP);
	}

}

//////////////////////////////////////////////////////////////
CHighscoreScene::~CHighscoreScene(void)
{
	DEBUG_PRINTF((" CHighscoreScene::Destructor(%x)",this));
}

//////////////////////////////////////////////////////////////
CBasicScene* CHighscoreScene::EventHandler(sf::Event &event)
{
	int			 iAction = 0;
	sf::Vector2i mousepos;

	// check mouse event
	if (event.Type == sf::Event::MouseMoved)
	{
		iAction = 1;
		mousepos = sf::Vector2i(event.MouseMove.X, event.MouseMove.Y);
	}
	else
	if ((event.Type == sf::Event::MouseButtonPressed) && (event.MouseButton.Button == sf::Mouse::Left))
	{
		iAction = 2;
		mousepos = sf::Vector2i(event.MouseButton.X, event.MouseButton.Y);
	}

	// process event
	if (iAction > 0)
	{
		int state;
		int pushButton = 0;

		// determinate button states
		state = this->isPointOverSprite(mousepos, this->spriteMenuBack);
		this->SetSpriteMenuIndex(this->spriteMenuBack, 8 + state);
		if (state) pushButton = 1;

		// action selector switch
		if ((iAction > 1) && (pushButton>0))
		{
			Materials->sndClick.Play();
			switch (pushButton)
			{
				case 1:								// Zur�ck!
					this->iAnimationAction = 1;
					this->fAnimationIndex = 255.0f;
					this->iSelected = pushButton;
				break;
				default:
					DEBUG_PRINTF((" CHighscoreScene::EventHandler(int) unknown Action id:%d",pushButton));
			}
		}

	}

	return NULL;
}

//////////////////////////////////////////////////////////////
CBasicScene* CHighscoreScene::Render()
{
	CBasicScene *NewScene = NULL;
	this->ParentWindow->Clear();

	switch (this->iAnimationAction)
	{
		case -2:							// < scene start, fade in Animation
			this->fAnimationIndex += 10.f;
			if (this->fAnimationIndex > 255.0f)
				this->fAnimationIndex = 255.0f;

			this->spriteTitle	.SetColor(sf::Color(255,255,255, sf::Uint8(this->fAnimationIndex)));
			this->spriteMenuBack.SetColor(sf::Color(255,255,255, sf::Uint8(this->fAnimationIndex)));

			// goto next animation
			if (this->fAnimationIndex >= 255.0f)	
			{
				this->iAnimationAction = -1;
				this->fAnimationIndex = 0.f;
			}
		break;
		case -1:							// fade in score items
			this->fAnimationIndex += 10.f;

			for (int i=0; i<CHighscoreManager::MAXENTRYCOUNT; ++i)
			{
					int iAlpha = int(this->fAnimationIndex - i * 50.f); 
					if (iAlpha > 255) iAlpha = 255;
					if (iAlpha < 0)   iAlpha = 0;

					sf::Color sColor(43,66,255, sf::Uint8(iAlpha));
					this->strPlayerNames[i] .SetColor(sColor);
					this->strPlayerPoints[i].SetColor(sColor);
			}
			break;
		case 1:								// < Menu select, move out animation
		{
			const float STEP   = -20.f;

			// fade out title and score items
			{
				this->fAnimationIndex -= 25.f;
				if (this->fAnimationIndex < 0.f)
					this->fAnimationIndex = 0.f;
				this->spriteTitle.SetColor(sf::Color(255,255,255, sf::Uint8(this->fAnimationIndex)));

				for (int i=0; i<CHighscoreManager::MAXENTRYCOUNT; ++i)
				{
					sf::Color sColor(43,66,255, sf::Uint8(this->fAnimationIndex));
					this->strPlayerNames[i] .SetColor(sColor);
					this->strPlayerPoints[i].SetColor(sColor);
				}
			}
			
			// move menu items out
			this->spriteMenuBack.Move(STEP, 0.f);
			if (this->spriteMenuBack.GetPosition().x < 0.f)
			{
				switch (this->iSelected)
				{
					case 1:		//Back
						NewScene = new CMainScene(*(this->ParentWindow));
						break;
					default:
						DEBUG_PRINTF(("CHighscoreScene::Render() unknown Action id:%d",this->iSelected));
				}
			}
		}
	}

	// draw background
	this->ParentWindow->Draw(this->spriteBackground);
	this->ParentWindow->Draw(this->spriteOverlay);
	this->ParentWindow->Draw(this->spriteLogo);

	// draw title
	this->ParentWindow->Draw(this->spriteTitle);

	// draw back menu
	this->ParentWindow->Draw(this->spriteMenuBack);

	// draw highscore items
	for (int i=0; i<CHighscoreManager::MAXENTRYCOUNT; ++i)
	{
		this->ParentWindow->Draw(this->strPlayerNames[i]);
		this->ParentWindow->Draw(this->strPlayerPoints[i]);
	}

	return NewScene;
}