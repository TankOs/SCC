Hier mein Beitrag zum SCC21.
SFML Version ist 1.6
Das Lied ist: Feel It von Outsider
