#ifndef SCREENMANAGER_HPP
#define SCREENMANAGER_HPP
#include <string>
#include <map>
#include <SFML/Graphics.hpp>

#include "Screen.hpp"

class ScreenManager
{
private:
    std::map< std::string,Screen&> _liste;
    sf::RenderWindow &_window;
public:
    ScreenManager(sf::RenderWindow &Window);
    bool addScreen(Screen &screen, std::string name);
    unsigned int size() const;
    void runScreen(std::string name);



};

#endif // SCREENMANAGER_HPP
