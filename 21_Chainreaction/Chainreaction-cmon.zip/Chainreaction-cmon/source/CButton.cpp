#include "CButton.hpp"

CButton::CButton(const std::string &text): _text(sf::String(text,sf::Font::GetDefaultFont(),20.f))
{
    _text.SetPosition(355,297);
}
//-----------------------------------------------------------------------------
void CButton::Render(sf::RenderTarget &Target) const
{
    Target.Draw(sf::Shape::Rectangle(350,300,400,320,sf::Color(0,0,0,0),1,sf::Color::Green));
    Target.Draw(_text);
}
//-----------------------------------------------------------------------------
bool CButton::click(int x, int y) const
{
    if(x>350 && x<400 && y>300 && y<320)
        return true;
    else
        return false;

}
