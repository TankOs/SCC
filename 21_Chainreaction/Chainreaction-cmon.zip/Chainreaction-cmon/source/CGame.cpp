#include "CGame.hpp"
#include "CBall.hpp"
#include <iostream>
#include <sstream>
#include "MenuScreen.hpp"
#include "GameScreen.hpp"
CGame::CGame():_GameField(*this),
               _button("play"),
               _click(false),
               _win(false),
               _pointcounter(0),
               _m(*this)
{
    this->Create(sf::VideoMode(800,600),"Chainrektion-Clon-by-cmon",sf::Style::Titlebar);
    this->SetFramerateLimit(60);
    Screen *s = new MenuScreen(this->_GameField,this->_pointcounter,this->_win);
    _m.addScreen(*s,std::string("Menu"));
    s = new GameScreen(_GameField);
    _m.addScreen(*s,std::string("Game"));
}
//-----------------------------------------------------------------------------
void CGame::run()
{
    int status;
    while(1)
    {
        _m.runScreen("Menu");
        _m.runScreen("Game");
        status = _GameField.checkEnd();
        if(status == 3)
        {
            _win = true;
            int level = _GameField.getLevel();
            _pointcounter = _pointcounter + _GameField.getcounter();
            level++;
            _GameField.loadLevel(level);
        }
        else if( status == 2)
        {
            _win = false;
            int level = _GameField.getLevel();
            _GameField.loadLevel(level);
        }
        if(this->IsOpened() == false)
            return;

    }
}
