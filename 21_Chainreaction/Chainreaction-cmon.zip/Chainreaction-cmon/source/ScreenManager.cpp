#include "ScreenManager.hpp"

ScreenManager::ScreenManager(sf::RenderWindow &Window): _window(Window)
{

}
//-----------------------------------------------------------------------------
bool ScreenManager::addScreen(Screen &screen, std::string name)
{
    std::pair<std::map<std::string,Screen&>::iterator,bool> ret;
    ret = _liste.insert(std::pair<std::string, Screen&>(name,screen));
    return ret.second;
}
//-----------------------------------------------------------------------------
unsigned int ScreenManager::size() const
{
    return _liste.size();
}
//-----------------------------------------------------------------------------
void ScreenManager::runScreen(std::string name)
{
    std::map<std::string,Screen&>::iterator iter;

    iter = _liste.find(name);
    iter->second.run(_window);
}
