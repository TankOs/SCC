#ifndef SCREEN_HPP
#define SCREEN_HPP

#include <string>
#include <SFML/Graphics.hpp>
class Screen
{
public:
    Screen();
    virtual void run(sf::RenderWindow &app) = 0;
};

#endif // SCREEN_HPP
