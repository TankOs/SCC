#include "CGameField.hpp"
#include "CGame.hpp"
#include "CBall.hpp"
#include <iostream>
CGameField::CGameField(CGame &App): _app(App),
                                    _counter(0),
                                    _level(0),
                                    _click(false),
                                    _loader("level.dat")
{
    this->loadLevel(1);

}
//-----------------------------------------------------------------------------
void CGameField::loadLevel(unsigned int level)
{
    _level = level;
    _moveliste.clear();
    _hitliste.clear();
    _counter = 0;
    _click = false;

    _loader.loadLevel(level);
    _winnumber = _loader.getHitCount();
    _ballnumber = _loader.getBallCount();

        for(unsigned int i=0; i<_ballnumber; i++)
            _moveliste.push_back(CBall(sf::Randomizer::Random(50,750),
                                       sf::Randomizer::Random(50,550),
                                       sf::Color(sf::Randomizer::Random(50,200),
                                                 sf::Randomizer::Random(50,200),
                                                 sf::Randomizer::Random(50,200))));
}
//-----------------------------------------------------------------------------
void CGameField::Draw() const
{
    for(unsigned int i=0; i < _hitliste.size(); i++)
        _app.Draw(_hitliste[i]);


    for(unsigned int i=0; i < _moveliste.size(); i++)
        _app.Draw(_moveliste[i]);
}
//-----------------------------------------------------------------------------
void CGameField::click(unsigned int x, unsigned int y)
{
    if(_click)
        return;

    static int bla = 0;
    for(std::vector<CBall>::iterator iter=_moveliste.begin(); iter != _moveliste.end(); iter++)
    {
        if(iter->hit(x,y))
        {
            _hitliste.push_back(*iter);
            _moveliste.erase(iter);
            _counter++;
            bla++;
              _click = true;
            return;
        }
    }
}
//-----------------------------------------------------------------------------
void CGameField::move()
{
    for(unsigned int i=0; i < _hitliste.size(); i++)
        _hitliste[i].move(_app.GetFrameTime());

    for(unsigned int i=0; i < _moveliste.size(); i++)
        _moveliste[i].move(_app.GetFrameTime());

}
//-----------------------------------------------------------------------------
void CGameField::checkCollision()
{
    for(std::vector<CBall>::iterator iter=_moveliste.begin(); iter != _moveliste.end(); iter++)
        for(unsigned int i=0; i<_hitliste.size(); i++)
        {
            if(_hitliste[i].hit(*iter))
            {
                iter->hit(1000,0);
                _hitliste.push_back(*iter);
                _moveliste.erase(iter);
                _counter++;
                return;
            }
        }
}
//-----------------------------------------------------------------------------
bool CGameField::checkWin() const
{
    return _counter >= _winnumber;
}
//-----------------------------------------------------------------------------
int CGameField::checkEnd() const
{
    if(!_click)
        return 1;

    for(unsigned int i=0; i < _hitliste.size(); i++)
        if(_hitliste[i].visible() == true)
        {
            if(this->checkWin())
                return 5;
            else
                return 4;        
        }
    if(this->checkWin())
        return 3;
    else
        return 2;
}
//-----------------------------------------------------------------------------
unsigned int CGameField::getLevel() const
{
    return _level;
}
//-----------------------------------------------------------------------------
unsigned int CGameField::getBallsnumber() const
{
    return _ballnumber;
}
//-----------------------------------------------------------------------------
unsigned int CGameField::getHitnumber() const
{
    return _winnumber;
}
//-----------------------------------------------------------------------------
unsigned int CGameField::getcounter() const
{
    return _counter;
}
