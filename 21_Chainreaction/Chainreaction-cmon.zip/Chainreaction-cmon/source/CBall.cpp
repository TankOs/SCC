#include "CBall.hpp"
#include "SFML/System.hpp"
#include <iostream>
#define DEBUG true
CBall::CBall():  _rect(), _r(10), _hit(false), _close(false)
{
    this->erzeugeRV();
    _Ball = sf::Shape::Circle(0,0,_r,sf::Color::Red);
    _visible = true;
}
//-----------------------------------------------------------------------------
CBall::CBall(float posx, float posy, sf::Color color):  _rect(), _r(10), _hit(false), _close(false)
{
    this->erzeugeRV();
    _Ball = sf::Shape::Circle(0,0,(float)_r,color);
    _Ball.SetPosition(posx,posy);
    _visible = true;
}
//-----------------------------------------------------------------------------
void CBall::Render(sf::RenderTarget &Target) const
{

    if(_Ball.GetScale().x>0.15)
    {
        Target.Draw(_Ball);
    }

}
//-----------------------------------------------------------------------------
void CBall::move(float time)
{
        if(_hit)
           this->hitdraw();
        int speed = 300;
        _Ball.Move(_rv.x*time*speed, _rv.y*time*speed);
        sf::Rect<float> ball(_Ball.GetPosition().x-_r,
                             _Ball.GetPosition().y-_r,
                             _Ball.GetPosition().x+_r,
                             _Ball.GetPosition().y+_r);
        if(ball.Right>800)
        {
            _rv.x =- _rv.x;
            _Ball.Move(_rv.x*time*speed, _rv.y*time*speed);
        }
        if(ball.Left< 0)
        {
            _rv.x =- _rv.x;
            _Ball.Move(_rv.x*time*speed, _rv.y*time*speed);
        }
        if(ball.Top<0)
        {
            _rv.y =- _rv.y;
            _Ball.Move(_rv.x*time*speed, _rv.y*time*speed);
        }
        if(ball.Bottom>600)
        {
            _rv.y =- _rv.y;
            _Ball.Move(_rv.x*time*speed, _rv.y*time*speed);
        }



}
//-----------------------------------------------------------------------------
void CBall::erzeugeRV()
{

    float x_tmp = sf::Randomizer::Random(-1.f,1.f);
    float y_tmp = sf::Randomizer::Random(-1.f,1.f);
    this->_rv.x = x_tmp;
    this->_rv.y = y_tmp;
}
//-----------------------------------------------------------------------------
bool CBall::hit(int x, int y)
{

    if(_hit)
        return false;

    sf::Rect<float> ball(_Ball.GetPosition().x-_r,
                         _Ball.GetPosition().y-_r,
                         _Ball.GetPosition().x+_r,
                         _Ball.GetPosition().y+_r);
    if(ball.Contains(x,y) || x == 1000)
    {
        this->_Ball.SetColor(sf::Color(this->_Ball.GetColor().r,this->_Ball.GetColor().g,this->_Ball.GetColor().b,100));
        _hit = true;
        _rv.x = 0;
        _rv.y = 0;
        _timer.Reset();
   }

    return ball.Contains(x,y);
}
//-----------------------------------------------------------------------------
void CBall::hitdraw()
{
    if(_visible == false)
        return;

    if(_close == false)
    {
        _Ball.SetScale(_Ball.GetScale().x+_timer.GetElapsedTime()*4,_Ball.GetScale().x+_timer.GetElapsedTime()*4);
        _timer.Reset();
        if(_Ball.GetScale().x>5)
            _close = true;
    }
    else
    {
        _Ball.SetScale(_Ball.GetScale().x-_timer.GetElapsedTime()*4,_Ball.GetScale().x-_timer.GetElapsedTime()*4);
        _timer.Reset();
        if(_Ball.GetScale().x <= 0.1)
            _visible = false;
    }

}
//-----------------------------------------------------------------------------
bool CBall::hit(const sf::Rect<float> &other)
{
    if(_Ball.GetScale().x<0.2)
        return false;
    sf::Rect<float> ball(this->getRect());

    return ball.Intersects(other);
}
//-----------------------------------------------------------------------------
bool CBall::hit(const CBall &other) const
{
    if(_Ball.GetScale().x<0.2)
        return false;

    int d = other._r*other._Ball.GetScale().x + this->_r*this->_Ball.GetScale().x;
    int xd = other._Ball.GetPosition().x - this->_Ball.GetPosition().x;
    int yd = other._Ball.GetPosition().y - this->_Ball.GetPosition().y;

    return sqrt(xd * xd + yd * yd) <= d;

}
//-----------------------------------------------------------------------------
sf::Rect<float> & CBall::getRect()
{
    _rect.Left = _Ball.GetPosition().x-(_r*_Ball.GetScale().x);
    _rect.Top = _Ball.GetPosition().y-(_r*_Ball.GetScale().y);
    _rect.Right=_Ball.GetPosition().x+(_r*_Ball.GetScale().x);
    _rect.Bottom=_Ball.GetPosition().y+(_r*_Ball.GetScale().y);
    return _rect;
}
//-----------------------------------------------------------------------------
bool CBall::visible() const
{
    return _visible;
}
