#include "CLeveLoader.hpp"
#include <iostream>
#include <stdlib.h>

CLeveLoader::CLeveLoader(const std::string &name): _stream(name.c_str(), std::ios::in)
{
   _DateiName = name;
   std::string bla;
   getline(_stream, bla);
    _levels = atoi(bla.c_str());
}
//-----------------------------------------------------------------------------
void CLeveLoader::loadLevel(unsigned int level)
{
    std::string text;
    _stream.seekg(0, std::ios::beg);
    getline(_stream, text);

    for(unsigned int i=1; i < level; i++)
        getline(_stream, text);

    getline(_stream, text);
    int strpos = text.find(" ");
    std::string f = text.substr(0,strpos);

    _hit = atoi(f.c_str());
    f = text.substr(strpos+1, text.size());

    _ball = atoi(f.c_str());
}
//-----------------------------------------------------------------------------
unsigned int CLeveLoader::getBallCount() const
{
    return _ball;
}
//-----------------------------------------------------------------------------
unsigned int CLeveLoader::getHitCount() const
{
    return _hit;
}
