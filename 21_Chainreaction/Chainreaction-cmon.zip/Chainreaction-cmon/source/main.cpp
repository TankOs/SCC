#include <CGame.hpp>
#include <CLeveLoader.hpp>
#include <SFML/Audio.hpp>
int main(int argc, char *argv[])
{
    sf::Music music;

    if(music.OpenFromFile("feel_it.ogg"))
    {
        music.SetVolume(5);
        music.Play();
    }

    CGame game;
    game.run();

    return 0;
}
