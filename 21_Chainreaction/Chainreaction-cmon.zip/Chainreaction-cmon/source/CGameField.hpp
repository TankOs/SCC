#ifndef CGAMEFIELD_HPP
#define CGAMEFIELD_HPP

#include <vector>
#include "CBall.hpp"
#include <CLeveLoader.hpp>
class CGame;

class CGameField
{
protected:
    CGame &_app;
    std::vector<CBall> _moveliste;
    std::vector<CBall> _hitliste;
    unsigned int _winnumber;
    unsigned int _ballnumber;
    unsigned int _counter;
    unsigned int _level;
    bool _click;
    CLeveLoader _loader;
public:
    CGameField(CGame &App);
    void loadLevel(unsigned int level);
    void Draw() const;
    void move();
    void checkCollision();
    void click(unsigned int x, unsigned int y);
    bool checkWin() const;
    int checkEnd() const;
    unsigned int getLevel() const;
    unsigned int getBallsnumber() const;
    unsigned int getHitnumber() const;
    unsigned int getcounter() const;

};

#endif // CGAMEFIELD_HPP
