#ifndef MENUSCREEN_HPP
#define MENUSCREEN_HPP

#include <SFML/Graphics.hpp>
#include "CButton.hpp"
#include "Screen.hpp"
#include "CGameField.hpp"

class MenuScreen : public Screen
{
protected:
    CButton      _button;
    CGameField   &_GameField;
    unsigned int &_pointcounter;
    bool         &_win;
public:
    MenuScreen(CGameField &gamefield, unsigned int &pointcounter, bool &win);
    virtual void run(sf::RenderWindow &app);
};

#endif // MENUSCREEN_HPP
