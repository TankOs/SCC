#ifndef CLEVELOADER_HPP
#define CLEVELOADER_HPP

#include <string>
#include <iostream>
#include <fstream>

class CLeveLoader
{
protected:
    std::ifstream _stream;
    std::string _DateiName;
    unsigned int _levels;
    unsigned int _hit;
    unsigned int _ball;
public:
    CLeveLoader(const std::string &name);
    void loadLevel(unsigned int level);
    unsigned int getBallCount() const;
    unsigned int getHitCount() const;

};

#endif // CLEVELOADER_HPP
