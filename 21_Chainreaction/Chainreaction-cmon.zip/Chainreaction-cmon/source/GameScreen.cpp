#include "GameScreen.hpp"
#include <iostream>
#include <sstream>
GameScreen::GameScreen(CGameField &gamefield):_GameField(gamefield)
{

}

void GameScreen::run(sf::RenderWindow &app)
{
    const sf::Input &Input = app.GetInput();
    sf::Event event;
    std::stringstream tmp;
    sf::String bla;
    bla.SetPosition(0,550);
    while(app.IsOpened())
    {
        while(app.GetEvent(event))
        {
            if(event.Type == sf::Event::Closed)
                app.Close();
            else if(event.Type == sf::Event::KeyPressed)
                if(event.Key.Code == sf::Key::Escape)
                    app.Close();
        }
        if(Input.IsMouseButtonDown(sf::Mouse::Left))
        {
            _GameField.click(Input.GetMouseX(), Input.GetMouseY());
        }
        tmp.str("");
        tmp << _GameField.getcounter() << "/" << _GameField.getHitnumber() ;
        bla.SetText(tmp.str());
        _GameField.move();
        _GameField.checkCollision();
        if(_GameField.checkEnd() == 3)
        {
            return ;
        }
        else if(_GameField.checkEnd() == 2)
        {
            return ;
        }

        if(_GameField.checkEnd() == 5)
        {
            app.Clear(sf::Color(100,100,100));
        }
        else
            app.Clear();
        _GameField.Draw();
        app.Draw(bla);

        app.Display();
    }
    return ;
}
