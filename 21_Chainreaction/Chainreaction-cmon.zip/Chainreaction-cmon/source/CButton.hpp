#ifndef CBUTTON_HPP
#define CBUTTON_HPP

#include <SFML/Graphics.hpp>

class CButton: public sf::Drawable
{
protected:
    sf::String _text;
public:
    CButton(const std::string &text);
    virtual void Render(sf::RenderTarget& Target) const;
    bool click(int x, int y) const;
};

#endif // CBUTTON_HPP
