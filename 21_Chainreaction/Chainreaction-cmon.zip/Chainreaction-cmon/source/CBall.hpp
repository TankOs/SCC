#ifndef CBALL_HPP
#define CBALL_HPP

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

class CBall: public sf::Drawable
{
private:
    sf::Shape _Ball;
    sf::Vector2f  _rv;
    sf::Rect<float> _rect;
    void erzeugeRV();
    unsigned int _r;
    bool _hit;
    bool _close;
    bool _visible;
    sf::Clock _timer;
    void hitdraw();

public:
    CBall();
    CBall(float posx, float posy, sf::Color color);
    virtual void Render(sf::RenderTarget& Target) const;
    void move(float time);
    bool hit(int x, int y);
    bool hit(const sf::Rect<float> &other);
    bool hit(const CBall &other) const;

    sf::Rect<float>& getRect();
    bool visible() const;
};

#endif // CBALL_HPP
