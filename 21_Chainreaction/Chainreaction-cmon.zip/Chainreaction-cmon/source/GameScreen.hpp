#ifndef GAMESCREEN_HPP
#define GAMESCREEN_HPP

#include <SFML/Graphics.hpp>
#include "Screen.hpp"
#include "CGameField.hpp"

class GameScreen : public Screen
{
protected:
        CGameField   &_GameField;
public:
    GameScreen(CGameField &gamefield);
    virtual void run(sf::RenderWindow &app);
};

#endif // GAMESCREEN_HPP
