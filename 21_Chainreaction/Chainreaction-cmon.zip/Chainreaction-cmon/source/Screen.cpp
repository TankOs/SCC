#include "Screen.hpp"

Screen::Screen()
{
}
