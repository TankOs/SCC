#include "MenuScreen.hpp"
#include <iostream>
#include <sstream>

MenuScreen::MenuScreen(CGameField &gamefield, unsigned int &pointcounter, bool &win):_button("play"),
                                                                          _GameField(gamefield),
                                                                          _pointcounter(pointcounter),
                                                                          _win(win)
{

}

void MenuScreen::run(sf::RenderWindow &app)
{
    sf::Event event;
    const sf::Input &Input = app.GetInput();

    std::stringstream tmp;

    sf::String ausgabe;
    sf::String win;
    sf::String counter;

    counter.SetPosition(280,350);
    ausgabe.SetPosition(280,200);
    win.SetPosition(310,250);

    tmp << "Level: " << _GameField.getLevel() << "   "
                     << _GameField.getHitnumber() << "/"
                     << _GameField.getBallsnumber();


    ausgabe.SetText(tmp.str());


    if(_win)
        win.SetText("Win");
    else
        win.SetText("Try agin");


    tmp.str("");
    tmp << "Pointcount: " << _pointcounter;
    counter.SetText(tmp.str());



    while(app.IsOpened())
    {
        while(app.GetEvent(event))
        {
            if(event.Type == sf::Event::Closed)
                app.Close();
            else if(event.Type == sf::Event::KeyPressed)
                if(event.Key.Code == sf::Key::Escape)
                    app.Close();
         }
        if(Input.IsMouseButtonDown(sf::Mouse::Left) && _button.click(Input.GetMouseX(), Input.GetMouseY()))
        {
            return;
        }
            app.Clear();
            app.Draw(_button);
            app.Draw(ausgabe);
            app.Draw(win);
            app.Draw(counter);
            app.Display();

    }
}
