#ifndef CGAME_HPP
#define CGAME_HPP

#include <SFML/Graphics.hpp>
#include "CGameField.hpp"
#include "CButton.hpp"

#include "ScreenManager.hpp"
#include "Screen.hpp"

class CGame: public sf::RenderWindow
{
protected:
    CGameField   _GameField;
    CButton      _button;
    bool         _click;
    bool         _win;
    unsigned int _pointcounter;
    ScreenManager _m;

public:
    CGame();
    void run();
};

#endif // CGAME_HPP
