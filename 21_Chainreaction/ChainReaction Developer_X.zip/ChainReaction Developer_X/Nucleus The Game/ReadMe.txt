Willkommen bei Nucleus-The-Game 
by Kevin Riehl
---------------------------------------
[+] Story
[+] Informationen
[+] How To Play
[+] Credits
---------------------------------------

Story
---------------------------------------
In diesem Spiel geht es darum, die 
erste Reaktion einer Kernschmelze so
zu gestalten, sodass eine Mindestzahl an
Teilchen reagiert.
---------------------------------------

Informationen
---------------------------------------
Im Ordner "Code" finden Sie den
Quellcode des Spiels, geschrieben von
Kevin Riehl alias Developer_X, in C++.

Im Ordner "Game" finden Sie eine
startbare Funktion des Spiels.
---------------------------------------

How To Play
---------------------------------------
In der Datei "HowToPlay.txt" finden Sie
die Instruktionen zum Spielen.
---------------------------------------

Credits
---------------------------------------
In der Datei "Credits.txt" finden Sie
die Credits des Spiels.
---------------------------------------
