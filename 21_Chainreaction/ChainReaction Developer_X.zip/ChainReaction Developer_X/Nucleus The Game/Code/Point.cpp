/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "Point.hpp"

///	Konstruktor
Point::Point() :
x(0),y(0)
{
}
Point::Point(float a,float b) :
x(a),y(b)
{
}
