#ifndef GAME_HPP_INCLUDED
#define GAME_HPP_INCLUDED

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "Particle.hpp"
#include <sstream>
#include <string>

class Game
{
public :
///	Attribute
	sf::RenderWindow* window;		/// Window

	sf::SoundBuffer sb1;			/// Sounds
	sf::SoundBuffer sb2;
	std::vector<sf::Sound> sounds;

	std::vector<Particle> particles;/// Particle
	std::vector<Particle> fragments;///	Fragments

	sf::Font font;					/// Font

	Point m;						/// Maus Position

	bool running;					/// Laufzeitvariable
	bool fire;						/// Schuss

	int width;						/// Spielbereich
	int height;

	int level;						/// Aktuelles Level
	int l;							/// Level
	long score;						/// Punktzahl
	int reached;					/// Zerst�rung
	int goal;						/// Ziel Zerst�rung

///	Funktionen
	void LoadData();		/// L�d alle Daten

	void NextLevel();		/// N�chstes Level
	void RunGame();			/// Startet das Spiel
	void Compute();			/// Verrechnet die Daten
	void ComputeLevel();	/// Verrechnet Level
	void CheckEvents();		/// Pr�ft Benutzereingaben
	void DrawGame();		/// Zeichnet Spiel

	void Generate();		/// Generiert neue Teilchen
	void CreateFragments(bool b,int i);/// Generiert Fragmente

	void AddSound();		/// F�ge Sound hinzu
	double GetDistance(Point a,Point b);/// Berechnet die Distanz

	template <class T> std::string toString(T t)
	{
		std::stringstream ss;
		ss << t;
		return ss.str();
	}
///	Konstruktor
	Game(sf::RenderWindow* w);
};

#endif // GAME_HPP_INCLUDED
