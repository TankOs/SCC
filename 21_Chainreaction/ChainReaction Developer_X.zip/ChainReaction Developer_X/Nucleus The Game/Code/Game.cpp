/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "Game.hpp"
#include <iostream>
using namespace std;

///	Funktionen
void Game::LoadData()
{
	sb1.LoadFromFile("sources/Sounds/Blob1.wav");
	sb2.LoadFromFile("sources/Sounds/Blob2.wav");

	font.LoadFromFile("sources/Fonts/Atomic.ttf");
}

void Game::NextLevel()
{
	if(level!=6)
		level++;
	l++;

	Generate();

	reached = 0;
	if(level<3)
		goal = particles.size()*0.5f;
	else if(level<5)
		goal = particles.size()*0.75f;
	else if(level<8)
		goal = particles.size()*0.9f;

	fire = true;
}
void Game::RunGame()
{
	NextLevel();
	while(running)
	{
		Compute();
		CheckEvents();
		DrawGame();
	}
}
void Game::Compute()
{
///	Verrechnet das Level
	ComputeLevel();

///	Verrechne Sounds
	for(int i = 0;i<sounds.size();i++)
	{
		if(sounds[i].GetStatus()==sf::Sound::Stopped)
		{
			sounds.erase(sounds.begin()+i);
			break;
		}
	}

///	Bewege Particle
	for(int i = 0;i<particles.size();i++)
	{
		particles[i].x += particles[i].mx*window->GetFrameTime()*level*25.0f;
		particles[i].y += particles[i].my*window->GetFrameTime()*level*25.0f;
	}

///	Bewege Fragmente
	for(int i = 0;i<fragments.size();i++)
	{
		fragments[i].x += fragments[i].mx*window->GetFrameTime()*level*75.0f;
		fragments[i].y += fragments[i].my*window->GetFrameTime()*level*75.0f;
	}

///	Reflektiere Particle
	for(int i = 0;i<particles.size();i++)
	{
		if(particles[i].x<0)
		{
			particles[i].mx *= -1;
			particles[i].x = 1;
		}
		if(particles[i].x>width)
		{
			particles[i].mx *= -1;
			particles[i].x = width-1;
		}
		if(particles[i].y<0)
		{
			particles[i].my *= -1;
			particles[i].y = 1;
		}
		if(particles[i].y>height)
		{
			particles[i].my *= -1;
			particles[i].y = height-1;
		}
	}

///	L�sche Fragmente
	for(int i = 0;i<fragments.size();i++)
	{
		if(fragments[i].x<0||fragments[i].x>width)
		{
			fragments.erase(fragments.begin()+i);
			break;
		}
		if(fragments[i].y<0||fragments[i].y>height)
		{
			fragments.erase(fragments.begin()+i);
			break;
		}
	}

///	Pr�fe Kollision mit Fragmenten
	for(int i = 0;i<particles.size();i++)
	{
		bool del = false;

		for(int a = 0;a<fragments.size();a++)
		{
			if(GetDistance(particles[i].GetPosition(),fragments[a].GetPosition())<20)
			{
				CreateFragments((particles[i].type%2==0),i);

				particles.erase(particles.begin()+i);
				del = true;

				score += 500;
				reached ++;

				AddSound();

				break;
			}
		}
		if(del)
			break;
	}

///	Pr�fe Kollision mit Partikeln
	for(int i = 0;i<particles.size();i++)
	{
		for(int a = 0;a<particles.size();a++)
		{
			if(i!=a&&GetDistance(particles[i].GetPosition(),particles[a].GetPosition())<20)
			{
				Point p1 = particles[i].GetPosition();
				Point p2 = particles[a].GetPosition();

				if(p1.x<p2.x)
				{
					particles[i].mx = -1 * fabs(particles[i].mx);
					particles[a].mx = +1 * fabs(particles[i].mx);
				}
				else
				{
					particles[i].mx = +1 * fabs(particles[i].mx);
					particles[a].mx = -1 * fabs(particles[i].mx);
				}

				if(p1.y<p2.y)
				{
					particles[i].my = -1 * fabs(particles[i].my);
					particles[a].my = +1 * fabs(particles[i].my);
				}
				else
				{
					particles[i].my = +1 * fabs(particles[i].my);
					particles[a].my = -1 * fabs(particles[i].my);
				}
			}
		}
	}
}
void Game::ComputeLevel()
{
	if(fire==false&&fragments.size()==0)
	{
		if(reached>=goal)
		{
			NextLevel();
		}
		else
		{
			reached = 0;
			Generate();
			if(level<3)
				goal = particles.size()*0.5f;
			else if(level<5)
				goal = particles.size()*0.75f;
			else if(level<8)
				goal = particles.size()*0.9f;
			fire = true;
		}
	}
}
void Game::CheckEvents()
{
	sf::Event Event;
	while (window->GetEvent(Event))
	{
	///	Beenden
		if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::Escape))
			running = false;

	///	Mausbewegung
		if (Event.Type == sf::Event::MouseMoved)
		{
			m.x = Event.MouseMove.X;
			m.y = Event.MouseMove.Y;
		}

	///	Mausklick
		if (Event.Type == sf::Event::MouseButtonPressed)
		{
			if(fire)
			{
				Particle pa;
				pa.x    = m.x;
				pa.y    = m.y;
				pa.c    = sf::Randomizer::Random(1,level);
				pa.type = sf::Randomizer::Random(1,level);
				particles.push_back(pa);

				CreateFragments(level%2==0,particles.size()-1);

				particles.pop_back();

				fire = false;
			}
		}
	}
}
void Game::DrawGame()
{
///	View setzen
	window->SetView(sf::View(sf::FloatRect(0,0,width,height)));

///	Zeichne Hintergrund
	if(reached>=goal)
		window->Draw(sf::Shape::Rectangle(0,0,width,height,sf::Color(255,255,255,75)));
	else
		window->Draw(sf::Shape::Rectangle(0,0,width,height,sf::Color(100,100,100,75)));

///	Zeichne Partikel
	for(int i = 0;i<particles.size();i++)
	{
		sf::Color c;
		sf::Color a;

	///	Farbe
		switch(particles[i].c)
		{
			case 1 : c = sf::Color::Black;
			break;
			case 2 : c = sf::Color::White;
			break;
			case 3 : c = sf::Color::Red;
			break;
			case 4 : c = sf::Color::Green;
			break;
			case 5 : c = sf::Color::Blue;
			break;
			case 6 : c = sf::Color::Yellow;
			break;
			case 7 : c = sf::Color::Magenta;
			break;
			case 8 : c = sf::Color::Cyan;
			break;
		};

	///	AntiFarbe
		if(particles[i].c!=1)
			a = sf::Color::Black;
		else
			a = sf::Color::White;

		window->Draw(sf::Shape::Circle
		(
			particles[i].x,
			particles[i].y,
			10,
			c,
			2,
			a
		));
	}

///	Zeichne Bruchst�cke
	for(int i = 0;i<fragments.size();i++)
	{
		sf::Color c;
		sf::Color a;

	///	Farbe
		switch(fragments[i].c)
		{
			case 1 : c = sf::Color::Black;
			break;
			case 2 : c = sf::Color::White;
			break;
			case 3 : c = sf::Color::Red;
			break;
			case 4 : c = sf::Color::Green;
			break;
			case 5 : c = sf::Color::Blue;
			break;
			case 6 : c = sf::Color::Yellow;
			break;
			case 7 : c = sf::Color::Magenta;
			break;
			case 8 : c = sf::Color::Cyan;
			break;
		};

	///	AntiFarbe
		if(fragments[i].c!=1)
			a = sf::Color::Black;
		else
			a = sf::Color::White;

		window->Draw(sf::Shape::Circle
		(
			fragments[i].x,
			fragments[i].y,
			5,
			c,
			1,
			a
		));
	}

///	Zeichne Info
	sf::String s;
	s.SetFont(font);
	s.SetSize(50);

	s.SetColor(sf::Color::Red);
	s.SetText("Level : "+ toString(l));
	s.SetPosition(10,10);
	window->Draw(s);

	s.SetColor(sf::Color::Cyan);
	s.SetText("Punktzahl : "+ toString(score));
	s.SetPosition(10,60);
	window->Draw(s);

	s.SetText("Teilchen : "+ toString(reached) + " von " + toString(goal));
	s.SetPosition(10,110);
	window->Draw(s);

	if(fire)
	{
		s.SetColor(sf::Color::Red);
		s.SetText(">> Beginnen Sie mit der Schmelze!");
		s.SetPosition(10,200);
		window->Draw(s);
	}

///	Zeichne Cursor
	window->Draw(sf::Shape::Circle(m.x,m.y,20,sf::Color(0,0,255,100),2,sf::Color::Black));

///	Bild anzeigen
	window->Display();
}

void Game::Generate()
{
	particles.clear();
	fragments.clear();

	for(int i = 0;i<pow(level+1,2);i++)
	{
		Particle pa;
		pa.x    = sf::Randomizer::Random(0,width);
		pa.y    = sf::Randomizer::Random(0,height);
		pa.c    = sf::Randomizer::Random(1,level);
		pa.type = sf::Randomizer::Random(1,level);

		pa.mx = 0;
		while(pa.mx==0)
			pa.mx = sf::Randomizer::Random(-3,+3);

		pa.my = 0;
		while(pa.my==0)
			pa.my = sf::Randomizer::Random(-3,+3);

		particles.push_back(pa);
	}
}
void Game::CreateFragments(bool b,int i)
{
	if(b)
	{
		Particle p1;
		p1.x    = particles[i].x;
		p1.y    = particles[i].y;
		p1.c    = particles[i].c;
		p1.type = particles[i].type;

		p1.mx = 1;
		p1.my = 0;
		fragments.push_back(p1);

		p1.mx = -1;
		p1.my = 0;
		fragments.push_back(p1);

		p1.mx = 0;
		p1.my = 1;
		fragments.push_back(p1);

		p1.mx = 0;
		p1.my = -1;
		fragments.push_back(p1);
	}
	else
	{
		Particle p1;
		p1.x    = particles[i].x;
		p1.y    = particles[i].y;
		p1.c    = particles[i].c;
		p1.type = particles[i].type;

		p1.mx = 1;
		p1.my = 1;
		fragments.push_back(p1);

		p1.mx = -1;
		p1.my = 1;
		fragments.push_back(p1);

		p1.mx = -1;
		p1.my = -1;
		fragments.push_back(p1);

		p1.mx = 1;
		p1.my = -1;
		fragments.push_back(p1);
	}
}

void Game::AddSound()
{
	sf::Sound s;

	s.SetBuffer(sb2);

	sounds.push_back(s);
	sounds[sounds.size()-1].Play();
}
double Game::GetDistance(Point a,Point b)
{
	return sqrt(pow(b.x-a.x,2)+pow(b.y-a.y,2));
}

///	Konstruktor
Game::Game(sf::RenderWindow* w) :
window(w),running(true),width(1440),height(900)
{
///	Lade Daten
	LoadData();

	level = 0;
	l = 0;
	score = 0;

///	Starte Spiel
	RunGame();
}
