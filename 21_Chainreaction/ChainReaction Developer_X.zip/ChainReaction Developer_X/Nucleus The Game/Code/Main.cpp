/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "Game.hpp"

using namespace std;

int main()
{
///	Musik abspielen
	sf::Music m;
	m.OpenFromFile("sources/Sounds/Music.wav");
	m.SetLoop(true);
	m.Play();

///	FensterEigenschaften setzen
	sf::WindowSettings Settings;
	Settings.DepthBits         = 24; /// Depth Buffer
	Settings.StencilBits       = 8;  /// Stencil Buffer
	Settings.AntialiasingLevel = 5;  /// Antialising

///	Fenster erstellen
	sf::RenderWindow* window = new sf::RenderWindow(sf::VideoMode::GetDesktopMode(), "Nucleus-The-Game C by Kevin Riehl 2011", sf::Style::Fullscreen,Settings);
	window->ShowMouseCursor(false);
	window->SetFramerateLimit(50);
	window->SetActive(true);

///	Spiel erstellen
	Game* game = new Game(window);

///	Spiel l�schen
	delete game;

///	Fenster l�schen
	delete window;

///	Musik beenden
	m.Stop();

///	Beenden
	return 0;
};
