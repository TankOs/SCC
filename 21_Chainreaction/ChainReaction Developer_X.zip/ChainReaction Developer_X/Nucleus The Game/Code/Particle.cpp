/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "Particle.hpp"

///	Funktionen
void Particle::SetPosition(int a,int b)
{
	x = a;
	y = b;

	p.x = a;
	p.y = b;
}
Point Particle::GetPosition()
{
	Point p(x,y);
	return p;
}

///	Konstruktor
Particle::Particle() :
x(0),y(0),mx(0),my(0),type(0),c(1)
{
	p.x = 0;
	p.y = 0;
}
Particle::Particle(int a,int b,int d) :
x(a),y(b),mx(0),my(0),type(0),c(d)
{
	p.x = a;
	p.y = b;
}
