#ifndef POINT_HPP_INCLUDED
#define POINT_HPP_INCLUDED

class Point
{
public :
///	Attribute
	float x;
	float y;

///	Konstruktor
	Point();
	Point(float a,float b);
};

#endif // POINT_HPP_INCLUDED
