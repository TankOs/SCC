#ifndef PARTICLE_HPP_INCLUDED
#define PARTICLE_HPP_INCLUDED

#include "Point.hpp"

class Particle
{
public :
///	Attribute
	float x;	///	X-Koordinate
	float y;	/// Y-Koordinate
	float mx;	/// X-Vektor
	float my;	/// Y-Vektor
	int type;/// Typ
	int c;	/// Farbe

	Point p;

///	Funktionen
	void SetPosition(int a,int b);
	Point GetPosition();

///	Konstruktor
	Particle();
	Particle(int a,int b,int d);
};

#endif // PARTICLE_HPP_INCLUDED
