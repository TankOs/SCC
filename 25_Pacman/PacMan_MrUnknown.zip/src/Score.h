#ifndef score_h
#define score_h

#include <iostream>
#include <iomanip>
#include <sstream>

#include <SFML/Graphics.hpp>

class Score
{
public:
	Score(sf::RenderWindow &window);

	void update(int value);

	int getScore() {return m_points;}

	void draw();

private:
	sf::RenderWindow &m_window;

	int m_points;

	static bool m_loaded;
	static sf::Font m_font;
	sf::Text m_score;

};

#endif