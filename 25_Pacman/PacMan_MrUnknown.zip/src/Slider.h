#ifndef slider_h
#define slider_h

#include <iostream>

#include <SFML/Graphics.hpp>

class Slider
{
public:
	Slider(sf::RenderWindow &window, sf::Font &font, const std::string &text, sf::Vector2f pos);

	void update();
	void draw();

	void reloadString(const std::string &text);
	void reloadPosition(int xPos);

	int getPercent() {return percent;}

	bool isReleased() {return m_released;}

private:
	enum STATE
	{
		NORMAL,
		HOVER,
		PRESSED
	} m_state;

	sf::RenderWindow &m_window;

	int x;
	float value;
	float percent;

	bool m_released;

	static bool m_loaded;
	static sf::Texture m_tex;
	sf::Sprite m_slider;
	sf::Sprite m_button;
	sf::Text m_text;
};

#endif