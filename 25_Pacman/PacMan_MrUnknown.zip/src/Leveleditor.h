#ifndef leveleditor_h
#define leveleditor_h

#include <list>
#include <iostream>
#include <fstream>

#include "Tile.h"
#include "TextButton.h"
#include "TextBox.h"
#include "Bar.h"
#include "StringBuilder.h"

class Leveleditor
{
public:
	Leveleditor(sf::RenderWindow &window);
	~Leveleditor();
	
	void restart();

	void update();
	void draw();

	void handleEvent(sf::Event ev);

	void save(const std::string &filename);
	void load(const std::string &filename);

	bool quit();

private:
	enum STATE
	{
		EDITOR,
		MENU,
		SAVE,
		LOAD
	} m_state;

	sf::RenderWindow &m_window;

	static bool m_loaded;
	static sf::Texture m_backTex;
	static sf::Font m_font;
	sf::Sprite m_background;
	sf::Text m_title;
	sf::Text m_errorString;

	bool m_exit;

	std::list<Tile> m_tiles;
	std::list<Tile> m_objects;

	std::list<Tile> m_selector;

	Tile *m_active;
	TextButton *m_continue;
	TextButton *m_save;
	TextButton *m_load;
	TextButton *m_quit;
	TextButton *m_back;
	TextBox *m_saveBox;
	TextBox *m_loadBox;
	Bar *m_savingBar;
	Bar *m_loadingBar;

	int m_tileID;
	int m_tileRot;

	bool m_spawnSet;
	
	bool m_redSpawnSet;
	bool m_blueSpawnSet;
	bool m_greenSpawnSet;
	bool m_orangeSpawnSet;
};

#endif