#include "Game.h"

HighscoreElement::HighscoreElement(int points, const std::string &name)
{
	m_points = points;
	m_name = name;
}

Game::Game(sf::RenderWindow &window):
m_window(window)
{
	if (!m_loaded)
	{
		m_backTex.LoadFromFile("data/pictures/background.png");
		m_font.LoadFromFile("data/fonts/arcade.ttf");
		m_loaded = true;
	}

	m_background.SetTexture(m_backTex);
	m_title.SetFont(m_font);
	m_title.SetColor(sf::Color::Yellow);
	m_title.SetPosition(60, 20);
	m_title2.SetFont(m_font);
	m_title2.SetColor(sf::Color::Yellow);
	m_title3.SetFont(m_font);
	m_title3.SetColor(sf::Color::Black);
	m_title3.SetString(StringBuilder::buildString("game", "title3_1") + "1");
	m_title3.SetPosition(200, 637);
	m_errorString.SetFont(m_font);
	m_errorString.SetColor(sf::Color::Red);
	m_errorString.SetString(StringBuilder::buildString("game", "errorstring1"));
	m_errorString.SetPosition(20, 640);
	m_errorString.SetCharacterSize(25);

	m_continue = new TextButton(m_window, m_font, StringBuilder::buildString("game", "button1"), sf::Vector2f(230, 230));
	m_restart = new TextButton(m_window, m_font, StringBuilder::buildString("game", "button2"), sf::Vector2f(230, 300));
	m_lvlSelection = new TextButton(m_window, m_font, StringBuilder::buildString("game", "button3"), sf::Vector2f(230, 370));
	m_options = new TextButton(m_window, m_font, StringBuilder::buildString("game", "button5"), sf::Vector2f(230, 430));
	m_quit = new TextButton(m_window, m_font, StringBuilder::buildString("game", "button4"), sf::Vector2f(230, 570));

	m_lvl1 = new PictureButton(m_window, "data/maps/lvl1", sf::Vector2f(80, 250));
	m_lvl2 = new PictureButton(m_window, "data/maps/lvl2", sf::Vector2f(230, 250));
	m_lvl3 = new PictureButton(m_window, "data/maps/lvl3", sf::Vector2f(380, 250));

	m_load = new TextBox(m_window, sf::Vector2f(40, 500));
	m_name = new TextBox(m_window, sf::Vector2f(40, 230));

	m_lvlFile = "";

	m_tilemap = new Tilemap(m_window);
	m_player = new Player(m_window, sf::Vector2f());
	m_score = NULL;

	m_state = LVLSELECTION;

	m_exit = false;
	m_settings = false;
	m_failure = false;
}

Game::~Game()
{
	delete m_tilemap;
	delete m_player;
	delete m_score;
	delete m_continue;
	delete m_restart;
	delete m_lvlSelection;
	delete m_quit;
	delete m_options;
	delete m_lvl1;
	delete m_lvl2;
	delete m_lvl3;
	delete m_load;
	delete m_name;
}

void Game::restart()
{
	m_exit = false;
	m_settings = false;
	m_nameEntered = false;

	m_level = 1;
	m_title3.SetString(StringBuilder::buildString("game", "title3_1") + "1");

	m_highscore.clear();
	
	std::ifstream Input("data/highscore");
	
	for (int i=0; i<10; ++i)
	{
		std::string buff;
		Input >> buff;
		int buf;
		Input >> buf;

		m_highscore.push_back(HighscoreElement(buf, buff));
	}

	Input.close();

	m_failure = false;

	if (m_lvlFile != "")
	{
		m_tilemap->load(m_lvlFile);

		if (m_tilemap->errorOccured())
		{
			m_failure = true;
			return;
		}	
	}
	else if (m_lvlFile == "")
		return;

	if (m_score != NULL)
	{
		delete m_score;
	}
	
	m_ghosts.clear();

	m_player->restart(m_tilemap->getSpawn());
	m_score = new Score(m_window);

	for (int i=0; i<4; ++i)
		m_ghosts.push_back(Ghost(m_window, i, m_tilemap->getGhostSpawn(i)));

	m_errorString.SetString(StringBuilder::buildString("game", "errorstring1"));
	m_continue->reloadString(StringBuilder::buildString("game", "button1"));
	m_restart->reloadString(StringBuilder::buildString("game", "button2"));
	m_lvlSelection->reloadString(StringBuilder::buildString("game", "button3"));
	m_quit->reloadString(StringBuilder::buildString("game", "button4"));
	m_options->reloadString(StringBuilder::buildString("game", "button5"));
}

void Game::nextLvl()
{
	++m_level;

	std::string buf;
	std::stringstream bufStream;

	bufStream << m_level;
	bufStream >> buf;

	m_title3.SetString(StringBuilder::buildString("game", "title3_1") + buf);

	m_player->setPos(m_tilemap->getSpawn());

	int i=0;
	for (std::list<Ghost>::iterator It = m_ghosts.begin(); It != m_ghosts.end(); ++It)
	{
		It->setPosition(m_tilemap->getGhostSpawn(i));
		It->raiseSpeed();
		++i;
	}

	m_tilemap->load(m_lvlFile);
}

void Game::update(float frameTime)
{
	if (m_state == LVLSELECTION)
	{
		m_lvl1->update();
		m_lvl2->update();
		m_lvl3->update();

		if (m_load->accepted())
		{
			m_lvlFile = "data/maps/" + m_load->getContent() + ".map";
			
			restart();

			if (m_failure)
			{
				m_load->update();
				return;
			}

			m_state = GAME;
		}
		m_load->update();
		
		if (m_lvl1->isClicked())
		{
			m_lvlFile = m_lvl1->getFile() + ".map";
			m_state = GAME;
			restart();
		}
		else if (m_lvl2->isClicked())
		{
			m_lvlFile = m_lvl2->getFile() + ".map";
			m_state = GAME;
			restart();
		}
		else if (m_lvl3->isClicked())
		{
			m_lvlFile = m_lvl3->getFile() + ".map";
			m_state = GAME;
			restart();
		}
	}
	else if (m_state == GAME)
	{
		m_player->isMoving(m_tilemap->checkCollision(m_player->getColBox()).x);
		m_player->update(frameTime);

		for (std::list<Ghost>::iterator It = m_ghosts.begin(); It != m_ghosts.end(); ++It)
		{
			It->giveIDandRot(m_tilemap->checkCollision(It->getColBox()));
			It->update(frameTime, m_player->getPos());
		
			if (It->playerCollision(m_player->getColBox()))
			{
				m_player->kill();
				int i=0;
				for (std::list<Ghost>::iterator It2 = m_ghosts.begin(); It2 != m_ghosts.end(); ++It2)
				{
					It2->setPosition(m_tilemap->getGhostSpawn(i));
					++i;
				}
			}
		}

		m_score->update(m_tilemap->checkCoinCollision(m_player->getColBox()));

		if (!m_player->isAlive())
			m_state = GAMEOVER;
		else if (m_tilemap->getCoins() == 0)
			nextLvl();
	}
	else if (m_state == PAUSE)
	{
		m_player->pauseSound();

		m_continue->update();
		m_restart->update();
		m_lvlSelection->update();
		m_quit->update();
		m_options->update();

		if (m_continue->isClicked())
		{
			m_player->reloadVolume();
			m_state = GAME;
		}
		else if (m_restart->isClicked())
		{
			m_state = GAME;
			restart();
		}
		else if (m_lvlSelection->isClicked())
			m_state = LVLSELECTION;
		else if (m_quit->isClicked())
			m_exit = true;
		else if (m_options->isClicked())
		{
			m_settings = true;
		}
		else
			m_settings = false;
	}
	else if (m_state == GAMEOVER)
	{
		m_restart->update();
		m_lvlSelection->update();
		m_quit->update();

		if (m_name->accepted())
		{
			for (std::list<HighscoreElement>::iterator It = m_highscore.begin(); It != m_highscore.end(); ++It)
			{
				if (m_score->getScore() > It->points())
				{
					m_highscore.insert(It, HighscoreElement(m_score->getScore(), m_name->getContent()));
					m_highscore.pop_back();
					break;
				}
			}

			std::ofstream Output("data/highscore");

			for (std::list<HighscoreElement>::iterator It = m_highscore.begin(); It != m_highscore.end(); ++It)
				Output << It->name() << " " << It->points() << std::endl;

			Output.close();
			
			m_nameEntered = true;
		}
		
		m_name->update();

		if (m_restart->isClicked())
		{
			m_state = GAME;
			restart();
		}
		else if (m_lvlSelection->isClicked())
			m_state = LVLSELECTION;
		else if (m_quit->isClicked())
			m_exit = true;
	}
}

void Game::draw()
{
	if (m_state == LVLSELECTION)
	{
		m_window.Draw(m_background);
		m_title.SetCharacterSize(45);
		m_title.SetString(StringBuilder::buildString("game", "title1_1"));
		m_window.Draw(m_title);
		m_title2.SetCharacterSize(45);
		m_title2.SetString(StringBuilder::buildString("game", "title2_1"));
		m_title2.SetPosition(15, 420);
		m_window.Draw(m_title2);
		
		if (m_failure)
			m_window.Draw(m_errorString);

		m_lvl1->draw();
		m_lvl2->draw();
		m_lvl3->draw();

		m_load->draw();
	}
	else if (m_state == GAME)
	{
		m_score->draw();
		m_tilemap->draw();
		m_player->draw();
		m_window.Draw(m_title3);
	
		for (std::list<Ghost>::iterator It = m_ghosts.begin(); It != m_ghosts.end(); ++It)
			It->draw();
	}
	else if (m_state == PAUSE)
	{
		m_window.Draw(m_background);
		m_title.SetCharacterSize(150);
		m_title.SetString(StringBuilder::buildString("game", "title1_2"));
		m_window.Draw(m_title);
		m_window.Draw(m_title3);

		m_continue->draw();
		m_restart->draw();
		m_lvlSelection->draw();
		m_quit->draw();
		m_options->draw();

		m_score->draw();
	}
	else if (m_state == GAMEOVER)
	{
		m_window.Draw(m_background);
		m_title.SetCharacterSize(85);
		m_title.SetString(StringBuilder::buildString("game", "title1_3"));
		m_window.Draw(m_title);
		m_title2.SetCharacterSize(30);
		m_title2.SetString(StringBuilder::buildString("game", "title2_2"));
		m_title2.SetPosition(70, 170);

		m_restart->draw();
		m_lvlSelection->draw();
		m_quit->draw();

		if (!m_nameEntered)
		{
			m_name->draw();
			m_window.Draw(m_title2);
		}
	}
}

void Game::handleEvent(sf::Event ev)
{
	if (ev.Type == sf::Event::KeyReleased && ev.Key.Code == sf::Keyboard::Escape)
	{
		if (m_state == GAME)
			m_state = PAUSE;
		else if (m_state == PAUSE)
			m_state = GAME;
		else if (m_state == LVLSELECTION)
		{
			m_lvlFile = "";
			m_failure = false;
			m_exit = true;
		}
	}
	if (ev.Type == sf::Event::KeyReleased && ev.Key.Code == sf::Keyboard::Space)
	{
		m_player->kill();
	}

	if (m_state == LVLSELECTION)
		m_load->handleEvent(ev);
	else if (m_state == GAME)
		m_player->handleEvent(ev);
	else if (m_state == GAMEOVER && !m_nameEntered)
		m_name->handleEvent(ev);
}

bool Game::quit()
{
	if (m_exit)
		m_state = LVLSELECTION;

	return m_exit;
}

bool Game::m_loaded = false;
sf::Texture Game::m_backTex;
sf::Font Game::m_font;