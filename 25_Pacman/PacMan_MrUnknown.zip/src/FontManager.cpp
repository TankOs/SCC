//
//  FontManager.cpp
//  Tilemap-Editor
//
//  Created by Arne Dußin on 01.11.11.
//  Copyright (c) 2011 DeyDoo Itec. All rights reserved.
//

#include "FontManager.h"

using namespace ddi;

FontManager::~FontManager()
{
	std::map<std::string, sf::Font*>::iterator It = m_Fonts.begin();
	
	while (It != m_Fonts.end())
	{
		delete (It->second);
		++It;
	}
}


sf::Font *FontManager::GetFont(const std::string &FileName)
{
	if (m_Fonts[FileName])
	{
		return m_Fonts[FileName];
	}
	
	sf::Font *NewFont = new (sf::Font);
	if (!NewFont->LoadFromFile(FileName))
	{
		delete NewFont;
		return NULL;
	}
    
	m_Fonts.insert(std::pair<std::string, sf::Font*>(FileName, NewFont));
	return NewFont;
}