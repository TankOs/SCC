#include "TextBox.h"

TextBox::TextBox(sf::RenderWindow &window, sf::Vector2f pos):
m_window(window)
{
	if (!m_loaded)
	{
		m_tex.LoadFromFile("data/pictures/textbox.png");
		m_font.LoadFromFile("data/fonts/arcade.ttf");
		m_loaded = true;
	}

	m_sprite.SetTexture(m_tex);
	m_sprite.SetPosition(pos);

	m_text.SetFont(m_font);
	m_text.SetCharacterSize(45);
	m_text.SetPosition(pos.x + 20, pos.y -10);
	m_text.SetColor(sf::Color::Yellow);

	m_state = NORMAL;
	m_accepted = false;
}

void TextBox::update()
{
	if (m_sprite.GetGlobalBounds().Contains(sf::Mouse::GetPosition(m_window).x, sf::Mouse::GetPosition(m_window).y))
	{
		if (sf::Mouse::IsButtonPressed(sf::Mouse::Left))
		{
			m_state = PRESSED;
			m_sprite.SetTextureRect(sf::IntRect(0, 100, 400, 50));
		}
		else if (m_state == PRESSED && !sf::Mouse::IsButtonPressed(sf::Mouse::Left))
		{
			m_state = ACTIVE;
		}
		else if (m_state != ACTIVE)
		{
			m_state = HOVER;
			m_sprite.SetTextureRect(sf::IntRect(0, 50, 400, 50));
		}
	}
	else if (m_state != ACTIVE)
	{
		m_state = NORMAL;
		m_sprite.SetTextureRect(sf::IntRect(0, 0, 400, 50));
	}
	else if (sf::Mouse::IsButtonPressed(sf::Mouse::Left))
	{
		m_state = NORMAL;
		m_sprite.SetTextureRect(sf::IntRect(0, 0, 400, 50));
	}

	if (m_state != ACTIVE)
	{
		m_content.clear();
		m_accepted = false;
	}

	m_text.SetString(m_content);
}

void TextBox::draw()
{
	m_window.Draw(m_sprite);
	m_window.Draw(m_text);
}

void TextBox::handleEvent(sf::Event ev)
{
	if (m_state == ACTIVE)
	{
		if (ev.Type == sf::Event::TextEntered && m_content.size() < 14)
		{
			if (ev.Text.Unicode >= 33 && ev.Text.Unicode <= 120)
				m_content += ev.Text.Unicode;
		}
		if (ev.Type == sf::Event::KeyPressed && ev.Key.Code == sf::Keyboard::Back)
		{
			if (m_content != "")
			{
				m_content.pop_back();
			}
		}
		
		if (ev.Type == sf::Event::KeyReleased && ev.Key.Code == sf::Keyboard::Return)
		{
			m_state = NORMAL;
			m_accepted = true;
		}
	}
}

bool TextBox::m_loaded = false;
sf::Texture TextBox::m_tex;
sf::Font TextBox::m_font;