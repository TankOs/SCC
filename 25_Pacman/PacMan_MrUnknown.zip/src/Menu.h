#ifndef menu_h
#define menu_h

#include <iostream>
#include <fstream>
#include <sstream>

#include <list>

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "TextButton.h"
#include "StringBuilder.h"

class Menu
{
public:
	Menu(sf::RenderWindow &window);
	~Menu();

	void update();
	void draw();

	void reloadStrings();

	int changeGamestate();

	void handleEvent(sf::Event ev);

private:
	enum STATE
	{
		MENU,
		HIGHSCORE
	} m_state;

	void loadHighscore();

	sf::RenderWindow &m_window;

	static bool m_loaded;
	static sf::Texture m_backgroundTex;
	sf::Sprite m_background;

	static sf::Font m_font;
	sf::Text m_title;
	
	TextButton *m_game;
	TextButton *m_leveleditor;
	TextButton *m_highscore;
	TextButton *m_back;
	TextButton *m_options;

	std::list<sf::Text> m_scores;
};

#endif