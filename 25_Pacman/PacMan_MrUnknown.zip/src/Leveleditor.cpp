#include "Leveleditor.h"

Leveleditor::Leveleditor(sf::RenderWindow &window):
m_window(window)
{
	m_state = EDITOR;

	for (int x=0; x<12; ++x)
	{
		m_selector.push_back(Tile(m_window, x, sf::Vector2f(5+x*(32+5), 644)));
	}

	if (!m_loaded)
	{
		m_backTex.LoadFromFile("data/pictures/background.png");
		m_font.LoadFromFile("data/fonts/arcade.ttf");
		m_loaded = true;
	}

	m_active = NULL;

	m_background.SetTexture(m_backTex);

	m_title.SetFont(m_font);
	m_title.SetColor(sf::Color::Yellow);
	m_errorString.SetFont(m_font);
	m_errorString.SetColor(sf::Color::Red);
	m_errorString.SetString("");
	m_errorString.SetPosition(10, 350);
	m_errorString.SetCharacterSize(25);

	m_continue = new TextButton(m_window, m_font, StringBuilder::buildString("lvleditor", "button1"), sf::Vector2f(230, 270));
	m_save = new TextButton(m_window, m_font, StringBuilder::buildString("lvleditor", "button2"), sf::Vector2f(230, 350));
	m_load = new TextButton(m_window, m_font, StringBuilder::buildString("lvleditor", "button3"), sf::Vector2f(230, 420));
	m_quit = new TextButton(m_window, m_font, StringBuilder::buildString("lvleditor", "button4"), sf::Vector2f(230, 520));
	m_back = new TextButton(m_window, m_font, StringBuilder::buildString("lvleditor", "button5"), sf::Vector2f(230, 500));

	m_saveBox = new TextBox(m_window, sf::Vector2f(40, 200));
	m_loadBox = new TextBox(m_window, sf::Vector2f(40, 200));

	m_savingBar = new Bar(m_window, sf::Vector2f(10, 647));
	m_loadingBar = new Bar(m_window, sf::Vector2f(10, 647));

	m_exit = false;
}

Leveleditor::~Leveleditor()
{
	delete m_active;
	delete m_continue;
	delete m_save;
	delete m_load;
	delete m_quit;
	delete m_back;
	delete m_saveBox;
	delete m_loadBox;
	delete m_savingBar;
	delete m_loadingBar;
}

void Leveleditor::restart()
{
	if (m_active != NULL)
		delete m_active;

	m_tiles.clear();
	m_objects.clear();

	m_tileID = 0;
	m_tileRot = 0;

	m_spawnSet = false;
	
	for (int y=0; y<20; ++y)
	{
		for (int x = 0; x<15; ++x)
		{
			m_tiles.push_back(Tile(m_window, sf::Vector2f(x*32, y*32)));
		}
	}

	for (int y=0; y<20; ++y)
	{
		for (int x = 0; x<15; ++x)
		{
			m_objects.push_back(Tile(m_window, 5,  sf::Vector2f(x*32, y*32)));
		}
	}

	m_active = new Tile(m_window, m_tileID, sf::Vector2f(sf::Mouse::GetPosition(m_window).x+20, sf::Mouse::GetPosition(m_window).y+20));

	m_exit = false;

	m_continue->reloadString(StringBuilder::buildString("lvleditor", "button1"));
	m_save->reloadString(StringBuilder::buildString("lvleditor", "button2"));
	m_load->reloadString(StringBuilder::buildString("lvleditor", "button3"));
	m_quit->reloadString(StringBuilder::buildString("lvleditor", "button4"));
	m_back->reloadString(StringBuilder::buildString("lvleditor", "button5"));
}

void Leveleditor::update()
{
	if (m_state == EDITOR)
	{
		int spawns = 0;
		int red = 0;
		int blue = 0;
		int green = 0;
		int orange = 0;
		for (std::list<Tile>::iterator It = m_objects.begin(); It != m_objects.end(); ++It)
		{
			if (It->getID() == 7)
				++spawns;
			else if (It->getID() == 8)
				++ red;
			else if (It->getID() == 9)
				++ blue;
			else if (It->getID() == 10)
				++ green;
			else if (It->getID() == 11)
				++ orange;
		
			if (spawns > 0)
				m_spawnSet = true;
			else
				m_spawnSet = false;
			if (red > 0)
				m_redSpawnSet = true;
			else
				m_redSpawnSet = false;
			if (blue > 0)
				m_blueSpawnSet = true;
			else
				m_blueSpawnSet = false;
			if (green > 0)
				m_greenSpawnSet = true;
			else
				m_greenSpawnSet = false;
			if (orange > 0)
				m_orangeSpawnSet = true;
			else
				m_orangeSpawnSet = false;
		}
	}
	else if (m_state == MENU)
	{
		m_continue->update();
		m_save->update();
		m_load->update();
		m_quit->update();

		if (m_continue->isClicked())
			m_state = EDITOR;
		else if (m_save->isClicked())
			m_state = SAVE;
		else if (m_load->isClicked())
			m_state = LOAD;
		else if (m_quit->isClicked())
			m_exit = true;
	}
	else if (m_state == SAVE)
	{
		if(m_saveBox->accepted())
			save(m_saveBox->getContent());

		m_saveBox->update();
		m_savingBar->update();

		m_back->update();
		if (m_back->isClicked())
			m_state = MENU;
	}
	else if (m_state == LOAD)
	{
		if(m_loadBox->accepted())
			load(m_loadBox->getContent());

		m_loadBox->update();
		m_loadingBar->update();

		m_back->update();
		if (m_back->isClicked())
			m_state = MENU;
	}

	if (m_state != SAVE && m_state != LOAD)
		m_errorString.SetString("");
}

void Leveleditor::draw()
{
	if (m_state == EDITOR)
	{
		for (std::list<Tile>::iterator It = m_tiles.begin(); It != m_tiles.end(); ++It)
		{
			It->draw();
		}

		for (std::list<Tile>::iterator It = m_objects.begin(); It != m_objects.end(); ++It)
		{
			It->draw();
		}

		for (std::list<Tile>::iterator It = m_selector.begin(); It != m_selector.end(); ++It)
		{
			It->draw();
		}

		m_active->draw();
	}
	else if (m_state == MENU)
	{
		m_window.Draw(m_background);
		m_title.SetCharacterSize(100);
		m_title.SetString(StringBuilder::buildString("lvleditor", "title1"));
		m_title.SetPosition(5, 40);
		m_window.Draw(m_title);

		m_continue->draw();
		m_save->draw();
		m_load->draw();
		m_quit->draw();
	}
	else if (m_state == SAVE)
	{
		m_window.Draw(m_background);
		m_title.SetCharacterSize(35);
		m_title.SetString(StringBuilder::buildString("lvleditor", "title2"));
		m_title.SetPosition(20, 100);
		m_window.Draw(m_title);
		m_window.Draw(m_errorString);

		m_saveBox->draw();
		m_savingBar->draw();

		m_back->draw();
	}
	else if (m_state == LOAD)
	{
		m_window.Draw(m_background);
		m_title.SetCharacterSize(35);
		m_title.SetString(StringBuilder::buildString("lvleditor", "title3"));
		m_title.SetPosition(20, 100);
		m_window.Draw(m_title);
		m_window.Draw(m_errorString);

		m_loadBox->draw();
		m_loadingBar->draw();

		m_back->draw();
	}
}

void Leveleditor::handleEvent(sf::Event ev)
{
	if (ev.Type == sf::Event::KeyReleased && ev.Key.Code == sf::Keyboard::Escape)
	{
		if (m_state == EDITOR || m_state == SAVE || m_state == LOAD)
			m_state = MENU;
		else if (m_state == MENU)
			m_state = EDITOR;
	}

	if (m_state == EDITOR)
	{
		if (sf::Mouse::IsButtonPressed(sf::Mouse::Left))
		{
			for (std::list<Tile>::iterator It = m_tiles.begin(); It != m_tiles.end(); ++It)
			{
				if (It->checkMouseCollision(sf::Vector2f(sf::Mouse::GetPosition(m_window).x, sf::Mouse::GetPosition(m_window).y)) && m_tileID < 5)
				{
					It->setID(m_tileID);
					It->setRotation(m_tileRot);
				}
			}

			for (std::list<Tile>::iterator It = m_objects.begin(); It != m_objects.end(); ++It)
			{
				if (It->checkMouseCollision(sf::Vector2f(sf::Mouse::GetPosition(m_window).x, sf::Mouse::GetPosition(m_window).y)) && m_tileID >= 5)
				{
					for (std::list<Tile>::iterator It2 = m_tiles.begin(); It2 != m_tiles.end(); ++It2)
					{
						if (It2->checkMouseCollision(sf::Vector2f(sf::Mouse::GetPosition(m_window).x, sf::Mouse::GetPosition(m_window).y)))
						{
							if(It2->getID() != 0 && m_tileID != 5)
							{
								if ((m_tileID == 7 && m_spawnSet == true )||
									(m_tileID == 8 && m_redSpawnSet == true )||
									(m_tileID == 9 && m_blueSpawnSet == true )||
									(m_tileID == 10 && m_greenSpawnSet == true )||
									(m_tileID == 11 && m_orangeSpawnSet == true ))
								{}
								else
									It->setID(m_tileID);
							}
							else if (m_tileID == 5)
							{
								It->setID(5);
							}
						}
					}
				}
			}

			for (std::list<Tile>::iterator It = m_selector.begin(); It != m_selector.end(); ++It)
			{
				if (It->checkMouseCollision(sf::Vector2f(sf::Mouse::GetPosition(m_window).x, sf::Mouse::GetPosition(m_window).y)))
				{
					m_tileID = It->getID();
				}
			}
		}
		else if (sf::Mouse::IsButtonPressed(sf::Mouse::Right))
		{
			if (m_tileRot == 3)
				m_tileRot = 0;
			else
				m_tileRot += 1;

			for (std::list<Tile>::iterator It = m_selector.begin(); It != m_selector.end(); ++It)
			{
				It->setRotation(m_tileRot);
			}

			m_active->setRotation(m_tileRot);
		}

		m_active->setID(m_tileID);
		m_active->setPos(sf::Vector2f(sf::Mouse::GetPosition(m_window).x+30, sf::Mouse::GetPosition(m_window).y+30));
	}
	else if (m_state == SAVE)
		m_saveBox->handleEvent(ev);
	else if (m_state == LOAD)
		m_loadBox->handleEvent(ev);
}

void Leveleditor::save(const std::string &filename)
{
	bool isStandardMap = false;

	if (filename == "lvl1" || filename == "lvl2" || filename == "lvl3")
	{
		m_errorString.SetString(StringBuilder::buildString("lvleditor", "errorstring1"));
		return;
	}

	if (!m_spawnSet)
	{
		m_errorString.SetString(StringBuilder::buildString("lvleditor", "errorstring2"));
		return;
	}
	if (!m_redSpawnSet || !m_blueSpawnSet || !m_greenSpawnSet || !m_orangeSpawnSet)
	{
		m_errorString.SetString(StringBuilder::buildString("lvleditor", "errorstring3"));
		return;
	}

	int buf = 0;
	for (std::list<Tile>::iterator It = m_objects.begin(); It != m_objects.end(); ++It)
	{
		if (It->getID() == 6)
			++buf;
	}

	if (buf == 0)
	{
		m_errorString.SetString(StringBuilder::buildString("lvleditor", "errorstring4"));
		return;
	}

	std::ofstream Output("data/maps/" + filename + ".map");

	Output << isStandardMap << " " << filename << std::endl;

	for (std::list<Tile>::iterator It = m_tiles.begin(); It != m_tiles.end(); ++It)
	{
		Output << It->getID() << " " << It->getPos().x << " " << It->getPos().y << " " << It->getRotation() << std::endl;
		m_savingBar->add();
	}

	Output << std::endl;

	for (std::list<Tile>::iterator It = m_objects.begin(); It != m_objects.end(); ++It)
	{
		Output << It->getID() << " " << It->getPos().x << " " << It->getPos().y << " " << It->getRotation() << std::endl;
		m_savingBar->add();
	}

	Output.close();

	m_state = EDITOR;
}

void Leveleditor::load(const std::string &filename)
{
	std::ifstream Input("data/maps/" + filename + ".map");

	if (Input.fail())
	{
		m_errorString.SetString(StringBuilder::buildString("lvleditor", "errorstring5") + filename + ".map!");
		return;
	}
	
	bool bufBool;
	Input >> bufBool;

	if (!bufBool)
	{
		m_tiles.clear();
		m_objects.clear();
		
		std::string buf;

		Input >> buf;

		for (int i=0; i<300; ++i)
		{
			int bufID;
			Input >> bufID;
			int bufX;
			Input >> bufX;
			int bufY;
			Input >> bufY;
			int bufRot;
			Input >> bufRot;

			m_tiles.push_back(Tile(m_window, bufID, sf::Vector2f(bufX, bufY), bufRot));

			m_loadingBar->add();
		}

		for (int i=0; i<300; ++i)
		{
			int bufID;
			Input >> bufID;
			int bufX;
			Input >> bufX;
			int bufY;
			Input >> bufY;
			int bufRot;
			Input >> bufRot;

			m_objects.push_back(Tile(m_window, bufID, sf::Vector2f(bufX, bufY), bufRot));

			m_loadingBar->add();
		}
	}
	else
	{
		m_errorString.SetString(StringBuilder::buildString("lvleditor", "errorstring6"));
		Input.close();
		return;
	}

	Input.close();

	m_state = EDITOR;
}

bool Leveleditor::quit()
{
	if (m_exit)
		m_state = EDITOR;

	return m_exit;
}

bool Leveleditor::m_loaded = false;
sf::Texture Leveleditor::m_backTex;
sf::Font Leveleditor::m_font;