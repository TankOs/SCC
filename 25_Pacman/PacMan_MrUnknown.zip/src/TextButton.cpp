#include "TextButton.h"

TextButton::TextButton(sf::RenderWindow &window, sf::Font &font, const std::string &text, sf::Vector2f pos):
m_window(window)
{
	m_text.SetFont(font);
	m_text.SetString(text);
	m_text.SetCharacterSize(45);
	m_text.SetOrigin(m_text.GetLocalBounds().Width/2, 45/2);
	m_text.SetPosition(pos);

	m_colBox = sf::FloatRect(pos.x-m_text.GetLocalBounds().Width/2, pos.y-m_text.GetGlobalBounds().Height/2, m_text.GetLocalBounds().Width, 45);

	m_buttonState = NORMAL;

	m_isClicked = false;
}

void TextButton::update()
{
	if (m_colBox.Contains(sf::Mouse::GetPosition(m_window).x, sf::Mouse::GetPosition(m_window).y))
	{
		if (m_buttonState != PRESSED)
			m_buttonState = HOVER;
		m_isClicked = false;
		m_text.SetColor(sf::Color::Yellow);
		m_text.SetCharacterSize(50);
		m_text.SetOrigin(m_text.GetLocalBounds().Width/2, 50/2);

		if (m_buttonState == PRESSED && !sf::Mouse::IsButtonPressed(sf::Mouse::Left))
		{
			m_isClicked = true;
			m_buttonState = HOVER;
		}
		else if (sf::Mouse::IsButtonPressed(sf::Mouse::Left))
		{
			m_text.SetColor(sf::Color(180, 180, 0));
			m_buttonState = PRESSED;
		}
	}
	else
	{
		m_buttonState = NORMAL;
		m_text.SetColor(sf::Color::White);
		m_text.SetCharacterSize(45);
		m_text.SetOrigin(m_text.GetLocalBounds().Width/2, 45/2);
		m_isClicked = false;
	}
}

void TextButton::draw()
{
	m_window.Draw(m_text);
}