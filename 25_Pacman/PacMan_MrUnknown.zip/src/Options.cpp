#include "Options.h"

Options::Options(sf::RenderWindow &window):
m_window(window)
{
	if (!m_loaded)
	{
		m_backTex.LoadFromFile("data/pictures/background.png");
		m_font.LoadFromFile("data/fonts/arcade.ttf");
		
		sf::SoundBuffer buffer;
		m_click.OpenFromFile("data/sounds/pacman.wav");
	
		m_loaded = true;
	}

	m_background.SetTexture(m_backTex);

	m_german = new PictureButton(m_window, "data/langs/german", sf::Vector2f(150, 250));
	m_english = new PictureButton(m_window, "data/langs/english", sf::Vector2f(350, 250));

	m_back = new TextButton(m_window, m_font, StringBuilder::buildString("options", "button1"), sf::Vector2f(100, 600));
	m_accept = new TextButton(m_window, m_font, StringBuilder::buildString("options", "button2"), sf::Vector2f(325, 600));

	m_music = new Slider(m_window, m_font, StringBuilder::buildString("options", "slider1"), sf::Vector2f(230, 400));
	m_sound = new Slider(m_window, m_font, StringBuilder::buildString("options", "slider2"), sf::Vector2f(230, 500));

	restart();
}

Options::~Options()
{
	delete m_german;
	delete m_english;
}

void Options::restart()
{
	m_title.SetFont(m_font);
	m_title.SetCharacterSize(130);
	m_title.SetString(StringBuilder::buildString("options", "title1"));
	m_title.SetPosition(5, 25);
	m_title.SetColor(sf::Color::Yellow);

	m_exit = false;

	m_back->reloadString(StringBuilder::buildString("options", "button1"));
	m_accept->reloadString(StringBuilder::buildString("options", "button2"));

	std::ifstream Options("data/options");

	std::string buf;
	Options >> buf;
	Options >> m_language;
	Options >> buf;
	int xPos = 0;
	Options >> xPos;
	m_music->reloadPosition(xPos);
	Options >> buf;
	xPos = 0;
	Options >> xPos;
	m_sound->reloadPosition(xPos);
	
	m_music->reloadString(StringBuilder::buildString("options", "slider1"));
	m_sound->reloadString(StringBuilder::buildString("options", "slider2"));
}

void Options::update()
{
	m_click.SetVolume(m_sound->getPercent());

	m_german->update();
	m_english->update();
	m_back->update();
	m_accept->update();

	m_music->update();
	
	m_sound->update();
	if (m_sound->isReleased())
	{
		m_click.Play();
	}

	if (m_german->isClicked())
	{
		m_language = m_german->getFile();
		write();
		restart();
	}
	else if (m_english->isClicked())
	{
		m_language = m_english->getFile();
		write();
		restart();
	}
	else if (m_back->isClicked())
	{
		m_exit = true;
	}
	else if (m_accept->isClicked())
	{
		write();
	}
}

void Options::draw()
{
	m_window.Draw(m_background);
	m_window.Draw(m_title);

	m_german->draw();
	m_english ->draw();
	m_back->draw();
	m_accept->draw();

	m_music->draw();
	m_sound->draw();
}

void Options::handleEvent(sf::Event ev)
{
	if (ev.Type == sf::Event::KeyReleased && ev.Key.Code == sf::Keyboard::Escape)
	{
		m_exit = true;
	}
}

void Options::write()
{
	std::ofstream Output("data/options");

	Output << "language " << m_language << std::endl;
	Output << "music " << m_music->getPercent() << std::endl;
	Output << "sound " << m_sound->getPercent() << std::endl;
}

bool Options::m_loaded = false;
sf::Texture Options::m_backTex;
sf::Font Options::m_font;