#include "Ghost.h"
#include <math.h>

Ghost::Ghost(sf::RenderWindow &window, int ID, sf::Vector2f pos):
m_window(window)
{
	m_speed = 80;

	m_isMoving = true;
	m_tileID = 0;

	if (!m_texLoaded)
	{
		m_tex.LoadFromFile("data/pictures/ghosts.png");
		m_texLoaded = true;
	}

	m_ghost.SetTexture(m_tex);
	m_ghost.SetTextureRect(sf::IntRect(ID*22, 0, 22, 22));
	m_ghost.SetOrigin(11, 11);
	m_ghost.SetPosition(pos.x + 16, pos.y + 16);

	m_direction = DIRECTION(rand()%4);
	m_oldDirection = m_direction;

	m_spawnPoint = pos;
	m_oldPos = pos;

	updateColBox();
}

void Ghost::update(float frameTime, sf::Vector2f playerPos)
{
	if (m_tileID > 0 || ((int)m_ghost.GetPosition().x == m_spawnPoint.x+16 && (int)m_ghost.GetPosition().y == m_spawnPoint.y+16))
	{
		if (((int)m_ghost.GetPosition().x > (int)m_ghost.GetPosition().x/32*32 + 14 && (int)m_ghost.GetPosition().x < (int)m_ghost.GetPosition().x/32*32 + 18) &&
			((int)m_ghost.GetPosition().y > (int)m_ghost.GetPosition().y/32*32 + 14 && (int)m_ghost.GetPosition().y < (int)m_ghost.GetPosition().y/32*32 + 18))
			if (m_oldDirection != NONE)	
				m_oldDirection = m_direction;
	}

	if (m_tileID == 1)
		tileID_1();
	else if (m_tileID == 2)
		tileID_2();
	else if (m_tileID == 3)
		tileID_3(playerPos);	
	else if (m_tileID == 4)
		tileID_4(playerPos);


	if (m_oldDirection == 4)
		m_oldDirection = rand()%4;

	if (m_isMoving && m_oldDirection != NONE)
	{
		m_oldPos = m_ghost.GetPosition();

		if (m_oldDirection == RIGHT)
		{
			m_ghost.SetPosition(m_ghost.GetPosition().x + m_speed*frameTime, (int)m_ghost.GetPosition().y/32*32 + 16);
		}
		else if (m_oldDirection == DOWN)
		{
			m_ghost.SetPosition((int)m_ghost.GetPosition().x/32*32 + 16, m_ghost.GetPosition().y + m_speed*frameTime);
		}
		else if (m_oldDirection == LEFT)
		{
			m_ghost.SetPosition(m_ghost.GetPosition().x - m_speed*frameTime, (int)m_ghost.GetPosition().y/32*32 + 16);
		}
		else if (m_oldDirection == UP)
		{
			m_ghost.SetPosition((int)m_ghost.GetPosition().x/32*32 + 16, m_ghost.GetPosition().y - m_speed*frameTime);
		}
	}
	else
	{
		m_oldDirection = NONE;
		m_ghost.SetPosition((int)m_oldPos.x/32*32 + 16, (int)m_oldPos.y/32*32 + 16);
	}

	if (m_ghost.GetPosition().x < 0 + 16)
	{
		m_ghost.SetPosition(m_oldPos);
		m_oldDirection = NONE;
	}
	else if (m_ghost.GetPosition().x > 480 - 16)
	{
		m_ghost.SetPosition(m_oldPos);
		m_oldDirection = NONE;
	}
	else if (m_ghost.GetPosition().y < 0 + 16)
	{
		m_ghost.SetPosition(m_oldPos);
		m_oldDirection = NONE;
	}
	else if (m_ghost.GetPosition().y> 640 - 16)
	{
		m_ghost.SetPosition(m_oldPos);
		m_oldDirection = NONE;
	}

	updateColBox();
}

void Ghost::updateColBox()
{
	m_colBox.Left = m_ghost.GetPosition().x - 11;
	m_colBox.Top = m_ghost.GetPosition().y - 11;
	m_colBox.Width = 22;
	m_colBox.Height = 22;
}

void Ghost::draw()
{
	m_window.Draw(m_ghost);
}

void Ghost::setPosition(sf::Vector2f pos)
{
	m_ghost.SetPosition(pos.x + 16, pos.y + 16);

	updateColBox();
}

void Ghost::giveIDandRot(sf::Vector2f IDrot)
{
	m_isMoving = IDrot.x;
	m_tileID = IDrot.x;
	m_tileRot = IDrot.y;
}

bool Ghost::playerCollision(sf::FloatRect entity)
{
	if (m_colBox.Intersects(entity))
		return true;
	else
		return false;
}

void Ghost::tileID_1()
{
	if (m_oldDirection == 4)
	{
		int buf = rand()%2;
		if (m_tileRot == 0 || m_tileRot == 2)
		{
			if (buf == 0)
				m_direction = UP;
			else
				m_direction = DOWN;
		}
		else if (m_tileRot == 1 || m_tileRot == 3)
		{
			if (buf == 0)
				m_direction = LEFT;
			else
				m_direction = RIGHT;
		}
	}
}

void Ghost::tileID_2()
{
		if (m_oldDirection == RIGHT)
		{
			if (m_tileRot == 1)
				m_direction = DOWN;
			else if (m_tileRot == 2)
				m_direction = UP;
		}
		else if (m_oldDirection == DOWN)
		{
			if (m_tileRot == 2)
				m_direction = LEFT;
			else if (m_tileRot == 3)
				m_direction = RIGHT;
		}
		else if (m_oldDirection == LEFT)
		{
			if (m_tileRot == 0)
				m_direction = DOWN;
			else if (m_tileRot == 3)
				m_direction = UP;
		}
		else if (m_oldDirection == UP)
		{
			if (m_tileRot == 0)
				m_direction = RIGHT;
			else if (m_tileRot == 1)
				m_direction = LEFT;
		}
}

void Ghost::tileID_3(sf::Vector2f playerPos)
{
	float x1 = m_ghost.GetPosition().x-32 - playerPos.x;
	float y1 = m_ghost.GetPosition().y - playerPos.y;
	float z1 = std::sqrt(x1*x1 + y1*y1);
		
	float x2 = m_ghost.GetPosition().x+32 - playerPos.x;
	float y2 = m_ghost.GetPosition().y - playerPos.y;
	float z2 = std::sqrt(x2*x2 + y2*y2);

	float x3 = m_ghost.GetPosition().x - playerPos.x;
	float y3 = m_ghost.GetPosition().y-32 - playerPos.y;
	float z3 = std::sqrt(x3*x3 + y3*y3);

	float x4 = m_ghost.GetPosition().x - playerPos.x;
	float y4 = m_ghost.GetPosition().y+32 - playerPos.y;
	float z4 = std::sqrt(x4*x4 + y4*y4);
		
	if (z1 < z2 && z1 < z3 && z1 < z4)
		m_direction = LEFT;
	else if (z2 < z1 && z2 < z3 && z2 < z4)
		m_direction = RIGHT;
	else if (z3 < z1 && z3 < z2 && z3 < z4)
		m_direction = UP;
	else if (z4 < z1 && z4 < z2 && z4 < z3)
		m_direction = DOWN;
}

void Ghost::tileID_4(sf::Vector2f playerPos)
{
	float x1 = m_ghost.GetPosition().x-32 - playerPos.x;
	float y1 = m_ghost.GetPosition().y - playerPos.y;
	float z1 = std::sqrt(x1*x1 + y1*y1);
		
	float x2 = m_ghost.GetPosition().x+32 - playerPos.x;
	float y2 = m_ghost.GetPosition().y - playerPos.y;
	float z2 = std::sqrt(x2*x2 + y2*y2);

	float x3 = m_ghost.GetPosition().x - playerPos.x;
	float y3 = m_ghost.GetPosition().y-32 - playerPos.y;
	float z3 = std::sqrt(x3*x3 + y3*y3);

	float x4 = m_ghost.GetPosition().x - playerPos.x;
	float y4 = m_ghost.GetPosition().y+32 - playerPos.y;
	float z4 = std::sqrt(x4*x4 + y4*y4);
	
	if (m_tileRot == 0)
	{
		if (z2 < z3 && z2 < z4)
			m_direction = RIGHT;
		else if (z3 < z2 && z3 < z4)
			m_direction = UP;
		else if (z4 < z2 && z4 < z3)
			m_direction = DOWN;
		if (z1 < z2 && z1 < z3 && z1 < z4)
		{
			if (m_oldDirection == LEFT)
				m_direction = DOWN;
			else
				m_direction = DIRECTION(m_oldDirection);
		}
	}
	else if (m_tileRot == 1)
	{
		if (z1 < z2 && z1 < z4)
			m_direction = LEFT;
		else if (z2 < z1 && z2 < z4)
			m_direction = RIGHT;
		else if (z4 < z1 && z4 < z2)
			m_direction = DOWN;
		if (z3 < z1 && z3 < z2 && z3 < z4)
		{
			if (m_oldDirection == UP)
				m_direction = RIGHT;
			else
				m_direction = DIRECTION(m_oldDirection);
		}
	}
	else if (m_tileRot == 2)
	{
		if (z1 < z3 && z1 < z4)
			m_direction = LEFT;
		else if (z3 < z2 && z3 < z4)
			m_direction = UP;
		else if (z4 < z2 && z4 < z3)
			m_direction = DOWN;
		if (z2 < z1 && z2 < z3 && z2 < z4)
		{
			if (m_oldDirection == RIGHT)
				m_direction = UP;
			else
				m_direction = DIRECTION(m_oldDirection);
		}
	}
	else if (m_tileRot == 3)
	{
		if (z1 < z2 && z1 < z4)
			m_direction = LEFT;
		else if (z2 < z1 && z2 < z4)
			m_direction = RIGHT;
		else if (z3 < z2 && z3 < z4)
			m_direction = UP;
		if (z4 < z1 && z4 < z2 && z4 < z3)
		{
			if (m_oldDirection == DOWN)
				m_direction = LEFT;
			else
				m_direction = DIRECTION(m_oldDirection);
		}
	}
}

sf::Texture Ghost::m_tex;
bool Ghost::m_texLoaded = false;