#include "StringBuilder.h"
#include <string>

std::string StringBuilder::buildString(const std::string &header, const std::string &row)
{
	std::string buf1, buf2, buf3, language;

	std::ifstream Options("data/options");
	
	while (!Options.eof() && !Options.fail())
	{
		Options >> buf1;

		if (buf1 == "language")
			Options >> language;
	}

	Options.close();

	std::ifstream Input(language + ".lang");

	while (!Input.eof() && !Input.fail())
	{
		Input >> buf2;

		if (buf2 == header)
		{
			Input >> buf3;
			
			if (buf3 == row)
				std::getline(Input, m_string);
		}
	}

	Input.close();

	return m_string.erase(0, 1);
}

std::string StringBuilder::m_string;