#ifndef game_h
#define game_h

#include <fstream>
#include <sstream>

#include <list>

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "Tilemap.h"
#include "Player.h"
#include "Ghost.h"
#include "Score.h"
#include "TextButton.h"
#include "PictureButton.h"
#include "TextBox.h"
#include "StringBuilder.h"

class HighscoreElement
{
public:
	HighscoreElement(int points, const std::string &name);

	int points() {return m_points;}
	std::string name() {return m_name;}

private:
	int m_points;
	std::string m_name;
};

class Game
{
public:
	Game(sf::RenderWindow &window);
	~Game();

	void restart();
	void nextLvl();

	void update(float frameTime);
	void draw();

	void handleEvent(sf::Event ev);

	bool quit();
	bool options() {return m_settings;}

private:
	enum STATE
	{
		LVLSELECTION,
		GAME,
		PAUSE,
		GAMEOVER
	} m_state;

	sf::RenderWindow &m_window;

	static bool m_loaded;
	static sf::Texture m_backTex;
	static sf::Font m_font;
	sf::Sprite m_background;
	sf::Text m_title;
	sf::Text m_title2;
	sf::Text m_title3;
	sf::Text m_errorString;

	std::string m_lvlFile;
	
	bool m_exit;
	bool m_settings;
	bool m_nameEntered;
	bool m_failure;

	int m_level;

	Tilemap *m_tilemap;
	Player *m_player;
	Score *m_score;
	TextButton *m_continue;
	TextButton *m_restart;
	TextButton *m_lvlSelection;
	TextButton *m_quit;
	TextButton *m_options;
	PictureButton *m_lvl1;
	PictureButton *m_lvl2;
	PictureButton *m_lvl3;
	TextBox *m_load;
	TextBox *m_name;

	std::list<Ghost> m_ghosts;
	std::list<HighscoreElement> m_highscore;
};

#endif