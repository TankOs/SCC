#include <iostream>
#include <fstream>

#include <SFML/Graphics.hpp>

#include "Menu.h"
#include "Game.h"
#include "Leveleditor.h"
#include "Options.h"

int main()
{
	srand(time(0));

	enum GAMESTATE
	{
		MENU,
		GAME,
		LEVELEDITOR,
		OPTIONS
	} gamestate;

	sf::Texture bottombarTexture;
	bottombarTexture.LoadFromFile("data/pictures/bottombar.png");
	sf::Sprite bottombar(bottombarTexture);
	bottombar.SetPosition(0, 640);

	std::fstream Input("data/options");

	std::string buf;
	int volume;

	while (!Input.eof())
	{
		Input >> buf;

		if (buf == "music")
			Input >> volume;
	}

	sf::Music menuMusic, lvleditorMusic;
	menuMusic.OpenFromFile("data/music/menu.ogg");
	lvleditorMusic.OpenFromFile("data/music/lvleditor.ogg");
	menuMusic.SetLoop(true);
	lvleditorMusic.SetLoop(true);
	menuMusic.SetVolume(volume);
	lvleditorMusic.SetVolume(volume);
	menuMusic.Play();


	sf::Clock frame_time;
	float frameTime;

	sf::RenderWindow window(sf::VideoMode(480, 680, 32), "PacMan");
	window.SetFramerateLimit(60);

	Menu menu(window);
	Game game(window);
	Leveleditor leveleditor(window);
	Options options(window);

	gamestate = MENU;
	int oldState = gamestate;

	sf::Event ev;
	while (window.IsOpen())
	{
		frame_time.Restart();

		while (window.PollEvent(ev))
		{
			if (gamestate == MENU)
				menu.handleEvent(ev);
			else if (gamestate == GAME)
				game.handleEvent(ev);
			else if (gamestate == LEVELEDITOR)
				leveleditor.handleEvent(ev);
			else if (gamestate == OPTIONS)
				options.handleEvent(ev);
			
			if (ev.Type == sf::Event::Closed)
				window.Close();
		}

		window.Clear();

		window.Draw(bottombar);

		if(gamestate == MENU)
		{
			oldState = MENU;
			menu.update();
			menu.draw();
			
			if (menu.changeGamestate())
			{
				if (menu.changeGamestate() == 2)
					leveleditor.restart();
				
				gamestate = GAMESTATE(menu.changeGamestate());
			}
		}
		else if (gamestate == GAME)
		{
			oldState = GAME;
			game.update(frameTime);
			game.draw();

			if (game.quit())
			{
				gamestate = MENU;
				game.restart();
			}
			if (game.options())
			{
				gamestate = OPTIONS;
			}
		}
		else if (gamestate == LEVELEDITOR)
		{
			leveleditor.update();
			leveleditor.draw();

			if (leveleditor.quit())
			{
				gamestate = MENU;
				menu.reloadStrings();
			}
		}
		else if (gamestate == OPTIONS)
		{
			options.update();
			options.draw();

			if (options.quit())
			{
				gamestate = GAMESTATE(oldState);
				options.restart();
				menu.reloadStrings();
			}
		}
		
		if (gamestate == GAME)
			menuMusic.Stop();
		else if (gamestate == MENU && menuMusic.GetStatus() != menuMusic.Playing)
		{
			menuMusic.Play();
			lvleditorMusic.Stop();
		}
		else if (gamestate == LEVELEDITOR && lvleditorMusic.GetStatus() != lvleditorMusic.Playing)
		{
			lvleditorMusic.Play();
			menuMusic.Stop();
		}

		menuMusic.SetVolume(options.getMusicVolume());
		lvleditorMusic.SetVolume(options.getMusicVolume());

		window.Display();

		frameTime = frame_time.GetElapsedTime().AsSeconds();
	}

	return 0;
}