#ifndef player_h
#define player_h

#include <iostream>
#include <fstream>

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

class Player
{
public:
	Player(sf::RenderWindow &window, sf::Vector2f spawnPoint);

	void update(float frameTime);
	void draw();

	void setPos(sf::Vector2f pos);
	sf::Vector2f getPos() {return m_pos;}

	void handleEvent(sf::Event ev);
	
	void kill();
	void restart(sf::Vector2f spawnPoint);
	
	void reloadVolume();
	void pauseSound() {m_pacmanSound.Pause();}

	void isMoving(int tileID);

	bool isAlive() {return m_isLiving;}

	sf::FloatRect getColBox() {return m_colBox;}

private:
	enum DIRECTION
	{
		RIGHT,
		DOWN, 
		LEFT,
		UP,
		NONE
	} m_direction;
	int m_oldDirection;
	bool m_buttonPressed;

	void updateColBox();

	sf::Clock m_animationTimer;

	sf::RenderWindow &m_window;

	static sf::Texture m_texture;
	static bool m_textureLoaded;
	sf::Sprite m_player;
	static sf::SoundBuffer m_pacmanBuffer;
	sf::Sound m_pacmanSound;

	sf::Vector2f m_pos;
	sf::Vector2f m_oldPos;
	sf::Vector2f m_spawnPoint;

	int m_lives;
	bool m_isLiving;
	sf::Texture m_texture2;
	sf::Sprite m_lifeSprite;

	int m_tileID;
	bool m_isMoving;
	sf::FloatRect m_colBox;
};

#endif