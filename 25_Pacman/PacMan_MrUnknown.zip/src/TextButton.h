#ifndef textbutton_h
#define textbutton_h

#include <SFML/Graphics.hpp>

class TextButton
{
public:
	TextButton(sf::RenderWindow &window, sf::Font &font, const std::string &text, sf::Vector2f pos);

	void update();
	void draw();

	void reloadString(const std::string &string) {m_text.SetString(string);}

	bool isClicked() {return m_isClicked;}

private:
	enum STATE
	{
		NORMAL,
		HOVER,
		PRESSED
	} m_buttonState;

	sf::RenderWindow &m_window;

	sf::Text m_text;
	sf::FloatRect m_colBox;

	bool m_isClicked;
};

#endif