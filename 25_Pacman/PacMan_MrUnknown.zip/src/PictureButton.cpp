#include "PictureButton.h"

PictureButton::PictureButton(sf::RenderWindow &window, const std::string &filename, sf::Vector2f pos):
m_window(window)
{
	m_tex.LoadFromFile(filename + ".png");
	m_sprite.SetTexture(m_tex);
	m_sprite.SetOrigin(m_tex.GetWidth()/2, m_tex.GetHeight()/2);
	m_sprite.SetPosition(pos);

	m_File = filename;
}

void PictureButton::update()
{
	if (m_sprite.GetGlobalBounds().Contains(sf::Mouse::GetPosition(m_window).x, sf::Mouse::GetPosition(m_window).y))
	{
		if (m_buttonState != PRESSED)
			m_buttonState = HOVER;
		m_isClicked = false;
		m_sprite.SetScale(1.2f, 1.2f);

		if (m_buttonState == PRESSED && !sf::Mouse::IsButtonPressed(sf::Mouse::Left))
		{
			m_isClicked = true;
			m_buttonState = HOVER;
		}
		else if (sf::Mouse::IsButtonPressed(sf::Mouse::Left))
		{
			m_buttonState = PRESSED;
		}
	}
	else
	{
		m_buttonState = NORMAL;
		m_sprite.SetScale(1, 1);
		m_isClicked = false;
	}
}

void PictureButton::draw()
{
	m_window.Draw(m_sprite);
}

std::string PictureButton::getFile()
{
	return m_File;
}