#ifndef tilemap_h
#define tilemap_h

#include <list>
#include <iostream>
#include <fstream>

#include "Tile.h"

class Tilemap
{
public:
	Tilemap(sf::RenderWindow &window);

	void draw();

	void load(const std::string &filename);

	sf::Vector2f checkCollision(sf::FloatRect entity);
	int checkCoinCollision(sf::FloatRect entity);

	sf::Vector2f getSpawn();
	sf::Vector2f getGhostSpawn(int ID);

	int getCoins() {return m_coins;}

	bool errorOccured() {return m_failure;}

private:
	sf::RenderWindow &m_window;

	bool m_failure;

	int m_coins;

	std::list<Tile> m_tiles;
	std::list<Tile> m_objects;
};

#endif