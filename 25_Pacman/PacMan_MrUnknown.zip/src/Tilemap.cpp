#include "Tilemap.h"

Tilemap::Tilemap(sf::RenderWindow &window):
m_window(window)
{
	m_failure = false;
}

void Tilemap::draw()
{
	for (std::list<Tile>::iterator It = m_tiles.begin(); It != m_tiles.end(); ++It)
	{
		It->draw();
	}

	for (std::list<Tile>::iterator It = m_objects.begin(); It != m_objects.end(); ++It)
	{
		It->draw();
	}
}

void Tilemap::load(const std::string &filename)
{
	m_tiles.clear();
	m_objects.clear();

	std::ifstream Input(filename);

	if (Input.fail())
	{
		m_failure = true;
		return;
	}
	
	m_failure = false;

	int buf1;
	Input >> buf1;
	std::string buf2;
	Input >> buf2;

	for (int i=0; i<300; ++i)
	{
		int bufID;
		Input >> bufID;
		int bufX;
		Input >> bufX;
		int bufY;
		Input >> bufY;
		int bufRot;
		Input >> bufRot;

		m_tiles.push_back(Tile(m_window, bufID, sf::Vector2f(bufX, bufY), bufRot));
	}

	for (int i=0; i<300; ++i)
	{
		int bufID;
		Input >> bufID;
		int bufX;
		Input >> bufX;
		int bufY;
		Input >> bufY;
		int bufRot;
		Input >> bufRot;

		m_objects.push_back(Tile(m_window, bufID, sf::Vector2f(bufX, bufY), bufRot));
	}

	m_coins = 0;

	for (std::list<Tile>::iterator It = m_objects.begin(); It != m_objects.end(); ++It)
	{
		if (It->getID() == 6)
			++m_coins;
	}
}

sf::Vector2f Tilemap::checkCollision(sf::FloatRect entity)
{
	sf::Vector2f buf;
	for (std::list<Tile>::iterator It = m_tiles.begin(); It != m_tiles.end(); ++It)
	{	
		if (It->checkCollision(entity).x < 5)
		{
			if (It->checkCollision(entity).x == 0)
				return sf::Vector2f();
			else if (It->checkCollision(entity).x != 0)
				buf = It->checkCollision(entity);
		}
	}

	return buf;
}

int Tilemap::checkCoinCollision(sf::FloatRect entity)
{
	for (std::list<Tile>::iterator It = m_objects.begin(); It != m_objects.end(); ++ It)
	{
		if (It->checkCollision(entity).x == 6)
		{
			It->setID(5);
			--m_coins;
			return 100;
		}
	}

	return 0;
}

sf::Vector2f Tilemap::getSpawn()
{
	for (std::list<Tile>::iterator It = m_objects.begin(); It != m_objects.end(); ++It)
	{
		if (It->getID() == 7)
			return It->getPos();
	}
}

sf::Vector2f Tilemap::getGhostSpawn(int ID)
{
	for (std::list<Tile>::iterator It = m_objects.begin(); It != m_objects.end(); ++It)
	{
		if (It->getID() == 8+ID)
			return It->getPos();
	}
}