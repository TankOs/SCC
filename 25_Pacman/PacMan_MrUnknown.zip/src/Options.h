#ifndef options_h
#define options_h

#include <iostream>
#include <fstream>

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "TextButton.h"
#include "PictureButton.h"
#include "StringBuilder.h"
#include "Slider.h"

class Options
{
public:
	Options(sf::RenderWindow &window);
	~Options();

	void restart();

	void update();
	void draw();

	void handleEvent(sf::Event ev);

	bool quit() {return m_exit;}

	float getMusicVolume() {return m_music->getPercent();}

private:
	void write();

	sf::RenderWindow &m_window;

	sf::Music m_click;

	static bool m_loaded;
	static sf::Texture m_backTex;
	static sf::Font m_font;
	sf::Sprite m_background;
	sf::Text m_title;

	bool m_exit;

	std::string m_language;

	PictureButton *m_german;
	PictureButton *m_english;

	TextButton *m_back;
	TextButton *m_accept;

	Slider *m_music;
	Slider *m_sound;
};

#endif