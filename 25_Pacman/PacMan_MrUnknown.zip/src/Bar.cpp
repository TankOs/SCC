#include "Bar.h"

Bar::Bar(sf::RenderWindow &window, sf::Vector2f pos):
m_window(window)
{
	if (!m_loaded)
	{
		m_tex.LoadFromFile("data/pictures/bar.png");
		m_loaded = true;
	}
	
	m_back.SetTexture(m_tex);
	m_back.SetTextureRect(sf::IntRect(0, 0, 460, 25));
	m_back.SetPosition(pos);

	m_fore.SetTexture(m_tex);
	m_fore.SetTextureRect(sf::IntRect(0, 25, 0, 25));
	m_fore.SetPosition(pos);

	value = 0;
	percent = 0;

	m_hasLoaded = false;
}

void Bar::update()
{
	if (percent == 100)
	{
		m_hasLoaded = true;
		value = 0;
		percent = 0;
		m_fore.SetTextureRect(sf::IntRect(0, 25, 0, 25));
	}
	else
		m_hasLoaded = false;
}

void Bar::draw()
{
	m_window.Draw(m_back);
	m_window.Draw(m_fore);
}

void Bar::add()
{
	++value;
	
	percent = value/6;
	
	m_fore.SetTextureRect(sf::IntRect(0, 25, percent*4.6f, 25));
}

bool Bar::m_loaded = false;
sf::Texture Bar::m_tex;