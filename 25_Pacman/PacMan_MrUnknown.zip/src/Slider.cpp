#include "Slider.h"

Slider::Slider(sf::RenderWindow &window, sf::Font &font, const std::string &string, sf::Vector2f pos):
m_window(window)
{
	if (!m_loaded)
	{
		m_tex.LoadFromFile("data/pictures/slider.png");
		m_loaded = true;
	}

	m_slider.SetTexture(m_tex);
	m_slider.SetTextureRect(sf::IntRect(0, 0, 400, 20));
	m_slider.SetOrigin(200, 0);
	m_slider.SetPosition(pos);
	
	m_button.SetTexture(m_tex);
	m_button.SetTextureRect(sf::IntRect(400, 0, 20, 20));
	m_button.SetOrigin(10, 0);
	m_button.SetPosition(pos);

	m_text.SetCharacterSize(30);
	m_text.SetFont(font);
	m_text.SetString(string);
	m_text.SetOrigin(m_text.GetGlobalBounds().Width/2, 50);
	m_text.SetPosition(pos);

	value = m_slider.GetGlobalBounds().Width/2;

	x = pos.x - 200;

	m_released = false;
}

void Slider::update()
{
	if (m_button.GetGlobalBounds().Contains(sf::Mouse::GetPosition(m_window).x, sf::Mouse::GetPosition(m_window).y))
	{
		m_button.SetScale(1.2f, 1.2f);

		if (!sf::Mouse::IsButtonPressed(sf::Mouse::Left) && m_released)
		{
			m_state = HOVER;
			m_released = false;
		}

		if (sf::Mouse::IsButtonPressed(sf::Mouse::Left))
			m_state = PRESSED;
		else if (m_state == PRESSED && !sf::Mouse::IsButtonPressed(sf::Mouse::Left))
			m_released = true;
	}
	else if (m_state != PRESSED || !sf::Mouse::IsButtonPressed(sf::Mouse::Left))
	{
		m_state = NORMAL;
		m_button.SetScale(1.f, 1.f);
	}

	if (m_state == PRESSED)
	{
		if (value >= 0 && value <= 400)
			m_button.SetPosition(sf::Mouse::GetPosition(m_window).x, m_button.GetPosition().y);
	}

	if (value < 0)
	{
		m_button.SetPosition(x, m_button.GetPosition().y);
		m_state = NORMAL;
	}
	else if (value > 400)
	{
		m_button.SetPosition(400 + x, m_button.GetPosition().y);
		m_state = NORMAL;
	}

	value = m_button.GetPosition().x - x;

	percent = value / 4;
}

void Slider::draw()
{
	m_window.Draw(m_slider);
	m_window.Draw(m_button);
	m_window.Draw(m_text);
}

void Slider::reloadString(const std::string &text)
{
	m_text.SetString(text);
}

void Slider::reloadPosition(int xPos)
{
	percent = xPos;
	xPos *= 4;
	m_button.SetPosition(xPos + x, m_button.GetPosition().y);
}

bool Slider::m_loaded = false;
sf::Texture Slider::m_tex;