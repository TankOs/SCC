#include "Menu.h"

Menu::Menu(sf::RenderWindow &window):
m_window(window)
{
	if (!m_loaded)
	{
		m_backgroundTex.LoadFromFile("data/pictures/background.png");
		m_font.LoadFromFile("data/fonts/arcade.ttf");
		m_loaded = true;
	}

	m_background.SetTexture(m_backgroundTex);

	m_title.SetFont(m_font);
	m_title.SetColor(sf::Color::Yellow);

	m_game = new TextButton(m_window, m_font, StringBuilder::buildString("menu", "button1"), sf::Vector2f(230, 330));
	m_leveleditor = new TextButton(m_window, m_font, StringBuilder::buildString("menu", "button2"), sf::Vector2f(230, 400));
	m_highscore = new TextButton(m_window, m_font, StringBuilder::buildString("menu", "button3"), sf::Vector2f(230, 470));
	m_back = new TextButton(m_window, m_font, StringBuilder::buildString("menu", "button4"), sf::Vector2f(230, 580));
	m_options = new TextButton(m_window, m_font, StringBuilder::buildString("menu", "button5"), sf::Vector2f(230, 530));

	m_state = MENU;
}

Menu::~Menu()
{
	delete m_game;
	delete m_leveleditor;
	delete m_highscore;
	delete m_back;
	delete m_options;
}

void Menu::reloadStrings()
{
	m_game->reloadString(StringBuilder::buildString("menu", "button1"));
	m_leveleditor->reloadString(StringBuilder::buildString("menu", "button2"));
	m_highscore->reloadString(StringBuilder::buildString("menu", "button3"));
	m_back->reloadString(StringBuilder::buildString("menu", "button4"));
	m_options->reloadString(StringBuilder::buildString("menu", "button5"));
}

void Menu::update()
{
	if (m_state == MENU)
	{
		m_game->update();
		m_leveleditor->update();
		m_highscore->update();
		m_options->update();

		if (m_highscore->isClicked())
		{
			m_state = HIGHSCORE;
			loadHighscore();
		}
	}
	else if (m_state == HIGHSCORE)
	{
		m_back->update();

		if (m_back->isClicked())
		{
			m_state = MENU;
		}
	}
}

void Menu::draw()
{
	m_window.Draw(m_background);

	if (m_state == MENU)
	{
		m_title.SetCharacterSize(150);
		m_title.SetString("PacMan");
		m_title.SetPosition(25, 40);
		m_window.Draw(m_title);

		m_game->draw();
		m_leveleditor->draw();
		m_highscore->draw();
		m_options->draw();
	}
	else if (m_state == HIGHSCORE)
	{
		m_title.SetCharacterSize(100);
		m_title.SetString("Highscore");
		m_title.SetPosition(40, 40);
		m_window.Draw(m_title);

		for (std::list<sf::Text>::iterator It = m_scores.begin(); It != m_scores.end(); ++It)
			m_window.Draw(*It);

		m_back->draw();
	}
}

int Menu::changeGamestate()
{
	if (m_game->isClicked())
		return 1;
	else if (m_leveleditor->isClicked())
		return 2;
	else if (m_options->isClicked())
		return 3;
	else 
		return 0;
}

void Menu::handleEvent(sf::Event ev)
{
	if (ev.Type == sf::Event::KeyReleased)
	{
		if (ev.Key.Code == sf::Keyboard::Escape)
		{
			if (m_state == HIGHSCORE)
				m_state = MENU;
		}
	}
}

void Menu::loadHighscore()
{
	m_scores.clear();

	std::ifstream Input("data/highscore");

	for (int i=0; i<10; ++i)
	{
		std::string name;
		Input >> name;
		std::string points;
		Input >> points;
		std::string buf;

		std::stringstream bufstream;
		bufstream << i+1;
		bufstream >> buf;

		buf += ") " + name + ": " + points;

		sf::Text m_bufString;
		m_bufString.SetString(buf);
		m_bufString.SetFont(m_font);
		m_bufString.SetCharacterSize(30);
		m_bufString.SetPosition(50, 200+i*35);

		m_scores.push_back(m_bufString);
	}

	Input.close();
}

bool Menu::m_loaded = false;
sf::Texture Menu::m_backgroundTex;
sf::Font Menu::m_font;