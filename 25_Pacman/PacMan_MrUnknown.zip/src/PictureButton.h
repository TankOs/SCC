#ifndef picturebutton_h
#define picturebutton_h

#include <iostream>

#include <SFML/Graphics.hpp>

class PictureButton
{
public:
	PictureButton(sf::RenderWindow &window, const std::string &filename, sf::Vector2f pos);

	void update();
	void draw();

	std::string getFile();

	bool isClicked() {return m_isClicked;}

private:
	enum BUTTONSTATE
	{
		NORMAL,
		HOVER,
		PRESSED
	} m_buttonState;

	sf::RenderWindow &m_window;

	bool m_isClicked;

	std::string m_File;

	sf::Texture m_tex;
	sf::Sprite m_sprite;
};

#endif