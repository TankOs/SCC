#include "Tile.h"

Tile::Tile(sf::RenderWindow &window, sf::Vector2f pos):
m_window(window)
{
	if(!m_textureLoaded)
		m_texture.LoadFromFile("data/pictures/tiles.png");

	m_tile.SetTexture(m_texture);
	m_tile.SetTextureRect(sf::IntRect(0, 0, 32, 32));
	m_tile.SetOrigin(16, 16);
	m_tile.SetPosition(pos.x + 16, pos.y + 16);
	
	m_colBox = sf::FloatRect(pos.x, pos.y, 32, 32);
	m_colBox2 = sf::FloatRect(pos.x, pos.y, 32, 32);

	m_ID = 0;
	m_pos = pos;
	m_rot = 0;
}

Tile::Tile(sf::RenderWindow &window, int ID, sf::Vector2f pos):
m_window(window)
{
	if(!m_textureLoaded)
		m_texture.LoadFromFile("data/pictures/tiles.png");

	m_tile.SetTexture(m_texture);
	m_tile.SetTextureRect(sf::IntRect(ID*32, 0, 32, 32));
	m_tile.SetOrigin(16, 16);
	m_tile.SetPosition(pos.x + 16, pos.y + 16);
	
	m_colBox = sf::FloatRect(pos.x, pos.y, 32, 32);

	m_ID = ID;
	m_pos = pos;
	m_rot = 0;

	if (m_ID == 6)
		m_colBox2 = sf::FloatRect(pos.x+11, pos.y+11, 7, 7);
	else
		m_colBox2 = sf::FloatRect(pos.x, pos.y, 32, 32);
}

Tile::Tile(sf::RenderWindow &window, int ID, sf::Vector2f pos, int rotation):
m_window(window)
{
	if(!m_textureLoaded)
		m_texture.LoadFromFile("data/pictures/tiles.png");

	m_textureLoaded = true;

	m_tile.SetTexture(m_texture);
	m_tile.SetTextureRect(sf::IntRect(ID*32, 0, 32, 32));
	m_tile.SetOrigin(16, 16);
	m_tile.SetPosition(pos.x + 16, pos.y + 16);
	
	m_colBox = sf::FloatRect(pos.x, pos.y, 32, 32);

	m_ID = ID;
	m_pos = pos;

	setRotation(rotation);

	if (m_ID == 6)
		m_colBox2 = sf::FloatRect(pos.x+14, pos.y+14, 3, 3);
	else
		m_colBox2 = sf::FloatRect(pos.x, pos.y, 32, 32);
}

void Tile::draw()
{
	m_window.Draw(m_tile);
}

void Tile::setPos(sf::Vector2f pos)
{
	m_tile.SetPosition(pos);
}

void Tile::setRotation(int rotation)
{
	m_rot = rotation;
	
	m_tile.SetRotation(m_rot*90);
}

void Tile::setID(int ID)
{
	m_ID = ID;

	m_tile.SetTextureRect(sf::IntRect(ID*32, 0, 32, 32));

	if (m_ID == 6)
		m_colBox2 = sf::FloatRect(m_pos.x+14, m_pos.y+14, 3, 3);
	else
		m_colBox2 = sf::FloatRect(m_pos.x, m_pos.y, 32, 32);
}

sf::Vector2f Tile::checkCollision(sf::FloatRect player)
{
	if (m_colBox2.Intersects(player))
	{
		return sf::Vector2f(m_ID, m_rot);
	}
	else 
		return sf::Vector2f(12, 12);
}

bool Tile::checkMouseCollision(sf::Vector2f mouse)
{
	if (m_colBox.Contains(mouse))
	{
		return true;
	}
	else
	{
		return false;
	}
}

sf::Texture Tile::m_texture;
bool Tile::m_textureLoaded = false;