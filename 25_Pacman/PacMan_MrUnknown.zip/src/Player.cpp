#include "Player.h"

Player::Player(sf::RenderWindow &window, sf::Vector2f spawnPoint):
m_window(window)
{
	if (!m_textureLoaded)
	{
		m_texture.LoadFromFile("data/pictures/player.png");	
		m_texture2.LoadFromFile("data/pictures/lives.png");
		m_pacmanBuffer.LoadFromFile("data/sounds/pacman.wav");
		m_textureLoaded = true;
	}

	m_pacmanSound.SetBuffer(m_pacmanBuffer);
	m_pacmanSound.SetLoop(true);

	m_player.SetTexture(m_texture);
	m_player.SetTextureRect(sf::IntRect(0, 0, 22, 22));
	m_player.SetOrigin(11, 11);
	
	m_lifeSprite.SetTexture(m_texture2);
	m_lifeSprite.SetPosition(370, 643);

	restart(spawnPoint);
}

void Player::update(float frameTime)
{
	if (!m_isLiving)
		return;

	if (m_tileID > 1 || ((int)m_player.GetPosition().x == m_spawnPoint.x+16 && (int)m_player.GetPosition().y == m_spawnPoint.y+16))
	{
		if (((int)m_player.GetPosition().x > (int)m_player.GetPosition().x/32*32 + 14 && (int)m_player.GetPosition().x < (int)m_player.GetPosition().x/32*32 + 18) &&
			((int)m_player.GetPosition().y > (int)m_player.GetPosition().y/32*32 + 14 && (int)m_player.GetPosition().y < (int)m_player.GetPosition().y/32*32 + 18))
		{
			if (m_oldDirection != NONE || m_buttonPressed == true)
				m_oldDirection = m_direction;
		}
	}
	else if ((m_oldDirection == 0 && m_direction == 2) || (m_oldDirection == 2 && m_direction == 0) ||
			 (m_oldDirection == 1 && m_direction == 3) || (m_oldDirection == 3 && m_direction == 1))
		m_oldDirection = m_direction;

	if (m_isMoving)
	{
		m_oldPos = m_player.GetPosition();

		if (m_oldDirection == RIGHT)
		{
			m_player.SetPosition(m_player.GetPosition().x + 100*frameTime, (int)m_player.GetPosition().y/32*32 + 16);
			m_player.SetRotation(m_oldDirection*90);
		}
		else if (m_oldDirection == DOWN)
		{
			m_player.SetPosition((int)m_player.GetPosition().x/32*32 + 16, m_player.GetPosition().y + 100*frameTime);
			m_player.SetRotation(m_oldDirection*90);
		}
		else if (m_oldDirection == LEFT)
		{
			m_player.SetPosition(m_player.GetPosition().x - 100*frameTime, (int)m_player.GetPosition().y/32*32 + 16);
			m_player.SetRotation(m_oldDirection*90);
		}
		else if (m_oldDirection == UP)
		{
			m_player.SetPosition((int)m_player.GetPosition().x/32*32 + 16, m_player.GetPosition().y - 100*frameTime);
			m_player.SetRotation(m_oldDirection*90);
		}
	}
	else
	{
		m_oldDirection = NONE;
		m_player.SetPosition((int)m_oldPos.x/32*32 + 16, (int)m_oldPos.y/32*32 + 16);
	}

	if (m_player.GetPosition().x < 0 + 16)
		m_player.SetPosition(m_oldPos);
	else if (m_player.GetPosition().x > 480 - 16)
		m_player.SetPosition(m_oldPos);
	else if (m_player.GetPosition().y < 0 + 16)
		m_player.SetPosition(m_oldPos);
	else if (m_player.GetPosition().y> 640 - 16)
		m_player.SetPosition(m_oldPos);

	m_pos = m_player.GetPosition();
	updateColBox();

	if (m_animationTimer.GetElapsedTime().AsMilliseconds() < 75)
		m_player.SetTextureRect(sf::IntRect(0, 0, 22, 22));

	else if (m_animationTimer.GetElapsedTime().AsMilliseconds() > 75 && m_animationTimer.GetElapsedTime().AsMilliseconds() < 150)
		m_player.SetTextureRect(sf::IntRect(22, 0, 22, 22));

	else if (m_animationTimer.GetElapsedTime().AsMilliseconds() > 150 && m_animationTimer.GetElapsedTime().AsMilliseconds() < 225)
		m_player.SetTextureRect(sf::IntRect(44, 0, 22, 22));

	else if (m_animationTimer.GetElapsedTime().AsMilliseconds() > 225 && m_animationTimer.GetElapsedTime().AsMilliseconds() < 300)
		m_player.SetTextureRect(sf::IntRect(66, 0, 22, 22));

	else if (m_animationTimer.GetElapsedTime().AsMilliseconds() > 300)
		m_animationTimer.Restart();

	if (m_pacmanSound.GetStatus() != m_pacmanSound.Playing && m_oldPos != m_player.GetPosition())
		m_pacmanSound.Play();
	else if (m_oldPos == m_player.GetPosition())
		m_pacmanSound.Stop();
}

void Player::draw()
{
	if (!m_isLiving)
		return;

	m_window.Draw(m_player);
	m_window.Draw(m_lifeSprite);
}

void Player::setPos(sf::Vector2f pos)
{
	m_player.SetPosition(pos.x+16, pos.y+16);

	updateColBox();
}

void Player::handleEvent(sf::Event ev)
{
	if (ev.Type == sf::Event::KeyPressed)
	{	
		if (ev.Key.Code == sf::Keyboard::Up || ev.Key.Code == sf::Keyboard::W)
			m_direction = UP;
		else if (ev.Key.Code == sf::Keyboard::Right || ev.Key.Code == sf::Keyboard::D)
			m_direction = RIGHT;
		else if (ev.Key.Code == sf::Keyboard::Down || ev.Key.Code == sf::Keyboard::S)
			m_direction = DOWN;
		else if (ev.Key.Code == sf::Keyboard::Left || ev.Key.Code == sf::Keyboard::A)
			m_direction = LEFT;

		m_buttonPressed = true;
	}
	else if (ev.Type == sf::Event::KeyReleased)
		m_buttonPressed = false;
}

void Player::kill()
{
	m_oldDirection = NONE;
	setPos(m_spawnPoint);

	m_lives--;
	
	if (m_lives >= 0)
		m_lifeSprite.SetTextureRect(sf::IntRect(0, 0, m_lives*32, 32));
	
	m_isLiving = m_lives;

	m_pacmanSound.Stop();
}

void Player::restart(sf::Vector2f spawnPoint)
{
	m_player.SetPosition(spawnPoint.x + 16, spawnPoint.y + 16);
	m_lifeSprite.SetTextureRect(sf::IntRect(0, 0, 96, 32));

	m_animationTimer.Restart();

	m_lives = 3;
	m_isLiving = true;

	m_direction = NONE;
	m_oldDirection = NONE;

	m_spawnPoint = spawnPoint;
	m_oldPos = spawnPoint;

	m_buttonPressed = false;

	updateColBox();

	reloadVolume();
}

void Player::updateColBox()
{
	m_colBox.Left = m_player.GetPosition().x-11;
	m_colBox.Top = m_player.GetPosition().y-11;
	m_colBox.Width = 22;
	m_colBox.Height = 22;
}

void Player::isMoving(int tileID)
{
	m_isMoving = tileID;

	m_tileID = tileID;
}

void Player::reloadVolume()
{
	std::ifstream Options("data/options");
	std::string buf;
	float volume;
	while (!Options.eof())
	{
		Options >> buf;
		
		if (buf == "sound")
			Options >> volume;	
	}

	m_pacmanSound.SetVolume(volume);
}

sf::Texture Player::m_texture;
bool Player::m_textureLoaded = false;
sf::SoundBuffer Player::m_pacmanBuffer;