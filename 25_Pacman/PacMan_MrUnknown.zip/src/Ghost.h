#ifndef ghost_h
#define ghost_h

#include <iostream>

#include <SFML/Graphics.hpp>

class Ghost
{
public:
	Ghost(sf::RenderWindow &window, int ID, sf::Vector2f pos);

	void update(float frameTime, sf::Vector2f playerPos);
	void updateColBox();

	void draw();

	void setPosition(sf::Vector2f pos);
	void raiseSpeed() {if (m_speed <= 150) m_speed += 10;}

	void giveIDandRot(sf::Vector2f IDrot);

	sf::FloatRect getColBox() {return m_colBox;}

	bool playerCollision(sf::FloatRect entity);

private:
	enum DIRECTION
	{
		RIGHT,
		DOWN, 
		LEFT,
		UP,
		NONE
	} m_direction;

	void tileID_1();
	void tileID_2();
	void tileID_3(sf::Vector2f playerPos);
	void tileID_4(sf::Vector2f playerPos);

	int m_oldDirection;
	int m_speed;

	sf::RenderWindow &m_window;

	sf::FloatRect m_colBox;

	int m_tileRot;
	int m_tileID;
	sf::Vector2f m_oldPos;
	sf::Vector2f m_spawnPoint;
	bool m_isMoving;

	static sf::Texture m_tex;
	static bool m_texLoaded;
	sf::Sprite m_ghost;
};

#endif