#ifndef stringbuilder_h
#define stringbuilder_h

#include <iostream>
#include <fstream>

class StringBuilder
{
public:
	 static std::string buildString(const std::string &header, const std::string &row);

private:
	 static std::string m_string;
};

#endif