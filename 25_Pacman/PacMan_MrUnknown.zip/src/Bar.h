#ifndef bar_h
#define bar_h

#include <iostream>

#include <sfml/Graphics.hpp>

class Bar
{
public:
	Bar(sf::RenderWindow &window, sf::Vector2f pos);

	void update();
	void draw();

	void add();

	//bool hasLoaded() {return m_hasLoaded;}

private:
	sf::RenderWindow &m_window;

	static bool m_loaded;
	static sf::Texture m_tex;
	sf::Sprite m_back;
	sf::Sprite m_fore;

	int value;
	int percent;

	bool m_hasLoaded;
};

#endif