//
//  FontManager.h
//  Tilemap-Editor
//
//  Created by Arne Dußin on 01.11.11.
//  Copyright (c) 2011 DeyDoo Itec. All rights reserved.
//

#ifndef Tilemap_Editor_FontManager_h
#define Tilemap_Editor_FontManager_h

#include <map>
#include <string>
#include <sfml/Graphics.hpp>

namespace ddi
{
    
    class FontManager
    {
    public:
        ~FontManager();
        
        sf::Font *GetFont(const std::string &FileName);
        sf::Font *defaultFont() {return (GetFont("Data/fonts/DejaVuSans.ttf"));}
        
    private:
        std::map<std::string, sf::Font*> m_Fonts;
        
    };
    
}

#endif
