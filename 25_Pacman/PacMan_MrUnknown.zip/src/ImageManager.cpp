//
//  ImageManager.cpp
//  Tilemap-Editor
//
//  Created by Arne Dußin on 01.11.11.
//  Copyright (c) 2011 DeyDoo Itec. All rights reserved.
//

#include "ImageManager.h"

using namespace ddi;

ImageManager::~ImageManager()
{
	std::map<std::string, sf::Texture*>::iterator It = m_Images.begin();
	
	while (It != m_Images.end())
	{
		delete (It->second);
		++It;
	}
}


sf::Texture *ImageManager::GetTexture(const std::string &FileName)
{
	/*if (m_Images[FileName])
	{
		return m_Images[FileName];
	}*/
    
    for (std::map<std::string, sf::Texture*>::iterator It = m_Images.begin(); It != m_Images.end(); ++It)
    {
        if (It->first == FileName)
            return It->second;
    }
	
	sf::Texture *NewImage = new (sf::Texture);
	if (!NewImage->LoadFromFile(FileName))
	{
		delete NewImage;
		return NULL;
	}
    
    NewImage->SetSmooth(false);
    
	m_Images.insert(std::pair<std::string, sf::Texture*>(FileName, NewImage));
	return NewImage;
}