//
//  ImageManager.h
//  Tilemap-Editor
//
//  Created by Arne Dußin on 01.11.11.
//  Copyright (c) 2011 DeyDoo Itec. All rights reserved.
//

#ifndef Tilemap_Editor_ImageManager_h
#define Tilemap_Editor_ImageManager_h

#include <map>
#include <string>
#include <sfml/Graphics.hpp>

namespace ddi
{

class ImageManager
{
public:
	~ImageManager();
	
	sf::Texture *GetTexture(const std::string &FileName);
	
private:
	std::map<std::string, sf::Texture*> m_Images;
	
};

}
    
#endif
