#include "Score.h"

Score::Score(sf::RenderWindow &window):
m_window(window)
{
	if (!m_loaded)
	{
		m_font.LoadFromFile("data/fonts/arcade.ttf");
		m_loaded = true;
	}

	m_score.SetFont(m_font);
	m_score.SetColor(sf::Color::Black);
	m_score.SetPosition(10, 637);

	m_points = 0;
}

void Score::update(int value)
{
	m_points += value;

	std::stringstream bufStream;
	std::string bufString;
	
	bufStream << std::setfill ('0') << std::setw (6) << m_points;
	bufStream >> bufString;

	m_score.SetString(bufString);
}

void Score::draw()
{
	m_window.Draw(m_score);
}

bool Score::m_loaded = false;
sf::Font Score::m_font;