#ifndef textbox_h
#define textbox_h

#include <iostream>

#include <SFML/Graphics.hpp>

class TextBox
{
public:
	TextBox(sf::RenderWindow &m_window, sf::Vector2f pos);

	void update();
	void draw();

	void handleEvent(sf::Event ev);

	std::string getContent() {return m_content;}
	bool accepted() {return m_accepted;}

private:
	enum STATE
	{
		NORMAL,
		HOVER,
		PRESSED,
		ACTIVE
	} m_state;
	sf::RenderWindow &m_window;

	static bool m_loaded;
	static sf::Texture m_tex;
	static sf::Font m_font;

	bool m_accepted;
	
	sf::Sprite m_sprite;
	sf::Text m_text;
	std::string m_content;
};

#endif