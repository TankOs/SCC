#ifndef tile_h
#define tile_h

#include <iostream>

#include <SFML/Graphics.hpp>

class Tile
{
public:
	Tile(sf::RenderWindow &window, sf::Vector2f pos);
	Tile(sf::RenderWindow &window, int ID, sf::Vector2f pos);
	Tile(sf::RenderWindow &window, int ID, sf::Vector2f pos, int rotation);

	void draw();

	void setPos(sf::Vector2f pos);
	sf::Vector2f getPos() {return m_pos;}

	void setRotation(int rotation);
	int getRotation() {return m_rot;}

	void setID(int ID);
	int getID() {return m_ID;}

	sf::Vector2f checkCollision(sf::FloatRect player);
	bool checkMouseCollision(sf::Vector2f mouse);

private:
	sf::RenderWindow &m_window;

	static sf::Texture m_texture;
	static bool m_textureLoaded;
	sf::Sprite m_tile;

	int m_ID;
	sf::Vector2f m_pos;
	int m_rot;

	sf::FloatRect m_colBox;
	sf::FloatRect m_colBox2;
};

#endif