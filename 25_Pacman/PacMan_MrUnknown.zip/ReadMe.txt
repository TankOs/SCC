SFML Version Used: 2.0

In the LevelEditor use left-click to place Tiles, and the right-click to rotate them.
The yellow Circle is your SpawnPoint and the others are for the Ghosts.

Control the PacMan with your Arrow-keys, or the wasd-Keys.

Credits:

Menu Theme: Home at Last - Ozzed
Leveleditor Theme: Low Tide - The J. Arthur Keenes Band

Graphics: Made by me ;)

If there are any problems with the Copyright, then tell me, I will replace the Music.

just send me an e-mail: tobias.oschmann@gmx.de