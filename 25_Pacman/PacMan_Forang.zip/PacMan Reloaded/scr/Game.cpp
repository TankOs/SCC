#include "Game.hpp"
#include "MainGameState.hpp"
#include "GameOverState.h"

//////////////////////////////////////////////////////////////////////////
Game::Game() : window(sf::VideoMode(800, 600), "PacMan Reloaded", 7U, sf::ContextSettings(0U, 0U, 10U)), postShader(NULL)
{
	srand((unsigned int)time(NULL));
	defaultFont.LoadFromFile("ArcadeClassic.ttf");

	frameTime = 0;
	isRunning = true;
	stateManager.AddGamestate("MainGameState", new MainGameState(*this));
	stateManager.AddGamestate("GameOverState", new GameOverState(*this));
	stateManager.ChangeState("MainGameState");

	renderTexture.Create(window.GetWidth(), window.GetHeight());

	
}

//////////////////////////////////////////////////////////////////////////
Game::~Game()
{
	if (postShader != NULL)
	{
		delete postShader;
		postShader = NULL;
	}
}

//////////////////////////////////////////////////////////////////////////
void Game::Run()
{
	while (isRunning)
	{
		timer.Restart();

		sf::Event event;
		while(window.PollEvent(event))
		{
			stateManager.HandleEvent(event);
			if (event.Type == sf::Event::Closed)
			{
				Exit();
			}
		}

		// Update
		stateManager.Update(frameTime);

		if (postShader != NULL)
		{
			renderTexture.Clear();
			stateManager.Draw();
			renderTexture.Display();

			sf::View oldView = window.GetView();
			window.SetView(sf::View(sf::FloatRect(0, 0, 800, 600)));

			window.Clear();
			window.Draw(sf::Sprite(renderTexture.GetTexture()), sf::RenderStates(postShader));
			window.Display();

			window.SetView(oldView);
		}
		else
		{
			window.Clear();
			stateManager.Draw();
			window.Display();
		}	
		//std::cout << 1000000 / timer.GetElapsedTime().AsMicroseconds() << std::endl;

		frameTime = timer.GetElapsedTime().AsSeconds();
		if (frameTime > 0.1)
		{
			frameTime = 0.1;
		}
		
	}
}
//////////////////////////////////////////////////////////////////////////
void Game::Exit()
{
	isRunning = false;
}
//////////////////////////////////////////////////////////////////////////
sf::RenderTarget& Game::GetRenderTarget()
{
	if (postShader != NULL)
	{
		return renderTexture;
	}
	else
	{
		return window;
	}
}
//////////////////////////////////////////////////////////////////////////
StateManager& Game::GetStateManager()
{
	return stateManager;
}

//////////////////////////////////////////////////////////////////////////
TextureManager& Game::GetTextureManager()
{
	return textureManager;
}

//////////////////////////////////////////////////////////////////////////
sf::Vector2f Game::GetMousePosition()
{
	return GetRenderTarget().ConvertCoords(sf::Mouse::GetPosition(window).x, sf::Mouse::GetPosition(window).y);
}

//////////////////////////////////////////////////////////////////////////
void Game::SetView( const sf::View& view )
{
	GetRenderTarget().SetView(view);
}

//////////////////////////////////////////////////////////////////////////
void Game::SetPostShader( const std::string& filePath )
{
	if (sf::Shader::IsAvailable())
	{
		if (postShader != NULL)
		{
			delete postShader;
			postShader = NULL;
		}
		if (filePath.empty())
		{
			return;
		}
		
		postShader = new sf::Shader;
		postShader->LoadFromFile(filePath, sf::Shader::Fragment);
	}
	
}

//////////////////////////////////////////////////////////////////////////
AudioManager& Game::GetAudioManager()
{
	return audioManager;
}
