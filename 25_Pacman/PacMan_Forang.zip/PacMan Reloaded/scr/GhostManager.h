#ifndef GhostManager_h__
#define GhostManager_h__

#include <list>
#include <sfml/Graphics.hpp>
#include "Ghost.h"


class GhostManager : public sf::Drawable
{
public:
	GhostManager(class Game& game, class Level& level);
	~GhostManager();

	void Update(float dt);

	void AddGhost(sf::Vector2f playerPosition, int difficulty);

	bool CheckCollision(sf::Vector2f center, float r);

	void Clear()
	{
		ghosts.clear();
	}
private:
	virtual void Draw(sf::RenderTarget& target, sf::RenderStates states) const;

	Game& game;
	Level& level;
	std::list<Ghost*> ghosts;
};
#endif // GhostManager_h__