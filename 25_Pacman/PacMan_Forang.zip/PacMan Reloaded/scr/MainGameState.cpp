#include "MainGameState.hpp"
#include <sstream>
#include <iostream>
#include <iomanip>

//////////////////////////////////////////////////////////////////////////
MainGameState::MainGameState(Game& game)
	: BaseState(game), player(game, level, sf::Vector2f(100, 100)),
	  level(game),
	  ghostManager(game, level),
	  scoreText("", game.GetDefaultFont(), 40),
	  time(0),
	  introScreen(*game.GetTextureManager().GetResource("IntroScreen.png")),
	  introSound(*game.GetAudioManager().GetResource("IntroSound.wav")),
	  pixelateShader(NULL),
	  life(3),
	  lifeText("Leben    3", game.GetDefaultFont(), 40),
	  mode("Normal Modus", game.GetDefaultFont()),
	  pickUpSound(*game.GetAudioManager().GetResource("drip.wav"))
{
	camera.SetSize(800, 600);
	MoveCamera();
	
	scoreText.SetPosition(7, 0);
	lifeText.SetPosition(550, 0);
	mode.SetPosition(300, 0);

	backgroundMusicNormal.OpenFromFile("power break-normal.ogg");
	backgroundMusicNormal.SetVolume(70);


	backgroundMusic8Bit.OpenFromFile("Power Break-8bit.ogg");
	backgroundMusic8Bit.SetVolume(0);


	pickUpSound.SetVolume(70);
}

//////////////////////////////////////////////////////////////////////////
MainGameState::~MainGameState()
{
	if (pixelateShader)
	{
		delete pixelateShader;
		pixelateShader = NULL;
	}
}


//////////////////////////////////////////////////////////////////////////
void MainGameState::Init()
{
	difficulty = 0;
	levelNum = 1;
	startLevel(true);

	introSound.Play();
	introIsPlaying = true;
	screenDestroyed = false;
	introScreen.SetColor(sf::Color::White);
	introScreen.SetTexture(*game.GetTextureManager().GetResource("IntroScreen.png"));
	introClock.Restart();

	playerScore = 0;
	scoreText.SetString("Punkte    00000");
	life = 3;
	lifeText.SetString("Leben    3");
}
//////////////////////////////////////////////////////////////////////////
void MainGameState::Exit()
{
	game.SetPostShader("");
	backgroundMusic8Bit.Stop();
	backgroundMusicNormal.Stop();
}
//////////////////////////////////////////////////////////////////////////
void MainGameState::Update( float dt )
{
	
	if (introIsPlaying)
	{
		if (!screenDestroyed)
		{
			if (introClock.GetElapsedTime().AsSeconds() > 4.4f)
			{
				introClock.Restart();
				screenDestroyed = true;
				backgroundMusicNormal.Play();
				backgroundMusic8Bit.Play();
				introScreen.SetTexture(*game.GetTextureManager().GetResource("IntroScreen_Destroyed.png"));
			}
		}
		else
		{
			int alpha = (1 - introClock.GetElapsedTime().AsSeconds() / 3 ) * 255;
			if (alpha < 0)
			{
				alpha = 0;
			}
			introScreen.SetColor(sf::Color(255, 255, 255, alpha));
			if (introClock.GetElapsedTime().AsSeconds() > 3)
			{
				introIsPlaying = false;
			}
		}
		return;
	}
	if (backgroundMusicNormal.GetStatus() == sf::Music::Stopped || backgroundMusic8Bit.GetStatus() == sf::Music::Stopped)
	{
		backgroundMusic8Bit.Play();
		backgroundMusicNormal.Play();
	}
	time += dt;
	if (game.GetPostShader())
	{
		game.GetPostShader()->SetParameter("time", time);
	}
	std::cout << modeTimer.GetElapsedTime().AsSeconds() << std::endl;
	if (modeTimer.GetElapsedTime().AsSeconds() > 15)
	{
		
		modeTimer.Restart();
		switch(rand() % 5)
		{
		case 0:
		case 1:
			mode.SetString("Normal Modus");
			backgroundMusic8Bit.SetVolume(0);
			backgroundMusicNormal.SetVolume(70);

			if (pixelateShader)
			{
				delete pixelateShader;
				pixelateShader = NULL;
			}			
			game.SetPostShader("");
			std::cout << "normal"
			break;
		case 2:
		case 3:
			// 8 Bit modus
			mode.SetString("8 Bit Modus");
			backgroundMusic8Bit.SetVolume(70);
			backgroundMusicNormal.SetVolume(0);

			pixelateShader = new sf::Shader();
			pixelateShader->LoadFromFile("pixelate.frag", sf::Shader::Fragment);
			game.SetPostShader("postEffect.frag");
			std::cout << "8bit"
			break;
		case 4:
			mode.SetString("Spezial Modus");
			backgroundMusic8Bit.SetVolume(0);
			backgroundMusicNormal.SetVolume(70);

			if (pixelateShader)
			{
				delete pixelateShader;
				pixelateShader = NULL;
			}			
			game.SetPostShader("postEffect2.frag");
			std::cout << "spezial"
			break;
		default:
			std::cout << "bla"
		}
	}

	ghostSpawnTimer += dt * (difficulty+2) / 2;
	if (ghostSpawnTimer > 8)
	{
		ghostSpawnTimer -= 8;
		ghostManager.AddGhost(player.GetPosition(), difficulty);
	}

	player.Update(dt);
	MoveCamera();

	Level::IteemType collisionType = level.CheckIteemCollision(player.GetBoundingBox());
	switch (collisionType)
	{
	case Level::ITEM_COIN :
		pickUpSound.Play();
		playerScore += 10;
		std::stringstream s;
		s << "Punkte    " << std::setfill('0') << std::setw(5) << playerScore;
		scoreText.SetString(s.str());
		break;
	}
	if (level.GetCoinCount() == 0)
	{
		++levelNum;
		startLevel(true);
	}
	ghostManager.Update(dt);

	if (ghostManager.CheckCollision(player.GetPosition(), player.GetBoundingBox().Width / 2))
	{
		--life;
		std::stringstream s;
		s << "Leben    " << life;
		lifeText.SetString(s.str());
		if (life == 0)
		{
			game.playerScore = playerScore;
			stateManager.ChangeState("GameOverState");
		}
		else
		{
			startLevel(false);
		}
		
	}


}
//////////////////////////////////////////////////////////////////////////
void MainGameState::Draw()
{
	game.SetView(camera);

	if (pixelateShader) { pixelateShader->SetParameter("pixel_threshold", 0.03); }
	game.GetRenderTarget().Draw(player, sf::RenderStates(pixelateShader));

	if (pixelateShader) { pixelateShader->SetParameter("pixel_threshold", 0.20); }
	game.GetRenderTarget().Draw(level, sf::RenderStates(pixelateShader));

	if (pixelateShader) { pixelateShader->SetParameter("pixel_threshold", 0.02); }
	game.GetRenderTarget().Draw(ghostManager, sf::RenderStates(pixelateShader));

	game.SetView(sf::View(sf::FloatRect(0, 0, 800, 600)));
	game.GetRenderTarget().Draw(scoreText);
	game.GetRenderTarget().Draw(lifeText);
	game.GetRenderTarget().Draw(mode);


	
	if (introIsPlaying)
	{
		game.GetRenderTarget().Draw(introScreen);
	}

	game.SetView(camera);
}

//////////////////////////////////////////////////////////////////////////
void MainGameState::startLevel(bool loadCoins)
{
	std::stringstream sstream;
	sstream << "Level_" << levelNum << ".pac";
	if (!level.LoadFromFile(sstream.str(), loadCoins))
	{
		levelNum = 1;
		++difficulty;
		startLevel(loadCoins);
		return;
	}
	
	player.SetPosition(level.GetPlayerStartPosition());


	ghostManager.Clear();
	ghostSpawnTimer = 0;
	for(int i = 0; i < level.GetNumGhosts() + difficulty*2; ++i)
	{
		ghostManager.AddGhost(player.GetPosition(), difficulty);
	}
}

//////////////////////////////////////////////////////////////////////////
void MainGameState::HandleEvent( sf::Event event )
{
	
	
}
//////////////////////////////////////////////////////////////////////////
void MainGameState::MoveCamera()
{
	camera.SetCenter(player.GetPosition());
	if (camera.GetCenter().x - camera.GetSize().x / 2.0f < 0)
	{
		camera.SetCenter(0 + camera.GetSize().x / 2.0f, camera.GetCenter().y);
	}
	else if (camera.GetCenter().x + camera.GetSize().x / 2.0f > level.GetLevelSize().x)
	{
		camera.SetCenter(level.GetLevelSize().x - camera.GetSize().x / 2.0f, camera.GetCenter().y);
	}
	if (camera.GetCenter().y - camera.GetSize().y / 2.0f < 0)
	{
		camera.SetCenter(camera.GetCenter().x, 0 + camera.GetSize().y / 2.0f);
	}
	else if (camera.GetCenter().y + camera.GetSize().y / 2.0f > level.GetLevelSize().y)
	{
		camera.SetCenter(camera.GetCenter().x, level.GetLevelSize().y - camera.GetSize().y / 2.0f);
	}
}
