#include <sfml/Graphics.hpp>
#include "Ghost.h"
#include "VectorMath.h"
#include "Level.hpp"


//////////////////////////////////////////////////////////////////////////
Ghost::Ghost( sf::Texture& tex, Level& level, sf::Vector2f position, float speed ) : sprite(tex), level(level)
{
	sprite.SetTextureRect(sf::IntRect(330,0,30,30));
	sprite.SetPosition(position);
	sprite.SetOrigin(sprite.GetLocalBounds().Width / 2, sprite.GetLocalBounds().Height / 2);
	
	direction = sf::Vector2f(rand() % 100 + 10.0f, rand() % 100 + 10.0f);
	direction = VectorMath::Normalize(direction);
	this->speed = speed;

	animationTimer = 0;
	numFrames = 12;
	currentFrame = 11;
	frameWidth = 30;
	playForward = false;
}

//////////////////////////////////////////////////////////////////////////
void Ghost::Update( float dt )
{
	sf::Vector2f NewGhostPosition;
	NewGhostPosition = sf::Vector2f(sprite.GetPosition() + sf::Vector2f(direction.x, 0) * dt * speed);
	bool xCollision = level.CheckWallCollision(sf::FloatRect(NewGhostPosition-sprite.GetOrigin(), sf::Vector2f(sprite.GetLocalBounds().Width, sprite.GetLocalBounds().Height)));

	NewGhostPosition = sf::Vector2f(sprite.GetPosition() + sf::Vector2f(0, direction.y) * dt * speed);
	bool yCollision = level.CheckWallCollision(sf::FloatRect(NewGhostPosition-sprite.GetOrigin(), sf::Vector2f(sprite.GetLocalBounds().Width, sprite.GetLocalBounds().Height)));

	NewGhostPosition = sf::Vector2f(sprite.GetPosition() + direction * dt * speed);
	if(level.CheckWallCollision(sf::FloatRect(NewGhostPosition-sprite.GetOrigin(), sf::Vector2f(sprite.GetLocalBounds().Width, sprite.GetLocalBounds().Height))))
	{
		if (xCollision)
		{
			direction.x = -direction.x;
		}
		if (yCollision)
		{
			direction.y = -direction.y;
		}
	}

	animationTimer +=  dt;
	if (animationTimer > 0.05f)
	{
		animationTimer -= 0.05f;

		if (currentFrame == numFrames-1)
		{
			playForward = false;
		}
		else if (currentFrame == 0)
		{
			playForward = true;
		}
		if (playForward)
		{
			++currentFrame;
		}
		else
		{
			--currentFrame;
		}
		sprite.SetTextureRect(sf::IntRect(currentFrame * frameWidth, 0, frameWidth, (int)sprite.GetLocalBounds().Height));
	}


	sprite.Move(direction * dt * speed);
}

//////////////////////////////////////////////////////////////////////////
bool Ghost::CheckCollision(sf::Vector2f center, float radius)
{
	return VectorMath::Distance(center, sprite.GetPosition()) <= radius + GetRadius();
}

//////////////////////////////////////////////////////////////////////////
void Ghost::Draw( sf::RenderTarget& target, sf::RenderStates states ) const
{
	target.Draw(sprite, states);
}
