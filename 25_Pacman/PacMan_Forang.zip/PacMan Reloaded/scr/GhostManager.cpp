#include "GhostManager.h"
#include "VectorMath.h"
#include "Game.hpp"
#include "Level.hpp"
#include <iostream>

//////////////////////////////////////////////////////////////////////////
GhostManager::GhostManager( class Game& game, class Level& level )
	: game(game), level(level)
{}

//////////////////////////////////////////////////////////////////////////
GhostManager::~GhostManager()
{
	for (auto it = ghosts.begin(); it != ghosts.end(); ++it)
	{
		delete *it;
	}
}

//////////////////////////////////////////////////////////////////////////
void GhostManager::Update( float dt )
{
	for (auto it = ghosts.begin(); it != ghosts.end(); ++it)
	{
		(*it)->Update(dt);
		auto it2 = it;
		++it2;
		for(; it2 != ghosts.end(); ++it2)
		{
			if((*it2)->CheckCollision((*it)->GetCenter(), (*it)->GetRadius()))
			{
				sf::Vector2f cOfMass = ((*it)->GetVelocity() + (*it2)->GetVelocity()) / 2.0f;

				sf::Vector2f normal1 = (*it2)->GetCenter() - (*it)->GetCenter();
				normal1 = VectorMath::Normalize(normal1);
				sf::Vector2f normal2 = (*it)->GetCenter() - (*it2)->GetCenter();
				normal2 = VectorMath::Normalize(normal2);

 				float temp = (*it)->GetRadius() + (*it2)->GetRadius();
 				temp -= VectorMath::Distance((*it2)->GetCenter() , (*it)->GetCenter());
				temp += 0.3f;
 				(*it)->Move(normal1 * -temp);
 				(*it2)->Move(normal2 * -temp);

				sf::Vector2f velocity1 = (*it)->GetVelocity();
				velocity1 -= cOfMass;
				velocity1 = VectorMath::Reflect(velocity1, normal1);
				velocity1 += cOfMass;
				(*it)->SetVelocity(VectorMath::Normalize(velocity1));

				sf::Vector2f velocity2 = (*it2)->GetVelocity();
				velocity2 -= cOfMass;
				velocity2 = VectorMath::Reflect(velocity2, normal1);
				velocity2 += cOfMass;
				(*it2)->SetVelocity(VectorMath::Normalize(velocity2));
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////////
void GhostManager::Draw( sf::RenderTarget& target, sf::RenderStates states ) const
{
	for (auto it = ghosts.begin(); it != ghosts.end(); ++it)
	{
		target.Draw(**it, states);
	}
}

//////////////////////////////////////////////////////////////////////////
void GhostManager::AddGhost(sf::Vector2f playerPosition, int difficulty)
{
	while(true)
	{
		sf::Vector2f position((float)(rand() % level.GetLevelSize().x), (float)(rand() % level.GetLevelSize().y));
		if (!level.CheckWallCollision(sf::FloatRect(position - sf::Vector2f(15, 15), sf::Vector2f(30, 30))))
		{
			if (VectorMath::Distance(position, playerPosition) > 150)
			{
				ghosts.push_back(new Ghost(*game.GetTextureManager().GetResource("Ghost_Spritesheet.png"), level, position, 180.0f + difficulty * 20.0f));
				break;
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////////
bool GhostManager::CheckCollision( sf::Vector2f center, float r )
{
	for (auto it = ghosts.begin(); it != ghosts.end(); ++it)
	{
		if ((*it)->CheckCollision(center, r))
		{
			return true;
		}
	}
	return false;
}
