#include "BaseState.hpp"
#include "Game.hpp"


BaseState::BaseState(Game& game)
	: game(game), stateManager(game.GetStateManager())
{
	
}