#ifndef Wall_h__
#define Wall_h__

#include <sfml/Graphics.hpp>

class Wall : public sf::Drawable, public sf::Transformable
{
public:
	Wall(sf::Texture& tex, float x, float y, float width, float height)
		: texture(tex)
	{
		SetPosition(x, y);

		vertexArray.SetPrimitiveType(sf::Quads);

		vertexArray.Append(sf::Vertex(sf::Vector2f(0.0f, 0.0f), sf::Vector2f(0.0f, 0.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(10.0f, 0.0f), sf::Vector2f(10.0f, 0.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(10.0f, 10), sf::Vector2f(10.0f, 10)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(0.0f, 10), sf::Vector2f(0.0f, 10)));

		vertexArray.Append(sf::Vertex(sf::Vector2f(10.0f, 0.0f), sf::Vector2f(10.0f, 0.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(width - 10.0f, 0.0f), sf::Vector2f(tex.GetWidth() - 10.0f, 0.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(width - 10.0f, 10.0f), sf::Vector2f(tex.GetWidth() - 10.0f, 10.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(10.0f, 10.0f), sf::Vector2f(10.0f, 10.0f)));

		vertexArray.Append(sf::Vertex(sf::Vector2f(width - 10.0f, 0.0f), sf::Vector2f(tex.GetWidth() - 10.0f, 0.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(width, 0.0f), sf::Vector2f((float)tex.GetWidth(), 0.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(width, 10.0f), sf::Vector2f((float)tex.GetWidth(), 10.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(width - 10.0f, 10.0f), sf::Vector2f(tex.GetWidth() - 10.0f, 10.0f)));



		vertexArray.Append(sf::Vertex(sf::Vector2f(0.0f, 10.0f), sf::Vector2f(0.0f, 10.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(10.0f, 10.0f), sf::Vector2f(10.0f, 10.0f)));	
		vertexArray.Append(sf::Vertex(sf::Vector2f(10.0f, height - 10.0f), sf::Vector2f(10.0f, 20.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(0.0f, height - 10.0f), sf::Vector2f(0.0f, 20.0f)));

		vertexArray.Append(sf::Vertex(sf::Vector2f(width - 10.0f, 10.0f), sf::Vector2f(tex.GetWidth() - 10.0f, 10.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(width, 10.0f), sf::Vector2f((float)tex.GetWidth(), 10.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(width, height - 10.0f), sf::Vector2f((float)tex.GetWidth(), 20.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(width - 10.0f, height - 10.0f), sf::Vector2f((float)tex.GetWidth() - 10, 20.0f)));


		vertexArray.Append(sf::Vertex(sf::Vector2f(0.0f, height - 10.0f), sf::Vector2f(0.0f, 20.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(10.0f, height - 10.0f), sf::Vector2f(10.0f, 20.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(10.0f, height), sf::Vector2f(10.0f, 30.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(0.0f, height), sf::Vector2f(0.0f, 30.0f)));

		vertexArray.Append(sf::Vertex(sf::Vector2f(10.0f, height - 10), sf::Vector2f(10.0f, 20.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(width - 10.0f, height - 10.0f), sf::Vector2f(tex.GetWidth() - 10.0f, 20.0f)));		
		vertexArray.Append(sf::Vertex(sf::Vector2f(width - 10.0f, height), sf::Vector2f(tex.GetWidth() - 10.0f, 30.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(10.0f, height), sf::Vector2f(10.0f, 30.0f)));

		vertexArray.Append(sf::Vertex(sf::Vector2f(width - 10.0f, height - 10.0f), sf::Vector2f(tex.GetWidth() - 10.0f, 20.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(width, height - 10.0f), sf::Vector2f((float)tex.GetWidth(), 20.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(width, height), sf::Vector2f((float)tex.GetWidth(), 30.0f)));
		vertexArray.Append(sf::Vertex(sf::Vector2f(width - 10.0f, height), sf::Vector2f((float)tex.GetWidth() - 10, 30.0f)));
	}


	bool checkCollision(sf::FloatRect rect)
	{
		return rect.Intersects(sf::FloatRect(GetPosition(), sf::Vector2f(vertexArray.GetBounds().Width, vertexArray.GetBounds().Height)));
	}

private:
	virtual void Draw(sf::RenderTarget& target, sf::RenderStates states) const
	{
		states.Transform = GetTransform();
		states.Texture = &texture;
		target.Draw(vertexArray, states);
	}

	sf::Texture& texture;
	sf::VertexArray vertexArray;
};
#endif // Wall_h__