#ifndef AudioManager_h__
#define AudioManager_h__

#include "ResourceManager.hpp"
#include <sfml/Audio.hpp>
#include <list>


class AudioManager : public ResourceManager<std::string, sf::SoundBuffer>
{
public:
	~AudioManager();
	void PlaySound(const std::string& FileName, float Volume);
	void Update();
protected:
	virtual sf::SoundBuffer* Load(const std::string FileName);
private:
	std::list<sf::Sound> m_Souds;
};
#endif // AudioManager_h__
