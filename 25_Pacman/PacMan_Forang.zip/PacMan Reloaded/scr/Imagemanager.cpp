#include "ImageManager.hpp"
#include <iostream>

sf::Texture* TextureManager::Load(const std::string FileName)
{
	// Neues Bild erstellen
	sf::Texture* texture = new sf::Texture();

	// Bild Laden
	if(!texture->LoadFromFile(FileName)) 
	{
		// Bild L�schen
		delete texture;
		texture = NULL;
		std::cout << "Das Bild " << FileName << " konnte nicht geladen werden.!" << std::endl;
	}
	if (texture)
	{
		std::cout << "Das Bild " << FileName << " wurde erfolgreich geladen." << std::endl;
	}
	
	return texture;
}
