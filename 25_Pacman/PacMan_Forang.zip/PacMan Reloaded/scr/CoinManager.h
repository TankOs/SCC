#ifndef CoinManager_h__
#define CoinManager_h__

#include <sfml/Graphics.hpp>
#include <list>

class CoinManager : public sf::Drawable
{
public:
	CoinManager(const sf::Texture& CoinTexture);
	~CoinManager();

	void AddCoin(sf::Vector2f pos);

	bool CheckCollisionAndRemove(sf::FloatRect rect);

	void Update()
	{

	}

	int Count()
	{
		return coins.size();
	}

private:
	virtual void Draw(sf::RenderTarget& target, sf::RenderStates states) const;

	const sf::Texture& coinTexture;
	std::list<class Coin*> coins;
};



#endif // CoinManager_h__

