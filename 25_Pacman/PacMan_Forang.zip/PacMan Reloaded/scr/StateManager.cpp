#include "StateManager.hpp"
#include "BaseState.hpp"

//////////////////////////////////////////////////////////////////////////
StateManager::StateManager()
{
	currentState = states.end();
}

//////////////////////////////////////////////////////////////////////////
StateManager::~StateManager()
{
	currentState->second->Exit();
	for (auto It = states.begin(); It != states.end(); ++It)
	{
		delete It->second;
	}
}

//////////////////////////////////////////////////////////////////////////
void StateManager::Update( float dt )
{
	currentState->second->Update(dt);
}

//////////////////////////////////////////////////////////////////////////
void StateManager::Draw()
{
	currentState->second->Draw();
}

//////////////////////////////////////////////////////////////////////////
void StateManager::HandleEvent( sf::Event event )
{
	currentState->second->HandleEvent(event);
}

//////////////////////////////////////////////////////////////////////////
void StateManager::AddGamestate( const std::string& name, BaseState* state )
{
	states.insert(std::make_pair(name, state));
}

//////////////////////////////////////////////////////////////////////////
void StateManager::ChangeState( const std::string& stateName )
{
	if (currentState != states.end())
	{
		currentState->second->Exit();
	}	

	std::map<std::string, BaseState*>::iterator newState = states.find(stateName);
	if (newState == states.end())
	{
		throw std::exception("Gamestate wurde nicht gefunden");
	}

	currentState = newState;
	currentState->second->Init();
}
