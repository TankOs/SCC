#include "CoinManager.h"
#include "Coin.h"
#include "Game.hpp"

//////////////////////////////////////////////////////////////////////////
CoinManager::CoinManager( const sf::Texture& coinTexture)
	: coinTexture(coinTexture)
{

}

//////////////////////////////////////////////////////////////////////////
CoinManager::~CoinManager()
{
	for (auto it = coins.begin(); it != coins.end(); ++it)
	{
		delete *it;
	}
}
//////////////////////////////////////////////////////////////////////////
void CoinManager::AddCoin( sf::Vector2f pos )
{
	coins.push_back(new Coin(coinTexture, pos));
}

//////////////////////////////////////////////////////////////////////////
bool CoinManager::CheckCollisionAndRemove( sf::FloatRect rect )
{
	for (auto it = coins.begin(); it != coins.end(); ++it)
	{
		if (rect.Intersects((*it)->GetBoundingBox()))
		{
			delete *it;
			coins.erase(it);
			return true;
		}
	}
	return false;
}

//////////////////////////////////////////////////////////////////////////
void CoinManager::Draw( sf::RenderTarget& target, sf::RenderStates states ) const
{
	for (auto it = coins.begin(); it != coins.end(); ++it)
	{
		target.Draw(**it, states);
	}	
}