#include "Coin.h"

//////////////////////////////////////////////////////////////////////////
Coin::Coin( const sf::Texture& texture, sf::Vector2f position )
	: sprite(texture)
{
	sprite.SetPosition(position);
}

//////////////////////////////////////////////////////////////////////////
sf::FloatRect Coin::GetBoundingBox()
{
	return sprite.GetGlobalBounds();
}

//////////////////////////////////////////////////////////////////////////
void Coin::Draw( sf::RenderTarget& target, sf::RenderStates states ) const
{
	target.Draw(sprite, states);
}
