#ifndef Player_h__
#define Player_h__

#include <sfml/Graphics.hpp>
#include "Game.hpp"
#include "VectorMath.h"
#include <iostream>
#include "Level.hpp"

class Player : public sf::Drawable
{
public:
	Player(Game& game, Level& level, sf::Vector2f startPosition);

	sf::FloatRect GetBoundingBox() const;
	sf::Vector2f GetPosition() const;
	void SetPosition(sf::Vector2f pos);

	void Update(float dt);

	
private:
	virtual void Draw(sf::RenderTarget& target, sf::RenderStates states) const;

	Game& game;
	Level& level;
	sf::Sprite sprite;
	sf::Vector2f direction;
	float speed;
	float animationTimer;
	int numFrames;
	int currentFrame;
	int frameWidth;
	bool openMouth;
};
#endif // Player_h__