#ifndef VectorMath_h__
#define VectorMath_h__

#include <sfml/System/Vector2.hpp>
#include <math.h>

class VectorMath
{
public:
	static float Length(const sf::Vector2f vec)
	{
		return sqrt(vec.x * vec.x + vec.y * vec.y);
	}

	static float Distance(const sf::Vector2f v1, const sf::Vector2f v2)
	{
		return Length(v1 - v2);
	}

	static sf::Vector2f Normalize(sf::Vector2f vec)
	{
		return vec / Length(vec);
	}

	static float Dot(const sf::Vector2f &v1, const sf::Vector2f &v2)
	{
		return v1.x * v2.x + v1.y * v2.y;
	}
	static sf::Vector2f Reflect(sf::Vector2f vec, sf::Vector2f normal)
	{
		return vec - 2.0f * normal * Dot(normal, vec);
	}
	static sf::Vector2f AngleToVector(float deg)
	{
		return sf::Vector2f(DegToRad(sin(deg)), DegToRad(cos(deg)));
	}
	static float VectorToAngle(const sf::Vector2f &v1, const sf::Vector2f &v2)
	{
		return RadToDeg(acos( Dot(v1, v2) ));
	}
	static float DegToRad(float deg)
	{
		return deg * 3.14159265f / 180;
	}
	static float RadToDeg(float rad)
	{
		return (180 * rad) / 3.14159265f;
	}
};
#endif // VectorMath_h__