#include "Level.hpp"
#include <fstream>
#include "Game.hpp"
#include <iostream>

//////////////////////////////////////////////////////////////////////////
Level::Level(Game& game)
	: game(game), coinManager(*game.GetTextureManager().GetResource("Coin.png"))
{
	numGhosts = 5;
	playerStartPosition = sf::Vector2f(100, 100);
	levelSize = sf::Vector2i(800, 600);
}

//////////////////////////////////////////////////////////////////////////
bool Level::LoadFromFile( const std::string& levelName, bool loadCoins )
{
	std::ifstream file(levelName);
	if (!file)
	{
		return false;
	}

	walls.clear();

	while(!file.eof())
	{
		std::string ID;
		file >> ID;
		if (!ID.empty())
		{
			if (ID == "Coin")
			{
				if (loadCoins)
				{
					float x, y;
					file >> x >> y;
					coinManager.AddCoin(sf::Vector2f(x, y));
				}				
			}
			else if (ID == "Wall")
			{
				float x, y, width, height;
				file >> x >> y >> width >> height;

				sf::Sprite sprite(*game.GetTextureManager().GetResource("Wall.png"));
				sprite.SetPosition(x, y);
				sprite.SetScale(width / sprite.GetLocalBounds().Width, height / sprite.GetLocalBounds().Height);


				walls.push_back(Wall(*game.GetTextureManager().GetResource("Wall.png"), x, y, width, height));
			}
			else if (ID == "NumGhosts")
			{
				file >> numGhosts;
			}
			else if (ID == "PlayerStartPosition")
			{
				file >> playerStartPosition.x >> playerStartPosition.y;
			}
			else if (ID == "LevelSize")
			{
				file >> levelSize.x >> levelSize.y;
			}
			else if (ID == "//")
			{
				file.ignore(1024, '\n');
			}
			else
			{
				std::cout << ID << " ist keine bekannte ID" << std::endl;
				file.ignore(1024, '\n');
			}
		}
	}
	// Begrenzung erstellen
	walls.push_back(Wall(*game.GetTextureManager().GetResource("Wall.png"), -10.0f, -23.0f, levelSize.x + 20.0f, 30.0f));				// oben
	walls.push_back(Wall(*game.GetTextureManager().GetResource("Wall.png"), levelSize.x - 7.0f, -20.0f, 30.0f, levelSize.y + 20.0f));	// rechts
	walls.push_back(Wall(*game.GetTextureManager().GetResource("Wall.png"), -10.0f, levelSize.y - 7.0f, levelSize.x + 20.0f, 30.0f));	// unten
	walls.push_back(Wall(*game.GetTextureManager().GetResource("Wall.png"), -23.0f, -10.0f, 30.0f, levelSize.y + 20.0f));				// links

	return true;
}


//////////////////////////////////////////////////////////////////////////
Level::IteemType Level::CheckIteemCollision( const sf::FloatRect& rect )
{
	if (coinManager.CheckCollisionAndRemove(rect))
	{
		return ITEM_COIN;
	}
	return ITEM_NONE;
}

//////////////////////////////////////////////////////////////////////////
bool Level::CheckWallCollision(sf::FloatRect rect)
{
	for (auto it = walls.begin(); it != walls.end(); ++it)
	{
		if (it->checkCollision(rect))
		{
			return true;
		}
	}
	return false;
}

//////////////////////////////////////////////////////////////////////////
void Level::Draw( sf::RenderTarget& target, sf::RenderStates states ) const
{
	target.Draw(coinManager, states);
	for (auto it = walls.begin(); it != walls.end(); ++it)
	{
		target.Draw(*it, states);
	}
}

//////////////////////////////////////////////////////////////////////////
int Level::GetCoinCount()
{
	return coinManager.Count();
}
