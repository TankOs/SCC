#include "Player.hpp"

//////////////////////////////////////////////////////////////////////////
Player::Player( Game& game, Level& level, sf::Vector2f startPosition ) : game(game),
	level(level),
	sprite(*game.GetTextureManager().GetResource("Pacman_Spritesheet.png"), sf::IntRect(0, 0, 40, 40))
{
	sprite.SetPosition(startPosition);
	sprite.SetOrigin(sprite.GetLocalBounds().Width / 2, sprite.GetLocalBounds().Height / 2);
	speed = 215;
	animationTimer = 0;
	numFrames = 5;
	currentFrame = 0;
	frameWidth = 50;
	openMouth = true;
}

//////////////////////////////////////////////////////////////////////////
sf::FloatRect Player::GetBoundingBox() const
{
	return sf::FloatRect(sprite.GetPosition() - sprite.GetOrigin(), sf::Vector2f(sprite.GetLocalBounds().Width, sprite.GetLocalBounds().Height));
}

//////////////////////////////////////////////////////////////////////////
void Player::Update( float dt )
{
	direction = VectorMath::Normalize(game.GetMousePosition() - sprite.GetPosition());
	if (VectorMath::Distance(sprite.GetPosition(), game.GetMousePosition()) > 3)
	{
		
		sprite.Move(sf::Vector2f(direction.x, 0) * dt * speed);
		if (level.CheckWallCollision(GetBoundingBox()))
		{
			sprite.Move(sf::Vector2f(direction.x, 0) * dt * -speed);
		}

		sprite.Move(sf::Vector2f(0, direction.y) * dt * speed);
		if (level.CheckWallCollision(GetBoundingBox()))
		{
			sprite.Move(sf::Vector2f(0, direction.y) * dt * -speed);
		}

		float Angle = VectorMath::VectorToAngle(sf::Vector2f(1,0), direction);
		if (game.GetMousePosition().y > sprite.GetPosition().y)
		{
			sprite.SetRotation(Angle);
		}
		else
		{
			sprite.SetRotation(360 - Angle);
		}
	}

	// Animation
	animationTimer +=  dt;
	if (animationTimer > 0.05f)
	{
		animationTimer -= 0.05f;

		if (currentFrame == numFrames-1)
		{
			openMouth = false;
		}
		else if (currentFrame == 0)
		{
			openMouth = true;
		}
		if (openMouth)
		{
			++currentFrame;
		}
		else
		{
			--currentFrame;
		}
		sprite.SetTextureRect(sf::IntRect(currentFrame * frameWidth, 0, frameWidth - 10, (int)sprite.GetLocalBounds().Height));
	}
}

//////////////////////////////////////////////////////////////////////////
void Player::Draw( sf::RenderTarget& target, sf::RenderStates states ) const
{
	target.Draw(sprite, states);
}

//////////////////////////////////////////////////////////////////////////
sf::Vector2f Player::GetPosition() const
{
	return sprite.GetPosition();
}

//////////////////////////////////////////////////////////////////////////
void Player::SetPosition( sf::Vector2f pos )
{
	sprite.SetPosition(pos);
}
