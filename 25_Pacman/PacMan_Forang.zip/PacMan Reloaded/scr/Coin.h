#ifndef Coin_h__
#define Coin_h__

#include <sfml/Graphics.hpp>

class Game;

class Coin : public sf::Drawable
{
public:
	Coin(const sf::Texture& texture, sf::Vector2f Position);

	sf::FloatRect GetBoundingBox();

private:
	virtual void Draw(sf::RenderTarget& target, sf::RenderStates states) const;

	sf::Sprite sprite;
};
#endif // Coin_h__