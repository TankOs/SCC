#ifndef Level_h__
#define Level_h__

#include <list>
#include "CoinManager.h"
#include "Wall.h"

class Level : public sf::Drawable
{
public:
	enum IteemType
	{
		ITEM_NONE,
		ITEM_COIN
	};
public:
	Level(class Game& game);
	bool LoadFromFile(const std::string& levelName, bool loadCoins);
	
	bool CheckWallCollision(sf::FloatRect rect);
	IteemType CheckIteemCollision(const sf::FloatRect& rect);
	int GetNumGhosts()
	{
		return numGhosts;
	}
	sf::Vector2f GetPlayerStartPosition()
	{
		return playerStartPosition;
	}
	sf::Vector2i GetLevelSize()
	{
		return levelSize;
	}
	int GetCoinCount();
private:
	virtual void Draw(sf::RenderTarget& target, sf::RenderStates states) const;

	class Game& game;

	CoinManager coinManager;
	std::list<class Wall> walls;

	int numGhosts;
	sf::Vector2f playerStartPosition;
	sf::Vector2i levelSize;
};


#endif // Level_h__