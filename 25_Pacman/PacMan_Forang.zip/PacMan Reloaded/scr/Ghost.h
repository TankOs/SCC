#ifndef Ghost_h__
#define Ghost_h__

#include <sfml/Graphics.hpp>

class Level;

class Ghost : public sf::Drawable
{
public:
	Ghost(sf::Texture& tex, Level& level, sf::Vector2f position, float speed);

	void Update(float dt);

	bool CheckCollision(sf::Vector2f center, float radius);

	float GetRadius(){return sprite.GetLocalBounds().Height / 2;}
	sf::Vector2f GetCenter(){return sprite.GetPosition();}

	sf::Vector2f GetVelocity() const {return direction;}
	void SetVelocity(sf::Vector2f vec) {direction = vec;}

	void Move(sf::Vector2f vec) {sprite.Move(vec);}
private:
	virtual void Draw(sf::RenderTarget& target, sf::RenderStates states) const;

	Level& level;
	sf::Vector2f direction;
	float speed;

	sf::Sprite sprite;
	float animationTimer;
	int numFrames;
	int currentFrame;
	int frameWidth;
	bool playForward;
};
#endif // Ghost_h__