#include "Game.hpp"
#include <iostream>

int main()
{
	if (!sf::Shader::IsAvailable())
	{

		std::cout << "Das Spiel kann nicht gestartet werden da die Grafikkarte keine Shader unterst�tzt!";
		std::cin.get();
		return -1;
	}
	try
	{
		Game game;
		game.Run();
	}
	catch (std::exception& e)
	{
		std::cout << e.what() << std::endl;
		std::cin.get();
	}	
}