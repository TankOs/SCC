#ifndef BaseState_h__
#define BaseState_h__

#include <sfml/Graphics.hpp>

class Game;
class StateManager;

class BaseState
{
public:
	BaseState(Game& game);

	virtual void Init() = 0;
	virtual void Exit() = 0;
	virtual void Draw() = 0;
	virtual void Update(float dt) = 0;
	virtual void HandleEvent(sf::Event event){};

protected:
	Game& game;
	StateManager& stateManager;
};
#endif // BaseState_h__