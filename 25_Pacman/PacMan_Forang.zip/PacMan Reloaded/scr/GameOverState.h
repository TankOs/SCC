#ifndef GameOverState_h__
#define GameOverState_h__

#include <sfml/Graphics.hpp>
#include <sstream>
#include "BaseState.hpp"
#include "Game.hpp"



class GameOverState : public BaseState
{
public:
	GameOverState(Game& game)
		: BaseState(game), gameOverText("",game.GetDefaultFont(), 60)
	{
		gameOverText.SetPosition(0, 100);
	}

	virtual void Init()
	{
		std::stringstream s;
		s << "                 Game Over\nDeine Punktzahl    " << game.playerScore << "\n\nBeliebige  Taste  druecken";
		gameOverText.SetString(s.str());
	}
	virtual void Exit(){}
	virtual void Draw()
	{
		game.SetView(sf::View(sf::FloatRect(0,0,800,600)));
		game.GetRenderTarget().Draw(gameOverText);
	}
	virtual void Update(float dt){}
	virtual void HandleEvent(sf::Event event)
	{
		if (event.Type == sf::Event::KeyPressed)
		{
			game.GetStateManager().ChangeState("MainGameState");
		}
	}

private:
	sf::Text gameOverText;
};
#endif // GameOverState_h__
