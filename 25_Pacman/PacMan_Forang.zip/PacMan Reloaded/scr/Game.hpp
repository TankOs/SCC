#ifndef Game_h__
#define Game_h__

#include <sfml/Graphics.hpp>
#include "StateManager.hpp"
#include "ImageManager.hpp"
#include "AudioManager.h"

class Game
{
public:
	Game();
	~Game();

	void Run();

	void Exit();


	sf::RenderTarget& GetRenderTarget();
	StateManager& GetStateManager();
	TextureManager& GetTextureManager();
	AudioManager& GetAudioManager();
	sf::Vector2f GetMousePosition();
	const sf::Font& GetDefaultFont(){ return defaultFont; }

	void SetView(const sf::View& view);

	void SetPostShader(const std::string& filePath);
	sf::Shader* GetPostShader() { return postShader; }

	int playerScore;

private:
	bool isRunning;
	sf::Clock timer;
	float frameTime;
	sf::RenderWindow window;
	sf::RenderTexture renderTexture;
	sf::Shader* postShader;
	StateManager stateManager;
	TextureManager textureManager;
	AudioManager audioManager;
	sf::Font defaultFont;

	
};
#endif // Game_h__