#ifndef MainGameState_h__
#define MainGameState_h__

#include "BaseState.hpp"
#include "Player.hpp"
#include "Level.hpp"
#include "GhostManager.h"

class MainGameState : public BaseState
{
public:
	MainGameState(Game& game);
	~MainGameState();

	virtual void Init();
	virtual void Exit();
	virtual void Draw();
	virtual void Update(float dt);

	void MoveCamera();

	virtual void HandleEvent(sf::Event event);;

private:
	void startLevel(bool loadCoins);

	Level level;
	Player player;
	GhostManager ghostManager;
	sf::View camera;
	int playerScore;
	sf::Text scoreText;
	float ghostSpawnTimer;
	int difficulty;
	int levelNum;
	int life;
	sf::Text lifeText;
	sf::Sound pickUpSound;
	float time;
	sf::Shader* pixelateShader;

	// Intro
	bool introIsPlaying;
	bool screenDestroyed;
	sf::Sprite introScreen;
	sf::Sound introSound;
	sf::Clock introClock;

	sf::Music backgroundMusicNormal;
	sf::Music backgroundMusic8Bit;

	sf::Text mode;
	sf::Clock modeTimer;
};

#endif // MainGameState_h__