#ifndef StateManager_h__
#define StateManager_h__

#include <string>
#include <map>
#include <sfml/Window/Event.hpp>

class BaseState;

class StateManager
{
public:
	StateManager();
	~StateManager();

	void Update(float dt);

	void Draw();

	void HandleEvent(sf::Event event);

	void AddGamestate(const std::string& name, BaseState* state);

	void ChangeState(const std::string& stateName);

private:
	std::map<std::string, BaseState*> states;
	std::map<std::string, BaseState*>::iterator currentState;
};
#endif // StateManager_h__