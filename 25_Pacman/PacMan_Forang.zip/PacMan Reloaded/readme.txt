SFML version 2.0

Anleitung:
Bewege PacMan mit der Maus durch die Level und sammle die M�nzen ein. Aber achte auf die b�sen
Geister!!! Das Spiel wird von Level zu Level immer schwerer.

Soundeffecte:
http://soundbible.com/1919-Shotgun-Blast.html
http://soundfxcenter.com/sound_effect/search.php?sfx=Pacman

Musik:
Eigenproduktion :D