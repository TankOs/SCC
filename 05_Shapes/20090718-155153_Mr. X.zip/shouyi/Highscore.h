#pragma once
#include "Global.h"

void DeleteHighscore();