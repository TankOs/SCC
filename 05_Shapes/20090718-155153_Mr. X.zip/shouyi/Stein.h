#include "Highscore.h"

class Steine {
private:
	sf::Clock Uhr;
	sf::Clock BewegungsUhr;
	sf::Vector2f Size;
	float x ,y;
	sf::Shape Figur;
public:
	Steine();
	const sf::Vector2f& GetPosition();
	void NewColor();
	sf::Drawable& GetDrawable();
	void N�chstesSpiel();
	sf::Drawable& GetSet(sf::Vector2f& Pos, float ElapsedTime, int ScoreFak);
	sf::Drawable& Run(float ElapsedTime);
	void Click(sf::Vector2f& MousePosition);
};

void LoadSounds();

extern Steine Stein;
extern Steine MausStein;