#include "Stein.h"

Steine Stein;
Steine MausStein;
sf::SoundBuffer Tock;
sf::SoundBuffer Tuuuut;
sf::Sound Player;

void LoadSounds() {
	Tock.LoadFromFile("Tock.ogg");
	Tuuuut.LoadFromFile("Tuuuut.ogg");
	Player.SetBuffer(Tock);
}

void N�chstesSpiel() {
	if(GetStatus() == TEIL2) {
		Player.SetBuffer(Tuuuut);
		Player.SetPitch(1);
	}
	if(GetStatus() == TEIL3) {
		Player.Stop();
	}
	Stein.N�chstesSpiel();
	MausStein = Stein;
	MausStein.NewColor();
}

Steine::Steine() {
	sf::Randomizer::SetSeed(std::time(NULL));
	x = sf::Randomizer::Random(-100.f, 100.f);
	y = sf::Randomizer::Random(-100.f, 100.f);
	Uhr.Reset();
	Size = sf::Vector2f(sf::Randomizer::Random(15.0f, 35.0f), sf::Randomizer::Random(15.0f, 35.0f));
	Figur = sf::Shape::Rectangle(sf::Vector2f(0,0), Size, sf::Color(sf::Randomizer::Random(50, 255), sf::Randomizer::Random(50, 255), sf::Randomizer::Random(50, 255)));
	Figur.SetPosition(sf::Randomizer::Random(0.0f, 800.0f-Size.x), sf::Randomizer::Random(0.0f, 600.0f-Size.y));
}
sf::Drawable& Steine::GetDrawable() {
	return(Figur);
}
void Steine::NewColor() {
	Figur.SetColor(sf::Color(sf::Randomizer::Random(50, 255), sf::Randomizer::Random(50, 255), sf::Randomizer::Random(50, 255)));
}
const sf::Vector2f& Steine::GetPosition() {
	return(Figur.GetPosition());
}
void Steine::N�chstesSpiel() {
	Score -= Uhr.GetElapsedTime();
	*this = Steine();
}
sf::Drawable& Steine::GetSet(sf::Vector2f& Pos, float ElapsedTime, int ScoreFak) {
	Figur.SetPosition(Pos);
	float f = std::min(Stein.GetPosition().x - this->GetPosition().x, -(Stein.GetPosition().x - this->GetPosition().x));
	f += std::min(Stein.GetPosition().y - this->GetPosition().y, -(Stein.GetPosition().y - this->GetPosition().y));
	if(GetStatus() == TEIL2) {
		Player.SetLoop(true);
		if(Player.GetStatus() != sf::Sound::Playing) {
			Player.Play();
		}
		Player.SetVolume(-f);
		Player.SetPitch(0.6 - f*0.001);
	}
	if(AnweisungsTimer.GetElapsedTime() > 3) {
		if(GetStatus() == TEIL2) {
			Score -= ScoreFak*f*ElapsedTime;
		}
		else {
			Score -= ScoreFak*f*ElapsedTime/10;
		}
	}
	return(Figur);

}
sf::Drawable& Steine::Run(float ElapsedTime) {
	if(BewegungsUhr.GetElapsedTime() > 0.4 && sf::Randomizer::Random(0, 5) == 0) {
		x = sf::Randomizer::Random(-100.f, 100.f);
		y = sf::Randomizer::Random(-100.f, 100.f);
		BewegungsUhr.Reset();
	}
	Figur.Move(
		std::min(std::max(x*ElapsedTime, -Figur.GetPosition().x), 800 - (Figur.GetPosition().x + Size.x)), 
		std::min(std::max(y*ElapsedTime, -Figur.GetPosition().y), 600 - (Figur.GetPosition().y + Size.y)));
	return(Figur);
}
void Steine::Click(sf::Vector2f& MousePosition) {
	if(MousePosition.x >= Figur.GetPosition().x && MousePosition.y >= Figur.GetPosition().y && MousePosition.x <= Figur.GetPosition().x + Size.x && MousePosition.y <= Figur.GetPosition().y + Size.y) {
		Score += (3 - Uhr.GetElapsedTime())*100;
		*this = Steine();
		Player.Play();
	}
	else {
		Score -= 100;
	}
}