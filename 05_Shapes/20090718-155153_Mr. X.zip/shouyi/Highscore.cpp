#include "Highscore.h"

float Scores[11];

void CreateHighscore() {
	try {
		std::ifstream is("Highscore");
		for(int i = 0; i < 10; i++) {
			if(is.good()) {
				is >> Scores[i];
			}
			else {
				Scores[i] = 0;
			}
		}
	}
	catch (...) {
		for(int i = 0; i < 10; i++) {
			Scores[i] = 0;
		}
	}
	Scores[10] = Score;
	int Buffer;
	int anzahl = 11;
	for(int k = anzahl - 1; k > 0; k--) {
		for(int i = 0; i < anzahl - 1; i++) {
			if(Scores[i] < Scores[i + 1]) {
				Buffer = Scores[i];
				Scores[i] = Scores[i + 1];
				Scores[i + 1] = Buffer;
			}
		}
		anzahl --;
	}
	bool gefunden = false;
	for(int i = 0; i < 11; i++) {
		std::ostringstream os;
		os << Scores[i];
		Punkte[i].SetText(os.str());
		if(Scores[i] == Score && !gefunden) {
			Punkte[i].SetStyle(5);
			Punkte[i].SetColor(sf::Color(255, 150, 150));
			gefunden = true;
		}
		Punkte[i].SetPosition(400 - Punkte[i].GetRect().GetWidth()/2, 60 + i*50);
	}
	std::ofstream os("Highscore");
	for(int i = 0; i < 10; i++) {
		os << Scores[i] << "\n";
	}
}

void DeleteHighscore() {
	std::ofstream os("Highscore");
	os.clear();
}