#pragma once
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include <sstream>
#include <fstream>
#include <cmath>

enum Spielstatus {TEIL1, TEIL2, TEIL3, HIGHSCORE, ENDE};
extern sf::Clock AufgabenTimer;
extern sf::Clock AnweisungsTimer;
extern sf::String Anweisung;
extern sf::String Punkte[11];
extern float Score;

void SetStatus(Spielstatus status);
void N�chstesSpiel();
void CreateHighscore();
extern inline Spielstatus GetStatus();