#include "Global.h"

Spielstatus Status;
sf::Clock AnweisungsTimer;
sf::Clock AufgabenTimer;
sf::String Anweisung;
sf::String Punkte[11];
float Score;

void SetStatus(Spielstatus status) {
	AnweisungsTimer.Reset();
	Status = status;
	switch(Status) {
		case TEIL1:
			Anweisung.SetText("Klicken Sie die K�stchen so schnell wie m�glich weg!");
			Score = 0.f;
			for(int i = 0; i < 11; i++) {
				Punkte[i].SetText("");
			}
			break;
		case TEIL2:
			Anweisung.SetText("Folgen Sie dem K�stchen so dicht wie m�glich!");
			N�chstesSpiel();
			break;
		case TEIL3:
			Anweisung.SetText("Halten Sie soviel Abstand zum K�stchen wie m�glich!");
			N�chstesSpiel();
			break;
		case HIGHSCORE:
			CreateHighscore();
			Anweisung.SetSize(25);
			Anweisung.SetText("Dr�cken Sie eine Taste zum Beenden. Entf l�scht dabei die Highscore.");
			break;
		case ENDE:
			break;
	}
	Anweisung.SetPosition(400 - Anweisung.GetRect().GetWidth() / 2, 5);
}
Spielstatus GetStatus() {
	return(Status);
}