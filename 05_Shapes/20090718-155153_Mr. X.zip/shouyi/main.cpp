﻿#include "Stein.h"

int main () {
	LoadSounds();
	sf::Vector2f AlteMausPos;
	sf::Clock MausUhr;
	sf::RenderWindow RW(sf::VideoMode(800, 600), "Shôuyì", sf::Style::Fullscreen);
	RW.ShowMouseCursor(true);
	RW.SetFramerateLimit(200);
	Anweisung.SetColor(sf::Color(255, 255, 255, 200));
	sf::Event EV;
	SetStatus(TEIL1);
	const sf::Input &IP = RW.GetInput();
	while(GetStatus() != ENDE) {
		RW.Clear();
		while(RW.GetEvent(EV)) {
			if(EV.Type == sf::Event::MouseButtonPressed && GetStatus() == TEIL1){
				if(EV.MouseButton.Button == sf::Mouse::Left) {
					Stein.Click(sf::Vector2f(IP.GetMouseX(), IP.GetMouseY()));
				}
			}
			if(EV.Type  == sf::Event::KeyPressed) {
				if(EV.Key.Code == sf::Key::Delete && GetStatus() == HIGHSCORE) {
					DeleteHighscore();
				}
				if(EV.Key.Code == sf::Key::Escape || GetStatus() == HIGHSCORE) {
					SetStatus(ENDE);
				}
			}
			if(EV.Type == sf::Event::Closed) {
				SetStatus(ENDE);
				RW.Close();
			}
		}
		if(GetStatus() < HIGHSCORE) {
			std::ostringstream os;
			os << Score << " Punkte";
			Punkte[0].SetText(os.str());
			Punkte[0].SetPosition(400 - Punkte[0].GetRect().GetWidth() / 2, 590 - Punkte[0].GetRect().GetHeight());
		}


		RW.Draw(Stein.Run(RW.GetFrameTime()));
		if(GetStatus() == TEIL2) {
			RW.Draw(MausStein.GetSet(sf::Vector2f(IP.GetMouseX(), IP.GetMouseY()), RW.GetFrameTime(), -1));
		}
		if(GetStatus() == TEIL3) {
			Stein.GetSet(AlteMausPos, 0, 0);
			RW.Draw(MausStein.GetSet(sf::Vector2f(IP.GetMouseX(), IP.GetMouseY()), RW.GetFrameTime(), 1));
		}
		if(MausUhr.GetElapsedTime() > 0.1) {
			AlteMausPos = sf::Vector2f(IP.GetMouseX(), IP.GetMouseY());
			MausUhr.Reset();
		}
		for(int i = 0; i < 11; i++) {
			RW.Draw(Punkte[i]);
		}
		if(AnweisungsTimer.GetElapsedTime() < 5) {
			RW.Draw(Anweisung);
		}


		if(AufgabenTimer.GetElapsedTime() > 30) {
			if(GetStatus() == HIGHSCORE) {
				RW.ShowMouseCursor(true);
				SetStatus(ENDE);
			}
			if(GetStatus() == TEIL3) {
				RW.ShowMouseCursor(true);
				SetStatus(HIGHSCORE);
			}
			if(GetStatus() == TEIL2) {
				RW.ShowMouseCursor(false);
				SetStatus(TEIL3);
			}
			if(GetStatus() == TEIL1) {
				RW.ShowMouseCursor(false);
				RW.SetCursorPosition(Stein.GetPosition().x, Stein.GetPosition().y);
				SetStatus(TEIL2);
			}
			AufgabenTimer.Reset();
		}
		RW.Display();
	}
	return EXIT_SUCCESS;
}