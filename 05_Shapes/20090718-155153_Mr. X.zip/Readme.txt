_______SHOUYI_______

Shouyi (chin. Geschicklichkeit) ist ein Geschicklichkeitsspiel, das aus drei Teilen (je 30 Sekunden) besteht.
1. Die K�stchen m�ssen so schnell wie m�glich weggeklickt werden. Jedes weggeklickte K�stchen bringt Punkte, die Zeit bis dahin wird aber abgezogen.
	Nicht treffen kostet auch Punkte!
2. Jetzt gilt es, dem K�stchen zu folgen. Die Distanz zwischen K�stchen und Maus (als K�stchen dargestellt) wird pro Sekunde vom Punktestand abgezogen.
3. Im letzten Teil muss man soviel Distanz wie m�glich zwischen das verfolgende K�stchen und die Maus bringen. Die Distanz wird einem pro Sekunde angerechnet.

Der Sourcecode und die beigelegten Sounddateien wurden von mir (Philipp Kloke) erstellt und stehen unter GPL v3 (nicht beigelegt).

Viel Spa�!
