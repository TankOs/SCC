//circlerail.h
#ifndef MYVERYOWNCIRCLERAIL_H
#define MYVERYOWNCIRCLERAIL_H

#include <SFML/Graphics.hpp>

class CircleRail {
public:
	// C'tor
	CircleRail(const sf::Vector2f& position, const float& radius):
	m_center(position),
	m_radius(radius)
	{ }
	// Methods
	sf::Vector2f GetPositionOnRail(const float& angle) const;
	// Member (public because of laziness)
	sf::Vector2f m_center;
	float m_radius;
};

#endif // MYVERYOWNCIRCLERAIL_H