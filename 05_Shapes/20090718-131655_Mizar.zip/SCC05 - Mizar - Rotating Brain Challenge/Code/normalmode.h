//normalmode.h
#ifndef MYNORMALMODEOFTHEGAME_H
#define MYNORMALMODEOFTHEGAME_H

#include "circleangle.h"
#include "circlerail.h"
#include "soundbutton.h"
#include "soundbuttonrenderer.h"
#include "gamestate.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <utility>
#include <string>

class NormalMode: public GameState {
public:
	// typedefs
	typedef std::vector<std::pair<SoundButton, CircleAngle> > ButtonAngleVec;
	typedef std::vector<unsigned int> OrderVec;
	// enum
	enum InGameStates {
		IGS_ShowOrder = 0,
		IGS_RepeatOrder,
		IGS_WaitForRotation,
		IGS_Rotate,
		IGS_Win,
		IGS_Lose
	};
	// C'tor
	NormalMode(sf::RenderWindow& window):
	GameState(window),
	m_rail(sf::Vector2f(m_game_window.GetWidth() / 2.f, m_game_window.GetHeight() / 2.f), 150.f),
	m_renderer(75.f, m_game_window),
	m_rotationtime_min(4.f),
	m_rotationtime_max(8.f),
	m_soundorder_init(3), // n sounds in first round
	m_rotation_start(6), // rotate each n-th round
	m_wincondition(50)
	{ }
	// Methods
	bool Init();
	States Events();
	void Draw();
private:
	// additional Methods
	void DontShowColor();
	void ShowEachColor();
	void RotateButtons();
	void MaxSoundDuration();
	void UpdateStatusString(const std::string& new_text);
	void UpdateSoundCountString(const unsigned int new_value);
	// Member
	ButtonAngleVec m_buttons;
	OrderVec m_order;
	CircleRail m_rail;
	SoundButtonRenderer m_renderer;
	InGameStates m_igstates;
	sf::Sound m_drumloop;
	sf::Sound m_rotationloop;
	sf::Sound m_win_sound;
	sf::Sound m_lose_sound;
	sf::String m_status_string;
	sf::String m_soundcount_string;
	sf::Vector2f m_mouse;
	sf::Clock m_timer;
	bool m_no_colors;
	bool m_rotate_clockwise;
	float m_showtime;
	float m_shownext;
	float m_rotationtime;
	float m_max_sound_duration;
	float m_text_size;
	const float m_rotationtime_min;
	const float m_rotationtime_max;
	unsigned int m_randomizer_end;
	unsigned int m_current_orderelement;
	const unsigned int m_soundorder_init;
	const unsigned int m_rotation_start;
	const unsigned int m_wincondition;
};

#endif // MYNORMALMODEOFTHEGAME_H