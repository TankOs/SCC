//main.cpp
#include "gameengine.h"

int main()
{
	GameEngine engine(800, 600, 32, 30, "Rotating Brain Challenge by Mizar", false);
	States state = S_MainMenu;
	while(state != S_Quit) {
		// Set the gamestate and initialise it, if something went wrong quit the application
		if(!engine.SetState(state)) {
			break;
		}
		// As long as the gamestate does not change -> check for events and draw everything thats needed
		while(engine.GetCurrentState() == state) {
			state = engine.GetGameState()->Events();
			engine.GetGameState()->Draw();
		}
	}

	return 0;
}