//circleangle.h
#ifndef MYCIRCLEANGLE_H
#define MYCIRCLEANGLE_H

class CircleAngle {
public:
	// C'tor
	CircleAngle(const float& angle, const float& angle_mod = 1.047f):
	m_angle(angle),
	m_angle_mod(angle_mod),
	m_angle_mod_this_frame(0.f)
	{ }
	// Methods
	void ChangeAngle(const bool clockwise, const float& frametime);
	// Member (public because of laziness)
	float m_angle;
	float m_angle_mod;
	float m_angle_mod_this_frame;
	static const float s_PI;
	static const float s_lowerbound;
	static const float s_upperbound;
};

#endif // MYCIRCLEANGLE_H