//resourcemanager.h
#ifndef MYRESOURCEMANAGER_H
#define MYRESOURCEMANAGER_H

#include <SFML/Audio.hpp>
#include <map>
#include <string>

class SoundManager {
public:
	// Singleton
	static SoundManager& Instance()
	{
		static SoundManager single_instance;
		return single_instance;
	}
	// Methods
	bool LoadSound(const std::string &filename);
	sf::SoundBuffer* GetSound(const std::string &filename);
	// Destructor
	~SoundManager();
private:
	typedef std::map<std::string, sf::SoundBuffer*> SoundMap;
	// Member
	SoundMap m_sounds;
	// Hidden C'tor, Copy C'tor and assignmentoperator
	SoundManager() { }
	SoundManager(const SoundManager& copy);
	SoundManager& operator=(const SoundManager& rhs);
};

#endif // MYRESOURCEMANAGER_H