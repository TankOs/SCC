//global_functions.h
#ifndef MYUSEFULLFUNCTIONS_H
#define MYUSEFULLFUNCTIONS_H

#include <SFML/Graphics.hpp>

bool IsPointInsideCircle(const sf::Vector2f& point, const sf::Vector2f& circle_center, const float& circle_radius);

#endif // MYUSEFULLFUNCTIONS_H