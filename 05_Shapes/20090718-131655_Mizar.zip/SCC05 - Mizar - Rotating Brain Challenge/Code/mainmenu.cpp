//mainmenu.cpp
#include "mainmenu.h"
#include "fontmanager.h"
#include <SFML/Graphics.hpp>

bool MainMenu::Init()
{
	if(!FontManager::Instance().LoadFont("fonts/rough_typewriter.otf"))
		return false;
	m_title_size = 40.f;
	m_text_size = 30.f;
	m_titlestring_upper.SetText("ROTATING");
	m_titlestring_midle.SetText("BRAIN");
	m_titlestring_bottom.SetText("CHALLENGE");
	m_titlestring_upper.SetFont(*(FontManager::Instance().GetFont("fonts/rough_typewriter.otf")));
	m_titlestring_midle.SetFont(*(FontManager::Instance().GetFont("fonts/rough_typewriter.otf")));
	m_titlestring_bottom.SetFont(*(FontManager::Instance().GetFont("fonts/rough_typewriter.otf")));
	m_titlestring_upper.SetSize(m_title_size);
	m_titlestring_midle.SetSize(m_title_size);
	m_titlestring_bottom.SetSize(m_title_size);
	m_titlestring_upper.SetPosition(m_game_window.GetWidth() * 0.33f - m_titlestring_upper.GetRect().GetWidth() / 2.f,
									m_game_window.GetHeight() * 0.1f);
	m_titlestring_midle.SetPosition(m_game_window.GetWidth() / 2.f - m_titlestring_midle.GetRect().GetWidth() / 2.f,
									m_game_window.GetHeight() * 0.2f);
	m_titlestring_bottom.SetPosition(m_game_window.GetWidth() * 0.66f - m_titlestring_bottom.GetRect().GetWidth() / 2.f,
									 m_game_window.GetHeight() * 0.3f);
	m_option_normal.SetText("Normal Mode");
	m_option_hard.SetText("Hard Mode");
	m_option_quit.SetText("Quit");
	m_option_normal.SetFont(*(FontManager::Instance().GetFont("fonts/rough_typewriter.otf")));
	m_option_hard.SetFont(*(FontManager::Instance().GetFont("fonts/rough_typewriter.otf")));
	m_option_quit.SetFont(*(FontManager::Instance().GetFont("fonts/rough_typewriter.otf")));
	m_option_normal.SetSize(m_text_size);
	m_option_hard.SetSize(m_text_size);
	m_option_quit.SetSize(m_text_size);
	m_option_normal.SetPosition(m_game_window.GetWidth() / 2.f - m_option_normal.GetRect().GetWidth() / 2.f,
								m_game_window.GetHeight() * 0.6f);
	m_option_hard.SetPosition(m_game_window.GetWidth() / 2.f - m_option_hard.GetRect().GetWidth() / 2.f,
							  m_game_window.GetHeight() * 0.7f);
	m_option_quit.SetPosition(m_game_window.GetWidth() / 2.f - m_option_quit.GetRect().GetWidth() / 2.f,
							  m_game_window.GetHeight() * 0.8f);

	m_default_color = sf::Color::White;
	m_selected_color = sf::Color::Yellow;

	m_option_normal.SetColor(m_default_color);
	m_option_hard.SetColor(m_default_color);
	m_option_quit.SetColor(m_default_color);
	m_titlestring_upper.SetColor(m_default_color);
	m_titlestring_midle.SetColor(m_default_color);
	m_titlestring_bottom.SetColor(m_default_color);

	m_mouse.x = 0.f;
	m_mouse.y = 0.f;

	return true;
}

States MainMenu::Events()
{
	sf::Event input;
	while(m_game_window.GetEvent(input)) {
		if(input.Type == sf::Event::Closed || (input.Type == sf::Event::KeyPressed && input.Key.Code == sf::Key::Escape))
			return S_Quit;

		if(input.Type == sf::Event::MouseMoved) {
			m_mouse.x = static_cast<float>(input.MouseMove.X);
			m_mouse.y = static_cast<float>(input.MouseMove.Y);
			if(m_option_normal.GetRect().Contains(m_mouse.x, m_mouse.y)) {
				m_option_normal.SetColor(m_selected_color);
			} else {
				m_option_normal.SetColor(m_default_color);
			}
			if(m_option_hard.GetRect().Contains(m_mouse.x, m_mouse.y)) {
				m_option_hard.SetColor(m_selected_color);
			} else {
				m_option_hard.SetColor(m_default_color);
			}
			if(m_option_quit.GetRect().Contains(m_mouse.x, m_mouse.y)) {
				m_option_quit.SetColor(m_selected_color);
			} else {
				m_option_quit.SetColor(m_default_color);
			}
		}

		if(input.Type == sf::Event::MouseButtonPressed && input.MouseButton.Button == sf::Mouse::Left) {
			if(m_option_normal.GetRect().Contains(m_mouse.x, m_mouse.y))
				return S_NormalMode;
			else if(m_option_hard.GetRect().Contains(m_mouse.x, m_mouse.y))
				return S_HardMode;
			else if(m_option_quit.GetRect().Contains(m_mouse.x, m_mouse.y))
				return S_Quit;
		}
	}
	return S_MainMenu;
}

void MainMenu::Draw()
{
	m_game_window.Clear();
	m_game_window.Draw(m_titlestring_upper);
	m_game_window.Draw(m_titlestring_midle);
	m_game_window.Draw(m_titlestring_bottom);
	m_game_window.Draw(m_option_normal);
	m_game_window.Draw(m_option_hard);
	m_game_window.Draw(m_option_quit);
	m_game_window.Display();
}