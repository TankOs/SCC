//hardmode.cpp
#include "hardmode.h"
#include "circleangle.h"
#include "circlerail.h"
#include "soundbutton.h"
#include "soundbuttonrenderer.h"
#include "soundmanager.h"
#include "fontmanager.h"
#include "global_functions.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <utility>
#include <string>
#include <sstream>

bool HardMode::Init()
{
	if(!SoundManager::Instance().LoadSound("sounds/buttonsound_1.ogg") || !SoundManager::Instance().LoadSound("sounds/buttonsound_2.ogg") ||
	   !SoundManager::Instance().LoadSound("sounds/buttonsound_3.ogg") || !SoundManager::Instance().LoadSound("sounds/buttonsound_4.ogg") ||
	   !SoundManager::Instance().LoadSound("sounds/drumloop.ogg") || !SoundManager::Instance().LoadSound("sounds/rotationloop.ogg") ||
	   !SoundManager::Instance().LoadSound("sounds/win.ogg") || !SoundManager::Instance().LoadSound("sounds/lose.ogg"))
	   return false;

	if(!FontManager::Instance().LoadFont("fonts/rough_typewriter.otf"))
		return false;

	m_buttons.push_back(std::make_pair(SoundButton(*(SoundManager::Instance().GetSound("sounds/buttonsound_1.ogg")), sf::Color::Blue, false),
									   CircleAngle(CircleAngle::s_PI)));
	m_buttons.push_back(std::make_pair(SoundButton(*(SoundManager::Instance().GetSound("sounds/buttonsound_2.ogg")), sf::Color::Red, false),
									   CircleAngle(CircleAngle::s_PI / 2.f)));
	m_buttons.push_back(std::make_pair(SoundButton(*(SoundManager::Instance().GetSound("sounds/buttonsound_3.ogg")), sf::Color::Green, false),
									   CircleAngle(CircleAngle::s_PI * 1.5f)));
	m_buttons.push_back(std::make_pair(SoundButton(*(SoundManager::Instance().GetSound("sounds/buttonsound_4.ogg")), sf::Color::Yellow, false),
									   CircleAngle(0.f)));

	// set buttonpositions
	for(ButtonAngleVec::iterator it(m_buttons.begin()), end(m_buttons.end()); it != end; ++it)
		it->first.m_position = m_rail.GetPositionOnRail(it->second.m_angle);

	m_drumloop.SetBuffer(*(SoundManager::Instance().GetSound("sounds/drumloop.ogg")));
	m_rotationloop.SetBuffer(*(SoundManager::Instance().GetSound("sounds/rotationloop.ogg")));
	m_win_sound.SetBuffer(*(SoundManager::Instance().GetSound("sounds/win.ogg")));
	m_lose_sound.SetBuffer(*(SoundManager::Instance().GetSound("sounds/lose.ogg")));
	m_drumloop.SetLoop(true);
	m_rotationloop.SetLoop(true);

	// initialise all additional variables
	MaxSoundDuration();
	m_igstates = IGS_ShowOrder;
	m_mouse.x = 0.f;
	m_mouse.y = 0.f;
	m_no_colors = false;
	m_rotate_clockwise = (sf::Randomizer::Random(0, 1) == 1);
	m_showtime = 0.5f;
	m_shownext = m_showtime + 0.1f;
	m_text_size = 30.f;
	m_swapcount = sf::Randomizer::Random(m_swapcount_min, m_swapcount_max);
	m_current_swapcount = 0;
	m_randomizer_end = m_buttons.size() - 1;
	m_current_orderelement = 0;

	// set the ingametext
	m_status_string.SetFont(*(FontManager::Instance().GetFont("fonts/rough_typewriter.otf")));
	m_soundcount_string.SetFont(*(FontManager::Instance().GetFont("fonts/rough_typewriter.otf")));
	m_status_string.SetSize(m_text_size);
	m_soundcount_string.SetSize(m_text_size);

	// reserve memory for the complete order
	m_order.reserve(m_wincondition);

	// create the first buttonorder
	for(OrderVec::size_type i(0); i != m_soundorder_init; ++i)
		m_order.push_back(sf::Randomizer::Random(0, m_randomizer_end));

	UpdateStatusString("Listen");
	UpdateSoundCountString(m_order.size() - m_current_orderelement);
	m_drumloop.Play();
	m_timer.Reset();

	return true;
}

States HardMode::Events()
{
	sf::Event input;
	while(m_game_window.GetEvent(input)) {
		if(input.Type == sf::Event::Closed || (input.Type == sf::Event::KeyPressed && input.Key.Code == sf::Key::Escape)) {
			m_drumloop.Stop();
			m_rotationloop.Stop();
			return S_Quit;
		}
		
		if(input.Type == sf::Event::MouseMoved) {
			m_mouse.x = static_cast<float>(input.MouseMove.X);
			m_mouse.y = static_cast<float>(input.MouseMove.Y);
		}

		if(m_igstates == IGS_RepeatOrder && input.Type == sf::Event::MouseButtonPressed && input.MouseButton.Button == sf::Mouse::Left) {
			for(ButtonAngleVec::size_type index(0), end(m_buttons.size()); index != end; ++index) {
				if(IsPointInsideCircle(m_mouse, m_buttons[index].first.m_position, m_renderer.GetCircleRadius())) {
					// check if the clicked button was the correct one, if not -> GAME OVER
					if(m_order[m_current_orderelement] == index) {
						m_buttons[index].first.m_showcolor = true;
						m_buttons[index].first.m_sound.Play();
						++m_current_orderelement;
						UpdateSoundCountString(m_order.size() - m_current_orderelement);
					} else {
						m_drumloop.Stop();
						m_rotationloop.Stop();
						m_lose_sound.Play();
						m_igstates = IGS_Lose;
						UpdateStatusString("You lost! 'Return' = back to mainmenu");
						// in "Lose"-state the text is set to the players performance
						UpdateSoundCountString((m_order.size() == m_soundorder_init ? m_current_orderelement : m_order.size() - 1));
					}
					// check if the clicked button was the last one, if so:
					// - add a new orderelement
					// - update ingametext
					// - check if its time for some swaping
					if(m_current_orderelement == m_order.size()) {
						if(m_order.size() == m_wincondition) {
							m_drumloop.Stop();
							m_rotationloop.Stop();
							m_win_sound.Play();
							m_igstates = IGS_Win;
							UpdateStatusString("Nice, you won! 'Return' = back to mainmenu");
							// in "Win"-state the text is set to the players performance
							UpdateSoundCountString(m_order.size());
						} else if(m_order.size() % m_swap_start == 0) {
							m_igstates = IGS_WaitForSwaping;
						} else {
							// Set random direction for rotation while the order is shown
							m_rotate_clockwise = (sf::Randomizer::Random(0, 1) == 1);
							m_igstates = IGS_ShowOrder;
							UpdateStatusString("Listen");
						}
						m_current_orderelement = 0;
						m_order.push_back(sf::Randomizer::Random(0, m_randomizer_end));
						m_igstates == IGS_Win ? ShowEachColor() : DontShowColor();
						m_timer.Reset();
					}
				}
			}
		}

		if(m_igstates == IGS_RepeatOrder && input.Type == sf::Event::MouseButtonReleased && input.MouseButton.Button == sf::Mouse::Left) {
			DontShowColor();
		}

		if((m_igstates == IGS_Win || m_igstates == IGS_Lose) && input.Type == sf::Event::KeyPressed &&
		   input.Key.Code == sf::Key::Return) {
			return S_MainMenu;
		}
	}

	switch(m_igstates) {
		case IGS_ShowOrder:
			RotateButtons();
			if(!m_no_colors && m_timer.GetElapsedTime() > m_showtime) {
				DontShowColor();
				m_no_colors = true;
			}
			if(m_timer.GetElapsedTime() > m_shownext) {
				if(m_current_orderelement == m_order.size()) {
					m_current_orderelement = 0;
					m_igstates = IGS_RepeatOrder;
					UpdateStatusString("Play it");
					UpdateSoundCountString(m_order.size() - m_current_orderelement);
				} else {
					m_buttons[m_order[m_current_orderelement]].first.m_showcolor = true;
					m_buttons[m_order[m_current_orderelement]].first.m_sound.Play();
					++m_current_orderelement;
				}
				m_no_colors = false;
				m_timer.Reset();
			}
			break;
		case IGS_WaitForSwaping:
			// wait as long as the longest soundeffect needs to be played
			if(m_timer.GetElapsedTime() > m_max_sound_duration) {
				// switch the backgroundmusic and start swaping
				m_drumloop.Stop();
				m_rotationloop.Play();
				// while swaping, each buttoncolor is shown
				ShowEachColor();
				m_igstates = IGS_Swap;
				UpdateStatusString("Swapping");
				m_timer.Reset();
			}
			break;
		case IGS_Swap:
			if(m_timer.GetElapsedTime() > m_swaptime) {
				if(m_current_swapcount == m_swapcount) {
					DontShowColor();
					// set music back to default music
					m_rotationloop.Stop();
					m_drumloop.Play();
					// set variables back to their initiate values
					m_current_swapcount = 0;
					m_swapcount = sf::Randomizer::Random(m_swapcount_min, m_swapcount_max);
					// set random direction for rotation while the order is shown
					m_rotate_clockwise = (sf::Randomizer::Random(0, 1) == 1);
					// switch back to the "showorder"-state
					m_igstates = IGS_ShowOrder;
					UpdateStatusString("Listen");
				} else {
					SwapButtonPositions();
					++m_current_swapcount;
				}
				m_timer.Reset();
			}
			break;
		default:
			break;
	}

	return S_HardMode;
}

void HardMode::Draw()
{
	m_game_window.Clear();
	for(ButtonAngleVec::const_iterator it(m_buttons.begin()), end(m_buttons.end()); it != end; ++it) {
		m_renderer.Draw(it->first);
	}
	m_game_window.Draw(m_status_string);
	if(m_igstates == IGS_RepeatOrder || m_igstates == IGS_Lose || m_igstates == IGS_Win) {
		m_game_window.Draw(m_soundcount_string);
	}
	m_game_window.Display();
}

void HardMode::DontShowColor()
{
	for(ButtonAngleVec::iterator it(m_buttons.begin()), end(m_buttons.end()); it != end; ++it)
		it->first.m_showcolor = false;
}

void HardMode::ShowEachColor()
{
	for(ButtonAngleVec::iterator it(m_buttons.begin()), end(m_buttons.end()); it != end; ++it)
		it->first.m_showcolor = true;
}

void HardMode::RotateButtons()
{
	for(ButtonAngleVec::iterator it(m_buttons.begin()), end(m_buttons.end()); it != end; ++it) {
		it->second.ChangeAngle(m_rotate_clockwise, m_game_window.GetFrameTime());
		it->first.m_position = m_rail.GetPositionOnRail(it->second.m_angle);
	}
}

void HardMode::MaxSoundDuration()
{
	m_max_sound_duration = 0.f;
	for(ButtonAngleVec::iterator it(m_buttons.begin()), end(m_buttons.end()); it != end; ++it) {
		float next_duration(it->first.m_sound.GetBuffer()->GetDuration());
		if(next_duration > m_max_sound_duration)
			m_max_sound_duration = next_duration;
	}
}

void HardMode::SwapButtonPositions()
{
	// choose 2 soundbuttons
	unsigned int first_pos(sf::Randomizer::Random(0, m_randomizer_end));
	unsigned int second_pos;
	do {
		second_pos = sf::Randomizer::Random(0, m_randomizer_end);
	}while(first_pos == second_pos);
	// swap the positions and angles (IMPORTANT) of these 2 soundbuttons
	sf::Vector2f temp_pos = m_buttons[first_pos].first.m_position;
	m_buttons[first_pos].first.m_position = m_buttons[second_pos].first.m_position;
	m_buttons[second_pos].first.m_position = temp_pos;

	float temp_angle = m_buttons[first_pos].second.m_angle;
	m_buttons[first_pos].second.m_angle = m_buttons[second_pos].second.m_angle;
	m_buttons[second_pos].second.m_angle = temp_angle;
}

void HardMode::UpdateStatusString(const std::string& new_text)
{
	m_status_string.SetText(new_text);
	m_status_string.SetPosition(m_game_window.GetWidth() / 2.f - m_status_string.GetRect().GetWidth() / 2.f,
								m_game_window.GetHeight() * 0.03f);
}

void HardMode::UpdateSoundCountString(const unsigned int new_value)
{
	std::ostringstream convert;
	if(m_igstates == IGS_Win || m_igstates == IGS_Lose) {
		convert << "Best performance: " << new_value << (new_value == 1 ? " sound" : " sounds");
	} else {
		convert << new_value << (new_value == 1 ? " sound" : " sounds") << " left";
	}
	m_soundcount_string.SetText(convert.str());
	m_soundcount_string.SetPosition(m_game_window.GetWidth() / 2.f - m_soundcount_string.GetRect().GetWidth() / 2.f,
									m_game_window.GetHeight() * 0.93f);
}