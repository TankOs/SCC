//all_gamestate.h
#ifndef ALLOFMYGAMESTATESTOGETHER_H
#define ALLOFMYGAMESTATESTOGETHER_H

// Gamestate class
#include "gamestate.h"
// Gamestate classes for each gamestate
#include "mainmenu.h"
#include "normalmode.h"
#include "hardmode.h"

#endif // ALLOFMYGAMESTATESTOGETHER_H