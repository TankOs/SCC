//fontmanager.cpp
#include "fontmanager.h"
#include <SFML/Graphics.hpp>
#include <string>

bool FontManager::LoadFont(const std::string& filename)
{
	if(!m_font[filename]) {
		m_font[filename] = new sf::Font;
		if(!m_font[filename]->LoadFromFile(filename)) {
			delete m_font[filename];
			m_font[filename] = 0;
			return false;
		}
	}
	return true;
}

sf::Font* FontManager::GetFont(const std::string& filename)
{
	if(LoadFont(filename)) {
		return m_font[filename];
	}
	return 0;
}

FontManager::~FontManager()
{
	for(FontMap::iterator it(m_font.begin()), end(m_font.end()); it != end; ++it)
	delete it->second;
}