//global_functions.cpp
#include "global_functions.h"
#include <SFML/Graphics.hpp>
#include <cmath>

bool IsPointInsideCircle(const sf::Vector2f& point, const sf::Vector2f& circle_center, const float& circle_radius)
{
	return (abs(point.x - circle_center.x) <= circle_radius) && (abs(point.y - circle_center.y) <= circle_radius);
}