//soundbutton.h
#ifndef MYSOUNDBUTTONS_H
#define MYSOUNDBUTTONS_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

class SoundButton {
public:
	// C'tor
	SoundButton(const sf::SoundBuffer& sound, const sf::Color& color = sf::Color::White,
				const bool showcolor = true, const sf::Vector2f& position = sf::Vector2f(0.f, 0.f)):
	m_sound(sound),
	m_color(color),
	m_position(position),
	m_showcolor(showcolor)
	{ }
	// Member (public because of laziness)
	sf::Sound m_sound;
	sf::Color m_color;
	sf::Vector2f m_position;
	bool m_showcolor;
};

#endif // MYSOUNDBUTTONS_H