//gameengine.h
#ifndef MYVERYOWNGAMEENGINE_H
#define MYVERYOWNGAMEENGINE_H

#include "all_gamestates.h"
#include <SFML/Graphics.hpp>
#include <string>

class GameEngine {
public:
	// C'tor
	GameEngine(const unsigned int width, const unsigned int height, const unsigned int color_depths,
			   const unsigned int frames_per_second, const std::string& title, const bool fullscreen):
	m_current_state(S_Quit),
	m_gamestate(0),
	m_engine_window(sf::VideoMode(width, height, color_depths), title, (fullscreen ? sf::Style::Fullscreen : sf::Style::Close))
	{
		m_engine_window.SetFramerateLimit(frames_per_second);
	}
	// Destructor
	~GameEngine();
	// Methods
	States GetCurrentState() const { return m_current_state; }
	GameState* GetGameState() const { return m_gamestate; }
	bool SetState(const States& new_state);
private:
	States m_current_state;
	GameState* m_gamestate;
	sf::RenderWindow m_engine_window;
};

#endif // MYVERYOWNGAMEENGINE_H