//fontmanager.h
#ifndef MYFONTMANAGER_H
#define MYFONTMANAGER_H

#include <SFML/Graphics.hpp>
#include <map>
#include <string>

class FontManager {
public:
	// Singleton
	static FontManager& Instance()
	{
		static FontManager singleton;
		return singleton;
	}
	// Methods
	bool LoadFont(const std::string& filename);
	sf::Font* GetFont(const std::string& filename);
	// Destructor
	~FontManager();
private:
	typedef std::map<std::string, sf::Font*> FontMap;
	FontMap m_font;
	// Hidden C'tor, Copy C'tor and assignmentoperator
	FontManager() { }
	FontManager(const FontManager& copy);
	FontManager& operator=(const FontManager& rhs);
};

#endif MYFONTMANAGER_H