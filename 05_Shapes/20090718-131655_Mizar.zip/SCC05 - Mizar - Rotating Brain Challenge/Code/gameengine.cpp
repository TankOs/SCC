//gameengine.cpp
#include "gameengine.h"
#include "all_gamestates.h"
#include <SFML/Graphics.hpp>

GameEngine::~GameEngine()
{
	m_engine_window.Close();
	delete m_gamestate;
}

bool GameEngine::SetState(const States &new_state)
{
	m_current_state = new_state;
	delete m_gamestate;
	// to prevent a second delete by the destructor
	m_gamestate = 0;
	switch(m_current_state) {
		case S_MainMenu:
			m_gamestate = new MainMenu(m_engine_window);
			break;
		case S_NormalMode:
			m_gamestate = new NormalMode(m_engine_window);
			break;
		case S_HardMode:
			m_gamestate = new HardMode(m_engine_window);
			break;
		default:
			return false;
			break;
	}
	return m_gamestate->Init();
}