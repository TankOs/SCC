//soundbuttonrenderer.cpp
#include "soundbuttonrenderer.h"
#include "soundbutton.h"
#include <SFML/Graphics.hpp>

void SoundButtonRenderer::Draw(const SoundButton& soundbutton)
{
	m_circle.SetPosition(soundbutton.m_position);
	soundbutton.m_showcolor ? m_circle.SetColor(soundbutton.m_color) : m_circle.SetColor(sf::Color::White);
	m_window.Draw(m_circle);
}