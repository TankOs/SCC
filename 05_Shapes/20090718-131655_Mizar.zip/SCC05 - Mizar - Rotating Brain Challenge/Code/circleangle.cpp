//circleangle.cpp
#include "circleangle.h"

const float CircleAngle::s_PI = 3.14159f;
const float CircleAngle::s_lowerbound = 0.f;
const float CircleAngle::s_upperbound = 2 * s_PI;

void CircleAngle::ChangeAngle(const bool clockwise, const float& frametime)
{
	m_angle_mod_this_frame = m_angle_mod * frametime;
	if(clockwise)
		m_angle - m_angle_mod_this_frame > s_lowerbound ? m_angle -= m_angle_mod_this_frame : m_angle = s_upperbound;
	else
		m_angle + m_angle_mod_this_frame < s_upperbound ? m_angle += m_angle_mod_this_frame : m_angle = s_lowerbound;
}