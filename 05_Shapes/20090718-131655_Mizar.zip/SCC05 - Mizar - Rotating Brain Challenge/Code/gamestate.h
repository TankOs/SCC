//gamestate.h
#ifndef MYGAMESTATES_H
#define MYGAMESTATES_H

#include <SFML/Graphics.hpp>

enum States {
	S_MainMenu = 0,
	S_NormalMode,
	S_HardMode,
	S_Quit
};

//enum InGameStates {
//	IGS_ShowOrder = 0,
//	IGS_RepeatOrder,
//	IGS_WaitForRotation,
//	IGS_Rotate,
//	IGS_Win,
//	IGS_Lose
//};

class GameState {
public:
	// C'tor
	GameState(sf::RenderWindow& window):
	m_game_window(window)
	{ }
	// virtual Destructor
	virtual ~GameState() { }
	// Methods
	virtual bool Init() = 0;
	virtual States Events() = 0;
	virtual void Draw() = 0;
protected:
	sf::RenderWindow& m_game_window;
};

#endif // MYGAMESTATES_H