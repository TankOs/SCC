//mainmenu.h
#ifndef MYMAINMENU_H
#define MYMAINMENU_H

#include "gamestate.h"
#include <SFML/Graphics.hpp>

class MainMenu: public GameState {
public:
	// C'tor
	MainMenu(sf::RenderWindow& window):
	GameState(window)
	{ }
	// Methods
	bool Init();
	States Events();
	void Draw();
private:
	sf::String m_titlestring_upper;
	sf::String m_titlestring_midle;
	sf::String m_titlestring_bottom;
	sf::String m_option_normal;
	sf::String m_option_hard;
	sf::String m_option_quit;
	sf::Vector2f m_mouse;
	sf::Color m_default_color;
	sf::Color m_selected_color;
	float m_title_size;
	float m_text_size;
};

#endif // MYMAINMENU_H