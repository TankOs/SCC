//circlerail.cpp
#include "circlerail.h"
#include <SFML/Graphics.hpp>
#include <cmath>

sf::Vector2f CircleRail::GetPositionOnRail(const float &angle) const
{
	return sf::Vector2f(m_center.x + m_radius * sin(angle), m_center.y + m_radius * cos(angle));
}