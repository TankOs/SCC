//imagemanager.cpp
#include "soundmanager.h"
#include <SFML/Audio.hpp>

// Methods
bool SoundManager::LoadSound(const std::string &filename)
{
	if(!m_sounds[filename]) {
		m_sounds[filename] = new sf::SoundBuffer;
		if(!m_sounds[filename]->LoadFromFile(filename)) {
			delete m_sounds[filename];
			m_sounds[filename] = 0; // to prevent a second delete by the destructor
			return false;
		}
	}
	return true;
}

sf::SoundBuffer* SoundManager::GetSound(const std::string &filename)
{
	if(LoadSound(filename)) {
		return m_sounds[filename];
	}
	return 0;
}

// Destructor
SoundManager::~SoundManager()
{
	for(SoundMap::iterator it(m_sounds.begin()), end(m_sounds.end()); it != end; ++it) {
		delete it->second;
	}
}