//soundbuttonrenderer.h
#ifndef MYSOUNDBUTTONRENDERER_H
#define MYSOUNDBUTTONRENDERER_H

#include "soundbutton.h"
#include <SFML/Graphics.hpp>

class SoundButtonRenderer {
public:
	// C'tor
	SoundButtonRenderer(const float& circle_radius, sf::RenderWindow& window):
	m_window(window),
	m_circle(sf::Shape::Circle(0.f, 0.f, circle_radius, sf::Color::White)),
	m_radius(circle_radius)
	{ }
	// Getter
	float GetCircleRadius() const { return m_radius; }
	// Methods
	void Draw(const SoundButton& soundbutton);
private:
	sf::RenderWindow& m_window;
	sf::Shape m_circle;
	float m_radius;
};

#endif // MYSOUNDBUTTONRENDERER_H