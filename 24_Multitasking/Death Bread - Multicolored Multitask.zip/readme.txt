Hier mein Beitrag zum SCC 24.
Genutzte SFML-Version: 1.6

Da ich mir mit der Ordnerstruktur usw. bei nicht-Macs nicht so sicher bin, hier nochmal ein paar Informationen, die ihr vielleicht zum kompilieren benötigt:
 - Gelinkte Frameworks: SFML, sfml-system, sfml-window, sfml-graphics, sfml-audio
 - Die Bilder usw. befinden sich in dem data-Ordner. Leider weiß ich nicht, wo sie bei Linux oder Windoof hin müssen, aber das lässt sich vermutlich aus den Pfadangaben in der Source lesen.

Falls irgendwelche Infos fehlen, fragt mich bitte im Forum ;)