/* (c) by Jonas Kaiser - quit.cpp */
/* Header */
#include "gameover.h"


GameOver::GameOver(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, Sound &TmpSound, sf::Image &ButtonImg, sf::Image &MsgBoxImg, sf::Font &KomikaAxis, float &TmpKeyUse) :
	GameWindow(TmpWindow),
	GameSystem(TmpSystem),
	GameTick(TmpTick),
	GameInput(TmpInput),
	GameSound(TmpSound),
	GameOverMsg(GameWindow, GameSystem, MsgBoxImg, KomikaAxis, sf::IntRect(0, 0, 800, 450), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 150 * GameSystem.GetWindowFactor(), "You lost!\nBut thats\nalright, because\nyou can't win.\n\nFinal score: " + FinalScore),
	RetryButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImg, KomikaAxis, sf::IntRect(0, 0, 800, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 150 * GameSystem.GetWindowFactor(), "Play again", 1),
	ReturnButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImg, KomikaAxis, sf::IntRect(0, 0, 800, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 300 * GameSystem.GetWindowFactor(), "Return to main menu", 2),
	LastKeyUse(TmpKeyUse)
{
	
}
GameOver::~GameOver()
{
	
}


void GameOver::Recalculate()
{
	GameOverMsg.Recalculate();
	RetryButton.Recalculate();
	ReturnButton.Recalculate();
	GameOverMsg.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	RetryButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	ReturnButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	GameOverMsg.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 150 * GameSystem.GetWindowFactor());
	RetryButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 150 * GameSystem.GetWindowFactor());
	ReturnButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 300 * GameSystem.GetWindowFactor());
}

void GameOver::Reset()
{
	MouseOrKey = 0;
	ActiveButton = 0;
	TmpActiveButton = 0;
}

void GameOver::Update()
{
	GameInput.GameOver(LastKeyUse, MouseOrKey, ActiveButton);
	if(GameInput.MouseMoved && MouseOrKey == 0)
		ActiveButton = 0;
	
	RetryButton.IsActive(MouseOrKey, ActiveButton);
	if(RetryButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		GameSystem.SetState(System::PLAY);
	}
	ReturnButton.IsActive(MouseOrKey, ActiveButton);
	if(ReturnButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		GameSystem.SetState(System::MENU);
	}
	
	if(TmpActiveButton != ActiveButton && ActiveButton != 0 && GameSystem.GetSound())
		GameSound.MenuChange.Play();
	TmpActiveButton = ActiveButton;
}

void GameOver::Display()
{
	GameOverMsg.Display();
	RetryButton.Display();
	ReturnButton.Display();
}

void GameOver::Delete()
{
	GameOverMsg.Delete();
}

void GameOver::Set(std::string &TmpFinalScore)
{
	FinalScore = TmpFinalScore;
	GameOverMsg.SetText("Final score: " + FinalScore, 6);
}