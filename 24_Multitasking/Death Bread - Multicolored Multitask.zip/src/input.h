/* (c) by Jonas Kaiser - input.h */
/* Headerguards */
#ifndef INPUT_H
#define INPUT_H

/* Headers */
#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "system.h"
#include "tick.h"


class Input
{
public:
	Input(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick);
	~Input();
	
	void Quit(float &Last, bool &MouseOrKey, int &ActiveButton);
	void Menu(float &Last, bool &MouseOrKey, int &ActiveButton);
	void Options(float &Last, bool &MouseOrKey, int &ActiveButton);
	void Help(float &Last, bool &MouseOrKey, int &ActiveButton);
	void About(float &Last, bool &MouseOrKey, int &ActiveButton);
	void Play(bool Explaining, int &GameOver);
	void GameOver(float &Last, bool &MouseOrKey, int &ActiveButton);
	
	int MouseX();
	int MouseY();
	
	bool IsDown(sf::Key::Code KeyCode);
	bool IsDown(sf::Mouse::Button MouseButton);
	
	bool MouseMoved;
	bool LeftMouseButton;
	
private:
	sf::RenderWindow &GameWindow;
	
	System &GameSystem;
	Tick &GameTick;
	
	sf::Event EventHandler;
	const sf::Input &InputHandler;
};

#endif