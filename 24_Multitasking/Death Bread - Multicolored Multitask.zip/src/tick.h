/* (c) by Jonas Kaiser - tick.h */
/* Headerguards */
#ifndef TICK_H
#define TICK_H

/* Headers */
#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>


class Tick
{
public:
	Tick();
	~Tick();
	
	void Update(float FPSReturnTime);
	
	float Get();
	void Set(float New);
	
	void UpdateFPS(float ReturnTime);
	float GetFPS();
	
private:	
	float Time;
	sf::Clock Timer;
	
	sf::Clock FPSTimer;
	int Frames;
	int FPS;
};

#endif