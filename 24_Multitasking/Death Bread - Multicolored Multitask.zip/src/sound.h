/* (c) by Jonas Kaiser - sound.h */
/* Headerguards */
#ifndef SOUND_H
#define SOUND_H

/* Headers */
#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "system.h"


class Sound
{
public:
	Sound(System &TmpSystem);
	~Sound();
	
	sf::Music Music;
	
	sf::SoundBuffer MenuChangeBuffer;
	sf::Sound MenuChange;
	sf::SoundBuffer MenuSelectBuffer;
	sf::Sound MenuSelect;
	
	sf::SoundBuffer GameWallBuffer;
	sf::Sound GameWall;
	sf::SoundBuffer GameBallBuffer;
	sf::Sound GameBall;
	sf::SoundBuffer GameSwitchBuffer;
	sf::Sound GameSwitch;
	sf::SoundBuffer GameSpikeBuffer;
	sf::Sound GameSpike;
	
private:
	System &GameSystem;
};

#endif