/* (c) by Jonas Kaiser - quit.cpp */
/* Header */
#include "quit.h"


Quit::Quit(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, Sound &TmpSound, sf::Image &ButtonImg, sf::Image &MsgBoxImg, sf::Font &KomikaAxis, float &TmpKeyUse) :
	GameWindow(TmpWindow),
	GameSystem(TmpSystem),
	GameTick(TmpTick),
	GameInput(TmpInput),
	GameSound(TmpSound),
	QuitMsg(GameWindow, GameSystem, MsgBoxImg, KomikaAxis, sf::IntRect(0, 0, 800, 450), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 75 * GameSystem.GetWindowFactor(), "Do you really\nwant to quit?"),
	YesButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImg, KomikaAxis, sf::IntRect(800, 0, 1200, 150), GameSystem.GetWindowWidth() / 2 - 200 * GameSystem.GetWindowFactor(), GameSystem.GetWindowHeight() / 2 + 225 * GameSystem.GetWindowFactor(), "Yes", 1),
	NoButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImg, KomikaAxis, sf::IntRect(800, 0, 1200, 150), GameSystem.GetWindowWidth() / 2 + 200 * GameSystem.GetWindowFactor(), GameSystem.GetWindowHeight() / 2 + 225 * GameSystem.GetWindowFactor(), "No", 2),
	LastKeyUse(TmpKeyUse)
{
	
}
Quit::~Quit()
{
	
}


void Quit::Recalculate()
{
	QuitMsg.Recalculate();
	YesButton.Recalculate();
	NoButton.Recalculate();
	QuitMsg.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	YesButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	NoButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	QuitMsg.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 75 * GameSystem.GetWindowFactor());
	YesButton.SetPosition(GameSystem.GetWindowWidth() / 2 - 200 * GameSystem.GetWindowFactor(), GameSystem.GetWindowHeight() / 2 + 225 * GameSystem.GetWindowFactor());
	NoButton.SetPosition(GameSystem.GetWindowWidth() / 2 + 200 * GameSystem.GetWindowFactor(), GameSystem.GetWindowHeight() / 2 + 225 * GameSystem.GetWindowFactor());
}

void Quit::Reset()
{
	MouseOrKey = 0;
	ActiveButton = 0;
	TmpActiveButton = 0;
}

void Quit::Update()
{
	GameInput.Quit(LastKeyUse, MouseOrKey, ActiveButton);
	if(GameInput.MouseMoved && MouseOrKey == 0)
		ActiveButton = 0;
	
	YesButton.IsActive(MouseOrKey, ActiveButton);
	if(YesButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
		{
			GameSound.MenuSelect.Play();
			sf::Sleep(0.25);
		}
		GameSystem.SetState(System::QUITTED);
	}
	NoButton.IsActive(MouseOrKey, ActiveButton);
	if(NoButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		GameSystem.SetState(System::MENU);
	}
	
	if(TmpActiveButton != ActiveButton && ActiveButton != 0 && GameSystem.GetSound())
		GameSound.MenuChange.Play();
	TmpActiveButton = ActiveButton;
}

void Quit::Display()
{
	QuitMsg.Display();
	YesButton.Display();
	NoButton.Display();
}

void Quit::Delete()
{
	QuitMsg.Delete();
}