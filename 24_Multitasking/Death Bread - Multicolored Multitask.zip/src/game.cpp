/* (c) by Jonas Kaiser - game.cpp */
/* Header */
#include "game.h"


Game::Game() :
	GameWindow(),
	GameSystem(GameWindow),
	GameInput(GameWindow, GameSystem, GameTick),
	GameSound(GameSystem),
	QuitScreen(GameWindow, GameSystem, GameTick, GameInput, GameSound, ButtonImg, MsgBoxImg, KomikaAxis, LastKeyUse),
	MenuScreen(GameWindow, GameSystem, GameTick, GameInput, GameSound, ButtonImg, KomikaAxis, LastKeyUse),
	OptionScreen(GameWindow, GameSystem, GameTick, GameInput, GameSound, ButtonImg, KomikaAxis, LastKeyUse),
	HelpScreen(GameWindow, GameSystem, GameTick, GameInput, GameSound, ButtonImg, MsgBoxImg, KomikaAxis, LastKeyUse),
	AboutScreen(GameWindow, GameSystem, GameTick, GameInput, GameSound, ButtonImg, MsgBoxImg, KomikaAxis, LastKeyUse),
	PlayScreen(GameWindow, GameSystem, GameTick, GameInput, GameSound, KomikaAxis, MsgBoxImg, FinalScore),
	GameOverScreen(GameWindow, GameSystem, GameTick, GameInput, GameSound, ButtonImg, MsgBoxImg, KomikaAxis, LastKeyUse),
	IsRunning(true),
	TmpFullscreen(1),
	LastKeyUse(-1)
{
	GameWindow.Create(sf::VideoMode(800, 600), "Multicolored Multitask", sf::Style::Close);
	
	GameSystem.UsedWindow.Left = 0;
	GameSystem.UsedWindow.Top = 0;
	GameSystem.UsedWindow.Right = GameSystem.GetWindowWidth();
	GameSystem.UsedWindow.Bottom = GameSystem.GetWindowHeight();
	
	GameWindow.SetFramerateLimit(40);
	
	BackgroundImg.SetSmooth(false);
	if(!BackgroundImg.LoadFromFile("data/background.png"))
	{
		std::cout << "error: could not load file \"data/background.png\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	Background.SetImage(BackgroundImg);
	Background.SetCenter(Background.GetSubRect().GetWidth() / 2, Background.GetSubRect().GetHeight() / 2);
	Background.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	Background.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2);
	
	CursorImg.SetSmooth(false);
	if(!CursorImg.LoadFromFile("data/cursor.png"))
	{
		std::cout << "error: could not load file \"data/cursor.png\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	Cursor.SetImage(CursorImg);
	Cursor.SetCenter(8, 8);
	Cursor.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	Cursor.SetPosition(GameInput.MouseX(), GameInput.MouseY());
	
	ButtonImg.SetSmooth(false);
	if(!ButtonImg.LoadFromFile("data/buttons.png"))
	{
		std::cout << "error: could not load file \"data/buttons.png\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	
	MsgBoxImg.SetSmooth(false);
	if(!MsgBoxImg.LoadFromFile("data/messagebox.png"))
	{
		std::cout << "error: could not load file \"data/messagebox.png\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	
	if(!KomikaAxis.LoadFromFile("data/komikaaxis.ttf", 72))
	{
		std::cout << "error: could not load file \"data/komikaaxis.ttf\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	
	GameSound.Music.Play();
}
Game::~Game()
{
	
}


void Game::Loop()
{
	while(IsRunning)
	{
		// Frames per second
		GameTick.Update(5);
		if(GameTick.GetFPS() != -1)
			std::cout << "FPS: " << GameTick.GetFPS() << std::endl;
						
		// If the state has changed
		if(TmpState != GameSystem.GetState())
		{
			QuitScreen.Reset();
			MenuScreen.Reset();
			OptionScreen.Reset();
			HelpScreen.Reset();
			AboutScreen.Reset();
			PlayScreen.Reset();
			GameOverScreen.Reset();
			
			TmpState = GameSystem.GetState();
		}
		
		// If the fullscreen option has been changed
		if(TmpFullscreen != GameSystem.GetFullscreen())
		{
			QuitScreen.Recalculate();
			MenuScreen.Recalculate();
			OptionScreen.Recalculate();
			HelpScreen.Recalculate();
			AboutScreen.Recalculate();
			PlayScreen.Recalculate();
			GameOverScreen.Recalculate();
			
			Background.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
			Background.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2);
			Cursor.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
			
			TmpFullscreen = GameSystem.GetFullscreen();
		}
		
		if(GameSystem.GetMusic() && GameSound.Music.GetStatus() != sf::Music::Playing)
			GameSound.Music.Play();
		if(!GameSystem.GetMusic() && GameSound.Music.GetStatus() != sf::Music::Stopped)
			GameSound.Music.Stop();
		
		
		
		GameWindow.Clear();
		if(GameSystem.GetState() != System::PLAY)
			GameWindow.Draw(Background);

		if(GameSystem.GetState() == System::QUIT)
		{
			QuitScreen.Update();
			QuitScreen.Display();
		}
		else if(GameSystem.GetState() == System::MENU)
		{
			MenuScreen.Update();
			MenuScreen.Display();
		}
		else if(GameSystem.GetState() == System::OPTIONS)
		{
			OptionScreen.Update();
			OptionScreen.Display();
		}
		else if(GameSystem.GetState() == System::HELP)
		{
			HelpScreen.Update();
			HelpScreen.Display();
		}
		else if(GameSystem.GetState() == System::ABOUT)
		{
			AboutScreen.Update();
			AboutScreen.Display();
		}		
		else if(GameSystem.GetState() == System::PLAY)
		{
			PlayScreen.Update();
			PlayScreen.Display();
		}
		else if(GameSystem.GetState() == System::GAMEOVER)
		{
			GameOverScreen.Set(FinalScore);
			GameOverScreen.Update();
			GameOverScreen.Display();
		}
		else if(GameSystem.GetState() == System::QUITTED)
		{
			QuitScreen.Delete();
			HelpScreen.Delete();
			AboutScreen.Delete();
			PlayScreen.Delete();
			GameOverScreen.Delete();
			GameWindow.Close();
			IsRunning = false;
		}
		else
		{
			std::cout << "error: wrong state" << std::endl;
			GameSystem.SetState(System::QUITTED);
		}
		
		/* Cursor */
		GameWindow.ShowMouseCursor(false);
		Cursor.SetPosition(GameInput.MouseX(), GameInput.MouseY());
		if(GameSystem.GetState() != System::PLAY)
			GameWindow.Draw(Cursor);
		GameWindow.Display();
	}
}