/* (c) by Jonas Kaiser - sound.cpp */
/* Header */
#include "sound.h"


Sound::Sound(System &TmpSystem) :
	GameSystem(TmpSystem)
{
	if(!Music.OpenFromFile("data/multicolored_multitask.ogg"))
	{
		std::cout << "error: could not load file \"data/multicolored_multitask.ogg\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	Music.SetLoop(true);
	
	
	if(!MenuChangeBuffer.LoadFromFile("data/menu_change.wav"))
	{
		std::cout << "error: could not load file \"data/menu_change.wav\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	MenuChange.SetBuffer(MenuChangeBuffer);
	
	if(!MenuSelectBuffer.LoadFromFile("data/menu_select.wav"))
	{
		std::cout << "error: could not load file \"data/menu_select.wav\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	MenuSelect.SetBuffer(MenuSelectBuffer);
	
	
	if(!GameWallBuffer.LoadFromFile("data/game_wall.wav"))
	{
		std::cout << "error: could not load file \"data/game_wall.wav\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	GameWall.SetBuffer(GameWallBuffer);
	
	if(!GameBallBuffer.LoadFromFile("data/game_ball.wav"))
	{
		std::cout << "error: could not load file \"data/game_ball.wav\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	GameBall.SetBuffer(GameBallBuffer);
	
	if(!GameSwitchBuffer.LoadFromFile("data/game_switch.wav"))
	{
		std::cout << "error: could not load file \"data/game_switch.wav\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	GameSwitch.SetBuffer(GameSwitchBuffer);
	
	if(!GameSpikeBuffer.LoadFromFile("data/game_spike.wav"))
	{
		std::cout << "error: could not load file \"data/game_spike.wav\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	GameSpike.SetBuffer(GameSpikeBuffer);
	
}
Sound::~Sound()
{
	
}