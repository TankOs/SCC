/* (c) by Jonas Kaiser - button.cpp */
/* Header */
#include "button.h"


Button::Button(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, sf::Image &Image, sf::Font &KomikaAxis, sf::IntRect SubRect, float PosX, float PosY, std::string TmpText, int InitNumber) :
	GameWindow(TmpWindow),
	GameSystem(TmpSystem),
	GameTick(TmpTick),
	GameInput(TmpInput),
	TextSize(72),
	Number(InitNumber),
	Position(PosX, PosY)
{	
	Sprite.SetImage(Image);
	Sprite.SetSubRect(SubRect);
	Sprite.SetCenter(SubRect.GetWidth() / 2, SubRect.GetHeight() / 2);
	Sprite.SetPosition(Position.x, Position.y);
	
	Text.SetText(TmpText);
	Text.SetFont(KomikaAxis);
	Text.SetColor(sf::Color(0, 0, 0, 255));
	Text.SetPosition(Position.x, Position.y);
}
Button::~Button()
{
	
}


bool Button::MouseOver()
{
	if(GameInput.MouseX() >= Position.x - Sprite.GetSize().x / 2 && GameInput.MouseX() <= Position.x + Sprite.GetSize().x / 2 && GameInput.MouseY() >= Position.y - Sprite.GetSize().y / 2 && GameInput.MouseY() <= Position.y + Sprite.GetSize().y / 2)
		return true;
	else
		return false;
}

bool Button::IsActive(bool &MouseOrKey, int &ActiveNumber)
{
	if(MouseOver() && GameInput.MouseMoved)
	{
		MouseOrKey = 0;
		ActiveNumber = Number;
		Active = true;
		return true;
	}
	else if(ActiveNumber == Number)
	{
		Active = true;
		return true;
	}
	else
	{
		Active = false;
		return false;
	}
}

bool Button::IsActive(int &ActiveNumber)
{
	if(MouseOver())
	{
		ActiveNumber = Number;
		Active = true;
		return true;
	}
	else
	{
		Active = false;
		return false;
	}
}

bool Button::Used(float &LastKeyUse, bool &MouseOrKey, int &ActiveNumber)
{
	if((MouseOver() && GameInput.LeftMouseButton && MouseOrKey == 0) || (IsActive(MouseOrKey, ActiveNumber) && GameInput.IsDown(sf::Key::Return) && MouseOrKey == 1 && GameTick.Get() - LastKeyUse >= 0.25))
	{
		LastKeyUse = GameTick.Get();
		return true;
	}
	else
	{
		return false;
	}
}

std::string Button::GetText()
{
	return Text.GetText();
}

void Button::SetText(std::string New)
{
	Text.SetText(New);
	TextSize = 72;
	Recalculate();
}

int Button::GetNumber()
{
	return Number;
}

void Button::SetNumber(int New)
{
	Number = New;
}

void Button::SetPosition(int x, int y)
{
	Position.x = x;
	Position.y = y;
	
	Sprite.SetPosition(Position.x, Position.y);
	Text.SetPosition(Position.x, Position.y);
}

void Button::SetPosition(sf::Vector2i Pos)
{
	Position.x = Pos.x;
	Position.y = Pos.y;
	
	Sprite.SetPosition(Position.x, Position.y);
	Text.SetPosition(Position.x, Position.y);
}

void Button::SetScale(float x, float y)
{
	Sprite.SetScale(x, y);
	Text.SetScale(x, y);
}

void Button::SetScale(sf::Vector2f Scale)
{
	Sprite.SetScale(Scale);
	Text.SetScale(Scale);
}

void Button::Recalculate()
{
	Text.SetSize(TextSize);
	while(Text.GetRect().GetWidth() + 10 > Sprite.GetSubRect().GetWidth() * Text.GetScale().x || Text.GetRect().GetHeight() + 10 > Sprite.GetSubRect().GetHeight() * Text.GetScale().y)
	{
		TextSize--;
		Text.SetSize(TextSize);
	}
	Text.SetCenter(Text.GetRect().GetWidth() / 2 / Text.GetScale().x, Text.GetRect().GetHeight() / 2 / Text.GetScale().y);
}

void Button::Display()
{
	if(Active)
	{
		Text.SetColor(sf::Color(255, 255, 255, 255));
		Text.SetSize(TextSize - TextSize / 9);
		Text.SetCenter(Text.GetRect().GetWidth() / 2 / Text.GetScale().x, Text.GetRect().GetHeight() / 2 / Text.GetScale().y);
	}
	else
	{
		Text.SetColor(sf::Color(0, 0, 0, 255));
		Text.SetSize(TextSize);
		Text.SetCenter(Text.GetRect().GetWidth() / 2 / Text.GetScale().x, Text.GetRect().GetHeight() / 2 / Text.GetScale().y);
	}
	GameWindow.Draw(Sprite);
	GameWindow.Draw(Text);
}