/* (c) by Jonas Kaiser - messagebox.cpp */
/* Header */
#include "messagebox.h"


Messagebox::Messagebox(sf::RenderWindow &TmpWindow, System &TmpSystem, sf::Image &Image, sf::Font &KomikaAxis, sf::IntRect SubRect, float PosX, float PosY, std::string TmpContent) :
	GameWindow(TmpWindow),
	GameSystem(TmpSystem),
	Content(0),
	Line(1),
	Position(PosX, PosY)
{	
	Sprite.SetImage(Image);
	Sprite.SetSubRect(SubRect);
	Sprite.SetCenter(SubRect.GetWidth() / 2, SubRect.GetHeight() / 2);
	Sprite.SetPosition(Position.x, Position.y);
	
	for(int i = 0; i < TmpContent.length(); i++)
	{
		if(TmpContent[i] == '\n')
			Line++;
	}
	
	Content = new sf::String[Line];
	
	Line = 1;
	for(int i = 0; i < TmpContent.length(); i++)
	{
		if(TmpContent[i] == '\n')
		{
			Line++;
		}
		else
		{
			TmpText = Content[Line - 1].GetText();
			Content[Line - 1].SetText(TmpText + TmpContent[i]);
		}
	}
	
	for(int j = 0; j < Line; j++)
	{
		Content[j].SetFont(KomikaAxis);
		Content[j].SetColor(sf::Color(0, 0, 0, 255));
		Content[j].SetPosition(Position.x, Position.y + 70 * (j - ((float)Line - 1) / 2.f) * Content[j].GetScale().y);
	}
}
Messagebox::~Messagebox()
{
	
}


std::string Messagebox::GetText()
{
	return Text;
}

void Messagebox::SetText(std::string NewLine, int Line)
{
	Content[Line - 1].SetText(NewLine);
	Recalculate();
}

void Messagebox::SetPosition(int x, int y)
{
	Position.x = x;
	Position.y = y;
	
	Sprite.SetPosition(Position.x, Position.y);
	for(int i = 0; i < Line; i++)
	{
		Content[i].SetPosition(Position.x, Position.y + 70 * (i - ((float)Line - 1) / 2.f) * Content[i].GetScale().y);
	}
}

void Messagebox::SetPosition(sf::Vector2i Pos)
{
	Position.x = Pos.x;
	Position.y = Pos.y;
	
	Sprite.SetPosition(Position.x, Position.y);
	for(int i = 0; i < Line; i++)
	{
		Content[i].SetPosition(Position.x, Position.y + 70 * (i - ((float)Line - 1) / 2.f) * Content[i].GetScale().y);
	}
}

void Messagebox::SetScale(float x, float y)
{
	Sprite.SetScale(x, y);
	for(int i = 0; i < Line; i++)
	{
		Content[i].SetScale(x, y);
	}
}

void Messagebox::SetScale(sf::Vector2f Scale)
{
	Sprite.SetScale(Scale.x, Scale.y);
	for(int i = 0; i < Line; i++)
	{
		Content[i].SetScale(Scale.x, Scale.y);
	}
}

void Messagebox::Recalculate()
{
	for(int i = 0; i < Line; i++)
	{
		Content[i].SetSize(72);
		Content[i].SetCenter(Content[i].GetRect().GetWidth() / 2 / Content[i].GetScale().x, Content[i].GetRect().GetHeight() / 2 / Content[i].GetScale().y);
		Content[i].SetPosition(Position.x, Position.y + 70 * (i - ((float)Line - 1) / 2.f) * Content[i].GetScale().y);
	}	
}

void Messagebox::Display()
{
	GameWindow.Draw(Sprite);
	for(int i = 0; i < Line; i++)
	{
		GameWindow.Draw(Content[i]);
	}
}

void Messagebox::Delete()
{
	delete [] Content;
	Content = 0;
}