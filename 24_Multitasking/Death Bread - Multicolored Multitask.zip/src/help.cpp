/* (c) by Jonas Kaiser - help.cpp */
/* Header */
#include "help.h"


Help::Help(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, Sound &TmpSound, sf::Image &ButtonImg, sf::Image &MsgBoxImg, sf::Font &KomikaAxis, float &TmpKeyUse) :
	GameWindow(TmpWindow),
	GameSystem(TmpSystem),
	GameTick(TmpTick),
	GameInput(TmpInput),
	GameSound(TmpSound),
	HelpMsg(GameWindow, GameSystem, MsgBoxImg, KomikaAxis, sf::IntRect(0, 0, 800, 450), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 75 * GameSystem.GetWindowFactor(), "You will get\nan explaination\nof the controls\nwhile playing\nthe game."),
	BackButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImg, KomikaAxis, sf::IntRect(800, 0, 1200, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 225 * GameSystem.GetWindowFactor(), "Back", 1),
	LastKeyUse(TmpKeyUse)
{
	
}
Help::~Help()
{
	
}


void Help::Recalculate()
{
	HelpMsg.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	BackButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	HelpMsg.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 75 * GameSystem.GetWindowFactor());
	BackButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 225 * GameSystem.GetWindowFactor());
	HelpMsg.Recalculate();
	BackButton.Recalculate();
}

void Help::Reset()
{
	MouseOrKey = 0;
	ActiveButton = 0;
	TmpActiveButton = 0;
}

void Help::Update()
{
	GameInput.Help(LastKeyUse, MouseOrKey, ActiveButton);
	if(GameInput.MouseMoved)
		ActiveButton = 0;
	
	BackButton.IsActive(ActiveButton);
	if(BackButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		GameSystem.SetState(System::MENU);
	}
	
	if(TmpActiveButton != ActiveButton && ActiveButton != 0 && GameSystem.GetSound())
		GameSound.MenuChange.Play();
	TmpActiveButton = ActiveButton;
}

void Help::Display()
{
	HelpMsg.Display();
	BackButton.Display();
}

void Help::Delete()
{
	HelpMsg.Delete();
}