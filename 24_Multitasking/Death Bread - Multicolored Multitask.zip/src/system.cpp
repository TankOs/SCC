/* (c) by Jonas Kaiser - system.cpp */
/* Header */
#include "system.h"


System::System(sf::RenderWindow &TmpWindow) :
	GameWindow(TmpWindow),
	State(MENU),
	Fullscreen(0),
	Sound(1),
	Music(1)
{
	
}
System::~System()
{
	
}


int System::GetState()
{
	return State;
}

void System::SetState(GameState Set)
{
	State = Set;
}

int System::GetWindowWidth()
{
	return GameWindow.GetWidth();
}

int System::GetWindowHeight()
{
	return GameWindow.GetHeight();
}

float System::GetWindowFactor()
{
	if(Fullscreen)
	{
		if(UsedWindow.GetWidth() / 1600.f < UsedWindow.GetHeight() / 1200.f)
			return (float)UsedWindow.GetWidth() / 1600.f;
		else
			return (float)UsedWindow.GetHeight() / 1200.f;
	}
	else
	{
		if(GetWindowWidth() / 1600.f < GetWindowHeight() / 1200.f)
			return (float)GetWindowWidth() / 1600.f;
		else
			return (float)GetWindowHeight() / 1200.f;
	}
}

bool System::GetFullscreen()
{
	return Fullscreen;
}

void System::SetFullscreen(bool New)
{
	if(Fullscreen != New)
	{
		Fullscreen = New;
		
		if(Fullscreen)
		{
			FullscreenMode = sf::VideoMode::GetMode(0);
			GameWindow.Create(FullscreenMode, "Multicolored Multitask", sf::Style::Fullscreen);
			
			if(FullscreenMode.Width / 1600 < FullscreenMode.Height / 1200)
			{
				UsedWindow.Right = FullscreenMode.Width;
				UsedWindow.Top = (FullscreenMode.Height - (1200 * FullscreenMode.Width / 1600)) / 2;
				UsedWindow.Bottom = FullscreenMode.Height - UsedWindow.Top;
			}
			else
			{
				UsedWindow.Left = (FullscreenMode.Width - (1600 * FullscreenMode.Height / 1200)) / 2;
				UsedWindow.Right = FullscreenMode.Width - UsedWindow.Left;
				UsedWindow.Bottom = FullscreenMode.Height;
			}
		}
		else
		{
			GameWindow.Create(sf::VideoMode(800, 600), "Multicolored Multitask", sf::Style::Close);
			
			UsedWindow.Left = 0;
			UsedWindow.Top = 0;
			UsedWindow.Right = GetWindowWidth();
			UsedWindow.Bottom = GetWindowHeight();
		}
	}
}

bool System::GetSound()
{
	return Sound;
}

void System::SetSound(bool New)
{
	Sound = New;
}

bool System::GetMusic()
{
	return Music;
}

void System::SetMusic(bool New)
{
	Music = New;
}