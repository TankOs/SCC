/* (c) by Jonas Kaiser - options.cpp */
/* Header */
#include "options.h"


Options::Options(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, Sound &TmpSound, sf::Image &ButtonImage, sf::Font &KomikaAxis, float &TmpKeyUse) :
	GameWindow(TmpWindow),
	GameSystem(TmpSystem),
	GameTick(TmpTick),
	GameInput(TmpInput),
	GameSound(TmpSound),
	FullscreenButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImage, KomikaAxis, sf::IntRect(0, 0, 800, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 300 * GameSystem.GetWindowFactor(), "Fullscreen: Off", 1),
	SoundButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImage, KomikaAxis, sf::IntRect(0, 0, 800, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 150 * GameSystem.GetWindowFactor(), "Sound: On", 2),
	MusicButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImage, KomikaAxis, sf::IntRect(0, 0, 800, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2, "Music: On", 3),
	ResetButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImage, KomikaAxis, sf::IntRect(0, 0, 800, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 150 * GameSystem.GetWindowFactor(), "Reset to defaults", 4),
	OkButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImage, KomikaAxis, sf::IntRect(800, 0, 1200, 150), GameSystem.GetWindowWidth() / 2 - 200 * GameSystem.GetWindowFactor(), GameSystem.GetWindowHeight() / 2 + 300 * GameSystem.GetWindowFactor(), "Ok", 5),
	AbortButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImage, KomikaAxis, sf::IntRect(800, 0, 1200, 150), GameSystem.GetWindowWidth() / 2 + 200 * GameSystem.GetWindowFactor(), GameSystem.GetWindowHeight() / 2 + 300 * GameSystem.GetWindowFactor(), "Abort", 6),
	LastKeyUse(TmpKeyUse),
	FullscreenOn(GameSystem.GetFullscreen()),
	TmpFullscreenOn(FullscreenOn),
	SoundOn(GameSystem.GetSound()),
	TmpSoundOn(SoundOn),
	MusicOn(GameSystem.GetMusic()),
	TmpMusicOn(MusicOn)
{
	
}
Options::~Options()
{
	
}


void Options::Recalculate()
{
	FullscreenButton.Recalculate();
	SoundButton.Recalculate();
	MusicButton.Recalculate();
	ResetButton.Recalculate();
	OkButton.Recalculate();
	AbortButton.Recalculate();	
	FullscreenButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	SoundButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	MusicButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	ResetButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	OkButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	AbortButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	FullscreenButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 300 * GameSystem.GetWindowFactor());
	SoundButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 150 * GameSystem.GetWindowFactor());
	MusicButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2);
	ResetButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 150 * GameSystem.GetWindowFactor());
	OkButton.SetPosition(GameSystem.GetWindowWidth() / 2 - 200 * GameSystem.GetWindowFactor(), GameSystem.GetWindowHeight() / 2 + 300 * GameSystem.GetWindowFactor());
	AbortButton.SetPosition(GameSystem.GetWindowWidth() / 2 + 200 * GameSystem.GetWindowFactor(), GameSystem.GetWindowHeight() / 2 + 300 * GameSystem.GetWindowFactor());
}

void Options::Reset()
{
	MouseOrKey = 0;
	ActiveButton = 0;
	TmpActiveButton = 0;
	
	FullscreenOn = GameSystem.GetFullscreen();
	TmpFullscreenOn = FullscreenOn;
	SoundOn = GameSystem.GetSound();
	TmpSoundOn = SoundOn;
	MusicOn = GameSystem.GetMusic();
	TmpMusicOn = MusicOn;
}

void Options::Update()
{
	GameInput.Options(LastKeyUse, MouseOrKey, ActiveButton);
	if(GameInput.MouseMoved && MouseOrKey == 0)
		ActiveButton = 0;
	
	FullscreenButton.IsActive(MouseOrKey, ActiveButton);
	if(FullscreenButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		TmpFullscreenOn = !TmpFullscreenOn;
	}
	SoundButton.IsActive(MouseOrKey, ActiveButton);
	if(SoundButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		TmpSoundOn = !TmpSoundOn;
	}
	MusicButton.IsActive(MouseOrKey, ActiveButton);
	if(MusicButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		TmpMusicOn = !TmpMusicOn;
	}
	ResetButton.IsActive(MouseOrKey, ActiveButton);
	if(ResetButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		Defaults();
	}
	OkButton.IsActive(MouseOrKey, ActiveButton);
	if(OkButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		Set();
		GameSystem.SetState(System::MENU);
	}
	AbortButton.IsActive(MouseOrKey, ActiveButton);
	if(AbortButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		GameSystem.SetState(System::MENU);
	}
	
	if(FullscreenButton.GetText() == "Fullscreen: Off" && TmpFullscreenOn == 1)
		FullscreenButton.SetText("Fullscreen: On");
	if(FullscreenButton.GetText() == "Fullscreen: On" && TmpFullscreenOn == 0)
		FullscreenButton.SetText("Fullscreen: Off");

	if(SoundButton.GetText() == "Sound: Off" && TmpSoundOn == 1)
		SoundButton.SetText("Sound: On");
	if(SoundButton.GetText() == "Sound: On" && TmpSoundOn == 0)
		SoundButton.SetText("Sound: Off");

	if(MusicButton.GetText() == "Music: Off" && TmpMusicOn == 1)
		MusicButton.SetText("Music: On");
	if(MusicButton.GetText() == "Music: On" && TmpMusicOn == 0)
		MusicButton.SetText("Music: Off");
	
	if(TmpActiveButton != ActiveButton && ActiveButton != 0 && GameSystem.GetSound())
		GameSound.MenuChange.Play();
	TmpActiveButton = ActiveButton;
}

void Options::Display()
{
	FullscreenButton.Display();
	SoundButton.Display();
	MusicButton.Display();
	ResetButton.Display();
	OkButton.Display();
	AbortButton.Display();
}

void Options::Defaults()
{
	TmpFullscreenOn = 0;
	TmpSoundOn = 1;
	TmpMusicOn = 1;
}

void Options::Set()
{
	FullscreenOn = TmpFullscreenOn;
	SoundOn = TmpSoundOn;
	MusicOn = TmpMusicOn;
	
	GameSystem.SetFullscreen(FullscreenOn);
	GameSystem.SetSound(SoundOn);
	GameSystem.SetMusic(MusicOn);
}