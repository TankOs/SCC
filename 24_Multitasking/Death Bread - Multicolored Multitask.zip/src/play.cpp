/* (c) by Jonas Kaiser - play.cpp */
/* Header */
#include "play.h"


Play::Play(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, Sound &TmpSound, sf::Font &KomikaAxis, sf::Image &MsgBoxImg, std::string &TmpFinalScore) :
	GameWindow(TmpWindow),
	GameSystem(TmpSystem),
	GameTick(TmpTick),
	GameInput(TmpInput),
	GameSound(TmpSound),
	TmpWindowFactor(0),
	RedGame(GameSystem.UsedWindow.Left + 40, GameSystem.UsedWindow.Top + 40, GameSystem.UsedWindow.Left + 780, GameSystem.UsedWindow.Top + 580),
	GreenGame(GameSystem.UsedWindow.Left + 820, GameSystem.UsedWindow.Top + 40, GameSystem.UsedWindow.Left + 1560, GameSystem.UsedWindow.Top + 580),
	BlueGame(GameSystem.UsedWindow.Left + 40, GameSystem.UsedWindow.Top + 620, GameSystem.UsedWindow.Left + 780, GameSystem.UsedWindow.Top + 1160),
	YellowGame(GameSystem.UsedWindow.Left + 820, GameSystem.UsedWindow.Top + 620, GameSystem.UsedWindow.Left + 1560, GameSystem.UsedWindow.Top + 1160),
	LastRedWallSpawn(GameTick.Get()),
	LastGreenBallSpawn(GameTick.Get()),
	LastColoredBallSpawn(GameTick.Get()),
	LastSpaceUse(-1),
	Speed(1.f),
	GameOver(0),
	FinalScore(TmpFinalScore),
	RealScore(0.f),
	Score(RealScore),
	Explained(0),
	Explaining(false),
	RedExplaination(GameWindow, GameSystem, MsgBoxImg, KomikaAxis, sf::IntRect(0, 0, 800, 450), RedGame.Left + RedGame.GetWidth() / 2, RedGame.Top + RedGame.GetHeight() / 2, "Do not collide\nwith the walls!\nControls:\n[W]/[I]/[UP]\n[S]/[K]/[DOWN]\nPress [Space]"),
	GreenExplaination(GameWindow, GameSystem, MsgBoxImg, KomikaAxis, sf::IntRect(0, 0, 800, 450), GreenGame.Left + GreenGame.GetWidth() / 2, GreenGame.Top + GreenGame.GetHeight() / 2, "Collect all\ngreen balls!\nControls:\n[A]/[J]/[LEFT]\n[D]/[L]/[RIGHT]\nPress [Space]"),
	BlueExplaination(GameWindow, GameSystem, MsgBoxImg, KomikaAxis, sf::IntRect(0, 0, 800, 450), BlueGame.Left + BlueGame.GetWidth() / 2, BlueGame.Top + BlueGame.GetHeight() / 2, "Collect all balls\nconsidering\nthe colors!\nControls:\n[SPACE]\nPress [Space]"),
	YellowExplaination(GameWindow, GameSystem, MsgBoxImg, KomikaAxis, sf::IntRect(0, 0, 800, 450), YellowGame.Left + YellowGame.GetWidth() / 2, YellowGame.Top + YellowGame.GetHeight() / 2, "Collect all yellow\nballs but watch\nout for the spikes!\nControls:\n[1] [2] [3]\nPress [Space]")
{
	BackgroundImg.SetSmooth(false);
	if(!BackgroundImg.LoadFromFile("data/play_background.png"))
	{
		std::cout << "error: could not load file \"data/play_background.png\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	Background.SetImage(BackgroundImg);
	Background.SetCenter(Background.GetSubRect().GetWidth() / 2, Background.GetSubRect().GetHeight() / 2);
	Background.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	Background.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2);
	
	TileImg.SetSmooth(false);
	if(!TileImg.LoadFromFile("data/tiles.png"))
	{
		std::cout << "error: could not load file \"data/tiles.png\"" << std::endl;
		GameSystem.SetState(System::QUITTED);
	}
	RedChar.SetImage(TileImg);
	RedChar.SetSubRect(sf::IntRect(0, 0, 128, 128));
	RedChar.SetCenter(RedChar.GetSubRect().GetWidth() / 2, RedChar.GetSubRect().GetHeight() / 2);
	GreenChar.SetImage(TileImg);
	GreenChar.SetSubRect(sf::IntRect(128, 0, 256, 128));
	GreenChar.SetCenter(GreenChar.GetSubRect().GetWidth() / 2, GreenChar.GetSubRect().GetHeight() / 2);
	YellowChar.SetImage(TileImg);
	YellowChar.SetSubRect(sf::IntRect(256, 0, 384, 128));
	YellowChar.SetCenter(YellowChar.GetSubRect().GetWidth() / 2, YellowChar.GetSubRect().GetHeight() / 2);
	WallTop.SetImage(TileImg);
	WallTop.SetSubRect(sf::IntRect(384, 0, 448, 64));
	WallTop.SetCenter(WallTop.GetSubRect().GetWidth() / 2, WallTop.GetSubRect().GetHeight() / 2);
	WallBottom.SetImage(TileImg);
	WallBottom.SetSubRect(sf::IntRect(384, 64, 448, 128));
	WallBottom.SetCenter(WallBottom.GetSubRect().GetWidth() / 2, WallBottom.GetSubRect().GetHeight() / 2);
	WallMid.SetImage(TileImg);
	WallMid.SetSubRect(sf::IntRect(448, 0, 512, 64));
	WallMid.SetCenter(WallMid.GetSubRect().GetWidth() / 2, WallMid.GetSubRect().GetHeight() / 2);
	WallSmall.SetImage(TileImg);
	WallSmall.SetSubRect(sf::IntRect(448, 64, 512, 128));
	WallSmall.SetCenter(WallSmall.GetSubRect().GetWidth() / 2, WallSmall.GetSubRect().GetHeight() / 2);
	Spike.SetImage(TileImg);
	Spike.SetSubRect(sf::IntRect(512, 0, 640, 128));
	Spike.SetCenter(Spike.GetSubRect().GetWidth() / 2, Spike.GetSubRect().GetHeight() / 2);
	RedBlue.SetImage(TileImg);
	RedBlue.SetSubRect(sf::IntRect(0, 128, 320, 192));
	RedBlue.SetCenter(RedBlue.GetSubRect().GetWidth() / 2, RedBlue.GetSubRect().GetHeight() / 2);
	GreenYellow.SetImage(TileImg);
	GreenYellow.SetSubRect(sf::IntRect(0, 192, 320, 256));
	GreenYellow.SetCenter(RedBlue.GetSubRect().GetWidth() / 2, RedBlue.GetSubRect().GetHeight() / 2);
	RedBallSprite.SetImage(TileImg);
	RedBallSprite.SetSubRect(sf::IntRect(384, 128, 448, 192));
	RedBallSprite.SetCenter(RedBallSprite.GetSubRect().GetWidth() / 2, RedBallSprite.GetSubRect().GetHeight() / 2);
	GreenBallSprite.SetImage(TileImg);
	GreenBallSprite.SetSubRect(sf::IntRect(448, 128, 512, 192));
	GreenBallSprite.SetCenter(GreenBallSprite.GetSubRect().GetWidth() / 2, GreenBallSprite.GetSubRect().GetHeight() / 2);
	BlueBallSprite.SetImage(TileImg);
	BlueBallSprite.SetSubRect(sf::IntRect(384, 192, 448, 256));
	BlueBallSprite.SetCenter(BlueBallSprite.GetSubRect().GetWidth() / 2, BlueBallSprite.GetSubRect().GetHeight() / 2);
	YellowBallSprite.SetImage(TileImg);
	YellowBallSprite.SetSubRect(sf::IntRect(448, 192, 512, 256));
	YellowBallSprite.SetCenter(YellowBallSprite.GetSubRect().GetWidth() / 2, YellowBallSprite.GetSubRect().GetHeight() / 2);
	
	ScoreSStream << Score;
	ScoreString.SetText(ScoreSStream.str());
	ScoreString.SetFont(KomikaAxis);
	ScoreString.SetColor(sf::Color(255, 255, 255, 255));
	ScoreString.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	ScoreString.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2);
}
Play::~Play()
{
	
}


void Play::Recalculate()
{
	RedGame = sf::FloatRect(GameSystem.UsedWindow.Left + 40 * GameSystem.GetWindowFactor(), GameSystem.UsedWindow.Top + 40 * GameSystem.GetWindowFactor(), GameSystem.UsedWindow.Left + 780 * GameSystem.GetWindowFactor(), GameSystem.UsedWindow.Top + 580 * GameSystem.GetWindowFactor());
	GreenGame = sf::FloatRect(GameSystem.UsedWindow.Left + 820 * GameSystem.GetWindowFactor(), GameSystem.UsedWindow.Top + 40 * GameSystem.GetWindowFactor(), GameSystem.UsedWindow.Left + 1560 * GameSystem.GetWindowFactor(), GameSystem.UsedWindow.Top + 580 * GameSystem.GetWindowFactor());
	BlueGame = sf::FloatRect(GameSystem.UsedWindow.Left + 40 * GameSystem.GetWindowFactor(), GameSystem.UsedWindow.Top + 620 * GameSystem.GetWindowFactor(), GameSystem.UsedWindow.Left + 780 * GameSystem.GetWindowFactor(), GameSystem.UsedWindow.Top + 1160 * GameSystem.GetWindowFactor());
	YellowGame = sf::FloatRect(GameSystem.UsedWindow.Left + 820 * GameSystem.GetWindowFactor(), GameSystem.UsedWindow.Top + 620 * GameSystem.GetWindowFactor(), GameSystem.UsedWindow.Left + 1560 * GameSystem.GetWindowFactor(), GameSystem.UsedWindow.Top + 1160 * GameSystem.GetWindowFactor());
	
	Background.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	Background.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2);
	
	RedChar.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	GreenChar.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	YellowChar.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	WallTop.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	WallBottom.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	WallMid.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	WallSmall.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	Spike.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	RedBlue.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	GreenYellow.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	RedBallSprite.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	GreenBallSprite.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	BlueBallSprite.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	YellowBallSprite.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	
	ScoreString.SetSize(72);
	ScoreString.SetCenter(ScoreString.GetRect().GetWidth() / 2 / ScoreString.GetScale().x, ScoreString.GetRect().GetHeight() / 2 / ScoreString.GetScale().y);
	ScoreString.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	ScoreString.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2);
	
	RedExplaination.Recalculate();
	GreenExplaination.Recalculate();
	BlueExplaination.Recalculate();
	YellowExplaination.Recalculate();
	RedExplaination.SetScale(GameSystem.GetWindowFactor() * 0.75, GameSystem.GetWindowFactor() * 0.75);
	GreenExplaination.SetScale(GameSystem.GetWindowFactor() * 0.75, GameSystem.GetWindowFactor() * 0.75);
	BlueExplaination.SetScale(GameSystem.GetWindowFactor() * 0.75, GameSystem.GetWindowFactor() * 0.75);
	YellowExplaination.SetScale(GameSystem.GetWindowFactor() * 0.75, GameSystem.GetWindowFactor() * 0.75);
	RedExplaination.SetPosition(RedGame.Left + RedGame.GetWidth() / 2, RedGame.Top + RedGame.GetHeight() / 2);
	GreenExplaination.SetPosition(GreenGame.Left + GreenGame.GetWidth() / 2, GreenGame.Top + GreenGame.GetHeight() / 2);
	BlueExplaination.SetPosition(BlueGame.Left + BlueGame.GetWidth() / 2, BlueGame.Top + BlueGame.GetHeight() / 2);
	YellowExplaination.SetPosition(YellowGame.Left + YellowGame.GetWidth() / 2, YellowGame.Top + YellowGame.GetHeight() / 2);
}

void Play::Reset()
{
	RedChar.SetPosition(RedGame.Left + 200 * GameSystem.GetWindowFactor(), RedGame.Top + RedGame.GetHeight() / 2);
	RedChar.SetRotation(0);
	RedChar.SetColor(sf::Color(255, 255, 255, 255));
	GreenChar.SetPosition(GreenGame.Left + GreenGame.GetWidth() / 2, GreenGame.Bottom - 100 * GameSystem.GetWindowFactor());
	GreenChar.SetColor(sf::Color(255, 255, 255, 255));
	YellowChar.SetPosition(YellowGame.Left + YellowGame.GetWidth() / 2, YellowGame.Bottom - 200 * GameSystem.GetWindowFactor());
	YellowChar.SetColor(sf::Color(255, 255, 255, 255));
	RedBlue.SetPosition(BlueGame.Left + BlueGame.GetWidth() / 2 - RedBlue.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor(), BlueGame.Bottom - 35 * GameSystem.GetWindowFactor());
	RedBlue.SetColor(sf::Color(255, 255, 255, 255));
	GreenYellow.SetPosition(BlueGame.Left + BlueGame.GetWidth() / 2 + GreenYellow.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor(), BlueGame.Bottom - 35 * GameSystem.GetWindowFactor());
	GreenYellow.SetColor(sf::Color(255, 255, 255, 255));
	
	BlueFlipped = false;
	RedBlue.FlipY(BlueFlipped);
	GreenYellow.FlipY(BlueFlipped);
	
	Wall = FirstWall;
	while(Wall != 0)
	{
		TmpWall = Wall->Next;
		delete [] Wall->Sprite;
		delete Wall;
		Wall = TmpWall;
	}
	FirstWall = 0;
	Wall = 0;
	TmpWall = 0;
	LastRedWallSpawn = GameTick.Get();
	
	GreenBall = FirstGreenBall;
	while(GreenBall != 0)
	{
		TmpGreenBall = GreenBall->Next;
		delete GreenBall->Sprite;
		delete GreenBall;
		GreenBall = TmpGreenBall;
	}
	FirstGreenBall = 0;
	GreenBall = 0;	
	TmpGreenBall = 0;	
	LastGreenBallSpawn = GameTick.Get();
	
	ColoredBall = FirstColoredBall;
	while(ColoredBall != 0)
	{
		TmpColoredBall = ColoredBall->Next;
		delete ColoredBall->Sprite;
		delete ColoredBall;
		ColoredBall = TmpColoredBall;
	}
	FirstColoredBall = 0;
	ColoredBall = 0;	
	TmpColoredBall = 0;	
	LastColoredBallSpawn = GameTick.Get();
	LastSpaceUse = -1;
	
	Yellow = FirstYellow;
	while(Yellow != 0)
	{
		TmpYellow = Yellow->Next;
		delete Yellow->Sprite;
		delete Yellow;
		Yellow = TmpYellow;
	}
	FirstYellow = 0;
	Yellow = 0;	
	TmpYellow = 0;	
	LastYellowSpawn = GameTick.Get();
		
	Speed = 1;
	
	GameOver = 0;
	RealScore = 0;
	Score = RealScore;
	
	Explained = 0;
	Explaining = false;
}

void Play::Update()
{
	TmpWindowFactor = GameSystem.GetWindowFactor();
	
	GameInput.Play(Explaining, GameOver);
	
	if(!Explaining && GameOver == 0 && (Explained == 0 || (Explained == 1 && RealScore >= 100) || (Explained == 2 && RealScore >= 200) || (Explained == 3 && RealScore >= 300)))
		Explaining = true;
	if(Explaining && GameInput.IsDown(sf::Key::Space))
	{
		Explaining = false;
		Explained++;
		
		LastSpaceUse = GameTick.Get();
	}
	if(Explaining)
	{
		LastRedWallSpawn += GameWindow.GetFrameTime();
		LastGreenBallSpawn += GameWindow.GetFrameTime();
		LastColoredBallSpawn += GameWindow.GetFrameTime();
		LastYellowSpawn += GameWindow.GetFrameTime();
	}
	
	if(GameOver == 0 && !Explaining)
	{		
		/* Red */
		if(GameInput.IsDown(sf::Key::W) || GameInput.IsDown(sf::Key::I) || GameInput.IsDown(sf::Key::Up))
		{
			RedChar.Move(0, -300 * Speed * GameWindow.GetFrameTime() * GameSystem.GetWindowFactor());
			RedChar.Rotate(100 * Speed * GameWindow.GetFrameTime());
		}
		else if(GameInput.IsDown(sf::Key::S) || GameInput.IsDown(sf::Key::K) || GameInput.IsDown(sf::Key::Down))
		{
			RedChar.Move(0, 300 * Speed * GameWindow.GetFrameTime() * GameSystem.GetWindowFactor());
			RedChar.Rotate(-100 * Speed * GameWindow.GetFrameTime());
		}
		else
		{
			if(RedChar.GetPosition().y < -5 * GameSystem.GetWindowFactor() + RedGame.Top + RedGame.GetHeight() / 2)
			{
				RedChar.Move(0, 150 * Speed * GameWindow.GetFrameTime() * GameSystem.GetWindowFactor());
				RedChar.Rotate(-25 * Speed * GameWindow.GetFrameTime());
			}
			else if(RedChar.GetPosition().y > 5 * GameSystem.GetWindowFactor() + RedGame.Top + RedGame.GetHeight() / 2)
			{
				RedChar.Move(0, -150 * Speed * GameWindow.GetFrameTime() * GameSystem.GetWindowFactor());
				RedChar.Rotate(25 * Speed * GameWindow.GetFrameTime());
			}
			else
			{
				if(RedChar.GetRotation() > 0 && RedChar.GetRotation() < 180)
					RedChar.Rotate(-(RedChar.GetRotation()) * 4 * Speed * GameWindow.GetFrameTime());
				else if(RedChar.GetRotation() > 180)
					RedChar.Rotate((RedChar.GetRotation() * (-1) + 360) * 4 * Speed * GameWindow.GetFrameTime());
			}
		}
		if(RedChar.GetPosition().y < RedGame.Top + (RedChar.GetSubRect().GetHeight() - 55) / 2 * GameSystem.GetWindowFactor())
			RedChar.SetY(RedGame.Top + (RedChar.GetSubRect().GetHeight() - 55) / 2 * GameSystem.GetWindowFactor());
		else if(RedChar.GetPosition().y > RedGame.Bottom - (RedChar.GetSubRect().GetHeight() - 55) / 2 * GameSystem.GetWindowFactor())
			RedChar.SetY(RedGame.Bottom - (RedChar.GetSubRect().GetHeight() - 55) / 2 * GameSystem.GetWindowFactor());
		if(RedChar.GetRotation() > 25 && RedChar.GetRotation() <= 180)
			RedChar.SetRotation(25);
		else if(RedChar.GetRotation() < 335 && RedChar.GetRotation() > 180)
			RedChar.SetRotation(-25);
		
		if(GameTick.Get() - LastRedWallSpawn >= 5 / Speed)
		{
			if(FirstWall == 0)
			{
				FirstWall = new RedWall;
				FirstWall->Size = sf::Randomizer::Random(1, 5);
				FirstWall->InitPosition.x = RedGame.Right - WallSmall.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor();
				FirstWall->InitPosition.y = sf::Randomizer::Random(RedGame.Top + (float)FirstWall->Size / 2.f * WallSmall.GetSubRect().GetHeight() * GameSystem.GetWindowFactor(), RedGame.Bottom - (float)FirstWall->Size / 2.f * WallSmall.GetSubRect().GetHeight() * GameSystem.GetWindowFactor());
				FirstWall->Sprite = new sf::Sprite[FirstWall->Size];
				for(int i = 0; i < FirstWall->Size; i++)
				{
					if(FirstWall->Size == 1)
						FirstWall->Sprite[i] = WallSmall;
					else if(i == 0)
						FirstWall->Sprite[i] = WallTop;
					else if(FirstWall->Size - i == 1)
						FirstWall->Sprite[i] = WallBottom;
					else
						FirstWall->Sprite[i] = WallMid;
					FirstWall->Sprite[i].SetColor(sf::Color(255, 255, 255, 0));
					FirstWall->Sprite[i].SetPosition(FirstWall->InitPosition.x, FirstWall->InitPosition.y + WallSmall.GetSubRect().GetHeight() * (i - ((float)FirstWall->Size - 1) / 2.f) * GameSystem.GetWindowFactor());
				}
				if(FirstWall->Next != 0)
					FirstWall->Next = 0;
			}
			else
			{
				Wall = FirstWall;
				while(Wall->Next != 0)
					Wall = Wall->Next;
				Wall->Next = new RedWall;
				Wall->Next->Size = sf::Randomizer::Random(1, 5);
				Wall->Next->InitPosition.x = RedGame.Right - WallSmall.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor();
				Wall->Next->InitPosition.y = sf::Randomizer::Random(RedGame.Top + (float)Wall->Next->Size / 2.f * WallSmall.GetSubRect().GetHeight() * GameSystem.GetWindowFactor(), RedGame.Bottom - (float)Wall->Next->Size / 2.f * WallSmall.GetSubRect().GetHeight() * GameSystem.GetWindowFactor());
				Wall->Next->Sprite = new sf::Sprite[Wall->Next->Size];
				for(int i = 0; i < Wall->Next->Size; i++)
				{
					if(Wall->Next->Size == 1)
						Wall->Next->Sprite[i] = WallSmall;
					else if(i == 0)
						Wall->Next->Sprite[i] = WallTop;
					else if(Wall->Next->Size - i == 1)
						Wall->Next->Sprite[i] = WallBottom;
					else
						Wall->Next->Sprite[i] = WallMid;
					Wall->Next->Sprite[i].SetColor(sf::Color(255, 255, 255, 0));
					Wall->Next->Sprite[i].SetPosition(Wall->Next->InitPosition.x, Wall->Next->InitPosition.y + WallSmall.GetSubRect().GetHeight() * (i - ((float)Wall->Next->Size - 1) / 2.f) * GameSystem.GetWindowFactor());
				}
				if(Wall->Next->Next != 0)
					Wall->Next->Next = 0;
			}
			
			LastRedWallSpawn = GameTick.Get();
		}
		Wall = FirstWall;
		while(Wall != 0)
		{
			for(int i = 0; i < Wall->Size; i++)
				Wall->Sprite[i].Move(-150 * Speed * GameWindow.GetFrameTime() * GameSystem.GetWindowFactor(), 0);
			Wall = Wall->Next;
		}
		
		
		Wall = FirstWall;
		while(Wall != 0 && Wall->Sprite[0].GetPosition().x > RedGame.Right - (WallSmall.GetSubRect().GetWidth() / 2 + 25) * GameSystem.GetWindowFactor())
		{
			TmpVisibility = FirstWall->Sprite[0].GetColor().a + 1000 * GameWindow.GetFrameTime() * Speed;
			if(TmpVisibility < 0)
				TmpVisibility = 0;
			if(TmpVisibility > 255)
				TmpVisibility = 255;
			for(int i = 0; i < Wall->Size; i++)
				Wall->Sprite[i].SetColor(sf::Color(255, 255, 255, TmpVisibility));
			Wall = Wall->Next;
		}
		Wall = FirstWall;
		while(Wall != 0 && Wall->Sprite[0].GetPosition().x < RedGame.Right - (WallSmall.GetSubRect().GetWidth() / 2 + 25) * GameSystem.GetWindowFactor() && Wall->Sprite[0].GetPosition().x > RedGame.Left + (WallSmall.GetSubRect().GetWidth() / 2 + 25) * GameSystem.GetWindowFactor())
		{
			for(int i = 0; i < Wall->Size; i++)
				Wall->Sprite[i].SetColor(sf::Color(255, 255, 255, 255));
			Wall = Wall->Next;
		}
		if(FirstWall != 0 && FirstWall->Sprite[0].GetPosition().x < RedGame.Left + (WallSmall.GetSubRect().GetWidth() / 2 + 25) * GameSystem.GetWindowFactor())
		{
			TmpVisibility = FirstWall->Sprite[0].GetColor().a - 1000 * GameWindow.GetFrameTime() * Speed;
			if(TmpVisibility < 0)
				TmpVisibility = 0;
			if(TmpVisibility > 255)
				TmpVisibility = 255;
			for(int i = 0; i < FirstWall->Size; i++)
				FirstWall->Sprite[i].SetColor(sf::Color(255, 255, 255, TmpVisibility));
		}
		
		if(FirstWall != 0 && (FirstWall->Sprite[0].GetPosition().x < RedGame.Left + WallSmall.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() || FirstWall->Sprite[0].GetColor().a <= 0))
		{
			TmpWall = FirstWall->Next;
			delete [] FirstWall->Sprite;
			delete FirstWall;
			FirstWall = TmpWall;
		}
		
		Wall = FirstWall;
		while(Wall != 0)
		{
			if(RedChar.GetPosition().x - 40 * GameSystem.GetWindowFactor() < Wall->Sprite[0].GetPosition().x + WallSmall.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() && RedChar.GetPosition().x + 40 * GameSystem.GetWindowFactor() > Wall->Sprite[0].GetPosition().x - WallSmall.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() && RedChar.GetPosition().y - 32 * GameSystem.GetWindowFactor() < Wall->InitPosition.y + WallSmall.GetSubRect().GetHeight() * (float)(Wall->Size / 2.f) * GameSystem.GetWindowFactor() && RedChar.GetPosition().y + 28 * GameSystem.GetWindowFactor() > Wall->InitPosition.y - WallSmall.GetSubRect().GetHeight() * (float)(Wall->Size / 2.f) * GameSystem.GetWindowFactor())
			{
				if(GameSystem.GetSound())
					GameSound.GameWall.Play();
				GameOver = 1;
			}
			Wall = Wall->Next;
		}		
		
		
		/* Green */
		if(RealScore >= 100)
		{
			if(GameInput.IsDown(sf::Key::A) || GameInput.IsDown(sf::Key::J) || GameInput.IsDown(sf::Key::Left))
				GreenChar.Move(-300 * Speed * GameWindow.GetFrameTime() * GameSystem.GetWindowFactor(), 0);
			else if(GameInput.IsDown(sf::Key::D) || GameInput.IsDown(sf::Key::L) || GameInput.IsDown(sf::Key::Right))
				GreenChar.Move(300 * Speed * GameWindow.GetFrameTime() * GameSystem.GetWindowFactor(), 0);
			
			if(GreenChar.GetPosition().x < GreenGame.Left + GreenChar.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor())
				GreenChar.SetX(GreenGame.Left + GreenChar.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor());
			else if(GreenChar.GetPosition().x > GreenGame.Right - GreenChar.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor())
				GreenChar.SetX(GreenGame.Right - GreenChar.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor());
			
			if(GameTick.Get() - LastGreenBallSpawn >= 4 / Speed)
			{
				if(FirstGreenBall == 0)
				{
					FirstGreenBall = new GreenBallStruct;
					FirstGreenBall->Sprite = new sf::Sprite;
					*FirstGreenBall->Sprite = GreenBallSprite;
					FirstGreenBall->Sprite[0].SetColor(sf::Color(255, 255, 255, 0));
					FirstGreenBall->Sprite[0].SetPosition(sf::Randomizer::Random(GreenGame.Left + GreenBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor(), GreenGame.Right - GreenBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor()), GreenGame.Top + GreenBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
					if(FirstGreenBall->Next != 0)
						FirstGreenBall->Next = 0;
				}
				else
				{
					GreenBall = FirstGreenBall;
					while(GreenBall->Next != 0)
						GreenBall = GreenBall->Next;
					GreenBall->Next = new GreenBallStruct;
					GreenBall->Next->Sprite = new sf::Sprite;
					*GreenBall->Next->Sprite = GreenBallSprite;
					GreenBall->Next->Sprite[0].SetColor(sf::Color(255, 255, 255, 0));
					GreenBall->Next->Sprite[0].SetPosition(sf::Randomizer::Random(GreenGame.Left + GreenBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor(), GreenGame.Right - GreenBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor()), GreenGame.Top + GreenBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
					if(GreenBall->Next->Next != 0)
						GreenBall->Next->Next = 0;
				}
				
				LastGreenBallSpawn = GameTick.Get();
			}
			GreenBall = FirstGreenBall;
			while(GreenBall != 0)
			{
				GreenBall->Sprite[0].Move(0, 100 * Speed * GameWindow.GetFrameTime() * GameSystem.GetWindowFactor());
				GreenBall = GreenBall->Next;
			}
			
			
			GreenBall = FirstGreenBall;
			while(GreenBall != 0 && GreenBall->Sprite[0].GetPosition().y < GreenGame.Top + (GreenBallSprite.GetSubRect().GetHeight() / 2 + 25) * GameSystem.GetWindowFactor())
			{
				TmpVisibility = GreenBall->Sprite[0].GetColor().a + 1000 * GameWindow.GetFrameTime() * Speed;
				if(TmpVisibility < 0)
					TmpVisibility = 0;
				if(TmpVisibility > 255)
					TmpVisibility = 255;
				GreenBall->Sprite[0].SetColor(sf::Color(255, 255, 255, TmpVisibility));
				GreenBall = GreenBall->Next;
			}
			GreenBall = FirstGreenBall;
			while(GreenBall != 0 && GreenBall->Sprite[0].GetPosition().y > GreenGame.Top + (GreenBallSprite.GetSubRect().GetHeight() / 2 + 25) * GameSystem.GetWindowFactor())
			{
				GreenBall->Sprite[0].SetColor(sf::Color(255, 255, 255, 255));
				GreenBall = GreenBall->Next;
			}
			if(FirstGreenBall != 0 && GreenChar.GetPosition().x - 64 * GameSystem.GetWindowFactor() < FirstGreenBall->Sprite[0].GetPosition().x + GreenBallSprite.GetSubRect().GetWidth() / 2 / 2 * GameSystem.GetWindowFactor() && GreenChar.GetPosition().x + 64 * GameSystem.GetWindowFactor() > FirstGreenBall->Sprite[0].GetPosition().x - GreenBallSprite.GetSubRect().GetWidth() / 2 / 2 * GameSystem.GetWindowFactor() && GreenChar.GetPosition().y - 32 * GameSystem.GetWindowFactor() < FirstGreenBall->Sprite[0].GetPosition().y + GreenBallSprite.GetSubRect().GetHeight() / 2 / 2 * GameSystem.GetWindowFactor() && GreenChar.GetPosition().y + 48 * GameSystem.GetWindowFactor() > FirstGreenBall->Sprite[0].GetPosition().y - GreenBallSprite.GetSubRect().GetHeight() / 2 / 2 * GameSystem.GetWindowFactor())
			{
				if(GameSystem.GetSound())
					GameSound.GameBall.Play();
				TmpGreenBall = FirstGreenBall->Next;
				delete FirstGreenBall->Sprite;
				delete FirstGreenBall;
				FirstGreenBall = TmpGreenBall;
			}
			if(FirstGreenBall != 0 && FirstGreenBall->Sprite[0].GetPosition().y + GreenBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor() > GreenGame.Bottom)
				GameOver = 2;
		}
		
		
		/* Blue */
		if(RealScore >= 200)
		{
			if(GameInput.IsDown(sf::Key::Space) && GameTick.Get() - LastSpaceUse >= 0.25)
			{
				if(GameSystem.GetSound())
					GameSound.GameSwitch.Play();
				BlueFlipped = !BlueFlipped;
				RedBlue.FlipY(BlueFlipped);
				GreenYellow.FlipY(BlueFlipped);
				
				LastSpaceUse = GameTick.Get();
			}
			if(!GameInput.IsDown(sf::Key::Space))
				LastSpaceUse = -1;
			
			if(GameTick.Get() - LastColoredBallSpawn >= 3.5 / Speed)
			{
				if(FirstColoredBall == 0)
				{
					FirstColoredBall = new ColoredBallStruct;
					FirstColoredBall->Color = sf::Randomizer::Random(1, 4);
					FirstColoredBall->Sprite = new sf::Sprite;
					switch(FirstColoredBall->Color)
					{
						case 1:
							*FirstColoredBall->Sprite = RedBallSprite;
							FirstColoredBall->Sprite[0].SetPosition(sf::Randomizer::Random(RedBlue.GetPosition().x - RedBlue.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() + RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor(), RedBlue.GetPosition().x + RedBlue.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() - RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor()), BlueGame.Top + RedBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
							break;
						case 2:
							*FirstColoredBall->Sprite = GreenBallSprite;
							FirstColoredBall->Sprite[0].SetPosition(sf::Randomizer::Random(GreenYellow.GetPosition().x - GreenYellow.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() + RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor(), GreenYellow.GetPosition().x + GreenYellow.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() - RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor()), BlueGame.Top + RedBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
							break;
						case 3:
							*FirstColoredBall->Sprite = BlueBallSprite;
							FirstColoredBall->Sprite[0].SetPosition(sf::Randomizer::Random(RedBlue.GetPosition().x - RedBlue.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() + RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor(), RedBlue.GetPosition().x + RedBlue.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() - RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor()), BlueGame.Top + RedBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
							break;
						case 4:
							*FirstColoredBall->Sprite = YellowBallSprite;
							FirstColoredBall->Sprite[0].SetPosition(sf::Randomizer::Random(GreenYellow.GetPosition().x - GreenYellow.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() + RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor(), GreenYellow.GetPosition().x + GreenYellow.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() - RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor()), BlueGame.Top + RedBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
							break;
						default:
							break;
					}
					FirstColoredBall->Sprite[0].SetColor(sf::Color(255, 255, 255, 0));
					if(FirstColoredBall->Next != 0)
						FirstColoredBall->Next = 0;
				}
				else
				{
					ColoredBall = FirstColoredBall;
					while(ColoredBall->Next != 0)
						ColoredBall = ColoredBall->Next;
					ColoredBall->Next = new ColoredBallStruct;
					ColoredBall->Next->Color = sf::Randomizer::Random(1, 4);
					ColoredBall->Next->Sprite = new sf::Sprite;
					switch(ColoredBall->Next->Color)
					{
						case 1:
							*ColoredBall->Next->Sprite = RedBallSprite;
							ColoredBall->Next->Sprite[0].SetPosition(sf::Randomizer::Random(RedBlue.GetPosition().x - RedBlue.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() + RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor(), RedBlue.GetPosition().x + RedBlue.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() - RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor()), BlueGame.Top + RedBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
							break;
						case 2:
							*ColoredBall->Next->Sprite = GreenBallSprite;
							ColoredBall->Next->Sprite[0].SetPosition(sf::Randomizer::Random(GreenYellow.GetPosition().x - GreenYellow.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() + RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor(), GreenYellow.GetPosition().x + GreenYellow.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() - RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor()), BlueGame.Top + RedBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
							break;
						case 3:
							*ColoredBall->Next->Sprite = BlueBallSprite;
							ColoredBall->Next->Sprite[0].SetPosition(sf::Randomizer::Random(RedBlue.GetPosition().x - RedBlue.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() + RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor(), RedBlue.GetPosition().x + RedBlue.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() - RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor()), BlueGame.Top + RedBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
							break;
						case 4:
							*ColoredBall->Next->Sprite = YellowBallSprite;
							ColoredBall->Next->Sprite[0].SetPosition(sf::Randomizer::Random(GreenYellow.GetPosition().x - GreenYellow.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() + RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor(), GreenYellow.GetPosition().x + GreenYellow.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor() - RedBallSprite.GetSubRect().GetWidth() / 2 * GameSystem.GetWindowFactor()), BlueGame.Top + RedBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
							break;
						default:
							break;
					}
					ColoredBall->Next->Sprite[0].SetColor(sf::Color(255, 255, 255, 0));
					if(ColoredBall->Next->Next != 0)
						ColoredBall->Next->Next = 0;
				}
				
				LastColoredBallSpawn = GameTick.Get();
			}
			ColoredBall = FirstColoredBall;
			while(ColoredBall != 0)
			{
				ColoredBall->Sprite[0].Move(0, 75 * Speed * GameWindow.GetFrameTime() * GameSystem.GetWindowFactor());
				ColoredBall = ColoredBall->Next;
			}
			
			
			ColoredBall = FirstColoredBall;
			while(ColoredBall != 0 && ColoredBall->Sprite[0].GetPosition().y < BlueGame.Top + (RedBallSprite.GetSubRect().GetHeight() / 2 + 25) * GameSystem.GetWindowFactor())
			{
				TmpVisibility = ColoredBall->Sprite[0].GetColor().a + 1000 * GameWindow.GetFrameTime() * Speed;
				if(TmpVisibility < 0)
					TmpVisibility = 0;
				if(TmpVisibility > 255)
					TmpVisibility = 255;
				ColoredBall->Sprite[0].SetColor(sf::Color(255, 255, 255, TmpVisibility));
				ColoredBall = ColoredBall->Next;
			}
			ColoredBall = FirstColoredBall;
			while(ColoredBall != 0 && ColoredBall->Sprite[0].GetPosition().y > BlueGame.Top + (RedBallSprite.GetSubRect().GetHeight() / 2 + 25) * GameSystem.GetWindowFactor())
			{
				ColoredBall->Sprite[0].SetColor(sf::Color(255, 255, 255, 255));
				ColoredBall = ColoredBall->Next;
			}
			if(FirstColoredBall != 0 && RedBlue.GetPosition().y - 8 * GameSystem.GetWindowFactor() < FirstColoredBall->Sprite[0].GetPosition().y + RedBallSprite.GetSubRect().GetHeight() / 2 / 2 * GameSystem.GetWindowFactor())
			{
				if((FirstColoredBall->Color == 1 && !BlueFlipped) || (FirstColoredBall->Color == 2 && !BlueFlipped) || (FirstColoredBall->Color == 3 && BlueFlipped) || (FirstColoredBall->Color == 4 && BlueFlipped))
				{
					if(GameSystem.GetSound())
						GameSound.GameBall.Play();
					TmpColoredBall = FirstColoredBall->Next;
					delete FirstColoredBall->Sprite;
					delete FirstColoredBall;
					FirstColoredBall = TmpColoredBall;
					
					BlueFlipped = !BlueFlipped;
					RedBlue.FlipY(BlueFlipped);
					GreenYellow.FlipY(BlueFlipped);
				}
				else
					GameOver = 3;
			}
		}
	
		
		/* Yellow */
		if(RealScore >= 300)
		{
			if(GameInput.IsDown(sf::Key::Num1) || GameInput.IsDown(sf::Key::Numpad1))
				YellowChar.SetX(YellowGame.Left + YellowGame.GetWidth() * 1 / 6);
			else if(GameInput.IsDown(sf::Key::Num2) || GameInput.IsDown(sf::Key::Numpad2))
				YellowChar.SetX(YellowGame.Left + YellowGame.GetWidth() * 3 / 6);
			else if(GameInput.IsDown(sf::Key::Num3) || GameInput.IsDown(sf::Key::Numpad3))
				YellowChar.SetX(YellowGame.Left + YellowGame.GetWidth() * 5 / 6);
			
			if(GameTick.Get() - LastYellowSpawn >= 7 / Speed)
			{
				if(FirstYellow == 0)
				{
					FirstYellow = new YellowStruct;
					FirstYellow->IsSpike = (sf::Randomizer::Random(1, 5) == 5);
					FirstYellow->Sprite = new sf::Sprite;
					if(FirstYellow->IsSpike)
					{
						*FirstYellow->Sprite = Spike;
						FirstYellow->Sprite[0].SetPosition(YellowGame.Left + sf::Randomizer::Random(1, 3) * YellowGame.GetWidth() / 3 - YellowGame.GetWidth() / 6, YellowGame.Top + Spike.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
					}
					else
					{
						*FirstYellow->Sprite = YellowBallSprite;
						FirstYellow->Sprite[0].SetPosition(YellowGame.Left + sf::Randomizer::Random(1, 3) * YellowGame.GetWidth() / 3 - YellowGame.GetWidth() / 6, YellowGame.Top + YellowBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
					}
					FirstYellow->Sprite[0].SetColor(sf::Color(255, 255, 255, 0));
					if(FirstYellow->Next != 0)
						FirstYellow->Next = 0;
				}
				else
				{
					Yellow = FirstYellow;
					while(Yellow->Next != 0)
						Yellow = Yellow->Next;
					Yellow->Next = new YellowStruct;
					Yellow->Next->IsSpike = (sf::Randomizer::Random(1, 5) > 3);
					Yellow->Next->Sprite = new sf::Sprite;
					if(Yellow->Next->IsSpike)
					{
						*Yellow->Next->Sprite = Spike;
						Yellow->Next->Sprite[0].SetPosition(YellowGame.Left + sf::Randomizer::Random(1, 3) * YellowGame.GetWidth() / 3 - YellowGame.GetWidth() / 6, YellowGame.Top + Spike.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
					}
					else
					{
						*Yellow->Next->Sprite = YellowBallSprite;
						Yellow->Next->Sprite[0].SetPosition(YellowGame.Left + sf::Randomizer::Random(1, 3) * YellowGame.GetWidth() / 3 - YellowGame.GetWidth() / 6, YellowGame.Top + YellowBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor());
					}
					FirstYellow->Sprite[0].SetColor(sf::Color(255, 255, 255, 0));
					if(Yellow->Next->Next != 0)
						Yellow->Next->Next = 0;
				}
				
				LastYellowSpawn = GameTick.Get();
			}
			Yellow = FirstYellow;
			while(Yellow != 0)
			{
				Yellow->Sprite[0].Move(0, 50 * Speed * GameWindow.GetFrameTime() * GameSystem.GetWindowFactor());
				Yellow = Yellow->Next;
			}
			
			
			Yellow = FirstYellow;
			while(Yellow != 0 && Yellow->Sprite[0].GetPosition().y < YellowGame.Top + (Yellow->Sprite[0].GetSubRect().GetHeight() / 2 + 25) * GameSystem.GetWindowFactor())
			{
				TmpVisibility = Yellow->Sprite[0].GetColor().a + 1000 * GameWindow.GetFrameTime() * Speed;
				if(TmpVisibility < 0)
					TmpVisibility = 0;
				if(TmpVisibility > 255)
					TmpVisibility = 255;
				Yellow->Sprite[0].SetColor(sf::Color(255, 255, 255, TmpVisibility));
				Yellow = Yellow->Next;
			}
			Yellow = FirstYellow;
			while(Yellow != 0 && Yellow->Sprite[0].GetPosition().y > YellowGame.Top + (Yellow->Sprite[0].GetSubRect().GetHeight() / 2 + 25) * GameSystem.GetWindowFactor() && Yellow->Sprite[0].GetPosition().y < YellowGame.Bottom - (Yellow->Sprite[0].GetSubRect().GetHeight() / 2 + 25) * GameSystem.GetWindowFactor())
			{
				Yellow->Sprite[0].SetColor(sf::Color(255, 255, 255, 255));
				Yellow = Yellow->Next;
			}
			Yellow = FirstYellow;
			while(Yellow != 0 && Yellow->IsSpike && Yellow->Sprite[0].GetPosition().y > YellowGame.Bottom - (Yellow->Sprite[0].GetSubRect().GetHeight() / 2 + 25) * GameSystem.GetWindowFactor())
			{
				TmpVisibility = Yellow->Sprite[0].GetColor().a - 1000 * GameWindow.GetFrameTime() * Speed;
				if(TmpVisibility < 0)
					TmpVisibility = 0;
				if(TmpVisibility > 255)
					TmpVisibility = 255;
				Yellow->Sprite[0].SetColor(sf::Color(255, 255, 255, TmpVisibility));
				Yellow = Yellow->Next;
			}
			if(FirstYellow != 0 && !FirstYellow->IsSpike && (int)YellowChar.GetPosition().x == (int)FirstYellow->Sprite[0].GetPosition().x && YellowChar.GetPosition().y - 32 * GameSystem.GetWindowFactor() < FirstYellow->Sprite[0].GetPosition().y + YellowBallSprite.GetSubRect().GetHeight() / 2 / 2 * GameSystem.GetWindowFactor() && YellowChar.GetPosition().y + 48 * GameSystem.GetWindowFactor() > FirstYellow->Sprite[0].GetPosition().y - YellowBallSprite.GetSubRect().GetHeight() / 2 / 2 * GameSystem.GetWindowFactor())
			{
				if(GameSystem.GetSound())
					GameSound.GameBall.Play();
				TmpYellow = FirstYellow->Next;
				delete FirstYellow->Sprite;
				delete FirstYellow;
				FirstYellow = TmpYellow;
			}
			if(FirstYellow != 0 && FirstYellow->IsSpike && (int)YellowChar.GetPosition().x == (int)FirstYellow->Sprite[0].GetPosition().x && YellowChar.GetPosition().y - 48 * GameSystem.GetWindowFactor() < FirstYellow->Sprite[0].GetPosition().y + 48 * GameSystem.GetWindowFactor() && YellowChar.GetPosition().y + 32 * GameSystem.GetWindowFactor() > FirstYellow->Sprite[0].GetPosition().y - 48 * GameSystem.GetWindowFactor())
			{
				if(GameSystem.GetSound())
					GameSound.GameSpike.Play();
				GameOver = 4;
			}
			if(FirstYellow != 0 && FirstYellow->IsSpike && FirstYellow->Sprite[0].GetPosition().y + Spike.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor() > YellowGame.Bottom)
			{
				TmpYellow = FirstYellow->Next;
				delete FirstYellow->Sprite;
				delete FirstYellow;
				FirstYellow = TmpYellow;
			}
			if(FirstYellow != 0 && !FirstYellow->IsSpike && FirstYellow->Sprite[0].GetPosition().y + YellowBallSprite.GetSubRect().GetHeight() / 2 * GameSystem.GetWindowFactor() > YellowGame.Bottom)
				GameOver = 4;
		}
		
		if(Speed < 2.499)
			Speed += GameWindow.GetFrameTime() / 250;
		else
			Speed = 2.5;
		
		RealScore += Speed * GameWindow.GetFrameTime();
	}
	
	Score = RealScore;
	ScoreSStream.str("");
	ScoreSStream << Score;
	ScoreString.SetText(ScoreSStream.str());	
	ScoreString.SetCenter(ScoreString.GetRect().GetWidth() / 2 / ScoreString.GetScale().x, ScoreString.GetRect().GetHeight() / 2 / ScoreString.GetScale().y);
	
	if(GameOver == 1)
	{
		RedChar.SetColor(sf::Color(0, 0, 0, 255));
	}
	if(GameOver == 2)
	{
		GreenChar.SetColor(sf::Color(0, 0, 0, 255));
	}
	if(GameOver == 3)
	{
		RedBlue.SetColor(sf::Color(0, 0, 0, 255));
		GreenYellow.SetColor(sf::Color(0, 0, 0, 255));
	}
	if(GameOver == 4)
	{
		YellowChar.SetColor(sf::Color(0, 0, 0, 255));
	}
	if(GameOver != 0)
	{
		FinalScore = ScoreSStream.str();
		GameSystem.SetState(System::GAMEOVER);
	}	
}

void Play::Display()
{
	GameWindow.Draw(Background);
	
	Wall = FirstWall;
	while(Wall != 0)
	{
		for(int i = 0; i < Wall->Size; i++)
			GameWindow.Draw(Wall->Sprite[i]);
		Wall = Wall->Next;
	}
	GameWindow.Draw(RedChar);
	
	if(RealScore >= 100)
	{
		GreenBall = FirstGreenBall;
		while(GreenBall != 0)
		{
			GameWindow.Draw(*GreenBall->Sprite);
			GreenBall = GreenBall->Next;
		}
		GameWindow.Draw(GreenChar);
	}
	
	if(RealScore >= 200)
	{
		ColoredBall = FirstColoredBall;
		while(ColoredBall != 0)
		{
			GameWindow.Draw(*ColoredBall->Sprite);
			ColoredBall = ColoredBall->Next;
		}
		GameWindow.Draw(RedBlue);
		GameWindow.Draw(GreenYellow);
	}
	
	if(RealScore >= 300)
	{
		Yellow = FirstYellow;
		while(Yellow != 0)
		{
			GameWindow.Draw(*Yellow->Sprite);
			Yellow = Yellow->Next;
		}
		GameWindow.Draw(YellowChar);
	}
	
	GameWindow.Draw(ScoreString);
	
	if(Explaining)
	{
		switch(Explained)
		{
			case 0:
				RedExplaination.Display();
				break;
			case 1:
				GreenExplaination.Display();
				break;
			case 2:
				BlueExplaination.Display();
				break;
			case 3:
				YellowExplaination.Display();
				break;
			default:
				break;
		}
	}
}

void Play::Delete()
{
	RedExplaination.Delete();
	GreenExplaination.Delete();
	BlueExplaination.Delete();
	YellowExplaination.Delete();
}