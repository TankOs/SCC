/* (c) by Jonas Kaiser - system.h */
/* Headerguards */
#ifndef SYSTEM_H
#define SYSTEM_H

/* Headers */
#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>


class System
{
public:
	System(sf::RenderWindow &TmpWindow);
	~System();
	
	enum GameState
	{QUIT, MENU, OPTIONS, HELP, ABOUT, PLAY, GAMEOVER, QUITTED};
	int GetState();
	void SetState(GameState Set);
	
	sf::IntRect UsedWindow;
	
	int GetWindowWidth();
	int GetWindowHeight();
	float GetWindowFactor();
	
	bool GetFullscreen();
	void SetFullscreen(bool New);
	bool GetSound();
	void SetSound(bool New);
	bool GetMusic();
	void SetMusic(bool New);
		
private:
	sf::RenderWindow &GameWindow;
	sf::VideoMode FullscreenMode;
		
	GameState State;
	
	bool Fullscreen;
	bool Sound;
	bool Music;
};

#endif