/* (c) by Jonas Kaiser - help.h */
/* Headerguards */
#ifndef HELP_H
#define HELP_H

/* Headers */
#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "system.h"
#include "tick.h"
#include "input.h"
#include "sound.h"
#include "messagebox.h"
#include "button.h"


class Help
{
public:
	Help(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, Sound &TmpSound, sf::Image &ButtonImg, sf::Image &MsgBoxImg, sf::Font &KomikaAxis, float &TmpKeyUse);
	~Help();
	
	void Recalculate();
	
	void Reset();
	void Update();
	void Display();
	void Delete();
	
private:
	sf::RenderWindow &GameWindow;
	
	System &GameSystem;
	Tick &GameTick;
	Input &GameInput;
	Sound &GameSound;
	
	Messagebox HelpMsg;
	
	Button BackButton;
	
	float &LastKeyUse;
	bool MouseOrKey;
	int ActiveButton;	
	int TmpActiveButton;	
};

#endif