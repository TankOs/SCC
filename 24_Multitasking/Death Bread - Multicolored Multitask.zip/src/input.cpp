/* (c) by Jonas Kaiser - input.cpp */
/* Header */
#include "input.h"


Input::Input(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick) :
	GameWindow(TmpWindow),
	GameSystem(TmpSystem),
	GameTick(TmpTick),
	InputHandler(GameWindow.GetInput())
{
	
}
Input::~Input()
{
	
}


void Input::Quit(float &Last, bool &MouseOrKey, int &ActiveButton)
{
	MouseMoved = false;
	LeftMouseButton = false;
	
	while(GameWindow.GetEvent(EventHandler))
	{
		if((EventHandler.Type == sf::Event::Closed) || (EventHandler.Type == sf::Event::KeyPressed && EventHandler.Key.Code == sf::Key::Escape))
			GameSystem.SetState(System::QUITTED);
		
		MouseMoved = (EventHandler.Type == sf::Event::MouseMoved);
		LeftMouseButton = (EventHandler.Type == sf::Event::MouseButtonPressed && EventHandler.MouseButton.Button == sf::Mouse::Left);
	}
	
	if((InputHandler.IsKeyDown(sf::Key::A) || InputHandler.IsKeyDown(sf::Key::J) || InputHandler.IsKeyDown(sf::Key::Left)) && GameTick.Get() - Last >= 0.25)
	{
		Last = GameTick.Get();
		MouseOrKey = 1;
		ActiveButton--;
		if(ActiveButton < 1)
			ActiveButton = 2;
	}
	if((InputHandler.IsKeyDown(sf::Key::D) || InputHandler.IsKeyDown(sf::Key::L) || InputHandler.IsKeyDown(sf::Key::Right)) && GameTick.Get() - Last >= 0.25)
	{
		Last = GameTick.Get();
		MouseOrKey = 1;
		ActiveButton++;
		if(ActiveButton > 2)
			ActiveButton = 1;
	}
	if(!InputHandler.IsKeyDown(sf::Key::A) && !InputHandler.IsKeyDown(sf::Key::J) && !InputHandler.IsKeyDown(sf::Key::Left) && !InputHandler.IsKeyDown(sf::Key::D) && !InputHandler.IsKeyDown(sf::Key::L) && !InputHandler.IsKeyDown(sf::Key::Right) && !InputHandler.IsKeyDown(sf::Key::Return))
		Last = -1;	
}

void Input::Menu(float &Last, bool &MouseOrKey, int &ActiveButton)
{
	MouseMoved = false;
	LeftMouseButton = false;

	while(GameWindow.GetEvent(EventHandler))
	{
		if(EventHandler.Type == sf::Event::Closed)
			GameSystem.SetState(System::QUITTED);
		if(EventHandler.Type == sf::Event::KeyPressed && EventHandler.Key.Code == sf::Key::Escape)
			GameSystem.SetState(System::QUIT);
		
		MouseMoved = (EventHandler.Type == sf::Event::MouseMoved);
		LeftMouseButton = (EventHandler.Type == sf::Event::MouseButtonPressed && EventHandler.MouseButton.Button == sf::Mouse::Left);
	}
	
	if((InputHandler.IsKeyDown(sf::Key::W) || InputHandler.IsKeyDown(sf::Key::I) || InputHandler.IsKeyDown(sf::Key::Up)) && GameTick.Get() - Last >= 0.25)
	{
		Last = GameTick.Get();
		MouseOrKey = 1;
		ActiveButton--;
		if(ActiveButton < 1)
			ActiveButton = 5;
	}
	if((InputHandler.IsKeyDown(sf::Key::S) || InputHandler.IsKeyDown(sf::Key::K) || InputHandler.IsKeyDown(sf::Key::Down)) && GameTick.Get() - Last >= 0.25)
	{
		Last = GameTick.Get();
		MouseOrKey = 1;
		ActiveButton++;
		if(ActiveButton > 5)
			ActiveButton = 1;
	}
	if(!InputHandler.IsKeyDown(sf::Key::W) && !InputHandler.IsKeyDown(sf::Key::I) && !InputHandler.IsKeyDown(sf::Key::Up) && !InputHandler.IsKeyDown(sf::Key::S) && !InputHandler.IsKeyDown(sf::Key::K) && !InputHandler.IsKeyDown(sf::Key::Down) && !InputHandler.IsKeyDown(sf::Key::Return))
		Last = -1;
}

void Input::Options(float &Last, bool &MouseOrKey, int &ActiveButton)
{
	MouseMoved = false;
	LeftMouseButton = false;
	
	while(GameWindow.GetEvent(EventHandler))
	{
		if(EventHandler.Type == sf::Event::Closed)
			GameSystem.SetState(System::QUITTED);
		if(EventHandler.Type == sf::Event::KeyPressed && EventHandler.Key.Code == sf::Key::Escape)
			GameSystem.SetState(System::MENU);
		
		MouseMoved = (EventHandler.Type == sf::Event::MouseMoved);
		LeftMouseButton = (EventHandler.Type == sf::Event::MouseButtonPressed && EventHandler.MouseButton.Button == sf::Mouse::Left);
	}
	
	if((InputHandler.IsKeyDown(sf::Key::W) || InputHandler.IsKeyDown(sf::Key::I) || InputHandler.IsKeyDown(sf::Key::Up)) && GameTick.Get() - Last >= 0.25)
	{
		Last = GameTick.Get();
		MouseOrKey = 1;
		ActiveButton--;
		if(ActiveButton < 1)
			ActiveButton = 5;
	}
	if((InputHandler.IsKeyDown(sf::Key::S) || InputHandler.IsKeyDown(sf::Key::K) || InputHandler.IsKeyDown(sf::Key::Down)) && GameTick.Get() - Last >= 0.25)
	{
		Last = GameTick.Get();
		MouseOrKey = 1;
		ActiveButton++;
		if(ActiveButton > 5)
			ActiveButton = 1;
	}
	if((InputHandler.IsKeyDown(sf::Key::A) || InputHandler.IsKeyDown(sf::Key::J) || InputHandler.IsKeyDown(sf::Key::Left)) && ActiveButton >= 5 && GameTick.Get() - Last >= 0.25)
	{
		Last = GameTick.Get();
		MouseOrKey = 1;
		ActiveButton--;
		if(ActiveButton < 5)
			ActiveButton = 6;
	}
	if((InputHandler.IsKeyDown(sf::Key::D) || InputHandler.IsKeyDown(sf::Key::L) || InputHandler.IsKeyDown(sf::Key::Right)) && ActiveButton >= 5 && GameTick.Get() - Last >= 0.25)
	{
		Last = GameTick.Get();
		MouseOrKey = 1;
		ActiveButton++;
		if(ActiveButton > 6)
			ActiveButton = 5;
	}
	if(!InputHandler.IsKeyDown(sf::Key::W) && !InputHandler.IsKeyDown(sf::Key::I) && !InputHandler.IsKeyDown(sf::Key::Up) && !InputHandler.IsKeyDown(sf::Key::S) && !InputHandler.IsKeyDown(sf::Key::K) && !InputHandler.IsKeyDown(sf::Key::Down) && !InputHandler.IsKeyDown(sf::Key::A) && !InputHandler.IsKeyDown(sf::Key::J) && !InputHandler.IsKeyDown(sf::Key::Left) && !InputHandler.IsKeyDown(sf::Key::D) && !InputHandler.IsKeyDown(sf::Key::L) && !InputHandler.IsKeyDown(sf::Key::Right) && !InputHandler.IsKeyDown(sf::Key::Return))
		Last = -1;
}

void Input::Help(float &Last, bool &MouseOrKey, int &ActiveButton)
{
	MouseMoved = false;
	LeftMouseButton = false;
	
	while(GameWindow.GetEvent(EventHandler))
	{
		if(EventHandler.Type == sf::Event::Closed)
			GameSystem.SetState(System::QUITTED);
		if(EventHandler.Type == sf::Event::KeyPressed && EventHandler.Key.Code == sf::Key::Escape)
			GameSystem.SetState(System::MENU);
		
		MouseMoved = (EventHandler.Type == sf::Event::MouseMoved);
		LeftMouseButton = (EventHandler.Type == sf::Event::MouseButtonPressed && EventHandler.MouseButton.Button == sf::Mouse::Left);
	}
	
	if((InputHandler.IsKeyDown(sf::Key::W) || InputHandler.IsKeyDown(sf::Key::I) || InputHandler.IsKeyDown(sf::Key::Up) || InputHandler.IsKeyDown(sf::Key::S) || InputHandler.IsKeyDown(sf::Key::K) || InputHandler.IsKeyDown(sf::Key::Down) || InputHandler.IsKeyDown(sf::Key::A) || InputHandler.IsKeyDown(sf::Key::J) || InputHandler.IsKeyDown(sf::Key::Left) || InputHandler.IsKeyDown(sf::Key::D) || InputHandler.IsKeyDown(sf::Key::L) || InputHandler.IsKeyDown(sf::Key::Right)) && GameTick.Get() - Last >= 0.25)
	{
		Last = GameTick.Get();
		MouseOrKey = 1;
		ActiveButton = 1;
	}
	if(!InputHandler.IsKeyDown(sf::Key::W) && !InputHandler.IsKeyDown(sf::Key::I) && !InputHandler.IsKeyDown(sf::Key::Up) && !InputHandler.IsKeyDown(sf::Key::S) && !InputHandler.IsKeyDown(sf::Key::K) && !InputHandler.IsKeyDown(sf::Key::Down) && !InputHandler.IsKeyDown(sf::Key::A) && !InputHandler.IsKeyDown(sf::Key::J) && !InputHandler.IsKeyDown(sf::Key::Left) && !InputHandler.IsKeyDown(sf::Key::D) && !InputHandler.IsKeyDown(sf::Key::L) && !InputHandler.IsKeyDown(sf::Key::Right) && !InputHandler.IsKeyDown(sf::Key::Return))
		Last = -1;
}

void Input::About(float &Last, bool &MouseOrKey, int &ActiveButton)
{
	MouseMoved = false;
	LeftMouseButton = false;
	
	while(GameWindow.GetEvent(EventHandler))
	{
		if(EventHandler.Type == sf::Event::Closed)
			GameSystem.SetState(System::QUITTED);
		if(EventHandler.Type == sf::Event::KeyPressed && EventHandler.Key.Code == sf::Key::Escape)
			GameSystem.SetState(System::MENU);
		
		MouseMoved = (EventHandler.Type == sf::Event::MouseMoved);
		LeftMouseButton = (EventHandler.Type == sf::Event::MouseButtonPressed && EventHandler.MouseButton.Button == sf::Mouse::Left);
	}
	
	if((InputHandler.IsKeyDown(sf::Key::W) || InputHandler.IsKeyDown(sf::Key::I) || InputHandler.IsKeyDown(sf::Key::Up) || InputHandler.IsKeyDown(sf::Key::S) || InputHandler.IsKeyDown(sf::Key::K) || InputHandler.IsKeyDown(sf::Key::Down) || InputHandler.IsKeyDown(sf::Key::A) || InputHandler.IsKeyDown(sf::Key::J) || InputHandler.IsKeyDown(sf::Key::Left) || InputHandler.IsKeyDown(sf::Key::D) || InputHandler.IsKeyDown(sf::Key::L) || InputHandler.IsKeyDown(sf::Key::Right)) && GameTick.Get() - Last >= 0.25)
	{
		Last = GameTick.Get();
		MouseOrKey = 1;
		ActiveButton = 1;
	}
	if(!InputHandler.IsKeyDown(sf::Key::W) && !InputHandler.IsKeyDown(sf::Key::I) && !InputHandler.IsKeyDown(sf::Key::Up) && !InputHandler.IsKeyDown(sf::Key::S) && !InputHandler.IsKeyDown(sf::Key::K) && !InputHandler.IsKeyDown(sf::Key::Down) && !InputHandler.IsKeyDown(sf::Key::A) && !InputHandler.IsKeyDown(sf::Key::J) && !InputHandler.IsKeyDown(sf::Key::Left) && !InputHandler.IsKeyDown(sf::Key::D) && !InputHandler.IsKeyDown(sf::Key::L) && !InputHandler.IsKeyDown(sf::Key::Right) && !InputHandler.IsKeyDown(sf::Key::Return))
		Last = -1;
}

void Input::Play(bool Explaining, int &GameOver)
{
	while(GameWindow.GetEvent(EventHandler))
	{
		if(EventHandler.Type == sf::Event::Closed)
			GameSystem.SetState(System::QUITTED);
		if(EventHandler.Type == sf::Event::KeyPressed && EventHandler.Key.Code == sf::Key::Escape && !Explaining)
			GameOver = 5;
	}
}

void Input::GameOver(float &Last, bool &MouseOrKey, int &ActiveButton)
{
	MouseMoved = false;
	LeftMouseButton = false;
	
	while(GameWindow.GetEvent(EventHandler))
	{
		if(EventHandler.Type == sf::Event::Closed)
			GameSystem.SetState(System::QUITTED);
		if(EventHandler.Type == sf::Event::KeyPressed && EventHandler.Key.Code == sf::Key::Escape)
			GameSystem.SetState(System::MENU);
		
		MouseMoved = (EventHandler.Type == sf::Event::MouseMoved);
		LeftMouseButton = (EventHandler.Type == sf::Event::MouseButtonPressed && EventHandler.MouseButton.Button == sf::Mouse::Left);
	}
	
	if((InputHandler.IsKeyDown(sf::Key::W) || InputHandler.IsKeyDown(sf::Key::I) || InputHandler.IsKeyDown(sf::Key::Up)) && GameTick.Get() - Last >= 0.25)
	{
		Last = GameTick.Get();
		MouseOrKey = 1;
		ActiveButton--;
		if(ActiveButton < 1)
			ActiveButton = 2;
	}
	if((InputHandler.IsKeyDown(sf::Key::S) || InputHandler.IsKeyDown(sf::Key::K) || InputHandler.IsKeyDown(sf::Key::Down)) && GameTick.Get() - Last >= 0.25)
	{
		Last = GameTick.Get();
		MouseOrKey = 1;
		ActiveButton++;
		if(ActiveButton > 2)
			ActiveButton = 1;
	}
	if(!InputHandler.IsKeyDown(sf::Key::W) && !InputHandler.IsKeyDown(sf::Key::I) && !InputHandler.IsKeyDown(sf::Key::Up) && !InputHandler.IsKeyDown(sf::Key::S) && !InputHandler.IsKeyDown(sf::Key::K) && !InputHandler.IsKeyDown(sf::Key::Down) && !InputHandler.IsKeyDown(sf::Key::Return))
		Last = -1;	
}


int Input::MouseX()
{
	return InputHandler.GetMouseX();
}
int Input::MouseY()
{
	return InputHandler.GetMouseY();
}


bool Input::IsDown(sf::Key::Code KeyCode)
{
	return InputHandler.IsKeyDown(KeyCode);
}
bool Input::IsDown(sf::Mouse::Button MouseButton)
{
	return InputHandler.IsMouseButtonDown(MouseButton);
}