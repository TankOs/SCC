/* (c) by Jonas Kaiser - about.cpp */
/* Header */
#include "about.h"


About::About(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, Sound &TmpSound, sf::Image &ButtonImg, sf::Image &MsgBoxImg, sf::Font &KomikaAxis, float &TmpKeyUse) :
	GameWindow(TmpWindow),
	GameSystem(TmpSystem),
	GameTick(TmpTick),
	GameInput(TmpInput),
	GameSound(TmpSound),
	AboutMsg(GameWindow, GameSystem, MsgBoxImg, KomikaAxis, sf::IntRect(0, 0, 800, 450), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 75 * GameSystem.GetWindowFactor(), "Multicolored\nMultitask\n\nMade by\nDeath Bread\nfor the 24th SCC"),
	BackButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImg, KomikaAxis, sf::IntRect(800, 0, 1200, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 225 * GameSystem.GetWindowFactor(), "Back", 1),
	LastKeyUse(TmpKeyUse)
{
	
}
About::~About()
{
	
}


void About::Recalculate()
{
	AboutMsg.Recalculate();
	BackButton.Recalculate();
	AboutMsg.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	BackButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	AboutMsg.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 75 * GameSystem.GetWindowFactor());
	BackButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 225 * GameSystem.GetWindowFactor());
}

void About::Reset()
{
	MouseOrKey = 0;
	ActiveButton = 0;
	TmpActiveButton = 0;
}

void About::Update()
{
	GameInput.About(LastKeyUse, MouseOrKey, ActiveButton);
	if(GameInput.MouseMoved)
		ActiveButton = 0;
	
	BackButton.IsActive(ActiveButton);
	if(BackButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		GameSystem.SetState(System::MENU);
	}
	
	if(TmpActiveButton != ActiveButton && ActiveButton != 0 && GameSystem.GetSound())
		GameSound.MenuChange.Play();
	TmpActiveButton = ActiveButton;
}

void About::Display()
{
	AboutMsg.Display();
	BackButton.Display();
}

void About::Delete()
{
	AboutMsg.Delete();
}