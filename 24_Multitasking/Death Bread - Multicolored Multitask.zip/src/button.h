/* (c) by Jonas Kaiser - button.h */
/* Headerguards */
#ifndef BUTTON_H
#define BUTTON_H

/* Headers */
#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "system.h"
#include "tick.h"
#include "input.h"


class Button
{
public:
	Button(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, sf::Image &Image, sf::Font &KomikaAxis, sf::IntRect SubRect, float PosX, float PosY, std::string TmpText, int InitNumber);
	~Button();
	
	bool MouseOver();
	bool IsActive(bool &MouseOrKey, int &ActiveNumber);
	bool IsActive(int &ActiveNumber);
	bool Used(float &LastKeyUse, bool &MouseOrKey, int &ActiveNumber);
	
	std::string GetText();
	void SetText(std::string New);
	
	int GetNumber();
	void SetNumber(int New);
	
	void SetPosition(int x, int y);
	void SetPosition(sf::Vector2i Pos);
	void SetScale(float x, float y);
	void SetScale(sf::Vector2f Scale);
	void Recalculate();

	void Display();
	
private:
	sf::RenderWindow &GameWindow;
	
	System &GameSystem;
	Tick &GameTick;
	Input &GameInput;
	
	sf::Sprite Sprite;
	
	sf::String Text;
	int TextSize;
	
	int Number;
	sf::Vector2i Position;
	
	bool Active;
};

#endif