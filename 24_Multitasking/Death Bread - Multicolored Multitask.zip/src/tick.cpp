/* (c) by Jonas Kaiser - tick.cpp */
/* Header */
#include "tick.h"


Tick::Tick() :
	Time(0)
{
	
}
Tick::~Tick()
{
	
}

void Tick::Update(float FPSReturnTime)
{
	Set(Get() + Timer.GetElapsedTime());
	Timer.Reset();
	UpdateFPS(FPSReturnTime);
}

float Tick::Get()
{
	return Time;
}

void Tick::Set(float New)
{
	Time = New;
}

void Tick::UpdateFPS(float ReturnTime)
{
	if(FPSTimer.GetElapsedTime() >= ReturnTime)
	{
		FPS = Frames / FPSTimer.GetElapsedTime();
		Frames = 0;
		FPSTimer.Reset();
	}
	else
	{
		FPS = -1;
	}
	
	Frames++;
}

float Tick::GetFPS()
{
	return FPS;
}