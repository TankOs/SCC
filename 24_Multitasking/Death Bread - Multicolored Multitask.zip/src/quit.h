/* (c) by Jonas Kaiser - quit.h */
/* Headerguards */
#ifndef QUIT_H
#define QUIT_H

/* Headers */
#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "system.h"
#include "tick.h"
#include "input.h"
#include "sound.h"
#include "messagebox.h"
#include "button.h"


class Quit
{
public:
	Quit(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, Sound &TmpSound, sf::Image &ButtonImg, sf::Image &MsgBoxImg, sf::Font &KomikaAxis, float &TmpKeyUse);
	~Quit();
	
	void Recalculate();
	
	void Reset();
	void Update();
	void Display();
	void Delete();
	
private:
	sf::RenderWindow &GameWindow;
	
	System &GameSystem;
	Tick &GameTick;
	Input &GameInput;
	Sound &GameSound;
	
	Messagebox QuitMsg;
	
	Button YesButton;
	Button NoButton;
	
	float &LastKeyUse;
	bool MouseOrKey;
	int ActiveButton;	
	int TmpActiveButton;	
};

#endif