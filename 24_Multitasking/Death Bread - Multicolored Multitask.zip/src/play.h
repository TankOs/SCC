/* (c) by Jonas Kaiser - play.h */
/* Headerguards */
#ifndef PLAY_H
#define PLAY_H

/* Headers */
#include <iostream>
#include <sstream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "system.h"
#include "tick.h"
#include "input.h"
#include "sound.h"
#include "messagebox.h"


class Play
{
public:
	Play(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, Sound &TmpSound, sf::Font &KomikaAxis, sf::Image &MsgBoxImg, std::string &TmpFinalScore);
	~Play();
	
	void Recalculate();
	
	void Reset();
	void Update();
	void Display();
	void Delete();
	
private:
	sf::RenderWindow &GameWindow;
	
	System &GameSystem;
	Tick &GameTick;
	Input &GameInput;
	Sound &GameSound;
	
	float TmpWindowFactor;
	
	sf::FloatRect RedGame;
	sf::FloatRect GreenGame;
	sf::FloatRect BlueGame;
	sf::FloatRect YellowGame;
	
	sf::Image BackgroundImg;
	sf::Sprite Background;
	
	sf::Image TileImg;
	sf::Sprite RedChar;
	sf::Sprite GreenChar;
	sf::Sprite YellowChar;
	sf::Sprite WallTop;
	sf::Sprite WallBottom;
	sf::Sprite WallMid;
	sf::Sprite WallSmall;
	sf::Sprite Spike;
	sf::Sprite RedBlue;
	sf::Sprite GreenYellow;
	sf::Sprite RedBallSprite;
	sf::Sprite GreenBallSprite;
	sf::Sprite BlueBallSprite;
	sf::Sprite YellowBallSprite;
	
	struct RedWall
	{
		int Size;
		sf::Vector2i InitPosition;
		sf::Sprite *Sprite;
		
		RedWall *Next;
	} *FirstWall, *Wall, *TmpWall;
	float LastRedWallSpawn;
	
	struct GreenBallStruct
	{
		sf::Sprite *Sprite;
		
		GreenBallStruct *Next;
	} *FirstGreenBall, *GreenBall, *TmpGreenBall;
	float LastGreenBallSpawn;
	
	struct ColoredBallStruct
	{
		int Color;
		sf::Sprite *Sprite;
		
		ColoredBallStruct *Next;
	} *FirstColoredBall, *ColoredBall, *TmpColoredBall;
	float LastColoredBallSpawn;
	float LastSpaceUse;
	bool BlueFlipped;
	
	struct YellowStruct
	{
		bool IsSpike;
		sf::Sprite *Sprite;
		
		YellowStruct *Next;
	} *FirstYellow, *Yellow, *TmpYellow;
	float LastYellowSpawn;
	
	int TmpVisibility;
	
	float Speed;
	
	int GameOver;
	std::string &FinalScore;
	
	float RealScore;
	int Score;
	std::stringstream ScoreSStream;
	sf::String ScoreString;
	
	int Explained;
	bool Explaining;
	
	Messagebox RedExplaination;
	Messagebox GreenExplaination;
	Messagebox BlueExplaination;
	Messagebox YellowExplaination;
};

#endif