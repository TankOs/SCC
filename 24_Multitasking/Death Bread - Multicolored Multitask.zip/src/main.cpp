/* (c) by Jonas Kaiser - main.cpp */
/* Headers */
#include "game.h"


Game Game;

int main()
{
	Game.Loop();
	
	return EXIT_SUCCESS;
}