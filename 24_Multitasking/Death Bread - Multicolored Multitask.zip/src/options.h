/* (c) by Jonas Kaiser - help.h */
/* Headerguards */
#ifndef OPTIONS_H
#define OPTIONS_H

/* Headers */
#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "system.h"
#include "input.h"
#include "sound.h"
#include "messagebox.h"
#include "button.h"


class Options
{
public:
	Options(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, Sound &TmpSound, sf::Image &ButtonImage, sf::Font &KomikaAxis, float &TmpKeyUse);
	~Options();
	
	void Recalculate();
	
	void Reset();
	void Update();
	void Display();
	void Defaults();
	void Set();
	
private:
	sf::RenderWindow &GameWindow;
	
	System &GameSystem;
	Tick &GameTick;
	Input &GameInput;
	Sound &GameSound;

	Button FullscreenButton;
	Button SoundButton;
	Button MusicButton;
	
	Button ResetButton;
	Button OkButton;
	Button AbortButton;
	
	float &LastKeyUse;
	bool MouseOrKey;
	int ActiveButton;
	int TmpActiveButton;
	
	bool FullscreenOn;
	bool TmpFullscreenOn;
	bool SoundOn;
	bool TmpSoundOn;
	bool MusicOn;
	bool TmpMusicOn;
};

#endif