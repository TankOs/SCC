/* (c) by Jonas Kaiser - menu.h */
/* Headerguards */
#ifndef MENU_H
#define MENU_H

/* Headers */
#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "system.h"
#include "tick.h"
#include "input.h"
#include "sound.h"
#include "button.h"


class Menu
{
public:
	Menu(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, Sound &TmpSound, sf::Image &ButtonImage, sf::Font &KomikaAxis, float &TmpKeyUse);
	~Menu();
	
	void Recalculate();
	
	void Reset();
	void Update();
	void Display();
	
private:
	sf::RenderWindow &GameWindow;
	
	System &GameSystem;
	Tick &GameTick;
	Input &GameInput;
	Sound &GameSound;
	
	Button PlayButton;
	Button OptionsButton;
	Button HelpButton;
	Button AboutButton;
	Button QuitButton;
	
	float &LastKeyUse;
	bool MouseOrKey;
	int ActiveButton;
	int TmpActiveButton;	
};

#endif