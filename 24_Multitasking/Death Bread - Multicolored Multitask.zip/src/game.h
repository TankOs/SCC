/* (c) by Jonas Kaiser - game.h */
/* Headerguards */
#ifndef GAME_H
#define GAME_H

/* Headers */
#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "system.h"
#include "tick.h"
#include "input.h"
#include "sound.h"
#include "quit.h"
#include "menu.h"
#include "options.h"
#include "help.h"
#include "about.h"
#include "play.h"
#include "gameover.h"


class Game
{
public:
	Game();
	~Game();
	
	void Loop();
	
protected:
	sf::RenderWindow GameWindow;
	
	sf::Image BackgroundImg;
	sf::Sprite Background;
	
	sf::Image CursorImg;
	sf::Sprite Cursor;
	
	sf::Image ButtonImg;
	sf::Image MsgBoxImg;
	sf::Font KomikaAxis;
	
	std::string FinalScore;
	
	System GameSystem;
	Tick GameTick;
	Input GameInput;
	Sound GameSound;
	Quit QuitScreen;
	Menu MenuScreen;
	Options OptionScreen;
	Help HelpScreen;
	About AboutScreen;
	Play PlayScreen;
	GameOver GameOverScreen;
	
	bool IsRunning;
	
	int TmpState;
	bool TmpFullscreen;
	
	float LastKeyUse;
};

#endif