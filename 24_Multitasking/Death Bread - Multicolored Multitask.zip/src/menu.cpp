/* (c) by Jonas Kaiser - menu.cpp */
/* Header */
#include "menu.h"


Menu::Menu(sf::RenderWindow &TmpWindow, System &TmpSystem, Tick &TmpTick, Input &TmpInput, Sound &TmpSound, sf::Image &ButtonImage, sf::Font &KomikaAxis, float &TmpKeyUse) :
	GameWindow(TmpWindow),
	GameSystem(TmpSystem),
	GameTick(TmpTick),
	GameInput(TmpInput),
	GameSound(TmpSound),
	PlayButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImage, KomikaAxis, sf::IntRect(0, 0, 800, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 300 * GameSystem.GetWindowFactor(), "Play", 1),
	OptionsButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImage, KomikaAxis, sf::IntRect(0, 0, 800, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 150 * GameSystem.GetWindowFactor(), "Options", 2),
	HelpButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImage, KomikaAxis, sf::IntRect(0, 0, 800, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2, "Help", 3),
	AboutButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImage, KomikaAxis, sf::IntRect(0, 0, 800, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 150 * GameSystem.GetWindowFactor(), "About", 4),
	QuitButton(GameWindow, GameSystem, GameTick, GameInput, ButtonImage, KomikaAxis, sf::IntRect(0, 0, 800, 150), GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 300 * GameSystem.GetWindowFactor(), "Quit", 5),
	LastKeyUse(TmpKeyUse)
{
	
}
Menu::~Menu()
{
	
}


void Menu::Recalculate()
{
	PlayButton.Recalculate();
	OptionsButton.Recalculate();
	HelpButton.Recalculate();
	AboutButton.Recalculate();
	QuitButton.Recalculate();
	PlayButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	OptionsButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	HelpButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	AboutButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	QuitButton.SetScale(GameSystem.GetWindowFactor(), GameSystem.GetWindowFactor());
	PlayButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 300 * GameSystem.GetWindowFactor());
	OptionsButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 - 150 * GameSystem.GetWindowFactor());
	HelpButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2);
	AboutButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 150 * GameSystem.GetWindowFactor());
	QuitButton.SetPosition(GameSystem.GetWindowWidth() / 2, GameSystem.GetWindowHeight() / 2 + 300 * GameSystem.GetWindowFactor());
}

void Menu::Reset()
{
	MouseOrKey = 0;
	ActiveButton = 0;
	TmpActiveButton = 0;
}

void Menu::Update()
{
	GameInput.Menu(LastKeyUse, MouseOrKey, ActiveButton);
	if(GameInput.MouseMoved && MouseOrKey == 0)
		ActiveButton = 0;
	
	PlayButton.IsActive(MouseOrKey, ActiveButton);
	if(PlayButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		GameSystem.SetState(System::PLAY);
	}
	OptionsButton.IsActive(MouseOrKey, ActiveButton);
	if(OptionsButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		GameSystem.SetState(System::OPTIONS);
	}
	HelpButton.IsActive(MouseOrKey, ActiveButton);
	if(HelpButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		GameSystem.SetState(System::HELP);
	}
	AboutButton.IsActive(MouseOrKey, ActiveButton);
	if(AboutButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		GameSystem.SetState(System::ABOUT);
	}
	QuitButton.IsActive(MouseOrKey, ActiveButton);
	if(QuitButton.Used(LastKeyUse, MouseOrKey, ActiveButton))
	{
		if(GameSystem.GetSound())
			GameSound.MenuSelect.Play();
		GameSystem.SetState(System::QUIT);
	}
	
	if(TmpActiveButton != ActiveButton && ActiveButton != 0 && GameSystem.GetSound())
		GameSound.MenuChange.Play();
	TmpActiveButton = ActiveButton;
}

void Menu::Display()
{
	PlayButton.Display();
	OptionsButton.Display();
	HelpButton.Display();
	AboutButton.Display();
	QuitButton.Display();
}