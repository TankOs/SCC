/* (c) by Jonas Kaiser - messagebox.h */
/* Headerguards */
#ifndef MESSAGEBOX_H
#define MESSAGEBOX_H

/* Headers */
#include <iostream>
#include <sstream>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "system.h"

class Messagebox
{
public:
	Messagebox(sf::RenderWindow &TmpWindow, System &TmpSystem, sf::Image &Image, sf::Font &KomikaAxis, sf::IntRect SubRect, float PosX, float PosY, std::string TmpContent);
	~Messagebox();
	
	std::string GetText();
	void SetText(std::string NewLine , int Line);
	
	void SetPosition(int x, int y);
	void SetPosition(sf::Vector2i Pos);
	void SetScale(float x, float y);
	void SetScale(sf::Vector2f Scale);
	void Recalculate();
	
	void Display();
	void Delete();
	
private:
	sf::RenderWindow &GameWindow;
	
	System &GameSystem;
		
	sf::Sprite Sprite;
	
	sf::String *Content;
	int Line;
	std::string TmpText;
	std::string Text;
	
	sf::Vector2i Position;
};

#endif