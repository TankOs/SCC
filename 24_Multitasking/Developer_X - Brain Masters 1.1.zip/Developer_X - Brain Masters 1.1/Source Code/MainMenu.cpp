/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "MainMenu.hpp"
using namespace std;

///	Funktionen
void MainMenu::Init()
{
/// Setze Parameter
	w  = 1440;
	h  = 900;
	o  = 0;
	ft = 0;

///	Lade Daten
	LoadData();
}
void MainMenu::LoadData()
{
///	Window erstellen
	sf::WindowSettings Settings;
	Settings.DepthBits         = 24; /// Depth Buffer
	Settings.StencilBits       = 8;  /// Stencil Buffer
	Settings.AntialiasingLevel = 5;  /// Antialising

	window = new sf::RenderWindow(sf::VideoMode::GetDesktopMode(), "Brain Game by Kevin Riehl C 2011", sf::Style::Fullscreen, Settings);
	window->SetActive(true);
	window->SetFramerateLimit(50);
	window->ShowMouseCursor(false);

///	Lade Font
	f.LoadFromFile("sources/Fonts/Brain Storm.ttf");
	s.SetFont(f);

///	Lade Bild
	m.LoadFromFile("sources/Images/Logo.jpg");
	symbol.SetImage(m);
	symbol.SetCenter(m.GetWidth()/2,m.GetHeight()/2);
}
void MainMenu::Intro()
{
	ft = 255.0f;
	for(int i = 90;i>0;i--)
	{
		ft = sin(i*0.018f)*255.0f;
		DrawMenu();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
	ft = 0.0f;
}
void MainMenu::Outro()
{
	ft = 0;
	for(int i = 0;i<90;i++)
	{
		ft = sin(i*0.018f)*255.0f;
		DrawMenu();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
	ft = 255.0f;
}

void MainMenu::StartGame()
{
	Game* g =  new Game(a,sm);
	g->Run();
	delete g;
}
void MainMenu::AchiGUI()
{
	AchievementGUI* ag =  new AchievementGUI(a);
	ag->Run();
	delete ag;
}
void MainMenu::StatGUI()
{
	StatisticsGUI* sg =  new StatisticsGUI(sm,a);
	sg->Run();
	delete sg;
}

void MainMenu::StartMusic()
{
	sf::SoundBuffer sb;
	sb.LoadFromFile("sources/Sounds/Scratch.wav");
	sf::Sound so;
	so.SetBuffer(sb);
	so.Play();

	sf::Clock c;
	while(c.GetElapsedTime()<1.0f)
	{
		mus->SetVolume(c.GetElapsedTime()*100);
		window->Draw(sf::Shape::Rectangle(0,0,window->GetWidth(),window->GetHeight(),sf::Color::White));
		window->Display();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
}
void MainMenu::QuitMusic ()
{
	sf::Clock c;
	while(c.GetElapsedTime()<1.0f)
	{
		mus->SetVolume(100-c.GetElapsedTime()*100);
		window->Draw(sf::Shape::Rectangle(0,0,window->GetWidth(),window->GetHeight(),sf::Color::White));
		window->Display();
		sf::Event Event;while (window->GetEvent(Event)){}
	}

	sf::SoundBuffer sb;
	sb.LoadFromFile("sources/Sounds/Scratch.wav");
	sf::Sound so;
	so.SetBuffer(sb);
	so.Play();
}

void MainMenu::Run()
{
	running = true;

	QuitMusic();
	while(true)
	{
		running = true;
		StartMusic();
		Intro();
		while(running)
		{
		///	Pr�fe Benutzereingaben
			CheckEvents();

		///	Zeichne Men�
			DrawMenu();
		}
		Outro();
		QuitMusic();

		if(o==1)
		{
			StartGame();
		}
		else if(o==2)
		{
			AchiGUI();
		}
		else if(o==3)
		{
			StatGUI();
		}
		else if(o==4)
		{
			break;
		}
	}

	delete window;
}
void MainMenu::CheckEvents()
{
	sf::Event Event;
	while (window->GetEvent(Event))
	{
		if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::Return) && (o>=1&&o<=4))
		{
			running = false;
			sfy.Play("medall");
		}
		else if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::Num1))
		{
			o = 1;
			sfy.Play("point");
		}
		else if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::Num2))
		{
			o = 2;
			sfy.Play("point");
		}
		else if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::Num3))
		{
			o = 3;
			sfy.Play("point");
		}
		else if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::Num4))
		{
			o = 4;
			sfy.Play("point");
		}
		else if ((Event.Type == sf::Event::KeyPressed))
		{
			o = 0;
			sfy.Play("error");
		}
	}
}
void MainMenu::DrawMenu()
{
///	View setzen
	window->SetView(sf::View(sf::FloatRect(0,0,w,h)));

///	Sounds verrechnen
	sfy.Compute();

///	Hintergrund zeichnen
	DrawBackground();

///	Zeichne Symbole
	DrawSymbols();

///	Zeichne Optionen
	DrawOptions();

///	Zeichne Vordergrund
	DrawForeground();

///	Bild aktualisieren
	window->Display();
}
void MainMenu::DrawBackground()
{
	window->Draw(sf::Shape::Rectangle(0,0,w,h,sf::Color::Black));
}
void MainMenu::DrawSymbols()
{
///	Zeichne Bild
	symbol.SetScale(0.9f+0.1f*cos(t.GetElapsedTime()),0.9f+0.1f*cos(t.GetElapsedTime()));
	symbol.SetPosition(w/2,h/2);
	window->Draw(symbol);

///	Zeichne Titel
	s.SetSize(100+sin(t.GetElapsedTime())*5.0f);
	s.SetText("BrainMasters");
	s.SetColor(sf::Color::Cyan);
	s.SetPosition(w/2-s.GetRect().GetWidth()/2,s.GetRect().GetHeight()/2);
	window->Draw(s);

///	Zeichne Hilfe
	if(o>=1&&o<=5)
	{
		s.SetSize(40);
		s.SetText("Fortfahren mit ENTER");
		s.SetColor(sf::Color::White);
		s.SetPosition(w-s.GetRect().GetWidth()-20,h-s.GetRect().GetHeight()-20);
		window->Draw(s);
	}
}
void MainMenu::DrawOptions()
{
	s.SetSize(30);

	DrawOption("[1]","Starte Spiel",w/3-00,h/4+30  ,(o==1));
	DrawOption("[2]","Achievements",w/3-20,h/4+80  ,(o==2));
	DrawOption("[3]","Statistik"   ,w/3-40,h/4+130 ,(o==3));
	DrawOption("[4]","Beenden"     ,w/3-200,h/4+180,(o==4));
}
void MainMenu::DrawOption(std::string n,std::string txt,int x,int y,bool b)
{
	s.SetColor(sf::Color::White);

///	Zeichne Hintergrund
	if(!b)
		window->Draw(sf::Shape::Rectangle(0,y-2,x,y+s.GetRect().GetHeight()+5,sf::Color(255,255,255,100)));
	else
		window->Draw(sf::Shape::Rectangle(0,y-2,x,y+s.GetRect().GetHeight()+5,sf::Color(255,255,255,255)));

///	Zeichne Nummer
	if(!b)
	{
		s.SetFont(sf::Font::GetDefaultFont());
		s.SetText(n);
		s.SetPosition(10,y-5);
		window->Draw(s);
	}

/// Zeichne Text
	if(!b)
	{
		s.SetFont(f);
		s.SetText(txt);
		s.SetPosition(50,y);
		window->Draw(s);
	}
	else
	{
		s.SetColor(sf::Color::Blue);
		s.SetFont(f);
		s.SetText(txt);
		s.SetPosition(60,y);
		window->Draw(s);
	}
}
void MainMenu::DrawForeground()
{
	window->Draw(sf::Shape::Rectangle(0,0,w,h,sf::Color(255,255,255,ft)));
}

///	Konstruktor
MainMenu::MainMenu(sf::Music* mu,Achievements* ac,StatisticsManager* m) : mus(mu),a(ac),sm(m),sfy(SoundFactory())
{
///	Initialisiere
	Init();
}
