/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>

#include "Intro.hpp"
#include "MainMenu.hpp"
#include "Achievements.hpp"
#include "StatisticsManager.hpp"

#include <string>
#include <iostream>
using namespace std;

/// Attribute
sf::Music m;
sf::RenderWindow* window;

MainMenu* mm;

Achievements*     ach;
StatisticsManager* sm;

///	Funktionen
void ChangeMusic(string s)
{
	sf::Clock t;
	while(t.GetElapsedTime()<1.0f)
	{
		m.SetVolume(100-t.GetElapsedTime()*100);
		window->Draw(sf::Shape::Rectangle(0,0,window->GetWidth(),window->GetHeight(),sf::Color::White));
		window->Display();
		sf::Event Event;while (window->GetEvent(Event)){}
	}

	m.OpenFromFile(s);
	m.SetLoop(true);
	m.Play();

	sf::SoundBuffer sb;
	sb.LoadFromFile("sources/Sounds/Scratch.wav");
	sf::Sound so;
	so.SetBuffer(sb);
	so.Play();

	t.Reset();
	while(t.GetElapsedTime()<1.0f)
	{
		m.SetVolume(t.GetElapsedTime()*100);
		window->Draw(sf::Shape::Rectangle(0,0,window->GetWidth(),window->GetHeight(),sf::Color::White));
		window->Display();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
}

///	Main
int main()
{
	sf::Clock watch;

///	Fenster erstellen
	sf::WindowSettings Settings;
	Settings.DepthBits         = 24; /// Depth Buffer
	Settings.StencilBits       = 8;  /// Stencil Buffer
	Settings.AntialiasingLevel = 5;  /// Antialising

	window = new sf::RenderWindow(sf::VideoMode::GetDesktopMode(), "Brain Game by Kevin Riehl C 2011", sf::Style::Fullscreen, Settings);
	window->SetActive(true);
	window->SetFramerateLimit(50);
	window->ShowMouseCursor(false);

///	Achievements laden
	ach = new Achievements();
	ach->Init();
	ach->Start();

///	Statistics laden
	sm = new StatisticsManager();
	sm->LoadData();

///	Intro
	ChangeMusic("sources/Music/Music.ogg");

	Intro* i = new Intro(window);
	delete i;

///	MainMenu
	mm = new MainMenu(&m,ach,sm);
	mm->Run();

///	Musik leiser machen
	sf::Clock t;
	while(m.GetVolume()>2)
	{
		m.SetVolume(m.GetVolume()-1);
		sf::Event Event;while(window->GetEvent(Event)){;}
		window->Draw(sf::Shape::Rectangle(0,0,window->GetWidth(),window->GetHeight(),sf::Color::White));window->Display();
		while(t.GetElapsedTime()<0.05f)
			;
		t.Reset();
	}

///	Speichere Statistics
	sm->SaveData();

///	F�ge verspiele Zeit hinzu
	ach->AddTime(watch.GetElapsedTime());

///	Speichere Achievements
	ach->SaveMemory();

///	Beenden
	return 0;
}
