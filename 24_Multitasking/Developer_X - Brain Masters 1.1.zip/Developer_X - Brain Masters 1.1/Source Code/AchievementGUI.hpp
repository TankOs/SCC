#ifndef ACHIEVEMENTGUI_HPP_INCLUDED
#define ACHIEVEMENTGUI_HPP_INCLUDED

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>

#include "SoundFactory.hpp"
#include "Achievements.hpp"
#include <vector>

class AchievementGUI
{
public :
///	Attribute
	sf::RenderWindow* window;
	sf::Image  b;
	sf::Sprite back;
	sf::Image  m2;
	sf::Sprite q;
	sf::Clock  t;
	sf::Font   f;
	sf::String s;
	sf::Music* m;
	SoundFactory sfy;
	std::vector<sf::Vector2f> positions;

	Achievements* a;
	float ft;
	int w;
	int h;
	bool running;

///	Funktionen
	void Init();
	void LoadData();
	void Intro();
	void Outro();

	void StartMusic();
	void QuitMusic ();

	void Run();
	void CheckEvents();
	void DrawGUI();
	void DrawBackground();
	void DrawAchievements();
	void DrawInfo();

///	Konsturktor
	AchievementGUI(Achievements* a);
};

#endif // ACHIEVEMENTGUI_HPP_INCLUDED
