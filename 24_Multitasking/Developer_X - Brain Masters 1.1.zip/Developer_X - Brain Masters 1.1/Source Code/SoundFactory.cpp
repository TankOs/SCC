/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "SoundFactory.hpp"
#include <iostream>
using namespace std;

///	Funktionen
void SoundFactory::LoadData()
{
	string path = "sources/Sounds/";

	sf::SoundBuffer sb1;
	sb1.LoadFromFile(path+"Fake.wav");
	buffers.push_back(sb1);

	sf::SoundBuffer sb2;
	sb2.LoadFromFile(path+"Medall.wav");
	buffers.push_back(sb2);

	sf::SoundBuffer sb3;
	sb3.LoadFromFile(path+"Point1.wav");
	buffers.push_back(sb3);

	sf::SoundBuffer sb4;
	sb4.LoadFromFile(path+"Point2.wav");
	buffers.push_back(sb4);

	sf::SoundBuffer sb5;
	sb5.LoadFromFile(path+"Collect.wav");
	buffers.push_back(sb5);

	sf::SoundBuffer sb6;
	sb6.LoadFromFile(path+"Looser.wav");
	buffers.push_back(sb6);
}

void SoundFactory::Compute()
{
	for(int i = 0;i<sounds.size();i++)
	{
		if(sounds[i].GetStatus()==sf::Sound::Stopped)
		{
			sounds[i].Stop();
			sounds.erase(sounds.begin()+i);
			break;
		}
	}
}
void SoundFactory::Play(std::string s)
{
	if(s=="error")
	{
		sf::Sound ss;
		ss.SetBuffer(buffers[0]);
		sounds.push_back(ss);
		sounds[sounds.size()-1].Play();
	}
	else if(s=="medall")
	{
		sf::Sound ss;
		ss.SetBuffer(buffers[1]);
		sounds.push_back(ss);
		sounds[sounds.size()-1].Play();
	}
	else if(s=="point")
	{
		int n = sf::Randomizer::Random(1,2);
		sf::Sound ss;
		ss.SetBuffer(buffers[1+n]);
		sounds.push_back(ss);
		sounds[sounds.size()-1].Play();
	}
	else if(s=="collect")
	{
		sf::Sound ss;
		ss.SetBuffer(buffers[4]);
		sounds.push_back(ss);
		sounds[sounds.size()-1].Play();
	}
	else if(s=="looser")
	{
		sf::Sound ss;
		ss.SetBuffer(buffers[5]);
		sounds.push_back(ss);
		sounds[sounds.size()-1].Play();
	}
}

///	Konstruktor
SoundFactory::SoundFactory()
{
	LoadData();
}
