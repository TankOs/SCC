#ifndef SOUNDFACTORY_HPP_INCLUDED
#define SOUNDFACTORY_HPP_INCLUDED

#include <SFML/Audio.hpp>
#include <vector>
#include <string>

class SoundFactory
{
public :
///	Attribute
	std::vector<sf::SoundBuffer> buffers;
	std::vector<sf::Sound>       sounds;

///	Funktionen
	void LoadData();

	void Compute();
	void Play(std::string s);

///	Konstruktor
	SoundFactory();
};

#endif // SOUNDFACTORY_HPP_INCLUDED
