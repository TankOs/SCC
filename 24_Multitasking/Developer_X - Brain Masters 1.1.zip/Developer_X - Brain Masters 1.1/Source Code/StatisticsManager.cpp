/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "StatisticsManager.hpp"

using namespace std;

///	Funktionen
void StatisticsManager::LoadData()
{
	max_value = 0;
	string line;
	ifstream f ("sources/Statistics/Statistics.txt");

	while(f.good())
	{
		getline (f,line);
		values.push_back(atof(line.c_str()));

		if(atof(line.c_str())>max_value)
		max_value = atof(line.c_str());
	}

	f.close();

	quotient = 0;
	for(int i = 0;i<values.size();i++)
		quotient += values[i];
	quotient /= values.size();
}
void StatisticsManager::SaveData()
{
	ofstream f ("sources/Statistics/Statistics.txt");

	for(int i = 0;i<values.size();i++)
	{
		f << toString(values[i]);

		if(i!=values.size()-1)
		{
			f << endl;
		}
	}

	f.close();
}
void StatisticsManager::AddResult(float t)
{
	values.push_back(t);

	if(t>max_value)
		max_value = t;

	quotient = 0;
	for(int i = 0;i<values.size();i++)
		quotient += values[i];
	quotient /= values.size();
}
void StatisticsManager::Reset()
{
	values.clear();
	SaveData();
}

///	Konstruktor
StatisticsManager::StatisticsManager()
{
}
