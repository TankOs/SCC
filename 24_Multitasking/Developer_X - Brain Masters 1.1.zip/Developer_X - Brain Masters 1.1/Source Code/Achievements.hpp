#ifndef ACHIEVEMENTS_HPP_INCLUDED
#define ACHIEVEMENTS_HPP_INCLUDED

#include "Achievement.hpp"
#include "System.hpp"
#include <fstream>
#include <vector>
#include <string>

class Achievements
{
public :
///	Strukturen
	struct Memory
	{
		int started;
		bool achi;
		bool stat;
		bool chea;
		int time;
		int pltime;
		bool all;
	} mem;

///	Attribute
	std::vector<Achievement> achievements;
	bool save;

///	Funktionen
	void Init();
	void LoadData();
	void LoadMemory();
	void LoadAchievements();
	void ComputeFree();
	void SaveMemory();

	void Start();
	void Achi ();
	void Stat ();
	void Cheat();
	void AddTime(int t);
	void PlTime (int t);

	void Reset();

///	Konstruktor
	Achievements();
};

#endif // ACHIEVEMENTS_HPP_INCLUDED
