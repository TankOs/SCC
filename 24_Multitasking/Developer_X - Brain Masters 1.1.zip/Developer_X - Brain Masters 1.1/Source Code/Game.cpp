/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "Game.hpp"
#include <iostream>
using namespace std;

///	Funktionen
void Game::Init()
{
///	Window erstellen
	sf::WindowSettings Settings;
	Settings.DepthBits         = 24; /// Depth Buffer
	Settings.StencilBits       = 8;  /// Stencil Buffer
	Settings.AntialiasingLevel = 5;  /// Antialising

	window = new sf::RenderWindow(sf::VideoMode::GetDesktopMode(), "Brain Game by Kevin Riehl C 2011", sf::Style::Fullscreen, Settings);
	window->SetActive(true);
	window->SetFramerateLimit(50);
	window->ShowMouseCursor(false);

/// Gr��en bestimmen
	w = 1440;
	h = 900;

///	Lade Daten
	LoadData();
}
void Game::LoadData()
{
///	Lade Music
	m = new sf::Music();
	m->OpenFromFile("sources/Music/Action Music.ogg");
	m->SetVolume(0);
	m->SetLoop(true);
	m->Play();

///	Lade Font
	f.LoadFromFile("sources/Fonts/Neutronium.ttf");

///	Initialisiere Texts
	texts.push_back("Spielanleitung [Zum Abbrechen Leertaste dr�cken]");
	texts.push_back(" ");
	texts.push_back("Der Bildschirm ist in vier Aufgabenbereiche unterteilt.");
	texts.push_back("Nach einer bestimmten Zeit bekommst du immer mehr Aufgaben");
	texts.push_back("hinzu, bis vier Aufgaben vorhanden sind.");
	texts.push_back("Die Aufgaben werden mit der Zeit immer schwerer.");
	texts.push_back("Jede der Aufgaben hat eine Fortschrittsanzeige. Je mehr");
	texts.push_back("du sie vernachl�ssigst, umso mehr steigt sie. Wenn sie voll ist,");
	texts.push_back("hast du verloren.");
	texts.push_back(" ");
	texts.push_back("Aufgabe 1 : Dr�cke den Buchstaben auf den Wolken");
	texts.push_back("Aufgabe 2 : Dr�cke die F-Tasten auf den Kreisen");
	texts.push_back("Aufgabe 3 : Suche den Cheat!");
	texts.push_back("Aufgabe 4 : Dr�cke die Nummern, du willst doch nicht OVERTIME, oder?");
	texts.push_back(" ");
	texts.push_back("Vielleicht findest du ja den ultimativen Cheat!");
	texts.push_back("Du kannst vorzeitig abbrechen, indem du ESC dr�ckst.");
	texts.push_back("Viel Gl�ck!");

	txs = 0;
	tys = 0;
	txe = 0;
	tye = 0;

///	Lade Bilder
	woodi.LoadFromFile("sources/Images/Mahagoni.jpg");
	wood.SetImage(woodi);
	wood.Resize(300,150);
	wood.SetPosition(w/2-150,h/2-75);

	cloudi.LoadFromFile("sources/Sprites/Cloud.png");
	cloud.SetImage(cloudi);
	cloud.Resize(175,116);
	cloud.SetCenter(cloudi.GetWidth()/2,cloudi.GetHeight()/2);

	heavyi.LoadFromFile("sources/Sprites/Heavy.png");
	heavy.SetImage(heavyi);
	heavy.SetCenter(heavyi.GetWidth()/2,heavyi.GetHeight()/2);
	heavy.Resize(500,500);

	andreas.LoadFromFile("sources/Sprites/Andreas.jpg");
	andi.SetImage(andreas);
	andi.SetCenter(andreas.GetWidth()/2,andreas.GetHeight()/2);

///	Setze Parameter
	as    = true;
	bs    = false;
	cs    = false;
	ds    = false;
	fa    = false;
	fb    = false;
	fc    = false;
	fd    = false;
	loose = false;
	at    = 0.0f;
	bt    = 0.0f;
	ct    = 0.0f;
	dt    = 0.0f;
}
void Game::Intro()
{
///	Hintergrund aufhellen
	for(int i = 90;i>0;i--)
	{
		ft = sin(i*0.018f)*255.0f;
		DrawGame();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
	ft = 0.0f;

///	Text Schreiben
	bool abort = false;
	for(int i = 0;i<texts.size();i++)
	{
		tye = i;
		for(int a = 0;a<texts[i].size();a++)
		{
			txe = a;
			if(!abort)
			{
				DrawGame();
			}
			sf::Event Event;
			while (window->GetEvent(Event))
			{
				if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::Space))
				{
					abort = true;
				}
			}
		}
	}

///	Warten
	sf::Clock c;
	while(c.GetElapsedTime()<3.0f&&!abort)
	{
		DrawGame();
		sf::Event Event;
		while (window->GetEvent(Event))
		{
			if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::Space))
			{
				abort = true;
			}
		}
	}

///	Text Entfernen
	for(int i = 0;i<texts.size();i++)
	{
		tys = i;
		for(int a = 0;a<texts[i].size();a++)
		{
			txs = a;

			if(!abort)
			{
				DrawGame();
			}
			sf::Event Event;
			while (window->GetEvent(Event))
			{
				if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::Space))
				{
					abort = true;
				}
			}
		}
	}
	texts.clear();
}
void Game::Outro()
{
///	Hintergrund verdunkeln
	for(int i = 0;i<90;i++)
	{
		ft = sin(i*0.018f)*255.0f;
		DrawGame();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
	ft = 255.0f;
}
void Game::StartMusic()
{
	sf::Clock c;
	while(c.GetElapsedTime()<1.0f)
	{
		m->SetVolume(c.GetElapsedTime()*100);
		DrawGame();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
}
void Game::QuitMusic()
{
	sf::Clock c;
	while(c.GetElapsedTime()<1.0f)
	{
		m->SetVolume(100-c.GetElapsedTime()*100);
		DrawGame();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
}

void Game::Run()
{
	running = true;

	StartMusic();
	Intro();

	t.Reset();
	while(running)
	{
		CheckEvents();
		ComputeGame();
		DrawGame();
	}
	if(loose)
	{
		float ts = t.GetElapsedTime();
		sm->AddResult(ts);
		achi->PlTime(ts);
	}
	else if(cheat)
	{
		Cheat();

		float ts = 1000;
		sm->AddResult(ts);
		achi->PlTime(ts);
	}

	Outro();
	QuitMusic();

	delete window;
}

void Game::CheckEvents()
{
	sf::Event Event;
	while (window->GetEvent(Event))
	{
	///	Beenden
		if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::Escape))
		{
			running = false;
		}

	///	Checke Tasks
		if (Event.Type == sf::Event::KeyPressed)
		{
			int code = Event.Key.Code;
			for(int i = 0;i<tasks.size();i++)
			{
				if(code==tasks[i].code)
				{
					if(tasks[i].area==1)
					{
						at -= 20.0f;
						if(at<0)
							at = 0;
					}
					else if(tasks[i].area==2)
					{
						bt -= 20.0f;
						if(bt<0)
							bt = 0;
					}
					else if(tasks[i].area==4)
					{
						dt -= 20.0f;
						if(dt<0)
							dt = 0;
					}

					sfy.Play("point");
					tasks.erase(tasks.begin()+i);
					break;
				}
			}

		///	Check Cheat
			if (code == 273&&cs)
			{
				cheat = true;
				running = false;
			}
		}
	}
}

void Game::ComputeGame()
{
///	Verrechne einzelne Areas
	if(as)
		ComputeA();
	if(bs)
		ComputeB();
	if(cs)
		ComputeC();
	if(ds)
		ComputeD();

///	Verrechne die Zeiten der Areas
	CheckTime();

///	Verrechne Freischaltung von Areas
	CheckAreas();

///	Verrechne die Tasks
	ComputeTasks();

///	Verrechne Speed
	ComputeSpeed();

///	Verrechne Sounds
	sfy.Compute();

///	Compute Overtime
	ComputeOvertime();
}
void Game::ComputeA()
{
	if(ac.GetElapsedTime()>0.5f/speed)
	{
		at += 1.0f;
		ac.Reset();
	}

	if(sa.GetElapsedTime()>shootspeed)
	{
		tasks.push_back(Task(1));
		sa.Reset();
		sfy.Play("collect");
	}
}
void Game::ComputeB()
{
	if(bc.GetElapsedTime()>0.5f/speed)
	{
		bt += 1.0f;
		bc.Reset();
	}

	if(sb.GetElapsedTime()>shootspeed)
	{
		tasks.push_back(Task(2));
		sb.Reset();
		sfy.Play("collect");
	}
}
void Game::ComputeC()
{
	if(cc.GetElapsedTime()>0.5f/speed)
	{
	//	ct += 1.0f;
		cc.Reset();
	}
}
void Game::ComputeD()
{
	if(dc.GetElapsedTime()>0.5f/speed)
	{
		dt += 1.0f;
		dc.Reset();
	}

	if(sd.GetElapsedTime()>shootspeed&&!overtime)
	{
		tasks.push_back(Task(4));
		sd.Reset();
		sfy.Play("collect");
	}
}
void Game::CheckTime()
{
	if(at>=100.0f||bt>=100.0f||ct>=100.0f)
	{
		sfy.Play("looser");
		running = false;
		loose = true;
	}
}
void Game::CheckAreas()
{
	if(t.GetElapsedTime()>0.0f&&!fa)
	{
		sfy.Play("medall");
		fa = true;
		as = true;
	}
	if(t.GetElapsedTime()>10.0f&&!fb)
	{
		sfy.Play("medall");
		fb = true;
		bs = true;
	}
	if(t.GetElapsedTime()>40.0f&&!fc)
	{
		sfy.Play("medall");
		fc = true;
		cs = true;
	}
	if(t.GetElapsedTime()>80.0f&&!fd)
	{
		sfy.Play("medall");
		fd = true;
		ds = true;
	}
}
void Game::ComputeTasks()
{
	for(int i = 0;i<tasks.size();i++)
	{
		if(tasks[i].t.GetElapsedTime()>15.0f/speed)
		{
			if(tasks[i].area == 1)
			{
				at += 5;
				tasks.erase(tasks.begin()+i);
			}
			else if(tasks[i].area == 2)
			{
				bt += 5;
				tasks.erase(tasks.begin()+i);
			}
			else if(tasks[i].area == 4)
			{
				overtime = true;
				overt.Reset();
				m2.OpenFromFile("sources/Music/OVERTIMEOVERTIME.ogg");
				m2.SetVolume(100);
				m2.Play();

				for(int x = 0;x<tasks.size();x++)
				{
					if(tasks[x].area==4)
					{
						tasks.erase(tasks.begin()+x);
						x--;
					}
				}
			}

			sfy.Play("error");
			break;
		}
	}
}
void Game::ComputeSpeed()
{
/// Berechne Speed
	speed = t.GetElapsedTime()/30.0f;

	if(speed<1.0f)
		speed = 1.0f;

///	Berechne Shoot Speed
	shootspeed = (20.0f)/(t.GetElapsedTime());

	if(shootspeed<2.0f)
		shootspeed = 2.0f;
}
void Game::ComputeOvertime()
{
	if(overtime)
	{
		dt = 0;
		if(overt.GetElapsedTime()>5.0f)
		{
			overtime = false;
			m2.SetVolume(0);
			m2.Stop();
		}
	}
}

void Game::DrawGame()
{
///	View setzen
	window->SetView(sf::View(sf::FloatRect(0,0,w,h)));

///	Zeichne Hintergrund
	DrawBackground();

///	Zeichne Part A
	DrawPartA();

///	Zeichne Part B
	DrawPartB();

///	Zeichne Part C
	DrawPartC();

///	Zeichne Part D
	DrawPartD();

///	Zeichne HUD
	DrawHUD();

///	Zeichne Foreground
	window->Draw(sf::Shape::Rectangle(0,0,w,h,sf::Color(255,255,255,ft)));

///	Aktualisiere Bild
	window->Display();
}
void Game::DrawBackground()
{
	sf::Shape sp1;
	sp1.AddPoint(0,0,    sf::Color( 83,253,244),sf::Color(0,0,0));
	sp1.AddPoint(w/2,0,  sf::Color( 83,253,244),sf::Color(0,0,0));
	sp1.AddPoint(w/2,h/2,sf::Color(000,000,255),sf::Color(0,0,0));
	sp1.AddPoint(0,h/2,  sf::Color(000,000,255),sf::Color(0,0,0));
	sp1.SetPosition(0,0);
	window->Draw(sp1);

	sf::Shape sp2;
	sp2.AddPoint(0,0,    sf::Color(242,253,168),sf::Color(0,0,0));
	sp2.AddPoint(w/2,0,  sf::Color(242,253,168),sf::Color(0,0,0));
	sp2.AddPoint(w/2,h/2,sf::Color(000,255,000),sf::Color(0,0,0));
	sp2.AddPoint(0,h/2,  sf::Color(000,255,000),sf::Color(0,0,0));
	sp2.SetPosition(w/2,0);
	window->Draw(sp2);

	sf::Shape sp3;
	sp3.AddPoint(0,0,    sf::Color(253,168,168),sf::Color(0,0,0));
	sp3.AddPoint(w/2,0,  sf::Color(253,168,168),sf::Color(0,0,0));
	sp3.AddPoint(w/2,h/2,sf::Color(255,000,000),sf::Color(0,0,0));
	sp3.AddPoint(0,h/2,  sf::Color(255,000,000),sf::Color(0,0,0));
	sp3.SetPosition(w/2,h/2);
	window->Draw(sp3);

	sf::Shape sp4;
	sp4.AddPoint(0,0,    sf::Color(255,255,200),sf::Color(0,0,0));
	sp4.AddPoint(w/2,0,  sf::Color(255,255,200),sf::Color(0,0,0));
	sp4.AddPoint(w/2,h/2,sf::Color(255,255,000),sf::Color(0,0,0));
	sp4.AddPoint(0,h/2,  sf::Color(255,255,000),sf::Color(0,0,0));
	sp4.SetPosition(0,h/2);
	window->Draw(sp4);
}
void Game::DrawPartA()
{
///	Zeichne Wolken
	s.SetFont(sf::Font::GetDefaultFont());
	s.SetSize(20);
	s.SetColor(sf::Color::Cyan);
	for(int i = 0;i<tasks.size();i--)
	{
		if(tasks[i].area==1)
		{
			float p = tasks[i].t.GetElapsedTime();

			cloud.SetPosition((w/2.0f)/6.0f*(tasks[i].position),(h/2.0f)/(15.0f/speed)*(p));
			window->Draw(cloud);

			s.SetText(tasks[i].label);
			s.SetPosition((w/2.0f)/6.0f*(tasks[i].position)-s.GetRect().GetWidth()/2,(h/2.0f)/(15.0f/speed)*(p)-s.GetRect().GetHeight()/2);
			window->Draw(s);
		}
	}

///	Zeichne Titel
	s.SetFont(f);
	s.SetSize(30);
	s.SetColor(sf::Color::Black);
	s.SetText("Aufgabenbereich 1");
	s.SetPosition(10,10);
	window->Draw(s);

///	Zeichne Balken
	window->Draw(sf::Shape::Rectangle(0,h/2-10,570.0f/100.0f*at,h/2,sf::Color::White,1,sf::Color::Black));

///	Zeichne Vordergrund
	if(!as)
		window->Draw(sf::Shape::Rectangle(0,0,w/2,h/2,sf::Color(200,200,200,200)));
}
void Game::DrawPartB()
{
///	Zeichne F-Keys-Linien
	for(int i = 0;i<6;i++)
	{
		window->Draw(sf::Shape::Line(w/2,(h/2.0f)/6.0f*i,w,(h/2.0f)/6.0f*i,2,sf::Color(100,100,100)));
	}

///	Zeichne F-Keys
	s.SetFont(sf::Font::GetDefaultFont());
	s.SetSize(20);
	s.SetColor(sf::Color::White);
	for(int i = 0;i<tasks.size();i++)
	{
		if(tasks[i].area==2)
		{
			float p = tasks[i].t.GetElapsedTime();

			window->Draw(sf::Shape::Circle(w/2+(w/2.0f)/(15.0f/speed)*(p),(h/2.0f)/6.0f*tasks[i].position,30,sf::Color::Red));

			s.SetText(tasks[i].label);
			s.SetPosition(w/2-s.GetRect().GetWidth()/2+(w/2.0f)/(15.0f/speed)*(p),(h/2.0f)/6.0f*tasks[i].position-s.GetRect().GetHeight()/2);
			window->Draw(s);
		}
	}

///	Zeichne Titel
	s.SetFont(f);
	s.SetSize(30);
	s.SetColor(sf::Color::Black);
	s.SetText("Aufgabenbereich 2");
	s.SetPosition(w-10-s.GetRect().GetWidth(),10);
	window->Draw(s);

///	Zeichne Balken
	window->Draw(sf::Shape::Rectangle(w/2,h/2-10,w/2+150+570.0f/100.0f*bt,h/2,sf::Color::White,1,sf::Color::Black));

///	Zeichne Vordergrund
	if(!bs)
		window->Draw(sf::Shape::Rectangle(w/2,0,w,h/2,sf::Color(200,200,200,200)));
}
void Game::DrawPartC()
{
///	Zeichne Titel
	s.SetFont(f);
	s.SetSize(30);
	s.SetColor(sf::Color::Black);
	s.SetText("Aufgabenbereich 3");
	s.SetPosition(w-10-s.GetRect().GetWidth(),h-10-s.GetRect().GetHeight());
	window->Draw(s);

///	Zeichne Text
	s.SetFont(sf::Font::GetDefaultFont());
	s.SetSize(30+10.0f*fabs(sin(t.GetElapsedTime())));
	s.SetColor(sf::Color::Blue);
	s.SetText("Suche den Cheat");
	s.SetPosition(w-w/4-s.GetRect().GetWidth()/2,h-h/4-s.GetRect().GetHeight()/2);
	window->Draw(s);

///	Zeichne Balken
	window->Draw(sf::Shape::Rectangle(w/2,h/2,w/2+150+570.0f/100.0f*ct,h/2+10,sf::Color::White,1,sf::Color::Black));

///	Zeichne Vordergrund
	if(!cs)
		window->Draw(sf::Shape::Rectangle(w/2,h/2,w,h,sf::Color(200,200,200,200)));
}
void Game::DrawPartD()
{
///	Zeichne Kasten
	int g = 0;
	s.SetFont(sf::Font::GetDefaultFont());
	s.SetColor(sf::Color::Black);
	s.SetSize(20);
	for(int i = 0;i<tasks.size();i++)
	{
		if(tasks[i].area==4)
		{
			float p = tasks[i].t.GetElapsedTime();

			window->Draw(sf::Shape::Rectangle((w/2.0f)/11.0f*g,h-h/4,(w/2.0f)/11.0f*g+(w/2.0f)/11.0f-5.0f,h-h/4+(w/2.0f)/11.0f-5.0f,sf::Color(100,100,100,(255.0f)/(15.0f/speed)*(p))));
			s.SetText(tasks[i].label);
			s.SetPosition((w/2.0f)/11.0f*g,h-h/4);
			window->Draw(s);

			g++;
		}
	}

///	Zeichne Titel
	s.SetFont(f);
	s.SetSize(30);
	s.SetColor(sf::Color::Black);
	s.SetText("Aufgabenbereich 4");
	s.SetPosition(10,h-10-s.GetRect().GetHeight());
	window->Draw(s);

///	Zeichne Balken
	window->Draw(sf::Shape::Rectangle(0,h/2,570.0f/100.0f*dt,h/2+10,sf::Color::White,1,sf::Color::Black));

///	Zeichne Vordergrund
	if(!ds)
		window->Draw(sf::Shape::Rectangle(0,h/2,w/2,h,sf::Color(200,200,200,200)));
}

void Game::DrawHUD()
{
	DrawAxis();

	if(overtime)
		DrawOvertime();

	if(texts.size()>0)
		DrawIntroTexts();
	else
		DrawTime();

///	Zeichne Andreas
	if(cheat&&cheat_s!=0.0f)
	{
		andi.SetScale(cheat_s+fabs(sin(t.GetElapsedTime())*0.2f),cheat_s+fabs(sin(t.GetElapsedTime())*0.2f));
		andi.SetPosition(w/2,h/2);
		window->Draw(andi);
	}
}
void Game::DrawTime()
{
///	Zeichne Holz
	window->Draw(wood);

///	Zeichne Rahmen
	window->Draw(sf::Shape::Rectangle(w/2-150,h/2-75,w/2+150,h/2+75,sf::Color(0,0,0,0),3,sf::Color(200,200,200)));

///	Zeichne Zeit
	s.SetFont(f);
	s.SetText(toStringTime(t.GetElapsedTime()/60));
	s.SetColor(sf::Color::Red);
	s.SetSize(70);
	s.SetPosition(w/2-s.GetRect().GetWidth()/2,h/2-s.GetRect().GetHeight()/2);
	window->Draw(s);
}
void Game::DrawAxis()
{
	window->Draw(sf::Shape::Rectangle(0,h/2-2,w,h/2+2,sf::Color::Black));
	window->Draw(sf::Shape::Rectangle(w/2-2,0,w/2+2,h,sf::Color::Black));

	window->Draw(sf::Shape::Rectangle(0,h/2-1,w,h/2+1,sf::Color::White));
	window->Draw(sf::Shape::Rectangle(w/2-1,0,w/2+1,h,sf::Color::White));
}
void Game::DrawOvertime()
{
	heavy.SetScale(fabs(sin(overt.GetElapsedTime())),fabs(sin(overt.GetElapsedTime())));

	heavy.SetPosition(w/4,h/4);
	window->Draw(heavy);

	heavy.SetPosition(w-w/4,h/4);
	window->Draw(heavy);

	heavy.SetPosition(w-w/4,h-h/4);
	window->Draw(heavy);

	heavy.SetPosition(w/4,h-h/4);
	window->Draw(heavy);
}
void Game::DrawIntroTexts()
{
///	Zeichne Kasten
	if(texts.size()>0)
	{
		window->Draw(sf::Shape::Rectangle(w/5,h/5,w-w/5,h-h/5,sf::Color(0,0,255),2,sf::Color::White));
	}

///	Zeichne Texte
	s.SetFont(sf::Font::GetDefaultFont());
	s.SetColor(sf::Color::Cyan);
	s.SetSize(20);
	for(int i = 0;i<tye;i++)
	{
		s.SetText(texts[i]);
		s.SetPosition(w/5+10,h/5+10+20*i);
		window->Draw(s);

		if(i<tys)
			window->Draw(sf::Shape::Rectangle(w/5+10,h/5+10+20*i,w/5+10+s.GetRect().GetWidth(),h/5+10+20*i+s.GetRect().GetHeight(),sf::Color::Blue));
	}
	s.SetPosition(w/5+10,h/5+10+20*tye);
	s.SetText(texts[tye].substr(0,txe));
	window->Draw(s);

	s.SetText(texts[tys].substr(0,txs));
	window->Draw(sf::Shape::Rectangle(w/5+10,h/5+10+20*tys,w/5+10+s.GetRect().GetWidth(),h/5+10+20*tys+s.GetRect().GetHeight(),sf::Color::Blue));
}

void Game::Cheat()
{
///	Texte hinzuf�gen
	texts.push_back("Du hast den Cheat entdeckt!!!");
	texts.push_back("Du kriegst eine Super Zeit zugeschrieben!");
	texts.push_back("");
	texts.push_back("Aber leider hast du Andreas sauer gemacht...");
	texts.push_back("- Sehr sauer!");
	texts.push_back("");
	texts.push_back("Ah.. Da kommt er ja!");

///	Parameter setzen
	txs = 0;
	tys = 0;
	txe = 0;
	tye = 0;

///	Text Intro
	for(int i = 0;i<texts.size();i++)
	{
		tye = i;
		for(int a = 0;a<texts[i].size();a++)
		{
			txe = a;
			DrawGame();
			sf::Event Event;while (window->GetEvent(Event)){}
		}
	}

///	Pausieren
	sf::Clock c;
	while(c.GetElapsedTime()<3.0f)
	{
		DrawGame();
		sf::Event Event;while (window->GetEvent(Event)){}
	}

///	Text Outro
	for(int i = 0;i<texts.size();i++)
	{
		tys = i;
		for(int a = 0;a<texts[i].size();a++)
		{
			txs = a;
			DrawGame();
			sf::Event Event;while (window->GetEvent(Event)){}
		}
	}
	texts.clear();

///	Andreas
	m->SetVolume(0);
	m2.OpenFromFile("sources/Music/Andreas.ogg");
	m2.SetLoop(false);
	m2.SetVolume(100);
	m2.Play();

/// Wartet ab
	cheat_s = 2.76;
	sf::Clock cl;
	while(cl.GetElapsedTime()<44)
	{
		DrawGame();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
}

///	Konstruktor
Game::Game(Achievements* ach,StatisticsManager* smg)
: achi(ach),sm(smg),sfy(SoundFactory()),ft(255),
  overtime(false),loose(false),cheat(false),cheat_s(0.0f)
{
	Init();
}
