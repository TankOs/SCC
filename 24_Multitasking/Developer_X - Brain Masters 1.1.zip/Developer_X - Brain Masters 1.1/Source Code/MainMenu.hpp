#ifndef MAINMENU_HPP_INCLUDED
#define MAINMENU_HPP_INCLUDED

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <string>

#include "Game.hpp"
#include "SoundFactory.hpp"
#include "Achievements.hpp"
#include "AchievementGUI.hpp"
#include "StatisticsManager.hpp"
#include "StatisticsGUI.hpp"

class MainMenu
{
public :
///	Attribute
	sf::RenderWindow* window;
	sf::Clock t;
	sf::Sprite symbol;
	sf::Image  m;
	sf::Font   f;
	sf::String s;
	sf::Music* mus;

	Achievements* a;
	SoundFactory sfy;
	StatisticsManager* sm;

	bool running;
	int w;
	int h;
	int o;
	float ft;

///	Funktionen
	void Init();
	void LoadData();
	void Intro();
	void Outro();

	void StartGame();
	void AchiGUI();
	void StatGUI();

	void StartMusic();
	void QuitMusic ();

	void Run();
	void CheckEvents();
	void DrawMenu();
	void DrawBackground();
	void DrawSymbols();
	void DrawOptions();
	void DrawOption(std::string n,std::string txt,int x,int y,bool b);
	void DrawForeground();

///	Konstruktor
	MainMenu(sf::Music* mu,Achievements* a,StatisticsManager* m);
};

#endif // MAINMENU_HPP_INCLUDED
