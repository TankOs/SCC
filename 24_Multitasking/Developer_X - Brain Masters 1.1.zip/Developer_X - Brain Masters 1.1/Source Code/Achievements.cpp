/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "Achievements.hpp"
#include <iostream>
using namespace std;

///	Funktionen
void Achievements::Init()
{
	LoadData();
	ComputeFree();
}
void Achievements::LoadData()
{
	LoadMemory();
	LoadAchievements();
}
void Achievements::LoadMemory()
{
///	Lade Memory
	string line;
	ifstream f ("sources/Achievements/Memory.txt");

	getline (f,line);
	mem.started = atoi(line.c_str());

	getline (f,line);
	mem.achi = (bool)(atoi(line.c_str()));

	getline (f,line);
	mem.stat = (bool)(atoi(line.c_str()));

	getline (f,line);
	mem.chea = (bool)(atoi(line.c_str()));

	getline (f,line);
	mem.time = atoi(line.c_str());

	getline (f,line);
	mem.pltime = atoi(line.c_str());

	getline (f,line);
	mem.all  = (bool)(atoi(line.c_str()));

	f.close();
}
void Achievements::LoadAchievements()
{
///	Lade Daten Abschnitt 1
	string line;
	ifstream f ("sources/Achievements/Data.txt");
	while (f.good())
	{
		getline (f,line);

		vector<string> data = tokenize(line,'|');
		Achievement a;
		a.title = data[0];
		a.limit = atoi(data[1].c_str());
		achievements.push_back(a);
	}
	f.close();

///	Lade Daten Abschnitt 2
	for(int i = 0;i<achievements.size();i++)
	{
		achievements[i].LoadImage("sources/Plaketten/"+achievements[i].title+".png");
	}

///	Lade Daten Abschnitt 3
	for(int i = 0;i<achievements.size();i++)
	{
		string path = "sources/Achievements/";
		path += achievements[i].title;
		path += ".txt";

		ifstream ft (path.c_str());
		while (ft.good())
		{
			getline (ft,line);
			achievements[i].AddText(line);
		}
		ft.close();
	}
}
void Achievements::ComputeFree()
{
///	Spieler
	if(mem.started>=achievements[0].limit)
		achievements[0].Free();
	else
		achievements[0].UnFree();
	if(mem.started>=achievements[1].limit)
		achievements[1].Free();
	else
		achievements[1].UnFree();
	if(mem.started>=achievements[2].limit)
		achievements[2].Free();
	else
		achievements[2].UnFree();

/// Sammler
	if(mem.achi==true)
		achievements[3].Free();
	else
		achievements[3].UnFree();

///	Statistiker
	if(mem.stat==true)
		achievements[4].Free();
	else
		achievements[4].UnFree();

///	Cheater
	if(mem.chea==true)
		achievements[5].Free();
	else
		achievements[5].UnFree();

/// Zeitschinder
	if(mem.time>=achievements[6].limit)
		achievements[6].Free();
	else
		achievements[6].UnFree();
	if(mem.time>=achievements[7].limit)
		achievements[7].Free();
	else
		achievements[7].UnFree();
	if(mem.time>=achievements[8].limit)
		achievements[8].Free();
	else
		achievements[8].UnFree();

/// R�nge
	if(mem.pltime>=achievements[9].limit)
		achievements[9].Free();
	else
		achievements[9].UnFree();
	if(mem.pltime>=achievements[10].limit)
		achievements[10].Free();
	else
		achievements[10].UnFree();
	if(mem.pltime>=achievements[11].limit)
		achievements[11].Free();
	else
		achievements[11].UnFree();
	if(mem.pltime>=achievements[12].limit)
		achievements[12].Free();
	else
		achievements[12].UnFree();
	if(mem.pltime>=achievements[13].limit)
		achievements[13].Free();
	else
		achievements[13].UnFree();
	if(mem.pltime>=achievements[14].limit)
		achievements[14].Free();
	else
		achievements[14].UnFree();
	if(mem.pltime>=achievements[15].limit)
		achievements[15].Free();
	else
		achievements[15].UnFree();
	if(mem.pltime>=achievements[16].limit)
		achievements[16].Free();
	else
		achievements[16].UnFree();

/// Super Spieler
	bool b = true;
	for(int i = 0;i<achievements.size()-1;i++)
	{
		if(!achievements[i].free)
		{
			b = false;
			break;
		}
	}

	if(b)
		achievements[17].Free();
	else
		achievements[17].UnFree();
}
void Achievements::SaveMemory()
{
	if(save)
	{
		ofstream f ("sources/Achievements/Memory.txt");

		f << toString(mem.started)     << endl;
		f << toString((int)(mem.achi)) << endl;
		f << toString((int)(mem.stat)) << endl;
		f << toString((int)(mem.chea)) << endl;
		f << toString(mem.time)        << endl;
		f << toString(mem.pltime)      << endl;
		f << toString(mem.all)         << endl;

		f.close();
	}
}

void Achievements::Start()
{
	mem.started++;
	ComputeFree();
}
void Achievements::Achi ()
{
	mem.achi = true;
	ComputeFree();
}
void Achievements::Stat ()
{
	mem.stat = true;
	ComputeFree();
}
void Achievements::Cheat()
{
	mem.chea = true;
	ComputeFree();
}
void Achievements::AddTime(int t)
{
	mem.time+=t;
	ComputeFree();
}
void Achievements::PlTime (int t)
{
	if(t>mem.pltime)
		mem.pltime = t;
	ComputeFree();
}

void Achievements::Reset()
{
	mem.started = 0;
	mem.achi    = false;
	mem.stat    = false;
	mem.chea    = false;
	mem.time    = 0;
	mem.pltime  = 0;
	mem.all     = false;
	SaveMemory();
	save = false;

	ComputeFree();
}

///	Konstruktor
Achievements::Achievements()
{
	save = true;
}
