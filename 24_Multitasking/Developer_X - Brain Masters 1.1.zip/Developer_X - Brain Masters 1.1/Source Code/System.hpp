#ifndef SYSTEM_HPP_INCLUDED
#define SYSTEM_HPP_INCLUDED

#include <string>
#include <vector>
#include <sstream>

///	String Angabe
std::string toStringTime(double h);
std::string toString    (int i);
std::string toString    (long i);
std::string toString    (float i);
std::string toString    (double i);

std::vector<std::string> tokenize(std::string toTokenize, char tokenizer);

#endif // SYSTEM_HPP_INCLUDED
