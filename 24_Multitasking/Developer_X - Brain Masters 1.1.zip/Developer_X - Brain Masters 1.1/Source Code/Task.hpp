#ifndef TASK_HPP_INCLUDED
#define TASK_HPP_INCLUDED

#include <SFML/System.hpp>
#include <string>
#include <vector>

class Task
{
public :
///	Attribute
	int code;
	int area;
	int position;
	std::string label;
	sf::Clock t;

///	Funktionen
	void GenerateCode();
	void GenerateLabel();

	int GetCode();
	int GetArea();
	int GetProgress();
	std::string GetLabel();

///	Konstruktor
	Task(int a);
};

#endif // TASK_HPP_INCLUDED
