#ifndef GAME_HPP_INCLUDED
#define GAME_HPP_INCLUDED

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>

#include "StatisticsManager.hpp"
#include "Achievements.hpp"
#include "SoundFactory.hpp"
#include "System.hpp"
#include "Task.hpp"

#include <vector>
#include <string>

class Game
{
public :
///	Strukturen
	struct Key
	{
		int code;
		int area;
	};

///	Attribute
	sf::RenderWindow*  window;
	sf::Clock  t;
	sf::Music* m;
	sf::Music  m2;
	sf::Font   f;
	sf::String s;

	StatisticsManager* sm;
	Achievements*      achi;
	SoundFactory sfy;

	bool running;
	bool overtime;
	bool loose;
	bool cheat;
	float ft;
	float cheat_s;
	int w;
	int h;

	sf::Clock overt;

///	Game
	bool as;
	bool bs;
	bool cs;
	bool ds;
	bool fa;
	bool fb;
	bool fc;
	bool fd;
	float at;
	float bt;
	float ct;
	float dt;
	sf::Clock ac;
	sf::Clock bc;
	sf::Clock cc;
	sf::Clock dc;
	sf::Clock sa;
	sf::Clock sb;
	sf::Clock sc;
	sf::Clock sd;

	float speed;
	float shootspeed;
	std::vector<Task> tasks;

///	Images
	sf::Image  woodi;
	sf::Sprite wood;

	sf::Image  cloudi;
	sf::Sprite cloud;

	sf::Image  heavyi;
	sf::Sprite heavy;

	sf::Image  andreas;
	sf::Sprite andi;

///	Intro
	std::vector<std::string> texts;
	int txs;
	int tys;
	int txe;
	int tye;

///	Funktionen
	void Init();
	void LoadData();
	void Intro();
	void Outro();
	void StartMusic();
	void QuitMusic();

	void Run();

	void CheckEvents();

	void ComputeGame();
	void ComputeA();
	void ComputeB();
	void ComputeC();
	void ComputeD();
	void CheckTime();
	void CheckAreas();
	void ComputeTasks();
	void ComputeSpeed();
	void ComputeOvertime();

	void DrawGame();
	void DrawBackground();
	void DrawPartA();
	void DrawPartB();
	void DrawPartC();
	void DrawPartD();
	void DrawHUD();
	void DrawTime();
	void DrawAxis();
	void DrawOvertime();
	void DrawIntroTexts();

	void Cheat();

///	Konstruktor
	Game(Achievements* ach,StatisticsManager* smg);
};

#endif // GAME_HPP_INCLUDED
