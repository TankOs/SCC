/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "Task.hpp"

using namespace std;

///	Funktionen
void Task::GenerateCode()
{
	if(area==1)
	{
		code = sf::Randomizer::Random(97,122);
	}
	else if(area==2)
	{
		code = sf::Randomizer::Random(305,316);
	}
	else if(area==4)
	{
		code = sf::Randomizer::Random(48,57);
	}

	position = sf::Randomizer::Random(1,4);
}
void Task::GenerateLabel()
{
	vector<string> chars;
	chars.push_back("A");
	chars.push_back("B");
	chars.push_back("C");
	chars.push_back("D");
	chars.push_back("E");
	chars.push_back("F");
	chars.push_back("G");
	chars.push_back("H");
	chars.push_back("I");
	chars.push_back("J");
	chars.push_back("K");
	chars.push_back("L");
	chars.push_back("M");
	chars.push_back("N");
	chars.push_back("O");
	chars.push_back("P");
	chars.push_back("Q");
	chars.push_back("R");
	chars.push_back("S");
	chars.push_back("T");
	chars.push_back("U");
	chars.push_back("V");
	chars.push_back("W");
	chars.push_back("X");
	chars.push_back("Y");
	chars.push_back("Z");

	vector<string> fkeys;
	fkeys.push_back("F01");
	fkeys.push_back("F02");
	fkeys.push_back("F03");
	fkeys.push_back("F04");
	fkeys.push_back("F05");
	fkeys.push_back("F06");
	fkeys.push_back("F07");
	fkeys.push_back("F08");
	fkeys.push_back("F09");
	fkeys.push_back("F10");
	fkeys.push_back("F11");
	fkeys.push_back("F12");

	vector<string> numbrs;
	numbrs.push_back("0");
	numbrs.push_back("1");
	numbrs.push_back("2");
	numbrs.push_back("3");
	numbrs.push_back("4");
	numbrs.push_back("5");
	numbrs.push_back("6");
	numbrs.push_back("7");
	numbrs.push_back("8");
	numbrs.push_back("9");

	if(area==1)
	{
		int a = code-97;
		label = chars[a];
	}
	else if(area==2)
	{
		int a = code-305;
		label = fkeys[a];
	}
	else if(area==4)
	{
		int a = code-48;
		label = numbrs[a];
	}
}

int Task::GetCode()
{
	return code;
}
int Task::GetArea()
{
	return area;
}
int Task::GetProgress()
{
	return t.GetElapsedTime();
}
std::string Task::GetLabel()
{
	return label;
}

///	Konstruktor
Task::Task(int a) : area(a)
{
	GenerateCode();
	GenerateLabel();
}
