/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "StatisticsGUI.hpp"
#include <iostream>
using namespace std;

///	Funktionen
void StatisticsGUI::Init()
{
///	Window erstellen
	sf::WindowSettings Settings;
	Settings.DepthBits         = 24; /// Depth Buffer
	Settings.StencilBits       = 8;  /// Stencil Buffer
	Settings.AntialiasingLevel = 5;  /// Antialising

	window = new sf::RenderWindow(sf::VideoMode::GetDesktopMode(), "Brain Game by Kevin Riehl C 2011", sf::Style::Fullscreen, Settings);
	window->SetActive(true);
	window->SetFramerateLimit(50);
	window->ShowMouseCursor(false);

/// Gr��en bestimmen
	w = 1440;
	h = 900;

///	Lade Daten
	LoadData();
}
void StatisticsGUI::LoadData()
{
///	Lade Music
	m = new sf::Music();
	m->OpenFromFile("sources/Music/Techno.ogg");
	m->SetVolume(0);
	m->SetLoop(true);
	m->Play();

///	Lade Font
	f.LoadFromFile("sources/Fonts/Neutronium.ttf");
}

void StatisticsGUI::Intro()
{
///	Parameter setzen
	start = 0;
	end   = 0;
	ft    = 255.0f;

///	Hintergrund aufhellen
	for(int i = 90;i>0;i--)
	{
		ft = sin(i*0.018f)*255.0f;
		DrawGUI();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
	ft = 0.0f;

///	End erweitern
	for(int i = 0;i<sm->values.size()+1;i++)
	{
		end = i;
		DrawGUI();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
	end = sm->values.size();
}
void StatisticsGUI::Outro()
{
///	start erweitern
	for(int i = 0;i<sm->values.size();i++)
	{
		start = i;
		DrawGUI();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
	start = sm->values.size()-1;

///	Hintergrund verdunkeln
	for(int i = 0;i<90;i++)
	{
		ft = sin(i*0.018f)*255.0f;
		DrawGUI();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
	ft = 255.0f;
}
void StatisticsGUI::StartMusic()
{
	sf::Clock c;
	while(c.GetElapsedTime()<1.0f)
	{
		m->SetVolume(c.GetElapsedTime()*100);
		DrawGUI();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
}
void StatisticsGUI::QuitMusic ()
{
	sf::Clock c;
	while(c.GetElapsedTime()<1.0f)
	{
		m->SetVolume(100-c.GetElapsedTime()*100);
		DrawGUI();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
}

void StatisticsGUI::Run()
{
	running = true;

	Intro();
	StartMusic();

	while(running)
	{
		CheckEvents();
		DrawGUI();
	}

	Outro();
	QuitMusic();

	delete window;
}
void StatisticsGUI::CheckEvents()
{
	sf::Event Event;
	while (window->GetEvent(Event))
	{
		if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::Escape))
		{
			running = false;
		}
		if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::R))
		{
			sm->Reset();
		}
	}
}
void StatisticsGUI::DrawGUI()
{
///	View setzen
	window->SetView(sf::View(sf::FloatRect(0,0,w,h)));

///	Zeichne Hintergrund
	DrawBackground();

///	Zeichne Statistiken
	DrawStatistics();

///	Zeichne Daten
	DrawData();

///	Zeichne Infos
	DrawInfo();

///	Zeichne Foreground
	window->Draw(sf::Shape::Rectangle(0,0,w,h,sf::Color(255,255,255,ft)));

///	Aktualisiere Bild
	window->Display();
}
void StatisticsGUI::DrawBackground()
{
	sf::Shape sp;
	sp.AddPoint(0,0,sf::Color(0,0,0),sf::Color(0,0,0));
	sp.AddPoint(w,0,sf::Color(0,0,0),sf::Color(0,0,0));
	sp.AddPoint(w,h,sf::Color(0,50,0)  ,sf::Color(0,0,0));
	sp.AddPoint(0,h,sf::Color(0,50,0)  ,sf::Color(0,0,0));

	window->Draw(sp);
}
void StatisticsGUI::DrawStatistics()
{
	if(sm->values.size()<2)
	{
		s.SetFont(sf::Font::GetDefaultFont());
		s.SetSize(50);
		s.SetColor(sf::Color::Green);

		s.SetText("Statistiken noch nicht darstellbar");
		s.SetPosition(w/2-s.GetRect().GetWidth()/2,h/2-50);
		window->Draw(s);

		s.SetText("Besuche die Statistiken an einem anderen Zeitpunkt!");
		s.SetPosition(w/2-s.GetRect().GetWidth()/2,h/2+50);
		window->Draw(s);
	}
	else if(abs(start-end)>2)
	{
		float x_step = (1300.0f)/(sm->values.size());
		float y_step = (850.0f) /(sm->max_value);

		for(int i = start;i<end-1;i++)
		{
			window->Draw(sf::Shape::Line
			(70+x_step*i,
			 h-25-(y_step*(sm->values[i])),
			 70+x_step*(i+1),
			 h-25-(y_step*(sm->values[i+1])),
			 2,
			 sf::Color::Green));
		}
		window->Draw(sf::Shape::Line(0,h-25-(y_step*(sm->quotient)),w,h-25-(y_step*(sm->quotient)),2,sf::Color::Green));
	}
}
void StatisticsGUI::DrawData()
{
	s.SetFont(sf::Font::GetDefaultFont());
	s.SetSize(50);
	s.SetColor(sf::Color(100,150,100));

///	Zeichne Durchschnitt
	s.SetText("Durschnitt : " + toString(sm->quotient));
	s.SetPosition(w-s.GetRect().GetWidth()-50,80);
	window->Draw(s);

///	Zeichne H�chsten Wert
	s.SetText("Max. Wert  : " + toString(sm->max_value));
	s.SetPosition(w-s.GetRect().GetWidth()-50,130);
	window->Draw(s);
}
void StatisticsGUI::DrawInfo()
{
///	Titel / �berschrift
	s.SetFont(f);
	s.SetSize(100);
	s.SetColor(sf::Color::Green);
	s.SetText("Statistiken");
	s.SetPosition(w/2-s.GetRect().GetWidth()/2,20);
	window->Draw(s);

///	Escape Info
	s.SetSize(40);
	s.SetColor(sf::Color::Green);
	s.SetText("Zum Verlassen ESC dr�cken");
	s.SetPosition(w-s.GetRect().GetWidth()-40,h-40);
	window->Draw(s);

///	Reset Info
	s.SetSize(40);
	s.SetColor(sf::Color::Green);
	s.SetText("Zum Resetten R dr�cken");
	s.SetPosition(+40,h-40);
	window->Draw(s);
}

///	Konstruktor
StatisticsGUI::StatisticsGUI(StatisticsManager* m,Achievements* ac) : sm(m)
{
	Init();
	ac->Stat();
}
