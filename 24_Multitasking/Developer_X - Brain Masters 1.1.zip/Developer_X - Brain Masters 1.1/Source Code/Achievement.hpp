#ifndef ACHIEVEMENT_H_INCLUDED
#define ACHIEVEMENT_H_INCLUDED

#include <SFML/Graphics.hpp>
#include <string>
#include <vector>

class Achievement
{
public :
///	Attribute
	std::string title;
	std::vector<std::string> texts;
	sf::Image  m;
	sf::Sprite s;
	bool free;
	int  limit;
	float t;

///	Funktionen
	void SetTitle (std::string s);
	void AddText  (std::string s);
	void LoadImage(std::string s);
	void SetLimit (int z);
	void Free     ();
	void UnFree   ();

///	Konstruktor
	Achievement();
};

#endif // ACHIEVEMENT_H_INCLUDED
