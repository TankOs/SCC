#ifndef STATISTICSMANAGER_HPP_INCLUDED
#define STATISTICSMANAGER_HPP_INCLUDED

#include "System.hpp"

#include <cstdlib>
#include <vector>
#include <string>
#include <fstream>

class StatisticsManager
{
public :
///	Attribute
	std::vector<float> values;
	float max_value;
	float quotient;

///	Funktionen
	void LoadData();
	void SaveData();
	void AddResult(float t);
	void Reset();

///	Konstruktor
	StatisticsManager();
};

#endif // STATISTICSMANAGER_HPP_INCLUDED
