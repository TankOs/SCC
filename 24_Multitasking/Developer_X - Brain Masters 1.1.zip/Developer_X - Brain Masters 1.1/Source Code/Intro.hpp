#ifndef INTRO_HPP_INCLUDED
#define INTRO_HPP_INCLUDED

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

#include <vector>
#include <string>

class Intro
{
public :
///	Attribute
	sf::RenderWindow* window;
	sf::Sprite gear;
	sf::Image  g_im;
	std::vector<sf::Vector2f> gearpos;

	sf::Sprite sfml1;
	sf::Sprite sfml2;
	sf::Image  sfim1;
	sf::Image  sfim2;

	sf::Font   f;
	sf::String s;
	sf::Clock  t;
	sf::Clock  t2;

	int w;
	int h;

///	Animation
	float ht1;
	float ht2;
	float ct;
	float bt;

///	Funktionen
	void Init();
	void LoadData();

	void Run();
	void Compute();
	void Draw();
	void DrawBackground();
	void DrawSymbols();

///	Konstruktor
	Intro(sf::RenderWindow* w);
};

#endif // INTRO_HPP_INCLUDED
