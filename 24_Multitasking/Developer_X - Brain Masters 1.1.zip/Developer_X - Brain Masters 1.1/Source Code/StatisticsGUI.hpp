#ifndef STATISTICSGUI_HPP_INCLUDED
#define STATISTICSGUI_HPP_INCLUDED

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "System.hpp"
#include "StatisticsManager.hpp"
#include "Achievements.hpp"

class StatisticsGUI
{
public :
///	Attribute
	sf::RenderWindow*  window;
	sf::Clock  t;
	sf::Music* m;
	sf::Font   f;
	sf::String s;
	StatisticsManager* sm;

	bool running;
	float ft;
	int start;
	int end;
	int w;
	int h;

///	Funktionen
	void Init();
	void LoadData();

	void Intro();
	void Outro();
	void StartMusic();
	void QuitMusic ();

	void Run();
	void CheckEvents();
	void DrawGUI();
	void DrawBackground();
	void DrawStatistics();
	void DrawData();
	void DrawInfo();

///	Konstruktor
	StatisticsGUI(StatisticsManager* m,Achievements* a);
};

#endif // STATISTICSGUI_HPP_INCLUDED
