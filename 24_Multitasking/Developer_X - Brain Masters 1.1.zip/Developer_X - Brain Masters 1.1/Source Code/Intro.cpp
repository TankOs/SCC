/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "Intro.hpp"

using namespace std;

///	Funktionen
void Intro::Init()
{
///	Lade Daten
	LoadData();
}
void Intro::LoadData()
{
///	Lade Font
	f.LoadFromFile("sources/Fonts/Neutronium.ttf");
	s.SetFont(f);

///	Lade Zahnrad
	g_im.LoadFromFile("sources/Sprites/Gear.png");
	gear.SetImage(g_im);
	gear.SetCenter(g_im.GetWidth()/2,g_im.GetHeight()/2);
	gear.Resize(100,100);

///	Lade SFML Logos
	sfim1.LoadFromFile("sources/Images/SFML_Wheel.png");
	sfim2.LoadFromFile("sources/Images/SFML_Logo.png");
	sfml1.SetImage(sfim1);
	sfml2.SetImage(sfim2);
	sfml1.SetCenter(sfim1.GetWidth()/2,sfim1.GetHeight()/2);
	sfml2.SetCenter(sfim2.GetWidth()/2,sfim2.GetHeight()/2);

///	Gear Positionen
	int width  = w;
	int height = h;

	int d = 60;
	int ox = width-width/4;
	int oy = height/2;

	gearpos.push_back(sf::Vector2f(ox,oy));

	gearpos.push_back(sf::Vector2f(ox-d*1,oy-d*1));
	gearpos.push_back(sf::Vector2f(ox-d*2,oy-d*2));

	gearpos.push_back(sf::Vector2f(ox+d*1,oy-d*1));
	gearpos.push_back(sf::Vector2f(ox+d*2,oy-d*2));

	gearpos.push_back(sf::Vector2f(ox-d*1,oy+d*1));
	gearpos.push_back(sf::Vector2f(ox-d*2,oy+d*2));

	gearpos.push_back(sf::Vector2f(ox+d*1,oy+d*1));
	gearpos.push_back(sf::Vector2f(ox+d*2,oy+d*2));
}

void Intro::Run()
{
	for(int i = 90;i>0;i--)
	{
		bt = sin(i*0.018f)*255.0f;

		Compute();
		Draw();
	}
	bt = 0;
	for(int i = 0;i<90;i++)
	{
		ht1 = sin(i*0.018f)*255.0f;

		Compute();
		Draw();
	}
	ht1 = 255;
	for(int i = 0;i<90;i++)
	{
		ht2 = sin(i*0.018f)*255.0f;

		Compute();
		Draw();
	}
	ht2 = 255;
	for(int i = 0;i<90;i++)
	{
		ct = sin(i*0.018f)*255.0f;

		Compute();
		Draw();
	}
	ct = 255;
	t2.Reset();

	while(t2.GetElapsedTime()<1.0f)
	{
		Compute();
		Draw();
	}

	for(int i = 90;i>0;i--)
	{
		ct = sin(i*0.018f)*255.0f;

		Compute();
		Draw();
	}
	ct = 0;
	t2.Reset();
	for(int i = 90;i>0;i--)
	{
		ht2 = sin(i*0.018f)*255.0f;

		Compute();
		Draw();
	}
	ht2 = 0;
	for(int i = 90;i>0;i--)
	{
		ht1 = sin(i*0.018f)*255.0f;

		Compute();
		Draw();
	}
	ht1 = 0;
	for(int i = 0;i<90;i++)
	{
		bt = sin(i*0.018f)*255.0f;

		Compute();
		Draw();
	}
	bt = 255;
}
void Intro::Compute()
{
///	Simuliere Benutzereingabenverrechnung
	sf::Event Event;while(window->GetEvent(Event)){;}
}
void Intro::Draw()
{
///	View setzen
	window->SetView(sf::View(sf::FloatRect(0,0,w,h)));

///	Zeichne den Hintergrund
	DrawBackground();

///	Zeichne Zahnr�der
	DrawSymbols();

///	Zeichne Vorhang
	window->Draw(sf::Shape::Rectangle(0,0,w,h,sf::Color(255,255,255,bt)));

///	Aktualisiere Bildschirm
	window->Display();
}
void Intro::DrawBackground()
{
	sf::Shape sp;
	sp.AddPoint(0,0,sf::Color(100,100,200),sf::Color(0,0,0));
	sp.AddPoint(w,0,sf::Color(100,100,200),sf::Color(0,0,0));
	sp.AddPoint(w,h,sf::Color(10,10,255)  ,sf::Color(0,0,0));
	sp.AddPoint(0,h,sf::Color(10,10,255)  ,sf::Color(0,0,0));

	window->Draw(sp);
}
void Intro::DrawSymbols()
{
///	Zeichne X_Games Logo
	gear.SetColor(sf::Color(255,255,255,ht1));
	for(int i = 0;i<gearpos.size();i++)
	{
		if(i%2==0)
			gear.SetRotation(t.GetElapsedTime()*90);
		else
			gear.SetRotation(t.GetElapsedTime()*-90+20);
		gear.SetPosition(gearpos[i].x,gearpos[i].y);
		window->Draw(gear);
	}

	s.SetSize(50);
	s.SetText("X-Games");
	s.SetColor(sf::Color(0,255,255,ht1));
	s.SetPosition(w-w/4-s.GetRect().GetWidth()/2,h/2-s.GetRect().GetHeight()/2);
	window->Draw(s);

	s.SetSize(30);
	s.SetText("in Cooperation with");
	s.SetColor(sf::Color(0,255,255,ct));
	s.SetPosition(w/2-s.GetRect().GetWidth()/2,h/2-s.GetRect().GetHeight()/2);
	window->Draw(s);

///	Zeichne SFML Logo
	sfml1.SetPosition(w/4,h/2);
	sfml2.SetPosition(w/4,h/2);

	sfml1.SetColor(sf::Color(255,255,255,ht2));
	sfml2.SetColor(sf::Color(255,255,255,ht2));

	sfml1.SetRotation(t.GetElapsedTime()*20);
	window->Draw(sfml1);
	window->Draw(sfml2);

///	Zeichne Copyrights
	s.SetSize(20);
	s.SetText("by Kevin Riehl alias Developer_X - C 2011 - all rights reserved by Kevin Riehl");
	s.SetColor(sf::Color(255,255,255,ct));
	s.SetPosition(w/2-s.GetRect().GetWidth()/2,h-s.GetRect().GetHeight()*2);
	window->Draw(s);
}

///	Konstruktor
Intro::Intro(sf::RenderWindow* w) :
window(w),ht1(0),ht2(0),ct(0),bt(255),w(1440),h(900)
{
///	Initialisiere Daten
	Init();

///	Starte Animation
	Run();
}
