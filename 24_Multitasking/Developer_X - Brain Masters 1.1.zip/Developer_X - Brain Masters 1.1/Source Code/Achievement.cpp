/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "Achievement.hpp"
using namespace std;

///	Funktionen
void Achievement::SetTitle (std::string s)
{
	title = "";
	title = s;
}
void Achievement::AddText  (std::string s)
{
	texts.push_back(s);
}
void Achievement::LoadImage(std::string ss)
{
	m.LoadFromFile(ss);
	s.SetImage(m);
}
void Achievement::SetLimit (int z)
{
	limit = z;
}
void Achievement::Free     ()
{
	free = true;
}
void Achievement::UnFree   ()
{
	free = false;
}

///	Konstruktor
Achievement::Achievement() : t(0)
{
	title = "";
	texts.clear();
	limit = 0;
	free  = false;
}
