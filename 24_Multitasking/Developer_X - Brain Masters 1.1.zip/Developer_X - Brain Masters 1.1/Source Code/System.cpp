/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "System.hpp"

///	String Angabe
std::string toStringTime(double hx)
{
	double ho = hx;

	int i = 0;
	for(i = 0;i<ho;i++);
		i--;

	int h = i;
	int m = (ho-h)*60.0;
	int s = (ho-h-m/60.0)*3600.0;

	while(s>=60)
	{
		m++;
		s-=60;
	}
	while(m>=60)
	{
		h++;
		m-=60;
	}

	std::stringstream ss;
	if(h>9)
		ss << h << ":";
	else
		ss << "0" << h << ":";

	if(m>9)
		ss << m << ":";
	else
		ss << "0" << m << ":";

	if(s>9)
		ss << s;
	else
		ss << "0" << s;

	return ss.str();
}
std::string toString    (int i)
{
	std::stringstream ss;
	ss << i;
	return ss.str();
}
std::string toString    (long i)
{
	std::stringstream ss;
	ss << i;
	return ss.str();
}
std::string toString    (float i)
{
	std::stringstream ss;
	ss << i;
	return ss.str();
}
std::string toString    (double i)
{
	std::stringstream ss;
	ss << i;
	return ss.str();
}

std::vector<std::string> tokenize(std::string toTokenize, char tokenizer)
{
	std::vector<std::string> tokens;

	std::string temp;
	for(int i = 0;i<toTokenize.size();i++)
	{
		if(toTokenize.c_str()[i]!=tokenizer)
			temp += toTokenize.c_str()[i];
		else
		{
			tokens.push_back(temp);
			temp = "";
		}
	}
	if(temp!="")
		tokens.push_back(temp);

	return tokens;
}
