/*
*	All the Code is written by Kevin Riehl alias Developer_X
*	Copyright 2011
*/

#include "AchievementGUI.hpp"
#include <iostream>
using namespace std;

///	Funktionen
void AchievementGUI::Init()
{
	LoadData();
}
void AchievementGUI::LoadData()
{
///	Window erstellen
	sf::WindowSettings Settings;
	Settings.DepthBits         = 24; /// Depth Buffer
	Settings.StencilBits       = 8;  /// Stencil Buffer
	Settings.AntialiasingLevel = 5;  /// Antialising

	window = new sf::RenderWindow(sf::VideoMode::GetDesktopMode(), "Brain Game by Kevin Riehl C 2011", sf::Style::Fullscreen, Settings);
	window->SetActive(true);
	window->SetFramerateLimit(50);
	window->ShowMouseCursor(false);

/// Gr��en bestimmen
	w = 1800;
	h = 1110;

///	Font laden
	f.LoadFromFile("sources/Fonts/Neutronium.ttf");
	s.SetFont(f);

///	Hintergrund laden
	b.LoadFromFile("sources/Images/Spirale.jpg");
	back.SetImage(b);
	back.Resize(w,w);
	back.Scale(1.6216f,1.6216f);
	back.SetCenter(w/2,w/2);

///	Fragezeichen laden
	m2.LoadFromFile("sources/Plaketten/Plakette.png");
	q.SetImage(m2);
	q.Resize(200,200);

///	Music laden
	m = new sf::Music();
	m->OpenFromFile("sources/Music/Achievements.ogg");
	m->SetLoop(true);
	m->SetVolume(0);
	m->Play();

///	Positionen bestimmen
	positions.push_back(sf::Vector2f(10,150));
	positions.push_back(sf::Vector2f(10,470));
	positions.push_back(sf::Vector2f(10,790));

	positions.push_back(sf::Vector2f(300,150));
	positions.push_back(sf::Vector2f(300,470));
	positions.push_back(sf::Vector2f(300,790));

	positions.push_back(sf::Vector2f(590,150));
	positions.push_back(sf::Vector2f(590,470));
	positions.push_back(sf::Vector2f(590,790));

	positions.push_back(sf::Vector2f(880,150));
	positions.push_back(sf::Vector2f(880,470));
	positions.push_back(sf::Vector2f(880,790));

	positions.push_back(sf::Vector2f(1170,150));
	positions.push_back(sf::Vector2f(1170,470));
	positions.push_back(sf::Vector2f(1170,790));

	positions.push_back(sf::Vector2f(1460,150));
	positions.push_back(sf::Vector2f(1460,470));
	positions.push_back(sf::Vector2f(1460,790));
}
void AchievementGUI::Intro()
{
///	Hintergrund aufhellen
	for(int i = 90;i>0;i--)
	{
		ft = sin(i*0.018f)*255.0f;
		DrawGUI();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
	ft = 0.0f;

///	Achievements �ffnen
	sf::Clock t;
	for(int i = 0;i < (a->achievements.size());i++)
	{
		if(a->achievements[i].free)
			sfy.Play("medall");
		else
			sfy.Play("error");

		t.Reset();
		while(t.GetElapsedTime()<0.4f)
		{
			a->achievements[i].t = 255.0f/0.4f*t.GetElapsedTime();
			DrawGUI();
			sf::Event Event;while (window->GetEvent(Event)){}
		}
		a->achievements[i].t = 255.0f;
	}
}
void AchievementGUI::Outro()
{
///	Hintergrund verdunkeln
	for(int i = 0;i<90;i++)
	{
		ft = sin(i*0.018f)*255.0f;
		DrawGUI();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
	ft = 255.0f;
}

void AchievementGUI::StartMusic()
{
	sf::Clock c;
	while(c.GetElapsedTime()<1.0f)
	{
		m->SetVolume(c.GetElapsedTime()*100);
		DrawGUI();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
}
void AchievementGUI::QuitMusic ()
{
	sf::Clock c;
	while(c.GetElapsedTime()<1.0f)
	{
		m->SetVolume(100-c.GetElapsedTime()*100);
		DrawGUI();
		sf::Event Event;while (window->GetEvent(Event)){}
	}
}

void AchievementGUI::Run()
{
	running = true;

	StartMusic();
	Intro();
	a->Achi();
	while(running)
	{
		CheckEvents();
		DrawGUI();
	}
	Outro();
	QuitMusic();

	for(int i = 0;i<a->achievements.size();i++)
	{
		a->achievements[i].t = 0;
	}

	delete window;
}
void AchievementGUI::CheckEvents()
{
	sf::Event Event;
	while (window->GetEvent(Event))
	{
		if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::Escape))
		{
			running = false;
			sfy.Play("point");
		}
		if ((Event.Type == sf::Event::KeyPressed) && (Event.Key.Code == sf::Key::R))
		{
			a->Reset();
			sfy.Play("error");
		}
	}
}
void AchievementGUI::DrawGUI()
{
///	View setzen
	window->SetView(sf::View(sf::FloatRect(w/255.0f*ft,0,w,h)));

///	Sounds verrechnen
	sfy.Compute();

///	Zeichne Hintergrund
	DrawBackground();

///	Zeichne Hintergrund 2
	window->Draw(sf::Shape::Rectangle(0,0,w,h,sf::Color(0,0,255,100)));

///	Zeichen Achievements
	DrawAchievements();

///	Zeichne Info
	DrawInfo();

///	Zeichne Foreground
	window->Draw(sf::Shape::Rectangle(0,0,w,h,sf::Color(255,255,255,ft)));

/// Aktualisiere Bildschirm
	window->Display();
}
void AchievementGUI::DrawBackground()
{
	back.SetRotation(t.GetElapsedTime()*25.0f);
	back.SetPosition(w/2,h/2);
	window->Draw(back);
}
void AchievementGUI::DrawAchievements()
{
	for(int i = 0;i<a->achievements.size();i++)
	{
		int x = positions[i].x;
		int y = positions[i].y;

	/// Zeichne Titel
		s.SetFont(f);
		s.SetSize(30);
		s.SetColor(sf::Color(0,255,255,a->achievements[i].t));
		s.SetPosition(positions[i].x+20,positions[i].y-30);
		s.SetText(a->achievements[i].title);
		window->Draw(s);

	///	Zeichne Bild
		if(a->achievements[i].free)
		{
			a->achievements[i].s.SetPosition(x,y);
			a->achievements[i].s.SetColor(sf::Color(255,255,255,a->achievements[i].t));
			window->Draw(a->achievements[i].s);
		}
		else
		{
			q.SetPosition(x,y);
			q.SetColor(sf::Color(255,255,255,a->achievements[i].t));
			window->Draw(q);
		}

	///	Zeichne Text
		s.SetFont(sf::Font::GetDefaultFont());
		s.SetSize(20);
		s.SetColor(sf::Color(255,255,255,a->achievements[i].t));
		for(int z = 0;z<a->achievements[i].texts.size();z++)
		{
			s.SetText(a->achievements[i].texts[z]);
			s.SetPosition(positions[i].x+10,positions[i].y+210+z*20);
			window->Draw(s);
		}
	}
}
void AchievementGUI::DrawInfo()
{
///	Titel / �berschrift
	s.SetFont(f);
	s.SetSize(100);
	s.SetColor(sf::Color::Cyan);
	s.SetText("Achievements");
	s.SetPosition(w/2-s.GetRect().GetWidth()/2,20);
	window->Draw(s);

///	Escape Info
	s.SetSize(40);
	s.SetColor(sf::Color::Cyan);
	s.SetText("Zum Verlassen ESC dr�cken");
	s.SetPosition(w-s.GetRect().GetWidth()-40,h-40);
	window->Draw(s);

///	Reset Info
	s.SetSize(40);
	s.SetColor(sf::Color::Cyan);
	s.SetText("Zum Resetten R dr�cken");
	s.SetPosition(+40,h-40);
	window->Draw(s);
}

///	Konsturktor
AchievementGUI::AchievementGUI(Achievements* ach) : ft(255.0f),a(ach),sfy(SoundFactory())
{
	Init();
}
