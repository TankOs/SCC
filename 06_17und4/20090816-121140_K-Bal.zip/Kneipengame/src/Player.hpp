#pragma once

#include <vector>
#include "Card.hpp"

class Player
{
    public:
        Player();
        ~Player();

        bool RequestForHold();

        void PushCard(Card card);
        std::vector<Card>* GetCards();

        void SetIsCPU(bool isCPU);
        bool GetIsCPU();

        void SetIsPlaying(bool isPlaying);
        bool GetIsPlaying();

        int GetHandValue();

        void SetPoints(int points);
        void AddPoints(int points);
        int GetPoints() const;

        void SetMoney(int money);
        int GetMoney() const;

        void SetWins(int wins);
        int GetWins() const;

        void SetLosses(int losses);
        int GetLosses() const;


    private:
        std::vector<Card> myCards;
        bool myIsCPU;
        bool myIsPlaying;
        int myHandValue;
        int myPoints;
        int myMoney;
        int myWins;
        int myLosses;
};
