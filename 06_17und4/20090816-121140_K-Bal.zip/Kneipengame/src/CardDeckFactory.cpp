#include "CardDeckFactory.hpp"
#include "CardDeck.hpp"

CardDeckFactory::CardDeckFactory()
{

}
CardDeckFactory::~CardDeckFactory()
{

}

CardDeck CardDeckFactory::CreateCardDeck(bool isSmallDeck)
{
    CardDeck temp;

    for(int i = 0; i < 4; i++)
    {
        for(int j = 5; i < 13; i++)
        {
            temp.PushCard(Card((Card::Suit)i, (Card::CardType)j));
        }
    }

    if(!isSmallDeck)
    {
        for(int i = 0; i < 4; i++)
        {
            for(int j = 0; i < 5; i++)
            {
                temp.PushCard(Card((Card::Suit)i, (Card::CardType)j));
            }
        }
    }

    temp.ShuffleCards();

    return temp;
}
