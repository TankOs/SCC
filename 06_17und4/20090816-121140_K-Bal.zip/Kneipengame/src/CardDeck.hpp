#pragma once

#include <vector>
#include "Card.hpp"

class CardDeck
{
    public:
        CardDeck();
        ~CardDeck();

        void PushCard(Card card);
        Card DrawCard();
        std::vector<Card>* GetCards();

        void ShuffleCards();

    private:
        std::vector<Card> myCards;
};
