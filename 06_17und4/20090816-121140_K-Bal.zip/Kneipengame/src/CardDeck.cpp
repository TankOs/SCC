#include <algorithm>
#include "CardDeck.hpp"


CardDeck::CardDeck()
{

}
CardDeck::~CardDeck()
{

}

void CardDeck::PushCard(Card card)
{
    myCards.push_back(card);
}
Card CardDeck::DrawCard()
{
    Card temp = myCards.back();
    myCards.pop_back();
    return temp;
}
std::vector<Card>* CardDeck::GetCards()
{
    return &myCards;
}

void CardDeck::ShuffleCards()
{
    std::random_shuffle(myCards.begin(), myCards.end());
}
