#pragma once

#include "Player.hpp"
#include "CardDeck.hpp"

class CardGame
{
    public:
        CardGame();
        ~CardGame();

        void SetCardDeck(const CardDeck& deck);
        CardDeck& GetCardDeck();

        void DrawCards();

        void PlayerLoses(int nr);

        int GetWinner();

        bool GetIsRunning();

    private:
        CardDeck myCardDeck;
        bool myIsHold;
        bool myFirstTime;
        Player myPlayer1;
        Player myPlayer2;

};
