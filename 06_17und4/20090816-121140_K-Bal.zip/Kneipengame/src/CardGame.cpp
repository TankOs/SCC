#include <iostream>
#include "CardGame.hpp"

CardGame::CardGame()
: myIsHold(false), myFirstTime(true)
{
    myPlayer1.SetIsCPU(false);
    myPlayer2.SetIsCPU(true);
}
CardGame::~CardGame()
{

}


void CardGame::SetCardDeck(const CardDeck& deck)
{
    myCardDeck = deck;
}
CardDeck& CardGame::GetCardDeck()
{
    return myCardDeck;
}

void CardGame::DrawCards()
{
    if(myFirstTime)
    {
        myPlayer1.PushCard(myCardDeck.DrawCard());
        myPlayer2.PushCard(myCardDeck.DrawCard());
        myPlayer1.PushCard(myCardDeck.DrawCard());
        myPlayer2.PushCard(myCardDeck.DrawCard());
        myFirstTime = false;
    }
    if(!myIsHold)
    {
        if(myPlayer1.RequestForHold())
        {
            myIsHold = true;
        }
        if(myPlayer1.GetIsPlaying())
        {
            myPlayer1.PushCard(myCardDeck.DrawCard());
            if(myPlayer1.GetHandValue() > 21)
            {
                myIsHold = true;
            }
        }
        if(myPlayer2.RequestForHold())
        {
            myIsHold = true;
        }
        if(myPlayer2.GetIsPlaying())
        {
            myPlayer2.PushCard(myCardDeck.DrawCard());
            if(myPlayer2.GetHandValue() > 21)
            {
                myIsHold = true;
            }
        }
    }
}

int CardGame::GetWinner()
{
    std::cout << std::endl << "Ihr habt " << myPlayer1.GetHandValue()
    << " Punkte, euer Gegenueber hat " << myPlayer2.GetHandValue() << "." << std::endl << std::endl;

    if(myPlayer1.GetHandValue() > 21 && myPlayer2.GetHandValue() > 21)
    {
        std::cout << "Remis!" << std::endl;
        return -1;
    }
    if(myPlayer1.GetHandValue() > 21)
    {
        std::cout << "Der fremde Mann gewinnt!" << std::endl;
        return 2;
    }
    if(myPlayer2.GetHandValue() > 21)
    {
        std::cout << "Ihr gewinnt!" << std::endl;
        return 1;
    }
    if(myPlayer1.GetHandValue() > myPlayer2.GetHandValue())
    {
        std::cout << "Ihr gewinnt!" << std::endl;
        return 1;
    }
    else if(myPlayer1.GetHandValue() < myPlayer2.GetHandValue())
    {
        std::cout << "Der fremde Mann gewinnt!" << std::endl;
        return 2;
    }
    else
    {
        std::cout << "Remis!" << std::endl;
        return -1;
    }
}

bool CardGame::GetIsRunning()
{
    return !myIsHold;
}
