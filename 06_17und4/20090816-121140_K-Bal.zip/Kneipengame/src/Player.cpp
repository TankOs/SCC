#include <iostream>
#include <stdlib.h>
#include "Player.hpp"

Player::Player()
: myIsCPU(true), myIsPlaying(true)
{

}
Player::~Player()
{

}

bool Player::RequestForHold()
{
    if(!myIsCPU)
    {
        std::cout << "Ihr habt " << GetHandValue() << " Punkte, Blatt offenlegen? (j/n): ";

        char temp;
        std::cin >> temp;

        std::cout << std::endl;

        if(temp < 107)
        {
            SetIsPlaying(false);
            return true;
        }
        return false;
    }
    else
    {
        int die = rand() % 21 +1;
        if(die < GetHandValue())
        {
            std::cout << "Euer Gegenueber legt sein Blatt offen." << std::endl << std::endl;
            SetIsPlaying(false);
            return true;
        }
        std::cout << "Euer Gegenueber entschliesst sich dazu,\neine weitere Karte zu nehmen." << std::endl << std::endl;
        return false;
    }
}

void Player::PushCard(Card card)
{
    myCards.push_back(card);
}
std::vector<Card>* Player::GetCards()
{
    return &myCards;
}

void Player::SetIsCPU(bool isCPU)
{
    myIsCPU = isCPU;
}
bool Player::GetIsCPU()
{
    return myIsCPU;
}

void Player::SetIsPlaying(bool isPlaying)
{
    myIsPlaying = isPlaying;
}
bool Player::GetIsPlaying()
{
    return myIsPlaying;
}

int Player::GetHandValue()
{
    int temp = 0;

    for(std::vector<Card>::iterator it = myCards.begin(); it != myCards.end(); it++)
    {
        temp += it->GetValue();
    }

    return temp;
}

void Player::SetPoints(int points)
{
    myPoints = points;
}
void Player::AddPoints(int points)
{
    myPoints += points;
}
int Player::GetPoints() const
{
    return myPoints;
}

void Player::SetMoney(int money)
{
    myMoney = money;
}
int Player::GetMoney() const
{
    return myMoney;
}

void Player::SetWins(int wins)
{
    myWins = wins;
}
int Player::GetWins() const
{
    return myWins;
}

void Player::SetLosses(int losses)
{
    myLosses = losses;
}
int Player::GetLosses() const
{
    return myLosses;
}
