#pragma once

class Card
{
    public:

        enum Suit
        {
            e_Diamonds = 0,
            e_Hearts,
            e_Clubs,
            e_Spades
        };

        enum CardType
        {
            e_2 = 0,
            e_3,
            e_4,
            e_5,
            e_6,
            e_7,
            e_8,
            e_9,
            e_10,
            e_Knave,
            e_Queen,
            e_King,
            e_Ace
        };


        Card(Suit suit, CardType cardtype);
        ~Card();

        Suit GetSuit() const;
        CardType GetCardType() const;

        int GetValue();

    private:
        Suit mySuit;
        CardType myCardType;
};
