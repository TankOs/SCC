#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "CardGame.hpp"
#include "CardDeckFactory.hpp"

int main()
{
    srand(time(0));

    std::cout << "Ihr betretet die marode Kneipe und\nsetzt euch an einen alten Eichentisch.\n"
    "Nachdem ihr bei der attraktiven Tochter des\nWirtes ein Bier bestellt habt, faellt euch auf, dass\n"
    "ein merkwuerdig dreinblickender Mannn euch beobachtet.\n\nEr erhebt sich und kommt auf euch zu.\n\n"
    "Mit rauchiger Stimme und merklich angestrengt spricht er euch an:" << std::endl <<
    "\"Ihr scheint mir ein spielfreudiger Gesell zu sein,\nwie waere es mit einer "
    "Partie 17 und 4?\"" << std::endl<<std::endl;

    std::cout <<
    "Ihr willigt ein und winkt der Bedienung zu,\n"
    "sie solle ein Kartenspiel herbeiholen." <<std::endl<<std::endl;

    std::cout <<
    "Jeder zieht zwei Karten..."
    <<std::endl;



    CardGame myGame;
    CardDeckFactory myFac;

    myGame.SetCardDeck(myFac.CreateCardDeck(false));

    // TODO spiel wiederholen

    while(myGame.GetIsRunning())
    {
        myGame.DrawCards();
    }
    int winner = myGame.GetWinner();

    switch(winner)
    {
        case 1:
        {
            std::cout << std::endl <<
            "Der fremde Mann macht sich eingeschnappt auf den Heimweg\n"
            "und die Bedienung bringt euch euer letztes Bier.\n"
            "Ihr koennt das Gefuehl nicht los werden, dass\n"
            "sich ihr Dekollete in den letzten Stunden vergroessert hat.\n"
            "Von eurem Charme in Bann gezogen, gibt sie euch Gelegenheit,\n"
            "es auf ihrem Zimmer herauszufinden.\n";
            break;
        }
        default:
        {
            std::cout << std::endl <<
            "Waehrend die Wirtstochter im Laufe des Abends immer\n"
            "schoener wird, stellt ihr fest, dass man von\n"
            "euch das Gegenteil behaupten koennte.\n"
            "Schliesslich zieht ihr taumelnd von dannen.\n";
            break;
        }
    }



    return 0;
}
