#pragma once

class CardDeck;

class CardDeckFactory
{
    public:
        CardDeckFactory();
        ~CardDeckFactory();

        CardDeck CreateCardDeck(bool isSmallDeck = false);
};
