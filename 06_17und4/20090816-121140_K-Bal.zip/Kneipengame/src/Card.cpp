#include "Card.hpp"

Card::Card(Suit suit, CardType cardtype)
: mySuit(suit), myCardType(cardtype)
{

}
Card::~Card()
{

}

Card::Suit Card::GetSuit() const
{
    return mySuit;
}
Card::CardType Card::GetCardType() const
{
    return myCardType;
}


int Card::GetValue()
{
    if(myCardType <= 8)
    {
        return myCardType+2;
    }
    else if(myCardType <= 11)
    {
        return 10;
    }
    return 11;
}
