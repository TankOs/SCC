#include "Global.h"

STATUS Status;
bool IGewonnen;
float Konto;
float Einsatz;
bool SpielVorbei;
sf::Clock Spiel;
bool Patt;