#include "Karten.h"
#include "Button.h"

sf::Image iHintergrund;
sf::String Gewonnen;
sf::String KontoStand;
sf::String Portemonnaie;
sf::String Aktion;
sf::Clock tAktion;
sf::Clock tZigarretten, Bier;
sf::String Passt;
bool Zigarretten;
bool Pleite;

std::string ConvertToEUR(float Betrag) {
	std::ostringstream os;
	if(Betrag < 1.0f && Betrag > -1.0f) {
		os << Betrag*100;
		return(os.str() + " ct");
	}
	else {
		os << Betrag;
		std::string str = os.str();
		if(str.find(".") != -1) {
			str.replace(str.find("."), 1, ",");
			if(str.substr(str.size()-3, str.size()-1).find(",") != -1) {
				if(str.at(str.size()-1) != '0' && str.at(str.size()-2) == ',') {
					str.append("0");
				}
			}
		}
		else {
			str.append(",-");
		}
		return(str + " EUR");
	}
}

void GrafikLaden() {
	KarteHinten.LoadFromFile("Grafik/KarteHinten.png");
	Kartensatz.LoadFromFile("Grafik/Kartensatz.png");
	iHintergrund.LoadFromFile("Grafik/Hintergrund.png");
}

void newAction(std::string akt) {
	akt.insert(0, static_cast<std::string>(Aktion.GetText()) + "\n");
	Aktion.SetText(akt);
}

void NeuesSpiel(Kartenblatt* Blatt, int EinsatzNiveau) {
	Einsatz = std::min(0.5f, (static_cast<float>(static_cast<int>(Konto*1/(1+EinsatzNiveau)*100)))/100);
	Konto -= Einsatz;
	newAction("Neues Spiel gestartet. Einsatz: " + ConvertToEUR(Einsatz));
	SetStatus(PLAYER1);
	for(int i = 0; i < 3; i++) {
		Blatt->EineGeben();
	}
}

int main() {
	GrafikLaden();
	Kartenblatt Blatt(sf::Vector2f(13, 280-KarteHinten.GetHeight()/2*0.7));
	sf::RenderWindow RW(sf::VideoMode(800, 600), "17 und 4", sf::Style::Close);
	RW.UseVerticalSync(true);
	sf::Event EV;

	SpielVorbei = true;
	Konto = 10;

	Button Setzen1("Riskanter Einsatz", sf::Vector2f(15, 270), sf::Vector2f(275, 330));
	Button Setzen2("Hoher Einsatz", sf::Vector2f(290, 270), sf::Vector2f(520, 330));
	Button Setzen3("Normaler Einsatz", sf::Vector2f(535, 270), sf::Vector2f(785, 330));
	Button Passen("Passen", sf::Vector2f(1, Blatt.StapelPos.y + KarteHinten.GetHeight()*0.7 + 15), sf::Vector2f(Blatt.StapelPos.x + KarteHinten.GetWidth()*0.7 + 15, Blatt.StapelPos.y + KarteHinten.GetHeight()*0.7 + 75));
	Portemonnaie.SetText("Portemonnaie:");
	Passt.SetText("Compi passt");
	Passt.SetColor(sf::Color(0,0,200));
	Passt.SetPosition(400 - Passt.GetRect().GetWidth()/2, 10 + KarteHinten.GetHeight()*0.7);
	Portemonnaie.SetSize(15);
	Aktion.SetSize(20);
	Gewonnen.SetSize(100);
	sf::Sprite sHintergrund(iHintergrund);

	newAction("Sie treffen sich mit Ihrem Freund Compi in einer Kneipe,\n          um dort gegeneinander 17 und 4 zu spielen.");

	while(GetStatus() != ENDE) {
		RW.Draw(sHintergrund);
		while(RW.GetEvent(EV)) {
			if(EV.Type == sf::Event::Closed) {
				RW.Close();
				SetStatus(ENDE);
			}
			if(EV.Type == sf::Event::MouseButtonPressed) {
				if(GetStatus() == PLAYER1) {
					if(Passen.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						Blatt.IchPasse = true;
					}
					if(!Blatt.IchPasse && EV.MouseButton.X >= Blatt.StapelPos.x - 3 && EV.MouseButton.X <= Blatt.StapelPos.x + KarteHinten.GetWidth() * 0.7 + 3 &&
						EV.MouseButton.Y >= Blatt.StapelPos.y - 3 && EV.MouseButton.Y <= Blatt.StapelPos.y + KarteHinten.GetHeight() * 0.7 + 3) {
							Blatt.EineGeben();
					}
				}
				if(GetStatus() == SETZEN) {
					if(Setzen1.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						NeuesSpiel(&Blatt, 1);
					}
					if(Setzen2.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						NeuesSpiel(&Blatt, 2);
					}
					if(Setzen3.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						NeuesSpiel(&Blatt, 3);
					}
				}
			}
		}
		if(Blatt.IchPasse && GetStatus() == PLAYER1) {
			SetStatus(PLAYER2);
		}
		if(Bier.GetElapsedTime() > 45 + sf::Randomizer::Random(-5, 5)) {
			newAction("Sie bestellen sich ein neues Bier (80 ct)");
			Bier.Reset();
			Konto -= 0.8;
			if(sf::Randomizer::Random(0, 15) == 0) {
				float f = 0;
				switch(sf::Randomizer::Random(0, 7)) {
					case 0:
						f=0.01;
						break;
					case 1:
						f=0.02;
						break;
					case 2:
						f=0.05;
						break;
					case 3:
						f = 0.1;
						break;
					case 4:
						f = 0.2;
						break;
					case 5:
						f = 0.5;
						break;
					case 6:
						f = 1;
						break;
					case 7:
						f = 2;
						break;
				}
				newAction("Sie haben auf dem Weg zum Tresen Geld gefunden. (" + ConvertToEUR(f) + ")");
				Konto += f;
			}
		}
		if(!Zigarretten && tZigarretten.GetElapsedTime() > 100 + sf::Randomizer::Random(-5, 5)) {
			newAction("Ihre Schachtel Zigarretten ist aufge(b)raucht.\n    Gefangen in Ihrer Sucht kaufen Sie sich eine neue f�r 3 EUR");
			Zigarretten = true;
			Konto -= 3;
			if(sf::Randomizer::Random(0, 15) == 0) {
				float f;
				switch(sf::Randomizer::Random(0, 7)) {
					case 0:
						f=0.01;
						break;
					case 1:
						f=0.02;
						break;
					case 2:
						f=0.05;
						break;
					case 3:
						f = 0.1;
						break;
					case 4:
						f = 0.2;
						break;
					case 5:
						f = 0.5;
						break;
					case 6:
						f = 1;
						break;
					case 7:
						f = 2;
						break;
				}
				newAction("Sie haben auf dem Weg zum Automaten Geld gefunden. (" + ConvertToEUR(f) + ")");
				Konto += f;
			}
		}
		if(sf::Randomizer::Random(0, 20000) == 0) {
			float f = sf::Randomizer::Random(0.5, Konto/2);
			f = static_cast<float>(static_cast<int>(f*100)) / 100;
			newAction("Ihnen fehlt Geld. Wei� der Himmel, wo es hin ist, aber es fehlen " + ConvertToEUR(f));
			Konto -= f;
		}

		if((GetStatus() == GEWINNER || GetStatus() == BEGINN) && SpielVorbei && Spiel.GetElapsedTime() > 3) {
			if(Pleite) {
				sf::Sleep(3);
				RW.Close();
				SetStatus(ENDE);
			}
			else {
				Blatt.Mischen();
				SetStatus(SETZEN);
			}
		}
		if(GetStatus() == PLAYER2) {
			Blatt.KI();
		}
		if((GetStatus() == PLAYER1 || GetStatus() == PLAYER2) && !SpielVorbei) {
			Blatt.Gewonnen();
		}
		if(tAktion.GetElapsedTime() >= 5) {
			std::string str = Aktion.GetText();
			if(str.size() > 0) {
				if(str.find("\n") != -1) {
					if(str.find("\n  ") != -1) {
						str.erase(0, str.find("\n  ")+1);
					}
					if(str.find("\n") != -1) {
						str.erase(0, str.find("\n")+1);
					}
					else {
						str.erase(0, str.size());
					}
				}
				else {
					str.erase(0, str.size());
				}
			}
			Aktion.SetText(str);
			tAktion.Reset();
		}


		if(GetStatus() == PLAYER1 || GetStatus() == PLAYER2 || GetStatus() == GEWINNER) {
			for(std::tr1::unordered_set<Karte*>::reverse_iterator i = Blatt.Stapel.rbegin(); i != Blatt.Stapel.rend(); i++) {
				RW.Draw(**i);
			}
			for(std::set<Karte*>::iterator i = Blatt.Gegner.begin(); i != Blatt.Gegner.end(); i++) {
				RW.Draw(**i);
			}
			for(std::set<Karte*>::iterator i = Blatt.Ich.begin(); i != Blatt.Ich.end(); i++) {
				RW.Draw(**i);
			}
			if(GetStatus() == GEWINNER) {
				if(Konto > 0) {
					if(Patt) {
						Gewonnen.SetColor(sf::Color(10,200,10,200));
						Gewonnen.SetText("Patt!");
					}
					else {
						if(IGewonnen) {
							Gewonnen.SetColor(sf::Color(10,200,10,200));
							Gewonnen.SetText("Gewonnen!");
						}
						else  {
							Gewonnen.SetColor(sf::Color(200,10,10,200));
							Gewonnen.SetText("Verloren!");
						}
					}
				}
				else if(!Pleite) {
					Gewonnen.SetColor(sf::Color(200,10,10,200));
					Gewonnen.SetText("Sie sind Pleite!");
					Pleite = true;
				}
				Gewonnen.SetPosition(400-Gewonnen.GetRect().GetWidth()/2, 300-Gewonnen.GetRect().GetHeight()/2);
				RW.Draw(Gewonnen);
			}
		}
		if(GetStatus() == PLAYER1 || GetStatus() == PLAYER2) {
			RW.Draw(Passen.getBorder());
			RW.Draw(Passen.getText());
		}
		if(GetStatus() == SETZEN) {
			RW.Draw(Setzen1.getBorder());
			RW.Draw(Setzen1.getText());
			RW.Draw(Setzen2.getBorder());
			RW.Draw(Setzen2.getText());
			RW.Draw(Setzen3.getBorder());
			RW.Draw(Setzen3.getText());
			Portemonnaie.SetPosition(400 - Portemonnaie.GetRect().GetWidth()/2, 5);
		}
		else {
			if(Konto < 10 || (Konto - static_cast<int>(Konto) == 0 && Konto < 1000)) {
				Portemonnaie.SetPosition(777 - Portemonnaie.GetRect().GetWidth(), 270);
			}
			else if(Konto < 100 || Konto - static_cast<int>(Konto) == 0) {
				Portemonnaie.SetPosition(770 - Portemonnaie.GetRect().GetWidth(), 270);
			}
			else {
				Portemonnaie.SetPosition(762 - Portemonnaie.GetRect().GetWidth(), 270);
			}
		}
		if((GetStatus() == PLAYER1 || GetStatus() == PLAYER2) && Blatt.GegnerPasst) {
			RW.Draw(Passt);
		}
		
		RW.Draw(Portemonnaie);
		KontoStand.SetText(ConvertToEUR(Konto));
		KontoStand.SetPosition(Portemonnaie.GetPosition().x + (Portemonnaie.GetRect().GetWidth() - KontoStand.GetRect().GetWidth())/2, Portemonnaie.GetPosition().y + 20);
		Aktion.SetPosition(400-Aktion.GetRect().GetWidth()/2, 595-Aktion.GetRect().GetHeight());
		RW.Draw(Aktion);
		RW.Draw(KontoStand);
		RW.Display();
		RW.Clear();
	}
	return(0);
}