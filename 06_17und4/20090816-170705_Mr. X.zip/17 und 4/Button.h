#pragma once
#include "Global.h"

class Button {
private:
	sf::Shape Rand;
	sf::String Text;
public:
	const sf::Drawable& getBorder() const;
	const sf::Drawable& getText() const;
	bool IsClicked(const sf::Vector2i& MousePosition);
	void setText(const std::string sText);
	Button(const std::string sText, const sf::Vector2f& Pos1, const sf::Vector2f& Pos2);
};