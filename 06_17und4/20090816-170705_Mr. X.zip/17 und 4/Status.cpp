#include "Karten.h"

extern STATUS Status;

void SetStatus(STATUS status) {
	Status = status;
	switch(status) {
		case SETZEN:
			SpielVorbei = false;
			break;
		case GEWINNER:
			SpielVorbei = true;
			if(!Patt) {
				if(IGewonnen) {
					Konto += Einsatz*2;
				}
				else {
					Konto -= Einsatz;
				}
			}
			else {
				Konto += Einsatz;
			}
			Einsatz = 0;
			Spiel.Reset();
			break;
		default:
			break;
	}
}

STATUS GetStatus() {
	return(Status);
}