#pragma once
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include <set>
#include <sstream>
#include <unordered_set>

enum STATUS {BEGINN, SETZEN, PLAYER1, PLAYER2, GEWINNER, ENDE};

extern bool IGewonnen;
extern bool Patt;
extern float Konto;
extern float Einsatz;
extern bool SpielVorbei;
extern sf::Clock Spiel;

STATUS GetStatus();
void SetStatus(STATUS status);