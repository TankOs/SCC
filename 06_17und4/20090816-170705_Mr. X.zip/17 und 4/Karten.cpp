#include "Karten.h"

sf::Image Kartensatz;
sf::Image KarteHinten;

Karte::Karte() {
	SetImage(KarteHinten);
	SetScale(0.7f, 0.7f);
}
void Karte::Extract(FARBEN farbe, ZAHLEN zahl) {
	Farbe = farbe;
	Zahl = zahl;
	switch (Zahl) {
		case DAUS:
			Wert = 11;
			break;
		case UNTER:
			Wert = 10;
			break;
		case OBER:
			Wert = 10;
			break;
		case K�NIG:
			Wert = 10;
			break;
		default:
			Wert = static_cast<int>(Zahl);
			break;
	}
	Img.Create(KarteHinten.GetWidth(), KarteHinten.GetHeight());
	Img.Copy(Kartensatz, 0, 0, sf::IntRect((Zahl-1)*KarteX, Farbe*KarteY, Zahl*KarteX, (Farbe+1)*KarteY), true);
}


Kartenblatt::Kartenblatt(sf::Vector2f Stapelpos) {
	StapelPos = Stapelpos;
	Load();
	Mischen();
}
void Kartenblatt::KI() {
	if(!GegnerPasst) {
		int a = 0;
		for(std::set<Karte*>::iterator i = Gegner.begin(); i != Gegner.end(); i++) {
			a += (*i)->Wert;
		}
		if(a <= 11) {
			EineGeben();
		}
		if(a > 11 && a < 20) {
			if(sf::Randomizer::Random(0,8) > 20-a) {
				EineGeben();
			}
			else {
				GegnerPasst = true;
				SetStatus(PLAYER1);
			}
		}
		if(a >= 20) {
			GegnerPasst = true;
			SetStatus(PLAYER1);
		}
	}
	else {
		SetStatus(PLAYER1);
	}
}
void Kartenblatt::Gewonnen() {
	int a = 0;
	for(std::set<Karte*>::iterator i = Gegner.begin(); i != Gegner.end(); i++) {
		a += (*i)->Wert;
	}
	int b = 0;
	for(std::set<Karte*>::iterator i = Ich.begin(); i != Ich.end(); i++) {
		b += (*i)->Wert;
	}
	if(a > 21) {
		if(!(a == 22 && Gegner.size() == 2)) {
			for(std::set<Karte*>::iterator i = Gegner.begin(); i != Gegner.end(); i++) {
				(*i)->SetImage((*i)->Img);
			}
			if((a == 22 && Gegner.size() == 2)) {
				Einsatz *= 2;
			}
			IGewonnen = true;
			SetStatus(GEWINNER);
		}
	}
	if(b > 21) {
		if(!(b == 22 && Ich.size() == 2)) {
			for(std::set<Karte*>::iterator i = Gegner.begin(); i != Gegner.end(); i++) {
				(*i)->SetImage((*i)->Img);
			}
			if(!(a == 22 && Gegner.size() == 2)) {
				Einsatz = 0;
			}
			IGewonnen = false;
			SetStatus(GEWINNER);
		}
	}
	if(GegnerPasst && IchPasse) {
		for(std::set<Karte*>::iterator i = Gegner.begin(); i != Gegner.end(); i++) {
			(*i)->SetImage((*i)->Img);
		}
		IGewonnen = (b > a);
		if(b == a) {
			Patt = true;
		}
		SetStatus(GEWINNER);
	}
}
void Kartenblatt::Load() {
	for(int i = 0; i < 4; i++) {
		for(int j = 0; j < 13; j++) {
			Karten[i][j].Extract(static_cast<FARBEN>(i), static_cast<ZAHLEN>(j+1));
		}
	}
}
void Kartenblatt::Mischen() {
	Patt = false;
	GegnerPasst = false;
	IchPasse = false;
	for(int i = 0; i < 4; i++) {
		for(int j = 0; j < 13; j++) {
			Karten[i][j].SetImage(KarteHinten);
		}
	}
	Gegner.erase(Gegner.begin(), Gegner.end());
	Ich.erase(Ich.begin(), Ich.end());
	if(Stapel.size() < 15) {
		Stapel.erase(Stapel.begin(), Stapel.end());
		while(Stapel.size() < 52) {
			bool b = false;
			while(!b) {
				int i = sf::Randomizer::Random(0,3);
				int j = sf::Randomizer::Random(0,12);
				if(Stapel.count(&Karten[i][j]) == 0) {
					Stapel.insert(&Karten[i][j]);
					Karten[i][j].SetRotation(sf::Randomizer::Random(-2.f, 2.f));
					Karten[i][j].SetPosition(StapelPos - sf::Vector2f(sf::Randomizer::Random(-2.f, 2.f), sf::Randomizer::Random(-5.f, 5.f)));
					b = true;
				}
			}
		}
	}
}
void Kartenblatt::EineGeben() {
	(*Stapel.begin())->SetPosition(0,0);
	if(GetStatus() == PLAYER1) {
		(*Stapel.begin())->SetImage((*Stapel.begin())->Img);
		Ich.insert(*Stapel.begin());
		int count = 0;
		for(std::set<Karte*>::iterator i = Ich.begin(); i != Ich.end(); i++) {
			switch(Ich.size()) {
				case 1:
					(*i)->SetPosition((3.5+count)*(KarteHinten.GetWidth()*0.7+10)+20, 575-KarteHinten.GetHeight()*0.7);
					break;
				case 2:
					(*i)->SetPosition((3+count)*(KarteHinten.GetWidth()*0.7+10)+20, 575-KarteHinten.GetHeight()*0.7);
					break;
				case 3:
					(*i)->SetPosition((2.5+count)*(KarteHinten.GetWidth()*0.7+10)+20, 575-KarteHinten.GetHeight()*0.7);
					break;
				case 4:
					(*i)->SetPosition((2+count)*(KarteHinten.GetWidth()*0.7+10)+20, 575-KarteHinten.GetHeight()*0.7);
					break;
				case 5:
					(*i)->SetPosition((1.5+count)*(KarteHinten.GetWidth()*0.7+10)+20, 575-KarteHinten.GetHeight()*0.7);
					break;
				case 6:
					(*i)->SetPosition((1+count)*(KarteHinten.GetWidth()*0.7+10)+20, 575-KarteHinten.GetHeight()*0.7);
					break;
				case 7:
					(*i)->SetPosition((0.5+count)*(KarteHinten.GetWidth()*0.7+10)+20, 575-KarteHinten.GetHeight()*0.7);
					break;
				case 8:
					(*i)->SetPosition((count)*(KarteHinten.GetWidth()*0.7+10)+20, 575-KarteHinten.GetHeight()*0.7);
					break;
				default:
					break;
			}
			count++;
		}
		SetStatus(PLAYER2);
	}
	else {
		Gegner.insert(*Stapel.begin());
		int count = 0;
		for(std::set<Karte*>::iterator i = Gegner.begin(); i != Gegner.end(); i++) {
			switch(Gegner.size()) {
				case 1:
					(*i)->SetPosition((3.5+count)*(KarteHinten.GetWidth()*0.7+10)+20, 5);
					break;
				case 2:
					(*i)->SetPosition((3+count)*(KarteHinten.GetWidth()*0.7+10)+20, 5);
					break;
				case 3:
					(*i)->SetPosition((2.5+count)*(KarteHinten.GetWidth()*0.7+10)+20, 5);
					break;
				case 4:
					(*i)->SetPosition((2+count)*(KarteHinten.GetWidth()*0.7+10)+20, 5);
					break;
				case 5:
					(*i)->SetPosition((1.5+count)*(KarteHinten.GetWidth()*0.7+10)+20, 5);
					break;
				case 6:
					(*i)->SetPosition((1+count)*(KarteHinten.GetWidth()*0.7+10)+20, 5);
					break;
				case 7:
					(*i)->SetPosition((0.5+count)*(KarteHinten.GetWidth()*0.7+10)+20, 5);
					break;
				case 8:
					(*i)->SetPosition((count)*(KarteHinten.GetWidth()*0.7+10)+20, 5);
					break;
				default:
					break;
			}
			count++;
		}
		SetStatus(PLAYER1);
	}
	Stapel.erase(*Stapel.begin());
}