#pragma once
#include "Global.h"

extern sf::Image Kartensatz;
extern sf::Image KarteHinten;

const int KarteX = 122;
const int KarteY = 202;

enum FARBEN {EICHEL, LAUB, HERZ, SCHELLE};
enum ZAHLEN {DAUS = 1, UNTER = 11, OBER = 12, K�NIG = 13};

class Karte : public sf::Sprite {
private:
public:
	sf::Image Img;
	FARBEN Farbe;
	ZAHLEN Zahl;
	int Wert;
	Karte();
	void Extract(FARBEN farbe, ZAHLEN zahl);
};

class Kartenblatt {
private:
public:
	bool GegnerPasst, IchPasse;
	Karte Karten[4][13];
	sf::Vector2f StapelPos;
	std::tr1::unordered_set<Karte*> Stapel;
	std::set<Karte*> Gegner;
	std::set<Karte*> Ich;
	Kartenblatt(sf::Vector2f Stapelpos);
	void KI();
	void Gewonnen();
	void Load();
	void Mischen();
	void EineGeben();
};