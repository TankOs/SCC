#######################################				16.08.2009
###   README zum Spiel "17 und 4"   ###
#######################################

LIZENZ:
Der Quellcode steht unter GPL3; Alle Grafiken unter "Creative Commons Attribution-Noncommercial-Share Alike-Lizenz" Version 3.0 (http://creativecommons.org/licenses/by-nc-sa/3.0/de/)
Die f�r die Vorderseiten der Karten als Basis verwendeten Grafiken stammen von Wikipedia (bzw. wikimedia.org) und wurden dort als "gemeinfrei" bezeichnet.

AUTOR:
Philipp Kloke
philipp.kloke@web.de