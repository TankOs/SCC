//alle_eimer.h
#ifndef ALLEMEINEEIMER_ALLESIMEIMER_H
#define ALLEMEINEEIMER_ALLESIMEIMER_H

// abstrakte Basisklasse
#include "eimer.h"
// Eimerklassen
#include "normaler_eimer.h"
#include "goldener_eimer.h"
#include "roter_eimer.h"

#endif // ALLEMEINEEIMER_ALLESIMEIMER_H