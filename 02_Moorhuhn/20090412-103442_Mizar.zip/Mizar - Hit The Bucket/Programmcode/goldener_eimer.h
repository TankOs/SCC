//goldener_eimer.h
//normaler_eimer.h
#ifndef GOLDENERPUNKTEEIMER_H
#define GOLDENERPUNKTEEIMER_H

#include "eimer.h"

class GoldenerEimer: public Eimer {
public:
	// Konstruktor
	GoldenerEimer(const sf::Image &eimer_bild, const unsigned int fenster_grenze_x, const unsigned int fenster_grenze_y):
	Eimer(eimer_bild,
		sf::Vector2f(0.f - eimer_bild.GetWidth(), sf::Randomizer::Random(0.1f, 0.3f) * fenster_grenze_y),
		  1.f, // Scale
		  0.f, // Rotation
		  50), // Punkte
	speed_x(125.f),
	speed_y(225.f)
	{
		// Initialisierungsliste setzt Eimer an den linken Fensterrand mit positivem X-Speed (= Bewegung nach rechts)
		// Wenn Zufallszahl == 1, setze Eimer an den rechten Fensterrand und kehre X-Speed um
		if(sf::Randomizer::Random(0, 1) == 1) {
			eimer_sprite.SetPosition(static_cast<float>(fenster_grenze_x), eimer_sprite.GetPosition().y);
			speed_x *= -1;
		}
	}
	// Bewegen
	virtual bool ausserhalb_fenster(const sf::RenderWindow &fenster);
	virtual void bewegen(const float frame_zeit);
private:
	float speed_x;
	float speed_y;
};

#endif // GOLDENERPUNKTEEIMER_H