//zeitlimit.cpp
#include "zeitlimit.h"
#include <sstream>
#include <iomanip>

void Zeitlimit::berechne_restzeit()
{
	if(restsekunden - zeit_timer.GetElapsedTime() > 0.f) {
		restsekunden -= zeit_timer.GetElapsedTime();
		zeit_timer.Reset();
	} else {
		restsekunden = 0.f;
	}
	return;
}

float Zeitlimit::get_restsekunden()
{
	berechne_restzeit();
	return restsekunden;
}
void Zeitlimit::zeichnen(sf::RenderWindow &fenster)
{
	berechne_restzeit();
	std::ostringstream konverter;
	konverter << std::setw(2) << std::setfill('0') << static_cast<int>(restsekunden / 60.f) << ":" // Minuten
			  << std::setw(2) << std::setfill('0')
			  << static_cast<int>(restsekunden - (static_cast<int>(restsekunden / 60.f) * 60.f));  // Sekunden (im Zeitformat)
	zeit_anzeige.SetText(konverter.str());
	fenster.Draw(zeit_anzeige);
	return;
}