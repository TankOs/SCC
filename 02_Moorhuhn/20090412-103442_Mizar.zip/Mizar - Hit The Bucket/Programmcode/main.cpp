//main.cpp
#include "alle_gamestates.h"
#include <vector>

int main()
{
	// Erstelle ein Fenster
	sf::RenderWindow fenster(sf::VideoMode(800, 600, 32), "Hit the Bucket", sf::Style::Close);
	// setze maximale Frames pro Sekunde auf 60
	fenster.SetFramerateLimit(60);
	// Zeige Mauscursor nicht an
	fenster.ShowMouseCursor(false);
	// Vector enth�lt jeden Gamestate genau einmal
	std::vector<Gamestate*> vec_gamestates;
	Hauptmenu hauptmenu; // Index -> 0
	Spiel spiel;		 // Index -> 1
	vec_gamestates.push_back(&hauptmenu);
	vec_gamestates.push_back(&spiel);
	// Integervariable dient als Index um auf die Gamestates zuzugreifen
	int gamestate_index(0);
	// Hauptschleife der Anwendung
	while(gamestate_index >= 0) {
		// �ber Index auf Gamestate zugreifen und dessen "Hauptfunktion" aufrufen.
		// Durch R�ckgabewert der "Hauptfunktion" eines Gamestates den Gamestate
		// wechseln oder die Anwendung beenden (bei R�ckgabewert kleiner als 0).
		gamestate_index = vec_gamestates[gamestate_index]->ausfuehren(fenster);
	}
	// Schlie�e das erstellte Fenster vor dem beenden der Anwendung wieder
	fenster.Close();

	return 0;
}