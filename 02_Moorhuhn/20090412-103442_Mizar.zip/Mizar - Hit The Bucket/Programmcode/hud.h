//hud.h
#ifndef ALLEHUDELEMENTEZUSAMMEN_H
#define ALLEHUDELEMENTEZUSAMMEN_H

#include "munitionsanzeige.h"
#include "punktanzeige.h"
#include "zeitlimit.h"

class HUD {
public:
	// Konstruktor
	HUD(const unsigned int fenster_grenze_x, const unsigned int fenster_grenze_y, const sf::Image &munitions_bild,
		const unsigned int max_schuesse = 8, const long int startpunkte = 0, const float sekunden = 120.f):
	hud_munition(munitions_bild, fenster_grenze_y, max_schuesse),
	hud_punkte(fenster_grenze_x, fenster_grenze_y, startpunkte),
	hud_zeit(fenster_grenze_x, fenster_grenze_y, sekunden)
	{ }
	// Munitionsfunktionen
	unsigned int munition_get_schuesse() const { return hud_munition.get_anzahl_schuesse(); }
	unsigned int munition_get_max_schuesse() const { return hud_munition.get_max_schuesse(); }
	void munition_schiessen() { hud_munition.schiessen(); return; }
	void munition_nachladen() { hud_munition.nachladen(); return; }
	// Punktefunktionen
	long int punkte_get_punkte() const { return hud_punkte.get_punktestand(); }
	void punkte_aendere_punkte(const long int aenderung) { hud_punkte.aendere_punktestand(aenderung); return; }
	// Zeitfunktionen
	float zeit_get_restsekunden() { return hud_zeit.get_restsekunden(); }
	// Zeichenfunktion
	void zeichnen(sf::RenderWindow &fenster) { hud_munition.zeichnen(fenster); hud_punkte.zeichnen(fenster); hud_zeit.zeichnen(fenster); return; }
private:
	Munitionsanzeige hud_munition;
	Punktanzeige hud_punkte;
	Zeitlimit hud_zeit;
};

#endif // ALLEHUDELEMENTEZUSAMMEN_H