//funktionen.cpp
#include "funktionen.h"

void speicher_freigeben(std::list<Eimer*>::iterator beg, std::list<Eimer*>::iterator end)
{
	while(beg != end) {
		delete *beg;
		++beg;
	}
	return;
}

bool hauptmenu_animation(sf::Sprite &fadenkreuz, sf::Sprite &titel, sf::Sprite &rechte_wand, sf::Sprite &linke_wand,
						 const sf::Image &hintergrund_bild, const sf::SoundBuffer &trommel_buffer, sf::String &menupunkt_1, 
						 sf::String &menupunkt_2, sf::String &menupunkt_3, sf::RenderWindow &fenster)
{
	sf::Event eingabe;
	int alpha_aenderung = 0;
	// Erstelle ein Sprite f�r den Hintergrund
	sf::Sprite hintergrund(hintergrund_bild);
	// Erstelle einen Trommelsound
	sf::Sound trommel(trommel_buffer);
	trommel.Play();
	// Setze Ausblend- und Bewegungsgeschwindigkeit anhand der l�nge des Trommelsounds
	const float alpha_abnahme = (titel.GetColor().a * 2.f) / trommel_buffer.GetDuration(); // x2 wegen static_cast<int>
	const float wand_speed_x = rechte_wand.GetSize().x / trommel_buffer.GetDuration();
	// Starte Animation
	while(fenster.IsOpened() && rechte_wand.GetPosition().x < static_cast<float>(fenster.GetWidth())) {
		// Aktualisiere Fadenkreuzposition
		fadenkreuz.SetPosition(fenster.GetInput().GetMouseX() - fadenkreuz.GetSize().x / 2.f,
							   fenster.GetInput().GetMouseY() - fadenkreuz.GetSize().y / 2.f);
		// Blende Men�punkte und Titel aus
		alpha_aenderung = static_cast<int>(alpha_abnahme * fenster.GetFrameTime());
		if(titel.GetColor().a - alpha_aenderung > 0) {
			titel.SetColor(sf::Color(titel.GetColor().r,
									 titel.GetColor().g,
									 titel.GetColor().b,
									 titel.GetColor().a - alpha_aenderung));
			menupunkt_1.SetColor(sf::Color(menupunkt_1.GetColor().r,
										   menupunkt_1.GetColor().g,
										   menupunkt_1.GetColor().b,
										   menupunkt_1.GetColor().a - alpha_aenderung));
			menupunkt_2.SetColor(sf::Color(menupunkt_2.GetColor().r,
										   menupunkt_2.GetColor().g,
										   menupunkt_2.GetColor().b,
										   menupunkt_2.GetColor().a - alpha_aenderung));
			menupunkt_3.SetColor(sf::Color(menupunkt_3.GetColor().r,
										   menupunkt_3.GetColor().g,
										   menupunkt_3.GetColor().b,
										   menupunkt_3.GetColor().a - alpha_aenderung));
		} else {
			titel.SetColor(sf::Color(titel.GetColor().r,
									 titel.GetColor().g,
									 titel.GetColor().b,
									 0));
			menupunkt_1.SetColor(sf::Color(menupunkt_1.GetColor().r,
										   menupunkt_1.GetColor().g,
										   menupunkt_1.GetColor().b,
										   0));
			menupunkt_2.SetColor(sf::Color(menupunkt_2.GetColor().r,
										   menupunkt_2.GetColor().g,
										   menupunkt_2.GetColor().b,
										   0));
			menupunkt_3.SetColor(sf::Color(menupunkt_3.GetColor().r,
										   menupunkt_3.GetColor().g,
										   menupunkt_3.GetColor().b,
										   0));
		}
		// Bewege die beiden W�nde
		rechte_wand.Move(wand_speed_x * fenster.GetFrameTime(), 0.f);
		linke_wand.Move(wand_speed_x * fenster.GetFrameTime() * -1, 0.f);
		// Arbeite Eingaben ab
		while(fenster.GetEvent(eingabe)) {
			// Wurde das Schlie�ensymbol angeklickt oder ESCAPE gedr�ckt, gib 'false' zur�ck, damit im
			// Hauptmen� das Spiel beendet werden kann
			if(eingabe.Type == sf::Event::Closed || fenster.GetInput().IsKeyDown(sf::Key::Escape)) {
				return false;
			}
		}
		// Zeichne alles ;)
		fenster.Clear(sf::Color(0, 0, 0));
		fenster.Draw(hintergrund);
		fenster.Draw(rechte_wand);
		fenster.Draw(linke_wand);
		fenster.Draw(titel);
		fenster.Draw(menupunkt_1);
		fenster.Draw(menupunkt_2);
		fenster.Draw(menupunkt_3);
		fenster.Draw(fadenkreuz);
		fenster.Display();
	}
	// Animation erfolgreich durchgelaufen -> true
	return true;
}

bool schuss_auf_eimer(std::list<Eimer*>::iterator beg, std::list<Eimer*>::iterator end,
					  std::list<Punktwertanzeige> &punktwert_liste, HUD &hud, const float maus_x, const float maus_y)
{
	// �berpr�fe ob ein Eimer getroffen wurde
	while(beg != end) {
		if(!(*beg)->get_ist_getroffen() && (*beg)->get_rect().Contains(maus_x, maus_y)) {
			// Eimer wurde getroffen
			(*beg)->getroffen();
			// F�ge Punktwert zu den Punkten des Spielers hinzu
			hud.punkte_aendere_punkte((*beg)->get_punktwert());
			// Erstelle neues Punktwert-Objekt zur Anzeige der erhaltenen Punkte
			punktwert_liste.push_back(Punktwertanzeige((*beg)->get_punktwert(),
													   (*beg)->get_pos().x + (*beg)->get_size().x / 2.f,
													   (*beg)->get_pos().y + (*beg)->get_size().y / 2.f));
			// Pro Schuss kann nur ein Eimer getroffen werden, darum verlasse die Funktion nach einem Treffer wieder
			return true;
		}
		// Wenn Eimer bereits getroffen, oder Eimer verfehlt -> n�chsten Eimer �berpr�fen
		++beg;
	}
	return false;
}

void bewege_eimer(std::list<Eimer*>::iterator beg, std::list<Eimer*>::iterator end, const float frame_zeit)
{
	while(beg != end) {
		(*beg)->bewegen(frame_zeit);
		++beg;
	}
	return;
}

void eimer_loeschen(std::list<Eimer*> &eimer_liste, const sf::RenderWindow &fenster)
{
	std::list<Eimer*>::iterator loesch_eimer_iter = eimer_liste.begin();
	while(loesch_eimer_iter != eimer_liste.end()) {
		if((*loesch_eimer_iter)->get_alphawert() == 0 || (*loesch_eimer_iter)->ausserhalb_fenster(fenster)) {
			// Wurde ein Eimer getroffen wird dessen Alphawert reduziert, ist dieser 0 oder befindet sich Eimer au�erhalb
			// des Fensters ...
			// ... Speicher freigeben
			delete *loesch_eimer_iter;
			// ... und entferne Eimer
			loesch_eimer_iter = eimer_liste.erase(loesch_eimer_iter);
		} else {
			++loesch_eimer_iter;
		}
	}
	return;
}

void punktwert_loeschen(std::list<Punktwertanzeige> &punktwert_liste)
{
	std::list<Punktwertanzeige>::iterator loesch_punktwert_iter = punktwert_liste.begin();
	while(loesch_punktwert_iter != punktwert_liste.end()) {
		if(loesch_punktwert_iter->get_alphawert() == 0) {
			// Nach Erstellung eines Punktwertanzeige-Objekts sinkt dessen Alphawert, ist dieser 0 -> entferne Punktwert
			loesch_punktwert_iter = punktwert_liste.erase(loesch_punktwert_iter);
		} else {
			++loesch_punktwert_iter;
		}
	}
	return;
}

void zeichne_eimer(std::list<Eimer*>::reverse_iterator beg, std::list<Eimer*>::reverse_iterator end, sf::RenderWindow &fenster)
{
	while(beg != end) {
		(*beg)->zeichnen(fenster);
		++beg;
	}
	return;
}

void zeichne_punktwerte(std::list<Punktwertanzeige>::iterator beg, std::list<Punktwertanzeige>::iterator end, sf::RenderWindow &fenster)
{
	while(beg != end) {
		beg->zeichnen(fenster, static_cast<int>(175 * fenster.GetFrameTime())); // 255 ist max. Alphawert, Alphawert�nderung �bergeben
		++beg;
	}
	return;
}

void spielende(const long int punkte, const unsigned int meiste_treffer, sf::Sprite &fadenkreuz,sf::Sprite &hintergrund,
			   sf::RenderWindow &fenster)
{
	// Erstelle mehrere sf::Strings zur Ausgabe der Errungenschaften
	sf::String time_up("Time's up!", sf::Font::GetDefaultFont(), 42.f);
	sf::String punkte_text("Score:", sf::Font::GetDefaultFont(), 42.f);
	sf::String treffer_text("Most hits in a row:", sf::Font::GetDefaultFont(), 42.f);
	sf::String quit_text("Press 'Esc' to quit.", sf::Font::GetDefaultFont(), 42.f);
	std::ostringstream konverter;
	konverter << punkte;
	sf::String punktanzahl_text(konverter.str(), sf::Font::GetDefaultFont(), 42.f);
	konverter.str(""); // std::ostringstream zur�cksetzen
	konverter << meiste_treffer;
	sf::String trefferanzahl_text(konverter.str(), sf::Font::GetDefaultFont(), 42.f);
	// Setze Positionen
	time_up.SetPosition(fenster.GetWidth() / 2.f - time_up.GetRect().GetWidth() / 2.f, 0.f);
	punkte_text.SetPosition(fenster.GetWidth() / 2.f - punkte_text.GetRect().GetWidth() / 2.f, fenster.GetHeight() * 0.2f);
	punktanzahl_text.SetPosition(fenster.GetWidth() / 2.f - punktanzahl_text.GetRect().GetWidth() / 2.f, fenster.GetHeight() * 0.3f);
	treffer_text.SetPosition(fenster.GetWidth() / 2.f - treffer_text.GetRect().GetWidth() / 2.f, fenster.GetHeight() * 0.4f);
	trefferanzahl_text.SetPosition(fenster.GetWidth() / 2.f - trefferanzahl_text.GetRect().GetWidth() / 2.f, fenster.GetHeight() * 0.5f);
	quit_text.SetPosition(fenster.GetWidth() / 2.f - quit_text.GetRect().GetWidth() / 2.f, fenster.GetHeight() * 0.9f);
	// sf::Event zur Abarbeitung von Eingaben
	sf::Event eingabe;
	// Hauptschleife
	while(fenster.IsOpened()) {
		// Aktualisiere Fadenkreuzposition
		fadenkreuz.SetPosition(fenster.GetInput().GetMouseX() - fadenkreuz.GetSize().x / 2.f,
							   fenster.GetInput().GetMouseY() - fadenkreuz.GetSize().y / 2.f);
		// Eingaben abarbeiten
		while(fenster.GetEvent(eingabe)) {
			// Wurde das Schlie�ensymbol angeklickt oder ESCAPE gedr�ckt, verlasse die Funktion
			if(eingabe.Type == sf::Event::Closed || fenster.GetInput().IsKeyDown(sf::Key::Escape)) {
				return;
			}
		}
		// Zeichnen
		fenster.Clear(sf::Color(0, 0, 0));
		fenster.Draw(hintergrund);
		fenster.Draw(time_up);
		fenster.Draw(punkte_text);
		fenster.Draw(punktanzahl_text);
		fenster.Draw(treffer_text);
		fenster.Draw(trefferanzahl_text);
		fenster.Draw(quit_text);
		fenster.Draw(fadenkreuz);
		fenster.Display();
	}
	return;
}
