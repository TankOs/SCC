//normaler_eimer.cpp
#include "normaler_eimer.h"

bool NormalerEimer::ausserhalb_fenster(const sf::RenderWindow &fenster)
{
	// Befindet sich Eimer links oder rechts neben der Fenstergrenze -> return true;
	if(eimer_sprite.GetPosition().x + eimer_sprite.GetSize().x < 0.f ||
	   eimer_sprite.GetPosition().x > static_cast<float>(fenster.GetWidth())) {
		return true;
	}
	// Befindet sich Eimer unter der unteren Fenstergrenze UND bewegt sich nach unten (speed_y > 0) -> return true;
	if(eimer_sprite.GetPosition().y > static_cast<float>(fenster.GetHeight()) && speed_y > 0.f) {
		return true;
	}
	// Befindet sich Eimer �ber der oberen Fenstergrenze -> return true; (dieser Fall sollte normalerweise nie eintreten)
	if(eimer_sprite.GetPosition().y + eimer_sprite.GetSize().y < 0.f) {
		return true;
	}
	// sonst return false;
	return false;
}

void NormalerEimer::bewegen(const float frame_zeit)
{
	if(!ist_getroffen) {
		eimer_sprite.Move(speed_x * frame_zeit, speed_y * frame_zeit);
		// Pr�fen ob Eimer bis zum h�chstpunkt hochgeflogen ist, falls ja kehre Y-Speed um
		// (Pr�fe nur wenn Eimer auch nach oben fliegt [speed_y < 0])
		if(eimer_sprite.GetPosition().y < max_pos_y && speed_y < 0) {
			speed_y *= -1;
		}
	}
	return;
}