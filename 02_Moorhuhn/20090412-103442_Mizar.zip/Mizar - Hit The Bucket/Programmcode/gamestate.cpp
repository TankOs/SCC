//gamestate.cpp
#include "gamestate.h"

void Gamestate::aktualisiere_mauskoordinaten(const sf::RenderWindow &fenster)
{
	maus_x = static_cast<float>(fenster.GetInput().GetMouseX());
	maus_y = static_cast<float>(fenster.GetInput().GetMouseY());
	return;
}