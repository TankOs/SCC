//normaler_eimer.h
#ifndef DERNORMALESILBERNEEIMER_H
#define DERNORMALESILBERNEEIMER_H

#include "eimer.h"

class NormalerEimer: public Eimer {
public:
	// Konstruktor
	NormalerEimer(const sf::Image &eimer_bild, const unsigned int fenster_grenze_x, const unsigned int fenster_grenze_y):
	Eimer(eimer_bild,
		  sf::Vector2f(sf::Randomizer::Random(0.f, static_cast<float>(fenster_grenze_x - eimer_bild.GetWidth())),
					   static_cast<float>(fenster_grenze_y)),
		  1.f, // Scale
		  0.f, // Rotation
		  15), // Punkte
	speed_x(100.f),
	speed_y(-200.f),
	max_pos_y(sf::Randomizer::Random(0.1f, 0.3f) * fenster_grenze_y) // Bis wie hoch fliegt der Eimer
	{
		if(sf::Randomizer::Random(0, 1) == 1) {
			speed_x *= -1;
		}
	}
	// Bewegen
	virtual bool ausserhalb_fenster(const sf::RenderWindow &fenster);
	virtual void bewegen(const float frame_zeit);
private:
	float speed_x;
	float speed_y;
	float max_pos_y;
};

#endif // DERNORMALESILBERNEEIMER_H