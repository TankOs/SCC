//gamestate.h
#ifndef DIEGAMESTATEBASISKLASSE_H
#define DIEGAMESTATEBASISKLASSE_H

#include <SFML/Graphics.hpp>

class Gamestate {
public:
	// Kontruktor
	Gamestate(): maus_x(0.f), maus_y(0.f) { }
	// "Hauptfunktion" eines Gamestates
	virtual int ausfuehren(sf::RenderWindow &fenster) = 0;
	// virtueller Destruktor
	virtual ~Gamestate() { }
protected:
	// Hilfsfunktion
	virtual void aktualisiere_mauskoordinaten(const sf::RenderWindow &fenster);
	// Datenelemente
	float maus_x;
	float maus_y;
};

#endif // DIEGAMESTATEBASISKLASSE_H