//goldener_eimer.h
//roter_eimer.cpp
#include "goldener_eimer.h"

bool GoldenerEimer::ausserhalb_fenster(const sf::RenderWindow &fenster)
{
	// Befindet sich Eimer �ber oder unter der Fenstergrenze -> return true;
	if(eimer_sprite.GetPosition().y + eimer_sprite.GetSize().y < 0.f ||
	   eimer_sprite.GetPosition().y > static_cast<float>(fenster.GetHeight())) {
		return true;
	}
	// Befindet sich Eimer links neben der Fenstergrenze UND bewegt sich nach rechts (speed_x < 0) -> return true;
	if(eimer_sprite.GetPosition().x + eimer_sprite.GetSize().x < 0.f && speed_x < 0.f) {
		return true;
	}
	// Befindet sich Eimer rechts neben der Fenstergrenze UND bewegt sich nach links (speed_x > 0) -> return true;
	if(eimer_sprite.GetPosition().x > static_cast<float>(fenster.GetWidth()) && speed_x > 0.f) {
		return true;
	}
	// sonst return false;
	return false;
}

void GoldenerEimer::bewegen(const float frame_zeit)
{
	if(!ist_getroffen) {
		eimer_sprite.Move(speed_x * frame_zeit, speed_y * frame_zeit);
	}
	return;
}