//zeitlimit.h
#ifndef EINEABTICKENDEUHR_H
#define EINEABTICKENDEUHR_H

#include <SFML/Graphics.hpp>

class Zeitlimit {
public:
	// Konstruktor
	Zeitlimit(const unsigned int fenster_grenze_x, const unsigned int fenster_grenze_y, const float sekunden = 120.f):
	zeit_anzeige("00:00", sf::Font::GetDefaultFont(), 40.f),
	restsekunden(sekunden)
	{
		zeit_anzeige.SetPosition(fenster_grenze_x / 2.f - zeit_anzeige.GetRect().GetWidth() / 2.f, 0.f);
		zeit_timer.Reset();
	}
	// Getter
	float get_restsekunden();
	// Funktionen
	void zeichnen(sf::RenderWindow &fenster);
private:
	// Hilfsfunktion
	void berechne_restzeit();
	// Datenelemente
	sf::String zeit_anzeige;
	float restsekunden;
	sf::Clock zeit_timer;
};

#endif // EINEABTICKENDEUHR_H