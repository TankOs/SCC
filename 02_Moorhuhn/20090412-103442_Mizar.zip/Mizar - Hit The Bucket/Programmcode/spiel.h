//spiel.h
#ifndef MEINKLEINESHITTHEBUCKETSPIEL_H
#define MEINKLEINESHITTHEBUCKETSPIEL_H

#include "gamestate.h"

class Spiel: public Gamestate {
public:
	// Konstruktor
	Spiel(): Gamestate() { }
	// "Hauptfunktion" dieses Gamestates
	virtual int ausfuehren(sf::RenderWindow &fenster);
};

#endif // MEINKLEINESHITTHEBUCKETSPIEL_H