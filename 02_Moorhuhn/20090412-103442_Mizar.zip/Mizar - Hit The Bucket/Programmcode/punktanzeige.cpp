//punktanzeige.cpp
#include "punktanzeige.h"
#include <sstream>
#include <iomanip>

void Punktanzeige::aendere_punktestand(const long int aenderung)
{
	if(punktestand + aenderung > 0) {
		punktestand += aenderung;
	} else {
		punktestand = 0;
	}
	return;
}

void Punktanzeige::zeichnen(sf::RenderWindow &fenster)
{
	std::ostringstream konverter;
	konverter << std::setw(5) << std::setfill('0') << punktestand;
	punkte_anzeige.SetText(konverter.str());
	fenster.Draw(punkte_anzeige);
	return;
}