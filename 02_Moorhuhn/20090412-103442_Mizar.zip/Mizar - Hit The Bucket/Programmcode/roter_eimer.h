//roter_eimer.h
//normaler_eimer.h
#ifndef EINBOESERROTEREIMER_H
#define EINBOESERROTEREIMER_H

#include "eimer.h"

class RoterEimer: public Eimer {
public:
	// Konstruktor
	RoterEimer(const sf::Image &eimer_bild, const unsigned int fenster_grenze_x):
	Eimer(eimer_bild,
		  sf::Vector2f(sf::Randomizer::Random(0.f, static_cast<float>(fenster_grenze_x - eimer_bild.GetWidth())),
					   0.f - eimer_bild.GetHeight()),
		  1.f, // Scale
		  0.f, // Rotation
		  -25), // Roter Eimer senkt die Punktzahl
	speed_y(275.f)
	{ }
	// Bewegen
	virtual bool ausserhalb_fenster(const sf::RenderWindow &fenster);
	virtual void bewegen(const float frame_zeit);
private:
	float speed_y;
};

#endif // EINBOESERROTEREIMER_H