//munitionsanzeige.h
#ifndef EINENETTEMUNITIONSANZEIGE_H
#define EINENETTEMUNITIONSANZEIGE_H

#include <SFML/Graphics.hpp>
#include <vector>

class Munitionsanzeige {
public:
	// Konstruktor
	Munitionsanzeige(const sf::Image &munitions_bild, const unsigned int fenster_grenze_y, const unsigned int max_munition = 8):
	anzahl_schuesse(max_munition),
	max_schuesse(max_munition)
	{
		for(unsigned int durchgaenge = 0; durchgaenge != max_schuesse; ++durchgaenge) {
			schuss_anzeige.push_back(sf::Sprite(munitions_bild,
									 sf::Vector2f(static_cast<float>(munitions_bild.GetWidth() * durchgaenge),
												  static_cast<float>(fenster_grenze_y * 0.97f - munitions_bild.GetWidth())))); // ab 97% der Fensterh�he zeichnen
		}
	}
	// Getter
	unsigned int get_anzahl_schuesse() const { return anzahl_schuesse; }
	unsigned int get_max_schuesse() const { return max_schuesse; }
	// Funktionen
	void nachladen() { anzahl_schuesse = max_schuesse; return; }
	void schiessen();
	void zeichnen(sf::RenderWindow &fenster);
private:
	unsigned int anzahl_schuesse;
	unsigned int max_schuesse;
	std::vector<sf::Sprite> schuss_anzeige;
};

#endif // EINENETTEMUNITIONSANZEIGE_H