//eimer.h
#ifndef MEINTRAGBARESBEHAELTNIS_H
#define MEINTRAGBARESBEHAELTNIS_H

#include <SFML/Graphics.hpp>

class Eimer {
public:
	// Konstruktor
	Eimer(const sf::Image &eimer_bild, const sf::Vector2f &eimer_pos = sf::Vector2f(0.f, 0.f),
		  const float eimer_scale = 1.f, const float eimer_rotation = 0.f, const int punkte = 0, const bool getroffen = false):
	eimer_sprite(eimer_bild, eimer_pos, sf::Vector2f(eimer_scale, eimer_scale), eimer_rotation),
	punktwert(punkte),
	ist_getroffen(getroffen)
	{ }
	// Getter
	virtual sf::FloatRect get_rect() const;
	virtual sf::Vector2f get_pos() const { return eimer_sprite.GetPosition(); }
	virtual sf::Vector2f get_size() const { return eimer_sprite.GetSize(); }
	virtual int get_punktwert() const { return punktwert; }
	virtual bool get_ist_getroffen() const { return ist_getroffen; }
	virtual int get_alphawert() const { return static_cast<int>(eimer_sprite.GetColor().a); }
	// Eimerfunktionen
	virtual void getroffen();
	virtual void aendere_alphawert(const int alpha_aenderung);
	virtual void zeichnen(sf::RenderWindow &fenster);
	// abstrakte Funktionen
	virtual bool ausserhalb_fenster(const sf::RenderWindow &fenster) = 0;
	virtual void bewegen(const float frame_zeit) = 0;
	// virtueller Destruktor
	virtual ~Eimer() { }
protected:
	// Datenelemente
	sf::Sprite eimer_sprite;
	int punktwert;
	bool ist_getroffen;
	static const float alphawert_abnahme;
};

#endif // MEINTRAGBARESBEHAELTNIS_H