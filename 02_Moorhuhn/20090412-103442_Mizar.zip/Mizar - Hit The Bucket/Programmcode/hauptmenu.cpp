//hauptmenu.cpp
#include "hauptmenu.h"
#include "funktionen.h"
#include <string>

int Hauptmenu::ausfuehren(sf::RenderWindow &fenster)
{
	// Lade das Bild f�r das Fadenkreuz und erstelle ein sf::Sprite
	sf::Image fadenkreuz_bild;
	if(!fadenkreuz_bild.LoadFromFile("img\\fadenkreuz.png")) {
		return -1;
	}
	sf::Sprite fadenkreuz(fadenkreuz_bild);
	// Lade die Hintergrundbilder des Hauptmen�s und erstelle entsprechende Sprites
	sf::Image titel_bild;
	if(!titel_bild.LoadFromFile("img\\titel.png")) {
		return -1;
	}
	sf::Sprite titel(titel_bild, sf::Vector2f(fenster.GetWidth() / 2.f - titel_bild.GetWidth() / 2.f, fenster.GetHeight() * 0.1f));
	sf::Image hauptmenu_hintergrund_bild;
	if(!hauptmenu_hintergrund_bild.LoadFromFile("img\\hauptmenu_hintergrund.jpg")) {
		return -1;
	}
	sf::Sprite rechte_wand(hauptmenu_hintergrund_bild, sf::Vector2f(fenster.GetWidth() / 2.f, 0.f));
	sf::Sprite linke_wand(hauptmenu_hintergrund_bild, sf::Vector2f(0.f, 0.f));
	// Lade zus�tzlich das Hintergrundbild des Spiels, dieses wird erst w�hrend der Animation und im Spiel selbst angezeigt.
	sf::Image hintergrund_bild;
	if(!hintergrund_bild.LoadFromFile("img\\bucket_hintergrund.jpg")) {
		return -1;
	}
	// Lade den Trommelsound (Verwendung dieses Soundbuffers erfolgt in der Funktion hauptmenu_animation)
	sf::SoundBuffer trommel_buffer;
	if(!trommel_buffer.LoadFromFile("mus\\trommel.ogg")) {
		return -1;
	}
	// Das Fenster wird in der main() im Fenstermodus erstellt, deshalb fullscreen = false
	bool fullscreen = false;
	std::string zu_fenster_text("Windowed");
	std::string zu_vollbild_text("Fullscreen");
	std::string vollbild_fehler("Fullscreen not supported");
	// Erstelle die Men�punkte und setze ihre Positionen
	sf::String menupunkt_1("Play", sf::Font::GetDefaultFont(), 42.f);
	sf::String menupunkt_2(zu_vollbild_text, sf::Font::GetDefaultFont(), 42.f);
	sf::String menupunkt_3("Quit", sf::Font::GetDefaultFont(), 42.f);
	menupunkt_1.SetPosition(fenster.GetWidth() / 2.f - menupunkt_1.GetRect().GetWidth() / 2.f,
							fenster.GetHeight() * 0.70f);
	menupunkt_2.SetPosition(fenster.GetWidth() / 2.f - menupunkt_2.GetRect().GetWidth() / 2.f,
							fenster.GetHeight() * 0.80f);
	menupunkt_3.SetPosition(fenster.GetWidth() / 2.f - menupunkt_3.GetRect().GetWidth() / 2.f,
							fenster.GetHeight() * 0.90f);
	// Erstelle sf::Event zur Abarbeitung von Eingaben
	sf::Event eingabe;
	// Hauptschleife des Hauptmen�s
	while(fenster.IsOpened()) {
		// Aktualisiere Mauscursorkoordinate
		aktualisiere_mauskoordinaten(fenster);
		// Aktualisiere Fadenkreuzposition
		fadenkreuz.SetPosition(maus_x - fadenkreuz.GetSize().x / 2.f, maus_y - fadenkreuz.GetSize().y / 2.f);
		// Befindet sich Mauscursor �ber einem Men�punkt, f�rbe diesen ein
		if(menupunkt_1.GetRect().Contains(maus_x, maus_y)) {
			menupunkt_1.SetColor(sf::Color(0, 255, 0)); // gr�n
		} else {
			menupunkt_1.SetColor(sf::Color(255, 255, 255)); // sonst wei�
		}
		if(menupunkt_2.GetRect().Contains(maus_x, maus_y)) {
			menupunkt_2.SetColor(sf::Color(0, 0, 255)); // blau
		} else {
			menupunkt_2.SetColor(sf::Color(255, 255, 255)); // sonst wei�
		}
		if(menupunkt_3.GetRect().Contains(maus_x, maus_y)) {
			menupunkt_3.SetColor(sf::Color(255, 0, 0)); // rot
		} else {
			menupunkt_3.SetColor(sf::Color(255, 255, 255)); // sonst wei�
		}
		// Abarbeitung der Eingaben
		while(fenster.GetEvent(eingabe)) {
			// Wurde das Schlie�ensymbol angeklickt oder ESCAPE gedr�ckt, beende die Anwendung
			if(eingabe.Type == sf::Event::Closed || fenster.GetInput().IsKeyDown(sf::Key::Escape)) {
				return -1;
			}
			// Wurde die linke Maustaste gedr�ckt, w�hrend sich der Mauscursor �ber...
			if(eingabe.Type == sf::Event::MouseButtonPressed && eingabe.MouseButton.Button == sf::Mouse::Left) {
				if(menupunkt_1.GetRect().Contains(maus_x, maus_y)) {
					// ... Men�punkt 1 befand, starte Animation. War diese erfolgreich dann springe ins Spiel
					if(hauptmenu_animation(fadenkreuz, titel, rechte_wand, linke_wand, hintergrund_bild, trommel_buffer,
										   menupunkt_1, menupunkt_2, menupunkt_3, fenster)) {
						return 1;
					} else {
						return -1;
					}
				} else if(menupunkt_2.GetRect().Contains(maus_x, maus_y)) {
					// ... Men�punkt 2 befand, wechsle zwischen Fenster- und Vollbildmodus
					if(fullscreen) {
						fenster.Create(sf::VideoMode(800, 600, 32), "Hit The Bucket", sf::Style::Close);
						menupunkt_2.SetText(zu_vollbild_text);
						menupunkt_2.SetPosition(fenster.GetWidth() / 2.f - menupunkt_2.GetRect().GetWidth() / 2.f,
												menupunkt_2.GetPosition().y);
						fenster.ShowMouseCursor(false);
						fullscreen = !fullscreen;
					} else if(!fullscreen) {
						if(sf::VideoMode(800, 600, 32).IsValid()) {
							fenster.Create(sf::VideoMode(800, 600, 32), "Hit The Bucket", sf::Style::Close | sf::Style::Fullscreen);
							menupunkt_2.SetText(zu_fenster_text);
							menupunkt_2.SetPosition(fenster.GetWidth() / 2.f - menupunkt_2.GetRect().GetWidth() / 2.f,
													menupunkt_2.GetPosition().y);
							fenster.ShowMouseCursor(false);
							fullscreen = !fullscreen;
						} else {
							menupunkt_2.SetText(vollbild_fehler);
							menupunkt_2.SetPosition(fenster.GetWidth() / 2.f - menupunkt_2.GetRect().GetWidth() / 2.f,
													menupunkt_2.GetPosition().y);
						}
					}
				} else if(menupunkt_3.GetRect().Contains(maus_x, maus_y)) {
					// ... Men�punkt 3 befand, beende die Anwendung
					return -1;
				}
			}
		}
		// Zeichne den Fensterinhalt
		fenster.Clear(sf::Color(0, 0, 0)); // bereinige den Fensterinhalt
		fenster.Draw(rechte_wand);
		fenster.Draw(linke_wand);
		fenster.Draw(titel);
		fenster.Draw(menupunkt_1);
		fenster.Draw(menupunkt_2);
		fenster.Draw(menupunkt_3);
		fenster.Draw(fadenkreuz);
		fenster.Display(); // Darstellung des Fensterinhalts
	}
	// Diese Codezeile sollte normalerweise nie erreicht werden, falls doch beende die Anwendung
	return -1;
}