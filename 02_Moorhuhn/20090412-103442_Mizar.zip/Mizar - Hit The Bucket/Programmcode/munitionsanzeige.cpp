//munitionsanzeige.cpp
#include "munitionsanzeige.h"

void Munitionsanzeige::schiessen()
{
	if(anzahl_schuesse - 1 > 0) {
		--anzahl_schuesse;
	} else {
		anzahl_schuesse = 0;
	}
	return;
}

void Munitionsanzeige::zeichnen(sf::RenderWindow &fenster)
{
	// Zeichnet so viele sf::Sprites wie noch Munition �brig ist
	for(unsigned int durchgaenge = 0; durchgaenge != anzahl_schuesse; ++durchgaenge) {
		// Sicherheitsabfrage um nicht auf Elemente zuzugreifen die gar nicht existieren
		if(durchgaenge < schuss_anzeige.size()) {
			fenster.Draw(schuss_anzeige[durchgaenge]);
		}
	}
	return;
}