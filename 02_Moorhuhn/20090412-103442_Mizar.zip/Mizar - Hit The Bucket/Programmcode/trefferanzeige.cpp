//trefferanzeige.cpp
#include "trefferanzeige.h"
#include <sstream>

const int Trefferanzeige::start_alpha = 155;
const int Trefferanzeige::farb_aenderung = 5;

void Trefferanzeige::set_treffer_in_folge(const unsigned int treffer)
{
	anzahl_treffer_in_folge = treffer;
	// Aktualisiere Text der Anzeige
	std::ostringstream konverter;
	konverter << "Hits: " << anzahl_treffer_in_folge;
	treffer_anzeige.SetText(konverter.str());
	// Die Anzahl der Treffer in Folge werden erst angezeigt, wenn mindestens 2 Treffer in Folge erzielt wurden
	if(anzahl_treffer_in_folge > 1) {
		treffer_anzeige.SetColor(sf::Color(treffer_anzeige.GetColor().r,
										   treffer_anzeige.GetColor().g,
										   treffer_anzeige.GetColor().b,
										   start_alpha));
	} else {
		treffer_anzeige.SetColor(sf::Color(treffer_anzeige.GetColor().r,
										   treffer_anzeige.GetColor().g,
										   treffer_anzeige.GetColor().b,
										   0));
	}
	// Setze Farbwerte. Durch Treffer in Folge �ndert sich die Farbe des Textes
	if(farb_aenderung * anzahl_treffer_in_folge <= 255) {								   // 255 = maximaler Farbwert
		treffer_anzeige.SetColor(sf::Color(255 - farb_aenderung * anzahl_treffer_in_folge, // roter Farbwert nimmt ab
										   farb_aenderung * anzahl_treffer_in_folge,       // gr�ner Farbwert nimmt zu
										   treffer_anzeige.GetColor().b,				   // blauer Farbwert bleibt unver�ndert
										   treffer_anzeige.GetColor().a));				   // Alphawert bleibt unver�ndert
	} else {
		treffer_anzeige.SetColor(sf::Color(0,
										   255,
										   treffer_anzeige.GetColor().b,
										   treffer_anzeige.GetColor().a));
	}
	return;
}

void Trefferanzeige::zeichnen(sf::RenderWindow &fenster, const int alpha_aenderung)
{
	// senke Alphawert (ausblenden)
	if(treffer_anzeige.GetColor().a - alpha_aenderung > 0) {
		treffer_anzeige.SetColor(sf::Color(treffer_anzeige.GetColor().r,
										   treffer_anzeige.GetColor().g,
										   treffer_anzeige.GetColor().b,
										   treffer_anzeige.GetColor().a - alpha_aenderung));
	} else {
		treffer_anzeige.SetColor(sf::Color(treffer_anzeige.GetColor().r,
										   treffer_anzeige.GetColor().g,
										   treffer_anzeige.GetColor().b,
										   0));
	}
	fenster.Draw(treffer_anzeige);
	return;
}