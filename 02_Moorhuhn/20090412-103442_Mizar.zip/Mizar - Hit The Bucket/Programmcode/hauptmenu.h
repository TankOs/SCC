//hauptmenu.h
#ifndef MEINKLEINESHAUPTMENUE_H
#define MEINKLEINESHAUPTMENUE_H

#include "gamestate.h"

class Hauptmenu: public Gamestate {
public:
	// Konstruktor
	Hauptmenu(): Gamestate() { }
	// "Hauptfunktion" dieses Gamestates
	virtual int ausfuehren(sf::RenderWindow &fenster);
};

#endif // MEINKLEINESHAUPTMENUE_H