//alle_gamestates.h
#ifndef ALLEGAMESTATESZUSAMMENGEFASST_H
#define ALLEGAMESTATESZUSAMMENGEFASST_H

//abstrakte Basisklasse
#include "gamestate.h"
// die einzelnen Gamestates
#include "hauptmenu.h"
#include "spiel.h"

#endif // ALLEGAMESTATESZUSAMMENGEFASST_H