//funktionen.h
#ifndef NUETZLICHEFUNKTIONEN_H
#define NUETZLICHEFUNKTIONEN_H

#include "eimer.h"
#include "hud.h"
#include "punktwertanzeige.h"
#include <list>
#include <SFML/Audio.hpp>

void speicher_freigeben(std::list<Eimer*>::iterator beg, std::list<Eimer*>::iterator end);
bool hauptmenu_animation(sf::Sprite &fadenkreuz, sf::Sprite &titel, sf::Sprite &rechte_wand, sf::Sprite &linke_wand,
						 const sf::Image &hintergrund_bild, const sf::SoundBuffer &trommel_buffer, sf::String &menupunkt_1, 
						 sf::String &menupunkt_2, sf::String &menupunkt_3, sf::RenderWindow &fenster);
bool schuss_auf_eimer(std::list<Eimer*>::iterator beg, std::list<Eimer*>::iterator end,
					  std::list<Punktwertanzeige> &punktwert_liste, HUD &hud, const float maus_x, const float maus_y);
void bewege_eimer(std::list<Eimer*>::iterator beg, std::list<Eimer*>::iterator end, const float frame_zeit);
void eimer_loeschen(std::list<Eimer*> &eimer_liste, const sf::RenderWindow &fenster);
void punktwert_loeschen(std::list<Punktwertanzeige> &punktwert_liste);
void zeichne_eimer(std::list<Eimer*>::reverse_iterator beg, std::list<Eimer*>::reverse_iterator end, sf::RenderWindow &fenster);
void zeichne_punktwerte(std::list<Punktwertanzeige>::iterator beg, std::list<Punktwertanzeige>::iterator end, sf::RenderWindow &fenster);
void spielende(const long int punkte, const unsigned int meiste_treffer, sf::Sprite &fadenkreuz,sf::Sprite &hintergrund,
			   sf::RenderWindow &fenster);

#endif // NUETZLICHEFUNKTIONEN_H