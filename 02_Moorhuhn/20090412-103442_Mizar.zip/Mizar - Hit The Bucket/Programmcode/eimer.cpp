//eimer.cpp
#include "eimer.h"

const float Eimer::alphawert_abnahme = 350.f;

void Eimer::getroffen()
{
	if(!ist_getroffen) {
		ist_getroffen = true;
	}
	return;
}

sf::FloatRect Eimer::get_rect() const
{
	return sf::FloatRect(eimer_sprite.GetPosition().x,
						 eimer_sprite.GetPosition().y,
						 eimer_sprite.GetPosition().x + eimer_sprite.GetSize().x,
						 eimer_sprite.GetPosition().y + eimer_sprite.GetSize().y);
}

void Eimer::aendere_alphawert(const int alpha_aenderung)
{
	if(eimer_sprite.GetColor().a - alpha_aenderung > 0) {
		eimer_sprite.SetColor(sf::Color(eimer_sprite.GetColor().r,
										eimer_sprite.GetColor().g,
										eimer_sprite.GetColor().b,
										eimer_sprite.GetColor().a - alpha_aenderung));
	} else {
		eimer_sprite.SetColor(sf::Color(eimer_sprite.GetColor().r,
										eimer_sprite.GetColor().g,
										eimer_sprite.GetColor().b,
										0));
	}
	return;
}

void Eimer::zeichnen(sf::RenderWindow &fenster)
{
	if(ist_getroffen && get_alphawert() != 0) {
		aendere_alphawert(static_cast<int>(alphawert_abnahme * fenster.GetFrameTime()));
	}
	fenster.Draw(eimer_sprite);
	return;
}