//trefferanzeige.h
#ifndef ZEIGTANZAHLDERTREFFERINFOLGEAN_H
#define ZEIGTANZAHLDERTREFFERINFOLGEAN_H

#include <SFML/Graphics.hpp>

class Trefferanzeige {
public:
	// Konstruktor
	Trefferanzeige(const unsigned int fenster_grenze_x, const unsigned int fenster_grenze_y, const unsigned int starttreffer = 0):
	treffer_anzeige("Hits: 000", sf::Font::GetDefaultFont(), 30.f),
	anzahl_treffer_in_folge(starttreffer)
	{
		treffer_anzeige.SetPosition(fenster_grenze_x * 0.99f - treffer_anzeige.GetRect().GetWidth(), // ab 99% der Fensterbreite zeichnen
								    fenster_grenze_y * 0.90f - treffer_anzeige.GetSize());  // ab 95% der Fensterh�he zeichnen
		treffer_anzeige.SetColor(sf::Color(255, 0, 0, 0)); // Alphawert 0, siehe definition von set_treffer_in_folge
	}
	// Setter
	void set_treffer_in_folge(const unsigned int treffer);
	// Getter
	unsigned int get_treffer_in_folge() const { return anzahl_treffer_in_folge; }
	// weitere Funktionen
	void zeichnen(sf::RenderWindow &fenster, const int alpha_aenderung);
private:
	sf::String treffer_anzeige;
	unsigned int anzahl_treffer_in_folge;
	static const int start_alpha;
	static const int farb_aenderung;
};

#endif // ZEIGTANZAHLDERTREFFERINFOLGEAN_H