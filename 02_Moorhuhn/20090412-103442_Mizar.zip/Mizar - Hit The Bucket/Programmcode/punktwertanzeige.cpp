//punktwertanzeige.cpp
#include "punktwertanzeige.h"

void Punktwertanzeige::zeichnen(sf::RenderWindow &fenster, const int alpha_aenderung)
{
	// bewege Punktwert
	punktwert_anzeige.Move(0.f, speed_y * fenster.GetFrameTime());
	// senke Alphawert
	if(punktwert_anzeige.GetColor().a - alpha_aenderung > 0) {
		punktwert_anzeige.SetColor(sf::Color(punktwert_anzeige.GetColor().r,
											 punktwert_anzeige.GetColor().g,
											 punktwert_anzeige.GetColor().b,
											 punktwert_anzeige.GetColor().a - alpha_aenderung));
	} else {
		punktwert_anzeige.SetColor(sf::Color(punktwert_anzeige.GetColor().r,
											 punktwert_anzeige.GetColor().g,
											 punktwert_anzeige.GetColor().b,
											 0));
	}
	fenster.Draw(punktwert_anzeige);
	return;
}