//spiel.cpp
#include "spiel.h"
#include "alle_eimer.h"
#include "funktionen.h"
#include "hud.h"
#include "punktwertanzeige.h"
#include "trefferanzeige.h"
#include <list>

int Spiel::ausfuehren(sf::RenderWindow &fenster)
{
	// Lade das Bild f�r das Fadenkreuz und erstelle ein sf::Sprite
	sf::Image fadenkreuz_bild;
	if(!fadenkreuz_bild.LoadFromFile("img\\fadenkreuz.png")) {
		return -1;
	}
	sf::Sprite fadenkreuz(fadenkreuz_bild);
	// Lade das Hintergrundbild
	sf::Image hintergrund_bild;
	if(!hintergrund_bild.LoadFromFile("img\\bucket_hintergrund.jpg")) {
		return -1;
	}
	sf::Sprite hintergrund(hintergrund_bild);
	// Lade die Bilder der einzelnen Eimer und erstelle eine Eimerliste
	sf::Image norm_eimer_bild;
	if(!norm_eimer_bild.LoadFromFile("img\\normaler_eimer.png")) {
		return -1;
	}
	sf::Image gold_eimer_bild;
	if(!gold_eimer_bild.LoadFromFile("img\\goldener_eimer.png")) {
		return -1;
	}
	sf::Image rot_eimer_bild;
	if(!rot_eimer_bild.LoadFromFile("img\\roter_eimer.png")) {
		return -1;
	}
	std::list<Eimer*> eimer_liste;
	std::list<Eimer*> rote_eimer;
	// Erstelle Zeitelemente f�r die Kreierung neuer Eimer
	float neuer_eimer = 0.f;
	sf::Clock eimer_timer;
	eimer_timer.Reset();
	float roter_neuer_eimer = 0.f;
	sf::Clock roter_eimer_timer;
	roter_eimer_timer.Reset();
	// Erstelle HUD
	sf::Image munitions_bild;
	if(!munitions_bild.LoadFromFile("img\\ziegelstein.png")) {
		return -1;
	}
	HUD hud(fenster.GetWidth(), fenster.GetHeight(), munitions_bild, 6, 0, 120.f);
	// Erstelle Anzeige zur Darstellung der Treffer in Folge
	Trefferanzeige treffer_in_folge(fenster.GetWidth(), fenster.GetHeight());
	// Erstelle eine Liste zur Anzeige der erhaltenen Punkte eines getroffenen Eimers
	std::list<Punktwertanzeige> punktwert_liste;
	// Erstelle sf::String der aufs Nachladen hinweist und setze seine Farbe und Position
	sf::String reload_text("RELOAD!", sf::Font::GetDefaultFont(), 46.f);
	reload_text.SetColor(sf::Color(255, 255, 0));
	reload_text.SetPosition(fenster.GetWidth() / 2.f - reload_text.GetRect().GetWidth() / 2.f,
							fenster.GetHeight() / 2.f - reload_text.GetSize() / 2.f);
	// Lade die Metalsounds, die beim treffen eines Eimers abgespielt werden
	sf::SoundBuffer metal_buffer;
	if(!metal_buffer.LoadFromFile("mus\\metal.ogg")) {
		return -1;
	}
	sf::Sound metal_sound(metal_buffer);
	sf::SoundBuffer metal_tief_buffer;
	if(!metal_tief_buffer.LoadFromFile("mus\\metal_b.ogg")) {
		return -1;
	}
	sf::Sound metal_tief_sound(metal_tief_buffer);
	// Lade den Sound f�rs Nachladen
	sf::SoundBuffer nachladen_buffer;
	if(!nachladen_buffer.LoadFromFile("mus\\nachladen.ogg")) {
		return -1;
	}
	sf::Sound nachladen_sound(nachladen_buffer);
	// Erstelle ein sf::Music-Objekt f�r die Hintergundmusik
	sf::Music hintergrund_musik;
	if(!hintergrund_musik.OpenFromFile("mus\\hintergrundmucke.ogg")) {
		return -1;
	}
	hintergrund_musik.SetLoop(true);
	hintergrund_musik.Play();
	// Erstelle eine Variable in der die meisten Treffer in folge gez�hlt werden
	unsigned int meiste_treffer = 0;
	// Erstelle sf::Event zur Abarbeitung von Eingaben
	sf::Event eingabe;
	// Hauptschleife des Spiels
	while(fenster.IsOpened()) {
		// Aktualisiere Mauscursorkoordinate
		aktualisiere_mauskoordinaten(fenster);
		// Aktualisiere Fadenkreuzposition
		fadenkreuz.SetPosition(maus_x - fadenkreuz.GetSize().x / 2.f, maus_y - fadenkreuz.GetSize().y / 2.f);
		// Erstellung neuer Eimer:
		// Ist Liste leer oder Zeitpunkt f�r neue Eimer erreicht -> Erstelle Eimer
		if(eimer_liste.size() == 0 || eimer_timer.GetElapsedTime() > neuer_eimer) {
			// Enth�lt Liste mehr als 30 Elemente, dann f�ge nichts mehr hinzu (nur zur Sicherheit)
			if(eimer_liste.size() <= 30) {
				int zufalls_eimer = sf::Randomizer::Random(0, 10);
				// Bestimme ob normaler oder goldener Eimer erstellt wird
				if(zufalls_eimer < 10) {
					eimer_liste.push_back(new NormalerEimer(norm_eimer_bild, fenster.GetWidth(), fenster.GetHeight()));
				} else {
					eimer_liste.push_back(new GoldenerEimer(gold_eimer_bild, fenster.GetWidth(), fenster.GetHeight()));
				}
				// setze neuen Zeitpunkt zur Eimererstellung und starte Zeitlimit
				neuer_eimer = sf::Randomizer::Random(0.4f, 1.1f);
				eimer_timer.Reset();
			}
		}
		// Erstelle roten Eimer
		if(rote_eimer.size() == 0 || roter_eimer_timer.GetElapsedTime() > roter_neuer_eimer) {
			rote_eimer.push_back(new RoterEimer(rot_eimer_bild, fenster.GetWidth()));
			// setze neuen Zeitpunkt zur Eimererstellung und starte Zeitlimit
			roter_neuer_eimer = sf::Randomizer::Random(0.5f, 1.f);
			roter_eimer_timer.Reset();
		}
		// Schleife zur Abarbeitung der Eingaben
		while(fenster.GetEvent(eingabe)) {
			// Wurde das Schlie�ensymbol angeklickt oder ESCAPE gedr�ckt, beende die Anwendung (und Speicher freigeben)
			if(eingabe.Type == sf::Event::Closed || fenster.GetInput().IsKeyDown(sf::Key::Escape)) {
				speicher_freigeben(eimer_liste.begin(), eimer_liste.end());
				speicher_freigeben(rote_eimer.begin(), rote_eimer.end());
				hintergrund_musik.Stop();
				return -1;
			}
			// Wurde die Leertaste gedr�ckt und Munition war nicht voll -> nachladen
			if(hud.munition_get_schuesse() != hud.munition_get_max_schuesse() && eingabe.Type == sf::Event::KeyPressed && eingabe.Key.Code == sf::Key::Space) {
				hud.munition_nachladen();
				nachladen_sound.Play(); // Spiele Sound f�rs Nachladen
			}
			// Hat Spieler mindestens noch eine Munitionseinheit und wurde die linke Maustaste gedr�ckt -> schie�en
			if(hud.munition_get_schuesse() > 0 && eingabe.Type == sf::Event::MouseButtonPressed && eingabe.MouseButton.Button == sf::Mouse::Left) {
				// Spieler wird eine Munitionseinheit abgezogen
				hud.munition_schiessen();
				// �berpr�fe zuerst ob ein roter Eimer getroffen wurde, wenn nicht dann �berpr�fe ob ein
				// anderer Eimer getroffen wurde
				if(schuss_auf_eimer(rote_eimer.begin(), rote_eimer.end(), punktwert_liste, hud, maus_x, maus_y)) {
					// Wurde roter Eimer getroffen fallen die Treffer in Folge zur�ck auf 0
					treffer_in_folge.set_treffer_in_folge(0);
					metal_tief_sound.Play(); // Spiele tiefen Soundeffekt wegen getroffenem roten Eimer
				} else if(schuss_auf_eimer(eimer_liste.begin(), eimer_liste.end(), punktwert_liste, hud, maus_x, maus_y)) {
					// Wurde ein normaler oder goldener Eimer getroffen erh�hen sich die Treffer in Folge um 1
					treffer_in_folge.set_treffer_in_folge(treffer_in_folge.get_treffer_in_folge() + 1);
					metal_sound.Play(); // Spiele normalen Soundeffekt wegen getroffenem normalen / goldenen Eimer
					// �berpr�fe ob es mehr Treffer in folge gab als zuvor. Aktualisiere ggf. die meiste_treffer-Variable
					if(treffer_in_folge.get_treffer_in_folge() > meiste_treffer) {
						meiste_treffer = treffer_in_folge.get_treffer_in_folge();
					}
				} else {
					// Wurde gar kein Eimer getroffen fallen die Treffer in Folge auch wieder auf 0 zur�ck
					treffer_in_folge.set_treffer_in_folge(0);
				}
			}
		}
		// Ist das Zeitlimit abgelaufen, gib Speicher wieder frei, zeige Errungenschaft an und beende Anwendung
		if(hud.zeit_get_restsekunden() <= 0.f) {
			speicher_freigeben(eimer_liste.begin(), eimer_liste.end());
			speicher_freigeben(rote_eimer.begin(), rote_eimer.end());
			spielende(hud.punkte_get_punkte(), meiste_treffer, fadenkreuz, hintergrund, fenster);
			hintergrund_musik.Stop();
			return -1;
		}
		// Bewege alle Eimer
		bewege_eimer(eimer_liste.begin(), eimer_liste.end(), fenster.GetFrameTime());
		bewege_eimer(rote_eimer.begin(), rote_eimer.end(), fenster.GetFrameTime());
		//�berpr�fe welche Objekte in den Listen gel�scht werden k�nnen und entferne diese
		eimer_loeschen(eimer_liste, fenster);
		eimer_loeschen(rote_eimer, fenster);
		punktwert_loeschen(punktwert_liste);
		// Zeichne alle Objekte
		fenster.Clear(sf::Color(0, 0, 0)); // bereinige Fensterinhalt
		// Zeichne Hintergrund
		fenster.Draw(hintergrund);
		// Zeichne alle Eimer
		// (Reverseiteratoren beim zeichnen verwenden. �ltere Objekte werden beim schie�en vor den neuen Objekten
		//  �berpr�ft, deshalb m�ssen die neuen Objekte hinter den �lteren Objekte gezeichnet werden.)
		zeichne_eimer(eimer_liste.rbegin(), eimer_liste.rend(), fenster);
		// Die roten Eimer werden alle �ber die anderen Eimer gezeichnet
		zeichne_eimer(rote_eimer.rbegin(), rote_eimer.rend(), fenster);
		// Zeichne Anzahl der Treffer in Folge
		treffer_in_folge.zeichnen(fenster, static_cast<int>(100.f * fenster.GetFrameTime())); // 255 ist max. Alphawert, Alphawert�nderung �bergeben
		// Zeichne Punktwerte
		zeichne_punktwerte(punktwert_liste.begin(), punktwert_liste.end(), fenster);
		// Zeichne HUD-Elemente
		hud.zeichnen(fenster);
		// Ist keine Munition mehr �brig -> zeichne Reloadtext
		if(hud.munition_get_schuesse() == 0) {
			fenster.Draw(reload_text);
		}
		// Zeichne Fadenkreuz
		fenster.Draw(fadenkreuz);
		fenster.Display(); // Darstellung des Fensterinhalts
	}
	// Diese Codezeile sollte normalerweise nie erreicht werden, falls doch beende die Anwendung (und Speicher freigeben)
	speicher_freigeben(eimer_liste.begin(), eimer_liste.end());
	speicher_freigeben(rote_eimer.begin(), rote_eimer.end());
	hintergrund_musik.Stop();
	return -1;
}