//punktanzeige.h
#ifndef DIEKLEINEANZEIGEFUERDIEPUNKTE_H
#define DIEKLEINEANZEIGEFUERDIEPUNKTE_H

#include <SFML/Graphics.hpp>

class Punktanzeige {
public:
	// Konstruktor
	Punktanzeige(const unsigned int fenster_grenze_x, const unsigned int fenster_grenze_y, const long int punkte = 0):
	punkte_anzeige("00000", sf::Font::GetDefaultFont(), 40.f),
	punktestand(punkte)
	{
		punkte_anzeige.SetPosition(fenster_grenze_x * 0.98f - punkte_anzeige.GetRect().GetWidth(), // ab 98% der Fensterbreite zeichnen
								   fenster_grenze_y * 0.97f - punkte_anzeige.GetSize());  // ab 97% der Fensterh�he zeichnen
	}
	// Getter
	long int get_punktestand() const { return punktestand; }
	// Funktionen
	void aendere_punktestand(const long int aenderung);
	void zeichnen(sf::RenderWindow &fenster);
private:
	sf::String punkte_anzeige;
	long int punktestand;
};

#endif // DIEKLEINEANZEIGEFUERDIEPUNKTE_H