//punktwertanzeige.h
#ifndef MEINEKLEINEPUNKTWERTANZEIGE_H
#define MEINEKLEINEPUNKTWERTANZEIGE_H

#include <SFML/Graphics.hpp>
#include <sstream>

class Punktwertanzeige {
public:
	// Konstruktor
	Punktwertanzeige(const long int punktwert, float pos_x, float pos_y):
	punktwert_anzeige("", sf::Font::GetDefaultFont(), 30.f),
	speed_y(-100.f)
	{
		std::ostringstream konverter;
		konverter << std::showpos << punktwert; // showpos: zeigt Pluszeichen bei positiven Zahlen an
		punktwert_anzeige.SetText(konverter.str());
		punktwert_anzeige.SetPosition(pos_x - punktwert_anzeige.GetRect().GetWidth() / 2.f,
									  pos_y - punktwert_anzeige.GetSize() / 2.f);
		//Ist Punktwert positiv -> Farbe gr�n und Zahl steigt nach oben, sonst -> Farbe rot und Y-Speed umkehren
		if(punktwert >= 0) {
			punktwert_anzeige.SetColor(sf::Color(0, 255, 0, 255));
		} else {
			punktwert_anzeige.SetColor(sf::Color(255, 0, 0, 255));
			speed_y *= -1;
		}
	}
	// Getter
	int get_alphawert() const { return static_cast<int>(punktwert_anzeige.GetColor().a); }
	// Funktionen
	void zeichnen(sf::RenderWindow &fenster, const int alpha_aenderung);
private:
	sf::String punktwert_anzeige;
	float speed_y;
};

#endif // MEINEKLEINEPUNKTWERTANZEIGE_H