﻿"Invasion der Mathebuecher"

by Marius Stärk


uses SFML 1.4

- Background image from www.wallpaper-area.to
- Sounds & music from www.freesound.org


Windows:

Put the following .dlls in your folder:

- sfml-system.dll
- sfml-window.dll
- sfml-audio.dll
- sfml-graphics.dll
- sfml-network.dll
- openal32.dll
- libsndfile-1.dll

Linux:

Dependencies:

- SFML 1.4
- Glut
- OpenAL
- libsndfile
- libpng