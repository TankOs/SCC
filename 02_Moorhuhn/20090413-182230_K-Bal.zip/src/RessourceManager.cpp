#include "RessourceManager.h"

#include <map>
#include <string>
#include <iostream>

#include <SFML/Graphics.hpp>


// Functions

// ---- Image related ----

bool RessourceManager::pushImage(const std::string& key)
{
    if(!m_Images[key])                                                    // Image not loaded yet
    {
        sf::Image* tempImg = new sf::Image;                               // Allocate Memory for new Image
        if(!tempImg->LoadFromFile(key))
        {
            // TODO: error handling
            delete tempImg;                                               // Image not found -> free Memory
            return false;
        }
        else
        {
            tempImg->CreateMaskFromColor(sf::Color(255,0,255), 0);      // Color key: pink
            tempImg->SetSmooth(false);                                    // No anti-aliasing
            m_Images[key] = tempImg;                                      // Save image
        }
    }
    return true;
}
void RessourceManager::deleteImage(const std::string& key)
{
    if(m_Images[key])
    {
        delete m_Images[key];                           // Free Memory

        ImageMap::iterator it = m_Images.find(key);

        if(it != m_Images.end())                        // Was the key already reserved?
        {
            m_Images.erase(it);                         // It was, so erase the entry
        }
    }
}

sf::Image* RessourceManager::getImage(const std::string& key)
{
    if(m_Images[key])           // Is the image in the container?
    {
        return m_Images[key];   // Yes, return it
    }
    else
    {
        pushImage(key);         // No, so try to load it
    }

    if(m_Images[key])           // Loading successful?
    {
        return m_Images[key];   // Yes, return it
    }
    else
    {
        return 0;               // No, error -> return 0
    }
}

int RessourceManager::getNumImages()
{
    return m_Images.size();
}

// ---- Sound related ----

bool RessourceManager::pushSoundBuffer(const std::string& key)
{
    if(!m_SoundBuffers[key])                                              // Soundbuffer not loaded yet
    {
        sf::SoundBuffer* tempSndBuf = new sf::SoundBuffer;                // Allocate Memory for new SoundBuffer
        if(!tempSndBuf->LoadFromFile(key))
        {
            // TODO: error handling
            delete tempSndBuf;                                            // SoundBuffer not found -> free Memory
            return false;
        }
        else
        {
            m_SoundBuffers[key] = tempSndBuf;                             // Save SoundBuffer
        }
    }
    return true;
}
void RessourceManager::deleteSoundBuffer(const std::string& key)
{
    if(m_SoundBuffers[key])
    {
        delete m_SoundBuffers[key];                           // Free Memory

        SoundBufferMap::iterator it = m_SoundBuffers.find(key);

        if(it != m_SoundBuffers.end())                        // Was the key already reserved?
        {
            m_SoundBuffers.erase(it);                         // It was, so erase the entry
        }
    }
}
sf::SoundBuffer* RessourceManager::getSoundBuffer(const std::string& key)
{
    if(m_SoundBuffers[key])           // Is the SoundBuffer in the container?
    {
        return m_SoundBuffers[key];   // Yes, return it
    }
    else
    {
        pushSoundBuffer(key);         // No, so try to load it
    }

    if(m_SoundBuffers[key])           // Loading successful?
    {
        return m_SoundBuffers[key];   // Yes, return it
    }
    else
    {
        return 0;               // No, error -> return 0
    }
}
int RessourceManager::getNumSoundBuffers()
{
    return m_SoundBuffers.size();
}

// ---- Music related ----

bool RessourceManager::loadSong(const std::string& key)
{
    if(!m_Songs[key])                                        // Song not loaded yet
    {
        sf::Music* tempMusic = new sf::Music;                // Allocate Memory for new sf::Music
        if(!tempMusic->OpenFromFile(key))
        {
            // TODO: error handling
            delete tempMusic;                                // Song not found -> free Memory
            return false;
        }
        else
        {
            m_Songs[key] = tempMusic;                        // Save sf::Music
        }
    }
    return true;
}
void RessourceManager::deleteSong(const std::string& key)
{
    if(m_Songs[key])
    {
        delete m_Songs[key];                           // Free Memory

        MusicMap::iterator it = m_Songs.find(key);

        if(it != m_Songs.end())                        // Was the key already reserved?
        {
            m_Songs.erase(it);                         // It was, so erase the entry
        }
    }
}
void RessourceManager::playSong(const std::string& key)
{
    if(m_Songs[key])           // Is the Song in the container?
    {
        m_Songs[key]->Play();
    }
    else
    {
        loadSong(key);         // No, so try to load it
    }

    if(m_Songs[key])           // Loading successful?
    {
        m_Songs[key]->Play();
    }
}

void RessourceManager::pauseSong(const std::string& key)
{
    if(m_Songs[key])           // Is the Song in the container?
    {
        m_Songs[key]->Pause();
    }
}

void RessourceManager::stopSong(const std::string& key)
{
    if(m_Songs[key])           // Is the Song in the container?
    {
        m_Songs[key]->Stop();
    }
}

int RessourceManager::getNumSongs()
{
    return m_Songs.size();
}

// ---- Font related ----

sf::Font* RessourceManager::getDefaultFont()
{
    if(m_DefaultFont)           // Font already loaded?
    {
        return m_DefaultFont;   // Yes, return it
    }
    return 0;                   // No, return 0
    std::cerr << "Default font not yet loaded" << std::endl;
}

void RessourceManager::setDefaultFont(const std::string& filename, int fontsize)
{
    if(!m_DefaultFont->LoadFromFile(filename, fontsize))
    {
        std::cerr << "Default font not found!" << std::endl;
    }
}

// Constructor / Destructor
RessourceManager::RessourceManager()
{
    m_DefaultFont = new sf::Font();
    setDefaultFont("media/defaultfont.ttf", 30);
}
RessourceManager::~RessourceManager()
{
    for(ImageMap::iterator it = m_Images.begin(); it != m_Images.end(); it++) // Free all of the image memory
    {
        delete it->second;
    }
    // Entries of the map don't have to be deleted because the map won't exist anymore

    for(SoundBufferMap::iterator it = m_SoundBuffers.begin(); it != m_SoundBuffers.end(); it++) // Free all of the image memory
    {
        delete it->second;
    }

    for(MusicMap::iterator it = m_Songs.begin(); it != m_Songs.end(); it++) // Free all of the image memory
    {
        it->second->Stop();
        delete it->second;
    }

    delete m_DefaultFont;
}

