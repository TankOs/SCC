#ifndef __GS_INTRO_H_
#define __GS_INTRO_H_

#include "GameState.h"

class GS_Intro : public GameState
{
    private:
    // Member
    float m_Timer;
    sf::Sprite* m_IntroSprite;

    public:
    // Functions
        static GS_Intro* instance();

        void init();
        void cleanUp();

        void pause();
        void resume();

        void handleEvents(sf::RenderWindow& app, GameEngine& game);
        void update(sf::RenderWindow& app, GameEngine& game);
        void render(sf::RenderWindow& app, GameEngine& game);

    protected:
    // Constructor / Destructor
        GS_Intro();
        ~GS_Intro();
};

#endif
