#ifndef __ENTITY_H_
#define __ENTITY_H_

#include <SFML/Graphics.hpp>

class Entity : public sf::Sprite
{
    protected:
    // Protected Members
        float m_Z, m_Speed, m_RadialVel;
        bool m_IsAlive;

    public:
    // Functions
        virtual void update(float delta) = 0;
        int getScore();

        bool getIsAlive();
        void setIsAlive(bool alive);

        virtual bool checkPointIsIncluded(sf::Vector2f point) = 0;
        virtual bool checkCircleIsIncluded(sf::Vector2f point, float radius) = 0;

    public:
    // Constructor / Destructor
        Entity(float x = 0.f, float z = 1.f, float speed = 10.f, float radialVelocity = 0.f);
        virtual ~Entity();
};

#endif
