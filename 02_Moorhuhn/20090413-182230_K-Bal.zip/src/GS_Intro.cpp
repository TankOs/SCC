#include "GS_Intro.h"
#include "GS_Main.h"
#include "GameEngine.h"
#include "RessourceManager.h"
#include <iostream>

GS_Intro* GS_Intro::instance()
{
    static GS_Intro myInstance;
    return &myInstance;
}

void GS_Intro::init()
{
    m_IntroSprite = new sf::Sprite;
    m_IntroSprite->SetImage(*RessourceManager::instance()->getImage("media/Intro.png"));
    m_IntroSprite->SetPosition(400.f,300.f);
    m_IntroSprite->SetCenter(200.f, 20.f);
}

void GS_Intro::cleanUp()
{
    RessourceManager::instance()->deleteImage("media/Intro.png");
    delete m_IntroSprite;
    m_IntroSprite = NULL;
}

void GS_Intro::render(sf::RenderWindow& app, GameEngine& game)
{
    app.Draw(*m_IntroSprite);
}

void GS_Intro::handleEvents(sf::RenderWindow& app, GameEngine& game)
{
    sf::Event event;
    while(app.GetEvent(event))
    {
        switch(event.Type)                  // Distinguish different event types
        {
            case sf::Event::Closed:         // X was pressed
            {
                app.Close();
                break;
            }
            case sf::Event::KeyPressed:     // ------------ Key input ---------------
            {
                switch(event.Key.Code)
                {
                    case sf::Key::Escape:   // Escape
                    {
                        game.changeState(GS_Main::instance());
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }
            case sf::Event::MouseButtonPressed:
            {
                switch(event.MouseButton.Button)
                {
                    case sf::Mouse::Left:
                    {
                        game.changeState(GS_Main::instance());
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }

            default:
            {
                break;
            }
        }
    }
}

void GS_Intro::update(sf::RenderWindow& app, GameEngine& game)
{
    float delta = app.GetFrameTime();
    float blendtime = 1.f;
    float introtime = 3.f;
    m_Timer += delta;

    if(m_Timer < blendtime)
    {
        m_IntroSprite->SetColor(sf::Color(255, 255, 255, 255*(1.f - (blendtime-m_Timer)/blendtime)));
    }

    if(m_Timer > introtime)
    {
        game.changeState(GS_Main::instance());
    }
}

void GS_Intro::pause()
{}

void GS_Intro::resume()
{}


GS_Intro::GS_Intro()
: GameState(), m_Timer(0.f)
{

}

GS_Intro::~GS_Intro()
{}
