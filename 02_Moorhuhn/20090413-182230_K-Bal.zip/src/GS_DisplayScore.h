#ifndef __GS_DISPLAYSCORE_H_
#define __GS_DISPLAYSCORE_H_

#include "GameState.h"
#include <SFML/Graphics.hpp>

class GS_DisplayScore : public GameState
{
    private:
    // Member
        float m_Timer, m_Score;
        sf::String m_ScoreString;

    public:
    // Functions
        static GS_DisplayScore* instance();

        void init();
        void cleanUp();

        void pause();
        void resume();

        void handleEvents(sf::RenderWindow& app, GameEngine& game);
        void update(sf::RenderWindow& app, GameEngine& game);
        void render(sf::RenderWindow& app, GameEngine& game);

        void setScore(int score);

    protected:
    // Constructor / Destructor
        GS_DisplayScore();
        ~GS_DisplayScore();
};

#endif


