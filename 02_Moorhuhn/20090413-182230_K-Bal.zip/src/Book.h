#ifndef __BOOK_H_
#define __BOOK_H_

#include "Entity.h"

class Book : public Entity
{
    private:
    // Member
    sf::Vector2f m_Size;

    public:
    // Functions
    void update(float delta);
    bool checkPointIsIncluded(sf::Vector2f point);
    bool checkCircleIsIncluded(sf::Vector2f point, float radius);

    public:
    // Constructor / Destructor
        Book(float x = 0.f, float z = 1.f, float speed = 10.f, float radialVelocity = 0.f, sf::Color color = sf::Color::White);
        virtual ~Book();
};

#endif
