#ifndef __GS_MAIN_H_
#define __GS_MAIN_H_

#include "GameState.h"
#include "Entity.h"
#include <vector>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

typedef std::vector<Entity*> EntityVector;

class GS_Main : public GameState
{
    private:
    // Member
        float m_Timer, m_Playtime, m_Spawntime, m_Spawncounter;
        int m_DegOfDumbness;
        int m_Score, m_Ammo, m_MaxAmmo;

        sf::Sprite* m_BackgroundSprite;
        sf::Sprite* m_BulletSprites[5];
        sf::Sprite* m_CrosshairSprite;
        sf::Sprite* m_DumbbrickSprites[10];

        EntityVector m_Entities;

        sf::String* m_ScoreString;
        sf::String* m_TimeString;
        sf::String* m_DumbnessString;

        sf::Sound* m_GunShotSound;
        sf::Sound* m_GunReloadSound;
        sf::Sound* m_GunEmptySound;


    public:
    // Functions
        static GS_Main* instance();

        void init();
        void cleanUp();

        void pause();
        void resume();

        void handleEvents(sf::RenderWindow& app, GameEngine& game);
        void update(sf::RenderWindow& app, GameEngine& game);
        void render(sf::RenderWindow& app, GameEngine& game);

        void reload();

    protected:
    // Constructor / Destructor
        GS_Main();
        ~GS_Main();
};

#endif
