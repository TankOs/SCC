#ifndef __GAMEENGINE_H_
#define __GAMEENGINE_H_


#include "GameState.h"
#include <stack>
#include <SFML/Graphics.hpp>

typedef std::stack<GameState*> StateStack;



class GameEngine
{
    private:
    // Member
        StateStack m_GameStates;
        sf::RenderWindow m_App;

    public:
    // Functions
    // ---- Init, Main Loop & CleanUp ----
        void init();
        void doMainLoop();
        void cleanUp();

    // ---- Game State Related ----
        void changeState(GameState* newState);
        void pushState(GameState* newState);
        void popState();

    private:
    // Functions
    // ---- Rendering & Logic ----
        void handleEvents();
        void update();
        void render();

    public:
    // Constructor / Destructor
        GameEngine();
        ~GameEngine();
};

#endif
