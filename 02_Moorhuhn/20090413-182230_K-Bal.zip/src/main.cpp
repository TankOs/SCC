#include "GameEngine.h"
#include <SFML/Window.hpp>
#include "RessourceManager.h"

int main()
{
    GameEngine game;

    RessourceManager::instance()->playSong("media/music.ogg");

    game.init();
    game.doMainLoop();
    game.cleanUp();

    RessourceManager::instance()->stopSong("media/music.ogg");

    return 0;
}
