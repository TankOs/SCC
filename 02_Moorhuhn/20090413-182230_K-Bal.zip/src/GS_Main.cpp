#include "GS_Main.h"
#include "GS_DisplayScore.h"
#include "GameEngine.h"
#include "Book.h"
#include "RessourceManager.h"
#include <iostream>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <iomanip>
#include "time.h"

GS_Main* GS_Main::instance()
{
    static GS_Main myInstance;
    return &myInstance;
}

void GS_Main::init()
{
    m_BackgroundSprite = new sf::Sprite;
    m_CrosshairSprite = new sf::Sprite;

    m_ScoreString = new sf::String("", *RessourceManager::instance()->getDefaultFont());
    m_TimeString = new sf::String("", *RessourceManager::instance()->getDefaultFont());
    m_DumbnessString = new sf::String("Grad der Verdummung", *RessourceManager::instance()->getDefaultFont());

    m_GunShotSound = new sf::Sound(*RessourceManager::instance()->getSoundBuffer("media/gunshot.wav"));
    m_GunReloadSound = new sf::Sound(*RessourceManager::instance()->getSoundBuffer("media/gunreload.wav"));
    m_GunEmptySound = new sf::Sound(*RessourceManager::instance()->getSoundBuffer("media/gunempty.wav"));

    for(int i = 0; i < m_MaxAmmo; i++)
    {
        m_BulletSprites[i] = new sf::Sprite;
        m_BulletSprites[i]->SetImage(*RessourceManager::instance()->getImage("media/bullet.png"));
        m_BulletSprites[i]->SetPosition((22.f * i) + 600.f, 550.f);
    }

    for(int i = 0; i < 10; i++)
    {
        m_DumbbrickSprites[i] = new sf::Sprite;
        m_DumbbrickSprites[i]->SetImage(*RessourceManager::instance()->getImage("media/dumbbrick.png"));
        m_DumbbrickSprites[i]->SetPosition(8.f, 540.f - (i * 12.f));
    }


    m_ScoreString->SetPosition(400.f, 555.f);
    m_ScoreString->SetColor(sf::Color::Black);
    m_TimeString->SetPosition(250.f, 555.f);
    m_TimeString->SetColor(sf::Color::Black);
    m_DumbnessString->SetPosition(8.f, 555.f);
    m_DumbnessString->SetColor(sf::Color::Black);

    m_BackgroundSprite->SetImage(*RessourceManager::instance()->getImage("media/background.png"));
    m_BackgroundSprite->SetPosition(0.f, 0.f);

    m_CrosshairSprite->SetImage(*RessourceManager::instance()->getImage("media/crosshair.png"));
    m_CrosshairSprite->SetCenter(16.f, 16.f);
    m_CrosshairSprite->SetColor(sf::Color::Black);

}

void GS_Main::cleanUp()
{
    m_GunShotSound->Stop();
    m_GunEmptySound->Stop();
    m_GunReloadSound->Stop();

    delete m_BackgroundSprite;
    delete m_CrosshairSprite;
    delete m_ScoreString;
    delete m_TimeString;
    delete m_DumbnessString;
    delete m_GunShotSound;
    delete m_GunReloadSound;
    delete m_GunEmptySound;

    for(int i = 0; i < m_MaxAmmo; i++)
    {
        delete m_BulletSprites[i];
    }

    for(int i = 0; i < 10; i++)
    {
        delete m_DumbbrickSprites[i];
    }
}

void GS_Main::render(sf::RenderWindow& app, GameEngine& game)
{
    app.Draw(*m_BackgroundSprite);

    for(int i = 0; i < m_Ammo; i++)
    {
        app.Draw(*m_BulletSprites[i]);
    }


    for(int i = 0; i < m_DegOfDumbness; i++)
    {
        app.Draw(*m_DumbbrickSprites[i]);
    }



    for(EntityVector::iterator it = m_Entities.begin(); it != m_Entities.end(); it++)
    {
        if((*it)->getIsAlive())
        {
            app.Draw(**it);
        }
    }

    app.Draw(*m_DumbnessString);

    app.Draw(*m_ScoreString);
    app.Draw(*m_TimeString);
    app.Draw(*m_CrosshairSprite);
}

void GS_Main::handleEvents(sf::RenderWindow& app, GameEngine& game)
{
    sf::Event event;
    while(app.GetEvent(event))
    {
        switch(event.Type)                  // Distinguish different event types
        {
            case sf::Event::Closed:         // X was pressed
            {
                cleanUp();
                app.Close();
                break;
            }
            case sf::Event::KeyPressed:     // ------------ Key input ---------------
            {
                switch(event.Key.Code)
                {
                    case sf::Key::Escape:   // Escape
                    {
                        GS_DisplayScore::instance()->setScore(m_Score);
                        game.changeState(GS_DisplayScore::instance());
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }
            case sf::Event::MouseButtonPressed:
            {
                switch(event.MouseButton.Button)
                {
                    case sf::Mouse::Left:
                    {
                        if(m_Ammo > 0)
                        {
                            m_GunShotSound->Stop();
                            m_GunShotSound->Play();

                            float mouse_x = app.GetInput().GetMouseX();
                            float mouse_y = app.GetInput().GetMouseY();
                            bool test = false;


                            for(EntityVector::iterator it = m_Entities.begin(); it != m_Entities.end(); it++)
                            {
                                if((*it)->checkCircleIsIncluded(sf::Vector2f(mouse_x, mouse_y), 16.f))
                                {
                                    m_Score += (*it)->getScore();
                                    delete *it;
                                    it = m_Entities.erase(it);
                                    m_Spawntime -= 0.0035f;
                                    test = true;
                                    break;
                                }
                            }

                            if(!test)
                            {
                                m_Spawntime += 0.007f;
                            }

                            m_Ammo--;
                            if(m_Ammo < 0)
                            {
                                m_Ammo = 0;
                            }
                        }
                        else
                        {
                            m_GunEmptySound->Stop();
                            m_GunEmptySound->Play();
                        }
                        break;
                    }
                    case sf::Mouse::Right:
                    {
                        if(m_Ammo < m_MaxAmmo)
                        {
                            m_GunReloadSound->Stop();
                            m_GunReloadSound->Play();

                            reload();
                        }
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }
            case sf::Event::MouseMoved:
            {
                m_CrosshairSprite->SetPosition(app.GetInput().GetMouseX(), app.GetInput().GetMouseY());
                break;
            }

            default:
            {
                break;
            }
        }
    }
}

void GS_Main::update(sf::RenderWindow& app, GameEngine& game)
{
    float delta = app.GetFrameTime();
    m_Timer += delta;

    for(EntityVector::iterator it = m_Entities.begin(); it != m_Entities.end(); it++)
    {
        (*it)->update(delta);
        if((*it)->GetPosition().y > 580)
        {
            delete *it;
            it = m_Entities.erase(it);
            m_DegOfDumbness--;
        }
    }

    // ---- Book Spawning ----
    if(m_Timer > m_Spawncounter)
    {
        srand ( time(NULL) + rand());

        float rand1 = rand() % 700 + 50;                // x
        float rand2 = rand() % 3 + 2;                   // z
        float rand3 = rand() % 30 + 150 - (10*rand2);   // Vel
        float rand4 = rand() % 510 - 255;               // Omega

        m_Entities.push_back(new Book(rand1, rand2, rand3, rand4, sf::Color((rand2*30)+150, rand3, rand4)));
        m_Spawncounter += m_Spawntime;
    }

    // ---- Update sf::Strings ----
    std::stringstream tempText1("");
    std::stringstream tempText2("");

    tempText1 << "Punkte: " << m_Score;

    m_ScoreString->SetText(tempText1.str());

    tempText2 << std::fixed << std::setprecision(0) <<  "Zeit: " << m_Playtime-m_Timer;

    m_TimeString->SetText(tempText2.str());


    // ---- End of Game ----
    if((m_Timer > m_Playtime) || (m_DegOfDumbness <= 0))
    {
        GS_DisplayScore::instance()->setScore(m_Score);
        game.changeState(GS_DisplayScore::instance());
    }
}

void GS_Main::pause()
{}

void GS_Main::resume()
{}

void GS_Main::reload()
{
    m_Ammo = m_MaxAmmo;
}


GS_Main::GS_Main()
: GameState(),
m_Timer(0.f),
m_Playtime(90.f),
m_Spawntime(0.8f),
m_Spawncounter(0.3f),
m_DegOfDumbness(10),
m_Score(0),
m_Ammo(5),
m_MaxAmmo(5)
{

}

GS_Main::~GS_Main()
{

}

