#ifndef __GS_HIGHSCORELIST_H_
#define __GS_HIGHSCORELIST_H_

#include "GameState.h"
#include <set>

class GS_Highscorelist : public GameState
{
    private:
    // Member
        float m_Timer;
        std::multiset<int> m_Scores;
        sf::String m_ScoreString;

    public:
    // Functions
        static GS_Highscorelist* instance();

        void init();
        void cleanUp();

        void pause();
        void resume();

        void handleEvents(sf::RenderWindow& app, GameEngine& game);
        void update(sf::RenderWindow& app, GameEngine& game);
        void render(sf::RenderWindow& app, GameEngine& game);

        void putScoreEntry(int score);
    public:
        void saveHighScoreList();
        void loadHighScoreList();

    protected:
    // Constructor / Destructor
        GS_Highscorelist();
        ~GS_Highscorelist();
};

#endif

