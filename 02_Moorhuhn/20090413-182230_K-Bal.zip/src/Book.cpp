#include "Book.h"
#include "Entity.h"
#include "RessourceManager.h"
#include <iostream>

void Book::update(float delta)
{
    if(m_IsAlive)
    {
        float dy = delta*m_Speed;
        float dw = delta*m_RadialVel;

        this->SetPosition(this->GetPosition() + sf::Vector2f(0.f, dy));
        this->SetRotation(this->GetRotation() + dw);
    }
}

bool Book::checkPointIsIncluded(sf::Vector2f point)
{
    sf::Vector2f transformed = this->TransformToLocal(point);

    if(transformed.x < -m_Size.x/2.f || transformed.x > m_Size.x/2.f)
    {
        return false;
    }
    if(transformed.y < -m_Size.y/2.f || transformed.y > m_Size.y/2.f)
    {
        return false;
    }
    return true;
}

bool Book::checkCircleIsIncluded(sf::Vector2f point, float radius)
{
    sf::Vector2f transformed = this->TransformToLocal(point);
    if(((transformed.x + radius) < 0.f) || ((transformed.x - radius) > 50.f))
    {
        return false;
    }
    if(((transformed.y + radius) < 0.f) || ((transformed.y - radius) > 70.f))
    {
        return false;
    }
    return true;
}

Book::Book(float x, float z, float speed, float radialVelocity, sf::Color color)
: Entity(x, z, speed, radialVelocity)
{
    this->SetImage(*RessourceManager::instance()->getImage("media/book.png"));
    this->SetColor(color);
    this->SetScale(2.f/z, 2.f/z);
    this->SetCenter(50.f/z,70.f/z);
    m_Size = this->GetSize();
}

Book::~Book()
{}
