#ifndef __GAMESTATE_H
#define __GAMESTATE_H

#include <SFML/Graphics.hpp>

class GameEngine;

class GameState
{
    public:
    // Functions
        virtual void init() = 0;
        virtual void cleanUp() = 0;

        virtual void pause() = 0;
        virtual void resume() = 0;

        virtual void handleEvents(sf::RenderWindow& app, GameEngine& game) = 0;
        virtual void update(sf::RenderWindow& app, GameEngine& game) = 0;
        virtual void render(sf::RenderWindow& app, GameEngine& game) = 0;


    protected:
    // Constructor / Destructor
        GameState();
        virtual ~GameState();
};

#endif


