#include "GS_Highscorelist.h"
#include "GameEngine.h"
#include "RessourceManager.h"
#include <iostream>
#include <fstream>
#include <sstream>

GS_Highscorelist* GS_Highscorelist::instance()
{
    static GS_Highscorelist myInstance;
    return &myInstance;
}

void GS_Highscorelist::init()
{
    m_ScoreString.SetPosition(360.f, 40.f);
}

void GS_Highscorelist::cleanUp()
{

}

void GS_Highscorelist::render(sf::RenderWindow& app, GameEngine& game)
{
    app.Draw(m_ScoreString);
}

void GS_Highscorelist::handleEvents(sf::RenderWindow& app, GameEngine& game)
{
    sf::Event event;
    while(app.GetEvent(event))
    {
        switch(event.Type)                  // Distinguish different event types
        {
            case sf::Event::Closed:         // X was pressed
            {
                app.Close();
                break;
            }
            case sf::Event::KeyPressed:     // ------------ Key input ---------------
            {
                switch(event.Key.Code)
                {
                    case sf::Key::Escape:   // Escape
                    {
                        app.Close();
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
            }
            case sf::Event::MouseButtonPressed:
            {
                switch(event.MouseButton.Button)
                {
                    case sf::Mouse::Left:
                    {
                        app.Close();
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }

            default:
            {
                break;
            }
        }
    }
}

void GS_Highscorelist::update(sf::RenderWindow& app, GameEngine& game)
{
    float delta = app.GetFrameTime();
    m_Timer += delta;

    std::stringstream scoreStream;

    scoreStream << "Highscores:\n";

    int i = 0;

    for(std::multiset<int>::reverse_iterator it = m_Scores.rbegin(); (it != m_Scores.rend()) && (i < 10); it++)
    {
        scoreStream << "      " << *it << "\n";
        i++;
    }

    m_ScoreString.SetText(scoreStream.str());
}

void GS_Highscorelist::pause()
{}

void GS_Highscorelist::resume()
{}

void GS_Highscorelist::putScoreEntry(int score)
{
    loadHighScoreList();

    m_Scores.insert(score);

    saveHighScoreList();
}

void GS_Highscorelist::loadHighScoreList()
{
    int temp;

    std::ifstream scorefile("highscore.scr", std::ios::binary);
    if(scorefile)
    {
        scorefile.read((char*)&temp, sizeof(int));
    }
    while( !scorefile.eof() )
    {
        m_Scores.insert(temp);
        scorefile.read((char*)&temp, sizeof(int));
    }
}

void GS_Highscorelist::saveHighScoreList()
{
    std::ofstream scorefile("highscore.scr", std::ios::trunc | std::ios::binary);

    int i = 0;

    for(std::multiset<int>::reverse_iterator it = m_Scores.rbegin(); it != m_Scores.rend(); it++)
    {
        if(i == 10)
        {
            break;
        }
        scorefile.write((char*)&(*it), sizeof(int));
        i++;
    }
}

GS_Highscorelist::GS_Highscorelist()
: GameState(), m_Timer(0.f), m_ScoreString("", *RessourceManager::instance()->getDefaultFont())
{

}

GS_Highscorelist::~GS_Highscorelist()
{}


