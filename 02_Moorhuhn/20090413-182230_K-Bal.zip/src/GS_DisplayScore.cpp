#include "GS_DisplayScore.h"
#include "GS_Highscorelist.h"
#include "GameEngine.h"
#include "RessourceManager.h"
#include <iostream>
#include <sstream>

GS_DisplayScore* GS_DisplayScore::instance()
{
    static GS_DisplayScore myInstance;
    return &myInstance;
}

void GS_DisplayScore::init()
{
    std::stringstream tempString("");
    tempString << "Deine Punkte: " << m_Score;
    m_ScoreString.SetText(tempString.str());
    m_ScoreString.SetPosition(320.f, 250.f);
}

void GS_DisplayScore::cleanUp()
{

}

void GS_DisplayScore::render(sf::RenderWindow& app, GameEngine& game)
{
    app.Draw(m_ScoreString);
}

void GS_DisplayScore::handleEvents(sf::RenderWindow& app, GameEngine& game)
{
    sf::Event event;
    while(app.GetEvent(event))
    {
        switch(event.Type)                  // Distinguish different event types
        {
            case sf::Event::Closed:         // X was pressed
            {
                app.Close();
                break;
            }
            case sf::Event::KeyPressed:     // ------------ Key input ---------------
            {
                switch(event.Key.Code)
                {
                    case sf::Key::Escape:   // Escape
                    {
                        GS_Highscorelist::instance()->putScoreEntry(m_Score);
                        game.changeState(GS_Highscorelist::instance());
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
            }
            case sf::Event::MouseButtonPressed:
            {
                switch(event.MouseButton.Button)
                {
                    case sf::Mouse::Left:
                    {
                        GS_Highscorelist::instance()->putScoreEntry(m_Score);
                        game.changeState(GS_Highscorelist::instance());
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
                break;
            }

            default:
            {
                break;
            }
        }
    }
}

void GS_DisplayScore::update(sf::RenderWindow& app, GameEngine& game)
{
    float delta = app.GetFrameTime();
    m_Timer += delta;

    if(m_Timer > 5.f)
    {
        GS_Highscorelist::instance()->putScoreEntry(m_Score);
        game.changeState(GS_Highscorelist::instance());
    }
}

void GS_DisplayScore::pause()
{}

void GS_DisplayScore::resume()
{}

void GS_DisplayScore::setScore(int score)
{
    m_Score = score;
}


GS_DisplayScore::GS_DisplayScore()
: GameState(), m_Timer(0.f), m_Score(0.f), m_ScoreString("", *RessourceManager::instance()->getDefaultFont())
{

}

GS_DisplayScore::~GS_DisplayScore()
{}



