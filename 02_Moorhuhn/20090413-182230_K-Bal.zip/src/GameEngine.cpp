#include "GameEngine.h"
#include "GameState.h"
#include "GS_Intro.h"

// Functions

// ---- Init & CleanUp ----
void GameEngine::init()
{
    changeState(GS_Intro::instance());
}

void GameEngine::doMainLoop()
{
    while(m_App.IsOpened())             // Loop until exit request
    {
        update();                       // Do logic

        m_App.Clear();                  // Clear the screen (black)

        render();                       // Draw stuff

        m_App.Display();                // Display stuff

        handleEvents();                 // Process incoming events
    }
}

void GameEngine::cleanUp()
{
    while ( !m_GameStates.empty() )
    {
		m_GameStates.pop();
	}
}

// ---- Game State Related ----
void GameEngine::changeState(GameState* newState)
{
    if(!m_GameStates.empty())
    {
        m_GameStates.top()->cleanUp();
        m_GameStates.pop();
    }
    m_GameStates.push(newState);
    m_GameStates.top()->init();

}

void GameEngine::pushState(GameState* newState)
{
    if(!m_GameStates.empty())
    {
        m_GameStates.top()->pause();
    }
    m_GameStates.push(newState);
    m_GameStates.top()->init();
}

void GameEngine::popState()
{
    if(!m_GameStates.empty())
    {
        m_GameStates.top()->cleanUp();
        m_GameStates.pop();
    }
    if(!m_GameStates.empty())
    {
        m_GameStates.top()->resume();
    }
}

// ---- Render & Logic ----
void GameEngine::render()
{
    m_GameStates.top()->render(m_App, *this);
}

void GameEngine::handleEvents()
{
    m_GameStates.top()->handleEvents(m_App, *this);
}

void GameEngine::update()
{
    m_GameStates.top()->update(m_App, *this);
}

// Constructor / Destructor
GameEngine::GameEngine()
: m_App()
{
    sf::VideoMode tempVideoMode(800,600,32);

    m_App.Create(tempVideoMode, "Invasion der Mathebuecher", sf::Style::Close);
    m_App.ShowMouseCursor(false);
    m_App.UseVerticalSync(true);
}

GameEngine::~GameEngine()
{

}
