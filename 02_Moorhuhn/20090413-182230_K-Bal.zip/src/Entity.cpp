#include "Entity.h"
#include <cmath>

int Entity::getScore()
{
    return (1.f*m_Z)+(0.2f*m_Speed)+(0.3f*fabs(m_RadialVel));
}

bool Entity::getIsAlive()
{
    return m_IsAlive;
}

void Entity::setIsAlive(bool alive)
{
    m_IsAlive = alive;
}



Entity::Entity(float x, float z, float speed, float radialVelocity)
: m_Z(z), m_Speed(speed), m_RadialVel(radialVelocity), m_IsAlive(true)
{
    this->SetPosition(x, -10.f);
}
Entity::~Entity()
{}
