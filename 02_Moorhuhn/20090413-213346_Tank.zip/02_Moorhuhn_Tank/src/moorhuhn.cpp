#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <sstream>
#include <iomanip>
#include "field.hpp"

const int SCREEN_WIDTH  = 800;
const int SCREEN_HEIGHT = 600;

const float          ENEMY_INTERVAL = 0.8f;
const unsigned long  MAX_ENEMIES = 10;
const unsigned long  MAX_SHOTS = 8;
const unsigned long  TARGET_FRAMERATE = 60;
const float          TIME_LIMIT = 90.f;
const float          MAX_MOVE_SPEED = 9.f;
const float          RELOAD_DELAY = 0.2f;

int main( void ) {
	sf::RenderWindow  wnd( sf::VideoMode( SCREEN_WIDTH, SCREEN_HEIGHT, 32 ), "SCC02 -- Moorhuhn-Klon, von Tank", sf::Style::Fullscreen );
	const sf::Input   &input( wnd.GetInput() );
	sf::Clock         clock;
	float             nextenemy( 0.f );

	sf::Image        img;
	sf::Image        cursorimage;
	sf::Image        ufoimage;
	sf::Image        shellimage;
	sf::SoundBuffer  shotbuffer;
	sf::SoundBuffer  reloadbuffer;
	sf::Font         defaultfont;

	img.LoadFromFile( "media/gfx/backgrounds/bg01.png" );
	cursorimage.LoadFromFile( "media/gfx/cursors/normal.png" );
	ufoimage.LoadFromFile( "media/gfx/enemies/myufo.png" );
	shellimage.LoadFromFile( "media/gfx/ui/shell.png" );
	shotbuffer.LoadFromFile( "media/sfx/shot.ogg" );
	reloadbuffer.LoadFromFile( "media/sfx/reload.ogg" );
	defaultfont.LoadFromFile( "media/gfx/fonts/aardc.ttf", 40 );

	sf::Sprite  cursor( cursorimage );
	sf::Sprite  shell( shellimage );
	cursor.SetCenter( cursorimage.GetWidth() / 2.f, cursorimage.GetHeight() / 2.f );

	sf::String  scorestr( L"000000", defaultfont, 40 );
	scorestr.SetColor( sf::Color( 0, 0, 0 ) );
	scorestr.SetPosition( 5.f, 5.f );

	sf::String  timeleftstr( scorestr );
	sf::String  reloadstr( scorestr );
	sf::String  gameoverstr( scorestr );

	{
		sf::FloatRect  rect( timeleftstr.GetRect() );
		timeleftstr.SetCenter( rect.GetWidth() / 2.f, 0 );
		timeleftstr.SetPosition( SCREEN_WIDTH / 2.f, 5.f );

		reloadstr.SetText( L"Reload!" );
		rect = reloadstr.GetRect();
		reloadstr.SetCenter( rect.GetWidth() / 2.f, rect.GetHeight() / 2.f );
		reloadstr.SetPosition( SCREEN_WIDTH / 2.f, SCREEN_HEIGHT / 2.f );

		gameoverstr.SetText( L"Game Over! Hit Escape to quit." );
		rect = gameoverstr.GetRect();
		gameoverstr.SetCenter( rect.GetWidth() / 2.f, rect.GetHeight() / 2.f );
		gameoverstr.SetPosition( SCREEN_WIDTH / 2.f, SCREEN_HEIGHT / 2.f );
		gameoverstr.SetColor( sf::Color( 255, 255, 255 ) );
	}

	sf::Sound  shot( shotbuffer );
	sf::Sound  reload( reloadbuffer );

	Field  field( sf::FloatRect( 0, 0, wnd.GetWidth(), wnd.GetHeight() ) );
	field.SetBackground( img );
	wnd.SetView( field.GetView() );

	wnd.ShowMouseCursor( false );
	wnd.SetFramerateLimit( TARGET_FRAMERATE );
	wnd.UseVerticalSync( true );

	unsigned long  shotsleft( MAX_SHOTS );
	unsigned long  score( 0 );
	float          timelimit( clock.GetElapsedTime() + TIME_LIMIT );
	float          nextsectick( 0.f );
	float          nextreloadtick( 0.f );
	bool           reloading( false );
	bool           gameover( false );
	unsigned char  blinkvalue( 0 );

	while( wnd.IsOpened() ) {
		sf::Event  event;

		while( wnd.GetEvent( event ) ) {
			switch( event.Type ) {
				case sf::Event::Closed:
					wnd.Close();
					break;

				case sf::Event::KeyPressed:
					if( event.Key.Code == sf::Key::Escape ) {
						wnd.Close();
					}

					break;

				case sf::Event::MouseButtonPressed:
					if( event.MouseButton.Button == sf::Mouse::Left && !gameover ) {
						if( shotsleft > 0 ) {
							if( reloading ) {
								reloading = false;
							}

							shot.Play();

							sf::Vector2f         hitpoint( input.GetMouseX(), input.GetMouseY() );
							const sf::FloatRect  &rect( field.GetView().GetRect() );
							hitpoint.x += rect.Left;
							hitpoint.y += rect.Top;

							unsigned long  killed( field.KillEnemies( hitpoint ) );

							if( killed > 0 ) {
								score += killed * 150;

								std::stringstream  sstr( "" );
								sstr << std::setfill( '0' ) << std::setw( 6 ) << score;
								scorestr.SetText( sstr.str() );
							}

							--shotsleft;
						}
					}
					else if( event.MouseButton.Button == sf::Mouse::Right && !gameover ) {
						if( !reloading && shotsleft < MAX_SHOTS ) {
							reloading = true;
							nextreloadtick = clock.GetElapsedTime() + RELOAD_DELAY;
						}
					}

					break;

				default:
					break;
			}
		}

		// Logic.
		if( !gameover ) {
			field.Update( 1.f );

			if( nextenemy < clock.GetElapsedTime() && field.GetEnemyCount() < MAX_ENEMIES ) {
				sf::Vector2f  position( 0.f - ufoimage.GetWidth(), sf::Randomizer::Random( 0.f, SCREEN_HEIGHT - ufoimage.GetHeight() ) );
				sf::Vector2f  velocity( sf::Randomizer::Random( 2.5f, 7.f ), sf::Randomizer::Random( -1.f, 1.f ) );

				if( sf::Randomizer::Random( 0, 1 ) == 1 ) {
					position.x = img.GetWidth();
					velocity.x *= -1.f;
				}

				field.AddEnemy( Enemy( position, velocity, ufoimage ) );
				nextenemy = clock.GetElapsedTime() + ENEMY_INTERVAL;
			}

			if( reloading ) {
				if( nextreloadtick <= clock.GetElapsedTime() ) {
					++shotsleft;
					if( shotsleft == MAX_SHOTS ) {
						reloading = false;
					}
					else {
						nextreloadtick = clock.GetElapsedTime() + RELOAD_DELAY;
					}

					reload.Play();
				}
			}
		}

		// UI.
		cursor.SetPosition( input.GetMouseX(), input.GetMouseY() );

		if( nextsectick < clock.GetElapsedTime() ) {
			float              elapsed( clock.GetElapsedTime() );
			std::stringstream  sstr( "" );

			sstr << (static_cast<int>( timelimit - elapsed ) / 60)
				<< ":"
				<< std::setfill( '0' ) << std::setw( 2 ) << (static_cast<int>( timelimit - elapsed + 1.f ) % 60)
			;

			if( !gameover ) {
				timeleftstr.SetText( sstr.str() );

				if( elapsed >= timelimit ) {
					gameover = true;
				}
			}

			nextsectick = clock.GetElapsedTime() + 1.f;
		}

		// Check if field is about to be moved.
		{
			sf::Vector2f  movedelta( 0, 0 );

			if( input.GetMouseX() > SCREEN_WIDTH * 0.8f ) {
				movedelta.x = ((input.GetMouseX() - SCREEN_WIDTH * 0.8f) * MAX_MOVE_SPEED) / (SCREEN_WIDTH - SCREEN_WIDTH * 0.8f);
			}
			else if( input.GetMouseX() < SCREEN_WIDTH * 0.2f ) {
				movedelta.x = (MAX_MOVE_SPEED * -1.f) + (input.GetMouseX() * MAX_MOVE_SPEED / (SCREEN_WIDTH * 0.2f));
			}

			field.Move( movedelta );
		}

		// Rendering.
		wnd.SetView( field.GetView() );
		field.Draw( wnd );

		wnd.SetView( wnd.GetDefaultView() ); // Default view for UI stuff etc.

		// Draw shells.
		{
			sf::Color  col( 255, 255, 255, 255 );

			if( shotsleft < 3 && !reloading ) {
				col.a = shotsleft == 0 ? blinkvalue : (blinkvalue + 100 > 255 ? 255 : blinkvalue + 100);
				blinkvalue += 10;

				if( shotsleft == 0 ) {
					reloadstr.SetColor( col );
					wnd.Draw( reloadstr );
				}
			}

			shell.SetColor( col );

			for( unsigned long shellid = 0; shellid < MAX_SHOTS; ++shellid ) {
				sf::Vector2f  shellpos( 15.f + shellid * (shellimage.GetWidth() + 10), SCREEN_HEIGHT - shellimage.GetHeight() - 5.f );
				shell.SetPosition( shellpos );

				if( shellid == shotsleft ) {
					if( shotsleft > 0 || reloading ) {
						col.a = 120;
						shell.SetColor( col );
					}
				}

				wnd.Draw( shell );
			}
		}

		wnd.Draw( scorestr );
		wnd.Draw( timeleftstr );

		if( gameover ) {
			wnd.Draw( gameoverstr );
		}

		wnd.Draw( cursor );

		wnd.Display();
	}

	return 0;
}
