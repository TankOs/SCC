#ifndef __FIELD_HPP__
#define __FIELD_HPP__

#include <list>
#include <SFML/Graphics.hpp>
#include "enemy.hpp"

class Field {
	public:
		Field( const sf::FloatRect &rect );

		void Draw( sf::RenderWindow &target );
		void Update( float factor );

		void SetBackground( sf::Image &image );
		const sf::View &GetView() const;

		void AddEnemy( const Enemy &enemy );
		unsigned long KillEnemies( const sf::Vector2f &position );
		size_t GetEnemyCount() const;

		void Move( const sf::Vector2f &delta );

	private:
		typedef std::list<Enemy>  EnemyCont;

		sf::FloatRect  m_fieldrect;
		sf::View       m_view;
		sf::Sprite     m_background;

		EnemyCont  m_enemies;
};

#endif
