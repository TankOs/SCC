#include <iostream>
#include "field.hpp"

Field::Field( const sf::FloatRect &rect ) :
	m_fieldrect( rect ),
	m_view( rect )
{
}

void Field::Draw( sf::RenderWindow &target ) {
	target.Draw( m_background );

	EnemyCont::iterator  iter( m_enemies.begin() );

	for( ; iter != m_enemies.end(); ++iter ) {
		iter->Draw( target );
	}
}

void Field::SetBackground( sf::Image &image ) {
	m_background.SetImage( image );
	m_view.SetFromRect( m_fieldrect );
}

const sf::View &Field::GetView() const {
	return m_view;
}

void Field::Move( const sf::Vector2f &delta ) {
	const sf::FloatRect  &viewrect( m_view.GetRect() );
	sf::Vector2f         center( m_view.GetCenter() ); // MOO

	if( viewrect.Right + delta.x > m_background.GetImage()->GetWidth() ) {
		center.x = m_background.GetImage()->GetWidth() - m_fieldrect.GetWidth() / 2.f;
	}
	else if( viewrect.Left + delta.x < m_fieldrect.Left ) {
		center.x = m_fieldrect.GetWidth() / 2.f;
	}
	else {
		center.x += delta.x;
	}

	if( viewrect.Bottom + delta.y > m_background.GetImage()->GetHeight() ) {
		center.y = m_background.GetImage()->GetHeight() - m_fieldrect.GetHeight() / 2.f;
	}
	else if( viewrect.Top + delta.y < m_fieldrect.Top ) {
		center.y = m_fieldrect.GetHeight() / 2.f;
	}
	else {
		center.y += delta.y;
	}

	m_view.SetCenter( center );
}

void Field::Update( float factor ) {
	EnemyCont::iterator  iter( m_enemies.begin() );

	while( iter != m_enemies.end() ) {
		iter->Update( factor );

		sf::Vector2f  pos( iter->GetPosition() );

		if( pos.x > m_fieldrect.Left + m_background.GetImage()->GetWidth() ||
				pos.y > m_fieldrect.Top + m_background.GetImage()->GetHeight() ||
				pos.x + iter->GetSprite().GetImage()->GetWidth() < m_fieldrect.Left ||
				pos.y + iter->GetSprite().GetImage()->GetHeight() < m_fieldrect.Top ) {
			iter = m_enemies.erase( iter );
			continue;
		}

		++iter;
	}
}

void Field::AddEnemy( const Enemy &enemy ) {
	m_enemies.push_back( enemy );
}

size_t Field::GetEnemyCount() const {
	return m_enemies.size();
}

unsigned long Field::KillEnemies( const sf::Vector2f &position ) {
	EnemyCont::iterator  iter( m_enemies.begin() );
	unsigned long        killed( 0 );

	while( iter != m_enemies.end() ) {
		const sf::Vector2f  &enemypos( iter->GetSprite().GetPosition() );
		const sf::Vector2f  enemysize( iter->GetSprite().GetImage()->GetWidth(), iter->GetSprite().GetImage()->GetHeight() );

		if( position.x >= enemypos.x && position.x <= enemypos.x + enemysize.x &&
				position.y >= enemypos.y && position.y <= enemypos.y + enemysize.y ) {
			iter = m_enemies.erase( iter );
			++killed;
			break;
		}
		++iter;
	}

	return killed;
}
