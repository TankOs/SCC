#ifndef __ENEMY_HPP__
#define __ENEMY_HPP__

#include <SFML/Graphics.hpp>

class Enemy {
	public:
		Enemy( const sf::Vector2f &position, const sf::Vector2f &velocity, const sf::Image &image );

		void Draw( sf::RenderWindow &target ) const;
		void Update( float factor );

		const sf::Vector2f &GetPosition() const;
		const sf::Sprite &GetSprite() const;

	private:
		sf::Sprite    m_sprite;
		sf::Vector2f  m_velocity;
};

#endif
