#include "enemy.hpp"

Enemy::Enemy( const sf::Vector2f &position, const sf::Vector2f &velocity, const sf::Image &image ) :
	m_sprite( image, position ),
	m_velocity( velocity )
{
}

void Enemy::Draw( sf::RenderWindow &target ) const {
	target.Draw( m_sprite );
}

const sf::Vector2f &Enemy::GetPosition() const {
	return m_sprite.GetPosition();
}

void Enemy::Update( float factor ) {
	m_sprite.Move( m_velocity * factor );
}

const sf::Sprite &Enemy::GetSprite() const {
	return m_sprite;
}
