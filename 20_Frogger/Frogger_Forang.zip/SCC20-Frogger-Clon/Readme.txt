sfml2 61adc51

Beim Starten der .exe gibt es manchmal Probleme. Einfach erneut starten und es m�sste klappen :D