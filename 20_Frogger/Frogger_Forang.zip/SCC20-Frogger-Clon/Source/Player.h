#pragma once

#include <sfml/Graphics.hpp>

class ImageManager;

class Player
{
public:
	Player(ImageManager& ImageMgr, sf::Vector2f Position);

	void Update(float Dt,  sf::FloatRect CameraRect);
	void Draw(sf::RenderTarget& Target);
	void UpdateCamera(sf::FloatRect Rect);
	void SetSpeed(float Speed)
	{
		m_Speed = Speed;
	}
	void SetPosition(sf::Vector2f Pos)
	{
		m_Sprite.SetPosition(Pos);
	}
	sf::Vector2f GetPosition() const
	{
		return m_Sprite.GetPosition();
	}

	sf::FloatRect GetBoundingBox() const
	{
		return sf::FloatRect(m_Sprite.GetPosition() - sf::Vector2f(16, 16), sf::Vector2f(32, 32));
	}
private:
	enum AnimationState
	{
		Normal,
		Blink,
		Move
	};
	sf::Sprite m_Sprite;
	float m_Speed;
	AnimationState m_AnimState;
	sf::Clock m_AnimTimer;
};