#include "Enemy.h"
#include "ImageManager.h"


Enemy::Enemy(Enemy* NextEnemy, ImageManager& ImageMgr, sf::Vector2f StartPosition)
{
	m_NextEnemy = NextEnemy;
	m_Left = StartPosition.x == 0;
	m_IsDead = false;
	int Type = rand() % 20 + 1;
	
	switch(Type)
	{
	case 1:
	case 2:
	case 13:
	case 19:
		m_Sprite.SetImage(*ImageMgr.GetResource("unit01.png"));
		m_Speed = 225;
		break;
	case 3:
	case 4:
	case 14:
		m_Sprite.SetImage(*ImageMgr.GetResource("unit02.png"));
		m_Speed = 90;
		break;
	case 5:
	case 6:
	case 7:
	case 8:
	case 15:
	case 18:
		m_Sprite.SetImage(*ImageMgr.GetResource("unit03.png"));
		m_Speed = 175;
		break;
	case 9:
	case 10:
	case 11:
	case 12:
	case 16:
	case 17:
	case 20:
		m_Sprite.SetImage(*ImageMgr.GetResource("unit04.png"));
		m_Speed = 150;
		break;
	}
	m_Sprite.SetOrigin(m_Sprite.GetSize() / 2.0f);
	if (m_Left)
	{
		m_Sprite.Rotate(180);
	}
	m_Sprite.SetPosition(StartPosition);
}


Enemy::~Enemy()
{
	if (m_NextEnemy)
	{
		delete m_NextEnemy;
		m_NextEnemy = NULL;
	}
}

void Enemy::Update( float Dt )
{
	if (m_NextEnemy)
	{
		m_NextEnemy->Update(Dt);
		if (m_NextEnemy->IsDead())
		{
			delete m_NextEnemy;
			m_NextEnemy = NULL;
		}
	}
	if (m_Left)
	{
		m_Sprite.Move(m_Speed * Dt, 0);
		if (m_NextEnemy)
		{
			if ((m_NextEnemy->GetBackXPos() - m_Sprite.GetPosition().x) <= 50)
			{
				m_Sprite.SetX(m_NextEnemy->GetBackXPos() - 50);
			}
		}
		if (m_Sprite.GetPosition().x > 1000)
		{
			m_IsDead = true;
		}
	}
	else
	{
		m_Sprite.Move(-m_Speed * Dt, 0);
		if (m_NextEnemy)
		{
			if ((m_Sprite.GetPosition().x - m_NextEnemy->GetBackXPos())  <= 50)
			{
				m_Sprite.SetX(m_NextEnemy->GetBackXPos() + 50);
			}
			if (m_Sprite.GetPosition().x < -100)
			{
				m_IsDead = true;
			}
		}
	}
}

void Enemy::Draw( sf::RenderTarget& Target )
{
	if (m_NextEnemy)
	{
		m_NextEnemy->Draw(Target);
	}
	m_Sprite.SetScale(1.0f, 1.0f);
	m_Sprite.SetColor(sf::Color(255,255,255,255));
	Target.Draw(m_Sprite);
}

Enemy* Enemy::TestCollision( sf::FloatRect Rect )
{
	sf::FloatRect MyRect(m_Sprite.GetPosition() - m_Sprite.GetSize() / 2.0f, m_Sprite.GetSize());
	if (MyRect.Intersects(Rect))
	{
		return this;
	}
	else
	{
		if (m_NextEnemy)
		{
			return m_NextEnemy->TestCollision(Rect);
		}
		else
		{
			return NULL;
		}
	}
	
}
