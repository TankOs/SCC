#ifndef GameState_h__
#define GameState_h__


#include <sfml/Window/Event.hpp>

class Game;
class Window;

// Interface f�r einen Zustand/State
class Gamestate
{
public:
	Gamestate(Game& TheGame);
	// Virtueller Destruktor
	virtual ~Gamestate();

	// Initialisiert den Zustand
	// Parameter: Zeiger auf Daten die der Spielzustand �bergeben bekommen soll (z.B �bergibt der Hauptspielzustand dem Highscorezustand die Punktzahl die der Spieler erreicht hat)
	virtual void Init(void* InitializationData) = 0;

	// F�hrt den Spielzustand herunter
	virtual void Exit() = 0;

	// Aktualisiert den Spielzustand
	// Parameter : Vergangangene Zeit seit dem letztdem Frame
	virtual void Update() = 0;

	// Malt den Spielzustand
	virtual void Draw() = 0; 

	virtual void HandleEvent(const sf::Event& Event);


protected:
	Game& m_Game;
	Window& m_Window;
};

#endif // GameState_h__
