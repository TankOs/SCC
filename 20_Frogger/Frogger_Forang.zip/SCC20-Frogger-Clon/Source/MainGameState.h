#pragma once

#include "GameState.h"
#include "Player.h"
#include "Background.h"
#include "EnemyManager.h"
#include "Camera.h"
#include "ImageButton.h"

#include <sstream>

class MainGameState : public Gamestate
{
public:
	MainGameState(Game& TheGame) 
		: Gamestate(TheGame),
		m_LevelLenght(10000),
		m_Player(TheGame.GetImagemanager(), sf::Vector2f(400,m_LevelLenght+70)),
		m_Camera(m_Window, sf::Vector2f(400,m_LevelLenght-200), 800),
		m_EnemyManager(TheGame.GetImagemanager(), 800, m_LevelLenght), m_Background(m_Window),
		m_MaxPlayerPosition(m_LevelLenght+70),		
		m_SlowMotion(false),
		m_MaxNumSlowMotion(0),
		m_CurrentNumSlowMotion(0),
		m_Boost(false),
		m_BoostTime(0),
		m_MaxNumBoost(),
		m_CurrentNumBoost(),
		m_PlayedSpeedUpSound(false),
		m_DistanceText("", TheGame.GetGameFont(), 30),
		m_DescriptionText("", TheGame.GetGameFont(), 30),
		m_Win(false),
		m_WinText("", TheGame.GetGameFont(), 50),
		m_Money(0),
		m_MoneyText("", TheGame.GetGameFont(), 50),
		m_Day(1),
		m_DayText("", TheGame.GetGameFont(), 50),
		m_NextDayButton(sf::Vector2f(580, 450), *TheGame.GetImagemanager().GetResource("GUI/StartNextDay.jpg"), m_DescriptionText, ""),
		m_BuySlowMotionButton(sf::Vector2f(400, 50), *TheGame.GetImagemanager().GetResource("GUI/BuySlowMotion.jpg"), m_DescriptionText, "Ein mal pro Runde kann mit der Leertaste\ndie Zeitlupe aktiviert werden\nKosten: 1000"),
		m_BuyBoostButton(sf::Vector2f(550, 50), *TheGame.GetImagemanager().GetResource("GUI/BuyBoost.jpg"), m_DescriptionText, "Ein mal pro Runde kann mit der Taste B\nein Geschwindigkeitsschub aktiviert werden\nKosten: 1500"),
		m_Lifes(1),
		m_MaxLifes(1),
		m_BuyLifeButton(sf::Vector2f(400, 200), *TheGame.GetImagemanager().GetResource("GUI/BuyLife.jpg"), m_DescriptionText, "Ein exrta Leben pro Tag\nKosten: 2500"),
		m_LifeText("", TheGame.GetGameFont(), 30),
		m_Intro(true),
		m_IntroText("Wo sind die Farben hin?\n Je weiter du kommst,\ndesto mehr Farbe\nkehren zur�ck.", TheGame.GetGameFont(), 50)
	{
		m_GrayScaleShader.reset(new sf::Shader());
		m_GrayScaleShader->LoadFromFile("GrayScale.frag");
		m_GrayScaleShader->SetCurrentTexture("texture");

		m_DistanceText.SetPosition(10,10);
		m_MoneyText.SetPosition(10,50);
		m_DayText.SetPosition(10, 110);
		m_DescriptionText.SetPosition(0, 400);
		m_WinText.SetPosition(50,200);
		m_WinText.SetColor(sf::Color(0,0,200));
		m_LifeText.SetPosition(690, 10);
		m_IntroText.SetPosition(100,200);

		m_NextDayButton.SetCallback(std::tr1::bind(&MainGameState::Restart, this));
		m_BuySlowMotionButton.SetCallback(std::tr1::bind(&MainGameState::UpgradeSlowMotion, this));
		m_BuySlowMotionButton.SetCallback(std::tr1::bind(&MainGameState::UpgradeSlowMotion, this));
		m_BuyBoostButton.SetCallback(std::tr1::bind(&MainGameState::UpgradeBoost, this));
		m_BuyLifeButton.SetCallback(std::tr1::bind(&MainGameState::UpgradeLife, this));

		m_BackgroundMusic.OpenFromFile("Casey LaLonde - Thank You - 03 Double Shot.ogg");
		
	}
	// Virtueller Destruktor
	virtual ~MainGameState() {}

	// Initialisiert den Zustand
	// Parameter: Zeiger auf Daten die der Spielzustand �bergeben bekommen soll (z.B �bergibt der Hauptspielzustand dem Highscorezustand die Punktzahl die der Spieler erreicht hat)
	virtual void Init(void* InitializationData)
	{
		m_Window.SetPostProcessingShader(m_GrayScaleShader);
		Restart();
		m_UpgradeShop = true;
		m_BackgroundMusic.Play();
		m_DistanceText.SetString("Entfernung: 0");
		m_MoneyText.SetString("Geld: 0");
		m_DayText.SetString("Tag: 1");
		m_LifeText.SetString("Leben: 1");
		m_Money = 0;
		m_Day = 1;
		m_Win = false;
		m_Intro = true;
		m_IntroTimer.Reset();
	}

	// F�hrt den Spielzustand herunter
	virtual void Exit()
	{
		m_BackgroundMusic.Stop();
	}

	// Aktualisiert den Spielzustand
	// Parameter : Vergangangene Zeit seit dem letztdem Frame
	virtual void Update()
	{	
		if (m_Intro)
		{
			if (m_IntroTimer.GetElapsedTime() >= 4000)
			{
				m_Intro = false;
			}
			return;
		}
		m_EnemyManager.Update(m_Window.GetFrameTime());
		if (!m_UpgradeShop && !m_Win)
		{
			m_Player.Update(m_Window.GetFrameTime(), m_Camera.GetCameraRect());
			m_Camera.UpdatePlayerPosition(m_Player.GetPosition());
			Enemy* TempEnemy = m_EnemyManager.TestCollision(m_Player.GetBoundingBox());
			if (TempEnemy)
			{
				--m_Lifes;
				std::stringstream SStream;
				SStream << "Leben: " << m_MaxLifes;
				m_LifeText.SetString(SStream.str());
				if (m_Lifes == 0)
				{
					m_Money += static_cast<int>(m_LevelLenght +54 - m_MaxPlayerPosition);
					std::stringstream SStream;
					SStream << "Geld: " << m_Money;
					m_MoneyText.SetString(SStream.str());
					 
					++m_Day;
					SStream.str("");
					SStream << "Tag: " << m_Day;
					m_DayText.SetString(SStream.str());
					 				
					m_SlowMotion = false;
					m_PlayedSpeedUpSound = false;
					m_BackgroundMusic.SetPitch(1.0f);
					m_Window.SetTimeScale(1.0f);
					m_UpgradeShop = true;
				}
				else
				{
					TempEnemy->Die();
					m_Game.GetAudiomanager().PlaySound("explode.wav", 50);
				}

			}
			if (m_Player.GetPosition().y <= -50)
			{
				m_Win = true;
				std::stringstream SStream;
				SStream << "Gl�ckwunsch! Du hast\n" << m_Day << " Tage gebraucht\num Die Farben zur�ck zu holen.";
				m_WinText.SetString(SStream.str());
			}
			float Factor =  m_Player.GetBoundingBox().Top/m_LevelLenght;
			Factor = 1 - Factor;
			m_GrayScaleShader->SetParameter("ColorFactor",Factor*Factor);
			if (m_Player.GetBoundingBox().Top < m_MaxPlayerPosition)
			{
				m_MaxPlayerPosition = m_Player.GetBoundingBox().Top;
				std::stringstream StringStream;
				StringStream << "Entfernung: " << static_cast<int>(m_LevelLenght +54 - m_MaxPlayerPosition);
				m_DistanceText.SetString(StringStream.str());
			}
		}
		m_EnemyManager.UpdateCamera(m_Camera.GetCameraRect());

		if (m_SlowMotion && m_SlowMotionTimer.GetElapsedTime() >= 4000)
		{
			if (!m_PlayedSpeedUpSound)
			{
				m_Game.GetAudiomanager().PlaySound("123438__anomalous_underdog__Slowdown_Short_Up.wav", 100);
				m_PlayedSpeedUpSound = true;
			}			
			if (m_SlowMotion && m_SlowMotionTimer.GetElapsedTime() >= 5000)
			{
				m_SlowMotion = false;
				m_PlayedSpeedUpSound = false;
				m_BackgroundMusic.SetPitch(1.0f);
				m_Window.SetTimeScale(1.0f);
				
			}
		}
		if (m_Boost)
		{
			m_BoostTime += m_Window.GetFrameTime();
			if (m_BoostTime >= 0.5)
			{
				m_BoostTime = 0;
				m_Boost = false;
				m_Player.SetSpeed(100);
			}
		}


	}

	// Malt den Spielzustand
	virtual void Draw()
	{

		m_Background.DrawGameBackground();
		if (m_Intro)
		{
			m_Window.Draw(m_IntroText);
			return;
		}
		m_Camera.Activate();
		if (!m_UpgradeShop && !m_Win)
		{
			m_Player.Draw(m_Window);
		}
		m_EnemyManager.Draw(m_Window);
		m_Camera.Deactivate();
		if (m_UpgradeShop)
		{
			m_NextDayButton.Draw(m_Window);
			m_BuySlowMotionButton.Draw(m_Window);
			m_BuyBoostButton.Draw(m_Window);
			m_BuyLifeButton.Draw(m_Window);
			m_Window.Draw(m_DescriptionText);
			m_Window.Draw(m_MoneyText);
			m_Window.Draw(m_DayText);
		}
		if (m_Win)
		{
			m_Window.Draw(m_WinText);
			return;
		}
		m_Window.Draw(m_DistanceText);
		m_Window.Draw(m_LifeText);

	}

	virtual void HandleEvent(const sf::Event& Event)
	{
		if (Event.Type == sf::Event::KeyPressed)
		{
			if (Event.Key.Code == sf::Keyboard::Space)
			{
				if (!m_UpgradeShop && m_CurrentNumSlowMotion > 0 && !m_SlowMotion)
				{
					--m_CurrentNumSlowMotion;
					m_SlowMotion = true;
					m_BackgroundMusic.SetPitch(0.5f);
					m_Window.SetTimeScale(0.3f);
					m_Game.GetAudiomanager().PlaySound("123437__anomalous_underdog__Slowdown_Short_Down.wav", 100);
					m_SlowMotionTimer.Reset();
				}				
			}
			else if (Event.Key.Code == sf::Keyboard::B && m_CurrentNumBoost > 0 && !m_Boost)
			{
				--m_CurrentNumBoost;
				m_Boost = true;
				m_Player.SetSpeed(700);
				m_Game.GetAudiomanager().PlaySound("3379__patchen__Rhino_04.wav", 100);
			}
		}
		if (m_UpgradeShop)
		{
			m_NextDayButton.HandleEvent(Event);
			m_BuySlowMotionButton.HandleEvent(Event);
			m_BuyBoostButton.HandleEvent(Event);
			m_BuyLifeButton.HandleEvent(Event);
		}
	}



private:
	void Restart()
	{
		m_LevelLenght = 10000;
		m_Player.SetPosition(sf::Vector2f(400,m_LevelLenght+70));
		m_Camera.Reset(sf::Vector2f(400,m_LevelLenght-200));
		m_EnemyManager.Reset(m_LevelLenght);
		m_MaxPlayerPosition = m_LevelLenght+70;
		m_UpgradeShop = false;
		m_CurrentNumSlowMotion = m_MaxNumSlowMotion;
		m_BoostTime = 0;
		m_Boost = false;
		m_CurrentNumBoost = m_MaxNumBoost;
		m_Lifes = m_MaxLifes;
	}
	void UpgradeSlowMotion()
	{
		switch (m_MaxNumSlowMotion)
		{
		case 0:
			if (m_Money >= 1000)
			{
				m_BuySlowMotionButton.SetDescription("Zwei mal pro Runde kann mit der Leertaste\ndie Zeitlupe aktiviert werden\nKosten: 4000");
				m_Money -= 1000;
			}
			else
			{
				return;
			}			
			break;
		case 1:
			if (m_Money >= 4000)
			{
				m_BuySlowMotionButton.SetDescription("");
				m_Money -= 4000;
			}
			else
			{
				return;
			}			
			break;
		default:
			return;
		}
		m_Game.GetAudiomanager().PlaySound("Cash.wav", 100);
		++m_MaxNumSlowMotion;

		std::stringstream SStream;
		SStream << "Geld: " << m_Money;
		m_MoneyText.SetString(SStream.str());
	}
	void UpgradeBoost()
	{
		switch (m_MaxNumBoost)
		{
		case 0:
			if (m_Money >= 1500)
			{
				m_BuyBoostButton.SetDescription("Zwei mal pro Runde kann mit der Taste B\nein Geschwindigkeitsschub aktiviert werden\nKosten: 5000");
				m_Money -= 1500;
			}
			else
			{
				return;
			}			
			break;
		case 1:
			if (m_Money >= 5000)
			{
				m_BuyBoostButton.SetDescription("");
				m_Money -= 5000;
			}
			else
			{
				return;
			}		
			
			break;
		default:
			return;
		}
		m_Game.GetAudiomanager().PlaySound("Cash.wav", 100);
		++m_MaxNumBoost;

		std::stringstream SStream;
		SStream << "Geld: " << m_Money;
		m_MoneyText.SetString(SStream.str());
	}
	void UpgradeLife()
	{
		switch (m_MaxLifes)
		{
		case 1:
			if (m_Money >= 2500)
			{
				m_BuyBoostButton.SetDescription("Zwei exrta Leben pro Tag\nKosten: 6000");
				m_Money -= 2500;
			}
			else
			{
				return;
			}				
			break;
		case 2:
			if (m_Money >= 6000)
			{
				m_BuyBoostButton.SetDescription("");
				m_Money -= 2500;
			}
			else
			{
				return;
			}			
			break;
		default:
			return;
		}
		m_Game.GetAudiomanager().PlaySound("Cash.wav", 100);
		++m_MaxLifes;
		std::stringstream SStream;
		SStream << "Leben: " << m_MaxLifes;
		m_LifeText.SetString(SStream.str());

		SStream.str("");
		SStream << "Geld: " << m_Money;
		m_MoneyText.SetString(SStream.str());
	}
private:
	std::tr1::shared_ptr<sf::Shader> m_GrayScaleShader;
	float m_LevelLenght;
	Player m_Player;
	Camera m_Camera;
	EnemyManager m_EnemyManager;
	Background m_Background;
	float m_MaxPlayerPosition;
	sf::Music m_BackgroundMusic;
	bool m_SlowMotion;
	int m_MaxNumSlowMotion;
	int m_CurrentNumSlowMotion;
	bool m_PlayedSpeedUpSound;
	sf::Clock m_SlowMotionTimer;
	bool m_Boost;
	float m_BoostTime;
	int m_MaxNumBoost;
	bool m_Win;
	sf::Text m_WinText;
	int m_CurrentNumBoost;
	sf::Text m_DistanceText;
	bool m_UpgradeShop;
	sf::Text m_DescriptionText;
	int m_Money;
	sf::Text m_MoneyText;
	int m_Day;
	sf::Text m_DayText;
	ImageButton m_NextDayButton;
	ImageButton m_BuySlowMotionButton;
	ImageButton m_BuyBoostButton;
	int m_MaxLifes;
	int m_Lifes;
	ImageButton m_BuyLifeButton;
	sf::Text m_LifeText;
	bool m_Intro;
	sf::Clock m_IntroTimer;
	sf::Text m_IntroText;
};