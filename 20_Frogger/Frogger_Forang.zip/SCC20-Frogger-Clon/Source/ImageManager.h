#ifndef ImageManager_h__
#define ImageManager_h__


#endif // ImageManager_h__
#include "ResourceManager.h"
#include <sfml/Graphics.hpp>

class ImageManager : public ResourceManager<std::string, sf::Image>
{
protected:
	virtual sf::Image* Load(const std::string FileName);
};
