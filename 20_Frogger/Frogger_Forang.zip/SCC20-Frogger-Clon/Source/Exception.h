#ifndef Exception_h__
#define Exception_h__

#include <exception>
#include <string>

class Exception : public std::exception
{
protected:
    long m_Line;
    std::string m_FileName;
public:
    Exception(const std::string& Description);

    Exception(const std::string& Description, const char* File, long Line );

	~Exception() throw() {}

	// Gibt eine Genaue Beschreibeung des Fehlers zur�ck
    const std::string GetFullDescription() const;

	// Gibt den Namen der Datei zur�ck, in der die Ausnahme geworfen wurde
    const std::string &getFile() const { return m_FileName; }

	// Gibt die Zeilennummer zur�ck, in der die Ausnahme geworfen wurde
    long getLine() const { return m_Line; }
};

#ifndef THROW_EXCEPTION
#define THROW_EXCEPTION(Description) throw Exception((Description), (__FILE__), (__LINE__));
#endif

#endif // Exception_h__
