#pragma once

#include <sfml/Graphics.hpp>

class ImageManager;                                                                    

class Enemy
{
public:
	Enemy(Enemy* NextEnemy, ImageManager& ImageMgr, sf::Vector2f StartPosition);

	~Enemy();

	void Update(float Dt);

	void Draw(sf::RenderTarget& Target);

	float GetSpeed(){return m_Speed;}

	void Die(){m_IsDead = true;}
	bool IsDead(){return m_IsDead;}

	float GetBackXPos(){return m_Sprite.TransformToGlobal(sf::Vector2f(m_Sprite.GetSize().x, 0)).x;}

	Enemy* TestCollision(sf::FloatRect Rect);
private:
	Enemy* m_NextEnemy;
	sf::Sprite m_Sprite;
	float m_Speed;
	bool m_Left;
	bool m_IsDead;
};