#pragma once
#include <sfml/Graphics.hpp>
#include <functional>

class ImageButton
{
public:
	ImageButton(sf::Vector2f Position, sf::Image& Image, sf::Text& DescriptionText, sf::String DescriptionString);
	void Draw(sf::RenderTarget& Target);
	void HandleEvent(sf::Event Event);
	void SetCallback(std::tr1::function<void()> Callback);
	void SetDescription(sf::String String)
	{
		m_DescriptionString = String;
		if (m_MouseOver)
		{
			m_DescriptionText.SetString(String);
		}
	}
private:
	sf::Sprite m_Sprite;
	sf::Shape m_Background;
	bool m_MouseOver;
	std::tr1::function<void()> m_Callback;
	sf::Text& m_DescriptionText;
	sf::String m_DescriptionString;
};