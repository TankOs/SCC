#pragma once

#include "Enemy.h"
#include <list>

class EnemyManager
{
public:
	EnemyManager(ImageManager& TheImageManager, float Width, float Length);
	~EnemyManager();

	void Update(float Dt);

	void Draw(sf::RenderTarget& Target);

	void UpdateCamera(sf::FloatRect Rect);

	Enemy* TestCollision(sf::FloatRect Rect);

	void Reset(float Lenght);

private:
	float GetSpawnTime()
	{
		if (m_Difficulty >= 9000)
		{
			return rand() % (7000 - 4000 + 1) + 4000;
		}
		else if (m_Difficulty >= 7000)
		{
			return rand() % (6500 - 4000 + 1) + 4000;
		}
		else if (m_Difficulty >= 5000)
		{
			return rand() % (5000 - 3000 + 1) + 3000;
		}
		else if (m_Difficulty >= 2000)
		{
			return rand() % (4000 - 2500 + 1) + 2500;
		}
		else if (m_Difficulty >= 1000)
		{
			return rand() % (3500 - 2000 + 1) + 2000;
		}
		else
		{
			return rand() % (3000 - 1500 + 1) + 1500;
		}
	}
	struct Row
	{
		Enemy* m_Enemy;
		float m_Time;
		sf::Uint32 m_NextEnemyTime;
		sf::Vector2f m_StartPosition;
	};

private:
	ImageManager& m_ImageManager;
	std::list<Row> m_EnemyRows;
	sf::Vector2f m_NextStartPosition;
	float m_Width;
	float m_Difficulty;
};