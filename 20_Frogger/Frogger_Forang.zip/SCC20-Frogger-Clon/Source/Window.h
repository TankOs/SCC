#pragma once

#include <sfml/Graphics.hpp>


class Window : public sf::RenderTarget
{
public:
	Window();
	Window(sf::VideoMode mode, const std::string& title, unsigned long style = sf::Style::Default, const sf::ContextSettings& settings = sf::ContextSettings())
		: m_Window(mode, title, style, settings)
	{
		RenderTarget::Initialize();
		m_RenderImage.Create(mode.Width, mode.Height);
		m_RenderImageSprite.SetImage(m_RenderImage.GetImage());
		m_TimeScale = 1;
	}
	explicit Window(sf::WindowHandle handle, const sf::ContextSettings& settings = sf::ContextSettings())
		: m_Window(handle, settings)
	{		
		RenderTarget::Initialize();
		m_RenderImage.Create(m_Window.GetWidth(), m_Window.GetHeight());
		m_RenderImageSprite.SetImage(m_RenderImage.GetImage());
		m_TimeScale = 1;
	}   
	void Create(sf::VideoMode mode, const std::string& title, unsigned long style = sf::Style::Default, const sf::ContextSettings& settings = sf::ContextSettings())
	{
		m_Window.Create(mode,title,style,settings);
		RenderTarget::Initialize();
		m_RenderImage.Create(mode.Width, mode.Height);
		m_RenderImageSprite.SetImage(m_RenderImage.GetImage());
		m_TimeScale = 1;
	}
	void Create(sf::WindowHandle handle, const sf::ContextSettings& settings = sf::ContextSettings())
	{
		m_Window.Create(handle, settings);
		RenderTarget::Initialize();
		m_RenderImage.Create(m_Window.GetWidth(), m_Window.GetHeight());
		m_RenderImageSprite.SetImage(m_RenderImage.GetImage());
		m_TimeScale = 1;
	}
	void Close(){m_Window.Close();}
	bool IsOpened() const{return m_Window.IsOpened();}
	virtual unsigned int GetWidth() const{return m_Window.GetWidth();}
	virtual unsigned int GetHeight() const{return m_Window.GetHeight();}
	const sf::ContextSettings& GetSettings() const{return m_Window.GetSettings();}
	bool PollEvent(sf::Event& event){return m_Window.PollEvent(event);}
	bool WaitEvent(sf::Event& event){return m_Window.WaitEvent(event);}
	void EnableVerticalSync(bool enabled){m_Window.EnableVerticalSync(enabled);}
	void ShowMouseCursor(bool show){m_Window.ShowMouseCursor(show);}
	void SetPosition(int x, int y){m_Window.SetPosition(x, y);}
	void SetSize(unsigned int width, unsigned int height){m_Window.SetSize(width, height);}
	void SetTitle(const std::string& title){m_Window.SetTitle(title);}
	void Show(bool show){m_Window.Show(show);}
	void EnableKeyRepeat(bool enabled){m_Window.EnableKeyRepeat(enabled);}
	void SetIcon(unsigned int width, unsigned int height, const sf::Uint8* pixels){m_Window.SetIcon(width, height, pixels);}
	bool SetActive(bool active = true) const{m_Window.SetActive(active);}
	void Display()
	{
	
		//m_RenderImageSprite.SetColor(sf::Color(255,255,255,100));
		m_RenderImage.Display();
		if (m_PostProcessingShader)
		{
			m_Window.Draw(m_RenderImageSprite, *m_PostProcessingShader);
		}
		else
		{
			m_Window.Draw(m_RenderImageSprite);
		}
		m_Window.Display();
	}
	void SetFramerateLimit(unsigned int limit){m_Window.SetFramerateLimit(limit);}
	float GetFrameTime() const{return (m_Window.GetFrameTime()*0.001f) * m_TimeScale;}
	void SetJoystickThreshold(float threshold){m_Window.SetJoystickThreshold(threshold);}
	sf::WindowHandle GetSystemHandle() const{return m_Window.GetSystemHandle();}

	std::tr1::shared_ptr<sf::Shader> GetPostProcessingShader() const { return m_PostProcessingShader; }
	void SetPostProcessingShader(std::tr1::shared_ptr<sf::Shader> PostProcessingShader) { m_PostProcessingShader = PostProcessingShader; }

	float GetTimeScale() const { return m_TimeScale; }
	void SetTimeScale(float TimeScale) { m_TimeScale = TimeScale; }

	// Gibt die Position der Muas relativ zum Fenster zur�ck
	sf::Vector2i GetRelativMouseposition()
	{
		return sf::Mouse::GetPosition(m_Window);
	}
	// Setzt die Mausposition relativ zum Fenster
	void SetRelativMouseposition(sf::Vector2i Position)
	{
		sf::Mouse::SetPosition(Position, m_Window);
	}

private :
	virtual bool Activate(bool active)
	{
// 		if (m_PostProcessingShader)
// 		{
			return m_RenderImage.SetActive(active);
// 		}
// 		else
// 		{
// 			return m_Window.SetActive(active);
// 		}
	}

private:
	sf::RenderImage m_RenderImage;
	sf::Sprite m_RenderImageSprite;
	sf::RenderWindow m_Window;
	std::tr1::shared_ptr<sf::Shader> m_PostProcessingShader; 
	float m_TimeScale;
};

