#include "GameState.h"
#include "Game.h"

Gamestate::Gamestate( Game& TheGame ) : m_Game(TheGame), m_Window(TheGame.GetWindow())
{

}

Gamestate::~Gamestate()
{

}

void Gamestate::HandleEvent( const sf::Event& Event )
{

}
