#ifndef Game_h__
#define Game_h__


#include <SFML/Graphics.hpp>
#include "StateManager.h"
#include "Logfile.h"
#include <list>
#include "Window.h"
#include "ImageManager.h"
#include "AudioManager.h"


class Game
{
public:
	Game();
	~Game(){};

	void Run();

	void Exit()
	{
		m_Exit = true;
	}

	Window& GetWindow()
	{
		return m_Window;
	}

	StateManager& GetStateManager()
	{
		return m_StateManager;
	}

	ImageManager& GetImagemanager() 
	{ 
		return m_Imagemanager;
	}
	AudioManager& GetAudiomanager() 
	{
		return m_Audiomanager;
	}

	sf::Font& GetGameFont()
	{
		return m_GameFont;
	}
private:

	// Gibt an ob das Programm beendet werden soll
	bool m_Exit;

	// Fenster auf das gerendert wird
	Window m_Window;

	// Statemanager
	StateManager m_StateManager;

	// Standartview
	sf::View m_View;

	// Resourcemanager
	ImageManager m_Imagemanager;
	AudioManager m_Audiomanager;

	sf::Font m_GameFont;

};
#endif // Game_h__