#pragma once
#include "GameState.h"
#include "Beat.h"
#include "BeatButton.h"

#include <sfml/Audio.hpp>
#include "Background.h"

// Interface f�r einen Zustand/State
class MainMenuState : public Gamestate
{
public:
	MainMenuState(Game& TheGame);
	// Virtueller Destruktor
	virtual ~MainMenuState();

	// Initialisiert den Zustand
	// Parameter: Zeiger auf Daten die der Spielzustand �bergeben bekommen soll (z.B �bergibt der Hauptspielzustand dem Highscorezustand die Punktzahl die der Spieler erreicht hat)
	virtual void Init(void* InitializationData);

	// F�hrt den Spielzustand herunter
	virtual void Exit();

	// Aktualisiert den Spielzustand
	// Parameter : Vergangangene Zeit seit dem letztdem Frame
	virtual void Update();

	// Malt den Spielzustand
	virtual void Draw(); 

	virtual void HandleEvent(const sf::Event& Event);

private:
	Beat m_Beat;
	sf::Music m_Music;
	BeatButton m_PlayButton;
	BeatButton m_ExitButton;
	Background m_Background;
};
