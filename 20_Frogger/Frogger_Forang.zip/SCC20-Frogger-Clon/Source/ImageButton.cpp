#include "ImageButton.h"

ImageButton::ImageButton( sf::Vector2f Position, sf::Image& Image, sf::Text& DescriptionText, sf::String DescriptionString )
	:m_Sprite(Image, Position),
	m_MouseOver(false),
	m_DescriptionText(DescriptionText),
	m_DescriptionString(DescriptionString)
{
	m_Background = sf::Shape::Rectangle(sf::FloatRect(Position - sf::Vector2f(4,4), m_Sprite.GetSize() + sf::Vector2f(8,8)), sf::Color(38, 182, 255, 100));
}


void ImageButton::Draw( sf::RenderTarget& Target )
{
	if (m_MouseOver)
	{
		Target.Draw(m_Background);
	}
	Target.Draw(m_Sprite);
}

void ImageButton::HandleEvent( sf::Event Event )
{
	if (Event.Type == sf::Event::MouseMoved)
	{
		sf::Vector2f MousePosition(Event.MouseMove.X, Event.MouseMove.Y);
		bool Befor = m_MouseOver;
		m_MouseOver = sf::FloatRect(m_Sprite.GetPosition(), m_Sprite.GetSize()).Contains(MousePosition);
		if (m_MouseOver)
		{
			m_DescriptionText.SetString(m_DescriptionString);
		}
		else
		{
			if (Befor)
			{
				m_DescriptionText.SetString("");
			}
			
		}
	}
	else if (Event.Type == sf::Event::MouseButtonReleased)
	{
		if (m_MouseOver)
		{
			if (m_Callback)
			{
				m_Callback();
			}
		}
	}
}

void ImageButton::SetCallback( std::tr1::function<void()> Callback )
{
	m_Callback = Callback;
}
