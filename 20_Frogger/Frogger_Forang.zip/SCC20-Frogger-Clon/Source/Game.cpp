#include "Game.h"
#include <iostream>
#include "MainGameState.h"
#include "AudioManager.h"
#include "MainMenuState.h"



Game::Game() : m_Exit(false), m_Window(sf::VideoMode(800,600), "SCC20 Frogger"), m_View(sf::FloatRect(0,0,800,600))
{
	m_Window.EnableKeyRepeat(false);
//	m_Window.SetFramerateLimit(150);
	m_Window.SetView(m_View);

	// Gamestates zum Statemanager hinzuf�gen
	m_StateManager.AddGamestate("MainMenuState", new MainMenuState(*this));
 	m_StateManager.AddGamestate("MainGameState", new MainGameState(*this));
//	m_StateManager.AddGamestate("GameOverState", new GameOverState(m_Window, m_StateManager));
	m_StateManager.ChangeGamestate("MainMenuState", 0);

	if (!m_GameFont.LoadFromFile("AltamonteNF.ttf"))
	{
		Logfile::GetInstance() << Error << "Fehler beim laden der Schrift 8bitlim.ttf. Defaultfont wird verwendet." << NewLine;
	}	
}

void Game::Run()
{
	Logfile::GetInstance() << Info << "Gameloop wird betreten" << NewLine;
	while(m_Window.IsOpened() && !m_Exit)
	{
		// Window Events verarbeiten
		sf::Event Event;
		while(m_Window.PollEvent(Event))
		{
			m_StateManager.HandleEvent(Event);
			if (Event.Type == sf::Event::Closed)
			{
				Exit();
			}
		}

		// Gamestate aktualisieren
		m_StateManager.Update();
		m_Audiomanager.Update();

		//AudioManager::GetInstance().Update();

		// Fenster clearen
		m_Window.Clear(sf::Color::Black);

		// Gamestate rendern
		m_StateManager.Draw();

		// Fenster anzeigen
		m_Window.Display();
	}
	Logfile::GetInstance() << Info << "Gameloop wurde verlassen" << NewLine;
}
