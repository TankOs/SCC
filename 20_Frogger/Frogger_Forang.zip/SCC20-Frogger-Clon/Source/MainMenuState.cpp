#include "MainMenuState.h"
#include <iostream>
#include "GameState.h"
#include "Game.h"

MainMenuState::MainMenuState( Game& TheGame )
	:Gamestate(TheGame),
	m_Beat(463),
	m_PlayButton(m_Window, sf::Vector2f(400,250), *TheGame.GetImagemanager().GetResource("GUI/StartGame.png"), m_Beat, false),
	m_ExitButton(m_Window, sf::Vector2f(400,350), *TheGame.GetImagemanager().GetResource("GUI/ExitGame.png"), m_Beat, true),
	m_Background(m_Window)
{
	m_Music.OpenFromFile("MainMenu.ogg");
	m_Music.SetLoop(true);

	m_PlayButton.SetCallback(std::tr1::bind(&StateManager::ChangeGamestate, &m_Game.GetStateManager(), std::string("MainGameState"), static_cast<void*>(NULL)));
	m_ExitButton.SetCallback(std::tr1::bind(&Game::Exit, &m_Game));
}

MainMenuState::~MainMenuState()
{

}

void MainMenuState::Init( void* InitializationData )
{
	m_Music.Play();
	
}

void MainMenuState::Exit()
{
	m_Music.Stop();
}

void MainMenuState::Update()
{
	
	m_Beat.Update();
	m_PlayButton.Update(m_Window.GetFrameTime());
	m_ExitButton.Update(m_Window.GetFrameTime());
}

void MainMenuState::Draw()
{
	
	m_Background.DrawMenuBackground();
	m_PlayButton.Draw(m_Window);
	m_ExitButton.Draw(m_Window);
	
}

void MainMenuState::HandleEvent( const sf::Event& Event )
{
	m_PlayButton.HandleEvent(Event);
	m_ExitButton.HandleEvent(Event);
}
