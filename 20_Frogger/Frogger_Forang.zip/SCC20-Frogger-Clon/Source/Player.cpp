#include "Player.h"
#include "ImageManager.h"
#include "VectorHelperFunctions.h"


Player::Player( ImageManager& ImageMgr, sf::Vector2f Position )
	: m_Sprite(*ImageMgr.GetResource("Player.png"), Position),
	m_Speed(150),
	m_AnimState(Normal)
{
	m_Sprite.SetSubRect(sf::IntRect(0,0,36,35));
	m_Sprite.SetOrigin(m_Sprite.GetSize() / 2.0f);
}

void Player::Update( float Dt,  sf::FloatRect CameraRect )
{
	float Rotation = m_Sprite.GetRotation();
	bool Moved = false;
	sf::Vector2f MoveVector;
	if (sf::Keyboard::IsKeyPressed(sf::Keyboard::Up))
	{
		Moved = true;
		MoveVector.y += -1;
		if (sf::Keyboard::IsKeyPressed(sf::Keyboard::Left))
		{
			MoveVector.x += -1;
			Rotation = 315;
		}
		else if (sf::Keyboard::IsKeyPressed(sf::Keyboard::Right))
		{
			MoveVector.x += 1;
			Rotation = 45;
		}
		else
		{
			Rotation = 0;
		}	
	}
	else if (sf::Keyboard::IsKeyPressed(sf::Keyboard::Down))
	{
		Moved = true;
		MoveVector.y += 1;
		if (sf::Keyboard::IsKeyPressed(sf::Keyboard::Left))
		{
			MoveVector.x += -1;
			Rotation = 225;
		}
		else if (sf::Keyboard::IsKeyPressed(sf::Keyboard::Right))
		{
			MoveVector.x += 1;
			Rotation = 135;
		}
		else
		{
			Rotation = 180;
		}	
	}
	else
	{
		if (sf::Keyboard::IsKeyPressed(sf::Keyboard::Left))
		{
			Moved = true;
			MoveVector.x += -1;
			Rotation = 270;
		}
		if (sf::Keyboard::IsKeyPressed(sf::Keyboard::Right))
		{
			Moved = true;
			MoveVector.x += 1;
			Rotation = 90;
		}
	}


	m_Sprite.SetRotation(Rotation);
	if (Moved)
	{
		Normalize(MoveVector);
		sf::Vector2f NewPos = m_Sprite.GetPosition() + MoveVector * m_Speed * Dt;
		
		if (NewPos.x - 16 > 0 && NewPos.x + 16 < 800)
		{
			m_Sprite.SetX(NewPos.x);
		}
		if (NewPos.y+16 < CameraRect.Top + CameraRect.Height)
		{
			m_Sprite.SetY(NewPos.y);
		}
		
		m_AnimState = Move;
	}
	else
	{
		if (m_AnimState == Move)
		{
			m_AnimState = Normal;
		}
	}
	if (m_AnimState == Normal)
	{
		if (m_AnimTimer.GetElapsedTime() > 2000)
		{
			m_AnimState = Blink;
			m_AnimTimer.Reset();
		}
		m_Sprite.SetSubRect(sf::IntRect(0,0,36,35));
	}
	else if (m_AnimState == Blink)
	{
		if (m_AnimTimer.GetElapsedTime() > 100)
		{
			sf::IntRect Subrect = m_Sprite.GetSubRect();
			if (Subrect.Left >= 144)
			{
				Subrect.Left = 0;
				m_AnimState = Normal;
			}
			else
				Subrect.Left += 36;
			m_Sprite.SetSubRect(Subrect);
			m_AnimTimer.Reset();
		}
	}
	else if (m_AnimState == Move)
	{
		if (m_AnimTimer.GetElapsedTime() > 100)
		{
			sf::IntRect Subrect = sf::IntRect(0,35,36, 60);
			Subrect.Left = m_Sprite.GetSubRect().Left;
			if (Subrect.Left >= 36)
			{
				Subrect.Left = 0;
			}
			else
				Subrect.Left += 36;
			m_Sprite.SetSubRect(Subrect);
			m_AnimTimer.Reset();
		}
	}
}

void Player::Draw( sf::RenderTarget& Target )
{
	Target.Draw(m_Sprite);
}
