#include "EnemyManager.h"

EnemyManager::EnemyManager(ImageManager& TheImageManager, float Width, float Length)
	:m_ImageManager(TheImageManager), m_NextStartPosition(0, Length), m_Width(Width)
{

}

EnemyManager::~EnemyManager()
{
	for (auto It = m_EnemyRows.begin(); It != m_EnemyRows.end(); ++It)
	{
		delete It->m_Enemy;
	}
}

void EnemyManager::Update( float Dt )
{
	for (auto It = m_EnemyRows.begin(); It != m_EnemyRows.end(); ++It)
	{
		It->m_Time += Dt*1000;
		if (It->m_Time >= It->m_NextEnemyTime)
		{
			It->m_Enemy = new Enemy(It->m_Enemy, m_ImageManager, It->m_StartPosition);
			It->m_NextEnemyTime = GetSpawnTime();
			It->m_Time = 0;
		}
		if (It->m_Enemy)
			It->m_Enemy->Update(Dt);
		if (It->m_Enemy && It->m_Enemy->IsDead())
		{
			delete It->m_Enemy;
			It->m_Enemy = 0;
		}
	}
}

void EnemyManager::Draw( sf::RenderTarget& Target )
{
	for (auto It = m_EnemyRows.begin(); It != m_EnemyRows.end(); ++It)
	{
		if (It->m_Enemy)
		{
			It->m_Enemy->Draw(Target);
		}		
	}
}

void EnemyManager::UpdateCamera(sf::FloatRect Rect)
{
	m_Difficulty = Rect.Top;
	while(Rect.Top-600 < m_NextStartPosition.y && m_NextStartPosition.y > 0)
	{
		Row NewRow;	
		NewRow.m_Enemy = new Enemy(NULL, m_ImageManager, m_NextStartPosition);
		NewRow.m_NextEnemyTime = GetSpawnTime();
		NewRow.m_StartPosition = m_NextStartPosition;
		NewRow.m_Time = 0;
		m_EnemyRows.push_back(NewRow);

		m_NextStartPosition.x = (rand() % 2) * m_Width;
		m_NextStartPosition.y -= 70;
	}

	while(Rect.Top + Rect.Height + 20 < m_EnemyRows.begin()->m_StartPosition.y)
	{
		delete m_EnemyRows.begin()->m_Enemy;
		m_EnemyRows.pop_front();
	}
}

Enemy* EnemyManager::TestCollision( sf::FloatRect Rect )
{
	for (auto It = m_EnemyRows.begin(); It != m_EnemyRows.end(); ++It)
	{
		if (It->m_Enemy)
		{
			Enemy* Temp = It->m_Enemy->TestCollision(Rect);
			if (Temp)
			{
				return Temp;
			}	
		}			
	}
	return NULL;
}

void EnemyManager::Reset( float Length )
{
	m_EnemyRows.clear();
	m_NextStartPosition = sf::Vector2f(0, Length);
}
