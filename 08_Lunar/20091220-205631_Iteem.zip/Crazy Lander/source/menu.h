#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

#include <SFML/Graphics.hpp>

bool RunMenu(sf::RenderWindow &App, sf::Font &Font, std::string &lvl);

#endif // MENU_H_INCLUDED
