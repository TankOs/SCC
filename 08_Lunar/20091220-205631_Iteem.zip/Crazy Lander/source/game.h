#ifndef GAME_H_INCLUDED
#define GAME_H_INCLUDED

#include <SFML/Graphics.hpp>

bool RunGame(sf::RenderWindow &App, sf::Font &Font, std::string &lvl);

#endif // GAME_H_INCLUDED
