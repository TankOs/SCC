#include "item.h"
#include <SFML/Audio.hpp>

Item::Item(std::string string)
{
    image.LoadFromFile("images/menu_bg.png");
    image_hover.LoadFromFile("images/menu_bg_hover.png");
    sprite.SetImage(image);
    sprite.SetColor(sf::Color::Yellow);
    font.LoadFromFile("arial.ttf");
    label = sf::String(string, font);
}
