#include "bar.h"

Bar::Bar()
{
    image.LoadFromFile("images/bar.png");
    sprite.SetImage(image);
}

void Bar::init(sf::Vector2f pos)
{
    position = pos;
    sprite.SetPosition(position);
}
