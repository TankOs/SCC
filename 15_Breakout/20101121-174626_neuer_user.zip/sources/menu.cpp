#include "menu.h"

Menu::Menu()
{
    items.push_back(Item("Start"));
    items.push_back(Item("Exit"));

    for(int i = 0;i < items.size();i++)
    {
        items.at(i).sprite.SetPosition(globals.menuMargins.x, (globals.menuMargins.y*(i+1))+(globals.menuItemSize.y*i));
        items.at(i).label.SetPosition(items.at(i).sprite.GetPosition().x+globals.menuPaddings.x, items.at(i).sprite.GetPosition().y+globals.menuPaddings.y);
    }

    selected = 1;
}
