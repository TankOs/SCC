/*
    Block-Destroyer 0.5 (c) 2010 Markus F.
*/
#include "game.h"

Game game;

int main()
{
    game.loop();

    return 0;
}
