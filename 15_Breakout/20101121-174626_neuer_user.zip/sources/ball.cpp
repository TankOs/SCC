#include "ball.h"

Ball::Ball(sf::Vector2f pos, float playerSizeX, float playerY)
{
    image.LoadFromFile("images/ball.png");
    position = pos;
    sprite.SetImage(image);
    sprite.SetPosition(position);
    direction = sf::Vector2f(1, -1);
    speed = 0.7f;

    playerWidth = playerSizeX;
    playerPosY = playerY;

    buffer.LoadFromFile("sound/ball.ogg");
    sound.SetBuffer(buffer);
}

bool Ball::collision(float playerPosX)
{
    if(position.x <= 0 || position.x+sprite.GetSize().x >= globals.windowSize.x)
    {
        direction = sf::Vector2f(-direction.x, direction.y);
        return true;
    }
    else if(position.y <= 0)
    {
        direction = sf::Vector2f(direction.x, -direction.y);
        return true;
    }
    else if(position.y+sprite.GetSize().y >= playerPosY && position.y+sprite.GetSize().y <= playerPosY+2)
    {
        if(position.x >= playerPosX && position.x+sprite.GetSize().x <= playerPosX+playerWidth)
        {
            position += sf::Vector2f(0, -1);
            int p = (position.x+sprite.GetSize().x)-(playerPosX+(playerWidth/2));
            direction = sf::Vector2f((p/(playerWidth/2))*3, -direction.y);
            return true;
        }
    }

    return false;
}

bool Ball::ballOutOfScreen()
{
    if(position.y+sprite.GetSize().y >= globals.windowSize.y)
        return true;

    return false;
}

void Ball::move(float playerPosX)
{
    if(collision(playerPosX))
        sound.Play();
    position = sf::Vector2f(position.x+(direction.x*speed), position.y+(direction.y*speed));
    sprite.SetPosition(position);
}
