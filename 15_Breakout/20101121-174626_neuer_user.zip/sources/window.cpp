#include "window.h"

Window::Window()
{
    mode = sf::VideoMode(globals.windowSize.x, globals.windowSize.y);
    settings = sf::WindowSettings(24, 8, 0);

    myWindow.Create(mode, "Block-Destroyer 0.5", sf::Style::Close, settings);
}
