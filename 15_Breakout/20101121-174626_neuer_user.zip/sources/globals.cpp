#include "globals.h"

Globals::Globals()
{
    windowSize = sf::Vector2i(800, 600);

    menuMargins = sf::Vector2f(20, 10);  //Left, Top
    menuMargins = sf::Vector2f(5, 3);  //Left, Top

    menuItemSize = sf::Vector2f(200, 50);

    playerSize = sf::Vector2f(130, 10);

    blockSize = sf::Vector2f(40, 15);

    blockMargin = 15;
}
