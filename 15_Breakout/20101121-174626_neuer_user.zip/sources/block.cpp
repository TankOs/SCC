#include "block.h"

Block::Block(sf::Vector2f pos, int punkte, sf::Image img)
{
    points = punkte;

    image = img;

    /*
    switch(points)
    {
        default:
            break;
        case 1:
        {
            image.LoadFromFile("images/block.png");
        }
        case 2:
        {
            image.LoadFromFile("images/block2.png");
        }
        case 3:
        {
            image.LoadFromFile("images/block3.png");
        }
    }*/

    sprite.SetImage(image);

    position = pos;
    sprite.SetPosition(position);
}
