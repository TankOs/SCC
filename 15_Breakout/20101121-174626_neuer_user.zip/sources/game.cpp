#include "game.h"

Game::Game()
{
    menuMode = false;   //Menue funtkioniert nicht

    player.init(sf::Vector2f((float)globals.windowSize.x/2, globals.windowSize.y-10-player.sprite.GetSize().y));

    balls.push_back(Ball(sf::Vector2f(globals.windowSize.x/2, globals.windowSize.y/2), player.sprite.GetSize().x, player.position.y));

    ballCount = 3;

    blocksEmpty = false;

    //Anzeiugestring
    font.LoadFromFile("Vera.ttf");
    strB = sf::String("", font, 30);
    strB.SetColor(sf::Color(180, 180, 180));
    strB.SetPosition(0, globals.windowSize.y-150);

    //Bilder f�r Bloecke laden
    blockImg.LoadFromFile("images/block1.png");
    blockImages.push_back(blockImg);

    blockImg.LoadFromFile("images/block2.png");
    blockImages.push_back(blockImg);

    blockImg.LoadFromFile("images/block3.png");
    blockImages.push_back(blockImg);

    activeMenuImage.LoadFromFile("images/menuActive.png");
    inactiveMenuImage.LoadFromFile("images/menuInactive.png");
    inactiveMenuItem.SetImage(activeMenuImage);
    inactiveMenuItem.SetImage(inactiveMenuImage);


    menu = Menu();

    level = 0;
    newLevel();
}

void Game::newLevel()
{
    level++;

    blockRows.clear();

    for(int i = 0;i < level;i++)
    {
        temp.clear();

        for(int e = 0;e < 15;e++)
        {
            int t = sf::Randomizer::Random(1, 3);
            temp.push_back(Block(sf::Vector2f((globals.blockSize.x*e)+(globals.blockMargin*e), (globals.blockSize.y*i)+(globals.blockMargin*(i+1))), t, blockImages.at(t-1)));
        }

        blockRows.push_back(temp);
    }

    blocksEmpty = false;
}

void Game::newBall(int nr)
{
    if(balls.size() > 1)
    {
        balls.erase(balls.begin()+nr);
    }
    balls.at(nr) = Ball(sf::Vector2f(globals.windowSize.x/2, globals.windowSize.y/2), player.sprite.GetSize().x, player.position.y);
}

bool Game::blockCollision()
{
    for(int i = 0;i < balls.size();i++)
    {
        if(balls.at(i).position.y <= blockRows.size()*(globals.blockSize.y+globals.blockMargin))
        {
            int u;

            if(balls.at(i).direction.y < 0)
            {
                u = balls.at(i).position.y;
                for(int e = 1;e <= blockRows.size();e++)
                {
                    if(u-(e*(globals.blockSize.y+globals.blockMargin)) < 0)
                    {
                        u = e-1;
                        break;
                    }
                }
            }
            else if(balls.at(i).direction.y > 0)
            {
                u = balls.at(i).position.y+globals.playerSize.y;
                for(int e = 1;e <= blockRows.size();e++)
                {
                    if(u-((e-1)*(globals.blockSize.y+globals.blockMargin))-globals.blockMargin >= 0 && u-((e-1)*(globals.blockSize.y+globals.blockMargin))-globals.blockMargin <= globals.blockMargin+globals.blockSize.y)
                    {
                        u = e-1;
                        break;
                    }
                }
            }

            if(u+1 <= blockRows.size())
            {
                for(int a = 0;a < blockRows.at(u).size();a++)
                {
                    if(balls.at(i).position.x <= blockRows.at(u).at(a).position.x+globals.blockSize.x && balls.at(i).position.x > blockRows.at(u).at(a).position.x && balls.at(i).position.y <= blockRows.at(u).at(a).position.y+globals.blockSize.y && balls.at(i).position.y > blockRows.at(u).at(a).position.y)
                    {
                        if(balls.at(i).direction.x <= 0)
                        {
                            if(balls.at(i).position.x >= blockRows.at(u).at(a).position.x+globals.blockSize.x-2)
                            {
                                balls.at(i).direction = sf::Vector2f(-balls.at(i).direction.x, balls.at(i).direction.y);
                            }
                            else
                            {
                                balls.at(i).direction = sf::Vector2f(balls.at(i).direction.x, -balls.at(i).direction.y);
                            }
                        }
                        else
                        {
                            if(balls.at(i).position.x <= blockRows.at(u).at(a).position.x+2)
                            {
                                balls.at(i).direction = sf::Vector2f(-balls.at(i).direction.x, balls.at(i).direction.y);
                            }
                            else
                            {
                                balls.at(i).direction = sf::Vector2f(balls.at(i).direction.x, -balls.at(i).direction.y);
                            }
                        }

                        points+=blockRows.at(u).at(a).points;
                        blockRows.at(u).erase(blockRows.at(u).begin()+a);

                        blocksEmpty = true;
                        for(int i = 0;i < blockRows.size();i++)
                        {
                            if(!blockRows.at(i).empty())
                            {
                                blocksEmpty = false;
                                break;
                            }
                        }

                        if(blocksEmpty)
                        {
                            balls.push_back(Ball(sf::Vector2f(globals.windowSize.x/2, globals.windowSize.y/2), player.sprite.GetSize().x, player.position.y));
                            newLevel();
                        }
                    }
                }
            }
        }
    }
}

void Game::getEvents()
{
    sf::Event event;
    window.myWindow.GetEvent(event);

    switch(event.Type)
    {
        default:
            break;
        case sf::Event::Closed:
        {
            window.myWindow.Close();
            break;
        }
        case sf::Event::KeyPressed:
        {
            switch(event.Key.Code)
            {
                default:
                {
                    break;
                }
                case sf::Key::Escape:
                {
                    window.myWindow.Close();
                    break;
                }
 /*               case sf::Key::M:
                {
                    menuMode = !menuMode;
                    break;
                }
                case sf::Key::Up:
                {
                    if(menu.selected <= 0)
                        menu.selected = menu.items.size()-1;
                    else
                        menu.selected--;
                    break;
                }
                case sf::Key::Down:
                {
                    if(menu.selected >= menu.items.size()-1)
                        menu.selected = 0;
                    else
                        menu.selected++;
                    break;
                }
                case sf::Key::Return:
                {
                    if(menuMode)
                    {
                        switch(menu.selected)
                        {
                            default:
                                break;
                            case 1:
                            {
                                menuMode = false;
                            }
                            case 2:
                            {
                                window.myWindow.Close();
                                break;
                            }
                        }
                    }
                    break;
                }*/
            }
            break;
        }
    }
}

void Game::updateMenu()
{
    for(int i = 0;i < menu.items.size();i++)
    {
        if(i == menu.selected)
        {
            menu.items.at(i).sprite = activeMenuItem;
        }
        else
        {
            menu.items.at(i).sprite = inactiveMenuItem;
        }
    }
}

void Game::updateItems()
{
    if(!menuMode)
    {
        //Schl�ger
        player.position = sf::Vector2f(window.myWindow.GetInput().GetMouseX()-(player.sprite.GetSize().x/2), player.position.y);

        if(player.position.x < 0)
            player.position = sf::Vector2f(0, player.position.y);
        else if(player.position.x+player.sprite.GetSize().x > globals.windowSize.x)
            player.position = sf::Vector2f(globals.windowSize.x-player.sprite.GetSize().x, player.position.y);

        player.sprite.SetPosition(player.position);

        //Ball
        for(int i = 0;i < balls.size();i++)
        {
            balls.at(i).move(player.position.x);
            if(balls.at(i).ballOutOfScreen())
            {
                if(ballCount <= 0)
                {
                    //
                }
                else
                {
                    ballCount--;
                    newBall(i);
                }
            }
        }

        //Bloecke
        blockCollision();

    }
}

void Game::drawWindow()
{
    window.myWindow.Clear();

    if(menuMode)
    {
        for(int i = 0;i < menu.items.size();i++)
        {
            window.myWindow.Draw(menu.items.at(i).sprite);
        }
    }
    else
    {
        for(int i = 0;i < balls.size();i++)
        {
            window.myWindow.Draw(balls.at(i).sprite);
        }


        for(int i = 0;i < blockRows.size();i++)
        {
            for(int e = 0;e < blockRows.at(i).size();e++)
            {
                blockSprite.SetImage(blockImages.at(blockRows.at(i).at(e).points-1));
                blockSprite.SetPosition(blockRows.at(i).at(e).position);
                window.myWindow.Draw(blockSprite);
            }
        }

        window.myWindow.Draw(player.sprite);
    }

    std::ostringstream str;
    str<<"\nLevel: "<<level<<"\nPunkte: "<<points<<"\n�brige B�lle: "<<ballCount;
    strB.SetText(str.str());

    window.myWindow.Draw(strB);

    window.myWindow.Display();
}

void Game::loop()
{
    while(window.myWindow.IsOpened())
    {
        getEvents();
        updateItems();
        drawWindow();
    }
}
