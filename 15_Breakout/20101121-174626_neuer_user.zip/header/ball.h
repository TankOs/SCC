#ifndef BALL_H
#define BALL_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "globals.h"

class Ball
{
private: Globals globals;
private: sf::Image image;
private: sf::SoundBuffer buffer;
private: sf::Sound sound;
public: sf::Sprite sprite;
public: sf::Vector2f position;
public: sf::Vector2f direction;
public: float speed;
private: float playerWidth, playerPosY;
public:
    Ball(sf::Vector2f pos, float playerSizeX, float playerY);
    bool collision(float playerPosX);
    bool ballOutOfScreen();
    void move(float playerPosX);
};

#endif // BALL_H
