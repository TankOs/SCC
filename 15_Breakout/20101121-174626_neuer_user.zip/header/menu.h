#ifndef MENU_H
#define MENU_H

#include "item.h"
#include "globals.h"

class Menu
{
private: Globals globals;
public: std::vector<Item> items;
public: int selected;
public:
    Menu();
};

#endif // MENU_H
