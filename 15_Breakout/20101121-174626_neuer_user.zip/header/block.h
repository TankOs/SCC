#ifndef BLOCK_H
#define BLOCK_H

#include <SFML/Graphics.hpp>

class Block
{    
public: sf::Sprite sprite;
public: sf::Vector2f position;
public: int points;
public: sf::Image image;
public:
    Block(sf::Vector2f pos, int punkte, sf::Image img);
};

#endif // BLOCK_H
