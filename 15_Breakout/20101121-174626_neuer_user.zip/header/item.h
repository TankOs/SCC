#ifndef ITEM_H
#define ITEM_H

#include <SFML/Graphics.hpp>

class Item
{
public: sf::Sprite sprite;
public: sf::Image image;
public: sf::Image image_hover;
public: sf::String label;
private: sf::Font font;
public:
    Item(std::string string);
};

#endif // ITEM_H
