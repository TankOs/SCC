#ifndef WINDOW_H
#define WINDOW_H

#include <SFML/Graphics.hpp>
#include "globals.h"

class Window
{
public: Globals globals;
private: sf::VideoMode mode;
private: sf::WindowSettings settings;
public: sf::RenderWindow myWindow;
public:
    Window();
};

#endif // WINDOW_H
