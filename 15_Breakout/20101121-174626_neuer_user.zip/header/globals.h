#ifndef GLOBALS_H
#define GLOBALS_H

#include <SFML/Graphics.hpp>

class Globals
{
public: sf::Vector2i windowSize;
public: sf::Vector2f menuMargins;
public: sf::Vector2f menuPaddings;
public: sf::Vector2f menuItemSize;
public: sf::Vector2f playerSize;
public: sf::Vector2f blockSize;
public: float blockMargin;
public:
    Globals();
};

#endif // GLOBALS_H
