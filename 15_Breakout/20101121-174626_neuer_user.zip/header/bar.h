#ifndef BAR_H
#define BAR_H

#include <SFML/Graphics.hpp>

class Bar
{
public: sf::Sprite sprite;
public: sf::Vector2f position;
private: sf::Image image;
public:
    Bar();
    void init(sf::Vector2f pos);
};

#endif // BAR_H
