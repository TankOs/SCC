#ifndef GAME_H
#define GAME_H

#include <sstream>
#include "window.h"
#include "menu.h"
#include "bar.h"
#include "ball.h"
#include "block.h"

class Game
{
private: Globals globals;
private: Menu menu;
private: Bar player;
private: Window window;
private: bool menuMode, blocksEmpty;
private: int ballCount, level, points;
private: std::deque<Ball> balls;
private: std::vector<std::deque<Block> > blockRows;
private: std::deque<Block> temp;
private: std::ostringstream str;
private: sf::String strB;
private: sf::Font font;
private: std::vector<sf::Image> blockImages;
private: sf::Image blockImg, activeMenuImage, inactiveMenuImage;
private: sf::Sprite blockSprite, activeMenuItem, inactiveMenuItem;
public:
    Game();
    void newLevel();
    void newBall(int nr);
    bool blockCollision();
    void getEvents();
    void updateMenu();
    void updateItems();
    void drawWindow();
    void loop();
};

#endif // GAME_H
