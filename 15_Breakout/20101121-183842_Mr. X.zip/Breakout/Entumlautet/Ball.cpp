#include "Ball.h"
#include "Ressourcen.h"


void Ball::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(Sprite);
}

Ball::Ball() : sf::Drawable(sf::Vector2f(75, 384)), Sprite(RM.Get<sf::Image>("Ball.png")), Bewegung(200, -135), Stein(RM.Get<sf::SoundBuffer>("Wand.wav")), Wand(RM.Get<sf::SoundBuffer>("Wand.wav")), Schlaeger(RM.Get<sf::SoundBuffer>("Schlaeger.wav")) {
	SetOrigin(Sprite.GetImage()->GetWidth()/2.f, Sprite.GetImage()->GetHeight()/2.f); 
}

void Ball::Move(float Speed) {
	sf::Vector2f Temp = Bewegung;
	Drawable::Move(Speed*Temp.x, Speed*Temp.y);
}

sf::FloatRect Ball::GetRect() const {
	static const sf::Vector2f Size((float)Sprite.GetImage()->GetWidth(), (float)Sprite.GetImage()->GetHeight());
	return(sf::FloatRect(GetPosition()-GetOrigin(), Size));
}

bool Ball::KollisionI(const sf::FloatRect& R) {
	sf::Vector2<bool> v = Collision(Bewegung, GetRect(), R);

	if(v.x) {
		Bewegung.Alpha = 360-Bewegung.Alpha;
	}
	if(v.y) {
		Bewegung.Alpha = 180-Bewegung.Alpha;
	}

	return(v.x||v.y);
}
bool Ball::KollisionW(const sf::FloatRect& R) {
	bool retval = false;

	static const float halfsize = Sprite.GetImage()->GetWidth()/2.f;
	if(GetPosition().y-halfsize < R.Top || GetPosition().y+halfsize > R.Top+R.Height) {
		Bewegung.Alpha = 360-Bewegung.Alpha;
		SetPosition(GetPosition().x, ToBounds(R.Top, GetPosition().y, R.Top+R.Height));
		retval = true;
	}
	if(GetPosition().x-halfsize < R.Left || GetPosition().x+halfsize > R.Left+R.Width) {
		Bewegung.Alpha = 180-Bewegung.Alpha;
		SetPosition(ToBounds(R.Left, GetPosition().x, R.Left+R.Width), GetPosition().y);
		retval = true;
	}


	return(retval);
}
