#include "Feld.h"
#include "Ressourcen.h"
#include <istream>


void Feld::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	for(uint8_t i = 0; i < 15; i++) {
		for(uint8_t j = 0; j < 15; j++) {
			if(Steine[i][j] != 0)
				Target.Draw(*Steine[i][j]);
		}
	}
}

Feld::Feld() : SteinVerschwindet(RM.Get<sf::SoundBuffer>("Verschwindet.wav")) {
	memset(Steine, 0, 15*15*sizeof(Stein*));
}

void Feld::Load(std::istream& ifs) {
	Unload();
	for(uint8_t j = 0; j < 15; j++) {
		for(uint8_t i = 0; i < 15; i++) {
			char typ;
			ifs >> typ;
			switch(typ) {
				case 'F':
					Steine[i][j] = new Stein(Stein::FEST);
					break;
				case 'P':
					Steine[i][j] = new Stein(Stein::POSITIV);
					break;
				case 'N':
					Steine[i][j] = new Stein(Stein::NEGATIV);
					break;
				default:
					break;
			}
			if(Steine[i][j] != 0)
				Steine[i][j]->SetPosition(167.f + i*46.f, 129.f + j*34.f);
		}
	}
}

void Feld::Unload() {
	for(uint8_t i = 0; i < 15; i++) {
		for(uint8_t j = 0; j < 15; j++) {
			delete Steine[i][j];
			Steine[i][j] = 0;
		}
	}
}

int16_t Feld::Destroy(uint8_t i, uint8_t j) {
	switch(Steine[i][j]->GetTyp()) {
		case Stein::POSITIV:
			delete Steine[i][j];
			Steine[i][j] = 0;
			SteinVerschwindet.Play();
			return(1);
		case Stein::NEGATIV:
			delete Steine[i][j];
			Steine[i][j] = 0;
			SteinVerschwindet.Play();
			return(-1);
		default:
			return(0);
	}
}

bool Feld::Abgeraeumt() const {
	for(uint8_t i = 0; i < 15; i++) {
		for(uint8_t j = 0; j < 15; j++) {
			if(Steine[i][j] && Steine[i][j]->GetTyp() == Stein::POSITIV)
				return(false);
		}
	}
	return(true);
}

Feld::~Feld() {
	Unload();
}
