#ifndef SCHL�GER_H
#define SCHL�GER_H

#include "Global.h"


class Schlaeger : public sf::Drawable {
	sf::Sprite Sprite;

	virtual void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	Schlaeger();
	void SetPosition(float x, float y, float Time);
	sf::FloatRect GetRect() const;
};


#endif
