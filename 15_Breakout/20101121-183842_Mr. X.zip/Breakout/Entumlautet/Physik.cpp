#include "Physik.h"


#define PI 3.14159265358979323846f


static float radtodeg(float f) {
	return(180.0f*f/PI);
}
static float degtorad(float f) {
	return(f*PI/180.0f);
}


PhysVec::PhysVec(float x, float alpha) : X(x), Alpha(alpha) {}
PhysVec::PhysVec(const sf::Vector2f& vec) : X(sqrt(vec.x*vec.x+vec.y*vec.y)), Alpha(radtodeg(asin(vec.y/X))) {}

PhysVec::operator sf::Vector2f() const {
	return(sf::Vector2f(X*cos(degtorad(Alpha)), X*sin(degtorad(Alpha))));
}

sf::Vector2<bool> Collision(sf::Vector2f Speed, sf::FloatRect R1, sf::FloatRect R2) {
	sf::FloatRect R3(R1.Left-Speed.x, R1.Top-Speed.y, R1.Width, R1.Height);
	if(!R3.Intersects(R2) && R1.Intersects(R2, R3)) { // Collidate
		return(sf::Vector2<bool>(std::abs(R3.Height/Speed.y) <= std::abs(R3.Width/Speed.x), std::abs(R3.Height/Speed.y) >= std::abs(R3.Width/Speed.x)));
	}
	else {
		return(sf::Vector2<bool>(false, false));
	}
}
