#ifndef GLOBAL_H
#define GLOBAL_H

#include <cstdint>
#include <cmath>
#include <SFML/Audio.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>


template<typename T>
T ToBounds(T lower, T value, T higher) {
	return(std::max(lower, std::min(higher, value)));
}

enum Spielstatus {
	BEGINN, SPIEL, ENDE
};

extern sf::Clock Uhr;

void SetStatus(Spielstatus status);
Spielstatus GetStatus();


#endif
