#include "Ressourcen.h"


Ressourcenmanager RM;

Ressource::Ressource() : Type(RES_NONE) {}

Ressource::~Ressource() {
	switch(Type) {
		case RES_IMAGE:
			delete Image;
			break;
		case RES_SOUND:
			delete Sound;
			break;
		default:
			break;
	}
}
