#ifndef STEIN_H
#define STEIN_H

#include "Global.h"


class Stein : public sf::Drawable {
public:
	enum TYP {LEER, FEST, POSITIV, NEGATIV};
private:
	TYP Typ;

	sf::Sprite Sprite;

	virtual void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	Stein(TYP typ);
	TYP GetTyp() const;
	sf::FloatRect GetRect() const;
};


#endif
