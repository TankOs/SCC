#include "Global.h"
#include "Spiel.h"
#include "Ressourcen.h"
#include "Button.h"
#include <sstream>


int main() {
	sf::RenderWindow RW(sf::VideoMode(1024, 768), "Breakout", sf::Style::Fullscreen);
	RW.SetFramerateLimit(100);
	bool Running = true;
	sf::Event EV;
	const sf::Input& IP = RW.GetInput();

	sf::Sprite Hintergrund(RM.Get<sf::Image>("Hintergrund.png"));

	Spiel *spiel = new Spiel;
	
	// "GUI"
	std::ostringstream os; // Zum Zusammenbauen der Strings
	sf::Text Punkte;
	Punkte.SetStyle(sf::Text::Bold);
	Punkte.SetPosition(5, 15);
	Punkte.SetCharacterSize(35);
	Punkte.SetRotation(5);
	Punkte.SetColor(sf::Color(60, 50, 220, 230));
	sf::Text Level;
	Level.SetStyle(sf::Text::Bold);
	Level.SetCharacterSize(35);
	Level.SetRotation(-5);
	Level.SetColor(sf::Color(60, 50, 220, 230));
	sf::Text Fertig("Spiel durchgespielt!");
	Fertig.SetCharacterSize(100);
	Fertig.SetPosition(1024/2-Fertig.GetRect().Width/2, 768/2-Fertig.GetRect().Height/2);
	Fertig.SetColor(sf::Color(200, 200, 30, 210));
	sf::Text Countdown("5");
	Countdown.SetCharacterSize(200);
	Countdown.SetPosition(1024/2-Countdown.GetRect().Width/2, 768/2-Countdown.GetRect().Height/2);
	Countdown.SetColor(sf::Color(220, 50, 60, 210));
	Button Reset("Zur�cksetzen", sf::Vector2f(10, 768 - 60), sf::Vector2f(250, 50));
	Button Neustart("Neu starten", sf::Vector2f(400, 768 - 60), sf::Vector2f(244, 50));
	Button Beenden("Beenden", sf::Vector2f(1024-10-200, 768 - 60), sf::Vector2f(200, 50));

	while(Running) {
		while(RW.GetEvent(EV)) {
			switch(EV.Type) {
				case sf::Event::Closed:
					Running = false;
					break;
				case sf::Event::KeyReleased:
					if(EV.Key.Code == sf::Key::Escape)
						Running = false;
					break;
				case sf::Event::MouseButtonReleased:
					if(EV.MouseButton.Button == sf::Mouse::Left) {
						if(Reset.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
							spiel->Level = 0;
							delete spiel;
							spiel = new Spiel();
						}
						else if(Neustart.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
							delete spiel;
							spiel = new Spiel();
						}
						else if(Beenden.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
							Running = false;
						}
					}
					break;
			}
		}
		
		spiel->Run(IP, RW.GetFrameTime());

		os.str("");
		os << "Punkte: " << spiel->Punkte;
		Punkte.SetString(os.str());
		os.str("");
		os << "Level: " << spiel->Level;
		Level.SetString(os.str());
		Level.SetPosition(1024 - Level.GetRect().Width - 5, 0);

		RW.Clear();
		RW.Draw(Hintergrund);
		RW.Draw(*spiel);
		switch(GetStatus()) {
			case BEGINN:
				if(Uhr.GetElapsedTime() >= 5.f)
					SetStatus(SPIEL);
				else {
					os.str("");
					os << static_cast<unsigned int>(5.f - Uhr.GetElapsedTime());
					Countdown.SetString(os.str());
					RW.Draw(Countdown);
				}
				break;
			case SPIEL:
				break;
			case ENDE:
				RW.Draw(Fertig);
				break;
		}
		RW.Draw(Punkte);
		RW.Draw(Level);
		RW.Draw(Reset);
		RW.Draw(Neustart);
		RW.Draw(Beenden);
		RW.Display();
	}

	delete spiel;
	return(0);
}
