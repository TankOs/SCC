#include "Global.h"


Spielstatus Status = BEGINN;
sf::Clock Uhr;

void SetStatus(Spielstatus status) {
	if(status == BEGINN) {
		Uhr.Reset();
	}
	Status = status;
}

Spielstatus GetStatus() {
	return(Status);
}
