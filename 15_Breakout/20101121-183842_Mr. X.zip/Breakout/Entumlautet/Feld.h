#ifndef FELD_H
#define FELD_H

#include "Global.h"
#include "Stein.h"


class Feld : public sf::Drawable {
	sf::Sound SteinVerschwindet;

	virtual void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	Stein* Steine[15][15];

	Feld();
	void Load(std::istream& ifs);
	void Unload();
	int16_t Destroy(uint8_t i, uint8_t j);
	bool Abgeraeumt() const;
	~Feld();
};


#endif
