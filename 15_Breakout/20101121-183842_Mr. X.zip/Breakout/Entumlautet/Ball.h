#ifndef BALL_H
#define BALL_H

#include "Global.h"
#include "Physik.h"


class Ball : public sf::Drawable {
	sf::Sprite Sprite;

	virtual void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	sf::Sound Wand, Schlaeger, Stein;
	PhysVec Bewegung;

	Ball();
	void Move(float Speed);
	sf::FloatRect GetRect() const;
	bool KollisionI(const sf::FloatRect& R);
	bool KollisionW(const sf::FloatRect& R);
};


#endif
