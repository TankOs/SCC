#include "Schlaeger.h"
#include "Ressourcen.h"


void Schl�ger::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(Sprite);
}

Schl�ger::Schl�ger() : Sprite(RM.Get<sf::Image>("Schlaeger.png")) {
	SetOrigin(Sprite.GetSubRect().Width/2, Sprite.GetSubRect().Height/2);
}

void Schl�ger::SetPosition(float x, float y, float Time) {
	Move(ToBounds(Time*-250.f, x - GetPosition().x, Time*250.f), ToBounds(Time*-250.f, y - GetPosition().y, Time*250.f));
}

sf::FloatRect Schl�ger::GetRect() const {
	static const int x = Sprite.GetSubRect().Width;
	static const int y = Sprite.GetSubRect().Height;
	if(GetRotation()==90 || GetRotation()==270)
		return(sf::FloatRect(GetPosition().x - y/2.f, GetPosition().y - x/2.f, y, x));
	else
		return(sf::FloatRect(GetPosition().x - x/2.f, GetPosition().y - y/2.f, x, y));
}
