#ifndef PHYSIK_H
#define PHYSIK_H

#include "Global.h"


struct PhysVec {
	float X; // Gr��e
	float Alpha; // Winkel

	PhysVec(float x = 0.0f, float alpha = 0.0f);
	PhysVec(const sf::Vector2f& vec);
	operator sf::Vector2f() const;
};

sf::Vector2<bool> Collision(sf::Vector2f Speed, sf::FloatRect R1, sf::FloatRect R2); // Erste Objekt bewegt sich


#endif
