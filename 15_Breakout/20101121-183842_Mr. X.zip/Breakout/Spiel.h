#ifndef SPIEL_H
#define SPIEL_H

#include "Global.h"
#include "Schlaeger.h"
#include "Ball.h"
#include "Feld.h"


class Spiel : public sf::Drawable {
	Ball B;
	Schl�ger S[4];
	Feld F;
	virtual void Render(sf::RenderTarget& Target, sf::Renderer&) const;
	void NextLevel();
public:
	uint16_t Level;
	int16_t Punkte;

	Spiel();
	void Run(const sf::Input& IP, float Time);
	~Spiel();
};


#endif
