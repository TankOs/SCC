#ifndef BUTTON_H
#define BUTTON_H

#include "Global.h"


class Button : public sf::Drawable {
private:
	sf::Shape Rand;
	sf::Text Text;
protected:
	void Render(sf::RenderTarget& Target, sf::Renderer&) const;
public:
	bool IsClicked(sf::Vector2i MousePosition) const;
	Button(const sf::String& sText, const sf::Vector2f& Position, const sf::Vector2f& Size);
};


#endif
