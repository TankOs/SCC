#include "Stein.h"
#include "Ressourcen.h"


void Stein::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(Sprite);
}

Stein::Stein(TYP typ) : Typ(typ) {
	switch(Typ) {
		case FEST:
			Sprite.SetImage(RM.Get<sf::Image>("Stein_F.png"));
			break;
		case POSITIV:
			Sprite.SetImage(RM.Get<sf::Image>("Stein_P.png"));
			break;
		case NEGATIV:
			Sprite.SetImage(RM.Get<sf::Image>("Stein_N.png"));
			break;
		default: // Leere Steine d�rfen nie erzeugt werden
			throw 0;
			break;
	}
}

Stein::TYP Stein::GetTyp() const {
	return(Typ);
}

sf::FloatRect Stein::GetRect() const {
	static const sf::Vector2f Size((float)Sprite.GetImage()->GetWidth(), (float)Sprite.GetImage()->GetHeight());
	return(sf::FloatRect(GetPosition(), Size));
}
