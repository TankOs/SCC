#include "Spiel.h"
#include "Ressourcen.h"
#include <fstream>
#include <sstream>


bool operator>(const sf::FloatRect& A, const sf::FloatRect& B) {
	return(A.Height+A.Width > B.Height+B.Width); // Umfang besser als Fl�cheninhalt
}

void Spiel::Render(sf::RenderTarget& Target, sf::Renderer&) const {
	Target.Draw(F);
	Target.Draw(B);
	for(uint8_t i = 0; i < 4; i++) {
		Target.Draw(S[i]);
	}
}

Spiel::Spiel() : Level(0), Punkte(0) {
	S[0].SetRotation(90);
	S[1].SetRotation(180);
	S[2].SetRotation(270);

	std::ifstream ifs("Level/Status");
	if(ifs.good()) {
		ifs >> Level;
		ifs.close();
	}

	NextLevel();
}

void Spiel::NextLevel() {
	std::ostringstream os;
	os << "Level/" << Level << ".bs";

	std::ifstream ifs(os.str());
	
	if(ifs.good()) {
		SetStatus(BEGINN);
		B.SetPosition(75, 384);
		F.Load(ifs);
		ifs.close();
	}
	else { // Spiel durchgespielt.
		SetStatus(ENDE);
	}
}

void Spiel::Run(const sf::Input& IP, float Time) {
	static const int x = RM.Get<sf::Image>("Schlaeger.png").GetWidth()/2;
	static const int y = RM.Get<sf::Image>("Schlaeger.png").GetHeight()/2;
	S[0].SetPosition(ToBounds(y+x*2, IP.GetMouseX(), 1024-y-x*2), x, Time);
	S[2].SetPosition(ToBounds(y+x*2, IP.GetMouseX(), 1024-y-x*2), 768 - x, Time);
	S[1].SetPosition(x, ToBounds(y, IP.GetMouseY(), 768-y), Time);
	S[3].SetPosition(1024 - x, ToBounds(y, IP.GetMouseY(), 768-y), Time);

	if(GetStatus() == SPIEL) {
		B.Move(Time);

		// Wand
		if(B.KollisionW(sf::FloatRect(0,0,1024,768))) {
			B.Wand.Play();
			Punkte--;
		}
		else {
			// Schl�ger
			sf::FloatRect Ball = B.GetRect();
			if(Ball.Intersects(S[0].GetRect())) {
				B.Bewegung.Alpha = 90.f-1.25f*((Ball.Left+Ball.Width/2.f) - (S[0].GetRect().Left + S[0].GetRect().Width/2.f));
				B.Schl�ger.Play();
			}
			else if(Ball.Intersects(S[2].GetRect())) {
				B.Bewegung.Alpha = -90.f+1.25f*((Ball.Left+Ball.Width/2.f) - (S[2].GetRect().Left + S[2].GetRect().Width/2.f));
				B.Schl�ger.Play();
			}
			if(Ball.Intersects(S[1].GetRect())) {
				B.Bewegung.Alpha = 1.25f*((Ball.Top+Ball.Height/2.f) - (S[1].GetRect().Top + S[1].GetRect().Height/2.f));
				B.Schl�ger.Play();
			}
			else if(Ball.Intersects(S[3].GetRect())) {
				B.Bewegung.Alpha = 180.f-1.25f*((Ball.Top+Ball.Height/2.f) - (S[3].GetRect().Top + S[3].GetRect().Height/2.f));
				B.Schl�ger.Play();
			}

			// Steine
			int8_t x = -1, y = -1;
			sf::FloatRect Gr��tes(0,0,0,0);
			sf::FloatRect Temp;
			for(uint8_t i = 0; i < 15; i++) { // St�rkste �berschneidung rausfinden
				for(uint8_t j = 0; j < 15; j++) {
					if(F.Steine[i][j]) {
						Ball.Intersects(F.Steine[i][j]->GetRect(), Temp);
						if(Temp>Gr��tes) {
							Gr��tes = Temp;
							x = i;
							y = j;
						}
					}
				}
			}

			if(x != -1 && y != -1 && B.KollisionI(F.Steine[x][y]->GetRect())) {
				Punkte += F.Destroy(x, y);
				B.Stein.Play();
			}
		}

		if(F.Abger�umt()) {
			if(Punkte > 0)
				Level++;
			NextLevel();
		}
	}
}

Spiel::~Spiel() {
	std::ofstream ofs("Level/Status");
	if(ofs.good()) {
		ofs << Level;
		ofs.close();
	}
}
