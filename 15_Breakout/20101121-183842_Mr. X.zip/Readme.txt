﻿SPIELZIEL:
Um zu gewinnen musst Du eine positive Anzahl an Punkten haben und alle grünen Steine abräumen. Diese erhöhen deinen Punktezähler um eins, rote Steine oder ein Aufprall des Balles auf die Wand senken ihn um eins. Gelbe Steine sind nicht zerstörbar.

BEDIENUNG:
Die Paddles werden mit der Maus gesteuert.
Das Spiel speichert das zuletzt erreichte Level, damit Du nicht immer von vorne beginnen musst. Um diesen Zähler zurückzusetzen, drücke den "Zurücksetzen"-Button im Spiel. Um das aktuelle Level von vorne zu beginnen, drücke "Neu starten".

ERWEITERN:
Das Spiel ist in Bezug auf die Anzahl an Levels beliebig erweiterbar. Um neue Levels hinzuzufügen, erstelle eine neue Datei mit dem Namen #.bs, wobei # eine fortlaufende Zahl sein muss. Das Dateiformat kannst Du dir hierbei von den anderen Leveln abgucken. Jedes Spielfeld muss hierbei 15*15 Steine groß sein.


HINWEISE/FEHLERQUELLEN:
Der Sourcecode wurde mit SFML2, Revision 1690 kompiliert und getestet.
Um die mitgelieferten Binaries ausführen zu können, muss auf dem Zielrechner das VCredist 2010 installiert sein:
x64-Download: http://www.microsoft.com/downloads/en/details.aspx?FamilyID=bd512d9e-43c8-4655-81bf-9350143d5867
x86-Download: http://www.microsoft.com/downloads/en/details.aspx?FamilyID=a7b7a05e-6de6-4d3a-a423-37bf0912db84