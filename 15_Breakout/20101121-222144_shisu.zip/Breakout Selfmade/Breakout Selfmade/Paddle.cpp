#include "Paddle.h"
#include "ImageManager.h"

Paddle::Paddle(const sf::Vector2f& pPosition, int pDrehung, bool pSmall, const sf::Vector2f& pSchranken)
: Drawable(pPosition), Position_OL(pPosition), Drehung(pDrehung), Schranken(pSchranken)
{
	if( !pSmall )
	{
		switch( pDrehung )
		{
			case 0: Bild_Sprite.SetImage( *ImgMng.getResource("Pictures/Paddle.png") ); break;
			case 90: Bild_Sprite.SetImage( *ImgMng.getResource("Pictures/Paddle_90.png") ); break;
			case 180: Bild_Sprite.SetImage( *ImgMng.getResource("Pictures/Paddle_180.png") ); break;
			case 270: Bild_Sprite.SetImage( *ImgMng.getResource("Pictures/Paddle_270.png") ); break;
		}
	}
	else
	{
		switch( pDrehung )
		{
			case 0: Bild_Sprite.SetImage( *ImgMng.getResource("Pictures/Paddle_S.png") ); break;
			case 90: Bild_Sprite.SetImage( *ImgMng.getResource("Pictures/Paddle_90_S.png") ); break;
			case 180: Bild_Sprite.SetImage( *ImgMng.getResource("Pictures/Paddle_180_S.png") ); break;
			case 270: Bild_Sprite.SetImage( *ImgMng.getResource("Pictures/Paddle_270_S.png") ); break;
		}
	}
	Size = Bild_Sprite.GetSize();
}

sf::Vector2f Paddle::getPosition_OL() const
{
	return Position_OL;
}

sf::Vector2f Paddle::getSize() const
{
	return Size;
}

void Paddle::Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const
{
	Target.Draw( Bild_Sprite );
}

void Paddle::moveCenterToX(double pPosition)
{
	if( pPosition >= Schranken.x && pPosition <= Schranken.y )
	{
		if( Drehung == 90 || Drehung == 270 )
		{
			this->SetPosition(pPosition - Size.x/2, this->GetPosition().y);
			Position_OL = sf::Vector2f(pPosition - Size.x/2, this->GetPosition().y);
		}
		else
		{
			this->SetPosition(pPosition - Size.x/2, this->GetPosition().y);
			this->Position_OL = sf::Vector2f(pPosition - Size.x/2, this->GetPosition().y);
		}
	}
	else
	{
		if(pPosition <= Schranken.x)
		{
			if( Drehung == 90 || Drehung == 270 )
			{
				this->SetPosition(Schranken.x - Size.x/2, this->GetPosition().y);
				Position_OL = sf::Vector2f(Schranken.x - Size.x/2, this->GetPosition().y);
			}
			else
			{
				this->SetPosition(Schranken.x - Size.x/2, this->GetPosition().y);
				this->Position_OL = sf::Vector2f(Schranken.x - Size.x/2, this->GetPosition().y);
			}
		}
		else
		{
			if( Drehung == 90 || Drehung == 270 )
			{
				this->SetPosition(Schranken.y - Size.x/2, this->GetPosition().y);
				Position_OL = sf::Vector2f(Schranken.y - Size.x/2, this->GetPosition().y);
			}
			else
			{
				this->SetPosition(Schranken.y - Size.x/2, this->GetPosition().y);
				this->Position_OL = sf::Vector2f(Schranken.y - Size.x/2, this->GetPosition().y);
			}
		}
	}
}

sf::Vector2f Paddle::getPosition_Center() const
{
	return sf::Vector2f(Position_OL.x+Size.x/2, Position_OL.y+Size.y/2);
}

int Paddle::getDrehung() const
{
	return Drehung;
}

void Paddle::moveCenterToY(double pPosition)
{
	if( pPosition >= Schranken.x && pPosition <= Schranken.y )
	{
		if( Drehung == 90 || 270 )
		{
			this->SetPosition(this->GetPosition().x, pPosition - Size.y/2);
			this->Position_OL = sf::Vector2f(this->GetPosition().x, pPosition - Size.y/2);
		}
		else
		{
			this->SetPosition(this->GetPosition().x, pPosition - Size.y/2);
			this->Position_OL = sf::Vector2f(this->GetPosition().x, pPosition - Size.y/2);
		}
	}
	else
	{
		if(pPosition <= Schranken.x)
		{
			if( Drehung == 90 || 270 )
			{
				this->SetPosition(this->GetPosition().x, Schranken.x - Size.y/2);
				this->Position_OL = sf::Vector2f(this->GetPosition().x, Schranken.x - Size.y/2);
			}
			else
			{
				this->SetPosition(this->GetPosition().x, Schranken.x - Size.y/2);
				this->Position_OL = sf::Vector2f(this->GetPosition().x, Schranken.x - Size.y/2);
			}
		}
		else
		{
			if( Drehung == 90 || 270 )
			{
				this->SetPosition(this->GetPosition().x, Schranken.y - Size.y/2);
				this->Position_OL = sf::Vector2f(this->GetPosition().x, Schranken.y - Size.y/2);
			}
			else
			{
				this->SetPosition(this->GetPosition().x, Schranken.y - Size.y/2);
				this->Position_OL = sf::Vector2f(this->GetPosition().x, Schranken.y - Size.y/2);
			}
		}
	}
}