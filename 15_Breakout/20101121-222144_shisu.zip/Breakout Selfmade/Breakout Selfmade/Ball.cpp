#include "Ball.h"
#include "ImageManager.h"

Ball::Ball(const sf::Vector2f& pPosition, float pRadius)
: Drawable(sf::Vector2f(pPosition.x-pRadius, pPosition.y-pRadius)), Position_Center(pPosition), Radius(pRadius),
Bild_Sprite( *ImgMng.getResource("Pictures/Ball2.png") )
{
}

float Ball::getRadius() const
{
	return Radius;
}

void Ball::moveTo(const sf::Vector2f& pPosition)
{
	Position_Center = pPosition;
	this->SetPosition(pPosition.x - Radius, pPosition.y - Radius);
}

void Ball::invertTempo_X()
{
	Tempo.x = -Tempo.x;
}

void Ball::invertTempo_Y()
{
	Tempo.y = -Tempo.y;
}

sf::Vector2f Ball::getTempo() const
{
	return Tempo;
}

void Ball::invertTempo_Full()
{
	Tempo.x = -Tempo.x;
	Tempo.y = -Tempo.y;
}

void Ball::setTempo(const sf::Vector2f& pTempo)
{
	Tempo = pTempo;
}

void Ball::pixelMove()
{
	this->Move(Tempo.x/100, Tempo.y/100);
	Position_Center = sf::Vector2f(this->GetPosition().x+Radius, this->GetPosition().y+Radius);
}

void Ball::fly(double pFaktor)
{
	this->Move(Tempo.x*pFaktor, Tempo.y*pFaktor);
	Position_Center = sf::Vector2f(this->GetPosition().x+Radius, this->GetPosition().y+Radius);
}

sf::Vector2f Ball::getPosition_Center() const
{
	return Position_Center;
}

sf::Vector2f Ball::getPosition_OL() const
{
	return sf::Vector2f(Position_Center.x-Radius, Position_Center.y-Radius);
}

void Ball::Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const
{
	Target.Draw( Bild_Sprite );
}