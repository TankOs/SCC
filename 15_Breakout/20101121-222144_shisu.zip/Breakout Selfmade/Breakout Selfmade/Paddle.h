#ifndef PADDLE_H
#define PADDLE_H

/* Bibliotheken-Includes */
#include <iostream>
#include <fstream>
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <sstream>

/* Eigene Header-Includes */

/* Paddle
 * Ein Paddle ist das vom Spieler direkt durch Mausbewegung bewegte Spielelement, das den Ball abblocken und somit
 * dem Spieler zu gewinnen helfen kann. */
class Paddle : public sf::Drawable
{
private:
	void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const;
	sf::Vector2f Position_OL, Size, Schranken;
	sf::Sprite Bild_Sprite;
	int Drehung;
public:
	Paddle(const sf::Vector2f& pPosition, int pDrehung, bool pSmall, const sf::Vector2f& pSchranken);
	sf::Vector2f getPosition_OL() const;
	sf::Vector2f getPosition_Center() const;
	sf::Vector2f getSize() const;
	int getDrehung() const;
	void moveCenterToX(double pPosition);
	void moveCenterToY(double pPosition);
};

#endif