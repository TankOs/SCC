#include <iostream>
 
#include "FontManager.h"
 
using namespace std;
 
sf::Font* FontManager::load( const std::string& strId ) {
	sf::Font* font = new sf::Font();
    if( !font->LoadFromFile( strId ) ) {
        cout << "[WARN] FontManager failed to load: " << strId << endl;
        delete font;
        font = NULL;
    }
 
    return font;
}