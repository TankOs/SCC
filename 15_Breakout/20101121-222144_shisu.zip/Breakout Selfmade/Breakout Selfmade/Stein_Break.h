#ifndef STEIN_BREAK_H
#define STEIN_BREAK_H

/* Bibliotheken-Includes */

/* Eigene Header-Includes */
#include "Stein.h"
#include "Ball.h"

/* Stein_Break
 * Der Stein_Break befindet sich auf dem Spielfeld und existiert dort, bis er vom Ball getroffen und zerst�rt wird. */
class Stein_Break : public Stein
{
private:
public:
	Stein_Break(const sf::Vector2f& pPosition, const std::string& pBildpfad);
	void hit(Ball& pBall);
};

#endif