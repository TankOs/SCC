#ifndef STRUCT_H
#define STRUCT_H

#include <SFML/Graphics.hpp>

struct TextProp
{
	float Size;
	sf::Color Color;
	std::string Font;
	std::string Text;
	TextProp( const sf::Color& pColor, float pSize, const std::string& pFont, const std::string& pText = "" )
		: Color( pColor ), Font( pFont ), Size( pSize ), Text( pText )
	{
	}
};

enum lool
{
	yes,
	no,
	maybe
};

#endif