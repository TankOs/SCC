#include "Stein_Break.h"

extern double ankathete(double pWinkel, double pHypotenuse);
extern double square(const double x);

Stein_Break::Stein_Break(const sf::Vector2f& pPosition, const std::string& pBildpfad)
: Stein(pPosition, pBildpfad)
{
}

void Stein_Break::hit(Ball& pBall)
{
	if((this->isAbove(pBall) && !this->isLeft(pBall) && !this->isRight(pBall))
		|| (this->isUnder(pBall) && !this->isLeft(pBall) && !this->isRight(pBall)))
	{
		pBall.invertTempo_Y();
	}
	else if((this->isLeft(pBall) && !this->isAbove(pBall) && !this->isUnder(pBall))
		|| (this->isRight(pBall) && !this->isAbove(pBall) && !this->isUnder(pBall)))
	{
		pBall.invertTempo_X();
	}
	else if(this->isLeft(pBall))
	{
		int lResultierende = sqrt(square(pBall.getTempo().x) + square(pBall.getTempo().y));
		double Tempo = -ankathete(45, lResultierende);
		if(this->isAbove(pBall))
		{
			pBall.setTempo(sf::Vector2f(Tempo, Tempo));
		}
		else if(this->isUnder(pBall))
		{
			pBall.setTempo(sf::Vector2f(Tempo, -Tempo));
		}
	}
	else if(this->isRight(pBall))
	{
		int lResultierende = sqrt(square(pBall.getTempo().x) + square(pBall.getTempo().y));
		double Tempo = ankathete(45, lResultierende);
		if(this->isAbove(pBall))
		{
			pBall.setTempo(sf::Vector2f(Tempo, -Tempo));
		}
		else if(this->isUnder(pBall))
		{
			pBall.setTempo(sf::Vector2f(Tempo, Tempo));
		}
	}
	Destroyed = true;
}