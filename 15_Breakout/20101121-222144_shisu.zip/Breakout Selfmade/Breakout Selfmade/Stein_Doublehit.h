#ifndef STEIN_DOUBLEHIT_H
#define STEIN_DOUBLEHIT_H

/* Bibliotheken-Includes */

/* Eigene Header-Includes */
#include "Stein.h"
#include "Ball.h"

/* Stein_Doublehit
 * Der Stein_Break befindet sich auf dem Spielfeld und existiert dort, bis er vom Ball doppelt getroffen und zerst�rt wird. */
class Stein_Doublehit : public Stein
{
private:
	int Hits;
	sf::Sprite Damaged_Sprite;
protected:
	void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const;
public:
	Stein_Doublehit(const sf::Vector2f& pPosition, const std::string& pBildpfad, const std::string& pBildpfadDamage);
	void hit(Ball& pBall);
};

#endif