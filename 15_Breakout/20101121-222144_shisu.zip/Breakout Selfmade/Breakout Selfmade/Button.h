#ifndef BUTTON_H
#define BUTTON_H

/* Bibliotheken-Includes */
#include <SFML/Graphics.hpp>

/* Eigene Header-Includes */
#include "Structs.h"

/* Button
 * Ein Button stellt einen Knopf dar, der gedr�ckt werden kann, worauf daraufhin von Seiten des Programms reagiert wird. */
class Button : public sf::Drawable
{
private:
	void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const;

	sf::Sprite *NormalSP, *PressedSP;
	sf::Shape *NormalSH, *PressedSH;
	bool Pressed;
	sf::Vector2f Size;
	sf::Text Text;
public:
	Button( const sf::Color& pFarbeNormal, const sf::Color& pFarbePressed, const sf::Vector2f& pSize, const TextProp& pText,
		const sf::Vector2f& pPosition = sf::Vector2f( 0, 0 ) );
	Button( const std::string& pPfadNormal, const std::string& pPfadPressed, const TextProp& pText,
		const sf::Vector2f& pPosition = sf::Vector2f( 0, 0 ), const sf::Vector2f& pOffset = sf::Vector2f( 0, 0 ) );
	Button(const Button& b);
	~Button();

	void SetTextOffset( const sf::Vector2f& pOffset );
	bool Getroffen( const sf::Vector2f& pPosition );
	void SetPressed( bool pPressed );

	bool IsPressed() const;
};

#endif