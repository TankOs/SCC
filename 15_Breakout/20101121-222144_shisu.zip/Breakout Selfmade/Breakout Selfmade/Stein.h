#ifndef STEIN_H
#define STEIN_H

/* Bibliotheken-Includes */
#include <iostream>
#include <fstream>
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <sstream>

/* Eigene Header-Includes */
#include "Ball.h"

/* Stein
 * Der Stein befindet sich auf dem Spielfeld und existiert dort, bis er zerst�rt wird. (In welcher Weise auch immer) */
class Stein : public sf::Drawable
{
private:
	sf::Vector2f Position_OL, Size;
protected:
	void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const;
	bool isLeft(const Ball& pBall) const;
	bool isRight(const Ball& pBall) const;
	bool isAbove(const Ball& pBall) const;
	bool isUnder(const Ball& pBall) const;
	sf::Sprite Bild_Sprite;
	bool Destroyed;
public:
	Stein(const sf::Vector2f& pPosition, const std::string& pBildpfad);
	Stein(const sf::Vector2f& pPosition, const sf::Vector2f& pSize, const std::string& pBildpfad);
	sf::Vector2f getPosition_OL() const;
	sf::Vector2f getPosition_Center() const;
	sf::Vector2f getSize() const;
	virtual void hit(Ball& pBall) = 0;
	bool getDestroyed() const;
};

#endif