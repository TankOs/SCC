/* Bibliotheken-Includes */
#include <iostream>
#include <fstream>
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <sstream>
#include <math.h>

/* Eigene Header-Includes */
#include "ImageManager.h"
#include "FontManager.h"
#include "Ball.h"
#include "Paddle.h"
#include "Stein.h"
#include "Stein_Break.h"
#include "Stein_Block.h"
#include "Stein_Doublehit.h"
#include "Button.h"
#include "Structs.h"

/* Breakout
 * Dieses Spiel stellt einen Breakout-Klon dar. */

ImageManager ImgMng;
FontManager FntMng;

const int Pkt_Break = 450, Pkt_Double = 750, Pkt_Ballout = -800, Pkt_Levelfinish = 2500;

int gScore;
sf::Text gScore_Text;

void Intro( sf::RenderWindow& pApp, std::vector<Stein_Break>& pSteine, std::vector<Stein_Block>& pBlocks,
		   std::vector<Stein_Doublehit> pDoublehits, std::vector<Paddle>& pPaddles,
		   sf::Sprite& pBG, sf::Sprite pLV, sf::Sprite pST, Ball& pTheBall );
void erstelleSteinreihe(std::vector<Stein_Break>& pSteine, const sf::Vector2f& pBeginn, const sf::Vector2f& pAbschnitte, int pAnzahl);
void erstelleSteinreihe( std::vector<Stein_Block>& pSteine, const sf::Vector2f& pBeginn, const sf::Vector2f& pAbschnitte, int pAnzahl );
void erstelleSteinreihe( std::vector<Stein_Doublehit>& pDoublehits, const sf::Vector2f& pBeginn, const sf::Vector2f& pAbschnitte, int pAnzahl );
void Spielroutine( sf::RenderWindow& pApp, std::vector<Paddle>& pPaddles, const sf::Vector2f& Ball_Normtempo,
				   const sf::Vector2f& Ball_Normposition, Ball& pTheBall, std::vector<Stein_Break>& pSteine,
				   std::vector<Stein_Block>& pBlocks, std::vector<Stein_Doublehit> pDoublehits, sf::Sprite& pBG, sf::Sprite& pLV,
				   sf::Sprite& pST, bool (*pOutside) (Ball&) );
bool Outside_Stg1( Ball& pTheBall );
bool Outside_Stg2( Ball& pTheBall );
bool Outside_Stg3( Ball& pTheBall );
bool Outside_Stg4( Ball& pTheBall );

bool kollision_Ball_Paddle(const Ball& pBall, const Paddle& pPaddle);
void abprall_Ball_Paddle(Ball& pBall, const Paddle& pPaddle);
bool kollision_Ball_Stein(const Ball& pBall, const Stein& pStein);
double square(double x);
double inBogenmass(double pWinkel);
double inGradmass(double pWinkel);
double ankathete(double pWinkel, double pHypotenuse);
double gegenkathete(double pWinkel, double pHypotenuse);
void UpdScore(int Points)
{
	gScore+=Points;
	std::ostringstream Temp;
	Temp<<gScore;
	gScore_Text.SetString("Score: "+Temp.str());
}

int main()
{
	sf::RenderWindow App(sf::VideoMode( 1024, 768, 32 ), "Breakout by Shisu", sf::Style::Close);
	gScore = 0;
	gScore_Text.SetPosition(sf::Vector2f(820, 0)); gScore_Text.SetColor(sf::Color(0, 0, 0));
	sf::Sprite BG(*ImgMng.getResource("Pictures/Background.png"));
	sf::Sprite BG2(*ImgMng.getResource("Pictures/Background_Stage2.png"));
	sf::Sprite BG3(*ImgMng.getResource("Pictures/Background_Stage3.png"));
	sf::Sprite BG4(*ImgMng.getResource("Pictures/Background_Stage4.png"));
	sf::Sprite Msg_Win(*ImgMng.getResource("Pictures/Message_Done.png"), sf::Vector2f(314, 355));
	sf::Sprite Msg_Loose(*ImgMng.getResource("Pictures/Message_Lost.png"), sf::Vector2f(363, 335));
	UpdScore(0);
	bool Start = false;
	Button Button_Start( "Pictures/Button.png", "Pictures/Button_pr.png", TextProp(sf::Color(200, 60, 80), 36, "Fonts/ParmaPetit.ttf", "Spiel starten"), sf::Vector2f(412, 354), sf::Vector2f(18, 5));

	while(App.IsOpened() && !Start)
	{	//"Men�"
		sf::Event Ev;
		while(App.GetEvent(Ev))
		{
			if(Ev.Type == sf::Event::Closed)
				App.Close();
			else if(Ev.Type == sf::Event::MouseButtonPressed)
			{
				Button_Start.Getroffen( sf::Vector2f( App.GetInput().GetMouseX(), App.GetInput().GetMouseY() ) );
			}
			else if(Ev.Type == sf::Event::MouseButtonReleased)
			{
				if( Button_Start.IsPressed() )
				{
					Button_Start.SetPressed( false );
					Start = true;
				}
			}
		}
		App.Clear();
		App.Draw(BG);
		App.Draw(gScore_Text);
		App.Draw(Button_Start);
		App.Display();
	}

/** Definition des Paddlevectors und der Vectoren f�r die Steine sowie des Balls */
	std::vector<Paddle> Paddles;
	std::vector<Stein_Break> Steine;
	std::vector<Stein_Block> Blocks;
	std::vector<Stein_Doublehit> Doublehits;
	Ball TheBall(sf::Vector2f(500, 480), 7.5);
/** \\Definition des Paddlevectors und der Vectoren f�r die Steine */

	/** Konfiguration der Paddles f�r Stage 1 */
	Paddles.push_back(Paddle(sf::Vector2f(440, 107), 0, false, sf::Vector2f(202, 822)));
	Paddles.push_back(Paddle(sf::Vector2f(107, 302), 270, false, sf::Vector2f(202, 566)));
	Paddles.push_back(Paddle(sf::Vector2f(440, 631), 180, false, sf::Vector2f(202, 822)));
	Paddles.push_back(Paddle(sf::Vector2f(887, 302), 90, false, sf::Vector2f(202, 566)));
	/** \\Konfiguration der Paddles f�r Stage 1 */

/** LEVEL 1.1 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 1.1 */
	TheBall.setTempo(sf::Vector2f(0, 250));
	/** Konfigurieren des Balls f�r LV 1 */

	/** Setzen der Steine f�r LV 1 1.*/
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Steine, sf::Vector2f(227, 320), sf::Vector2f(54, 0), 10);
	erstelleSteinreihe(Steine, sf::Vector2f(227, 380), sf::Vector2f(54, 0), 10);
	/** \\Setzen der Steine f�r LV 1.1 */

	/** Spielablauf des LV 1.1 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST1.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV1.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(0, 250), sf::Vector2f(500, 480), TheBall, Steine, Blocks, Doublehits, BG, LV, ST, Outside_Stg1);
	}
	/** \\Spielablauf des LV 1.1 */
	} while(gScore < 0 && App.IsOpened());
	sf::Clock Uhr;
	sf::Event Event;
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 1.1 */

/** LEVEL 1.2 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 1.2 */
	TheBall.moveTo(sf::Vector2f(520, 480));
	TheBall.setTempo(sf::Vector2f(0, 290));
	/** Konfigurieren des Balls f�r LV 1.2 */

	/** Setzen der Steine f�r LV 1.2 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Steine, sf::Vector2f(210, 250), sf::Vector2f(54, 19), 11);
	erstelleSteinreihe(Steine, sf::Vector2f(210, 459), sf::Vector2f(54, -19), 11);
	/** \\Setzen der Steine f�r LV 1.2 */

	/** Spielablauf des LV 1.2 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST1.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV2.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(0, 290), sf::Vector2f(520, 480), TheBall, Steine, Blocks, Doublehits, BG, LV, ST, Outside_Stg1);
	}
	/** \\Spielablauf des LV 1.2 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 1.2 */

/** LEVEL 1.3 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 1.3 */
	TheBall.moveTo(sf::Vector2f(520, 280));
	TheBall.setTempo(sf::Vector2f(0, -300));
	/** Konfigurieren des Balls f�r LV 1.3 */

	/** Setzen der Steine f�r LV 1.3 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Steine, sf::Vector2f(210, 200), sf::Vector2f(54, 19), 11);
	erstelleSteinreihe(Steine, sf::Vector2f(210, 409), sf::Vector2f(54, -19), 11);
	
	erstelleSteinreihe(Steine, sf::Vector2f(210, 314), sf::Vector2f(54, 19), 11);
	erstelleSteinreihe(Steine, sf::Vector2f(210, 523), sf::Vector2f(54, -19), 11);

	erstelleSteinreihe(Doublehits, sf::Vector2f(426, 352), sf::Vector2f(54, 0), 4);
	erstelleSteinreihe(Doublehits, sf::Vector2f(426, 371), sf::Vector2f(54, 0), 4);
	/** \\Setzen der Steine f�r LV 1.3 */

	/** Spielablauf des LV 1.3 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST1.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV3.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(0, -300), sf::Vector2f(520, 280), TheBall, Steine, Blocks, Doublehits, BG, LV, ST, Outside_Stg1);
	}
	/** \\Spielablauf des LV 1.3 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 1.3 */

/** LEVEL 1.4 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 1.4 */
	TheBall.moveTo(sf::Vector2f(520, 370));
	TheBall.setTempo(sf::Vector2f(300, 0));
	/** Konfigurieren des Balls f�r LV 1.4 */

	/** Setzen der Steine f�r LV 1.4 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	for(int j = 0;j < 2; ++j)
	{
		for(int i = 0;i < 2;++i)
		{
			erstelleSteinreihe(Steine, sf::Vector2f(186+365*i, 200+300*j), sf::Vector2f(0, 19), 5);
			erstelleSteinreihe(Steine, sf::Vector2f(402+365*i, 200+300*j), sf::Vector2f(0, 19), 5);
			erstelleSteinreihe(Steine, sf::Vector2f(240+365*i, 200+300*j), sf::Vector2f(54, 0), 3);
			erstelleSteinreihe(Steine, sf::Vector2f(240+365*i, 276+300*j), sf::Vector2f(54, 0), 3);
			Blocks.push_back( Stein_Block( sf::Vector2f(240+365*i , 219+300*j) , "Pictures/Stein_Block.png" ) );
			Blocks.push_back( Stein_Block( sf::Vector2f(348+365*i , 219+300*j) , "Pictures/Stein_Block.png" ) );
			Blocks.push_back( Stein_Block( sf::Vector2f(240+365*i , 257+300*j) , "Pictures/Stein_Block.png" ) );
			Blocks.push_back( Stein_Block( sf::Vector2f(348+365*i , 257+300*j) , "Pictures/Stein_Block.png" ) );
			erstelleSteinreihe(Doublehits, sf::Vector2f(294+365*i, 219+300*j), sf::Vector2f(0, 19), 3);
			Doublehits.push_back( Stein_Doublehit( sf::Vector2f(240+365*i , 238+300*j) , "Pictures/Stein_Doublehit_D0.png",
				"Pictures/Stein_Doublehit_D1.png" ) );
			Doublehits.push_back( Stein_Doublehit( sf::Vector2f(348+365*i , 238+300*j) , "Pictures/Stein_Doublehit_D0.png",
				"Pictures/Stein_Doublehit_D1.png" ) );
		}
	}
	/** \\Setzen der Steine f�r LV 1.4 */

	/** Spielablauf des LV 1.4 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST1.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV4.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(300, 0), sf::Vector2f(520, 370), TheBall, Steine, Blocks, Doublehits, BG, LV, ST, Outside_Stg1);
	}
	/** \\Spielablauf des LV 1.4 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 1.4 */

	/** Konfiguration der Paddles f�r Stage 2 */
	while(!Paddles.empty())
		Paddles.pop_back();
	Paddles.push_back(Paddle(sf::Vector2f(440, 99), 0, false, sf::Vector2f(201, 578)));
	Paddles.push_back(Paddle(sf::Vector2f(106, 302), 270, false, sf::Vector2f(194, 396)));
	Paddles.push_back(Paddle(sf::Vector2f(440, 638), 180, false, sf::Vector2f(474, 820)));
	Paddles.push_back(Paddle(sf::Vector2f(885, 302), 90, false, sf::Vector2f(402, 573)));
	/** \\Konfiguration der Paddles f�r Stage 2 */

	/** Konfiguration der Blocks f�r Stage 2 */
	Blocks.push_back(Stein_Block(sf::Vector2f(650, 80), sf::Vector2f(300, 250), "Pictures/Empty.png"));
	Blocks.push_back(Stein_Block(sf::Vector2f(52, 468), sf::Vector2f(350, 230), "Pictures/Empty.png"));
	/** \\Konfiguration der Blocks f�r Stage 2 */

/** LEVEL 1 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG2); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 1 */
	TheBall.moveTo(sf::Vector2f(520, 370));
	TheBall.setTempo(sf::Vector2f(300, 0));
	/** Konfigurieren des Balls f�r LV 1 */

	/** Setzen der Steine f�r LV 1 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Steine, sf::Vector2f(300, 270), sf::Vector2f(54, 19), 9);
	erstelleSteinreihe(Steine, sf::Vector2f(246, 289), sf::Vector2f(54, 19), 9);
	/** \\Setzen der Steine f�r LV 1 */

	/** Spielablauf des LV 1 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST2.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV1.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG2, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(300, 0), sf::Vector2f(520, 370), TheBall, Steine, Blocks, Doublehits, BG2, LV, ST, Outside_Stg2);
	}
	/** \\Spielablauf des LV 1 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG2); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 1 */
	
/** LEVEL 2.2 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG2); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 2.2 */
	TheBall.moveTo(sf::Vector2f(520, 240));
	TheBall.setTempo(sf::Vector2f(300, -60));
	/** Konfigurieren des Balls f�r LV 2.2 */

	/** Setzen der Steine f�r LV 2.2 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Steine, sf::Vector2f(300, 270), sf::Vector2f(54, 19), 9);
	erstelleSteinreihe(Steine, sf::Vector2f(246, 289), sf::Vector2f(54, 19), 9);
	erstelleSteinreihe(Doublehits, sf::Vector2f(192, 327), sf::Vector2f(54, -19), 5);
	erstelleSteinreihe(Doublehits, sf::Vector2f(570, 460), sf::Vector2f(54, -19), 5);
	/** \\Setzen der Steine f�r LV 2.2 */

	/** Spielablauf des LV 2.2 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST2.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV2.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG2, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(300, -60), sf::Vector2f(520, 240), TheBall, Steine, Blocks, Doublehits, BG2, LV, ST, Outside_Stg2);
	}
	/** \\Spielablauf des LV 2.2 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG2); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 2.2 */

/** LEVEL 2.3 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG2); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 2.3 */
	TheBall.moveTo(sf::Vector2f(520, 240));
	TheBall.setTempo(sf::Vector2f(300, -60));
	/** Konfigurieren des Balls f�r LV 2.3 */

	/** Setzen der Steine f�r LV 2.3 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Blocks, sf::Vector2f(300, 230), sf::Vector2f(0, 19), 5);
	erstelleSteinreihe(Blocks, sf::Vector2f(300+54, 230), sf::Vector2f(0, 19*4), 2);
	erstelleSteinreihe(Steine, sf::Vector2f(300+54, 230+19), sf::Vector2f(0, 19), 3);
	erstelleSteinreihe(Blocks, sf::Vector2f(300+108, 230), sf::Vector2f(0, 19*4), 2);
	erstelleSteinreihe(Doublehits, sf::Vector2f(300+108, 230+19), sf::Vector2f(0, 19), 3);
	erstelleSteinreihe(Blocks, sf::Vector2f(555, 440), sf::Vector2f(0, 19*4), 2);
	erstelleSteinreihe(Doublehits, sf::Vector2f(555, 440+19), sf::Vector2f(0, 19), 3);
	erstelleSteinreihe(Blocks, sf::Vector2f(555+54, 440), sf::Vector2f(0, 19*4), 2);
	erstelleSteinreihe(Steine, sf::Vector2f(555+54, 440+19), sf::Vector2f(0, 19), 3);
	erstelleSteinreihe(Blocks, sf::Vector2f(555+108, 440), sf::Vector2f(0, 19), 5);
	/** \\Setzen der Steine f�r LV 2.3 */

	/** Spielablauf des LV 2.3 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST2.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV3.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG2, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(300, -60), sf::Vector2f(520, 240), TheBall, Steine, Blocks, Doublehits, BG2, LV, ST, Outside_Stg2);
	}
	/** \\Spielablauf des LV 2.3 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG2); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 2.3 */

/** LEVEL 2.4 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG2); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 2.4 */
	TheBall.moveTo(sf::Vector2f(380, 350));
	TheBall.setTempo(sf::Vector2f(0, -360));
	/** Konfigurieren des Balls f�r LV 2.4 */

	/** Setzen der Steine f�r LV 2.4 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Doublehits, sf::Vector2f(400, 290), sf::Vector2f(0, 22), 8);
	erstelleSteinreihe(Doublehits, sf::Vector2f(460, 300), sf::Vector2f(0, 22), 9);
	erstelleSteinreihe(Doublehits, sf::Vector2f(520, 290), sf::Vector2f(0, 22), 9);
	erstelleSteinreihe(Doublehits, sf::Vector2f(580, 300), sf::Vector2f(0, 22), 8);
	Steine.push_back(Stein_Break(sf::Vector2f(700, 450), "Pictures/Stein.png"));
	/** \\Setzen der Steine f�r LV 2.4 */

	/** Spielablauf des LV 2.4 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST2.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV4.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG2, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(0, -360), sf::Vector2f(380, 350), TheBall, Steine, Blocks, Doublehits, BG2, LV, ST, Outside_Stg2);
	}
	/** \\Spielablauf des LV 2.4 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG2); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 2.4 */

	/** Konfiguration der Paddles f�r Stage 3 */
	while(!Paddles.empty())
		Paddles.pop_back();
	Paddles.push_back(Paddle(sf::Vector2f(398, 302), 270, true, sf::Vector2f(150, 392)));
	Paddles.push_back(Paddle(sf::Vector2f(440, 649), 180, false, sf::Vector2f(232, 822)));
	Paddles.push_back(Paddle(sf::Vector2f(608, 305), 90, true, sf::Vector2f(150, 392)));
	/** \\Konfiguration der Paddles f�r Stage 3 */

	/** Konfiguration der Blocks f�r Stage 3 */
	while(!Blocks.empty())
		Blocks.pop_back();
	Blocks.push_back(Stein_Block(sf::Vector2f(6, 408), sf::Vector2f(400, 20), "Pictures/Empty.png"));
	Blocks.push_back(Stein_Block(sf::Vector2f(615, 408), sf::Vector2f(400, 20), "Pictures/Empty.png"));
	Blocks.push_back(Stein_Block(sf::Vector2f(140, 400), sf::Vector2f(20, 400), "Pictures/Empty.png"));
	Blocks.push_back(Stein_Block(sf::Vector2f(894, 400), sf::Vector2f(20, 400), "Pictures/Empty.png"));
	Blocks.push_back(Stein_Block(sf::Vector2f(300, 94), sf::Vector2f(400, 20), "Pictures/Empty.png"));
	/** \\Konfiguration der Blocks f�r Stage 3 */

/** LEVEL 3.1 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG3); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 3.1 */
	TheBall.moveTo(sf::Vector2f(550, 400));
	TheBall.setTempo(sf::Vector2f(0, 280));
	/** Konfigurieren des Balls f�r LV 3.1 */

	/** Setzen der Steine f�r LV 3.1 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Steine, sf::Vector2f(162, 430), sf::Vector2f(54, 1), 7);
	erstelleSteinreihe(Steine, sf::Vector2f(839, 440), sf::Vector2f(-54, 3), 13);
	/** \\Setzen der Steine f�r LV 3.1 */

	/** Spielablauf des LV 3.1 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST3.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV1.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG3, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(sf::Vector2f(0, 280)), sf::Vector2f(550, 400), TheBall, Steine, Blocks, Doublehits, BG3, LV, ST, Outside_Stg3);
	}
	/** \\Spielablauf des LV 3.1 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG3); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 3.1 */

/** LEVEL 3.2 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG3); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 3.2 */
	TheBall.moveTo(sf::Vector2f(700, 580));
	TheBall.setTempo(sf::Vector2f(0, -310));
	/** Konfigurieren des Balls f�r LV 3.2 */

	/** Setzen der Steine f�r LV 3.2 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Steine, sf::Vector2f(162, 430), sf::Vector2f(54, 1), 7);
	erstelleSteinreihe(Steine, sf::Vector2f(839, 440), sf::Vector2f(-54, 3), 13);
	erstelleSteinreihe(Blocks, sf::Vector2f(162, 500), sf::Vector2f(54, 3), 13);
	/** \\Setzen der Steine f�r LV 3.2 */

	/** Spielablauf des LV 3.2 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST3.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV2.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG3, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(sf::Vector2f(0, -310)), sf::Vector2f(700, 580), TheBall, Steine, Blocks, Doublehits, BG3, LV, ST, Outside_Stg3);
	}
	/** \\Spielablauf des LV 3.2 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG3); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 3.2 */

/** LEVEL 3.3 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG3); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 3.3 */
	TheBall.moveTo(sf::Vector2f(700, 580));
	TheBall.setTempo(sf::Vector2f(0, -310));
	/** Konfigurieren des Balls f�r LV 3.3 */

	/** Setzen der Steine f�r LV 3.3 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Steine, sf::Vector2f(490, 200), sf::Vector2f(0, 19), 6);
	erstelleSteinreihe(Doublehits, sf::Vector2f(162, 430), sf::Vector2f(54, 1), 7);
	erstelleSteinreihe(Doublehits, sf::Vector2f(839, 440), sf::Vector2f(-54, 3), 13);
	erstelleSteinreihe(Blocks, sf::Vector2f(162, 500), sf::Vector2f(54, 3), 13);
	/** \\Setzen der Steine f�r LV 3.3 */

	/** Spielablauf des LV 3.3 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST3.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV3.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG3, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(sf::Vector2f(0, -310)), sf::Vector2f(700, 580), TheBall, Steine, Blocks, Doublehits, BG3, LV, ST, Outside_Stg3);
	}
	/** \\Spielablauf des LV 3.3 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG3); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 3.3 */

	/** Konfiguration der Paddles f�r Stage 4 */
	while(!Paddles.empty())
		Paddles.pop_back();
	Paddles.push_back(Paddle(sf::Vector2f(450, 107), 0, false, sf::Vector2f(218, 483)));
	Paddles.push_back(Paddle(sf::Vector2f(123, 302), 270, false, sf::Vector2f(202, 524)));
	Paddles.push_back(Paddle(sf::Vector2f(440, 589), 180, false, sf::Vector2f(218, 423)));
	Paddles.push_back(Paddle(sf::Vector2f(440, 633), 180, true, sf::Vector2f(642, 849)));
	Paddles.push_back(Paddle(sf::Vector2f(878, 302), 90, false, sf::Vector2f(315, 568)));
	/** \\Konfiguration der Paddles f�r Stage 4 */

	/** Konfiguration der Blocks f�r Stage 4 */
	while(!Blocks.empty())
		Blocks.pop_back();
	Blocks.push_back(Stein_Block(sf::Vector2f(495, 348), sf::Vector2f(111, 299), "Pictures/Empty.png"));
	Blocks.push_back(Stein_Block(sf::Vector2f(555, 132), sf::Vector2f(400, 111), "Pictures/Empty.png"));
	/** \\Konfiguration der Blocks f�r Stage 4 */

/** LEVEL 4.1 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG4); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 4.1 */
	TheBall.moveTo(sf::Vector2f(700, 580));
	TheBall.setTempo(sf::Vector2f(0, -310));
	/** Konfigurieren des Balls f�r LV 4.1 */

	/** Setzen der Steine f�r LV 4.1 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Steine, sf::Vector2f(485, 240), sf::Vector2f(0, 19), 5);
	erstelleSteinreihe(Doublehits, sf::Vector2f(540, 250), sf::Vector2f(0, 19), 5);
	erstelleSteinreihe(Steine, sf::Vector2f(595, 248), sf::Vector2f(0, 19), 5);
	erstelleSteinreihe(Blocks, sf::Vector2f(180, 360), sf::Vector2f(50, -22), 6);
	erstelleSteinreihe(Doublehits, sf::Vector2f(200, 200), sf::Vector2f(54, 19), 3);
	erstelleSteinreihe(Steine, sf::Vector2f(431, 300), sf::Vector2f(0, 19), 8);
	/** \\Setzen der Steine f�r LV 4.1 */

	/** Spielablauf des LV 4.1 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST4.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV1.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG4, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(sf::Vector2f(0, -310)), sf::Vector2f(700, 580), TheBall, Steine, Blocks, Doublehits, BG4, LV, ST, Outside_Stg4);
	}
	/** \\Spielablauf des LV 4.1 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG4); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 4.1 */

/** LEVEL 4.2 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG4); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 4.2 */
	TheBall.moveTo(sf::Vector2f(700, 580));
	TheBall.setTempo(sf::Vector2f(0, -310));
	/** Konfigurieren des Balls f�r LV 4.2 */

	/** Setzen der Steine f�r LV 4.2 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Doublehits, sf::Vector2f(485, 240), sf::Vector2f(0, 19), 5);
	erstelleSteinreihe(Doublehits, sf::Vector2f(540, 250), sf::Vector2f(0, 19), 5);
	erstelleSteinreihe(Doublehits, sf::Vector2f(595, 248), sf::Vector2f(0, 19), 5);
	erstelleSteinreihe(Doublehits, sf::Vector2f(180, 360), sf::Vector2f(50, -22), 6);
	erstelleSteinreihe(Doublehits, sf::Vector2f(200, 200), sf::Vector2f(54, 19), 3);
	erstelleSteinreihe(Doublehits, sf::Vector2f(431, 300), sf::Vector2f(0, 19), 8);
	erstelleSteinreihe(Doublehits, sf::Vector2f(377, 300), sf::Vector2f(0, 19), 8);
	/** \\Setzen der Steine f�r LV 4.2 */

	/** Spielablauf des LV 4.2 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST4.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV2.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG4, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(sf::Vector2f(0, -310)), sf::Vector2f(700, 580), TheBall, Steine, Blocks, Doublehits, BG4, LV, ST, Outside_Stg4);
	}
	/** \\Spielablauf des LV 4.2 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG4); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 4.2 */

/** LEVEL 4.3 */
	do
	{
	if(gScore < 0)
	{
		gScore = 0;
		UpdScore(0);
		sf::Clock Uhr;
		sf::Event Event;
		while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
		{
			while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
			App.Clear(); App.Draw(BG4); App.Draw(Msg_Loose); App.Display();
		}
	}
	/** Konfigurieren des Balls f�r LV 4.3 */
	TheBall.moveTo(sf::Vector2f(700, 580));
	TheBall.setTempo(sf::Vector2f(0, -500));
	/** Konfigurieren des Balls f�r LV 4.3 */

	/** Setzen der Steine f�r LV 4.3 */
	while(!Steine.empty())
		Steine.pop_back();
	while(!Doublehits.empty())
		Doublehits.pop_back();
	while(!Blocks.empty())
		Blocks.pop_back();
	erstelleSteinreihe(Doublehits, sf::Vector2f(485, 240), sf::Vector2f(0, 19), 5);
	erstelleSteinreihe(Doublehits, sf::Vector2f(540, 250), sf::Vector2f(0, 19), 5);
	erstelleSteinreihe(Doublehits, sf::Vector2f(595, 248), sf::Vector2f(0, 19), 5);
	erstelleSteinreihe(Doublehits, sf::Vector2f(649, 248), sf::Vector2f(0, 19), 7);
	erstelleSteinreihe(Doublehits, sf::Vector2f(180, 360), sf::Vector2f(50, -22), 6);
	erstelleSteinreihe(Doublehits, sf::Vector2f(200, 200), sf::Vector2f(54, 19), 3);
	erstelleSteinreihe(Doublehits, sf::Vector2f(431, 300), sf::Vector2f(0, 19), 8);
	erstelleSteinreihe(Doublehits, sf::Vector2f(377, 300), sf::Vector2f(0, 19), 8);
	/** \\Setzen der Steine f�r LV 4.3 */

	/** Spielablauf des LV 4.3 */
	{
		sf::Sprite ST(*ImgMng.getResource("Pictures/Message_ST4.png"), sf::Vector2f(10, 10));
		sf::Sprite LV(*ImgMng.getResource("Pictures/Message_LV3.png"), sf::Vector2f(30, 40));
		Intro(App, Steine, Blocks, Doublehits, Paddles, BG4, LV, ST, TheBall);
		Spielroutine(App, Paddles, sf::Vector2f(sf::Vector2f(0, -500)), sf::Vector2f(700, 580), TheBall, Steine, Blocks, Doublehits, BG4, LV, ST, Outside_Stg4);
	}
	/** \\Spielablauf des LV 4.3 */
	} while(gScore < 0 && App.IsOpened());
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 1.5 && App.IsOpened())
	{
		while(App.GetEvent(Event)) { if(Event.Type == sf::Event::Closed) { App.Close(); } }
		App.Clear(); App.Draw(BG4); App.Draw(Msg_Win); App.Display();
	}
/** \\LEVEL 4.3 */

	sf::Sprite End(*ImgMng.getResource("Pictures/Message_End.png"), sf::Vector2f(322, 100));
	Uhr.Reset();
	while(Uhr.GetElapsedTime() < 10 && App.IsOpened())
	{
		sf::Event Ev;
		while(App.GetEvent(Ev))
		{
			if(Ev.Type == sf::Event::Closed) App.Close();
		}
		App.Clear();
		App.Draw(BG2);
		App.Draw(End);
		App.Display();
	}

	return 0;
}


bool Outside_Stg1( Ball& pTheBall )
{
	return pTheBall.getPosition_Center().y < 137 + pTheBall.getRadius() - 0.5
		|| pTheBall.getPosition_Center().y > 631 - pTheBall.getRadius() + 0.5
		|| pTheBall.getPosition_Center().x < 137 + pTheBall.getRadius() - 0.5
		|| pTheBall.getPosition_Center().x > 887 - pTheBall.getRadius() + 0.5;
}

bool Outside_Stg2( Ball& pTheBall )
{
	return pTheBall.getPosition_Center().y < 129 + pTheBall.getRadius() - 0.5
		|| pTheBall.getPosition_Center().y > 638 - pTheBall.getRadius() + 0.5
		|| pTheBall.getPosition_Center().x < 136 + pTheBall.getRadius() - 0.5
		|| pTheBall.getPosition_Center().x > 885 - pTheBall.getRadius() + 0.5;
}

bool Outside_Stg3( Ball& pTheBall )
{
	return pTheBall.getPosition_Center().y < 114 + pTheBall.getRadius() - 0.5
		|| pTheBall.getPosition_Center().y > 649 - pTheBall.getRadius() + 0.5
		|| pTheBall.getPosition_Center().x < 160 + pTheBall.getRadius() - 0.5
		|| pTheBall.getPosition_Center().x > 896 - pTheBall.getRadius() + 0.5
		|| (pTheBall.getPosition_Center().y < 435 - pTheBall.getRadius() - 0.5
		&& pTheBall.getPosition_Center().x < 412 + pTheBall.getRadius() - 0.5)
		|| (pTheBall.getPosition_Center().y < 435 - pTheBall.getRadius() - 0.5
		&& pTheBall.getPosition_Center().x > 608 - pTheBall.getRadius() + 0.5);
}

bool Outside_Stg4( Ball& pTheBall )
{
	if(pTheBall.getPosition_Center().x < 554)
	{
		return pTheBall.getPosition_Center().y < 135 + pTheBall.getRadius() - 0.5
		|| pTheBall.getPosition_Center().y > 590 - pTheBall.getRadius() + 0.5
		|| pTheBall.getPosition_Center().x < 151 + pTheBall.getRadius() - 0.5;
	}
	else
	{
		return pTheBall.getPosition_Center().y < 135 + pTheBall.getRadius() - 0.5
		|| pTheBall.getPosition_Center().y > 634 - pTheBall.getRadius() + 0.5
		|| pTheBall.getPosition_Center().x > 879 - pTheBall.getRadius() + 0.5;
	}
}

void Spielroutine( sf::RenderWindow& pApp, std::vector<Paddle>& pPaddles, const sf::Vector2f& Ball_Normtempo,
				   const sf::Vector2f& Ball_Normposition, Ball& pTheBall, std::vector<Stein_Break>& pSteine,
				   std::vector<Stein_Block>& pBlocks, std::vector<Stein_Doublehit> pDoublehits, sf::Sprite& pBG, sf::Sprite& pLV,
				   sf::Sprite& pST, bool (*pOutside) (Ball&) )
{
	bool LevelDone = false, BallOut = false;
	while( pApp.IsOpened() && !LevelDone)
	{
		BallOut = false;
		sf::Event Event;
		while( pApp.IsOpened() && !BallOut && !LevelDone )
		{
			while( pApp.GetEvent(Event) )
			{
				switch( Event.Type )
				{
				case sf::Event::Closed:
					pApp.Close();
					break;
				case sf::Event::MouseMoved:
					for( std::vector<Paddle>::iterator i = pPaddles.begin(); i != pPaddles.end(); ++i )
					{
						if( i->getDrehung() == 0 || i->getDrehung() == 180 )
						{
							i->moveCenterToX( pApp.GetInput().GetMouseX() );
						}
						else
						{
							i->moveCenterToY( pApp.GetInput().GetMouseY() );
						}
					}
					break;
				}
			}
			for( std::vector<Stein_Break>::iterator i = pSteine.begin(); i != pSteine.end(); ++i )
			{
				if( i->getDestroyed() == false )
				{
					if( kollision_Ball_Stein( pTheBall, *i ) )
					{
						pTheBall.invertTempo_Full();
						while( kollision_Ball_Stein( pTheBall, *i ) )
						{
							pTheBall.pixelMove();
						}
						pTheBall.invertTempo_Full();
						i->hit(pTheBall);
					}
				}
				else
				{
					pSteine.erase(i);
					UpdScore(Pkt_Break);
					break;
				}
			}
			for( std::vector<Stein_Block>::iterator i = pBlocks.begin(); i != pBlocks.end(); ++i )
			{
				if( i->getDestroyed() == false )
				{
					if( kollision_Ball_Stein( pTheBall, *i ) )
					{
						pTheBall.invertTempo_Full();
						while( kollision_Ball_Stein( pTheBall, *i ) )
						{
							pTheBall.pixelMove();
						}
						pTheBall.invertTempo_Full();
						i->hit(pTheBall);
					}
				}
				else
				{
					pBlocks.erase(i);
					break;
				}
			}
			for( std::vector<Stein_Doublehit>::iterator i = pDoublehits.begin(); i != pDoublehits.end(); ++i )
			{
				if( i->getDestroyed() == false )
				{
					if( kollision_Ball_Stein( pTheBall, *i ) )
					{
						pTheBall.invertTempo_Full();
						while( kollision_Ball_Stein( pTheBall, *i ) )
						{
							pTheBall.pixelMove();
						}
						pTheBall.invertTempo_Full();
						i->hit(pTheBall);
					}
				}
				else
				{
					pDoublehits.erase(i);
					UpdScore(Pkt_Double);
					break;
				}
			}

			if( pOutside(pTheBall) )
			{
				bool lCollision = false;
				for( std::vector<Paddle>::iterator i = pPaddles.begin(); i != pPaddles.end(); ++i )
				{
					if( kollision_Ball_Paddle( pTheBall, *i ) )
					{
						pTheBall.invertTempo_Full();
						while( kollision_Ball_Paddle( pTheBall, *i ) )
						{
							pTheBall.pixelMove();
						}
						pTheBall.invertTempo_Full();
						abprall_Ball_Paddle( pTheBall, *i );
						lCollision = true;
					}
				}
				if( lCollision == false )
				{
					BallOut = true;
					UpdScore(Pkt_Ballout);
				}
			}

			if( pSteine.empty() && pDoublehits.empty() )
			{
				LevelDone = true;
				UpdScore(Pkt_Levelfinish);
			}

			pTheBall.fly( pApp.GetFrameTime() );

			pApp.Clear();
			pApp.Draw(pBG);
			pApp.Draw(gScore_Text);
			pApp.Draw(pST);
			pApp.Draw(pLV);
			for( std::vector<Stein_Break>::iterator i = pSteine.begin(); i != pSteine.end(); ++i )
			{
				pApp.Draw(*i);
			}
			for( std::vector<Stein_Block>::iterator i = pBlocks.begin(); i != pBlocks.end(); ++i )
			{
				pApp.Draw(*i);
			}
			for( std::vector<Stein_Doublehit>::iterator i = pDoublehits.begin(); i != pDoublehits.end(); ++i )
			{
				pApp.Draw(*i);
			}
			for( std::vector<Paddle>::iterator i = pPaddles.begin(); i != pPaddles.end(); ++i )
			{
				pApp.Draw( *i );
			}
			pApp.Draw(pTheBall);
			pApp.Display();
		}

		pTheBall.moveTo(Ball_Normposition);
		pTheBall.setTempo(Ball_Normtempo);

		sf::Clock Uhr;
		bool Clicked = false;
		while( pApp.IsOpened() && Uhr.GetElapsedTime() < 3 && !Clicked && !LevelDone )
		{
			while( pApp.GetEvent( Event ) )
			{
				switch(Event.Type)
				{
				case sf::Event::Closed:
					pApp.Close();
					break;
				case sf::Event::MouseButtonPressed:
					Clicked = true;
					break;
				case sf::Event::MouseMoved:
					for( std::vector<Paddle>::iterator i = pPaddles.begin(); i != pPaddles.end(); ++i )
					{
						if( i->getDrehung() == 0 || i->getDrehung() == 180 )
						{
							i->moveCenterToX( pApp.GetInput().GetMouseX() );
						}
						else
						{
							i->moveCenterToY( pApp.GetInput().GetMouseY() );
						}
					}
					break;
				}
			}

			pApp.Clear();
			pApp.Draw(pBG);
			pApp.Draw(gScore_Text);
			pApp.Draw(pST);
			pApp.Draw(pLV);
			for( std::vector<Stein_Break>::iterator i = pSteine.begin(); i != pSteine.end(); ++i )
			{
				pApp.Draw(*i);
			}
			for( std::vector<Stein_Block>::iterator i = pBlocks.begin(); i != pBlocks.end(); ++i )
			{
				pApp.Draw(*i);
			}
			for( std::vector<Stein_Doublehit>::iterator i = pDoublehits.begin(); i != pDoublehits.end(); ++i )
			{
				pApp.Draw(*i);
			}
			for( std::vector<Paddle>::iterator i = pPaddles.begin(); i != pPaddles.end(); ++i )
			{
				pApp.Draw( *i );
			}
			pApp.Draw(pTheBall);
			pApp.Display();
		}
	}
}

void Intro( sf::RenderWindow& pApp, std::vector<Stein_Break>& pSteine, std::vector<Stein_Block>& pBlocks,
		   std::vector<Stein_Doublehit> pDoublehits, std::vector<Paddle>& pPaddles,
		   sf::Sprite& pBG, sf::Sprite pLV, sf::Sprite pST, Ball& pTheBall )
{
	sf::Clock Uhr;
	while( pApp.IsOpened() && Uhr.GetElapsedTime() < 4 )
	{
		sf::Event Event;
		while( pApp.GetEvent(Event) )
		{
			switch(Event.Type)
			{
			case sf::Event::Closed:
				pApp.Close();
				break;
			}
		}

		pApp.Clear();
		pApp.Draw(pBG);
		pApp.Draw(gScore_Text);
		if( Uhr.GetElapsedTime() > 2 )
		{
			for( std::vector<Stein_Break>::iterator i = pSteine.begin(); i != pSteine.end(); ++i )
			{
				pApp.Draw(*i);
			}
			for( std::vector<Stein_Block>::iterator i = pBlocks.begin(); i != pBlocks.end(); ++i )
			{
				pApp.Draw(*i);
			}
			for( std::vector<Stein_Doublehit>::iterator i = pDoublehits.begin(); i != pDoublehits.end(); ++i )
			{
				pApp.Draw(*i);
			}
		}
		if( Uhr.GetElapsedTime() > 1 )
		{
			for( std::vector<Paddle>::iterator i = pPaddles.begin(); i != pPaddles.end(); ++i )
			{
				pApp.Draw(*i);
			}
			pApp.Draw(pLV);
			pApp.Draw(pST);
		}
		if( Uhr.GetElapsedTime() > 3 )
		{
			pApp.Draw(pTheBall);
		}
		pApp.Display();
	}
}

double ankathete( double pWinkel, double pHypotenuse )
{
	return cos( inBogenmass(pWinkel) ) * pHypotenuse;
}

double gegenkathete( double pWinkel, double pHypotenuse )
{
	return sin( inBogenmass(pWinkel) ) * pHypotenuse;
}

void abprall_Ball_Paddle( Ball& pBall, const Paddle& pPaddle )
{
	if( pBall.getPosition_Center().y < pPaddle.getPosition_Center().y )
	{
		if( pBall.getPosition_Center().x > pPaddle.getPosition_Center().x )
		{
			double lResultierende = sqrt( square( pBall.getTempo().x ) + square( pBall.getTempo().y ) );
			double lWinkel = inGradmass( atan( ( ( pPaddle.getPosition_Center().y - pBall.getPosition_Center().y )
				/ ( pBall.getPosition_Center().x - pPaddle.getPosition_Center().x ) ) ) );
			pBall.setTempo( sf::Vector2f( ankathete( lWinkel, lResultierende ), -gegenkathete( lWinkel, lResultierende ) ) );
		}
		else if( pBall.getPosition_Center().x < pPaddle.getPosition_Center().x )
		{
			double lResultierende = sqrt( square( pBall.getTempo().x ) + square( pBall.getTempo().y ) );
			double lWinkel = inGradmass( atan( ( ( pPaddle.getPosition_Center().x - pBall.getPosition_Center().x )
				/ ( pPaddle.getPosition_Center().y - pBall.getPosition_Center().y ) ) ) );
			pBall.setTempo( sf::Vector2f( -gegenkathete( lWinkel, lResultierende ), -ankathete( lWinkel, lResultierende ) ) );
		}
		else
		{
			pBall.setTempo( sf::Vector2f( pBall.getTempo().x, -pBall.getTempo().y ) );
		}
	}
	else if( pBall.getPosition_Center().y > pPaddle.getPosition_Center().y )
	{
		if( pBall.getPosition_Center().x > pPaddle.getPosition_Center().x )
		{
			double lResultierende = sqrt( square( pBall.getTempo().x ) + square( pBall.getTempo().y ) );
			double lWinkel = inGradmass( atan( ( ( pBall.getPosition_Center().x - pPaddle.getPosition_Center().x )
				/ ( pBall.getPosition_Center().y - pPaddle.getPosition_Center().y ) ) ) );
			pBall.setTempo( sf::Vector2f( gegenkathete( lWinkel, lResultierende ), ankathete( lWinkel, lResultierende ) ) );
		}
		else if( pBall.getPosition_Center().x < pPaddle.getPosition_Center().x )
		{
			double lResultierende = sqrt( square( pBall.getTempo().x ) + square( pBall.getTempo().y ) );
			double lWinkel = inGradmass( atan( ( ( pBall.getPosition_Center().y - pPaddle.getPosition_Center().y )
				/ ( pPaddle.getPosition_Center().x - pBall.getPosition_Center().x ) ) ) );
			pBall.setTempo( sf::Vector2f( -ankathete( lWinkel, lResultierende ), gegenkathete( lWinkel, lResultierende ) ) );
		}
		else
		{
			pBall.setTempo( sf::Vector2f( pBall.getTempo().x, -pBall.getTempo().y ) );
		}
	}
	else
	{
		pBall.setTempo( sf::Vector2f( -pBall.getTempo().x, pBall.getTempo().y ) );
	}
}

void erstelleSteinreihe( std::vector<Stein_Break>& pSteine, const sf::Vector2f& pBeginn, const sf::Vector2f& pAbschnitte, int pAnzahl )
{
	for( int i = 0; i < pAnzahl; ++i )
	{
		pSteine.push_back( Stein_Break( sf::Vector2f( pBeginn.x + pAbschnitte.x * i, pBeginn.y + pAbschnitte.y * i )
			, "Pictures/Stein.png" ) );
	}
}

void erstelleSteinreihe( std::vector<Stein_Block>& pSteine, const sf::Vector2f& pBeginn, const sf::Vector2f& pAbschnitte, int pAnzahl )
{
	for( int i = 0; i < pAnzahl; ++i )
	{
		pSteine.push_back( Stein_Block( sf::Vector2f( pBeginn.x + pAbschnitte.x * i, pBeginn.y + pAbschnitte.y * i )
			, "Pictures/Stein_Block.png" ) );
	}
}

void erstelleSteinreihe( std::vector<Stein_Doublehit>& pDoublehits, const sf::Vector2f& pBeginn, const sf::Vector2f& pAbschnitte, int pAnzahl )
{
	for( int i = 0; i < pAnzahl; ++i )
	{
		pDoublehits.push_back( Stein_Doublehit( sf::Vector2f( pBeginn.x + pAbschnitte.x * i, pBeginn.y + pAbschnitte.y * i )
			, "Pictures/Stein_Doublehit_D0.png", "Pictures/Stein_Doublehit_D1.png" ) );
	}
}

double inBogenmass( double pWinkel )
{
	return pWinkel/180*3.1415926535;
}

double inGradmass( double pWinkel )
{
	return pWinkel*180/3.1415926535;
}

bool kollision_Ball_Stein( const Ball& pBall, const Stein& pStein )
{
	int Ball_Radius = pBall.getRadius();
	sf::Vector2f Ball_Position_Mitte = pBall.getPosition_Center();
	sf::Vector2f Stein_Position_OL = pStein.getPosition_OL();
	sf::Vector2f Stein_Size = pStein.getSize();

	if( !( Ball_Position_Mitte.x + Ball_Radius < Stein_Position_OL.x )
		&& !( Ball_Position_Mitte.x - Ball_Radius > Stein_Position_OL.x + Stein_Size.x )
		&& !( Ball_Position_Mitte.y + Ball_Radius < Stein_Position_OL.y )
		&& !( Ball_Position_Mitte.y - Ball_Radius > Stein_Position_OL.y + Stein_Size.y ) )
	{
		return true;
	}
	else
	{
		if( sqrt( square( Ball_Position_Mitte.x - Stein_Position_OL.x ) + square( Ball_Position_Mitte.y - Stein_Position_OL.y ) ) < Ball_Radius
			|| sqrt( square( Ball_Position_Mitte.x - ( Stein_Position_OL.x + Stein_Size.x ) ) + square( Ball_Position_Mitte.y - ( Stein_Position_OL.y + Stein_Size.y ) ) ) < Ball_Radius
			|| sqrt( square( Ball_Position_Mitte.x - Stein_Position_OL.x ) + square( Ball_Position_Mitte.y - ( Stein_Position_OL.y + Stein_Size.y ) ) ) < Ball_Radius
			|| sqrt( square( Ball_Position_Mitte.x - ( Stein_Position_OL.x + Stein_Size.x ) ) +	square( Ball_Position_Mitte.y - Stein_Position_OL.y ) ) < Ball_Radius)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}

bool kollision_Ball_Paddle( const Ball& pBall, const Paddle& pPaddle )
{
	int Ball_Radius = pBall.getRadius();
	sf::Vector2f Ball_Position_Mitte = pBall.getPosition_Center();
	sf::Vector2f Paddle_Position_OL = pPaddle.getPosition_OL();
	sf::Vector2f Paddle_Size = pPaddle.getSize();

	if( !( Ball_Position_Mitte.x + Ball_Radius < Paddle_Position_OL.x )
		&& !( Ball_Position_Mitte.x - Ball_Radius > Paddle_Position_OL.x + Paddle_Size.x )
		&& !( Ball_Position_Mitte.y + Ball_Radius < Paddle_Position_OL.y )
		&& !( Ball_Position_Mitte.y - Ball_Radius > Paddle_Position_OL.y + Paddle_Size.y ) )
	{
		return true;
	}
	else
	{
		if( sqrt( square( Ball_Position_Mitte.x - Paddle_Position_OL.x ) + square( Ball_Position_Mitte.y - Paddle_Position_OL.y ) ) < Ball_Radius
			|| sqrt( square( Ball_Position_Mitte.x - ( Paddle_Position_OL.x + Paddle_Size.x ) ) + square( Ball_Position_Mitte.y - (Paddle_Position_OL.y + Paddle_Size.y ) ) ) < Ball_Radius
			|| sqrt( square( Ball_Position_Mitte.x - Paddle_Position_OL.x ) + square( Ball_Position_Mitte.y - ( Paddle_Position_OL.y + Paddle_Size.y ) ) ) < Ball_Radius
			|| sqrt( square( Ball_Position_Mitte.x - ( Paddle_Position_OL.x + Paddle_Size.x ) ) + square( Ball_Position_Mitte.y - Paddle_Position_OL.y ) ) < Ball_Radius )
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}

double square( double x )
{
	return x * x;
}