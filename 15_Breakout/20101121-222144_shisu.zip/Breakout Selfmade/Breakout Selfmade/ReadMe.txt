 _____        _____ _   _         
| __  |_ _   |   __| |_|_|___ _ _ 
| __ -| | |  |__   |   | |_ -| | |
|_____|_  |  |_____|_|_|_|___|___|
      |___|                       
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

"Breakout Selfmade" ist ein Breatout-Klon, programmiert
von Dennis Marschner aka Shisu mit SFML.

- Breakout Selfmade Version -

1.0


- Steuerung -

Starten und loslegen!


- Credits -

Code Programmiert von		Dennis Marschner
Grafiken erstellt von		Dennis Marschner
Fonts erhalten von		http://www.dafont.com/
Lizenz der Fonts		Free


- Daten -

Genutzte SFML-Version:		2.0
