#include "Stein.h"
#include "ImageManager.h"

Stein::Stein(const sf::Vector2f& pPosition, const std::string& pBildpfad)
: Drawable(pPosition), Position_OL(pPosition), Bild_Sprite( *ImgMng.getResource(pBildpfad) ), Destroyed(false)
{
	Size = Bild_Sprite.GetSize();
}

Stein::Stein(const sf::Vector2f& pPosition, const sf::Vector2f& pSize, const std::string& pBildpfad)
: Drawable(pPosition), Position_OL(pPosition), Bild_Sprite( *ImgMng.getResource(pBildpfad) ), Destroyed(false), Size(pSize)
{
}

sf::Vector2f Stein::getPosition_OL() const
{
	return Position_OL;
}

sf::Vector2f Stein::getPosition_Center() const
{
	return sf::Vector2f(Position_OL.x+Size.x/2, Position_OL.y+Size.y/2);
}

bool Stein::getDestroyed() const
{
	return Destroyed;
}

sf::Vector2f Stein::getSize() const
{
	return Size;
}

bool Stein::isLeft(const Ball& pBall) const
{
	return pBall.getPosition_Center().x < this->getPosition_OL().x;
}

bool Stein::isRight(const Ball& pBall) const
{
	return pBall.getPosition_Center().x > this->getPosition_OL().x+this->getSize().x;
}

bool Stein::isAbove(const Ball& pBall) const
{
	return pBall.getPosition_Center().y < this->getPosition_OL().y;
}

bool Stein::isUnder(const Ball& pBall) const
{
	return pBall.getPosition_Center().y > this->getPosition_OL().y+this->getSize().y;
}

void Stein::Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const
{
	if(!Destroyed)
	{
		Target.Draw(Bild_Sprite);
	}
}