#ifndef BALL_H
#define BALL_H

/* Bibliotheken-Includes */
#include <iostream>
#include <fstream>
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <sstream>

/* Eigene Header-Includes */

/* Ball
 * Der Ball bewegt sich �ber das Spielfeld und wird von den Paddles sowie diversen Steinen abgeblockt. Letztere kann
 * er auch durch (mehrmaliges) ber�hren zerst�ren. */
class Ball : public sf::Drawable
{
private:
	void Render( sf::RenderTarget& Target, sf::Renderer& renderer ) const;
	sf::Sprite Bild_Sprite;
	sf::Vector2f Position_Center, Tempo;
	float Radius;
public:
	Ball(const sf::Vector2f& pPosition, float pRadius);
	float getRadius() const;
	void setTempo(const sf::Vector2f& pTempo);
	sf::Vector2f getTempo() const;
	void fly(double pFaktor);
	void invertTempo_X();
	void invertTempo_Y();
	void invertTempo_Full();
	sf::Vector2f getPosition_OL() const;
	void moveTo(const sf::Vector2f& pPosition);
	void pixelMove();
	sf::Vector2f getPosition_Center() const;
};

#endif