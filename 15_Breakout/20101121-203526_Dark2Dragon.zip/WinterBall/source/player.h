#include <SFML/Graphics.hpp>

#ifndef PLAYER_H
#define PLAYER_H

class Player
{
private:

	float fTimer;
	int lives;
	sf::Image PlayerImage;
	sf::Image LifeImage;
	sf::Sprite PlayerSprite;
	sf::Sprite Life1;
	sf::Sprite Life2;
	sf::Sprite Life3;
	sf::Sprite Life4;
	sf::Sprite Life5;

public:
	Player();
	void Move(sf::RenderWindow &App);
	void Reset();
	void AddLife(); 
	void RemoveLife() {lives--;}
	void ChangeSize(bool bWhat);
	void ReNew();
	int getLives() {return lives;}
	sf::Sprite getSprite() {return PlayerSprite;}
	void Draw(sf::RenderWindow &App);
};


#endif