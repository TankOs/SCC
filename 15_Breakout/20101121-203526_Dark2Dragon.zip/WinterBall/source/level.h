#include <SFML/Graphics.hpp>
#include <list>
#include <iostream>
#include <fstream>
#include <sstream>
#include "blocks.h"
#include "ball.h"
#include "bonus.h"

#ifndef LEVEL_H
#define LEVEL_H

class Level
{
private:
	// Score
	float score;

	// Block Bilder
	sf::Image Block1Image;
	sf::Image Block2Image;
	sf::Image Block3Image;
	sf::Image Block4Image;
	sf::Image Block5Image;

	// Bonus Bilder
	sf::Image BonusImage;

	// Background
	sf::Image RahmenImage;
	sf::Image BackgroundImage;
	sf::Sprite BackgroundSprite;
	sf::Sprite RahmenSprite;

	// Level
	int stage;
	std::list<Blocks> LevelStruct;
	std::list<Bonus> BonusList;

public:
	Level();
	void BuildLevel(int iStage);
	Blocks BuildBlock(int status, float xPos, float yPos);
	void checkCollision(Ball &ball, Sound &sound);
	int checkLevel(sf::Sprite &Player, sf::RenderWindow &App);
	void reset();
	float getScore() {return score;}
	int getLevel() {return stage;}
	void Draw(sf::RenderWindow &App);
	void DrawRahmen(sf::RenderWindow &App) {App.Draw(RahmenSprite);}
};


#endif