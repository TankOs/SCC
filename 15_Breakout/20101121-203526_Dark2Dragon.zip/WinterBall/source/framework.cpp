#include "framework.h"

Framework::Framework() {
	FrameWorkStage = 0;
	stopMove = true;
	Timer = 0;
	iBonus = 0;

	GameOverImage.LoadFromFile("gfx/gameover.png");
	GameOverImage.SetSmooth(false);
	GameOverSprite.SetImage(GameOverImage);
	GameOverSprite.SetPosition(387, 300);

	MenueImage.LoadFromFile("gfx/menue.png");
	MenueImage.SetSmooth(false);
	MenueSprite.SetImage(MenueImage);
	MenueSprite.SetPosition(0,0);

	BaseFont.LoadFromFile("verdanab.ttf");
	LevelFont.LoadFromFile("AlmonteSnow.ttf");
	
	YourScore.SetFont(BaseFont);
	YourScore.SetSize(50);
	YourScore.SetColor(sf::Color(255,0,0,255));
	YourScore.SetPosition(440, 420);

	Highscore.SetFont(BaseFont);
	Highscore.SetSize(38);
	Highscore.SetColor(sf::Color(0,0,102,255));
	Highscore.SetPosition(380,536);
	
	Score.SetFont(BaseFont);
	Score.SetSize(20);
	Score.SetPosition(90,734);
	Score.SetText("0");
	LevelName.SetFont(LevelFont);
	LevelName.SetSize(76);
	LevelName.SetPosition(390, 180);
	LevelName.SetText("");
	LevelName.SetColor(sf::Color(255,0,0,255));
	DrawLevelString=false;
	gameover = false;

	GameEngineState = 0;

	sound.PlayLoop();
}


// MAIN PROCESS!
void Framework::Go(sf::RenderWindow &App) {

	// Game Over?
	if (player.getLives() < 0 || FrameWorkStage == 50) {
		gameover = true;
		GameEngineState = 2;
	}

	// Level pr�fen und bauen
	if (FrameWorkStage != level.getLevel()) {
		level.BuildLevel(FrameWorkStage+1);
		FrameWorkStage++;
		sLevelName.str("");
		sLevelName << "Level " << FrameWorkStage;
		LevelName.SetText(sLevelName.str());
		player.Reset();
		ball.Reset();
		stopMove = true;
		DrawLevelString=true;
	}

	// Timer f�r StopMove
	if (stopMove == true) {
		if (Timer == 90) {
			stopMove = false;
			Timer = 0;
			DrawLevelString=false;
		}
		Timer++;
	}
		
	// Bewegung
	if (stopMove == false && gameover == false) {
		player.Move(App);
		if (ball.Move(player.getSprite(), App, sound) == true) {
			player.RemoveLife();
			ball.Reset();
			player.Reset();
			stopMove = true;
			sound.PlayLoose();
		}		
	}
	ball.Rotate();

	// Score
	sScore.str("");
	sScore << level.getScore();
	Score.SetText(sScore.str());


	// Levelkollisionen
	level.checkCollision(ball, sound);
	iBonus = level.checkLevel(player.getSprite(), App);

	// Bonus auswerten
	if (iBonus != 0) {
		switch(iBonus) {
			case 1:
				ball.SpeedY(-1);
				break;
			case 2:
				ball.SpeedY(1);
				break;
			case 3:
				player.ChangeSize(true);
				break;
			case 4:
				player.ChangeSize(false);
				break;
			case 5:
				player.AddLife();
				break;
			default: 
				break;
		}
		sound.PlayBonus();
	}

}

// Reset
void Framework::Reset() {
	FrameWorkStage = 0;
	stopMove = true;
	Timer = 0;
	iBonus = 0;
	DrawLevelString=false;
	gameover = false;

	level.reset();
	player.ReNew();
}

// Check Highscore
void Framework::checkHighscore() {
	
	std::string line;
	std::string sscore;
	std::string newHighscoreList="";
	std::stringstream convert;
	int iVergleich;
	int iYourScore;
	bool newHighScore=false;

	convert << level.getScore();
	convert >> iYourScore;
	convert.clear();
	
	std::ifstream file("highscore");
	if (!file.good())
	{
		std::cerr << "Not able to open file highscore" << std::endl;
	}

	while (!file.eof())
	{
		std::getline(file, line);
	
		convert << line.substr(0,6);
		convert >> iVergleich;
		convert.clear();

		if (iYourScore > iVergleich && newHighScore == false) {
			convert << iYourScore;
			convert >> sscore;
			convert.clear();
				
			if (sscore.length() < 6) {
				int len = sscore.length();
				for(int i=0; i<6-len;i++)
					sscore = "0" + sscore;
			}

			newHighscoreList = newHighscoreList + sscore + "\n" + line + "\n";
			newHighScore = true;
		}
		else
			newHighscoreList = newHighscoreList + line + "\n";

		
	}
	file.close();

	// Neuer Highscore?
	if (newHighScore == true) {
		newHighscoreList = newHighscoreList.substr(0,34);
		std::ofstream newFile;
		newFile.open("highscore");
		newFile.clear();
		newFile << newHighscoreList;
		newFile.close();
	}

}
	
// DRAW ALL
void Framework::Draw(sf::RenderWindow &App) {
	level.Draw(App);
	ball.Draw(App);
	level.DrawRahmen(App);
	player.Draw(App);
	App.Draw(Score);

	if (DrawLevelString == true)
		App.Draw(LevelName);

	if (gameover == true) {
		App.Draw(GameOverSprite);
		sScore.str("");
		sScore << level.getScore();
		YourScore.SetText(sScore.str());
		App.Draw(YourScore);
	}


}

// DRAW MENUE
void Framework::DrawMenue(sf::RenderWindow &App) {

	std::string line;
	std::string highscore;

	App.Draw(MenueSprite);
	
	std::ifstream file("highscore");
	if (!file.good())
	{
		std::cerr << "Not able to open file highscore" << std::endl;
	}

	while (!file.eof())
	{
		std::getline(file, line);
		highscore = highscore + line + "\n";
	}

	file.close();

	sHighscore.str(highscore);
	Highscore.SetText(sHighscore.str());
	sHighscore.clear();

	App.Draw(Highscore);
}