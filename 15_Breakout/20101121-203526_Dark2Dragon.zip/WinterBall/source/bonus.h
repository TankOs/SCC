#include <SFML/Graphics.hpp>

#ifndef BONUS_H
#define BONUS_H

class Bonus
{
private:

	sf::Sprite BonusSprite;
	int boni;
	float fTimer;

public:
	Bonus(sf::Image &BonusImage, float xPos, float yPos);
	void Move(sf::RenderWindow &App);
	sf::Sprite getSprite() {return BonusSprite;}
	int getBoni() {return boni;}
	void Draw(sf::RenderWindow &App) {App.Draw(BonusSprite);}
};


#endif