#include "collision.h"

int simpleCollision(const sf::Sprite &object1, const sf::Sprite &object2) {
	float lx,uy,rx,dy;
	int back = 0;
	
	if (object1.GetPosition().x + object1.GetSize().x > object2.GetPosition().x && 
		object1.GetPosition().x < object2.GetPosition().x + object2.GetSize().x &&
		object1.GetPosition().y + object1.GetSize().y > object2.GetPosition().y &&
		object1.GetPosition().y < object2.GetPosition().y + object2.GetSize().y)
	{  
		uy = (object1.GetPosition().y + object1.GetSize().y) - object2.GetPosition().y;
		dy = (object2.GetPosition().y + object2.GetSize().y) - object1.GetPosition().y; 
		lx = (object1.GetPosition().x + object1.GetSize().x) - object2.GetPosition().x;
		rx = (object2.GetPosition().x + object2.GetSize().x) - object1.GetPosition().x;

		//keine negativen Werte zulassen!
		if (uy < 0) {uy = uy *-1;}
		if (dy < 0) {dy = dy *-1;}
		if (lx < 0) {lx = lx *-1;}
		if (rx < 0) {rx = rx *-1;}

		//der kleinste Wert zeigt die Kollision an
		if (uy < dy && uy < rx && uy < lx)
		{		
			//Kollision oben
			back = 1;
		}
		if (dy < uy && dy < rx && dy < lx)
		{
			//Kollision unten
			back = 2;
		}
		if (lx < dy && lx < uy && lx < rx)
		{		
			//Kollision links
			back = 3;
		}
		if (rx < dy && rx < uy && rx < lx)
		{		
			//Kollision rechts
			back = 4;
		}
	
	}
	return back;
}