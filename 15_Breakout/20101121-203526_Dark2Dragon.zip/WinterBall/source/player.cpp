#include "player.h"


Player::Player() {
	
	PlayerImage.LoadFromFile("gfx/player.png");
	PlayerImage.SetSmooth(false);

	LifeImage.LoadFromFile("gfx/life.png");
	LifeImage.SetSmooth(false);

	PlayerSprite.SetImage(PlayerImage);

	PlayerSprite.SetPosition(427, 650);

	fTimer = 0;

	lives = 3;

	Life1.SetImage(LifeImage);
	Life2.SetImage(LifeImage);
	Life3.SetImage(LifeImage);
	Life4.SetImage(LifeImage);
	Life5.SetImage(LifeImage);

	Life1.SetPosition(974, 728);
	Life2.SetPosition(934, 728);
	Life3.SetPosition(894, 728);
	Life4.SetPosition(854, 728);
	Life5.SetPosition(814, 728);
}


void Player::Move(sf::RenderWindow &App) {
	fTimer = App.GetFrameTime()*100;

	if (App.GetInput().IsKeyDown(sf::Key::Left)) {
		if (PlayerSprite.GetPosition().x-(5*fTimer) < 30) 
			PlayerSprite.SetPosition(30, PlayerSprite.GetPosition().y);
		else	
			PlayerSprite.Move(-(5*fTimer),0);
	}

	if (App.GetInput().IsKeyDown(sf::Key::Right)) {
		if (PlayerSprite.GetPosition().x+(5*fTimer) > 994 - PlayerSprite.GetSize().x) 
			PlayerSprite.SetPosition(994 - PlayerSprite.GetSize().x, PlayerSprite.GetPosition().y);
		else	
			PlayerSprite.Move(5*fTimer,0);
	}
}

void Player::Reset() {
	PlayerSprite.SetScaleX(1);
	PlayerSprite.SetPosition(427, 650);
}


void Player::AddLife() {
	if (lives < 5)
		lives++;
}

void Player::Draw(sf::RenderWindow &App) {

	App.Draw(PlayerSprite);

	switch (lives) {
		case 5: App.Draw(Life5);
		case 4: App.Draw(Life4);
		case 3: App.Draw(Life3);
		case 2: App.Draw(Life2);
		case 1: App.Draw(Life1);
	}
}

void Player::ChangeSize(bool bWhat) {

	if (bWhat == true) {
		if (PlayerSprite.GetScale().x < 2)
			PlayerSprite.SetScaleX(PlayerSprite.GetScale().x+0.5);
	}
	else {
		if (PlayerSprite.GetScale().x > 0.5)
			PlayerSprite.SetScaleX(PlayerSprite.GetScale().x-0.5);
	}
}

void Player::ReNew() {
	lives = 3;
}