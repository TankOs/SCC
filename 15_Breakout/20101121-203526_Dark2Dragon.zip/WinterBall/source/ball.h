#include <SFML/Graphics.hpp>
#include "sound.h"


#ifndef BALL_H
#define BALL_H

class Ball
{
private:

	sf::Image BallImage;
	sf::Sprite BallSprite;
	int xRect;
	int rectTimer;
	float fxSpeed, fySpeed;
	float fWinkel;
	float fTimer;

public:
	Ball();
	void Rotate();
	bool Move(sf::Sprite PlayerSprite, sf::RenderWindow &App, Sound &sound);
	void changeDir(int LevelCollision, sf::Sprite &Block);
	void SpeedY(float ySpeed);
	void Reset();
	sf::Sprite getSprite() {return BallSprite;}
	void Draw(sf::RenderWindow &App) {App.Draw(BallSprite);}
};


#endif