#include <SFML/Graphics.hpp>

#ifndef BLOCKS_H
#define BLOCKS_H

class Blocks
{
private:

	sf::Sprite BlockSprite;
	int status;
	int anim;
	int animTimer;

public:
	Blocks(int iStatus, sf::Image &BlockImage, float xPos, float yPos);
	void changeStatus(int iStatus, sf::Image &BlockImage);
	void setPosition(float x, float y);
	void Destroyed();
	sf::Sprite getSprite() {return BlockSprite;}
	int getStatus() {return status;}
	void Draw(sf::RenderWindow &App) {App.Draw(BlockSprite);}
};


#endif