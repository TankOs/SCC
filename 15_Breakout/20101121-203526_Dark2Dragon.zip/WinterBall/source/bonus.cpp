#include "bonus.h"

Bonus::Bonus(sf::Image &BonusImage, float xPos, float yPos) {

	// Zufallsgenerator: welcher Bonus?
	boni = sf::Randomizer::Random(0,4);

	// Leben ist schwerer zu bekommen :)
	if (boni == 4)
		boni = sf::Randomizer::Random(0,4);


	BonusSprite.SetImage(BonusImage);
	BonusSprite.SetSubRect(sf::IntRect(boni*50,0,(boni+1)*50,50));
	BonusSprite.SetPosition(xPos+23,yPos);

	fTimer = 0;
}

void Bonus::Move(sf::RenderWindow &App) {
	fTimer = App.GetFrameTime()*100;

	BonusSprite.Move(0,3*fTimer);
}