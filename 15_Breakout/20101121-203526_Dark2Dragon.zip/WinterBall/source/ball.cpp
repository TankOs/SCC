#include "ball.h"
#include "collision.h"

Ball::Ball() {

	BallImage.LoadFromFile("gfx/ball.png");
	BallImage.SetSmooth(false);

	BallSprite.SetImage(BallImage);

	rectTimer = 0;
	xRect = 0;

	fxSpeed = 2;
	fySpeed = 2;

	BallSprite.SetSubRect(sf::IntRect(xRect*30,0,(xRect*30)+30,30));
}


void Ball::Rotate() {
	
	if (rectTimer == 2) {
		rectTimer = 0;

		if (xRect == 7) 
			xRect = 0;
		else
			xRect++;

		BallSprite.SetSubRect(sf::IntRect(xRect*30,0,(xRect*30)+30,30));
	}
	else
		rectTimer++;
}


bool Ball::Move(sf::Sprite PlayerSprite, sf::RenderWindow &App, Sound &sound) {
	bool ret=false;
	fTimer = App.GetFrameTime()*100;
	int checkPlayerCol=0;
	int iFactorX;

	// --- Kollision mit Wand pr�fen ---
	if (BallSprite.GetPosition().x <= 30) { 
		BallSprite.SetPosition(31, BallSprite.GetPosition().y);
		fxSpeed = -1*fxSpeed;
		sound.PlayClong();
	}

	if (BallSprite.GetPosition().x >= 994 - BallSprite.GetSize().x) {
		BallSprite.SetPosition(993 - BallSprite.GetSize().x, BallSprite.GetPosition().y);
		fxSpeed = -1*fxSpeed;
		sound.PlayClong();
	}

	if (BallSprite.GetPosition().y <= 30) {
		BallSprite.SetPosition(BallSprite.GetPosition().x, 31);
		fySpeed = -1*fySpeed;
		sound.PlayClong();
	}

	if (BallSprite.GetPosition().y >= 738) {
		ret = true;
	}

	// --- Kollision mit Spieler pr�fen ---
	checkPlayerCol = simpleCollision(BallSprite, PlayerSprite);

	// Kollision oben
	if (checkPlayerCol == 1) {
		BallSprite.SetPosition(BallSprite.GetPosition().x, PlayerSprite.GetPosition().y - BallSprite.GetSize().y);
		fySpeed = -1*fySpeed;

		iFactorX = (PlayerSprite.GetPosition().x+(PlayerSprite.GetSize().x/2)-BallSprite.GetPosition().x)/17;

		fxSpeed = -1*iFactorX;
		sound.PlayClong();
	}

	// Kollision links / rechts
	if (checkPlayerCol == 3 || checkPlayerCol == 4) {
		fxSpeed = -1*fxSpeed;
		sound.PlayClong();
	}


	// Ball bewegen
	BallSprite.Move(fxSpeed*fTimer, fySpeed*fTimer);

	return ret;
}


void Ball::changeDir(int LevelCollision, sf::Sprite &Block) {

	switch (LevelCollision) {
		case 1:
			BallSprite.SetPosition(BallSprite.GetPosition().x, Block.GetPosition().y+22);//Block.GetSize().y);
			fySpeed = -1*fySpeed;
			break;
		case 2:
			BallSprite.SetPosition(BallSprite.GetPosition().x, Block.GetPosition().y-BallSprite.GetSize().y);
			fySpeed = -1*fySpeed;
			break;
		case 3:
			BallSprite.SetPosition(Block.GetPosition().x + Block.GetSize().x , BallSprite.GetPosition().y); 
			fxSpeed = -1*fxSpeed;
			break;
		case 4:
			BallSprite.SetPosition(Block.GetPosition().x - BallSprite.GetSize().x , BallSprite.GetPosition().y); 
			fxSpeed = -1*fxSpeed;
			break;
	}		
}

void Ball::Reset() {
	BallSprite.SetPosition(497,600);
	//fxSpeed = sf::Randomizer::Random(-1,1)
	fySpeed = -1;
	fxSpeed = 0;
}

void Ball::SpeedY(float ySpeed) {
	if (fySpeed < 0) {
		if (fySpeed > -7)
			fySpeed = fySpeed - ySpeed;
		if (fySpeed > -1)
			fySpeed = -1;
	}
	else {
		if (fySpeed < 7)
			fySpeed = fySpeed + ySpeed;
		if (fySpeed < 1)
			fySpeed = 1;
	}

}
