#include "level.h"
#include "collision.h"

Level::Level() {

	RahmenImage.LoadFromFile("gfx/rahmen.png");
	RahmenImage.SetSmooth(false);
	BackgroundImage.LoadFromFile("gfx/background.png");
	BackgroundImage.SetSmooth(false);
	Block1Image.LoadFromFile("gfx/block1.png");
	Block1Image.SetSmooth(false);
	Block2Image.LoadFromFile("gfx/block2.png");
	Block2Image.SetSmooth(false);
	Block3Image.LoadFromFile("gfx/block3.png");
	Block3Image.SetSmooth(false);
	Block4Image.LoadFromFile("gfx/block4.png");
	Block4Image.SetSmooth(false);
	Block5Image.LoadFromFile("gfx/block5.png");
	Block5Image.SetSmooth(false);

	BonusImage.LoadFromFile("gfx/bonus.png");
	BonusImage.SetSmooth("false");

	BackgroundSprite.SetImage(BackgroundImage);
	BackgroundSprite.SetPosition(0,0);

	RahmenSprite.SetImage(RahmenImage);
	RahmenSprite.SetPosition(0,0);

	stage = 1;
	score = 0;
}


void Level::BuildLevel(int iStage) {
	std::string line;
	std::string level;
	std::stringstream str;
	int iLevel[190];

	stage = iStage;

	std::ifstream file("levels");
	if (!file.good())
	{
		std::cerr << "Not able to open file levels" << std::endl;
	}

	while (!file.eof())
	{
		std::getline(file, line);
		level = level + line;
	}

	// Level ausw�hlen
	level = level.substr((stage-1)*190, 190);

	for (int i=0; i<190; i++) {
		str << level.substr(i,1);
		str >> iLevel[i];
		str.clear();
	}

	for (int j=0; j<19; j++) {
		for (int h=0; h<10; h++) {
			if (iLevel[(j*10)+h] != 0)
				LevelStruct.push_back(Level::BuildBlock(iLevel[(j*10)+h], ((h*96)+33), (j*22)+30));
		}
	}
	
	file.close();
}


void Level::Draw(sf::RenderWindow &App) {
	std::list<Blocks>::iterator lIter;
	std::list<Bonus>::iterator lIterBonus;

	App.Draw(BackgroundSprite);

	for (lIter=LevelStruct.begin(); lIter!=LevelStruct.end(); ) {
		lIter->Draw(App);
		lIter++;
	}

	for (lIterBonus=BonusList.begin(); lIterBonus!=BonusList.end(); ) {
		lIterBonus->Draw(App);
		lIterBonus++;
	}
}


void Level::checkCollision(Ball &ball, Sound &sound) {
	int collision=0;
	int state;
	std::list<Blocks>::iterator lIter;
	
	for (lIter=LevelStruct.begin(); lIter!=LevelStruct.end(); ) {
		collision = simpleCollision(lIter->getSprite(), ball.getSprite());

		if (collision != 0) {
			state = lIter->getStatus();

			switch (state) {
				case 5:
					lIter->changeStatus(2, Block2Image);
					score = score + 50;
					break;
				case 4:
					lIter->changeStatus(2, Block2Image);
					score = score + 40;
					break;
				case 3:
					lIter->changeStatus(2, Block2Image);
					score = score + 30;
					break;
				case 2:
					lIter->changeStatus(1, Block1Image);
					score = score + 20;
					break;
				case 1:
					lIter->changeStatus(0, Block1Image);
					score = score + 10;
					break;
				default:
					collision = 0;
			}
				
			ball.changeDir(collision, lIter->getSprite());
			ball.SpeedY(0.1);
			sound.PlayClong();
		}
		lIter++;
	}
}


int Level::checkLevel(sf::Sprite &Player, sf::RenderWindow &App) {
	std::list<Blocks>::iterator lIter;
	std::list<Bonus>::iterator lIterBonus;
	int ret = 0;

	int state;

	// LEVEL / BL�CKE
	if (LevelStruct.empty() == true) {
		stage++;
	}

	for (lIter=LevelStruct.begin(); lIter!=LevelStruct.end(); ) {
		state = lIter->getStatus();

		if (state == 0) 
			lIter->Destroyed();

		if (state == -1) {

			// Bonus erstellen?
			if (sf::Randomizer::Random(1,5) == 1) {
				BonusList.push_back(Bonus::Bonus(BonusImage, lIter->getSprite().GetPosition().x, lIter->getSprite().GetPosition().y));		
			}

			lIter = LevelStruct.erase(lIter);
		}
		else			
			lIter++;
	}

	// BONUS

	for (lIterBonus=BonusList.begin(); lIterBonus!=BonusList.end(); ) {
		
		lIterBonus->Move(App);

		// Kollision mit Spieler?
		if (simpleCollision(lIterBonus->getSprite(), Player) != 0) {
			ret = lIterBonus->getBoni()+1;
			lIterBonus = BonusList.erase(lIterBonus);
		}
		// Wenn nicht, dann au�erhalb Bildschirm?
		else {
			if (lIterBonus->getSprite().GetPosition().y > 768)
				lIterBonus = BonusList.erase(lIterBonus);
			else
				lIterBonus++;
		}
	}

	return ret;
}


Blocks Level::BuildBlock(int status, float xPos, float yPos) {
	Blocks block(status, Block1Image, xPos, yPos);

	switch (status) {
		case 2:
			block.changeStatus(status, Block2Image);
			break;
		case 3:
			block.changeStatus(status, Block3Image);
			break;
	}

	return block;
}


void Level::reset() {
	LevelStruct.clear();
	BonusList.clear();

	stage = 1;
	score = 0;
}
