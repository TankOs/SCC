#include <SFML/Audio.hpp>



#ifndef SOUND_H
#define SOUND_H

class Sound
{
private:
	sf::SoundBuffer LoopBuffer;
	sf::Sound MainLoop;
	sf::SoundBuffer LooseBuffer;
	sf::Sound Loose;
	sf::SoundBuffer ClongBuffer;
	sf::Sound Clong;
	sf::SoundBuffer Clong2Buffer;
	sf::Sound Clong2;
	sf::SoundBuffer BonusBuffer;
	sf::Sound Bonus;	
public:
	Sound();
	void PlayLoop();
	void PlayLoose();
	void PlayClong();
	void PlayBonus();	
};

#endif