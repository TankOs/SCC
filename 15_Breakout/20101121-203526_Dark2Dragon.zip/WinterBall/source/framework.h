#include "player.h"
#include "level.h"
#include "ball.h"
#include <sstream>

#ifndef FRAMEWORK_H
#define FRAMEWORK_H

class Framework
{
private:
	Player player;
	Level level;
	Ball ball;
	Sound sound;
	int iBonus;
	int FrameWorkStage;
	int Timer;
	int GameEngineState;
	bool gameover;
	bool stopMove;
	bool DrawLevelString;
	sf::Font BaseFont;
	sf::Font LevelFont;
	sf::String Highscore;
	sf::String Score;
	sf::String LevelName;
	sf::String YourScore;
	sf::Image MenueImage;
	sf::Image GameOverImage;
	sf::Sprite MenueSprite;
	sf::Sprite GameOverSprite;
	std::stringstream sHighscore;
	std::stringstream sLevelName;
	std::stringstream sScore;
	
public:
	Framework();
	void Initialize();
	int getState() {return GameEngineState;}
	void setState(int state) {GameEngineState = state;}
	void Go(sf::RenderWindow &App);
	void Reset();
	void checkHighscore();
	void DrawMenue(sf::RenderWindow &App);
	void Draw(sf::RenderWindow &App);
};


#endif