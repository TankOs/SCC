#include "blocks.h"

Blocks::Blocks(int iStatus, sf::Image &BlockImage, float xPos, float yPos) {
	
	status = iStatus;
	anim = 0;
	animTimer = 0;

	BlockSprite.SetImage(BlockImage);
	BlockSprite.SetSubRect(sf::IntRect(0,0,96,22));
	BlockSprite.SetPosition(xPos, yPos);
}


void Blocks::changeStatus(int iStatus, sf::Image &BlockImage) {
	
	status = iStatus;
	BlockSprite.SetImage(BlockImage);
	BlockSprite.SetSubRect(sf::IntRect(0,0,96,22));
}

void Blocks::Destroyed() {

	if (animTimer == 5 && status != -1) {
		animTimer = 0;
		anim++;
		BlockSprite.SetSubRect(sf::IntRect(0,anim*22,96,(1+anim)*22));

		if (anim == 4)
			status = -1;
	}

	animTimer++;
}

void Blocks::setPosition(float x, float y) {
		BlockSprite.SetPosition(x, y);
}