#include "sound.h"

Sound::Sound() {

	LoopBuffer.LoadFromFile("sfx/destination.ogg");
	MainLoop.SetBuffer(LoopBuffer);
	LooseBuffer.LoadFromFile("sfx/clong.ogg");
	Loose.SetBuffer(LooseBuffer);
	ClongBuffer.LoadFromFile("sfx/bell.ogg");
	Clong.SetBuffer(ClongBuffer);
	Clong2Buffer.LoadFromFile("sfx/bell2.ogg");
	Clong2.SetBuffer(Clong2Buffer);
	BonusBuffer.LoadFromFile("sfx/drip.ogg");
	Bonus.SetBuffer(BonusBuffer);
}

void Sound::PlayLoop() {
	MainLoop.Play();
	MainLoop.SetLoop(true);
}

void Sound::PlayLoose() {
	Loose.Play();
}

void Sound::PlayClong() {
	if (sf::Randomizer::Random(1,2) == 1)
		Clong.Play();
	else
		Clong2.Play();
}

void Sound::PlayBonus() {
	Bonus.Play();
}
