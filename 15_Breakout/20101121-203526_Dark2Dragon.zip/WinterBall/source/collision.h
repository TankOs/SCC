// Collision by Dark2Dragon 2010
//


#include <SFML/Graphics.hpp>

#ifndef COLLISION_H
#define COLLISION_H


// SIMPLE COLLISION
// return:
// 1 for upper collision
// 2 for lower collision
// 3 for left collision
// 4 for right collision

int simpleCollision(const sf::Sprite &object1, const sf::Sprite &object2);

#endif
