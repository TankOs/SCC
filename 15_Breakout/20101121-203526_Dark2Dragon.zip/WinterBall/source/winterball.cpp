////////////////////////////////////////////////////////////
// WINTERBALL
////////////////////////////////////////////////////////////
// (c) Dark2Dragon 2010
// V 0.1b


#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

#include "framework.h"


int main()
{

	// ### Main Window ###
	sf::RenderWindow App(sf::VideoMode(1024, 768, 16), "Winterball");

	App.SetFramerateLimit(60);
	App.ShowMouseCursor(false);

	// Initilize FRAMEWORK
	Framework gameEngine;

	// Pause
	bool Pause = false;

	// Neuer Highscore
	bool high=false;

	// ### Start game loop ###
    while (App.IsOpened())
    {  
		if (gameEngine.getState() == 0) {
			// Draw Menue
			gameEngine.DrawMenue(App);
		}
	
		if (gameEngine.getState() > 0) {
						
			// Main Process
			if (Pause == false)
				gameEngine.Go(App);	
			
			// DRAW all
			gameEngine.Draw(App);	
		}


		// Process events
        sf::Event Event;
        while (App.GetEvent(Event))
        {
			// Close window: exit
            if (Event.Type == sf::Event::Closed)
                App.Close();

			// KeyEvents abfangen
			if (Event.Type == sf::Event::KeyPressed)
			{
				// only in Menue - Any Key
				if (gameEngine.getState() == 0) {
					gameEngine.Reset();
					gameEngine.setState(1);
				}

				// Pause Button
				if (Event.Key.Code == sf::Key::Pause) {
					if (Pause == false)
						Pause = true;
					else
						Pause = false;
				}
				
				// Escape key: exit
                if (Event.Key.Code == sf::Key::Escape)
                    App.Close();	

				// GameOver press enter
				if (Event.Key.Code == sf::Key::Return && gameEngine.getState() == 2) {
					gameEngine.checkHighscore();
					gameEngine.setState(0);
				}
			}	     
		}

		App.Display();
		App.Clear();
	}

	return 0;
}

