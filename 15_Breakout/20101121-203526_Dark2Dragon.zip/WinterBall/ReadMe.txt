+++ WINTERBALL V1.0 +++
by Dark2Dragon

-------------
Controls:
Linke Pfeiltaste 	= links
Rechte Pfeiltaste 	= recths
Pause			= pause
esc			= beenden

-------------
Bonus (Symbol in gr�ner Box):
Blaue Pfeile nach au�en = Spieler vergr��ern
Rote Pfeile nach innen	= Spielder verkleinern
Ball mit blauem Pfeil	= Ballgeschwindigkeit vergr��ern
Ball mit rotem Pfeil	= Ballgeschwindigkeit verringern
1up			= +1 Leben

-------------
Graphics by
Dark2Dragon

-------------
Sounds & Music by
www.soundjay.com
www.flashkit.com