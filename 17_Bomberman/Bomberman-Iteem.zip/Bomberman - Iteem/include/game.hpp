#ifndef GAME_HPP_INCLUDED
#define GAME_HPP_INCLUDED

class Game
{
    public:
        Game();
        ~Game();

        int run(void);
};

#endif // GAME_HPP_INCLUDED
