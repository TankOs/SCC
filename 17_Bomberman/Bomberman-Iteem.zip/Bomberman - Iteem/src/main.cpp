#include "game.hpp"

int main(void)
{
    Game game;
    return game.run();
}
