#ifndef __LMENU_H__
#define __LMENU_H__

#include <SFML/Graphics.hpp>

#include <list>

namespace l
{
	class menu
	{
		private:
			sf::Image my_background_image;
			unsigned int my_xpos, my_ypos;
			std::list<menu*> my_submenus;
			std::string my_identifier;
			bool my_isvisible;
			bool my_isactive;
		public:
			menu()
			{
				my_isactive = false;
				my_isvisible = false;
				my_submenus.clear();
			}
			void set_position(unsigned int xpos, unsigned int ypos)
			{
				my_xpos = xpos;
				my_ypos = ypos;
			}
			void set_background(sf::Image &background_image)
			{
				my_background_image = background_image;
			}
			void set_visible(bool visible)
			{
				my_isvisible = visible;
			}
			bool is_visible()
			{
				return my_isvisible;
			}
			bool is_active()
			{
				return my_isactive;
			}
			void keypress(unsigned int keycode)
			{
			}
			void set_active(bool active)
			{
				/* deactivate all submenus */
				for(std::list<menu*>::iterator it=my_submenus.begin();it!=my_submenus.end();it++)
				{
					(*it)->set_active(false);
				}
				my_isactive = active;
			}
			void set_active(std::string identifier)
			{
				if(identifier == my_identifier)
				{
					my_isactive = true;
				}
				else
				{
					my_isactive = false;
					for(std::list<menu*>::iterator it=my_submenus.begin();it!=my_submenus.end();it++)
					{
						(*it)->set_active(identifier);
					}
				}
			}
			void set_identifier(std::string identifier)
			{
				my_identifier = identifier;
			}
			std::string get_identifier()
			{
				return my_identifier;
			}
			bool add_submenu(menu *menu)
			{
				if(NULL == menu)
				{
					return false;
				}
				my_submenus.push_back(menu);
				return true;
			}
			void draw(sf::RenderWindow &Window)
			{
				if(Window.IsOpened())
				{
					if(my_isactive)
					{
						sf::Sprite rendersprite;
						rendersprite.SetImage(my_background_image);
						rendersprite.SetPosition(my_xpos,my_ypos);
						Window.Draw(rendersprite);
					}
					else
					{
						for(std::list<menu*>::iterator it=my_submenus.begin();it!=my_submenus.end();it++)
						{
							if((*it)->is_active())
							{
								(*it)->draw(Window);
							}
						}
					}
				}
			}
	};
};

#endif

