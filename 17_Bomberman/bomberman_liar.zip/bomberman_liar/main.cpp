#include <iostream>

#include <SFML/Graphics.hpp>

#include "game.h"

int main(int argc, char *argv[])
{
	sf::RenderWindow Window;
	sf::Event Event;
	game boomberman;
	boomberman.load_map("data/map1.bmap");
	boomberman.add_player("data/player1.bpla");
	boomberman.add_player("data/player2.bpla");
	/*
	l::menu menu;
	menu.set_identifier("mainmenu");
	menu.set_active(true);
	menu.set_position(100,100);*/
	//menu.set_background(test);
	Window.Create(sf::VideoMode(640,480,32),"BOOMBERMAN");
	Window.SetFramerateLimit(60);
	while(Window.IsOpened())
	{
		while(Window.GetEvent(Event))
		{
			if(sf::Event::Closed == Event.Type)
			{
				exit(0); /* workaround, sfml2 behaves gay */
				Window.Close();
			}
			if(sf::Event::KeyPressed == Event.Type)
			{
				if(sf::Key::Escape == Event.Key.Code)
				{
					exit(0); /* workaround, sfml2 behaves gay */
					Window.Close();
				}
				else
				{
					boomberman.keypress(Event.Key.Code);
					//menu.keypress(Event.Key.Code);
				}
			}
		}

		Window.Clear();
		//menu.draw(Window);
		boomberman.draw(Window);
		Window.Display();
	}
	Window.Close();
	return 0;
}

