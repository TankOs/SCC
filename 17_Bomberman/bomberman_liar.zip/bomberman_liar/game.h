
#ifndef __GAME_H__
#define __GAME_H__

#include <list>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>

#include <SFML/Graphics.hpp>

std::vector<std::string> split_string_delim(std::string str, char delimiter)
{
	std::vector<std::string> result;
	std::string token;
	std::stringstream strstream(str);
	while(getline(strstream,token,delimiter))
	{
		result.push_back(token);
	}
	return result;
}

std::vector<std::string> split_string(std::string str)
{
	std::vector<std::string> result;
	std::vector<std::string> tmp_split = split_string_delim(str,'\n');
	/* wow... i want c++0x lambda's for this: */
	for(std::vector<std::string>::iterator it=tmp_split.begin();it!=tmp_split.end();it++)
	{
		std::vector<std::string> tmp_split_second = split_string_delim(*it,'\t');
		for(std::vector<std::string>::iterator it2=tmp_split_second.begin();it2!=tmp_split_second.end();it2++)
		{
			std::vector<std::string> tmp_split_third = split_string_delim(*it,' ');
			result.insert(result.end(),tmp_split_third.begin(),tmp_split_third.end());
		}
	}
	return result;
}

class animation
{
	private:
		std::vector<sf::Image*> my_images;
		sf::Sprite my_sprite;
		unsigned int my_current_image;
		unsigned int my_x, my_y;
		sf::Color my_transparency_color;
	public:
		animation() : my_current_image(0), my_x(0), my_y(0), my_transparency_color(255,255,255) {}
		unsigned int get_xsize()
		{
			if(my_images.size() == 0) return 0;
			return my_images[my_current_image]->GetWidth();
		}
		unsigned int get_ysize()
		{
			if(my_images.size() == 0) return 0;
			return my_images[my_current_image]->GetHeight();
		}
		unsigned int get_xpos()
		{
			return my_x;
		}
		unsigned int get_ypos()
		{
			return my_y;
		}
		void next_image()
		{
			my_current_image++;
			if(my_current_image >= my_images.size())
			{
				my_current_image = 0;
			}
		}
		void load_animation(std::vector<std::string> file_names)
		{
			for(std::vector<std::string>::iterator it=file_names.begin();it!=file_names.end();it++)
			{
				sf::Image *image = new sf::Image;
				image->LoadFromFile(*it);
				my_images.push_back(image);
			}
			my_current_image = 0;
		}
		void set_transparency_color(sf::Color color)
		{
			my_transparency_color = color;
		}
		void set_xy(unsigned int x, unsigned int y)
		{
			my_x = x;
			my_y = y;
		}
		virtual void draw(sf::RenderWindow &Window)
		{
			if(my_images.size() <= 0) return;
			my_images[my_current_image]->CreateMaskFromColor(my_transparency_color);
			my_sprite.SetImage(*my_images[my_current_image]);
			my_sprite.SetX(my_x);
			my_sprite.SetY(my_y);
			Window.Draw(my_sprite);
		}
};

class timed_animation : public animation
{
	private:
		sf::Clock my_clock;
		float my_animation_delay;
	public:
		timed_animation() : my_animation_delay(0)
		{
			my_clock.Reset();
		}
		void set_animation_delay(float delay)
		{
			my_animation_delay = delay;
		}
		void draw(sf::RenderWindow &Window)
		{
			if(my_clock.GetElapsedTime() >= my_animation_delay)
			{
				next_image();
				my_clock.Reset();
			}
			animation::draw(Window);
		}
};

enum dir
{
	LEFT = 0,
	RIGHT,
	DOWN,
	UP,
};

class map;
class player;

class bomb
{
	private:
		timed_animation my_animation;
		timed_animation my_explode_animation;
		unsigned int my_fields_to_destroy;
		float my_explode_time;
		float my_duration_time;
		sf::Clock my_explode_timer;
		unsigned int my_xpos, my_ypos;
	public:
		bomb() : my_explode_time(0), my_fields_to_destroy(0), my_xpos(0), my_ypos(0) {}
		void load_animation(std::vector<std::string> file_names, float delay = 0)
		{
			my_animation.load_animation(file_names);
			my_animation.set_animation_delay(delay);
		}
		void load_explode_animation(std::vector<std::string> file_names, float delay = 0)
		{
			my_explode_animation.load_animation(file_names);
			my_explode_animation.set_animation_delay(delay);
		}
		void reset()
		{
			my_explode_timer.Reset();
		}
		bool expired()
		{
			return (my_explode_timer.GetElapsedTime() >= my_explode_time + my_duration_time);
		}
		unsigned int get_xpos()
		{
			return my_xpos;
		}
		unsigned int get_ypos()
		{
			return my_ypos;
		}
		unsigned int get_xsize()
		{
			return my_animation.get_xsize();
		}
		unsigned int get_ysize()
		{
			return my_animation.get_ysize();
		}
		bool is_exploding()
		{
			if(!expired())
			{
				if(my_explode_timer.GetElapsedTime() >= my_explode_time)
				{
					return true;
				}
			}
			return false;
		}
		void set_xy(unsigned int x, unsigned int y)
		{
			my_xpos = x;
			my_ypos = y;
		}
		void set_duration_time(float duration_time)
		{
			my_duration_time = duration_time;
		}
		void set_explode_time(float explode_time)
		{
			my_explode_time = explode_time;
		}
		void set_fields_to_destroy(unsigned int fields)
		{
			my_fields_to_destroy = fields;
		}
		void render_and_draw(sf::RenderWindow &Window, std::vector<player*> &players, map &gamemap);
};

class player
{
	private:
		animation my_animation_left;
		animation my_animation_right;
		animation my_animation_down;
		animation my_animation_up;
		timed_animation my_dying_animation;
		bomb my_bomb;
		bool my_is_dead;
		unsigned int my_xpos, my_ypos;
		unsigned int my_xsize, my_ysize;
		unsigned int my_x_movement_pixels, my_y_movement_pixels;
		unsigned int my_left_key, my_right_key, my_down_key, my_up_key, my_place_bomb_key;
		sf::Clock my_input_clock;
		dir my_direction;
	public:
		player() : my_xpos(50), my_ypos(50), my_direction(LEFT), my_left_key('a'), my_right_key('d'), my_down_key('s'), my_up_key('w'), my_place_bomb_key('f'), my_is_dead(false)
		{
			my_input_clock.Reset();
		}
		bool is_dead()
		{
			return my_is_dead;
		}
		unsigned int get_xpos()
		{
			return my_xpos;
		}
		unsigned int get_ypos()
		{
			return my_ypos;
		}
		unsigned int get_xsize()
		{
			return my_xsize;
		}
		unsigned int get_ysize()
		{
			return my_ysize;
		}
		unsigned int get_xmov()
		{
			return my_x_movement_pixels;
		}
		unsigned int get_ymov()
		{
			return my_y_movement_pixels;
		}
		void hit(unsigned int xpos, unsigned int ypos, unsigned int xpos2, unsigned int ypos2)
		{
			#ifndef WINSFML16
			sf::Rect<unsigned int> rect(xpos, ypos, xpos2-xpos, ypos2-ypos);
			sf::Rect<unsigned int> player_rect(my_xpos,my_ypos,my_xsize,my_ysize);
			#else
			sf::Rect<unsigned int> rect(xpos, ypos, xpos2, ypos2);
			sf::Rect<unsigned int> player_rect(my_xpos,my_ypos,my_xsize+my_xpos,my_ysize+my_ypos);
			#endif
			if(rect.Intersects(player_rect))
			{
				my_is_dead = true;
			}
		}
		void place_bomb(map *game_map);/*
		{
			my_bomb.Reset();
			game_map->add_bomb(&my_bomb);
		}*/
		float get_input_elapsed_time()
		{
			return my_input_clock.GetElapsedTime();
		}
		unsigned int get_left_key()
		{
			return my_left_key;
		}
		unsigned int get_right_key()
		{
			return my_right_key;
		}
		unsigned int get_down_key()
		{
			return my_down_key;
		}
		unsigned int get_up_key()
		{
			return my_up_key;
		}
		unsigned int get_place_bomb_key()
		{
			return my_place_bomb_key;
		}
		void load_from_file(std::string file_name)
		{
			std::ifstream playerin;
			std::string line;
			bool not_handled = true;
			playerin.open(file_name.c_str(),std::ios::in);
			if(playerin.is_open())
			{
				while(getline(playerin,line))
				{
					not_handled = true;
					std::vector<std::string> tokenized_line = split_string(line);
					if(not_handled) if(tokenized_line.size() == 3)
					{
						if("set_movement_pixels" == tokenized_line[0])
						{
							std::stringstream x_movement_stream(tokenized_line[1]);
							std::stringstream y_movement_stream(tokenized_line[2]);
							x_movement_stream >> my_x_movement_pixels;
							y_movement_stream >> my_y_movement_pixels;
							not_handled = false;
						}
					}
					if(not_handled) if(tokenized_line.size() == 2)
					{
						if("set_left_key" == tokenized_line[0])
						{
							my_left_key = tokenized_line[1][0];
							not_handled = false;
						}
						else if("set_right_key" == tokenized_line[0])
						{
							my_right_key = tokenized_line[1][0];
							not_handled = false;
						}
						else if("set_down_key" == tokenized_line[0])
						{
							my_down_key = tokenized_line[1][0];
							not_handled = false;
						}
						else if("set_up_key" == tokenized_line[0])
						{
							my_up_key = tokenized_line[1][0];
							not_handled = false;
						}
						else if("set_place_bomb_key" == tokenized_line[0])
						{
							my_place_bomb_key = tokenized_line[1][0];
							not_handled = false;
						}
						else if("set_default_bomb_explode_time" == tokenized_line[0])
						{
							float explode_time;
							std::stringstream explode_time_stream(tokenized_line[1]);
							explode_time_stream >> explode_time;
							my_bomb.set_explode_time(explode_time);
							not_handled = false;
						}
						else if("set_default_bomb_duration_time" == tokenized_line[0])
						{
							float duration_time;
							std::stringstream duration_time_stream(tokenized_line[1]);
							duration_time_stream >> duration_time;
							my_bomb.set_duration_time(duration_time);
							not_handled = false;
						}
						else if("bomb_set_fields_to_destroy" == tokenized_line[0])
						{
							unsigned int fields = 0;
							std::stringstream bomb_fields_to_dest_stream(tokenized_line[1]);
							bomb_fields_to_dest_stream >> fields;
							my_bomb.set_fields_to_destroy(fields);
						}
					}
					if(not_handled) if(tokenized_line.size() == 3)
					{
						if("set_start_xy" == tokenized_line[0])
						{
							unsigned int x=0, y=0;
							std::stringstream strx(tokenized_line[1]), stry(tokenized_line[2]);
							strx >> x;
							stry >> y;
							my_xpos = x;
							my_ypos = y;
							not_handled = false;
						}
					}
					if(not_handled) if(tokenized_line.size() == 4)
					{
						if("set_transparency_color" == tokenized_line[0])
						{
							unsigned int R, G, B;
							std::stringstream color_stream(tokenized_line[1]);
							color_stream >> R;
							color_stream.clear();
							color_stream.str(tokenized_line[2]);
							color_stream >> G;
							color_stream.clear();
							color_stream.str(tokenized_line[3]);
							color_stream >> B;
							set_transparency_color(sf::Color(R,G,B));
							not_handled = false;
						}
					}
					if(not_handled) if(tokenized_line.size() >= 1)
					{
						if("animation_left" == tokenized_line[0])
						{
							std::vector<std::string> images;
							images.resize(tokenized_line.size()-1);
							std::copy(tokenized_line.begin()+1,tokenized_line.end(),images.begin());
							my_animation_left.load_animation(images);
							not_handled = false;
						}
						if("animation_right" == tokenized_line[0])
						{
							std::vector<std::string> images;
							images.resize(tokenized_line.size()-1);
							std::copy(tokenized_line.begin()+1,tokenized_line.end(),images.begin());
							my_animation_right.load_animation(images);
							not_handled = false;
						}
						if("animation_down" == tokenized_line[0])
						{
							std::vector<std::string> images;
							images.resize(tokenized_line.size()-1);
							std::copy(tokenized_line.begin()+1,tokenized_line.end(),images.begin());
							my_animation_down.load_animation(images);
							not_handled = false;
						}
						if("animation_up" == tokenized_line[0])
						{
							std::vector<std::string> images;
							images.resize(tokenized_line.size()-1);
							std::copy(tokenized_line.begin()+1,tokenized_line.end(),images.begin());
							my_animation_up.load_animation(images);
							not_handled = false;
						}
					}
					if(not_handled) if(tokenized_line.size() >= 4)
					{
						if("bomb" == tokenized_line[0])
						{
							std::vector<std::string> before_explode_images;
							std::vector<std::string> explode_images;
							std::vector<std::string>::iterator it;
							for(it=tokenized_line.begin()+1;it!=tokenized_line.end();it++)
							{
								if("explode" == *it)
								{
									it++;
									break;
								}
								else
								{
									before_explode_images.push_back(*it);
								}
							}
							while(it!=tokenized_line.end())
							{
								explode_images.push_back(*it);
								it++;
							}
							// TODO: make delay configurable:
							my_bomb.load_animation(before_explode_images,0.5f);
							my_bomb.load_explode_animation(explode_images,0.5f);
							not_handled = false;
						}
					}
				}
			}
			else
			{
				std::cerr << "unable to open the player file" << std::endl;
			}
			playerin.close();
		}
		void set_transparency_color(sf::Color color)
		{
			my_animation_left.set_transparency_color(color);
			my_animation_right.set_transparency_color(color);
			my_animation_down.set_transparency_color(color);
			my_animation_up.set_transparency_color(color);
		}
		void draw(sf::RenderWindow &Window)
		{
			my_animation_left.set_xy(my_xpos,my_ypos);
			my_animation_right.set_xy(my_xpos,my_ypos);
			my_animation_down.set_xy(my_xpos,my_ypos);
			my_animation_up.set_xy(my_xpos,my_ypos);
			if(LEFT == my_direction)
			{
				my_animation_left.draw(Window);
				my_xsize = my_animation_left.get_xsize();
				my_ysize = my_animation_left.get_ysize();
			}
			if(RIGHT == my_direction)
			{
				my_animation_right.draw(Window);
				my_xsize = my_animation_right.get_xsize();
				my_ysize = my_animation_right.get_ysize();
			}
			if(DOWN == my_direction)
			{
				my_animation_down.draw(Window);
				my_xsize = my_animation_down.get_xsize();
				my_ysize = my_animation_down.get_ysize();
			}
			if(UP == my_direction)
			{
				my_animation_up.draw(Window);
				my_xsize = my_animation_up.get_xsize();
				my_ysize = my_animation_up.get_ysize();
			}
		}
		void go_left()
		{
			my_direction = LEFT;
			my_animation_left.next_image();
			my_xpos -= my_x_movement_pixels;
			my_input_clock.Reset();
		}
		void go_right()
		{
			my_direction = RIGHT;
			my_animation_right.next_image();
			my_xpos += my_x_movement_pixels;
			my_input_clock.Reset();
		}
		void go_down()
		{
			my_direction = DOWN;
			my_animation_down.next_image();
			my_ypos += my_y_movement_pixels;
			my_input_clock.Reset();
		}
		void go_up()
		{
			my_direction = UP;
			my_animation_up.next_image();
			my_ypos -= my_y_movement_pixels;
			my_input_clock.Reset();
		}
};

class layer
{
	private:
		std::list<timed_animation*> my_animations;
	public:
		void clear()
		{
			my_animations.clear();
		}
		std::list<timed_animation*> *get_animations()
		{
			return &my_animations;
		}
		void add_animation(std::vector<std::string> file_names, unsigned int x, unsigned int y, float delay = 0)
		{
			timed_animation *anim = new timed_animation;
			anim->load_animation(file_names);
			anim->set_animation_delay(delay);
			anim->set_xy(x,y);
			my_animations.push_back(anim);
		}
		void set_transparency_color(sf::Color color)
		{
			for(std::list<timed_animation*>::iterator it=my_animations.begin();it!=my_animations.end();it++)
			{
				(*it)->set_transparency_color(color);
			}
		}
		void draw(sf::RenderWindow &Window)
		{
			for(std::list<timed_animation*>::iterator it=my_animations.begin();it!=my_animations.end();it++)
			{
				(*it)->draw(Window);
			}
		}
};

class map
{
	private:
		sf::Image my_background_image;
		sf::Sprite my_background_sprite;
		std::vector<layer*> my_layers;
		std::list<bomb*> my_bombs;
		unsigned int my_player_layer;
		sf::Color my_transparency_color;
		unsigned int my_bomb_layer;
	public:
		map() : my_player_layer(0), my_transparency_color(255,255,255) {}
		void load_background(std::string file_name)
		{
			my_background_image.LoadFromFile(file_name);
			my_background_sprite.SetImage(my_background_image);
		}
		void place_bomb(bomb *newbomb)
		{
			for(std::list<bomb*>::iterator it=my_bombs.begin();it!=my_bombs.end();it++)
			{
				if((*it) == newbomb)
				{
					return;
				}
			}
			my_bombs.push_back(newbomb);
		}
		void hit(unsigned int xpos, unsigned int ypos, unsigned int xpos2, unsigned int ypos2)
		{
			#ifndef WINSFML16
			sf::Rect<unsigned int> rect(xpos,ypos,xpos2-xpos,ypos2-ypos);
			#else
			sf::Rect<unsigned int> rect(xpos,ypos,xpos2,ypos2);
			#endif
			if(my_bomb_layer < my_layers.size())
			{
				if(my_layers[my_bomb_layer])
				{
					bool found = true;
					std::list<timed_animation*> *animations = my_layers[my_bomb_layer]->get_animations();
					while(found)
					{
						found = false;
						for(std::list<timed_animation*>::iterator it=animations->begin();it!=animations->end();it++)
						{
							#ifndef WINSFML16
							sf::Rect<unsigned int> anim_rect((*it)->get_xpos(),(*it)->get_ypos(),(*it)->get_xsize(),(*it)->get_ysize());
							#else
							sf::Rect<unsigned int> anim_rect((*it)->get_xpos(),(*it)->get_ypos(),(*it)->get_xsize()+(*it)->get_xpos(),(*it)->get_ysize()+(*it)->get_ypos());
							#endif
							if(anim_rect.Intersects(rect))
							{
								animations->erase(it);
								found = true;
								break;
							}
						}
					}
				}
			}
		}
		bool goable(unsigned int xpos, unsigned int ypos, unsigned int xsize, unsigned int ysize)
		{
			unsigned layer_id = my_player_layer;
			#ifndef WINSFML16
			sf::Rect<unsigned int> rect(xpos,ypos,xsize,ysize);
			#else
			sf::Rect<unsigned int> rect(xpos,ypos,xsize+xpos,ysize+ypos);
			#endif
			for(std::list<bomb*>::iterator it=my_bombs.begin();it!=my_bombs.end();it++)
			{
				#ifndef WINSFML16
				sf::Rect<unsigned int> bomb_rect((*it)->get_xpos(),(*it)->get_ypos(),(*it)->get_xsize(),(*it)->get_ysize());
				#else
				sf::Rect<unsigned int> bomb_rect((*it)->get_xpos(),(*it)->get_ypos(),(*it)->get_xsize()+(*it)->get_xpos(),(*it)->get_ysize()+(*it)->get_ypos());
				#endif
				if(bomb_rect.Intersects(rect))
				{
					if(!(*it)->expired() && !(*it)->is_exploding())
					{
						return false;
					}
				}
			}
			for(unsigned int i=layer_id;i<my_layers.size();i++)
			{
				if(!my_layers[i]) continue;
				std::list<timed_animation*> *animations = my_layers[i]->get_animations();
				for(std::list<timed_animation*>::iterator it=animations->begin();it!=animations->end();it++)
				{
					#ifndef WINSFML16
					sf::Rect<unsigned int> layer_rect((*it)->get_xpos(),(*it)->get_ypos(),(*it)->get_xsize(),(*it)->get_ysize());
					#else
					sf::Rect<unsigned int> layer_rect((*it)->get_xpos(),(*it)->get_ypos(),(*it)->get_xpos()+(*it)->get_xsize(),(*it)->get_ypos()+(*it)->get_ysize());
					#endif
					if(layer_rect.Intersects(rect))
					{
						return false;
					}
				}
			}
			return true;
		}
		void load_from_file(std::string file_name)
		{
			std::string line;
			std::ifstream mapin;

			my_layers.clear();

			mapin.open(file_name.c_str(),std::ios::in);
			if(mapin.is_open())
			{
				while(getline(mapin,line))
				{
					std::vector<std::string> tokenized_line = split_string(line);
					if(tokenized_line.size() == 2)
					{
						if("background" == tokenized_line[0])
						{
							load_background(tokenized_line[1]);
						}
						else if("set_player_layer" == tokenized_line[0])
						{
							std::stringstream player_layer_stream(tokenized_line[1]);
							player_layer_stream >> my_player_layer;
						}
						else if("set_bomb_layer" == tokenized_line[0])
						{
							std::stringstream bomb_layer_stream(tokenized_line[1]);
							bomb_layer_stream >> my_bomb_layer;
						}
					}
					else if(tokenized_line.size() == 4)
					{
						if("set_transparency_color" == tokenized_line[0])
						{
							unsigned int R, G, B;
							std::stringstream color_stream(tokenized_line[1]);
							color_stream >> R;
							color_stream.clear();
							color_stream.str(tokenized_line[2]);
							color_stream >> G;
							color_stream.clear();
							color_stream.str(tokenized_line[3]);
							color_stream >> B;
							my_transparency_color = sf::Color(R,G,B);
						}
					}
					else if(tokenized_line.size() >= 6)
					{
						if("layer_animation" == tokenized_line[0])
						{
							unsigned int layer_id = 0;
							float time_delay = 0;
							unsigned int x=0, y=0;
							std::vector<std::string> images;
							std::stringstream layer_id_stream(tokenized_line[1]);
							std::stringstream time_delay_stream(tokenized_line[2]);
							std::stringstream x_stream(tokenized_line[3]);
							std::stringstream y_stream(tokenized_line[4]);
							layer_id_stream >> layer_id;
							time_delay_stream >> time_delay;
							x_stream >> x;
							y_stream >> y;
							images.resize(tokenized_line.size()-5);
							std::copy(tokenized_line.begin()+5,tokenized_line.end(),images.begin());
							if(my_layers.size() <= layer_id)
							{
								my_layers.resize(layer_id+1);
							}
							if(!my_layers[layer_id])
							{
								my_layers[layer_id] = new layer;
							}
							my_layers[layer_id]->add_animation(images,x,y,time_delay);
							my_layers[layer_id]->set_transparency_color(my_transparency_color);
						}
					}
				}
			}
			else
			{
				std::cerr << "unable to open the map file" << std::endl;
			}
			mapin.close();
		}
		void render_and_draw(sf::RenderWindow &Window, std::vector<player*> &players, map &gamemap)
		{
			my_background_sprite.SetImage(my_background_image);
			Window.Draw(my_background_sprite);
			for(unsigned int i=0;i<my_layers.size();i++)
			{
				if(my_layers[i])
				{
					my_layers[i]->draw(Window);
				}
				if(my_bomb_layer == i)
				{
					for(std::list<bomb*>::iterator it=my_bombs.begin();it!=my_bombs.end();it++)
					{
						if(!(*it)->expired())
						{
							(*it)->render_and_draw(Window,players,gamemap);
						}
					}
				}
			}
		}
};

void player::place_bomb(map *game_map)
{
	my_bomb.reset();
	if(LEFT == my_direction)
	{
		my_bomb.set_xy(my_xpos-my_xsize, my_ypos);
	}
	if(RIGHT == my_direction)
	{
		my_bomb.set_xy(my_xpos+my_xsize, my_ypos);
	}
	if(DOWN == my_direction)
	{
		my_bomb.set_xy(my_xpos, my_ypos+my_ysize);
	}
	if(UP == my_direction)
	{
		my_bomb.set_xy(my_xpos, my_ypos-my_ysize);
	}
	game_map->place_bomb(&my_bomb);
}

void bomb::render_and_draw(sf::RenderWindow &Window, std::vector<player*> &players, map &gamemap)
{
	if(my_explode_timer.GetElapsedTime() >= my_explode_time)
	{
		my_explode_animation.set_xy(my_xpos,my_ypos);
		my_explode_animation.draw(Window);
		for(unsigned int j=0;j<players.size();j++)
		{
			players[j]->hit(my_xpos,my_ypos,my_xpos+my_explode_animation.get_xsize(),my_ypos+my_explode_animation.get_ysize());
			gamemap.hit(my_xpos,my_ypos,my_xpos+my_explode_animation.get_xsize(),my_ypos+my_explode_animation.get_ysize());
		}
		for(unsigned int i=0;i<my_fields_to_destroy;i++)
		{
			my_explode_animation.set_xy(my_xpos+(i+1)*my_explode_animation.get_xsize(),my_ypos);
			my_explode_animation.draw(Window);
			my_explode_animation.set_xy(my_xpos-(i+1)*my_explode_animation.get_xsize(),my_ypos);
			my_explode_animation.draw(Window);
			my_explode_animation.set_xy(my_xpos,my_ypos+(i+1)*my_explode_animation.get_ysize());
			my_explode_animation.draw(Window);
			my_explode_animation.set_xy(my_xpos,my_ypos-(i+1)*my_explode_animation.get_ysize());
			my_explode_animation.draw(Window);
			for(unsigned int j=0;j<players.size();j++)
			{
				players[j]->hit(my_xpos+(i+1)*my_explode_animation.get_xsize(),my_ypos,my_xpos+(i+2)*my_explode_animation.get_xsize(),my_ypos+my_explode_animation.get_ysize());
				gamemap.hit(my_xpos+(i+1)*my_explode_animation.get_xsize(),my_ypos,my_xpos+(i+2)*my_explode_animation.get_xsize(),my_ypos+my_explode_animation.get_ysize());
				players[j]->hit(my_xpos-(i+1)*my_explode_animation.get_xsize(),my_ypos,my_xpos-(i)*my_explode_animation.get_xsize(),my_ypos+my_explode_animation.get_ysize());
				gamemap.hit(my_xpos-(i+1)*my_explode_animation.get_xsize(),my_ypos,my_xpos-(i)*my_explode_animation.get_xsize(),my_ypos+my_explode_animation.get_ysize());
				players[j]->hit(my_xpos,my_ypos+(i+1)*my_explode_animation.get_ysize(),my_xpos+my_explode_animation.get_xsize(),my_ypos+(i+2)*my_explode_animation.get_ysize());
				gamemap.hit(my_xpos,my_ypos+(i+1)*my_explode_animation.get_ysize(),my_xpos+my_explode_animation.get_xsize(),my_ypos+(i+2)*my_explode_animation.get_ysize());
				players[j]->hit(my_xpos,my_ypos-(i+1)*my_explode_animation.get_ysize(),my_xpos+my_explode_animation.get_xsize(),my_ypos-(i)*my_explode_animation.get_ysize());
				gamemap.hit(my_xpos,my_ypos-(i+1)*my_explode_animation.get_ysize(),my_xpos+my_explode_animation.get_xsize(),my_ypos-(i)*my_explode_animation.get_ysize());
			}
		}
	}
	else
	{
		my_animation.set_xy(my_xpos,my_ypos);
		my_animation.draw(Window);
	}
}

class game
{
	private:
		std::vector<player*> my_players;
		std::vector<unsigned int> my_input;
		map my_map;
	public:
		game(){}
		~game(){}
		void add_player(std::string file_name)
		{
			player *play = new player;
			play->load_from_file(file_name);
			my_players.push_back(play);
		}
		void load_map(std::string file_name)
		{
			my_map.load_from_file(file_name);
		}
		void keypress(unsigned int keycode)
		{
			for(unsigned int i=0;i<my_input.size();i++)
			{
				if(my_input[i] == keycode)
				{
					return;
				}
			}
			my_input.push_back(keycode);
		}
		void draw(sf::RenderWindow &Window)
		{
			for(unsigned int i=0;i<my_input.size();i++)
			{
				for(unsigned int j=0;j<my_players.size();j++)
				{
					if(my_players[j]->is_dead()) continue;
					if(my_players[j]->get_input_elapsed_time() >= 0.1)
					{
						if(my_input[i] == my_players[j]->get_left_key())
						{
							if(my_map.goable(my_players[j]->get_xpos()-my_players[j]->get_xmov(),my_players[j]->get_ypos(),my_players[j]->get_xsize(),my_players[j]->get_ysize()))
							{
								my_players[j]->go_left();
							}
						}
						if(my_input[i] == my_players[j]->get_right_key())
						{
							if(my_map.goable(my_players[j]->get_xpos()+my_players[j]->get_xmov(),my_players[j]->get_ypos(),my_players[j]->get_xsize(),my_players[j]->get_ysize()))
							{
								my_players[j]->go_right();
							}
						}
						if(my_input[i] == my_players[j]->get_down_key())
						{
							if(my_map.goable(my_players[j]->get_xpos(),my_players[j]->get_ypos()+my_players[j]->get_ymov(),my_players[j]->get_xsize(),my_players[j]->get_ysize()))
							{
								my_players[j]->go_down();
							}
						}
						if(my_input[i] == my_players[j]->get_up_key())
						{
							if(my_map.goable(my_players[j]->get_xpos(),my_players[j]->get_ypos()-my_players[j]->get_ymov(),my_players[j]->get_xsize(),my_players[j]->get_ysize()))
							{
								my_players[j]->go_up();
							}
						}
						if(my_input[i] == my_players[j]->get_place_bomb_key())
						{
							my_players[j]->place_bomb(&my_map);
						}
					}
				}
			}
			my_input.clear();
			my_map.render_and_draw(Window,my_players,my_map);
			unsigned int alive_players = 0;
			for(unsigned int i=0;i<my_players.size();i++)
			{
				if(my_players[i])
				{
					if(!my_players[i]->is_dead())
					{
						my_players[i]->draw(Window);
						alive_players++;
					}
				}
			}
			if(alive_players <= 1)
			{
#ifdef WINSFML16
				sf::String game_finished("Game Over");
#else
				sf::Text game_finished("Game Over");
#endif
				sf::Sprite strsprite;
				game_finished.SetColor(sf::Color(255,0,255));
				game_finished.SetX(200);
				game_finished.SetY(200);
				Window.Draw(game_finished);
			}
		}
		
};

#endif

