#include "objects.h"

GoodObject::GoodObject(int y, int maxY)
{
    active = true;
    points = sf::Randomizer::Random(4, 6);
    position = sf::Vector2f(sf::Randomizer::Random(500, maxY), y);
    sprite = sf::Sprite();
    sprite.SetImage(image);
    sprite.SetPosition(position);
    sprite.SetRotation(0);
    sprite.SetSubRect(sf::IntRect(0, 0, 20, 20));
}

BadObject::BadObject(int y, int maxY)
{
    active = true;
    points = sf::Randomizer::Random(-10, -8);
    position = sf::Vector2f(sf::Randomizer::Random(500, maxY), y);
    sprite = sf::Sprite();
    sprite.SetImage(image);
    sprite.SetCenter(0, 0);
    sprite.SetPosition(position);
    sprite.SetRotation(0);
    sprite.SetSubRect(sf::IntRect(0, 0, 20, 20));
}