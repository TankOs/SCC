#include "game.h"

#include <sstream>

Game myGame;

int main()
{
    myGame.myWindow.Create(myGame.myVideoMode, "Jump'n'Run", sf::Style::Fullscreen, myGame.mySettings);

    while(myGame.myWindow.IsOpened())
    {
	myGame.getInput();
	myGame.getInput2();
	myGame.checkCollisions();
	myGame.update();

	if((-myGame.backgroundPos)+myGame.player.GetPosition().x >= myGame.endPos)
	{
	    myGame.finish = true;
	    std::ostringstream str;
	    if(myGame.points <= 0)
	    {
		str<<"Verloren mit "<<myGame.points<<" Punkten\nBen�tigte Zeit: "<<(int)myGame.clk.GetElapsedTime()<<" Sekunden\nSpiel startet in 5 Sekunden neu";
	    }
	    else
	    {
		str<<"Gewonnen mit "<<myGame.points<<" Punkten\nBen�tigte Zeit: "<<(int)myGame.clk.GetElapsedTime()<<" Sekunden\nSpiel startet in 5 Sekunden neu";
	    }
	    myGame.string.SetText(str.str());

	    sf::Clock clk;
	    clk.Reset();

	    while(myGame.myWindow.IsOpened())
	    {
		myGame.getInput();
		myGame.update();

		if(clk.GetElapsedTime() >= 5)
		    break;
	    }
	    myGame.music.Stop();
	    myGame.myWindow.Close();
	    myGame.reset();

	    return main();
	}
    }

    return 0;
}