#include "game.h"
#include <sstream>

Game::Game()
{
    reset();
}

void Game::reset()
{
    screen = sf::Vector2i(800, 600);
    mySettings = sf::WindowSettings(32, 0, 0);
    myVideoMode = sf::VideoMode(screen.x, screen.y, 32);
    myWindow.UseVerticalSync(true);

    falling = false;
    finish = false;
    points = 0;
    endPos = 7500;
    jumpSpeedUp = 0.09;
    jumpSpeedDown = 0.05;
    maxJump = 70;
    backgroundPos = 0;
    leftSpeed = 0.06;
    rightSpeed = 0.1;

    buffer.LoadFromFile("audio\\music.ogg");
    music.SetBuffer(buffer);
    music.SetLoop(true);
    music.Play();
    font.LoadFromFile("arial.ttf", 24);
    string = sf::String("", font);
    string.SetColor(sf::Color(255, 130, 30, 255));

    distance = sf::Sprite();
    distance.SetColor(sf::Color::Blue);
    distance.SetCenter(0, 0);
    distance.SetPosition(0, 0);
    distance.SetRotation(0);
    distance.SetSubRect(sf::IntRect(0, 0, 0, 0));

    backgroundImg.LoadFromFile("img\\background.jpg");
    background.SetCenter(0, 0);
    background.SetImage(backgroundImg);
    background.SetPosition(0, 0);
    background.SetRotation(0);

    startPoint = sf::Sprite();
    startPoint.SetColor(sf::Color(0, 0, 0, 220));
    startPoint.SetCenter(0, 0);
    startPoint.SetPosition((screen.x/2)-(16.5), 400);
    startPoint.SetRotation(0);
    startPoint.SetSubRect(sf::IntRect(0, 0, 4, 200));

    endPoint = sf::Sprite();
    endPoint.SetColor(sf::Color(255, 255, 0, 220));
    endPoint.SetCenter(0, 0);
    endPoint.SetPosition(endPos, 400);
    endPoint.SetRotation(0);
    endPoint.SetSubRect(sf::IntRect(0, 0, (screen.x/2)+25, 200));

    playerImgL.LoadFromFile("img\\player_l.png");
    playerImgR.LoadFromFile("img\\player_r.png");
    goodImg.LoadFromFile("img\\good.png");
    badImg.LoadFromFile("img\\bad.png");
    player = sf::Sprite();
    player.SetImage(playerImgR);
    player.SetPosition((screen.x/2)-(12.5), screen.y-50);
    player.SetRotation(0);
    player.SetSubRect(sf::IntRect(0, 0, 25, 50));

    for(int i = 0;i < 33;i++)
	badObjectListe.push_back(BadObject(screen.y-20, endPos-50));
    for(int i = 0;i < 33;i++)
	goodObjectListe.push_back(GoodObject(screen.y-20, endPos-50));

    for(int i = 0;i < badObjectListe.size();i++)
    {
	badObjectListe.at(i).sprite.SetImage(badImg);
    }
    for(int i = 0;i < goodObjectListe.size();i++)
    {
	goodObjectListe.at(i).sprite.SetImage(goodImg);
    }

    clk.Reset();
}

void Game::update()
{
    distance.SetSubRect(sf::IntRect(0, 0, (int)(screen.x/100*((-backgroundPos)/(endPos-player.GetPosition().x)*100)), 100));

    myWindow.Clear();

    myWindow.Draw(background);

    if(!allObjectsHidden())
    {
	for(int i = 0;i < goodObjectListe.size();i++)
	{
	    if(goodObjectListe.at(i).active == true && goodObjectListe.at(i).sprite.GetPosition().x+goodObjectListe.at(i).sprite.GetSize().x > 0)
		myWindow.Draw(goodObjectListe.at(i).sprite);
	}
	for(int i = 0;i < badObjectListe.size();i++)
	{
	    if(badObjectListe.at(i).active == true && badObjectListe.at(i).sprite.GetPosition().x+badObjectListe.at(i).sprite.GetSize().x > 0)
		myWindow.Draw(badObjectListe.at(i).sprite);
	}
    }

    if(myWindow.GetInput().IsKeyDown(sf::Key::Up) && !falling)
    {
	if(player.GetPosition().y+50 > screen.y-maxJump)
	{
	    player.SetPosition(player.GetPosition().x, player.GetPosition().y-jumpSpeedUp);
	    falling = false;
	}
	if(player.GetPosition().y+50 <= screen.y-maxJump)
	    falling = true;
    }
    else if(player.GetPosition().y+50 < screen.y)
    {
	falling = true;
    }
    if(falling)
    {
	if(player.GetPosition().y+50 < screen.y)
	    player.SetPosition(player.GetPosition().x, player.GetPosition().y+jumpSpeedDown);
	else
	    falling = false;
    }

    if(!finish)
    {
	std::ostringstream str;
	str<<"Punkte: "<<points<<"\n"<<(int)((-backgroundPos)/(endPos-player.GetPosition().x)*100)<<"%\n"<<(int)clk.GetElapsedTime()<<" Sekunden";
	string.SetText(str.str());
    }

    myWindow.Draw(startPoint);
    myWindow.Draw(endPoint);
    myWindow.Draw(player);
    myWindow.Draw(distance);
    myWindow.Draw(string);
    myWindow.Display();
}

void Game::changePositions()
{
    for(int i = 0;i < goodObjectListe.size();i++)
    {
	goodObjectListe.at(i).sprite.SetPosition(goodObjectListe.at(i).position.x+backgroundPos, goodObjectListe.at(i).position.y);
    }
    for(int i = 0;i < badObjectListe.size();i++)
    {
	badObjectListe.at(i).sprite.SetPosition(badObjectListe.at(i).position.x+backgroundPos, badObjectListe.at(i).position.y);
    }
    startPoint.SetPosition((screen.x/2)-(16.5)+backgroundPos, 400);
    endPoint.SetPosition(endPos+backgroundPos, 400);
}

void Game::updatePoints(int change)
{
    points+=change;
}

void Game::checkCollisions()
{
    for(int i = 0;i < goodObjectListe.size();i++)
    {
	if(goodObjectListe.at(i).active == true)
	{
	    if((player.GetPosition().x+25 >= goodObjectListe.at(i).sprite.GetPosition().x) && (player.GetPosition().x <= goodObjectListe.at(i).sprite.GetPosition().x+goodObjectListe.at(i).sprite.GetSize().x))
	    {
		if(player.GetPosition().y+50 >= screen.y-goodObjectListe.at(i).sprite.GetSize().y)
		{
		    goodObjectListe.at(i).active = false;
		    updatePoints(goodObjectListe.at(i).points);
		}
	    }
	}
    }
    for(int i = 0;i < badObjectListe.size();i++)
    {
	if(badObjectListe.at(i).active == true)
	{
	    if((player.GetPosition().x+25 >= badObjectListe.at(i).sprite.GetPosition().x) && (player.GetPosition().x <= badObjectListe.at(i).sprite.GetPosition().x+badObjectListe.at(i).sprite.GetSize().x))
	    {
		if(player.GetPosition().y+50 >= screen.y-badObjectListe.at(i).sprite.GetSize().y)
		{
		    badObjectListe.at(i).active = false;
		    updatePoints(badObjectListe.at(i).points);
		}
	    }
	}
    }
}

void Game::getInput()
{
    sf::Event event;
    myWindow.GetEvent(event);

    switch(event.Type)
    {
	default:
	{
	    break;
	}
	case sf::Event::Closed:
	{
	    myWindow.Close();
	    break;
	}
	case sf::Event::KeyPressed:
	{
	    switch(event.Key.Code)
	    {
		default:
		{
		    break;
		}
		case sf::Key::Escape:
		{
		    myWindow.Close();
		    break;
		}
	    }
	    break;
	}
    }
}

void Game::getInput2()
{
    if(myWindow.GetInput().IsKeyDown(sf::Key::Right))
    {
	player.SetImage(playerImgR);
	backgroundPos -= rightSpeed;
	changePositions();
    }
    if(myWindow.GetInput().IsKeyDown(sf::Key::Left))
    {
	player.SetImage(playerImgL);
	if(backgroundPos <= leftSpeed)
	{
	    backgroundPos += leftSpeed;
	    changePositions();
	}
    }
}

bool Game::allObjectsHidden()
{
    for(int i = 0;i < goodObjectListe.size();i++)
    {
	if(goodObjectListe.at(i).active == true)
	    return false;
    }
    for(int i = 0;i < badObjectListe.size();i++)
    {
	if(badObjectListe.at(i).active == true)
	    return false;
    }
    return true;
}