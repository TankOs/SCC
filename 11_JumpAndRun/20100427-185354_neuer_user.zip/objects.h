#ifndef OBJECTS_H
#define OBJECTS_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>

class Objects
{
public: sf::Image image;
public: sf::Sprite sprite;
public: sf::Vector2f position;
public: int points;
public: bool active;
};
class BadObject : public Objects
{
public:
    BadObject(int y, int maxY);
};
class GoodObject : public Objects
{
public:
    GoodObject(int y, int maxY);
};

#endif // OBJECTS_H
