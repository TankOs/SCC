#ifndef GAME_H
#define GAME_H

#include "objects.h"

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

class Game
{
private: sf::Vector2i screen;
private: sf::Image backgroundImg,playerImgL,playerImgR,goodImg,badImg;
private: sf::Sprite background,distance;
private: sf::SoundBuffer buffer;
private: sf::Font font;
private: std::vector<GoodObject> goodObjectListe;
private: std::vector<BadObject> badObjectListe;
private: sf::Sprite startPoint,endPoint;

private: bool falling;
private: float rightSpeed,leftSpeed,jumpSpeedUp,jumpSpeedDown;
private: int maxJump;

public: int points,endPos;
public: float backgroundPos;
public: bool finish;
public: sf::RenderWindow myWindow;
public: sf::WindowSettings mySettings;
public: sf::VideoMode myVideoMode;
public: sf::String string;
public: sf::Sprite player;
public: sf::Sound music;
public: sf::Clock clk;

public:
    Game();
public: void reset();
public: void update();
private: void updatePoints(int change);
public: void checkCollisions();
private: void changePositions();
public: void getInput();
public: void getInput2();
public: bool allObjectsHidden();
};

#endif // GAME_H
