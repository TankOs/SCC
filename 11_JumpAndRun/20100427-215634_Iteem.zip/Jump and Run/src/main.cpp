#include "game.h"

int main(void)
{
    Game myGame;
    return myGame.run();
}
