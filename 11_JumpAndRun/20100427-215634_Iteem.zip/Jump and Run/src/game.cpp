#include "game.h"

#include "menustate.h"
#include "gamestate.h"

Game::Game()
{
    sf::VideoMode VideoMode(800, 600, 32); //"Standart"-wert

    App.Create(VideoMode, "Jump and Run");
    App.UseVerticalSync(true);

    myState = new MenuState(App);
    myState->onEnter();
}

Game::~Game()
{
    delete myState;
}

int Game::run()
{
    while(true)
    {
        switch( myState->update() )
        {
            case State::NoChange:
                break;
            case State::Game:
                myState->onLeave();
                delete myState;
                myState = new GameState(App);
                myState->onEnter();
                break;
            case State::Menu:
                myState->onLeave();
                delete myState;
                myState = new MenuState(App);
                myState->onEnter();
                break;
            case State::Quit:
                myState->onLeave();
                return 0;
                break;
        }

        myState->draw();
    }

    return 0;
}
