#ifndef MAP_H_INCLUDED
#define MAP_H_INCLUDED

#include <string>
#include <SFML/Graphics.hpp>
#include <vector>

enum Collision
{
    Non,
    Good,
    Bad
};

class Map
{
    public:
        Map(const sf::String ImageName, sf::Vector2i TileDimension = sf::Vector2i(50,50));
        ~Map(){};
        bool LoadFromFile(const std::string &File);
        bool LoadFromString(const std::string &string, int MapWidth, int MapHeight);
        void SetViewCenter(sf::Vector2f Center);
        bool SetTileSet(const std::string &ImageName);
        void SetTileDimension(sf::Vector2i TileDimension);
        void Draw(sf::RenderTarget &RenderTarget);
        int TouchMap(sf::Vector2f);
    private:
        void ReloadSprites(void);
        std::vector< std::vector< char > > CharMap;
        std::vector< std::vector< sf::Sprite > > SpriteMap;
        sf::Vector2i TileDimension;
        sf::View View;
        sf::Image TileSet;
    public:
        sf::View GetView(void) {return View;};
};

#endif // MAP_H_INCLUDED
