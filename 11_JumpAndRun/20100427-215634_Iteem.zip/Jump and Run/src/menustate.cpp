#include <SFML/Graphics.hpp>

#include "menustate.h"

MenuState::MenuState(sf::RenderWindow &Window) :
State(Window)
{};

MenuState::~MenuState() {};

int MenuState::update()
{
    sf::Event Event;
    while(App.GetEvent(Event))
    {
        if(Event.Type == sf::Event::Closed)
            return State::Quit;
        if(Event.Type == sf::Event::KeyPressed)
            return State::Game;
    }
    return State::NoChange;
}

void MenuState::draw()
{
    App.Clear();

    App.Draw(PressAnyKey);

    App.Display();
}

void MenuState::onEnter()
{
    PressAnyKey.SetColor(sf::Color::White);
    PressAnyKey.SetString("Press any Key...");
}

void MenuState::onLeave()
{
}
