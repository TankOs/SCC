#ifndef MENUSTATE_H_INCLUDED
#define MENUSTATE_H_INCLUDED

#include <SFML/Graphics.hpp>

#include "state.h"

class MenuState : public State
{
    public:
        MenuState(sf::RenderWindow &Window);

        virtual ~MenuState();

        virtual int update();
        virtual void draw();

        virtual void onEnter();
        virtual void onLeave();
    private:
        sf::Text PressAnyKey;
};

#endif // MENUSTATE_H_INCLUDED
