#ifndef GAMESTATE_H_INCLUDED
#define GAMESTATE_H_INCLUDED

#include "state.h"
#include "map.h"
#include <SFML/Audio.hpp>

class GameState : public State
{
    public:
        GameState(sf::RenderWindow &Window);

        virtual ~GameState();

        virtual int update();
        virtual void draw();

        virtual void onEnter();
        virtual void onLeave();

    private:
        Map myMap;
        sf::Vector2f Center;

        sf::Image PlayerImage;
        sf::Sprite PlayerSprite;
        float YSpeed;

        bool h;
        float ElapsedTimeUp;

        sf::Music myMusic;
};

const char CharMap[] =
".                                            ."
".                                            ."
".                                            ."
".                                            ."
".                                            ."
".                         ------  -----------."
".--------------        ---......  ............"
"...............---   --.........  ............"
"..................---...........  ............"
"..............................................";

#endif // GAMESTATE_H_INCLUDED
