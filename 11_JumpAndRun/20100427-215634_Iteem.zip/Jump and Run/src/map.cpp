#include "map.h"

Map::Map(const sf::String ImageName, sf::Vector2i TileDimension)
{
    this->TileDimension = TileDimension;
    SetTileSet(ImageName);
    TileSet.SetSmooth(false);
    View.SetCenter(400, 300);
    View.SetSize(800, 600);
}

bool Map::LoadFromFile(const std::string &File)
{
    return false;
}

bool Map::LoadFromString(const std::string &string, int MapWidth, int MapHeight)
{
    if(string.length() < MapWidth * MapHeight)
        return false;

    CharMap.resize(MapWidth);
    for(int i = 0; i < MapWidth; i++)
        CharMap[i].resize(MapHeight);

    for(int i = 0; i < MapHeight; i++)
    {
        for(int j = 0; j < MapWidth; j++)
            CharMap[j][i] = string[ j + i * MapWidth];
    }

    SpriteMap.resize(800 / TileDimension.x + 2);
    for(int i = 0; i < SpriteMap.size(); i++)
        SpriteMap[i].resize(600 / TileDimension.y + 2);

    ReloadSprites();

    return true;
}

void Map::SetViewCenter(sf::Vector2f Center)
{
    int x = static_cast<int>(View.GetCenter().x) / TileDimension.x;
    int y = static_cast<int>(View.GetCenter().y) / TileDimension.y;

    if(x != static_cast<int>(Center.x) / TileDimension.x or y != static_cast<int>(Center.y) / TileDimension.y)
    {
        View.SetCenter(Center);
        ReloadSprites();
    }

    View.SetCenter(Center);
}

bool Map::SetTileSet(const std::string &ImageName)
{
    return TileSet.LoadFromFile(ImageName);
}

void Map::Draw(sf::RenderTarget &RenderTarget)
{
    RenderTarget.SetView(View);
    for(int i = 0; i < SpriteMap.size(); i++)
    {
        for(int j = 0; j < SpriteMap[i].size(); j++)
            RenderTarget.Draw(SpriteMap[i][j]);
    }
    RenderTarget.SetView(RenderTarget.GetDefaultView());
}

void Map::SetTileDimension(sf::Vector2i TileDimension)
{
    this->TileDimension = TileDimension;
}

void Map::ReloadSprites(void)
{
    float x = View.GetCenter().x - 50;
    float y = View.GetCenter().y - 50;
    for(int i = 0; i < SpriteMap.size(); i++)
    {
        int cx = int(x - 400) / TileDimension.x + i;
        for(int j = 0; j < SpriteMap[i].size(); j++)
        {
            int cy = int(y - 300) / TileDimension.y + j;
            SpriteMap[i][j].SetPosition(cx * TileDimension.x, cy * TileDimension.y);
            SpriteMap[i][j].SetImage(TileSet);
            SpriteMap[i][j].SetColor(sf::Color(255, 255, 255, 255));
            if(cx >= 0 and cx < CharMap.size() and cy >= 0 and cy < CharMap[cx].size())
            {
                switch(CharMap[cx][cy])
                {
                    case '-':
                        SpriteMap[i][j].SetSubRect(sf::IntRect(0, 0, TileDimension.x, TileDimension.y));
                        break;
                    case '.':
                        SpriteMap[i][j].SetSubRect(sf::IntRect(TileDimension.x, 0, TileDimension.x, TileDimension.y));
                        break;
                    case 'I':
                        SpriteMap[i][j].SetSubRect(sf::IntRect(2*TileDimension.x, 0, TileDimension.x, TileDimension.y));
                        break;
                    default:
                        SpriteMap[i][j].SetColor(sf::Color(0, 0, 0, 0));
                }
            }
            else
                SpriteMap[i][j].SetSubRect(sf::IntRect(TileDimension.x, 0, TileDimension.x, TileDimension.y));
        }
    }
}

int Map::TouchMap(sf::Vector2f Pos)
{
    int x = int(Pos.x) / TileDimension.x;
    int y = int(Pos.y) / TileDimension.y;

    if (!(x >= 0 and x < CharMap.size() and y >= 0 and y < CharMap[x].size()))
        return Good;

    switch(CharMap[x][y])
    {
        case '-': case '.': return Good;
        case 'I': return Bad;
        default: return Non;
    }
}
