#ifndef CALACOISH_H_INCLUDED
#define CALACOISH_H_INCLUDED

#include <SFML/Graphics.hpp>

#include "state.h"

class Game
{
    public:
        Game(void);
        ~Game();
        int run();
    private:
        sf::RenderWindow App;

        State *myState;
};

#endif // CALACOISH_H_INCLUDED
