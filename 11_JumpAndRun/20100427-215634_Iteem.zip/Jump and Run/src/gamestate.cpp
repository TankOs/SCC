#include "gamestate.h"

const float PI = 3.141529;

GameState::GameState(sf::RenderWindow &Window) :
State(Window),
myMap("data/TileSet.png", sf::Vector2i(50, 50))
{};

GameState::~GameState() {};

int GameState::update()
{
    const sf::Input &Input = App.GetInput();
    sf::Event Event;

    while(App.GetEvent(Event))
    {
        if(Event.Type == sf::Event::Closed)
            return State::Quit;
    }

    sf::Vector2f tmpPos = PlayerSprite.GetPosition();

    if(Input.IsKeyDown(sf::Key::Left))
    {
        PlayerSprite.Move(-App.GetFrameTime() * 200, 0);
        PlayerSprite.Rotate((App.GetFrameTime() * 200) / (PI * 24) * 360);
    }
    if(Input.IsKeyDown(sf::Key::Right))
    {
        PlayerSprite.Move(App.GetFrameTime() * 200, 0);
        PlayerSprite.Rotate((-App.GetFrameTime() * 200) / (24 * PI) * 360);
    }

    if(myMap.TouchMap(sf::Vector2f(PlayerSprite.GetPosition().x + 12, PlayerSprite.GetPosition().y + 12)) != Non or
    myMap.TouchMap(sf::Vector2f(PlayerSprite.GetPosition().x - 12, PlayerSprite.GetPosition().y + 12)) != Non)
        PlayerSprite.SetPosition(tmpPos);

    YSpeed += App.GetFrameTime() * 20;

    if(Input.IsKeyDown(sf::Key::Up) and h and ElapsedTimeUp < 0.25f)
    {
        YSpeed -= 40 * App.GetFrameTime();
        ElapsedTimeUp += App.GetFrameTime();
    }
    else
    {
        ElapsedTimeUp = 0;
        h = false;
    }


    tmpPos = PlayerSprite.GetPosition();
    PlayerSprite.Move(0, YSpeed);

    if(myMap.TouchMap(sf::Vector2f(PlayerSprite.GetPosition().x + 12, PlayerSprite.GetPosition().y + 12)) != Non or
    myMap.TouchMap(sf::Vector2f(PlayerSprite.GetPosition().x - 12, PlayerSprite.GetPosition().y + 12)) != Non)
    {
        PlayerSprite.SetPosition(tmpPos);
        YSpeed = 0;
        h = true;
    }

    myMap.SetViewCenter(PlayerSprite.GetPosition());

    return State::NoChange;
}

void GameState::draw()
{
    App.Clear(sf::Color(127,188,255));

    myMap.Draw(App);

    App.SetView(myMap.GetView());
    App.Draw(PlayerSprite);
    App.SetView(App.GetDefaultView());

    App.Display();
}

void GameState::onEnter()
{
    myMap.LoadFromString(CharMap, 46, 10);
    Center = sf::Vector2f(400, 300);

    PlayerImage.LoadFromFile("data/Player.png");
    PlayerSprite.SetImage(PlayerImage);
    PlayerSprite.SetOrigin(12, 12);
    PlayerSprite.SetPosition(100, 100);
    YSpeed = 0;

    ElapsedTimeUp = 0;
    h = true;

    myMusic.OpenFromFile("data/music.ogg");
    myMusic.Play();
}

void GameState::onLeave()
{
}
