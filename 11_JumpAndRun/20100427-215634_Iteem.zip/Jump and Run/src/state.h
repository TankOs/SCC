#ifndef STATE_H_INCLUDED
#define STATE_H_INCLUDED

#include <SFML/Graphics.hpp>

class State //Jeder State erbt von dieser Klasse
{
    public:
        State(sf::RenderWindow &Window) : App(Window)
        {};

        virtual ~State(){};

        //draw und update werden getrennt
        virtual int update() = 0;
        virtual void draw() = 0;

        //zum initialsieren bezw. zerstören des states
        virtual void onEnter() = 0;
        virtual void onLeave() = 0;

        enum NextState
        {
            NoChange,
            Menu,
            Game,
            Quit
        };

    protected:
        sf::RenderWindow &App;
};

#endif // STATE_H_INCLUDED
