#include "player.h"

Player::Player(const std::string path, int XPos, int YPos) {
	PlayerImage.LoadFromFile(path);
	PlayerSprite.SetImage(PlayerImage);

	// Position setzen
	PlayerSprite.SetPosition(XPos,YPos);

	// Rect positionieren
	PlayerSprite.SetSubRect(sf::IntRect(700,0,800,100));	

	reg = 0;
	jumping = 0;
	MoveX = 0;
	MoveY = 0;
	lookLeft = false;

}

void Player::stand() {

	if (lookLeft == false)
		PlayerSprite.SetSubRect(sf::IntRect(700,0,800,100));	
	else
		PlayerSprite.SetSubRect(sf::IntRect(700,100,800,200));	

}

void Player::move(float x, float y, float left) {

	PlayerSprite.Move(x,y);

	PlayerSprite.SetSubRect(sf::IntRect(100*reg,100*left,100*(reg+1),100*(left+1)));
	reg++;


	if (reg == 7) {
		reg = 0;
	}

	// Nach links oder rechts schauen?
	if (left == 1) 
		lookLeft = true;
	else
		lookLeft = false;

}

void Player::jump(bool up, bool collision, bool collision2, bool collision3) {

	if (up == 1 && jumping < 10) {
		if (lookLeft == false) PlayerSprite.SetSubRect(sf::IntRect(800,0,900,100));	
		else PlayerSprite.SetSubRect(sf::IntRect(800,100,900,200));
		PlayerSprite.Move(0,-10);
		jumping++;
	}

	if ((collision > 1 && collision2 > 1 && collision3 > 1) && (up == 0 || jumping == 10)) {
		if (lookLeft == false) PlayerSprite.SetSubRect(sf::IntRect(800,0,900,100));	
		else PlayerSprite.SetSubRect(sf::IntRect(800,100,900,200));	
		PlayerSprite.Move(0,10);
	}

	if (collision == 1 && collision2 == 1 && collision3 == 1) {
		jumping = 0;
	}


}





