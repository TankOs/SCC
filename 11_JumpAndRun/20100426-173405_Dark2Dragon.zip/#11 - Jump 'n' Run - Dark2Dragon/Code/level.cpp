#include "level.h"

// Sprite setzen(X-Position, Y-Position, Anzahl auf X-Position, SpriteImage, Kollision ja/nein?)
void Level::setSprite(int X, int Y, int length, sf::Image &sImage, bool coll) {
	for (int i=0; i<length; i++) {
		lvl1[X+i][Y].sprite.SetImage(sImage);
		lvl1[X+i][Y].collision = coll;
		lvl1[X+i][Y].sprite.SetPosition((X+i)*50,50*Y);
	}

}
	
void Level::Draw(sf::RenderWindow &App, float Xpos) {
	float left = (Xpos/50) - 8;
	if (left < 0) left = 0;

	for (int j=left; j<(Xpos/50)+15; j++) {
		for (int h=4; h<12; h++) {
			App.Draw(lvl1[j][h].sprite);
		}
	}
}