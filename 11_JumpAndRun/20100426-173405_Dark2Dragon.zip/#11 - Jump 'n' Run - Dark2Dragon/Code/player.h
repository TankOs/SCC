#include <SFML/Graphics.hpp>
#include "level.h"

#ifndef PLAYER_H
#define PLAYER_H

class Player
{
private:
	sf::Image PlayerImage;
	sf::Sprite PlayerSprite;
	float reg;
	int jumping;
	float MoveX, MoveY;
	bool lookLeft;

public:
	Player(const std::string path,int XPos, int YPos);
	void stand();
	void move(float x, float y, float left);
	void move(float x, float y) {PlayerSprite.Move(x,y);}
	void jump(bool up, bool collision, bool collision2, bool collision3);
	bool getLook() {return lookLeft;}
	float getX() {return PlayerSprite.GetPosition().x;}
	float getY() {return PlayerSprite.GetPosition().y;}
	void setRect(int l, int o, int el, int ol) {PlayerSprite.SetSubRect(sf::IntRect(l,o,el,ol));}
	void Draw(sf::RenderWindow &App) {App.Draw(PlayerSprite);}
};


#endif