////////////////////////////////////////////////////////////
// Adventure of Sheep DEMO
////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
// Headers
////////////////////////////////////////////////////////////
#include <SFML/Window.hpp>
#include "level.h"
#include "player.h"

int main()
{

	// ### Main Window ###
    sf::RenderWindow App(sf::VideoMode(800, 600, 16), "Adventure of Sheep");

	App.SetFramerateLimit(20);
	App.ShowMouseCursor(false);

	// ### Level Build ###
	Level Stage1;

	// Bilder setzen
	sf::Image ImGras;
	sf::Image ImFels;

	// Variablen
	float Timer = 0;
	bool isJumping = false;
	bool isWalking = false;
	int Xpos, Ypos;

	if (!ImGras.LoadFromFile("gfx/wiese.png")) {};
	if (!ImFels.LoadFromFile("gfx/fels.png")) {};

	// Boden setzen
	Stage1.setSprite(0,11,400,ImGras,true);

	// Steine setzen
	Stage1.setSprite(0,10,1,ImFels, true);
	Stage1.setSprite(0,9,1,ImFels, true);
	Stage1.setSprite(0,8,1,ImFels, true);
	Stage1.setSprite(12,9,8,ImFels, true);
	Stage1.setSprite(16,7,4,ImFels, true);
	Stage1.setSprite(21,10,4,ImFels, true);
	Stage1.setSprite(29,9,5,ImFels, true);
	Stage1.setSprite(38,6,10,ImFels, true);
	Stage1.setSprite(40,10,1,ImFels, true);
	Stage1.setSprite(45,10,1,ImFels, true);
	Stage1.setSprite(50,10,1,ImFels, true);
	Stage1.setSprite(55,10,1,ImFels, true);
	Stage1.setSprite(60,10,1,ImFels, true);
	Stage1.setSprite(65,10,1,ImFels, true);
	Stage1.setSprite(70,10,1,ImFels, true);
	Stage1.setSprite(75,10,1,ImFels, true);


	// Player Build
	Player Hero("gfx/hero2.png",300,400);

	// Ansicht
	sf::View Ansicht;
	Ansicht.SetCenter(500,100);


	// ### Start game loop ###
    while (App.IsOpened())
    {  

		Timer = App.GetFrameTime()*100;

		// Collision Punkte berechnen
		Xpos = Hero.getX()/50;
		Ypos = Hero.getY()/50;


        // Process events
        sf::Event Event;
        while (App.GetEvent(Event))
        {

			// Close window: exit
            if (Event.Type == sf::Event::Closed)
                App.Close();

			// KeyEvents abfangen
			if (Event.Type == sf::Event::KeyPressed)
			{
				// Escape key: exit
                if (Event.Key.Code == sf::Key::Escape)
                    App.Close();

				// Links laufen
				if (Event.Key.Code == sf::Key::Left && Stage1.getCollision(Xpos,Ypos+1) > 1) {	
					Ansicht.Move(-2*Timer,0);
					Hero.move(-2*Timer,0,1);
					isWalking = true;		
				}

				// Rechts laufen
				if (Event.Key.Code == sf::Key::Right && Stage1.getCollision(Xpos+2,Ypos+1) > 1) {
						Ansicht.Move(2*Timer,0);
						Hero.move(2*Timer,0,0);
						isWalking = true;
				}

				// Jump
				if (Event.Key.Code == sf::Key::Space && Stage1.getCollision(Xpos+2,Ypos+1) > 1 && 
					Stage1.getCollision(Xpos,Ypos+1) > 1 && Stage1.getCollision(Xpos,Ypos) > 1) {
						if (Hero.getLook() == false) {
							Ansicht.Move(2*Timer,0);
							Hero.move(2*Timer,0,0);
						}
						else {
							Ansicht.Move(-2*Timer,0);
							Hero.move(-2*Timer,0,1);
						}
						isWalking = true;
						isJumping = true;
				}				
			}	     
		}

		// Jump?
		Hero.jump(isJumping, Stage1.getCollision(Xpos+1,Ypos+2), Stage1.getCollision(Xpos,Ypos+2), Stage1.getCollision(Xpos+2,Ypos+2));

		// Walk? Jump?
		if (isJumping == false && isWalking == false) {
				Hero.stand();
		}
		else {
			isJumping = false;
			isWalking = false;
		}

		// View setzen
		App.SetView(Ansicht);

		 // Clear screen
		App.Clear(sf::Color(135,206,235));

		// Objekte zeichnen
		Hero.Draw(App);
		Stage1.Draw(App, Hero.getX());

		
		 // Display
		App.Display();

	}

	return 0;
}

