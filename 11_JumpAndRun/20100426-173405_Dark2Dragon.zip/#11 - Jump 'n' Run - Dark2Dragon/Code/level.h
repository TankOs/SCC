#include <SFML/Graphics.hpp>

#ifndef LEVEL_H
#define LEVEL_H

class Level
{
private:
	struct Tilemap {
		bool collision;
		sf::Sprite sprite;
	};

	Tilemap lvl1[400][12];


public:
	void setSprite(int X, int Y, int length, sf::Image &sImage, bool coll);
	void Draw(sf::RenderWindow &App, float Xpos);
	bool getCollision(int x, int y) {return lvl1[x][y].collision;}
	sf::Sprite getSprite(int x, int y) {return lvl1[x][y].sprite;}
};
#endif