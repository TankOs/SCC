/* 
 * File:   Player.h
 * Author: eric
 *
 * Created on 4. April 2010, 21:35
 */

#ifndef _PLAYER_H
#define	_PLAYER_H

#include "SFML/Graphics.hpp"
#include "Block.h"
#include "Flame.h"

enum State { STAND, WALK, JUMP };
enum Direction { LEFT, RIGHT, UP, DOWN };

class Player {
public:
    Player();
    Player(const Player& orig);
    virtual ~Player();

    void Draw(sf::RenderWindow &Window);
    void update(float frameTime,std::vector<Block> blocks);
    bool move(Direction directionToMove);
    bool jump();
    sf::FloatRect getHitbox();
    void setPosition(float x, float y);
    bool fireDamage(std::vector<Flame> &flames, float frameTime);
    float getEnergy();
    void reset();
    float getVel();
private:
    sf::Image image;
    sf::Sprite sprite;
    State state;
    Direction dir;
    float vel;
    bool isMoving;
    bool isJumping;
    float animationTimer;

    float energy;

    void setState(State newState);
    void updateAnimation(float frameTime);
    void setAnimationFrame(int row, int frame);
    bool blocksIntersect(sf::FloatRect rect, std::vector<Block> blocks);
    bool moveButNotThroughWalls(float amount, bool horizontal, std::vector<Block> blocks);
    bool moveButNotThroughWalls(float amountX, float amountY, std::vector<Block> blocks) { if (amountX != 0) moveButNotThroughWalls(amountX, true, blocks); else moveButNotThroughWalls(amountY, false, blocks); }
};

#endif	/* _PLAYER_H */

