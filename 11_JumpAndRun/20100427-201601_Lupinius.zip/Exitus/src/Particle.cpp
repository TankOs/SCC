/*
 * File:   Particle.cpp
 * Author: eric
 *
 * Created on 13. April 2010, 18:52
 */

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>


#include "Particle.h"

Particle::Particle() {
}

Particle::Particle(sf::Image &image, int xPos, int yPos, float lifetime, float xSpeed, float ySpeed, float randomness) {
    Particle(image, xPos, yPos, lifetime, xSpeed, ySpeed, randomness, randomness);
}

Particle::Particle(sf::Image &image, int xPos, int yPos, float lifetime, float xSpeed, float ySpeed, float xRandomness, float yRandomness, float randomRot, float size) {
    sprite.SetImage(image);
    sprite.SetPosition(xPos, yPos);
    this->speedX = xSpeed;
    sprite.Scale(size, size);
    this->speedY = ySpeed;
    this->randomX = xRandomness;
    this->randomY = yRandomness;
    this->lifeTime = lifetime;
    this->randomRot = randomRot;
    sprite.SetCenter(image.GetWidth()/2, image.GetHeight()/2);
}

Particle::Particle(const Particle& orig) {
    this->lifeTime = orig.lifeTime;
    this->speedX = orig.speedX;
    this->speedY = orig.speedY;
    this->randomX = orig.randomX;
    this->randomY = orig.randomY;
    this->sprite = orig.sprite;
    this->randomRot = orig.randomRot;
}

Particle::~Particle() {
}

bool Particle::isAlive() {
    return lifeTime > 0;
}

void Particle::render(sf::RenderWindow &window) {
    window.Draw(sprite);
}

void Particle::update(float frametime) {
    sprite.Move(speedX * frametime, speedY * frametime);
    sprite.Move(sf::Randomizer::Random(-randomX, randomX) * frametime, sf::Randomizer::Random(-randomY, randomY) * frametime);
    sprite.Rotate(sf::Randomizer::Random(-randomRot, randomRot));
    lifeTime -= frametime;
}

bool Particle::collides(sf::FloatRect other) {
    return other.Intersects(sf::FloatRect(
            sprite.GetPosition().x,
            sprite.GetPosition().y,
            sprite.GetPosition().x + sprite.GetSize().x - 50,
            sprite.GetPosition().y + sprite.GetSize().y
            ));
}