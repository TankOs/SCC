#include "Game.h"

int main() {

    Game Notausgang;
    
    Notausgang.Run();

    return 0;

}