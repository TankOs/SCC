/* 
 * File:   Player.cpp
 * Author: eric
 * 
 * Created on 4. April 2010, 21:35
 */
#include <iostream>

#include "SFML/Graphics.hpp"

#include "Player.h"
#include "Block.h"

Player::Player() {
    image.LoadFromFile("resource/player.png");
    sprite.SetImage(image);
    state = STAND;
    animationTimer = 0;
    energy = 1;
}

Player::Player(const Player& orig) {
}

Player::~Player() {
}

void Player::Draw(sf::RenderWindow &window) {
    window.Draw(sprite);
}

void Player::update(float frameTime, std::vector<Block> blocks) {

    // Walking

    if (isMoving) {

        moveButNotThroughWalls(dir == RIGHT ? 500 * frameTime : -500 * frameTime, true, blocks);

    } else if (state != JUMP)
        setState(STAND);

    // Jumping / Falling

    vel += 750 * frameTime;

    if (vel > 50)
        isJumping = true;

    if (!moveButNotThroughWalls(vel * frameTime, false, blocks)) {
        if (vel > 0) {
            isJumping = false;
            if (isMoving)
                state = WALK;
            else
                state = STAND;
        }
        vel = 0;
    }

    isMoving = false;

    if (isJumping)
        setState(JUMP);

    sprite.SetColor(sf::Color(255, 255 * energy, 255 * energy));

    if (energy < 1)
        energy += 2 * frameTime;
    
    updateAnimation(frameTime);
}

bool Player::moveButNotThroughWalls(float amount, bool horizontal, std::vector<Block> blocks) {

    short int direction;
    sprite.Move(horizontal ? amount : 0, !horizontal ? amount : 0);
    if (amount < 0) direction = 1; else direction = -1;
    sf::FloatRect hitbox = getHitbox();

    if ( blocksIntersect(hitbox, blocks) ) { // Collission Detection
        while (blocksIntersect(hitbox, blocks)) { // Move out of the wall!
            hitbox = getHitbox();
            sprite.Move(horizontal ? 0.25 * direction : 0, !horizontal ? 0.25 * direction : 0);
        }
        return false;
    }

    return true;

}

bool Player::move(Direction directionToMove) {
    dir = directionToMove;
    sprite.FlipX(dir == RIGHT);
    if (state != WALK)
        setState(WALK);
    isMoving = true;
}

void Player::setState(State newState) {
    animationTimer = 0;
    state = newState;
}

void Player::updateAnimation(float frameTime) {
     switch (state) {

         case WALK:
            animationTimer += frameTime;
            if ( animationTimer >= 0.48343*1.5)
                animationTimer -= 0.48343*1.5;
            setAnimationFrame(1, animationTimer * 60/1.5); // Play walking animation
            break;
         case STAND:
            setAnimationFrame(0, 0);
            break;
         case JUMP:
            setAnimationFrame(2, 0);
            break;
    }
}

void Player::setAnimationFrame(int row, int frame) {
    int height = 150, width = 150;
    int x = frame * width;
    int y = row * height;

    sprite.SetSubRect(sf::IntRect(x, y, x + width, y + height));
}

bool Player::jump() {
    if ( !isJumping ) {
        isJumping = true;
        vel = -750;
        return true;
    }
    return false;
}

bool Player::blocksIntersect(sf::FloatRect rect, std::vector<Block> blocks) {
    for ( int i = 0; i < blocks.size(); i++) {
        if (blocks[i].intersects(rect))
            return true;
    }

    return false;
}

sf::FloatRect Player::getHitbox() {
    int offsetX = 40,
        offsetY = 15,
        width   = 73,
        height  = 130;
    return sf::FloatRect(sprite.GetPosition().x + offsetX,
                                sprite.GetPosition().y + offsetY,
                                (sprite.GetPosition().x + offsetX) + width,
                                (sprite.GetPosition().y + offsetY) + height);
}

void Player::setPosition(float x, float y) {
    sprite.SetPosition(x, y);
}

bool Player::fireDamage(std::vector<Flame> &flames, float frameTime) {
    for (int i = 0; i < flames.size(); i++) {
        energy -= flames[i].collides(getHitbox()) * frameTime * 1.2;
    }
}

float  Player::getEnergy() { return energy; }

void Player::reset() { energy = 1; vel = 0; }

float Player::getVel() { return vel; }