/*
 * File:   Particle.h
 * Author: eric
 *
 * Created on 13. April 2010, 18:52
 */

#ifndef _PARTICLE_H
#define	_PARTICLE_H

#include <SFML/Graphics.hpp>

class Particle {
public:
    Particle();
    Particle(sf::Image &image, int xPos, int yPos, float lifetime, float xSpeed = 0, float ySpeed = 0, float randomness = 0);
    Particle(sf::Image &image, int xPos, int yPos, float lifetime, float xSpeed, float ySpeed, float xRandomness, float yRandomness, float randomRot = 0, float size = 1);
    Particle(const Particle& orig);
    virtual ~Particle();

    bool isAlive();
    void render(sf::RenderWindow &window);
    void update(float frametime);

    bool collides(sf::FloatRect other);
private:
    sf::Sprite sprite;
    float speedX, speedY;
    float lifeTime;
    float randomX, randomY, randomRot;

};

#endif	/* _PARTICLE_H */

