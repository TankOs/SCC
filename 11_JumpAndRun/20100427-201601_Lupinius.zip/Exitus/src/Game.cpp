/* 
 * File:   Game.cpp
 * Author: eric
 * 
 * Created on 4. April 2010, 21:22
 */

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <fstream>
#include <sstream>

#include "Game.h"

void drawBox(sf::FloatRect rect, sf::RenderWindow &window) {
    window.Draw(sf::Shape::Rectangle(rect.Left, rect.Top, rect.Right, rect.Bottom, sf::Color(255, 255, 255, 30)));
}

Game::Game() {

    music.OpenFromFile("resource/Fireproof_Babies_-_Swim_below_as_Leviathans.ogg");

    app.Create(sf::VideoMode(800, 600), "Exitus");
    app.ShowMouseCursor(false);

    color = sf::Color(0x1B, 0x59, 0x0C);
    level = 0;
    camera = app.GetDefaultView();
    app.SetView(camera);
    
    fullscreen = false;

    jumpSound.LoadFromFile("resource/jump.wav");
    jump.SetBuffer(jumpSound);

    exitImage.LoadFromFile("resource/exit.png");
    exit.SetImage(exitImage);

    flyingBodyparts[0] = ParticleSystem("bodypar1.png");
    flyingBodyparts[1] = ParticleSystem("bodypar2.png");
    flyingBodyparts[2] = ParticleSystem("bodypar3.png");
    flyingBodyparts[3] = ParticleSystem("bodypar4.png");
    flyingBodyparts[4] = ParticleSystem("bodypar5.png");
    flyingBodyparts[5] = ParticleSystem("bodypar6.png");

    font.LoadFromFile("resource/Megaton.ttf", 100);
    end.SetFont(font);
    end.SetText("Das Ende");
    end.SetSize(100);
    end.SetPosition(80, 220);

    state = GAME;

    nextlevel();
    
}

Game::Game(const Game& orig) {
}

Game::~Game() {
}

int Game::Run() {

    music.Play();

    while (app.IsOpened()) { // Main Loop

        // Event Handling
        sf::Event Event;
        while (app.GetEvent(Event)) { HandleEvent(Event); }

        app.Clear(color);

        if (state == GAME) {

            if (player.getEnergy() < 0 || player.getVel() > 3000) {
                for (int i = 0; i < 6; i++)  {
                    flyingBodyparts[i].spawnParticle(player.getHitbox().Right + 20, player.getHitbox().Top + 100, 10, sf::Randomizer::Random(-1000, 1000), sf::Randomizer::Random(-1000, 1000), 0, 0, 0, 1);
                }
                player.setPosition(origX, origY);
                player.reset();
            }

            if (player.getHitbox().Intersects(sf::FloatRect(
                    exit.GetPosition().x,
                    exit.GetPosition().y + 100,
                    exit.GetPosition().x + exit.GetSize().x,
                    exit.GetPosition().y + exit.GetSize().y
                    )))
                if (!nextlevel())
                    state = END;
            const sf::Input &input = app.GetInput();
            movePlayer(input);

            player.fireDamage(fire, app.GetFrameTime());

            for (int i = 0; i < fire.size(); i++) {
                fire[i].update(app.GetFrameTime());
            }

            for (int i = 0; i < 6; i++)
                flyingBodyparts[i].update(app.GetFrameTime());

            player.update(app.GetFrameTime(), blocks);

            MoveCamera();

            Draw();
        } else {
            app.SetView(app.GetDefaultView());
            app.Draw(end);
        }

        app.Display();

    }

    music.Stop();

}

void Game::HandleEvent(sf::Event Event) {
    switch (Event.Type) {
        case sf::Event::Closed:
            app.Close();
            break;
        case sf::Event::KeyPressed:
            switch (Event.Key.Code) {
                case sf::Key::Escape:
                    app.Close();
                    break;
                case sf::Key::F11:
                    fullscreen = !fullscreen;
                    if (fullscreen)
                        app.Create(sf::VideoMode(app.GetWidth(), app.GetHeight()), "Exitus", sf::Style::Fullscreen);
                    else
                        app.Create(sf::VideoMode(app.GetWidth(), app.GetHeight()), "Exitus");
                    app.SetView(camera);
                    break;
                case sf::Key::R:
                    player.setPosition(origX, origY);
                    player.reset();
                    break;
                }
            break;
    }
}

void Game::Draw() {
    app.Draw(exit);

    for (int i = 0; i < 6; i++) 
        flyingBodyparts[i].render(app);

    for (int i = 0; i < fire.size(); i++)
        fire[i].draw(app);

    player.Draw(app);
    
    for ( int i = 0; i < blocks.size(); i++) {
        blocks[i].draw(app);
    }
}

void Game::movePlayer(const sf::Input& input) {
    if ( input.IsKeyDown(sf::Key::Right) )
        player.move(RIGHT);
    else if ( input.IsKeyDown(sf::Key::Left) )
        player.move(LEFT);
    if (input.IsKeyDown(sf::Key::Up))
        if (player.jump())
            jump.Play();
}

void Game::MoveCamera() {
    float x = camera.GetCenter().x, y = camera.GetCenter().y;
    float px = (player.getHitbox().Left + player.getHitbox().Right) / 2, py = (player.getHitbox().Bottom + player.getHitbox().Top) / 2;
    x += (px - camera.GetCenter().x) * 8 * app.GetFrameTime();
    y += (py - camera.GetCenter().y) * 8 * app.GetFrameTime();
    camera.SetCenter(x, y);
}

bool Game::loadLevel(const char filename[]) {
    blocks.clear();
    fire.clear();

    std::cout << "Lade Level aus Datei " << filename << std::endl;

    std::string name("levels/");
    name.append(filename);

    std::ifstream file;
    file.open(name.c_str());

    if (!file) {
        std::cout << "Konnte Datei nicht öffnen!" << std::endl;
        return false;
    }

    std::string line;

    while (!file.eof()) {

        getline(file, line);

        if ( line == "player") {
            int coord[2];
            for (int i = 0; i < 2; i++) {
                std::string pos;
                getline(file, pos);
                coord[i] = atoi(pos.c_str());
            }
            player.setPosition(coord[0], coord[1]);
            origX = coord[0];
            origY = coord[1];
        } else if ( line == "block") {
            int coord[4];
            for (int i = 0; i < 4; i++) {
                std::string pos;
                getline(file, pos);
                coord[i] = atoi(pos.c_str());
            }
            blocks.push_back(Block(coord[0], coord[1], coord[2], coord[3]));
        } else if ( line == "flame" || line == "fire" ) {
            int coord[2];
            for (int i = 0; i < 2; i++) {
                std::string pos;
                getline(file, pos);
                coord[i] = atoi(pos.c_str());
            }
            fire.push_back(Flame(coord[0], coord[1]));
        } else if ( line == "exit" ) {
            int coord[2];
            for (int i = 0; i < 2; i++) {
                std::string pos;
                getline(file, pos);
                coord[i] = atoi(pos.c_str());
            }
            exit.SetPosition(coord[0], coord[1]);
        } else if (line[0] == *"#") {
        } else if (line != "")
            std::cout << "Warnung: Unbekannter Gegenstand: " << line << std::endl;
        
    }

    file.close();

    return true;

}

bool Game::nextlevel() {
    level++;
    std::ostringstream stream;
    stream << level << ".txt";
    return loadLevel(stream.str().c_str());
}