/* 
 * File:   Block.h
 * Author: eric
 *
 * Created on 5. April 2010, 17:26
 */

#ifndef _BLOCK_H
#define	_BLOCK_H

class Block {
public:
    Block();
    Block(int x1, int y1, int x2, int y2);
    Block(const Block& orig);
    virtual ~Block();

    bool intersects(sf::FloatRect other);
    void draw(sf::RenderWindow &window);
    void output();
    sf::FloatRect getRect();
private:
    sf::FloatRect pos;
};

#endif	/* _BLOCK_H */

