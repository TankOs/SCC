/* 
 * File:   Game.h
 * Author: eric
 *
 * Created on 4. April 2010, 21:22
 */

#ifndef _GAME_H
#define	_GAME_H

#include <SFML/Audio.hpp>

#include "Player.h"
#include "Block.h"
#include "ParticleSystem.h"
#include "Flame.h"

enum GameState { GAME, END };

class Game {
public:
    Game();
    Game(const Game& orig);
    virtual ~Game();

    int Run();
private:
    bool fullscreen;

    sf::RenderWindow app;
    int level;
    Player player;
    int origX, origY;
    sf::Color color;
    sf::View camera;

    sf::SoundBuffer jumpSound;
    sf::Sound jump;
    sf::Music music;

    sf::Image exitImage;
    sf::Sprite exit;

    sf::Font font;
    sf::String end;

    std::vector<Block> blocks;
    std::vector<Flame> fire;

    ParticleSystem flyingBodyparts[6];

    GameState state;

    bool loadLevel(const char filename[]);
    bool nextlevel();
    void HandleEvent(sf::Event Event);
    void Draw();
    void movePlayer(const sf::Input &input);
    void MoveCamera();
};

#endif	/* _GAME_H */

