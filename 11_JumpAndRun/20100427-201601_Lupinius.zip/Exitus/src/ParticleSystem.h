/*
 * File:   ParticleSystem.h
 * Author: eric
 *
 * Created on 13. April 2010, 18:52
 */

#ifndef _PARTICLESYSTEM_H
#define	_PARTICLESYSTEM_H

#include "Particle.h"

#include <list>


class ParticleSystem {
public:
    ParticleSystem();
    ParticleSystem(char name[]);
    ParticleSystem(const ParticleSystem& orig);
    virtual ~ParticleSystem();
    
    void update(float frameTime);
    void render(sf::RenderWindow &window);

    void spawnParticle(int xPos, int yPos, float lifetime, float xSpeed, float ySpeed, float xRandomness, float yRandomness, float randeomRot, float size = 1);
    int collides(sf::FloatRect other);
private:
    std::list<Particle> particles;
    sf::Image image;
};

#endif	/* _PARTICLESYSTEM_H */

