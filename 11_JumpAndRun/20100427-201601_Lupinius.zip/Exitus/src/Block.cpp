/* 
 * File:   Block.cpp
 * Author: eric
 * 
 * Created on 5. April 2010, 17:26
 */

#include <SFML/Graphics.hpp>
#include <iostream>

#include "Block.h"

Block::Block() {
}

Block::Block(int x1, int y1, int x2, int y2) {
    pos = sf::FloatRect(x1, y1, x2, y2);
}

Block::Block(const Block& orig) {
    this->pos = orig.pos;
}

Block::~Block() {
}

bool Block::intersects(sf::FloatRect other) {
    return pos.Intersects(other);
}

void Block::draw(sf::RenderWindow &window) {
    window.Draw(sf::Shape::Rectangle(pos.Left, pos.Top, pos.Right, pos.Bottom, sf::Color(255, 255, 255)));
}

void Block::output() {
    std::cout << pos.Left << ", " << pos.Top << ", "  << pos.Right << ", "  << pos.Bottom << std::endl;
}

sf::FloatRect Block::getRect() {
    return pos;
}