/* 
 * File:   Flame.h
 * Author: eric
 *
 * Created on 16. April 2010, 22:00
 */

#ifndef _FLAME_H
#define	_FLAME_H

#include "ParticleSystem.h"


class Flame {
public:
    Flame();
    Flame(float posX, float posY);
    Flame(const Flame& orig);
    virtual ~Flame();

    void update(float frameTime);
    void draw(sf::RenderWindow &window);

    int collides(sf::FloatRect other);
private:
    ParticleSystem parSys[3];
    float posX, posY;
    float spawnTimer[2];

};

#endif	/* _FLAME_H */

