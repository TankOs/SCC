/* 
 * File:   Flame.cpp
 * Author: eric
 * 
 * Created on 16. April 2010, 22:00
 */

#include "Flame.h"

Flame::Flame() {
}

Flame::Flame(float posX, float posY) {
    parSys[0] = ParticleSystem("fireparticle_1.png");
    parSys[1] = ParticleSystem("fireparticle_2.png");
    parSys[2] = ParticleSystem("fireparticle_3.png");
    this->posX = posX;
    this->posY = posY;
    spawnTimer[0] = 0; spawnTimer[1] = 0; spawnTimer[2] = 0;
}

Flame::Flame(const Flame& orig) {
    parSys[0] = orig.parSys[0];
    parSys[1] = orig.parSys[1];
    parSys[2] = orig.parSys[2];
    posX = orig.posX;
    posY = orig.posY;
    spawnTimer[0] = orig.spawnTimer[0];
    spawnTimer[1] = orig.spawnTimer[1];
    spawnTimer[2] = orig.spawnTimer[2];
}

Flame::~Flame() {
}

void Flame::update(float frameTime) {
    int toSpawn;
    for ( int i = 0; i < 3; i++) {

        toSpawn = 0;

        spawnTimer[i] += frameTime;
        while (spawnTimer[i] > 0.1) {
            spawnTimer[i] -= 0.1 + sf::Randomizer::Random(-0.05f, 0.05f) - (i == 1 ? 0 : 0.02);
            toSpawn++;
        }

        for (int j = 0; j < toSpawn; j++)
            parSys[i].spawnParticle(posX - ((i - 1) * 50), posY, i == 1 ? 0.35 : 0.5, (i - 1) * 40, -400, i == 1 ? 500 : 700, 1000, 1, 0.7);

        parSys[i].update(frameTime);
    }
}

void Flame::draw(sf::RenderWindow &window) {
    parSys[1].render(window);
    parSys[0].render(window);
    parSys[2].render(window);
}

int Flame::collides(sf::FloatRect other) {
    return parSys[0].collides(other) + parSys[1].collides(other) + parSys[2].collides(other);
}