/*
 * File:   ParticleSystem.cpp
 * Author: eric
 *
 * Created on 13. April 2010, 18:52
 */

#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>

#include "ParticleSystem.h"

ParticleSystem::ParticleSystem() {
}

ParticleSystem::ParticleSystem(char name[]) {
    std::string filename("resource/");
    filename.append(name);
    image.LoadFromFile(filename.c_str());
}

ParticleSystem::ParticleSystem(const ParticleSystem& orig) {
}

ParticleSystem::~ParticleSystem() {
}

void ParticleSystem::spawnParticle(int xPos, int yPos, float lifetime, float xSpeed, float ySpeed, float xRandomness, float yRandomness, float randeomRot, float size) {
    particles.push_back( Particle(image, xPos, yPos, lifetime, xSpeed, ySpeed, xRandomness, yRandomness, randeomRot, size) );
}

void ParticleSystem::update(float frameTime) {
    particles.reverse();
    for (std::list<Particle>::iterator i = particles.begin(); i != particles.end(); i++) {
        i->update(frameTime);
        if (!i->isAlive()) {
            std::list<Particle>::iterator todelete = i;
            i++;
            particles.erase(todelete);
        }
    }
    particles.reverse();
}

void ParticleSystem::render(sf::RenderWindow &window) {
    for (std::list<Particle>::iterator i = particles.begin(); i != particles.end(); i++) {
        i->render(window);
    }
}

int ParticleSystem::collides(sf::FloatRect other) {
    int count = 0;
    for (std::list<Particle>::iterator i = particles.begin(); i != particles.end(); i++) {
        if (i->collides(other))
            count++;
    }
    return count;
}