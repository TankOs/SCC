#ifndef ROLLINGENEMY_HPP
#define ROLLINGENEMY_HPP

#include <SFML/Graphics.hpp>

class C_RollingEnemy
{
    public:

    C_RollingEnemy(sf::Sprite *Sprite, sf::Vector2f StartPos, float xScreenSize);
    bool Update(float LineHigh, float Scroll, float FrameTime);
    void Render(sf::RenderWindow &DrawHere);
    bool Collide( C_Granny *Granny);
    void ImHit();

    private:

    bool FromLeft;
    short TurnAround;
    float MoveSpeed;
    float RollFactor;
    float xScreenSize;

    bool Red;
    bool Alive;

    sf::Sprite *Sprite;
    sf::Rect<int> EnemyRect;
    sf::Vector2f Position;

    sf::Color RedColor;
};

C_RollingEnemy::C_RollingEnemy(sf::Sprite *Sprite, sf::Vector2f StartPos, float xScreenSize)
{
    this->Sprite = Sprite;
    this->xScreenSize = xScreenSize;

    EnemyRect = Sprite->GetSubRect();

    Position.x = StartPos.x;
    Position.y = StartPos.y;

    EnemyRect.Offset(Position.x, Position.y);
    Sprite->Move(Position.x, Position.y);

    FromLeft = false;
    Alive = true;
    TurnAround = 0;

    if ( StartPos.y < 0 )
    {
        FromLeft = true;
    }
    Sprite->SetCenter( 64, 64);
    MoveSpeed = 300;
    RollFactor = -300;

    RedColor.r = 200;
    RedColor.b = 10;
    RedColor.g = 10;

}

void C_RollingEnemy::ImHit()
{
    Alive = false;
}

void C_RollingEnemy::Render(sf::RenderWindow &DrawHere)
{
    if ( Red == true)
    {
        Sprite->SetColor(RedColor);
    }
    else
    {
        Sprite->SetColor( sf::Color(255,255,255));
    }
    Sprite->SetPosition(Position);
    DrawHere.Draw(*Sprite);
}

bool C_RollingEnemy::Update(float LineHigh, float Scroll, float FrameTime)
{

    Sprite->Rotate(RollFactor*FrameTime);
    float yOffset =  LineHigh - Position.y -64 ;

    Position.y = LineHigh - 64 ;
    Scroll     += MoveSpeed*FrameTime;
    Position.x += Scroll;
    Position.x += MoveSpeed*FrameTime;


    EnemyRect.Offset(Scroll+ MoveSpeed*FrameTime,yOffset);
    Sprite->Move(Scroll+ MoveSpeed*FrameTime,yOffset);

    if ( xScreenSize < Position.x && FromLeft == false )
    {
        FromLeft = true;
        RollFactor *= -1;
        MoveSpeed *= -1;
    }

    else if ( 0 > Position.x && FromLeft == true )
    {
        FromLeft = false;
        RollFactor *= -1;
        MoveSpeed *= -1;
    }

    else if ( Alive == false)
    {
        return false;
    }

    return true;
}

bool C_RollingEnemy::Collide( C_Granny * Granny)
{


    sf::Rect<int> PlayerRect;
    sf::Vector2f GrannyPos;
    sf::Vector2i GrannySize;

    GrannyPos = Granny->GetPos();
    GrannySize = Granny->GetSize();

    PlayerRect.Top = PlayerRect.Bottom = GrannyPos.y;
    PlayerRect.Bottom += GrannySize.y;

    PlayerRect.Left = PlayerRect.Right = GrannyPos.x;
    PlayerRect.Right += GrannySize.x;

    EnemyRect = Sprite->GetSubRect();
    EnemyRect.Offset(Position.x, Position.y);

    Red = EnemyRect.Intersects(PlayerRect,NULL) ;

    return EnemyRect.Intersects(PlayerRect,NULL) ;
}

#endif // ROLLINGENEMY_HPP
