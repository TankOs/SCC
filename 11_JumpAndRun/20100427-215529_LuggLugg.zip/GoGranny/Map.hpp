#ifndef MAP_HPP
#define MAP_HPP

#include <SFML/Graphics.hpp>
#include <vector>
#include <iostream>

class C_Tile
{
    public:

    C_Tile(bool solid, int PicID, int ID ) { this->solid = solid; this->ID = ID; this->PicID = PicID; }
    ~C_Tile() {}

    bool GetSolid() {return solid;}
    int  GetID()    {return ID;   }
    int  GetPicID() {return PicID;}


    private:

    bool solid;
    int PicID;
    int ID;
};

class C_Map
{
    public:

    C_Map ( sf::Vector2<float> ScreenSize );
    ~C_Map ();

    void Render(sf::RenderWindow &DrawHere);
    void Fluctuate(float HighPerSecond);
    float Update(float FrameTime);
    bool CreateMap(); // false if sth went wrong
    float GetLineHigh() {return LineHigh; }


    bool ResetLineHigh();

    private:

    bool LineVisible;

    float CurScroll;
    float MaxScroll;
    float ScrollSpeed;
    float FluctuateFactor;

    float LineVelocity;
    float LineHigh;
    float Scroll;
    float StartLineHigh;

    std::vector<C_Tile*> TileLine;
    sf::Vector2f ScreenSize;
    sf::Vector2f TileSize;

    sf::Image  ITiles;
    sf::Sprite  Tiles;


};


#endif //MAP_HPP
