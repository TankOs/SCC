
#include "Map.hpp"
#include "Granny.hpp"
#include "EnemyHandler.hpp"
#include "LevelHandler.hpp"
#include "AudioHandler.hpp"
#include <iostream>

#include <SFML/Graphics.hpp>

int main()
{

    bool DEAD  = false;

    sf::Clock NextLevelClock;
    bool Active = false;

    float CurScroll;
    short GetLevel = 0 ;

    sf::Vector2<int> ScreenSize;
    ScreenSize.x = 1024;
    ScreenSize.y = 600;

    sf::Vector2f fScreenSize;
    fScreenSize.x = 1024;
    fScreenSize.y = 600;

    sf::Image IBackground; IBackground.LoadFromFile("Background.png");
    sf::Sprite Background; Background.SetImage(IBackground);

    sf::Image ILevel; ILevel.LoadFromFile("Level.png");
    sf::Sprite Level; Level.SetImage(ILevel);

    // Create the main rendering window
    sf::RenderWindow App(sf::VideoMode(ScreenSize.x, ScreenSize.y, 32), "GoGranny");
    C_Map Map( fScreenSize );
    C_EnemyHandler EnemyHandler(fScreenSize);
    C_Granny Granny;
    C_LevelHandler LevelHandler;
    C_AudioHandler AudioHandler;

 //   void AddLevel(short RollingEnemysThisLevel, short SpikesThisLevel, float TimeForThisLevel, short MaxRollingEnemysAtOneTime);
    /*LevelHandler.AddLevel( 2, 1, 8, 1 );
    LevelHandler.AddLevel( 6, 2, 14, 2 );
    LevelHandler.AddLevel( 8, 8, 28, 2 );
    LevelHandler.AddLevel( 12, 6, 35, 3 );
    LevelHandler.AddLevel( 24, 12, 45, 4);
*/
    /// Set Functions

    const sf::Input &Input = App.GetInput() ;
    Map.CreateMap();

    /// Set Functions End

    // Start game loop
    while (App.IsOpened())
    {
        // Process events
        sf::Event Event;
        while (App.GetEvent(Event))
        {
            // Close window : exit
            if (Event.Type == sf::Event::Closed)
                App.Close();
        }

        /// Event AND UPDATE PART START

        if ( DEAD == false)
        {



        CurScroll = Map.Update(App.GetFrameTime());
        AudioHandler.Update(Input);

        EnemyHandler.Update( Map.GetLineHigh(), CurScroll , App.GetFrameTime());
        if ( ! Granny.Update(App.GetFrameTime(), Input, Map.GetLineHigh(), CurScroll ) )
        {
            DEAD = true;
        }
        //GetLevel = LevelHandler.Update(&Map, &EnemyHandler);

        if ( GetLevel != -1 )
        {
            Active = true;
            NextLevelClock.Reset();
        }

        if ( NextLevelClock.GetElapsedTime() > 1 )
        {
            Active = false;
        }


        EnemyHandler.Collide( &Granny);

        }

        /// Event and UPDATE PART END

        /// Render PART START

        // Clear the screen (fill it with black color)

        App.Clear();


        App.Draw(Background);
        Map.Render(App);
        EnemyHandler.Render(App);
        Granny.Render(App);

       /* if ( Active == true)
        {
            App.Draw(Level);
        } */

        /// Render PART END

        // Display window contents on screen
        App.Display();

    }

    std::cout << " The end my friend " << std::endl;

    return 0;
}
