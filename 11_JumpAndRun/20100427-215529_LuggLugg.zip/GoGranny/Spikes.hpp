#ifndef SPIKES_HPP
#define SPIKES_HPP

#include <SFML/Graphics.hpp>
#include <iostream>

class C_Spikes
{
public:
    C_Spikes(sf::Sprite *SpikeSprite, sf::Vector2f Position, float xScreenSize)  ;
    ~C_Spikes() {}

    bool Update( float LineHigh, float Scroll);
    void Render (sf::RenderWindow &DrawHere);
    bool Collide( C_Granny * Granny);
    void ImHit();

private:

    float xScreenSize;
    bool  SpawnedRight;
    bool Alive;

    sf::Sprite *SpikeSprite;

    sf::Vector2f Position;
    sf::Rect<int> SpikeRect;

};

C_Spikes::C_Spikes(sf::Sprite *SpikeSprite, sf::Vector2f Position, float xScreenSize)
{
    this->SpikeSprite = SpikeSprite;
    this->xScreenSize = xScreenSize;

    this->Position.x = Position.x;
    this->Position.y = Position.y;

    SpikeRect = SpikeSprite->GetSubRect();
    SpikeRect.Offset(Position.x, Position.y);
    SpikeSprite->SetPosition(Position);

    SpawnedRight = false;
    if ( Position.x > 0 )
    {
        SpawnedRight = true;
    }

    std::cout << this->Position.x  << " Position.x " << std::endl;


    Alive = true;
}

bool C_Spikes::Update( float LineHigh, float Scroll)
{
    float yOffset =  LineHigh - Position.y -32 ;
    Position.y = LineHigh - 32 ;
    Position.x += Scroll;

    SpikeRect.Offset(Scroll,yOffset);
    SpikeSprite->Move(Scroll,yOffset);

    if ( Position.x > xScreenSize + 32 && SpawnedRight == false )
    {
        return false;
    }

    else if ( Position.x < -32 && SpawnedRight == true )
    {
        return false;
    }

    else if ( Alive == false )
    {
        return false;
    }

    return true;

}

bool C_Spikes::Collide( C_Granny * Granny)
{

    sf::Rect<int> PlayerRect;
    sf::Vector2f GrannyPos;
    sf::Vector2i GrannySize;

    GrannyPos = Granny->GetPos();
    GrannySize = Granny->GetSize();

    PlayerRect.Top = PlayerRect.Bottom = GrannyPos.y;
    PlayerRect.Bottom += GrannySize.y;

    PlayerRect.Left = PlayerRect.Right = GrannyPos.x;
    PlayerRect.Right += GrannySize.x;

    SpikeRect = SpikeSprite->GetSubRect();
    SpikeRect.Offset(Position.x, Position.y);

    return SpikeRect.Intersects(PlayerRect,NULL) ;
}

void C_Spikes::Render (sf::RenderWindow &DrawHere)
{
    SpikeSprite->SetPosition(Position);
    DrawHere.Draw(*SpikeSprite);
}

void C_Spikes::ImHit()
{
    Alive = false;
}

#endif // SPIKES_HPP
