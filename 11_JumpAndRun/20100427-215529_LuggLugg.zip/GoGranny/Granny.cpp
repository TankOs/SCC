#include "Granny.hpp"

C_Granny::C_Granny()
{
    IGrannySprite.LoadFromFile("GrannyS.png");
    GrannySprite.SetImage(IGrannySprite);

    ILives.LoadFromFile("Live.png");
    Lives.SetImage(ILives);

    Anim.Init(&GrannySprite,10,2);

    FaceLeft = false;


    Waiting.Init(0,3,0,false);
    Walking.Init(4,9,1,false);
    Jumping.Init(11,13,2,false);
    HitTheGround.Init(11,11,3,true);
    Attack.Init(14,17,4,true);

    SCPS = 2.5;
    CurState = Waiting.GetStateID();
    Velocity = 0;

    LiveCount = 6;

    ImInvincible = true;
    Invincible.Reset();



}

void C_Granny::Render(sf::RenderWindow &DrawHere)
{
    short PicID = 0;
    sf::Vector2f LivePos;
    LivePos.x = LivePos.y = 0;

    if ( CurState == Waiting.GetStateID() )
    {
        PicID = Waiting.GetCurPicID();
    }

    else if ( CurState == Walking.GetStateID() )
    {
        PicID = Walking.GetCurPicID();
    }

    else if ( CurState == Jumping.GetStateID() )
    {
        PicID = Jumping.GetCurPicID();
    }

    else if ( CurState == HitTheGround.GetStateID() )
    {
        PicID = HitTheGround.GetCurPicID();
    }
    else if ( CurState == Attack.GetStateID() )
    {
         PicID = Attack.GetCurPicID();
    }

    if ( ImInvincible == false )
    {
        GrannySprite.SetBlendMode( sf::Blend::None );
        GrannySprite.SetBlendMode( sf::Blend::Alpha );

        Anim.Render(DrawHere, &Position, PicID);
    }
    else if ( ImInvincible == true)
    {
        GrannySprite.SetBlendMode( sf::Blend::Add );

        Anim.Render(DrawHere, &Position, PicID);
    }

    Anim.Flip  (FaceLeft);

    short n = 0;

    for ( n = 0; n < LiveCount; n++)
    {
        Lives.SetPosition(LivePos);
        LivePos.x += 128;
        DrawHere.Draw(Lives);
    }

}

bool C_Granny::Update(float FrameTime, const sf::Input &Input, float LineHigh, float Scroll)
{
    if ( LiveCount <= 0)
    {
        return false;
    }

    if ( Invincible.GetElapsedTime() > 1.0f && ImInvincible == true )
    {
        ImInvincible = false;
    }


    float FPS = 1/FrameTime;
    float Gap = LineHigh - this->LineHigh ;
    Gap*= FrameTime;
    this->LineHigh = LineHigh;
    AnimCount++;


    if ( FPS/SCPS < AnimCount)
    {

        AnimCount = 0;
        if ( CurState == Waiting.GetStateID())
        {
            Waiting.Update();
            Jumping.Reset();
        }
        else if ( CurState == Walking.GetStateID() )
        {
            Walking.Update();
            Jumping.Reset();
        }
        else if ( CurState == Jumping.GetStateID() )
        {
            if ( Jumping.GetPicEnd() != Jumping.GetCurPicID() )
            {
                Jumping.Update();
            }
        }
        else if ( CurState == HitTheGround.GetStateID() )
        {
            if (  HitTheGround.Update() == -100 )
            {
                CurState = Waiting.GetStateID();
                Jumping.Reset();
            }
        }
        else if (CurState == Attack.GetStateID() )
        {
            if ( Attack.Update() == -100)
            {
                CurState == Waiting.GetStateID();
            }
        }
    }




    if ( CurState == Waiting.GetStateID() ||
         CurState == Walking.GetStateID() ||
         CurState == Jumping.GetStateID() ||
         CurState == Attack.GetStateID()
    )
    {
        if ( Input.IsKeyDown(sf::Key::Left )   ) { Position.x -= 150*FrameTime; FaceLeft = true;  }
        if ( Input.IsKeyDown(sf::Key::Right)   ) { Position.x += 150*FrameTime; FaceLeft = false; }
        if ( CurState != Jumping.GetStateID()   ) { CurState = Walking.GetStateID();}

        if ( Input.IsKeyDown(sf::Key::Up   ) )
        {
            if ( OnSolidGround == true && Jumping.GetCurPicID() == Jumping.GetPicEnd()  )
            {
                Velocity -= 200;

                std::cout << "Dr�cke " <<std::endl;

                OnSolidGround = false;

            }
            CurState = Jumping.GetStateID();
        }

        if ( Input.IsKeyDown(sf::Key::Space ) && CurState != Jumping.GetStateID() )
        {

            CurState = Attack.GetStateID();
        }

    }


    if ( !Input.IsKeyDown(sf::Key::Left )  &&
         !Input.IsKeyDown(sf::Key::Right)  &&
         !Input.IsKeyDown(sf::Key::Up)     &&
         CurState != Attack.GetStateID()   &&
         CurState != HitTheGround.GetStateID() &&
         CurState != Jumping.GetStateID()  ) { CurState = Waiting.GetStateID(); }

         // Gravitiy

    if ( Position.y + 320 >= LineHigh - Gap   )
    {
        Position.y = LineHigh - 320;

        if ( OnSolidGround == false && Velocity > 0 && Jumping.GetCurPicID() == Jumping.GetPicEnd()   )
        {
            OnSolidGround = true;
            CurState = HitTheGround.GetStateID();

        }
        else if ( OnSolidGround == true && CurState != Jumping.GetStateID())
        {
            Velocity = 0;
        }
    }
    else if ( Jumping.GetCurPicID() == Jumping.GetPicEnd() || CurState != Jumping.GetStateID()&& Velocity > 0  )
    {
        OnSolidGround = false;
    }

    if ( OnSolidGround == false )
    {
        Velocity   += 98.1 * FrameTime;
        Position.y += Velocity * FrameTime;
    }

    Position.x += Scroll;

    return true;

}

bool C_Granny::AmIPunching()
{
    if ( CurState == Attack.GetStateID())
    {
        return true;
    }
    return false;
}
