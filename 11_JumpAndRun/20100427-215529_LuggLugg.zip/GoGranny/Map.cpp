#include "Map.hpp"

C_Map::C_Map (  sf::Vector2<float> ScreenSize )
{
    if (!ITiles.LoadFromFile("Tiles.png"))
    {
    std::cout << " Problem " << std::endl;
    }
    Tiles.SetImage(ITiles);

    TileSize = Tiles.GetSize();

    this->ScreenSize.x = ScreenSize.x;
    this->ScreenSize.y = ScreenSize.y;


    MaxScroll       = TileSize.x;
    CurScroll       = 0;
    ScrollSpeed     = 60;
    LineVelocity    = 0;
    FluctuateFactor = 0;

    LineHigh = ScreenSize.y ;
    LineHigh /= 3;
    LineHigh *= 2.6;

    StartLineHigh = LineHigh;
    LineVisible = true;
}

C_Map::~C_Map ()
{
    std::vector<C_Tile*>::const_iterator cii;
    for(cii= TileLine.begin(); cii!= TileLine.end(); cii++)
    {
        delete (*cii);
    }

}

float C_Map::Update(float FrameTime)
{



    Fluctuate(FluctuateFactor);
    if ( LineHigh < 0 && LineVisible == false )
    {
        LineVisible = true;
        FluctuateFactor*=-1;
    }

    else if ( LineHigh > ScreenSize.y && LineVisible == true )
    {
        LineVisible = false;
        FluctuateFactor*=-1;
    }

    CurScroll += FrameTime*ScrollSpeed;
    if ( CurScroll > MaxScroll )
    {
        CurScroll -= MaxScroll;
    }
    else if ( CurScroll < 0-MaxScroll)
    {
        CurScroll += MaxScroll;
    }

    // Line Velocity

    if ( LineVelocity > 0 )
    {
        LineVelocity -= 98.1 * FrameTime;
        if ( LineVelocity < 0 )
        {
            LineVelocity = 0;
        }
    }

    else if ( LineVelocity < 0 )
    {
        LineVelocity -= 9.81 * FrameTime;
        if ( LineVelocity > 0 )
        {
            LineVelocity = 0;
        }
    }

    LineHigh += LineVelocity*FrameTime;


    return FrameTime*ScrollSpeed;
}

bool C_Map::CreateMap()
{
    short ID = -1;

    C_Tile * Temp ;
    while ( ID * TileSize.x < ScreenSize.x + TileSize.x)
    {
        Temp = new C_Tile(true, sf::Randomizer::Random(0,0), ID);
        TileLine.push_back(Temp);
        ID++;
    }

    return true;
}

void C_Map::Render(sf::RenderWindow &DrawHere)
{
    sf::Vector2f TilePos;
    TilePos.y = LineHigh;

    std::vector<C_Tile*>::const_iterator cii;
    for(cii= TileLine.begin(); cii!= TileLine.end(); cii++)
    {

        TilePos.x = TileSize.x * (*cii)->GetID() +CurScroll ;
        Tiles.SetPosition(TilePos);
        DrawHere.Draw(Tiles);
    }
}

void C_Map::Fluctuate(float HighPerSecond)
{
    FluctuateFactor = HighPerSecond;
}

bool C_Map::ResetLineHigh()
{
    if ( LineHigh > StartLineHigh)
    {
        LineVelocity =  LineHigh - StartLineHigh ;
        LineVelocity *= -1;
    }
    else if ( LineHigh < StartLineHigh)
    {
        LineVelocity = StartLineHigh - LineHigh;
    }
    else
    {
        return true;
    }

    return false;
}
