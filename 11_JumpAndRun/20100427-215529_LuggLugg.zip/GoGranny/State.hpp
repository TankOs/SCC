#ifndef STATE_HPP_INCLUDED
#define STATE_HPP_INCLUDED

/*Handels the States of the Units */

class C_State
{
    public:
    C_State()  {}
    ~C_State() {}

    void Init(short PicBegin, short PicEnd, short StateID, bool WaitingAfterAnimEnd);
    short GetStateID()  { return StateID; }
    short GetCurPicID() { return CurPicID;}
    short GetPicEnd()   { return PicEnd;}
    short Update();
    void Reset() {  CurPicID = PicBegin;}

    private:

    bool WaitingAfterAnimEnd;


    short StateID;
    short PicBegin;
    short PicEnd;
    short CurPicID;
};



#endif // STATE_HPP_INCLUDED
