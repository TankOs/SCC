#ifndef GRANNY_HPP
#define GRANNY_HPP

#include "Anim.hpp"
#include "State.hpp"
#include <iostream>

class C_Granny
{
    public:
    C_Granny();
    ~C_Granny() {}

    bool Update(float FrameTime, const sf::Input &Input, float LingeHigh, float Scroll);
    void Render(sf::RenderWindow &DrawHere);

    bool ImHit()
    {
        if ( ImInvincible != true )
        {
            LiveCount--; Invincible.Reset();
            ImInvincible = true;
        }
        else
        {
            return false;
        }
        return true;
    }

    bool AmIPunching();

    const sf::Vector2<float> GetPos() { return Position;}
    const sf::Vector2<int> GetSize() { sf::Vector2i Size(320,320); return Size; }

    private:

    sf::Image IGrannySprite;
    sf::Sprite GrannySprite;

    sf::Image ILives;
    sf::Sprite Lives;

    sf::Vector2<float> Position;
    sf::Clock Invincible; //  you cant get two hits in less than a second

    C_Anim Anim;

    /// States Begin

    C_State Waiting;
    C_State Walking;
    C_State Jumping;
    C_State HitTheGround;
    C_State Attack;

    /// States End

    float Velocity;
    float LineHigh;

    bool FaceLeft;
    bool OnSolidGround;
    bool ImInvincible;
    short AnimCount;

    short SCPS; // sprite changes per second
    short CurState;
    short LiveCount;
};

#endif //GRANNY_HPP
