#ifndef AUDIOHANDLER_HPP
#define AUDIOHANDLER_HPP

#include <SFML/Audio.hpp>

class C_AudioHandler
{
    public:
    C_AudioHandler()
    {
        // Load a music to play
        bMusic.OpenFromFile("Data/Matilda.ogg");
        bMusic.Play();
        bMusic.SetLoop(true);

        MusicPlays = true;
        DownTime.Reset();
    }
    ~C_AudioHandler() {}

    void Update(const sf::Input &Input);


    private:

    bool MusicPlays;
    sf::Music bMusic;

    sf::Clock DownTime;

};

void C_AudioHandler::Update( const sf::Input &Input)
{
    if ( Input.IsKeyDown(sf::Key::P ) && DownTime.GetElapsedTime() > 0.5 )
    {
        if (MusicPlays == false)
        {
            bMusic.Play();
            MusicPlays = true;
        }
        else
        {
            bMusic.Pause();
            MusicPlays = false;
        }

        ;
        DownTime.Reset();
    }


}



#endif // AUDIOHANDLER_HPP



