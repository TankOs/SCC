#include "Anim.hpp"

C_Anim::C_Anim() {}

void C_Anim::Init(sf::Sprite *pAnimSprite, short xLines, short yLines)
{
    UnitPic = pAnimSprite;

    this->xLines = xLines;
    this->yLines = yLines;

    sf::Vector2<float> FullSize;
    UnitPicSize = pAnimSprite->GetSize();
    FullSize    = pAnimSprite->GetSize();

    UnitPicSize.x /= xLines ;
    UnitPicSize.y /= yLines ;

    PlayerRect.Top    = 0;
    PlayerRect.Left   = 0;
    PlayerRect.Right  = static_cast<int> (UnitPicSize.x);
    PlayerRect.Bottom = static_cast<int> (UnitPicSize.y);

    FullRect.Top    = 0;
    FullRect.Left   = 0;
    FullRect.Right  = static_cast<int> (FullSize.x);
    FullRect.Bottom = static_cast<int> (FullSize.y);

}

void C_Anim::Render(sf::RenderWindow &DrawHere, sf::Vector2<float> *Position, short PicID)
{
    short yLine = 0 ;  // PicId becomes xLine after if

    while ( PicID > xLines )
    {
        PicID -= xLines;
        yLine++;
    }

    sf::Vector2<int> Offset(PlayerRect.Right *PicID, PlayerRect.Bottom *yLine);

    PlayerRect.Offset(Offset.x,Offset.y );

    UnitPic->SetSubRect(PlayerRect);
    Offset.x *= -1; Offset.y *= -1;
    PlayerRect.Offset(Offset.x,Offset.y);

    UnitPic->SetPosition(Position->x , Position->y);
    DrawHere.Draw(*UnitPic);

    UnitPic->SetSubRect(FullRect); // important to prevent collision bugs with an other class using the same sprite
}

void C_Anim::Flip(bool Left)
{
    UnitPic->FlipX(Left);
}

sf::Vector2<float> * C_Anim::GetPicSize()
{
    return &UnitPicSize;
}
