#ifndef ENEMYHANDLER_HPP
#define ENEMYHANDLER_HPP

#include "Spikes.hpp"
#include "RollingEnemy.hpp"
#include "Granny.hpp"
#include <list>

class C_EnemyHandler
{
public:

    C_EnemyHandler(sf::Vector2f ScreenSize);
    ~C_EnemyHandler();

    void Update( float LineHigh, float Scroll, float FrameTime );
    void SetNumberOfRollingEnemys( short NumOfRE );
    void SetNumberOfMaxSpikes   ( short MaxSpikes );
    void SetNumberOfTotal( short TotalResThisLevel, short TotalSpikesThisLevel);

    short GetNumberOfREs()
    {
        return REnemyCount;
    }
    short GetNumberOfSpikes()
    {
        return SpikeCount;
    }
    void Render(sf::RenderWindow &DrawHere);
    bool Collide( C_Granny *Granny);


private:

    void CreateSpikes       ( sf::Vector2f Position );
    void CreateRollingEnemy ( sf::Vector2f Position );

    short SpikeCount;      short REnemyCount;
    short MaxSpikes;
    short LevelReCount;    short LevelSpikeCount;
    short MaxRes;

    float DistanceSinceLastSpike;
    float DistanceSinceLastRE;

    sf::Vector2f ScreenSize;

    sf::Image ISpikeSprite;
    sf::Sprite SpikeSprite;

    sf::Image IReSprite;
    sf::Sprite ReSprite;

    std::list<C_Spikes*> Spikes;
    std::list<C_Spikes*>::iterator Sp;

    std::list<C_RollingEnemy*> REnemys;
    std::list<C_RollingEnemy*>::iterator Re;

};

C_EnemyHandler::C_EnemyHandler(sf::Vector2f ScreenSize)
{
    this->ScreenSize.x = ScreenSize.x;
    this->ScreenSize.y = ScreenSize.y;

    ISpikeSprite.LoadFromFile( "Spikes.png");
    SpikeSprite.SetImage(ISpikeSprite);

    IReSprite.LoadFromFile("Enemy.png");
    ReSprite.SetImage(IReSprite);

    SpikeCount = 0;
    REnemyCount = 0;

    LevelSpikeCount = 45;
    LevelReCount = 45;


    MaxSpikes = 2;  /// CHANGE ME
    MaxRes    = 5;

    DistanceSinceLastSpike = 0;
    DistanceSinceLastRE = 0;
}

C_EnemyHandler::~C_EnemyHandler()
{
    for (Sp = Spikes.begin(); Sp != Spikes.end(); Sp++)
    {
        delete (*Sp);
        *Sp = NULL;
    }
}

void C_EnemyHandler::CreateSpikes ( sf::Vector2f Position )
{
    C_Spikes * Temp;
    Temp = new C_Spikes(&SpikeSprite, Position, ScreenSize.x);

    Spikes.push_back(Temp);

    SpikeCount++;
}

void C_EnemyHandler::CreateRollingEnemy( sf::Vector2f Position)
{
    C_RollingEnemy * Temp;
    Temp = new C_RollingEnemy(&ReSprite, Position, ScreenSize.x);

    REnemys.push_back(Temp);

    REnemyCount++;

}

void C_EnemyHandler::Update( float LineHigh, float Scroll, float FrameTime )
{
    sf::Vector2f Position;

    DistanceSinceLastSpike += Scroll;
    DistanceSinceLastRE += Scroll;

//    std::cout << "SpikeCount : " << SpikeCount << " MaxSpikes " << MaxSpikes << std::endl;

    if ( SpikeCount < MaxSpikes && LevelSpikeCount >= 1 && Scroll != 0 )
    {
        if ( DistanceSinceLastSpike > 320.0f * 1.5f ||  DistanceSinceLastSpike < -320.0f * 1.5f )
        {

            DistanceSinceLastSpike = 0;

            Position.y = LineHigh+32;

            if ( Scroll > 0)
            {
                Position.x = -32;
            }

            else if ( Scroll <0 )
            {
                Position.x = ScreenSize.x + 32;
            }
            CreateSpikes( Position );
            LevelSpikeCount--;
        }

    }

    if ( REnemyCount <= MaxRes && LevelReCount >= 1 && LevelReCount >= 2 &&  Scroll != 0  )
    {

        if ( DistanceSinceLastRE < -320.0f * 1.5f ||  DistanceSinceLastRE > 320.0f * 1.5f )
        {
        DistanceSinceLastRE = 0;

        Position.y = LineHigh;
        if ( Scroll < 0)
        {
            Position.x = - 2*128;
        }
        CreateRollingEnemy( Position) ;
        LevelReCount--;
        }
    }

    for (Sp = Spikes.begin(); Sp != Spikes.end(); Sp++)
    {
        if ((*Sp)->Update(LineHigh,Scroll) == false )
        {
            delete (*Sp);
            (*Sp) = NULL;

            Spikes.erase(Sp);
            Sp = Spikes.end();
            SpikeCount--;
        }
    }

    for (Re = REnemys.begin(); Re != REnemys.end(); Re++)
    {
        if ( !(*Re)->Update(LineHigh,Scroll,FrameTime))
        {
            delete (*Re);
            (*Re) = NULL;

            REnemys.erase(Re);
            Re = REnemys.end();
            REnemyCount--;
        }
    }
}

void C_EnemyHandler::Render(sf::RenderWindow &DrawHere)
{
    for (Sp = Spikes.begin(); Sp != Spikes.end(); Sp++)
    {
        (*Sp)->Render(DrawHere);
    }

    for (Re = REnemys.begin(); Re != REnemys.end(); Re++)
    {
        (*Re)->Render(DrawHere);
    }

}

bool C_EnemyHandler::Collide( C_Granny *Granny)
{
    for (Sp = Spikes.begin(); Sp != Spikes.end(); Sp++)
    {
        if ((*Sp)->Collide ( Granny ) == true )
        {
            if ( Granny->ImHit() == true)
            {
                (*Sp)->ImHit();
            }
        }
    }

    for (Re = REnemys.begin(); Re != REnemys.end(); Re++)
    {
        if ( (*Re)->Collide(Granny) == true )
        {
            if ( Granny->AmIPunching() == false)
            {
                Granny->ImHit();
            }
            else
            {
                (*Re)->ImHit();
            }
        }
    }
    return true;
}

void C_EnemyHandler::SetNumberOfMaxSpikes ( short MaxSpikes )
{
    this->MaxSpikes = MaxSpikes;
}

void C_EnemyHandler::SetNumberOfTotal( short TotalResThisLevel, short TotalSpikesThisLevel)
{
    this->LevelReCount    = TotalResThisLevel;
    this->LevelSpikeCount = TotalSpikesThisLevel;
}

void C_EnemyHandler::SetNumberOfRollingEnemys ( short MaxRes )
{
    this->MaxRes = MaxRes;

}

#endif // ENEMYHANDLER_HPP
