Zum anfangen die nach oben Pfeiltaste gedr�ckt halten

Pfeiltasten : Laufen
Space : Schlagen
P : Musik Aus / An

Vielen dank an Floyd Blue f�r die Musik !
