#ifndef LEVELHANDLER_HPP
#define LEVELHANDLER_HPP

#include <SFML/System.hpp>
#include <list>

#include "Map.hpp"
#include "EnemyHandler.hpp"

class C_Level
{
public:

    C_Level( short ID, short RollingEnemysThisLevel, short SpikesThisLevel, float TimeForThisLevel, short MaxRollingEnemysAtOneTime  ) {}
    ~C_Level(){}

    void LevelStart( )
    {
        Clock.Reset();
    };
    bool Update()
    // retunrs false if the next lvl should start
    {
        if ( Clock.GetElapsedTime() > TimeForThisLevel )
        {
            return false;
        }
        return true;
    }

    short GetID()
    {
        return ID;
    }
    short GetNumberOfRollingEnemys()
    {
        return RollingEnemysThisLevel;
    }
    short GetNumberOfSpikes()
    {
        return SpikesThisLevel;
    }

    short GetMaxRollingEnemysAtOneTime()
    {
        return MaxRollingEnemysAtOneTime;
    }

private:

    short ID;

    short SpikesThisLevel;
    short RollingEnemysThisLevel;
    short MaxRollingEnemysAtOneTime;
    float TimeForThisLevel;


    sf::Clock Clock;

};



class C_LevelHandler
{
public:

    C_LevelHandler()
    {
        TotalLevels = 0;
        CurLevel = 0;
        LevelStarted = false;
        Break = false;
    }
    ~C_LevelHandler();

    void AddLevel(short RollingEnemysThisLevel, short SpikesThisLevel, float TimeForThisLevel, short MaxRollingEnemysAtOneTime);
    short Update( C_Map * Map, C_EnemyHandler *EnemyHandler );

private:

    short GetNumberOfRollingEnemys();
    short GetNumberOfSpikes();
    short GetMaxRollingEnemysAtOneTime();

    std::list<C_Level*> Levels;
    std::list<C_Level*>::iterator Lv;

    short TotalLevels;
    short CurLevel;

    bool Break;
    bool LevelStarted;

};

C_LevelHandler::~C_LevelHandler()
{
    for ( Lv = Levels.begin(); Lv != Levels.end(); Lv++)
    {
        delete (*Lv);
        *Lv = NULL;
    }
}


void C_LevelHandler::AddLevel(short RollingEnemysThisLevel, short SpikesThisLevel, float TimeForThisLevel, short MaxRollingEnemysAtOneTime)
{
    C_Level * Temp;
    Temp = new C_Level(TotalLevels, RollingEnemysThisLevel, SpikesThisLevel, TimeForThisLevel, MaxRollingEnemysAtOneTime);

    Levels.push_back(Temp);

    TotalLevels++;
}

short C_LevelHandler::GetNumberOfRollingEnemys()
{
    for ( Lv = Levels.begin(); Lv != Levels.end(); Lv++)
    {
        if ( CurLevel = (*Lv)->GetID() )
        {
            return (*Lv)->GetNumberOfRollingEnemys();
        }
    };

    return -1;
}

short C_LevelHandler::GetNumberOfSpikes()
{
    for ( Lv = Levels.begin(); Lv != Levels.end(); Lv++)
    {
        if ( CurLevel = (*Lv)->GetID() )
        {
            return GetNumberOfSpikes() ;
        }
    };

    return -1;
}

short C_LevelHandler::GetMaxRollingEnemysAtOneTime()
{
    for ( Lv = Levels.begin(); Lv != Levels.end(); Lv++)
    {
        if ( CurLevel = (*Lv)->GetID() )
        {
            return (*Lv)->GetMaxRollingEnemysAtOneTime();
        }
    };

    return -1;
}

short C_LevelHandler::Update( C_Map * Map, C_EnemyHandler * EnemyHandler )
{



    if ( LevelStarted == false && CurLevel <= TotalLevels  )
    {
        std::cout << CurLevel << std::endl;
        LevelStarted = true;
        CurLevel++;
        for ( Lv = Levels.begin(); Lv != Levels.end(); Lv++)
        {
        if ( CurLevel = (*Lv)->GetID() )
        {
            Map->Fluctuate(0);

            (*Lv)->LevelStart();
            return CurLevel;

        }
        }
    }

    for ( Lv = Levels.begin(); Lv != Levels.end(); Lv++)
    {
        if ( CurLevel = (*Lv)->GetID() )
        {
            if (  (*Lv)->Update() == false )
            {
                Break = true;
                LevelStarted = false;
            }
        }
    }

    if ( Break == true )
    {

        if ( EnemyHandler->GetNumberOfREs() != 0 )
        {
            Map->Fluctuate(0);
        }

        else
        {
            Break = false;

        }
    }
    return -1;


}

#endif // LEVELHANDLER_HPP
