#include "State.hpp"

void C_State::Init (short PicBegin, short PicEnd, short StateID, bool WaitingAfterAnimEnd)
{
    this->PicBegin = PicBegin;
    this->PicEnd   = PicEnd;
    this->StateID  = StateID;
    this->CurPicID = PicBegin;
    this-> WaitingAfterAnimEnd = WaitingAfterAnimEnd;
}

short C_State::Update()
{
    CurPicID++;
    if ( CurPicID > PicEnd )
    {
        if ( WaitingAfterAnimEnd == true)
        {
            CurPicID = PicBegin;
            return -100;
        }
        else
        {
            CurPicID = PicBegin;
        }
    }
    return CurPicID;
}
