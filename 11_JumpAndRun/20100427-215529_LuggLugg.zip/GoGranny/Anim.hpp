#ifndef ANIM_HPP
#define ANIM_HPP

#include <SFML/Graphics.hpp>

class C_Anim
{
    public:
    C_Anim();
    ~C_Anim() {}
    void Init   (sf::Sprite *pAnimSprite, short xLines, short yLines);
    void Render (sf::RenderWindow &DrawHere, sf::Vector2<float> *Position, short PicID);
    void Flip   (bool Left );
    sf::Vector2<float> * GetPicSize();

    private:

    short xLines;
    short yLines;

    sf::Sprite        *UnitPic;
    sf::Vector2<float> UnitPicSize;
    sf::Rect<int>      FullRect;
    sf::Rect<int>      PlayerRect;
};

#endif // ANIM_HPP
