#include <iostream>
#include <vector>
#include <set>
#include <ctime>

enum Direction {
	North = 0,
	East,
	South,
	West,
	Giveup
};

#if defined( _WIN32 ) || defined( __WIN32__ )
	#define EXPORT __declspec( dllexport )
#else
	#define EXPORT
#endif

unsigned int  MazeSize( 0 );
unsigned int  XPos( 0 );
unsigned int  YPos( 0 );

Direction LastDir = Giveup;
std::vector<std::vector<std::set<Direction>>> Cache;
bool WayBack = false;

Direction ToNorth() {
	Cache[XPos][YPos].insert(North);
	--YPos;
	LastDir = North;
	return(North);
}
Direction ToSouth() {
	Cache[XPos][YPos].insert(South);
	++YPos;
	LastDir = South;
	return(South);
}
Direction ToWest() {
	Cache[XPos][YPos].insert(West);
	--XPos;
	LastDir = West;
	return(West);
}
Direction ToEast() {
	Cache[XPos][YPos].insert(East);
	++XPos;
	LastDir = East;
	return(East);
}
Direction Move(Direction D) {
	switch(D) {
		case North:
			return(ToNorth());
		case South:
			return(ToSouth());
		case West:
			return(ToWest());
		case East:
			return(ToEast());
		default:
			return(Giveup);
	}
}
Direction Anti(Direction D) {
	switch(D) {
		case North:
			return(South);
		case West:
			return(East);
		case South:
			return(North);
		case East:
			return(West);
		default:
			return(D);
	}
}

extern "C" {

/** Wird beim Laden der DLL gerufen.
 * @param size Wurzel der Größe des Labyrinths (Labyrinth ist immer ein Quadrat).
 * @param xpos X-Startposition.
 * @param ypos Y-Startposition.
 * @return Gebe true zurück, wenn alles okay ist.
 */
bool EXPORT Init( unsigned int size, unsigned int xpos, unsigned int ypos ) {
	std::srand(std::time(NULL));
	MazeSize = size;
	XPos = xpos;
	YPos = ypos;

	Cache.resize(size);
	for(std::vector<std::vector<std::set<Direction>>>::iterator i = Cache.begin(); i != Cache.end(); ++i) {
		i->resize(size);
	}

	return(true);
}

/** Wird nach jeder Bewegung und zu Beginn gerufen.
 * @param north true, falls die Bewegung Richtung Norden nicht möglich ist.
 * @param east true, falls die Bewegung Richtung Osten nicht möglich ist.
 * @param south true, falls die Bewegung Richtung Süden nicht möglich ist.
 * @param west true, falls die Bewegung Richtung Westen nicht möglich ist.
 */
Direction EXPORT Touch(bool north, bool east, bool south, bool west) {
	std::set<Direction> Dirs;
	if(!north) Dirs.insert(North);
	if(!east) Dirs.insert(East);
	if(!west) Dirs.insert(West);
	if(!south) Dirs.insert(South);

	if(Dirs.size() == 0) {
		return(Giveup);
	}
	if(Dirs.size() == 1) {
		return(Move(*Dirs.begin()));
	}
	else {
		if(Cache[XPos][YPos].size() == Dirs.size()) {
START:
			unsigned int temp = std::rand() % Dirs.size();
			std::set<Direction>::iterator it = Dirs.begin();
			for(int i = 0; i < temp; ++i) {
				++it;
			}
			if(*it == Anti(LastDir)) {
				goto START;
			}
			return(Move(*it));
		}
		else {
			for(std::set<Direction>::iterator i = Dirs.begin(); i != Dirs.end(); ++i) {
				if(Cache[XPos][YPos].find(*i) == Cache[XPos][YPos].end() && Anti(LastDir) != *i) {
					return(Move(*i));
				}
			}
			for(std::set<Direction>::iterator i = Dirs.begin(); i != Dirs.end(); ++i) {
				if(Cache[XPos][YPos].find(*i) == Cache[XPos][YPos].end()) {
					return(Move(*i));
				}
			}
		}
	}
	return(Giveup);
}

}
