/**
 * PLEASE NOTE:
 * This code has been hacked in QUICKLY. Don't expect software-technical
 * wonders here.
 */
#if defined( _WIN32 ) || defined( __WIN32__ ) || defined( _NERV_NICH_ )
#define WIN
#endif

#include <SFML/Graphics.hpp>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include "../../lib/src/Constants.hpp"

#ifdef WIN
#include <windows.h>
#define FreeLib( handle ) FreeLibrary( handle )
#else
#include <dlfcn.h>
#define FreeLib( handle ) dlclose( handle )
#endif

/** Hopefully god will forgive me for such an evil hack.
 */
union H4X0R {
	void*      Fux0r;
	bool       (*Init)( unsigned int, unsigned int, unsigned int );
	Direction  (*Touch)( bool, bool, bool, bool );
};

struct Hint {
	Hint() :
		Block( false ),
		Visited( false )
	{}

	bool  Block;
	bool  Visited;
};

typedef std::vector<Hint>  MazeArray;

const unsigned int  ScreenWidth( 800 );
const unsigned int  ScreenHeight( 600 );

int main() {
	// Try to open shared library.
#ifdef WIN
	HMODULE  libhandle( LoadLibrary( "../lib/solver.dll" ) );
#else
	void*  libhandle( dlopen( "../lib/libsolver.so", RTLD_LAZY ) );
#endif

	if( !libhandle ) {
		std::cerr << "Konnte Solver-Bibliothek nicht öffnen!" << std::endl;
		return 1;
	}

	// Clear error and get symbols.
	H4X0R         initfunc;
	H4X0R         touchfunc;
	unsigned int  numerrors( 0 );

#ifdef WIN
	initfunc.Fux0r = (void*)GetProcAddress( libhandle, "Init" );
	touchfunc.Fux0r = (void*)GetProcAddress( libhandle, "Touch" );
	if( !initfunc.Fux0r || !touchfunc.Fux0r ) {
		numerrors = 1337;
	}
#else
	dlerror();
	initfunc.Fux0r = dlsym( libhandle, "Init" );
	numerrors += dlerror() != 0 ? 1 : 0;

	touchfunc.Fux0r = dlsym( libhandle, "Touch" );
	numerrors += dlerror() != 0 ? 1 : 0;
#endif

	if( numerrors ) {
		FreeLib( libhandle );
		std::cerr << "Konnte einige benötigte Funktionen nicht in der Bibliothek finden!" << std::endl;
		return 1;
	}

	unsigned int  xpos( 0 );
	unsigned int  ypos( 0 );
	unsigned int  destx( 0 );
	unsigned int  desty( 0 );
	unsigned int  size( 10 );
	MazeArray     maze;

	{
		std::ifstream      fin( "data/contest.maze" );
		std::string        line;
		std::stringstream  sstr;

		if( !fin.is_open() ) {
			FreeLib( libhandle );
			std::cerr << "Konnte Maze nicht laden." << std::endl;
			return 1;
		}

		std::getline( fin, line );
		sstr.str( line );
		sstr >> size;

		maze.resize( size * size );

		for( unsigned int row = 0; row < size; ++row ) {
			std::getline( fin, line );

			for( unsigned int col = 0; col < size; ++col ) {
				switch( line[col] ) {
					case 'S':
						xpos = col;
						ypos = row;
						break;

					case 'Z':
						destx = col;
						desty = row;
						break;

					case 'X':
						maze[row * size + col].Block = true;
						break;

					case '.':
					default:
						maze[row * size + col].Block = false;
						break;
				}
			}
		}

		fin.close();
	}

	if( !(*initfunc.Init)( size, xpos, ypos ) ) {
		FreeLib( libhandle );
		std::cerr << "Bibliothek möchte nicht. :-(" << std::endl;
		return 1;
	}

	sf::RenderWindow  window( sf::VideoMode( ScreenWidth, ScreenHeight, 32 ), "Maze-GUI" );
	sf::Event         event;
	sf::String        infostr( L"ESC drücken zum Beenden." );
	sf::String        gameoverstr( L":-(" );
	Direction         result( North );
	unsigned int      steps( 0 );
	bool              showend( false );
	bool              moveerror( false );
	float             rectwidth( static_cast<float>( std::min( ScreenHeight, ScreenWidth ) ) / static_cast<float>( size ) );
	float             rectheight( static_cast<float>( std::min( ScreenHeight, ScreenWidth ) ) / static_cast<float>( size ) );

	window.UseVerticalSync( true );
	gameoverstr.SetPosition( 20, 100 );

	while( window.IsOpened() ) {

		while( window.GetEvent( event ) ) {
			switch( event.Type ) {
				case sf::Event::Closed:
					window.Close();
					break;

				case sf::Event::KeyPressed:
					if( event.Key.Code == sf::Key::Escape ) {
						window.Close();
					}
					break;

				default:
					break;
			}
		}

		if( !showend ) {
			result = (*touchfunc.Touch)(
				ypos == 0 || maze[(ypos - 1) * size + xpos].Block,
				xpos >= size - 1 || maze[ypos * size + xpos + 1].Block,
				ypos >= size - 1 || maze[(ypos + 1) * size + xpos].Block,
				xpos == 0 || maze[ypos * size + xpos - 1].Block
			);

			++steps;
			maze[ypos * size + xpos].Visited = true;

			switch( result ) {
				case North:
					if( ypos == 0 ) {
						moveerror = true;
						break;
					}

					--ypos;
					break;

				case East:
					if( xpos >= size - 1 ) {
						moveerror = true;
						break;
					}

					++xpos;
					break;

				case South:
					if( ypos >= size - 1 ) {
						moveerror = true;
						break;
					}

					++ypos;
					break;

				case West:
					if( xpos == 0 ) {
						moveerror = true;
						break;
					}

					--xpos;
					break;

				case Giveup:
					gameoverstr.SetText( L"Bibi hat aufgegeben und will nicht mehr. :-(" );
					showend = true;
					break;

				default:
					break;
			}

			std::stringstream  sstr;
			sstr << "Schritte: " << steps;
			infostr.SetText( sstr.str() );

			if( moveerror ) {
				gameoverstr.SetText( L"Bibi ist aus dem Level gefallen." );
				showend = true;
			}
			else if( !showend ) {
				if( maze[ypos * size + xpos].Block == true ) {
					gameoverstr.SetText( L"Bibi läuft gegen die Wand." );
					showend = true;
				}
				else if( xpos == destx && ypos == desty ) {
					gameoverstr.SetText( L"Bibi hat das Ziel erreicht!" );
					showend = true;
				}
			}
		}

		window.Clear();

		for( unsigned int y = 0; y < size; ++y ) {
			for( unsigned int x = 0; x < size; ++x ) {
				sf::Color  color( 80, 80, 80 );

				if( x == xpos && y == ypos ) {
					color.r = 255;
					color.g = 255;
					color.b = 0;
				}
				else if( maze[y * size + x].Block ) {
					color.r = 255;
			}
				else if( maze[y * size + x].Visited ) {
					color.r = color.g = color.b = 140;
				}
				else if( x == destx && y == desty ) {
					color.r = 0;
					color.g = 255;
					color.b = 255;
				}

				sf::Shape  rect(
					sf::Shape::Rectangle(
						static_cast<float>( x ) * rectwidth,
						static_cast<float>( y ) * rectheight,
						static_cast<float>( x + 1 ) * rectwidth - 1.f,
						static_cast<float>( y + 1 ) * rectheight - 1.f,
						color
					)
				);

				window.Draw( rect );
			}
		}

		window.Draw( infostr );

		if( showend ) {
			window.Draw( gameoverstr );
		}

		window.Display();
	}

	FreeLib( libhandle );
	return 0;
}
