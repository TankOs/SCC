#ifndef __CONSTANTS_HPP__
#define __CONSTANTS_HPP__

enum Direction {
	North = 0,
	East,
	South,
	West,
	Giveup
};

#endif
