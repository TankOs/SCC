#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include "Constants.hpp"
#include <vector>
#include <list>

#if defined( _WIN32 ) || defined( __WIN32__ )
#define EXPORT __declspec( dllexport )
#else
#define EXPORT
#endif
#include <iostream>
unsigned int  MazeSize = 0;
unsigned int  XPos = 0;
unsigned int  YPos = 0;

#include <stdio.h>

class field
{
	public:
		void SetSize(const unsigned int x, const unsigned int y)
		{
			array.resize(x);
			for(unsigned int x0=0;x0<x;x0++)
			{
				array[x0].resize(y);
			}
		}
		void Set(const unsigned int x, const unsigned int y, const char c)
		{
			array[x][y] = c;
		}
		char Get(const unsigned int x, const unsigned int y)
		{
			if((x < array.size()) && (y < array[x].size()))
			{
				if(array[x][y] == 'S')
					return '-';
				return array[x][y];
			}
			else return 'X';
		}
		void Draw()
		{
			for(unsigned int y=0;y<array[0].size();y++)
			{
				for(unsigned int x=0;x<array.size();x++)
				{
					printf("%c",array[x][y]);
				}
				printf("\n");
			}
		}
		void Update(unsigned int XPos, unsigned int YPos, bool north, bool east, bool south, bool west)
		{
			if(this->Get(XPos,YPos)!='S') this->Set(XPos,YPos,'-');
			if(XPos < array.size() - 1)
			{
				if(this->Get(XPos+1,YPos) == '\?')
				{
					if(east) this->Set(XPos+1,YPos,'X');
					else this->Set(XPos+1,YPos,'.');
				}
			}
			if(YPos > 0)
			{
				if(this->Get(XPos,YPos-1) == '\?')
				{
					if(north) this->Set(XPos,YPos-1,'X');
					else this->Set(XPos,YPos-1,'.');
				}
			}
			if(XPos > 0)
			{
				if(this->Get(XPos-1,YPos) == '\?')
				{
					if(west) this->Set(XPos-1,YPos,'X');
					else this->Set(XPos-1,YPos,'.');
				}
			}
			if(YPos < array[0].size() - 1)
			{
				if(this->Get(XPos,YPos+1) == '\?')
				{
					if(south) this->Set(XPos,YPos+1,'X');
					else this->Set(XPos,YPos+1,'.');
				}
			}
		}
		bool PossibleToGo(unsigned int _XPos, unsigned int _YPos, Direction dir)
		{
			switch(dir)
			{
				case North:
					if(this->Get(_XPos,_YPos-1)!='X')
						return true;
					break;
				case East:
					if(this->Get(_XPos+1,_YPos)!='X')
						return true;
					break;
				case South:
					if(this->Get(_XPos,_YPos+1)!='X')
						return true;
					break;
				case West:
					if(this->Get(_XPos-1,_YPos)!='X')
						return true;
					break;
				default:
					break;
			};
			return false;
		}
		bool PossibleToGoAndNotVisited(unsigned int _XPos, unsigned int _YPos, Direction dir)
		{
			if(this->PossibleToGo(_XPos,_YPos,dir))
			{
				switch(dir)
				{
					case North:
						if(this->Get(_XPos,_YPos-1)!='-')
							return true;
						break;
					case East:
						if(this->Get(_XPos+1,_YPos)!='-')
							return true;
						break;
					case South:
						if(this->Get(_XPos,_YPos+1)!='-')
							return true;
						break;
					case West:
						if(this->Get(_XPos-1,_YPos)!='-')
							return true;
						break;
					default:
						break;
				};
			}
			return false;
		}
	private:
		std::vector< std::vector<char> > array;
};

static field knownfield;
static Direction last_direction=Giveup;
static std::vector<Direction> directionstogo;

extern "C"
{

/** Wird beim Laden der DLL gerufen.
 * @param size Wurzel der Größe des Labyrinths (Labyrinth ist immer ein Quadrat).
 * @param xpos X-Startposition.
 * @param ypos Y-Startposition.
 * @return Gebe true zurück, wenn alles okay ist.
 */
bool EXPORT Init(unsigned int size, unsigned int xpos, unsigned int ypos)
{
	MazeSize = size;
	XPos = xpos;
	YPos = ypos;

	knownfield.SetSize(size,size);
	for(unsigned int x=0;x<size;x++)
	{
		for(unsigned int y=0;y<size;y++)
		{
			knownfield.Set(x,y,'\?');
		}
	}

	knownfield.Set(XPos,YPos,'S');

	return true;
}

Direction next_direction_in_circle(Direction first_direction, Direction curr_direction)
{
	switch(curr_direction)
	{
		case North:
			if(first_direction == West) return Giveup;
			else return West;
		case East:
			if(first_direction == North) return Giveup;
			else return North;
		case South:
			if(first_direction == East) return Giveup;
			else return East;
		case West:
			if(first_direction == South) return Giveup;
			else return South;
		default:
			return North;
	};
}

struct pos
{
	unsigned int x;
	unsigned int y;
};

struct edge
{
	pos start;
	pos end;
	unsigned long int cost;
};

const unsigned long int infinity = 0x7FFF; /* something big */

bool inbounds(edge &this_edge)
{
	if((this_edge.start.x < MazeSize)&&(this_edge.start.y < MazeSize))
	{
		if((this_edge.end.x < MazeSize)&&(this_edge.end.y < MazeSize))
		{
			return true;
		}
	}
	return false;
}


std::vector<edge> get_edges(field &knownfield)
{
	std::vector<edge> Edges;
	edge new_edge;
	for(unsigned int x=0;x<MazeSize;x++)
	{
		for(unsigned int y=0;y<MazeSize;y++)
		{
			new_edge.start.x = x;
			new_edge.start.y = y;
			if(knownfield.PossibleToGoAndNotVisited(new_edge.start.x,new_edge.start.y,North))
			{
				new_edge.end.x = new_edge.start.x;
				new_edge.end.y = new_edge.start.y - 1;
				new_edge.cost = 5;
			}
			else if(knownfield.PossibleToGo(new_edge.start.x,new_edge.start.y,North))
			{
				new_edge.end.x = new_edge.start.x;
				new_edge.end.y = new_edge.start.y - 1;
				new_edge.cost = 10;
			}
			else
			{
				new_edge.end.x = new_edge.start.x;
				new_edge.end.y = new_edge.start.y - 1;
				new_edge.cost = infinity;
			}
			Edges.push_back(new_edge);
			if(knownfield.PossibleToGoAndNotVisited(new_edge.start.x,new_edge.start.y,East))
			{
				new_edge.end.x = new_edge.start.x + 1;
				new_edge.end.y = new_edge.start.y;
				new_edge.cost = 5;
			}
			else if(knownfield.PossibleToGo(new_edge.start.x,new_edge.start.y,East))
			{
				new_edge.end.x = new_edge.start.x + 1;
				new_edge.end.y = new_edge.start.y;
				new_edge.cost = 10;
			}
			else
			{
				new_edge.end.x = new_edge.start.x + 1;
				new_edge.end.y = new_edge.start.y;
				new_edge.cost = infinity;
			}
			Edges.push_back(new_edge);
			if(knownfield.PossibleToGoAndNotVisited(new_edge.start.x,new_edge.start.y,South))
			{
				new_edge.end.x = new_edge.start.x;
				new_edge.end.y = new_edge.start.y + 1;
				new_edge.cost = 5;
			}
			else if(knownfield.PossibleToGo(new_edge.start.x,new_edge.start.y,South))
			{
				new_edge.end.x = new_edge.start.x;
				new_edge.end.y = new_edge.start.y + 1;
				new_edge.cost = 10;
			}
			else
			{
				new_edge.end.x = new_edge.start.x;
				new_edge.end.y = new_edge.start.y + 1;
				new_edge.cost = infinity;
			}
			Edges.push_back(new_edge);
			if(knownfield.PossibleToGoAndNotVisited(new_edge.start.x,new_edge.start.y,West))
			{
				new_edge.end.x = new_edge.start.x - 1;
				new_edge.end.y = new_edge.start.y;
				new_edge.cost = 5;
			}
			else if(knownfield.PossibleToGo(new_edge.start.x,new_edge.start.y,West))
			{
				new_edge.end.x = new_edge.start.x - 1;
				new_edge.end.y = new_edge.start.y;
				new_edge.cost = 10;
			}
			else
			{
				new_edge.end.x = new_edge.start.x - 1;
				new_edge.end.y = new_edge.start.y;
				new_edge.cost = infinity;
			}
			Edges.push_back(new_edge);
		}
	}
	return Edges;
}/*
function Dijkstra(Graph, Quelle):
 2      for each Knoten v in Graph:               // Variablen initialisieren
 3          abstand[v] := inf                     // Abstand der Quelle zu v
 4          vorgänger[v] := null                  // Vorheriger Knoten auf dem Weg zu v
 5      abstand[Quelle] := 0                      // Der Abstand der Quelle zu sich selbst ist 0
 6      Q := Die Menge aller Knoten in Graph
 7      while Q nicht leer:                       // Der eigentliche Algorithmus
 8          u := Knoten in Q mit kleinstem Wert in abstand[]
 9          if abstand[u] = ∞:
10              break                             // alle verbleibenden Knoten sind unerreichbar
11          entferne u aus Q
12          for each nachbar v von u:             // nur die v, die noch in Q enthalten sind.
13              alternativ := abstand[u] + abstand_zwischen(u, v)  
                                                  // abstand_zwischen bestimmt das Kantengewicht zwischen u und v
14              if alternativ < abstand[v]:       // Verwende (u,v,a)
15                  abstand[v] := alternativ
16                  vorgänger[v] := u
17      return vorgänger[]

Direction dijkstra_2(std::vector< std::vector<unsigned int> > &dist, unsigned int g)
{
	std::vector<unsigned int> d, pre;
	std::vector<bool> visited;
	unsigned int u=0;
	int mini=-1;
	d.resize(MazeSize*MazeSize);
	pre.resize(MazeSize*MazeSize);
	visited.resize(MazeSize*MazeSize);
	for(std::vector<unsigned int>::size_type i=0;i<d.size();i++)
	{
		d[i] = infinity;
		pre[i] = MazeSize+1;
	}
	d[g] = 0;
	for(std::vector<unsigned int>::size_type i=0;i<d.size();i++)
	{
		mini = -1;
		for (i = 0; i < n; ++i)
			if (!visited[i] && ((mini == -1) || (d[i] < d[mini])))
				mini = i;
		visited[i] = true;
		
	}
}*/

/* this function has been taken from http://snippets.dzone.com/posts/show/4832 */
void dijkstra(unsigned int s, std::vector< std::vector<unsigned long> > &dist,std::vector<unsigned long> &d)
{
	int i, k, mini, n=MazeSize*MazeSize;
	std::vector<bool> visited;

	visited.resize(MazeSize*MazeSize);

	d.resize(MazeSize*MazeSize);

	for (i = 0; i < n; ++i) {
		d[i] = infinity;
		visited[i] = false; /* the i-th element has not yet been visited */
	}

	d[s] = 0;

	for (k = 0; k < n; ++k) {
		mini = -1;
		for (i = 0; i < n; ++i)
			if (!visited[i] && ((mini == -1) || (d[i] < d[mini])))
				mini = i;

		visited[mini] = true;

		for (i = 0; i < n; ++i)
			if (dist[mini][i])
				if (d[mini] + dist[mini][i] < d[i]) 
					d[i] = d[mini] + dist[mini][i];
	}
}

std::vector<Direction> find_path(field &knownfield, unsigned int x, unsigned int y, unsigned int tox, unsigned int toy)
{
	std::cout << "FIXME: use dijkstra instead of some dumb rand() code" << std::endl;
	std::vector< std::vector<Direction> > directions;
	std::vector<bool> good;
	std::vector<unsigned int> cost;
	const unsigned int count = 10000;
	directions.clear();
	Direction curr_dir, rand_dir;
	unsigned int curr_x=x, curr_y=y;
	good.resize(count);
	directions.resize(count);
	cost.resize(count);
	for(unsigned int i=0;i<count;i++)
	{
		cost[i]=0;
		good[i] = true;
		curr_dir = Giveup;
		curr_x = x;
		curr_y = y;
		while(((curr_x!=tox)||(curr_y!=toy)))
		{
			if((knownfield.PossibleToGoAndNotVisited(curr_x,curr_y,North))||(knownfield.PossibleToGoAndNotVisited(curr_x,curr_y,South))||(knownfield.PossibleToGoAndNotVisited(curr_x,curr_y,West))||(knownfield.PossibleToGoAndNotVisited(curr_x,curr_y,East)))
			{
				break;
			}
			rand_dir = North;
			switch(sf::Randomizer::Random(0,4))
			{
				case 0:
					rand_dir = North;
					break;
				case 1:
					rand_dir = East;
					break;
				case 2:
					rand_dir = South;
					break;
				case 3:
					rand_dir = West;
					break;
				default: rand_dir = North; break;
			};
			if(knownfield.PossibleToGo(curr_x,curr_y,rand_dir))
			{
				curr_dir = rand_dir;
			}
			else continue;
			switch(curr_dir)
			{
				case South:
					curr_y++;
					break;
				case North:
					curr_y--;
					break;
				case East:
					curr_x++;
					break;
				case West:
					curr_x--;
					break;
				default: good[i]=false; break; // should never happen
			};
			cost[i]++;
			directions[i].push_back(curr_dir);
			if((curr_x>MazeSize)||(curr_y>MazeSize)) { good[i]=false; break; }
		}
	}
	unsigned int z=0, k=0xFFFF;
	for(unsigned int i=0;i<count;i++)
	{
		if(k>cost[i])
		{
			k=cost[i];
			z=i;
		}
	}
	return directions[z];
/*
	std::vector<Direction> directions;
	std::vector< std::vector<unsigned long> > Cost;
	std::vector<unsigned long> d;
	std::vector<edge> Edges;
	std::vector<bool> visited;
	Cost.resize(MazeSize*MazeSize);
	visited.resize(MazeSize*MazeSize);
	printf("pathfind - dijkstra\n");
	for(unsigned int i=0;i<MazeSize*MazeSize;i++)
	{
		Cost[i].resize(MazeSize*MazeSize);
	}
	Edges = get_edges(knownfield);
	for(unsigned int x1=0;x1<MazeSize;x1++)
	{
		for(unsigned int y1=0;y1<MazeSize;y1++)
		{
			for(unsigned int x0=0;x0<MazeSize;x0++)
			{
				for(unsigned int y0=0;y0<MazeSize;y0++)
				{
					Cost[x1+y1*MazeSize][x0+y0*MazeSize] = 0;
				}
			}
		}
	}
	for(std::vector<edge>::size_type i=0;i<Edges.size();i++)
	{
		if(inbounds(Edges[i])) Cost[Edges[i].start.x + Edges[i].start.y*MazeSize][Edges[i].end.x + Edges[i].end.y*MazeSize]=Edges[i].cost;
	}
	dijkstra(tox + toy*MazeSize,Cost,d);
	printf("x:%d,y:%d;tox:%d;toy:%d\n",x,y,tox,toy);
	printf("Shortest Cost from (x,y) to (tox,toy): %d\n",(unsigned int)d[x+y*MazeSize]);
	// get cheapest 
	unsigned int curr_x=tox, curr_y=toy, curr_cost=infinity;
	Direction curr_dir;
	while((x!=curr_x)||(y!=curr_y))
	{printf("ahfuck:x:%d,y:%d,tox:%d,toy:%d,curr_x:%d,curr_y:%d\n",x,y,tox,toy,curr_x,curr_y);
		curr_cost = infinity;
		curr_dir = Giveup;printf("W00T\n");
		if(curr_y>0)
		{printf("OWW");printf("%d,%d\n",curr_x,curr_y);printf("cost-tonorth:%d\n",(unsigned int)d[curr_x + (curr_y-1)*MazeSize]);
			if(d[curr_x + (curr_y-1)*MazeSize]<curr_cost)
			{printf("BAA");
				curr_cost = d[curr_x + (curr_y-1)*MazeSize];
				curr_dir = South;
			}
		}printf("WAAAT\n");
		if(curr_y<MazeSize-1)
		{printf("AWW");printf("%d,%d\n",curr_x,curr_y);printf("cost-tosouth:%d\n",(unsigned int)d[curr_x + (curr_y+1)*MazeSize]);
			if(d[curr_x + (curr_y+1)*MazeSize]<curr_cost)
			{printf("ZZ");printf("%d,%d\n",curr_x,curr_y);
				curr_cost = d[curr_x + (curr_y+1)*MazeSize];
				curr_dir = North;
			}
		}printf("WUUUT\n");
		if(curr_x>0)
		{printf("EWW");;printf("%d,%d\n",curr_x,curr_y);printf("cost-tonwest:%d\n",(unsigned int)d[curr_x-1 + curr_y*MazeSize]);
			if(d[curr_x-1 + curr_y*MazeSize]<curr_cost)
			{printf("YY");
				curr_cost = d[curr_x-1 + curr_y*MazeSize];
				curr_dir = East;
			}
		}printf("WEEEET\n");
		if(curr_x<MazeSize-1)
		{printf("DWW");printf("%d,%d\n",curr_x,curr_y);printf("cost-toeast:%d\n",(unsigned int)d[curr_x+1 + curr_y*MazeSize]);
			if(d[curr_x+1 + curr_y*MazeSize]<curr_cost)
			{printf("DDD");
				curr_cost = d[curr_x+1 + curr_y*MazeSize];
				curr_dir = West;
			}
		}printf("WTTTTT\n");
		switch(curr_dir)
		{
			case South:
				curr_y++;printf("south\n");
				break;
			case North:
				curr_y--;printf("north\n");
				break;
			case East:
				curr_x++;printf("east\n");
				break;
			case West:
				curr_x--;printf("west\n");
				break;
			default: printf("ARGH\n");break; // should never happen
		};printf("GOOOOO\n");
		if(curr_dir == Giveup){printf("damn\n"); break;}
		directions.push_back(curr_dir);printf("BAAA\n");
		printf("ahfuck:x:%d,y:%d,tox:%d,toy:%d,curr_x:%d,curr_y:%d\n",x,y,tox,toy,curr_x,curr_y);
		if(curr_x>=MazeSize) { printf("fuck"); break; }
		if(curr_y>=MazeSize) { printf("fuck"); break; }
	}
	return directions;*/
}

/** Wird nach jeder Bewegung und zu Beginn gerufen.
 * @param north true, falls die Bewegung Richtung Norden nicht möglich ist.
 * @param east true, falls die Bewegung Richtung Osten nicht möglich ist.
 * @param south true, falls die Bewegung Richtung Süden nicht möglich ist.
 * @param west true, falls die Bewegung Richtung Westen nicht möglich ist.
 */
Direction EXPORT Touch(bool north, bool east, bool south, bool west)
{
	Direction new_direction = Giveup, curr_direction = Giveup;
	static unsigned int curr_dircount=0;
	printf("------\n");
	printf("pos: %i, %i| ",XPos,YPos);
	printf("north: %s, east: %s, south: %s, west: %s\n",north ? "true" : "false",east ? "true" : "false",south ? "true" : "false",west ? "true" : "false");
	knownfield.Update(XPos,YPos,north,east,south,west);
	printf("knownfield:\n");
	knownfield.Draw();
	curr_direction = (last_direction == Giveup) ? North : last_direction;
	if(directionstogo.size()!=0)
	{
		new_direction = directionstogo[curr_dircount++];
		if(directionstogo.size()<=curr_dircount)
		{
			directionstogo.clear();
		}
		if(!knownfield.PossibleToGo(XPos,YPos,new_direction))
		{
			directionstogo.clear();
			new_direction = Giveup;
		}
		else
		{
			last_direction = new_direction;
			switch(new_direction)
			{
				case East: XPos++; break;
				case South: YPos++; break;
				case West: XPos--; break;
				case North: YPos--; break;
				default: break; /* WTH DO WE GIVE UP??? */
			}
			return new_direction;
		}
	}
	for(unsigned int i=0;i<4;i++)
	{
		if(knownfield.PossibleToGoAndNotVisited(XPos,YPos,curr_direction))
		{
			new_direction = curr_direction;
		}
		else if(new_direction != Giveup)
			break;
		curr_direction = next_direction_in_circle(last_direction,curr_direction);
	}
	if(new_direction == Giveup)
	{
		char curr_c;
		unsigned int tox=MazeSize+1, toy=MazeSize+1;
		/* ok... do pathfinding, to the nearest '?' or '.' */
		for(unsigned int i=1;(i<MazeSize)&&(tox==MazeSize+1);i++)
		{
			for(unsigned int y=0;y<(i*2+1)&&(tox==MazeSize+1);y++)
			{
				if((y==0)||(y==((i*2+1)-1))) for(unsigned int x=0;(x<i*2+1)&&(tox==MazeSize+1);x++)
				{
					curr_c = knownfield.Get(XPos+x-i,YPos+y-i);
					if((curr_c=='\?')||(curr_c=='.'))
					{
						tox = x + XPos - i;
						toy = y + YPos - i;
						break;
					}
				}
				else
				{
					curr_c = knownfield.Get(XPos-i,YPos+y-i);
					if((curr_c=='\?')||(curr_c=='.'))
					{
						tox = XPos - i;
						toy = y + YPos - i;
						break;
					}
					curr_c = knownfield.Get(XPos-i+i*2+1-1,YPos+y-i);
					if((curr_c=='\?')||(curr_c=='.'))
					{
						tox = XPos - i + i*2+1-1;
						toy = y + YPos - i;
						break;
					}
				}
			}
		}
//		knownfield.Set(tox,toy,'G');
//		knownfield.Draw();
		directionstogo = find_path(knownfield,XPos,YPos,tox,toy);
		curr_dircount=0;
		if(directionstogo.size()>0)
		{
			new_direction = directionstogo[curr_dircount++];
		}
	}
	switch(new_direction)
	{
		case East: XPos++; break;
		case South: YPos++; break;
		case West: XPos--; break;
		case North: YPos--; break;
		default: break; /* WTH DO WE GIVE UP??? */
	}
	last_direction = new_direction;
	return new_direction;
}

}
