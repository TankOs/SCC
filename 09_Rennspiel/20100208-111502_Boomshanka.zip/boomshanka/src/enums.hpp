#ifndef ENUMS_HPP
#define ENUMS_HPP


#include <iostream>
//#include <deque>

#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>


namespace state
{
	enum Gamestates
	{
		Menu = 0,
		Game
	};
}

namespace img
{
	enum Images
	{
		Car,
		Ziel,
		
		Tile_Gras,
		Tile_Strasse,
		
		Tile_Kurve_Ausen,
		Tile_Kurve_Innen,
		Tile_Kurve_Anfang
	};
}


namespace map
{
	enum Tiles
	{
		Gras = 0,
		Strasse_Horizontal,
		Strasse_Vertikal,
		
		Kurve_Anfang_ObenRechts,
		Kurve_Anfang_ObenLinks,
		Kurve_Anfang_UntenRechts,
		Kurve_Anfang_UntenLinks,
		Kurve_Anfang_RechtsUnten,
		Kurve_Anfang_RechtsOben,
		Kurve_Anfang_LinksUnten,
		Kurve_Anfang_LinksOben,
		
		Kurve_Ausen_RechtsOben,
		Kurve_Ausen_LinksOben,
		Kurve_Ausen_RechtsUnten,
		Kurve_Ausen_LinksUnten,
		
		Kurve_Innen_RechtsOben,
		Kurve_Innen_LinksOben,
		Kurve_Innen_RechtsUnten,
		Kurve_Innen_LinksUnten
	};
}


#endif


