#ifndef PLAYER_HPP
#define PLAYER_HPP

#include "enums.hpp"
#include "math.h"


class Player
{
	private:
		sf::Sprite Car;
		float speed, rotation;
		float richtung;
		
		static unsigned int playernumb;
		
		float a;
		
		float pi;
	public:
		Player(){;}
		Player(sf::Sprite);
		~Player();
		
		sf::Sprite& getSprite();
		
		void beschlaeunigen(float);
		void bremsen(float);
		void kurve(float, bool rechts);
		void drive(float);
		
		void brems(float);
		
		float getRotation(){return -(richtung*57.2958);}
};


#endif


