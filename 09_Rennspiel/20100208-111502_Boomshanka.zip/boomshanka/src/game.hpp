#ifndef GAME_HPP
#define GAME_HPP

#include <vector>


#include "enums.hpp"
#include "gamesettings.hpp"
#include "imagemanager.hpp"
#include "player.hpp"
#include "tile.hpp"


class Game
{
	private:
		unsigned int win_height, win_width;
		unsigned int counter;
		unsigned int level;
		std::vector<std::vector<Tile> > map;
		unsigned int laps;
		unsigned int lapcounter;
		
		sf::Sprite ziel;
		
		Imagemanager imagemanager;
		
		sf::Text frametext;
		
		Player player;
		
		sf::Vector2i startpos;
		std::vector<sf::Vector2i> route;
		unsigned int routecounter;
		
		sf::Text message;
	public:
		Game();
		~Game();
		
		bool init(Gamesettings&);
		bool loadLevel(Gamesettings&);
		
		bool run(Gamesettings&);
		void draw(sf::RenderWindow&);
};


#endif


