#ifndef IMAGEMANAGER_HPP
#define IMAGEMANAGER_HPP


#include "enums.hpp"


class Imagemanager
{
	private:
		sf::Image car;
		sf::Image ziel;
		
		sf::Image tile_strasse;
		sf::Image tile_gras;
		sf::Image tile_kurve_anfang;
		sf::Image tile_kurve_ausen;
		sf::Image tile_kurve_innen;
		
	public:
		Imagemanager();
		~Imagemanager();
		
		bool loadImages();
		sf::Sprite getImage(img::Images);
};


#endif


