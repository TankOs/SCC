#include "tile.hpp"



Tile::Tile()
{

}



Tile::Tile(map::Tiles tiletyp, Imagemanager& imagemanager)
{
	switch (tiletyp)
	{
		case map::Gras:
			tilesprite=imagemanager.getImage(img::Tile_Gras);
			break;
		
		case map::Strasse_Horizontal:
			tilesprite=imagemanager.getImage(img::Tile_Strasse);
			tilesprite.SetOrigin(tilesprite.GetSize().x,tilesprite.GetSize().y);
			tilesprite.Rotate(90);
			break;
		
		case map::Strasse_Vertikal:
			tilesprite=imagemanager.getImage(img::Tile_Strasse);
			break;
		
		case map::Kurve_Anfang_ObenRechts:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Anfang);
			break;
		case map::Kurve_Anfang_ObenLinks:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Anfang);
			tilesprite.FlipY(true);
			break;
		case map::Kurve_Anfang_UntenRechts:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Anfang);
			tilesprite.FlipX(true);
			break;
		case map::Kurve_Anfang_UntenLinks:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Anfang);
			tilesprite.FlipX(true);
			tilesprite.FlipY(true);
			break;
		case map::Kurve_Anfang_RechtsUnten:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Anfang);
			tilesprite.SetOrigin(tilesprite.GetSize().x,tilesprite.GetSize().y);
			tilesprite.Rotate(90);
			break;
		case map::Kurve_Anfang_RechtsOben:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Anfang);
			tilesprite.FlipY(true);
			tilesprite.SetOrigin(tilesprite.GetSize().x,tilesprite.GetSize().y);
			tilesprite.Rotate(90);
			break;
		case map::Kurve_Anfang_LinksUnten:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Anfang);
			tilesprite.FlipY(true);
			tilesprite.SetOrigin(tilesprite.GetSize().x,tilesprite.GetSize().y);
			tilesprite.Rotate(-90);
			break;
		case map::Kurve_Anfang_LinksOben:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Anfang);
			tilesprite.SetOrigin(tilesprite.GetSize().x,tilesprite.GetSize().y);
			tilesprite.Rotate(-90);
			break;
		
		case map::Kurve_Ausen_RechtsOben:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Ausen);
			tilesprite.FlipY(true);
			break;
		case map::Kurve_Ausen_LinksOben:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Ausen);
			break;
		case map::Kurve_Ausen_RechtsUnten:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Ausen);
			tilesprite.FlipY(true);
			tilesprite.FlipX(true);
			break;
		case map::Kurve_Ausen_LinksUnten:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Ausen);
			tilesprite.FlipX(true);
			break;
		
		case map::Kurve_Innen_RechtsOben:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Innen);
			tilesprite.FlipY(true);
			break;
		case map::Kurve_Innen_LinksOben:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Innen);
			break;
		case map::Kurve_Innen_RechtsUnten:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Innen);
			tilesprite.FlipY(true);
			tilesprite.FlipX(true);
			break;
		case map::Kurve_Innen_LinksUnten:
			tilesprite=imagemanager.getImage(img::Tile_Kurve_Innen);
			tilesprite.FlipX(true);
			break;
		
		default:
			std::cerr<<"Error: No Image for a tile!\n";
			break;
	}
}



Tile::~Tile()
{

}



sf::Sprite& Tile::getSprite()
{
	return tilesprite;
}



