#include "game.hpp"



Game::Game()
{
	level=1;
}


Game::~Game()
{
	
}


//--------------------------------------------------------------------------------------------------------------------//


bool Game::run(Gamesettings& gamesettings)
{
	sf::RenderWindow& window=gamesettings.getWindow();
	sf::Event event;
	sf::View view=window.GetDefaultView();
	const sf::Input& input = window.GetInput();
	
	//Fenstergröße
	win_width=window.GetWidth();
	win_height=window.GetHeight();
	window.SetCursorPosition(static_cast<float>(win_width)/2.f, static_cast<float>(win_height)*0.7f);
	
	bool running;
	
	running=imagemanager.loadImages();
	if(running)
		running=init(gamesettings);
	
	//Framezähler
	sf::Clock clock;
	unsigned int frames=0;
	frametext.SetString("0");
	
	bool go=false;
	bool win=false;
	sf::Clock time;
	
//--------------------------------------------------------------------------------------------------------------------//
	while(running)
	{
		//Events&Inputs
		while(window.GetEvent(event))
		{
			if(event.Type==sf::Event::Closed)
			{
				return false;
			}
			else if(event.Type==sf::Event::Resized)
			{
				win_width=event.Size.Width;
				win_height=event.Size.Height;
			}
		}
		//Alt+F4 schließt auch im Vollbild
		if((input.IsKeyDown(sf::Key::LAlt))&&(input.IsKeyDown(sf::Key::F4)))
		{
			return false;
		}
		
		if(go==true && win==false)
		{
		
		if((input.IsKeyDown(sf::Key::Up)))
		{
			player.beschlaeunigen(window.GetFrameTime());
		}
		if((input.IsKeyDown(sf::Key::Down)))
		{
			player.bremsen(window.GetFrameTime());
		}
		if((input.IsKeyDown(sf::Key::Right)))
		{
			player.kurve(window.GetFrameTime(),true);
		}
		if((input.IsKeyDown(sf::Key::Left)))
		{
			player.kurve(window.GetFrameTime(),false);
		}
		//Display Time
		
		}
		else if(!win)
		{
			if(time.GetElapsedTime()>4)
			{
				message.SetString("");
				go=true;
				time.Reset();
			}
			else if(time.GetElapsedTime()>3)
			{
				message.SetString("  Go!");
				message.SetColor(sf::Color::Red);
			}
			else if(time.GetElapsedTime()>2)
			{
				message.SetString("   1");
			}
			else if(time.GetElapsedTime()>1)
			{
				message.SetString("   2");
				message.SetColor(sf::Color::Yellow);
			}
			else
			{
				
			}
		}
		else if(win)
		{
			if(time.GetElapsedTime()>5)
				return false;
			player.brems(window.GetFrameTime());
		}
		
		sf::Rect<float> rec(200*route[routecounter].x,200*route[routecounter].y,200*(route[routecounter].x+1),200*(route[routecounter].y+1
		));
		if(rec.Contains(player.getSprite().TransformToGlobal(sf::Vector2f(0,0)))||
		rec.Contains(player.getSprite().TransformToGlobal(sf::Vector2f(player.getSprite().GetSubRect().Right,0)))||
		rec.Contains(player.getSprite().TransformToGlobal(sf::Vector2f(0,player.getSprite().GetSubRect().Bottom)))||
		rec.Contains(player.getSprite().TransformToGlobal(sf::Vector2f(player.getSprite().GetSubRect().Right,player.getSprite().GetSubRect().Bottom))))
		{
			++routecounter;
			if(routecounter==route.size())
			{
				routecounter=0;
				++lapcounter;
				std::cout<<"Runde "<<lapcounter<<" vollstaendig.\n";
				if(laps==lapcounter)
				{
					win=true;
					std::ostringstream strstr;
					strstr<<time.GetElapsedTime();
					std::string str("Gewonnen!!\n Zeit: "+strstr.str());
					message.SetString(str.c_str());
					std::cout<<str<<std::endl;
					time.Reset();
				}
			}
			else if(!win)
			{
				std::cout<<"Wegpunkt passiert. Naechster Wegepunkt: "<<route[routecounter].x<<" "<<route[routecounter].y<<"\n";
			}
		}
		
		//Let the cars crash =D
		player.drive(window.GetFrameTime());
		
		//View ;sf::Vector2f MousePos = App.ConvertCoords(App.GetInput().GetMouseX(), App.GetInput().GetMouseY());
		view.SetCenter(player.getSprite().TransformToGlobal(sf::Vector2f(player.getSprite().GetSubRect().Right/2,
																		player.getSprite().GetSubRect().Top)));
		view.SetRotation(-player.getRotation());
		
		message.SetRotation(-view.GetRotation());
		message.SetPosition(player.getSprite().TransformToGlobal(
		sf::Vector2f(player.getSprite().GetSubRect().Right/2-message.GetRect().Right/2, player.getSprite().GetSubRect().Top-300)));
		
		//Auch Framezähler
		++frames;
		if(clock.GetElapsedTime()>=1)
		{
			std::ostringstream str;
			str<<frames;
			frametext.SetString(str.str());
			clock.Reset();
			frames=0;
		}
		
		
		//Draw everything:
		window.SetView(view);
		draw(window);
		
		window.Display();
		window.Clear();
	}
	return true;
}
//--------------------------------------------------------------------------------------------------------------------//



bool Game::init(Gamesettings& gamesettings)
{
	routecounter=0;
	lapcounter=0;
	
	message.SetScale(static_cast<float>(win_width)/1600.f*2, static_cast<float>(win_height)/1200.f*2);
	
	//player
	player=Player(imagemanager.getImage(img::Car));
	player.getSprite().SetScale(0.56,0.56);
	player.getSprite().SetPosition(win_width/2-player.getSprite().GetSize().x/2.f,win_height/2);
	
	ziel=imagemanager.getImage(img::Ziel);
	
	if(!loadLevel(gamesettings)) return false;
	
	return true;
}


void Game::draw(sf::RenderWindow& window)
{
	//Draw Tiles FIXME Nur sichtbaren!
	for(int i=0;i<map.size();++i)
	{
		for(int j=0;j<map[i].size();++j)
		{
			window.Draw(map[i][j].getSprite());
		}
	}
	//Draw Strings
	window.Draw(frametext);
	
	window.Draw(ziel);
	
	//Draw Player
	window.Draw(player.getSprite());
	
	//Draw string
	window.Draw(message);
}



bool Game::loadLevel(Gamesettings& gamesettings)
{
	
	std::string level_str="lev/lev";
	std::ostringstream levnumb;
	levnumb<<level;
	level_str+=levnumb.str();
	
	std::ifstream newlevel(level_str.c_str());
	std::string line;
	
	while (std::getline(newlevel, line))
	{
		if(line.substr(0,6)=="$Name=")
		{
			message.SetString(line.substr(6));
			message.SetColor(sf::Color::Blue);
		}
		else if(line.substr(0,6)=="$Laps=")
		{
			std::stringstream strstr(line.substr(6));
			strstr>>laps;
		}
		else if(line.substr(0,9)=="$Position")
		{
			int x,y; char z;
			newlevel>>x>>z>>y;
			player.getSprite().SetPosition(x*200+100,y*200+250);
			startpos=sf::Vector2i(x,y);
		}
		else if(line.substr(0,10)=="$Map_begin")
		{
			bool dateiende=true;
			std::getline(newlevel, line);
			for(int i=0;line!="$Map_end" && dateiende;dateiende=std::getline(newlevel, line))
			{
				map.push_back(std::vector<Tile>());
				for(int j=0;j<line.size();++j)
				{
					switch(line[j])
					{
						case '=':
							map[i].push_back(Tile(map::Strasse_Horizontal, imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							map[i][j].getSprite().Move(map[i][j].getSprite().GetSize().x,0);
							break;
							
						case '!':
							map[i].push_back(Tile(map::Strasse_Vertikal, imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
							
						case 'o':
							map[i].push_back(Tile(map::Gras, imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
						
						case 'c':
							map[i].push_back(Tile(map::Kurve_Ausen_LinksOben, imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
						
						case 'b':
							map[i].push_back(Tile(map::Kurve_Ausen_RechtsOben , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
						
						case 'd':
							map[i].push_back(Tile(map::Kurve_Ausen_LinksUnten , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
						
						case 'a':
							map[i].push_back(Tile(map::Kurve_Ausen_RechtsUnten , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
							
						case 'm':
							map[i].push_back(Tile(map::Kurve_Innen_LinksOben , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
						
						case 'n':
							map[i].push_back(Tile(map::Kurve_Innen_RechtsOben , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
						
						case 'q':
							map[i].push_back(Tile(map::Kurve_Innen_LinksUnten , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
						
						case 'p':
							map[i].push_back(Tile(map::Kurve_Innen_RechtsUnten , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
						
						case 'k':
							map[i].push_back(Tile(map::Kurve_Anfang_ObenLinks , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
						
						case 'l':
							map[i].push_back(Tile(map::Kurve_Anfang_LinksOben , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							map[i][j].getSprite().Move(0,map[i][j].getSprite().GetSize().x); //
							break;
						
						case 'i':
							map[i].push_back(Tile(map::Kurve_Anfang_RechtsOben , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							map[i][j].getSprite().Move(map[i][j].getSprite().GetSize().x,0); //FIXME
							break;
						
						case 'j':
							map[i].push_back(Tile(map::Kurve_Anfang_ObenRechts , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
						
						case 'h':
							map[i].push_back(Tile(map::Kurve_Anfang_RechtsUnten, imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							map[i][j].getSprite().Move(map[i][j].getSprite().GetSize().x,0); //FIXME
							break;
						
						case 'g':
							map[i].push_back(Tile(map::Kurve_Anfang_UntenRechts , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
						
						case 'e':
							map[i].push_back(Tile(map::Kurve_Anfang_LinksUnten , imagemanager)); //
							map[i][j].getSprite().SetPosition(200*j,200*i);
							map[i][j].getSprite().Move(0,map[i][j].getSprite().GetSize().x);
							break;
						
						case 'f':
							map[i].push_back(Tile(map::Kurve_Anfang_UntenLinks , imagemanager));
							map[i][j].getSprite().SetPosition(200*j,200*i);
							break;
							
							
						default:
							std::cerr<<"Error: '"<<line[j]<<"' bezeichnet keinen Tile-Typ\n";
							break;
							
					}
				}
				++i;
			}
		}
		else if(line.substr(0,12)=="$Route_begin")
		{
			while (std::getline(newlevel, line))
			{
				if(line=="$Route_end") break;
				int x, y;
				std::stringstream strstr(line);
				strstr>>x>>y;
				
				route.push_back(sf::Vector2i(x,y));
			}
			ziel.SetPosition(route[route.size()-1].x*200,route[route.size()-1].y*200+150);
		}
	}
	
	return true;
}




