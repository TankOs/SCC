#include "menu.hpp"



Menu::Menu()
{

}


Menu::~Menu()
{

}

//-----------------------------------------------------------------------------------------------------------------------//


bool Menu::showmenu(state::Gamestates& gamestate, Gamesettings& gamesettings)
{
	bool MenuIsRunning=true;
	sf::Event event;
	
	sf::RenderWindow& window=gamesettings.getWindow();
	
	while(MenuIsRunning)//Menuloop
	{
		while(window.GetEvent(event))
		{
			if(event.Type==sf::Event::Closed || 
			(event.Type==sf::Event::KeyPressed && (event.Key.Code == sf::Key::Escape)))
			{
				return false;
			}
			else //if()
			{
			
			}
		}
		
		window.Display();
		window.Clear();
		
		//Menü wird übersprungen!
		gamestate=state::Game;
		break;
	}
}



