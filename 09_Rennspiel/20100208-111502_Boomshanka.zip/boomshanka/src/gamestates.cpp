#include "gamestates.hpp"


Gamemanager::Gamemanager()
{
	//FIXME Laden von Fenstergröße etc und an gamesettings schicken
	videomode=sf::VideoMode(800, 600, 32); //Muss aus datei geladen werden
}


Gamemanager::~Gamemanager()
{

}


//---------------------------------------------------------------------------------------------------------------------//


void Gamemanager::fullscreen(bool isfull)
{
	gamesettings.setFullscreen(isfull);
}



void Gamemanager::setVideomode(sf::VideoMode mode)
{
	videomode=mode;
}



void Gamemanager::gamestates()
{
	gamesettings.createWindow(videomode);//false, wenn fehlgeschlagen! FIXME
	
	bool running=true;
	state::Gamestates gamestate=state::Menu;
	
	while(running)
	{
		switch(gamestate)
		{
			case state::Menu:
				running=menumanager.showmenu(gamestate, gamesettings);
				break;
			case state::Game:
				Game game;
				running=game.run(gamesettings);
				gamestate=state::Menu;
				break;
		}
	}
}


