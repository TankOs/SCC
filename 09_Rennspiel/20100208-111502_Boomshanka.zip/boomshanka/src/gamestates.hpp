#ifndef GAMESTATES_HPP
#define GAMESTATES_HPP

//Wichtige Header werden in enums.hpp includiert//

#include "enums.hpp"
#include "gamesettings.hpp"
#include "game.hpp"
#include "menu.hpp"


class Gamemanager
{
	private:
		Menu menumanager;
		Gamesettings gamesettings;
	public:
		Gamemanager();
		~Gamemanager();
		
		void fullscreen(bool);
		void setVideomode(sf::VideoMode);
		sf::VideoMode videomode;
		
		void gamestates();
};


#endif

