#include "imagemanager.hpp"



Imagemanager::Imagemanager()
{
	
}


Imagemanager::~Imagemanager()
{
	
}


//---------------------------------------------------------------------------------------------------------------------//


bool Imagemanager::loadImages()
{
	if(!car.LoadFromFile("img/car.png"))
	{
		std::cerr<<"Can´t load Image 'car.png', aborting.\n";
		return false;
	}
	if(!ziel.LoadFromFile("img/ziel.png"))
	{
		std::cerr<<"Can´t load Image 'ziel.png', aborting.\n";
		return false;
	}
	if(!tile_gras.LoadFromFile("img/tile_gras.png"))
	{
		std::cerr<<"Can´t load Image 'tile_gras.png', aborting.\n";
		return false;
	}
	if(!tile_strasse.LoadFromFile("img/tile_strase.png"))
	{
		std::cerr<<"Can´t load Image 'tile_strase.png', aborting.\n";
		return false;
	}
	if(!tile_kurve_ausen.LoadFromFile("img/tile_kurve_ausen.png"))
	{
		std::cerr<<"Can´t load Image 'tile_kurve_ausen.png', aborting.\n";
		return false;
	}
	if(!tile_kurve_innen.LoadFromFile("img/tile_kurve_innen.png"))
	{
		std::cerr<<"Can´t load Image 'tile_kurve_innen.png', aborting.\n";
		return false;
	}
	if(!tile_kurve_anfang.LoadFromFile("img/tile_kurve_anfang.png"))
	{
		std::cerr<<"Can´t load Image 'tile_kurve_anfang.png', aborting.\n";
		return false;
	}
	
	
	return true;
}



sf::Sprite Imagemanager::getImage(img::Images imagename)
{
	sf::Sprite back;
	
	switch(imagename)
	{
		case img::Car:
			back.SetImage(car);
			break;
		case img::Tile_Gras:
			back.SetImage(tile_gras);
			break;
		case img::Tile_Strasse:
			back.SetImage(tile_strasse);
			break;
		case img::Ziel:
			back.SetImage(ziel);
			break;
		case img::Tile_Kurve_Anfang:
			back.SetImage(tile_kurve_anfang);
			break;
		case img::Tile_Kurve_Innen:
			back.SetImage(tile_kurve_innen);
			break;
		case img::Tile_Kurve_Ausen:
			back.SetImage(tile_kurve_ausen);
			break;
		default:
			break;
	}
	
	return back;
}



