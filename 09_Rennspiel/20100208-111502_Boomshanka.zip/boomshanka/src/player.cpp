#include "player.hpp"


unsigned int Player::playernumb=0;

Player::Player(sf::Sprite spr)
:Car(spr), speed(0), richtung(0), pi(3.1416)
{
	Car.SetOrigin(Car.GetSize().x/2,Car.GetSize().y/2);
	
	switch (playernumb)
	{
		case 0:
			Car.SetColor(sf::Color::Red);
			break;
		case 1:
			Car.SetColor(sf::Color::Blue);
			break;
		case 2:
			Car.SetColor(sf::Color::Green);
			break;
		case 4:
			
			break;
		case 5:
			
			break;
		case 6:
			
			break;
		case 7:
			
			break;
	}
	++playernumb;
	a=0;
}


Player::~Player()
{

}



sf::Sprite& Player::getSprite()
{
	return Car;
}




void Player::beschlaeunigen(float time)
{
	speed+=25*time;
}



void Player::bremsen(float time)
{
	if(speed>0)
	{
		speed-=16*time;
	}
	else
	{
		speed-=12*time;
	}
}


void Player::brems(float time)
{
	if(speed>0)
	{
		speed-=16*time;
	}
	else
	{
		speed=0;
	}
}



void Player::kurve(float time, bool rechts)
{
	if(rechts)
	{
		richtung+=0.3*time*speed-speed*speed*time*0.01;
		a+= speed*speed*0.008;
	}
	else
	{
		richtung-=0.3*time*speed-speed*speed*time*0.01;
		a-= speed*speed*0.008;
	}
}




void Player::drive(float time)
{
	//Widerstand
	if(speed>=0)
	{
		speed=speed-speed*speed*0.06*time;
	}
	else
	{
		speed=speed+speed*speed*0.09*time;
	}
	
	if(speed>0.5*time)
	{
		speed-=0.5*time;
	}
	else if(speed<-0.5*time)
	{
		speed+=0.5*time;
	}
	else
	{
		speed=0;
	}
	
	if(richtung>360)
	{
		richtung-=360;
	}
	else if(richtung<-360)
	{
		richtung+=360;
	}
	
	
	if(a>0)
	{
		a-=a*a*0.015;
		speed-=a/200;
	}
	else
	{
		a+=a*a*0.015;
		speed+=a/200;
	}
	
	Car.SetRotation(-richtung*57.2958-a);
	Car.Move(speed*sin(richtung),-speed*cos(richtung));
	
}





