#ifndef tile_HPP
#define tile_HPP

#include "enums.hpp"
#include "imagemanager.hpp"



class Tile
{
	private:
		sf::Sprite tilesprite;
	public:
		Tile();
		Tile(map::Tiles, Imagemanager&);
		~Tile();
		
		sf::Sprite& getSprite();
};


#endif


