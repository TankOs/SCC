#ifndef MENU_HPP
#define MENU_HPP


#include "enums.hpp"
#include "gamesettings.hpp"


class Menu
{
	private:
		
	public:
		Menu();
		~Menu();
		
		bool showmenu(state::Gamestates&, Gamesettings&);
};


#endif
//Gamemanager& gamemanager, 
