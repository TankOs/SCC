#ifndef GAMESETTINGS_HPP
#define GAMESETTINGS_HPP

#include "enums.hpp"

#include <fstream> 
#include <string>
#include <sstream>


class Gamesettings
{
	private:
		bool fullscreen; //vollbild?
		sf::RenderWindow window; //Das Fenster
		
	public:
		Gamesettings();
		~Gamesettings();
		
		void setFullscreen(bool&);
		bool createWindow(sf::VideoMode&);
		
		sf::RenderWindow& getWindow();
		
};


#endif


