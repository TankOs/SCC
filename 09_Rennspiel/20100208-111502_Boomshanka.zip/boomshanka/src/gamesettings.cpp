#include "gamesettings.hpp"



Gamesettings::Gamesettings()
{
	//Hier müssen werte geladen werden
	fullscreen=false; //s.o.
}


Gamesettings::~Gamesettings()
{

}


//---------------------------------------------------------------------------------------------------------------------//


void Gamesettings::setFullscreen(bool& isfull)
{
	fullscreen=isfull;
}



bool Gamesettings::createWindow(sf::VideoMode& videomode)
{
	bool modeworks=true;
	
	if(!videomode.IsValid() && fullscreen)
	{
		modeworks=false;
		std::cerr<<"Video Mode isn´t valid! Try with 800, 600, 32.\n";
		videomode=sf::VideoMode(800, 600, 32);
		if(!videomode.IsValid())
		{
			std::cerr<<"Failed!\n";
			return EXIT_FAILURE;
		}
	}
	
	if(fullscreen)
	{
		window.Create(videomode, "Autorennen", sf::Style::Fullscreen);
	}
	else
	{
		window.Create(videomode, "Autorennen", sf::Style::Close);
	}
	
	window.UseVerticalSync(true);
	window.ShowMouseCursor(false);
	return modeworks;
}



sf::RenderWindow& Gamesettings::getWindow()
{
	return window;
}



