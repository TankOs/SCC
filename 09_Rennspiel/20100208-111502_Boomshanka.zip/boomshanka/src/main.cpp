#include <iostream>
#include <cstring>
#include <sstream>

#include "gamestates.hpp"



void printHelp();



int main(int argc, char* argv[])
{
	Gamemanager newgame;
	int i=argc-1;
	
	while(i>0)
	{
		if(strcmp(argv[argc-i], "--help") == 0||strcmp(argv[argc-i], "-h")==0)
		{
			printHelp();
			return EXIT_SUCCESS;
		}
		else if(strcmp(argv[argc-i], "--fullscreen") == 0||strcmp(argv[argc-i], "-full")==0)
		{
			newgame.fullscreen(true);
		}
		else if(strcmp(argv[argc-i], "--window") == 0||strcmp(argv[argc-i], "-win")==0)
		{
			newgame.fullscreen(false);
		}
		else if(strcmp(argv[argc-i], "--resolution") == 0||strcmp(argv[argc-i], "-r")==0)
		{
			std::stringstream str1, str2;
			int x,y;
			str1<<argv[argc-i+1];
			str1>>x;
			str2<<argv[argc-i+2];
			str2>>y;
			newgame.setVideomode(sf::VideoMode(x,y,32));
			i-=2;
		}
		else
		{
			std::cout<<"Invalid option '"<<argv[argc-i]<<"'. Please try '--help' to get more information."<<std::endl;
			return EXIT_SUCCESS;
		}
		--i;
	}
	
	newgame.gamestates();
}


void printHelp()
{
	std::cout<<"\t\t\tAutorenngame by Boomshanka\n\nArguments are:\n\n--fullscreen\t\t-full\t\tPlay this game in ";
	std::cout<<"fullscreenmode.\n--window\t\t-win\t\tPlay this game in windowmode.\n--resolution x y\t-r x y\t\t";
	std::cout<<"Window size in x y.\n--help\t\t\t-h\t\tShow this help text.\n";
}


