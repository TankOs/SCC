#include "VMadness.hpp"

int main() {
	VMadness  app( sf::VideoMode( 1024, 768, 32 ) );

	app.Run();

	return 0;
}
