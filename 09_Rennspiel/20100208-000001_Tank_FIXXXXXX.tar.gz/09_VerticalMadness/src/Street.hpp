#ifndef __STREET_HPP__
#define __STREET_HPP__

#include "EventReceiver.hpp"
#include "Object.hpp"
#include <SFML/Graphics/Image.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Rect.hpp>
#include <SFML/System/Vector2.hpp>
#include <SFML/Graphics/View.hpp>
#include <list>
#include <vector>
#include <set>

namespace sf {
	class RenderTarget;
}

class Street {
	public:
		Street( EventReceiver& receiver, const sf::Vector2i& size, unsigned int lanes = 4 );

		void Clear();

		void Update( float time );
		void Render( sf::RenderTarget& target ) const;

		void SetLanes( unsigned int lanes );
		void SetSpeed( float speed );

		void SpawnObstacle();
		void SpawnFuel();
		void SpawnRepairKit();
		void SpawnCar();
		Object& SpawnPlayer();

	private:
		typedef std::list<Object>       ObjectList;
		typedef std::set<Object*>       ObjectPtrSet;
		typedef std::vector<sf::Image>  ImageArray;

		void LoadImage( unsigned int index, const std::string& filename );
		Object& AddObject( const Object& object );
		ObjectList::iterator RemoveObject( const ObjectList::iterator& iter );

		EventReceiver&  m_receiver;

		sf::Vector2i   m_size;
		sf::FloatRect  m_lanerect;

		unsigned int   m_lanes;
		float          m_yoffset;
		float          m_speed;

		ObjectList    m_objects;
		ObjectPtrSet  m_collisionobjects;

		ImageArray    m_images;

		mutable sf::Sprite  m_grass;
		mutable sf::Sprite  m_lane;
		mutable sf::Sprite  m_curb;

		sf::View  m_scrollview;
};

#endif
