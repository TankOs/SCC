#ifndef __OBJECT_HPP__
#define __OBJECT_HPP__

#include <SFML/Graphics/Rect.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/System/Vector2.hpp>

namespace sf {
	class Image;
	class RenderTarget;
}

class Object {
	public:
		enum Type {
			Generic = 0,
			Car = 1,
			PowerUpFuel = 2,
			PowerUpRepairKit = 3
		};

		enum Flags {
			FlagNone = 0,
			FlagCollision = 1,
			FlagPlayer = 2,
			FlagNoScroll = 4,
			FlagPowerUp = 8,
			FlagKill = 16
		};

		Object( const sf::Image& image, Type type, int flags = FlagNone );

		void Update( float time );
		void Render( sf::RenderTarget& target ) const;

		void Move( float x, float y );
		void Rotate( float angle );
		void SetPosition( float x, float y );
		void SetRotation( float angle );
		void SetColor( const sf::Color& color );

		void SetRotationVelocity( float velocity );
		void SetVelocity( float x, float y );

		void MarkForRemoval();

		const sf::FloatRect& GetRect() const;
		const sf::Vector2f& GetVelocity() const;

		bool HasFlag( Flags flag ) const;
		Type GetType() const;

	private:
		void UpdateSpritePosition();

		Type   m_type;
		int    m_flags;

		sf::Sprite     m_sprite;
		sf::FloatRect  m_rect;
		sf::Vector2f   m_velocity;
		float          m_rotationvelocity;
};

#endif
