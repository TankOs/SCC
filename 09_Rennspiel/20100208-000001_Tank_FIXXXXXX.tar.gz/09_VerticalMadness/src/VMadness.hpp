#ifndef __SRC_VMADNESS_HPP__
#define __SRC_VMADNESS_HPP__

#include "Street.hpp"
#include "EventReceiver.hpp"
#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/Graphics/Text.hpp>
#include <SFML/Graphics/Image.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Audio/Sound.hpp>
#include <SFML/Audio/SoundBuffer.hpp>
#include <SFML/System/Clock.hpp>
#include <list>

class VMadness : public EventReceiver {
	public:
		VMadness( const sf::VideoMode& videomode );

		void Run();

		virtual bool OnPowerupCollected( const Object& player, const Object& powerup );
		virtual bool OnPlayerCollided( const Object& player, const Object& other );
		virtual void OnPlayerTouchedCurbs( const Object& player, bool left );

	private:
		typedef std::list<sf::Text>  TextList;

		void ChangeScore( int delta );
		void CreatePopText( const sf::String& msg );
		void ChangeLevel( unsigned char level );
		void ChangeHealth( float delta );
		void SetBigText( const sf::String& str );

		sf::RenderWindow  m_window;
		const sf::Input&  m_input;

		Street  m_street;

		float          m_fuel;
		float          m_health;
		unsigned int   m_points;
		Object*        m_player;
		unsigned char  m_level;

		bool       m_startup;
		bool       m_gameover;
		sf::Clock  m_startupclock;
		sf::Clock  m_levelclock;
		bool       m_fuelwarned;
		float      m_secondswarned;

		sf::Font  m_font;

		sf::Image   m_pointsbgimage;
		sf::Sprite  m_pointsbg;
		sf::Text    m_pointstext;
		sf::Image   m_fuelbgimage;
		sf::Sprite  m_fuelbg;
		sf::Text    m_fueltext;
		sf::Text    m_leveltext;

		TextList  m_poptexts;

		sf::SoundBuffer  m_crashbuffer;
		sf::SoundBuffer  m_powerupbuffer;
		sf::Sound        m_crashsound;
		sf::Sound        m_powerupsound;
};

#endif
