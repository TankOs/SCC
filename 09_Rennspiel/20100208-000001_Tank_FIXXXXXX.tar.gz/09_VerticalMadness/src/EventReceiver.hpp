#ifndef __EVENTRECEIVER_HPP__
#define __EVENTRECEIVER_HPP__

class Object;

class EventReceiver {
	public:
		virtual bool OnPowerupCollected( const Object& player, const Object& powerup ) = 0;
		virtual bool OnPlayerCollided( const Object& player, const Object& other ) = 0;
		virtual void OnPlayerTouchedCurbs( const Object& player, bool left ) = 0;
};

#endif
