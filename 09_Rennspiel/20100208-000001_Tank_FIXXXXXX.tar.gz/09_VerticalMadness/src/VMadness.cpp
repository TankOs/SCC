#include "VMadness.hpp"
#include <SFML/System/Randomizer.hpp>
#include <iostream> // XXX
#include <sstream>
#include <iomanip>

const float LogicFrameTime = 1.f / 60.f; // Run 60 updates per second.

VMadness::VMadness( const sf::VideoMode& videomode ) :
	m_window( videomode, "Vertical Madness", sf::Style::Close ),
	m_input( m_window.GetInput() ),
	m_street( *this, sf::Vector2i( videomode.Width, videomode.Height ) ),
	m_fuel( 100.f ),
	m_health( 100.f ),
	m_points( 0 ),
	m_player( 0 ),
	m_level( 1 ),
	m_startup( true ),
	m_gameover( false ),
	m_fuelwarned( false ),
	m_secondswarned( 0.f ),
	m_pointstext( L"00000000", m_font ),
	m_fueltext( L"Fuel: 100%", m_font ),
	m_leveltext( L"Level 1", m_font, 60 )
{
	m_font.LoadFromFile( "data/chumbly.ttf" );

	m_window.UseVerticalSync( true );
	m_window.EnableKeyRepeat( false );

	m_fueltext.SetPosition( 10.f, static_cast<float>( videomode.Height ) - m_fueltext.GetRect().GetSize().y - 10.f );

	m_pointsbgimage.LoadFromFile( "data/points.png" );
	m_pointsbg.SetImage( m_pointsbgimage );
	m_pointstext.SetStyle( sf::Text::Italic );

	m_pointsbg.SetPosition( 20, 20 );
	m_pointstext.SetPosition( 40, 45 );

	m_fuelbgimage.LoadFromFile( "data/fuelbg.png" );
	m_fuelbg.SetImage( m_fuelbgimage );
	m_fueltext.SetStyle( sf::Text::Italic );

	m_fuelbg.SetPosition( static_cast<float>( videomode.Width - m_fuelbgimage.GetWidth() - 20 ), 20 );
	m_fueltext.SetPosition( m_fuelbg.GetPosition().x + 20, 45 );

	m_crashbuffer.LoadFromFile( "data/crash.ogg" );
	m_powerupbuffer.LoadFromFile( "data/powerup.ogg" );
	m_crashsound.SetBuffer( m_crashbuffer );
	m_powerupsound.SetBuffer( m_powerupbuffer );

	m_leveltext.SetPosition( static_cast<float>( videomode.Width ) / 2.f, static_cast<float>( videomode.Height ) / 2.f );
}

void VMadness::Run() {
	sf::Event           event;
	float               elapsed( 0.f );
	float               nextobstacle( 0.f );
	sf::Vector2f        velocity( 0.f, 0.f );
	TextList::iterator  tliter;
	TextList::iterator  tliterend;

	ChangeLevel( 1 );

	while( m_window.IsOpened() ) {
		// Fetch events.
		while( m_window.GetEvent( event ) ) {
			if( event.Type == sf::Event::Closed ) {
				m_window.Close();
			}
			else if( event.Type == sf::Event::KeyPressed ) {
				if( event.Key.Code == sf::Key::L ) {
					ChangeLevel( static_cast<unsigned char>( m_level + 1 ) );
				}
			}
		}

		if( m_startup ) {
			if( m_startupclock.GetElapsedTime() >= 2.5f ) {
				m_startup = false;
			}
		}
		else if( !m_gameover ) {
			// Movement.
			velocity.x = 0.f;
			velocity.y = 0.f;
			if( m_input.IsKeyDown( sf::Key::Right ) ) {
				velocity.x += 5.f;
			}
			if( m_input.IsKeyDown( sf::Key::Left ) ) {
				velocity.x -= 5.f;
			}
			if( m_input.IsKeyDown( sf::Key::Up ) ) {
				velocity.y -= 5.f;
			}
			if( m_input.IsKeyDown( sf::Key::Down ) ) {
				velocity.y += 5.f;
			}

			m_player->SetVelocity( velocity.x, velocity.y );
		
			if( m_levelclock.GetElapsedTime() >= 60.f ) {
				ChangeLevel( static_cast<unsigned char>( m_level + 1 ) );
			}
			else if( m_levelclock.GetElapsedTime() >= 45.f && m_secondswarned < 45.f ) {
				m_secondswarned = 45.f;
				CreatePopText( L"15 seconds..." );
			}
			else if( m_levelclock.GetElapsedTime() >= 30.f && m_secondswarned < 30.f ) {
				m_secondswarned = 30.f;
				CreatePopText( L"30 seconds..." );
			}
		}

		// Frame-independent update loop.
		elapsed += m_window.GetFrameTime();
		if( elapsed >= LogicFrameTime ) {
			unsigned int  frames( static_cast<unsigned int>( elapsed / LogicFrameTime ) );

			for( unsigned int frame = 0; frame < frames; ++frame ) {
				if( !m_gameover ) {
					if( !m_startup ) {
						m_fuel -= (3.f + velocity.y * -.5f) * LogicFrameTime;
						ChangeScore( 10 * m_level );

						if( !m_fuelwarned && m_fuel < 25.f ) {
							CreatePopText( L"Low fuel!" );
							m_fuelwarned = true;
						}
						else if( m_fuelwarned && m_fuel >= 25.f ) {
							m_fuelwarned = false;
						}
						else if( m_fuel <= 0.f ) {
							CreatePopText( L"OUT OF FUEL :-(" );
							SetBigText( L"GAME OVER" );
							m_fuel = 0.f;
							m_gameover = true;
						}

						// Spawn obstacles and stuff.
						nextobstacle -= LogicFrameTime;
						if( nextobstacle < 0.f ) {
							if( m_fuel <= 60.f && sf::Randomizer::Random( 0, m_fuel <= 30.f ? 1 : 2 ) == 0 ) {
								m_street.SpawnFuel();
							}

							if( m_health < 100.f && sf::Randomizer::Random( 0, 3 ) == 0 ) {
								m_street.SpawnRepairKit();
							}

							int  type( sf::Randomizer::Random( 0, 2 ) );

							if( type < 2 ) {
								m_street.SpawnObstacle();

								if( m_level > 2 && sf::Randomizer::Random( 0, 2 ) == 0 ) {
									m_street.SpawnObstacle();
								}
							}
							else if( type < 3 ) {
								m_street.SpawnCar();

								if( m_level > 2 && sf::Randomizer::Random( 0, 2 ) == 0 ) {
									m_street.SpawnCar();
								}
							}

							nextobstacle = std::max( 1.5f / static_cast<float>( m_level ), .5f );
						}
					}

					m_street.Update( LogicFrameTime );
				}
			}

			elapsed -= static_cast<float>( frames ) * LogicFrameTime;
		}

		{
			std::stringstream  sstr;
			sstr << std::setprecision( 1 ) << std::fixed << m_fuel << "%";
			m_fueltext.SetString( sstr.str() );

			sstr.str( "" );
			sstr << std::setfill( '0' ) << std::setw( 8 ) << m_points;
			m_pointstext.SetString( sstr.str() );
		}

		// Render scene.
		m_window.Clear();
		m_street.Render( m_window );
		m_window.Draw( m_pointsbg );
		m_window.Draw( m_pointstext );
		m_window.Draw( m_fuelbg );
		m_window.Draw( m_fueltext );

		if( m_poptexts.size() ) {
			tliter = m_poptexts.begin();
			tliterend = m_poptexts.end();

			while( tliter != tliterend ) {
				if( tliter->GetColor().a <= 3 ) {
					tliter = m_poptexts.erase( tliter );
					continue;
				}

				tliter->SetScale( tliter->GetScale().x + .008f, tliter->GetScale().x + .008f );
				tliter->SetColor( sf::Color( 255, 255, 255, static_cast<sf::Uint8>( tliter->GetColor().a - 3 ) ) );
				tliter->Move( 0.f, -2.2f );

				m_window.Draw( *tliter );
				++tliter;
			}
		}

		if( m_startup || m_gameover ) {
			// Shadow.
			m_leveltext.SetColor( sf::Color( 0, 0, 0, 80 ) );
			m_leveltext.Move( 5.f, 5.f );
			m_window.Draw( m_leveltext );

			m_leveltext.SetColor( sf::Color( 0, 255, 255, 255 ) );
			m_leveltext.Move( -5.f, -5.f );
			m_window.Draw( m_leveltext );
		}

		m_window.Display();
	}
}

bool VMadness::OnPowerupCollected( const Object& /*player*/, const Object& powerup ) {
	if( powerup.GetType() == Object::PowerUpFuel ) {
		m_fuel = std::min( m_fuel + 10.f, 100.f );
		ChangeScore( 2500 );
		CreatePopText( L"Fuel +10% (+2500)" );
	}
	else if( powerup.GetType() == Object::PowerUpRepairKit ) {
		ChangeHealth( 10.f );
		ChangeScore( 3500.f );
		CreatePopText( L"Repaired +10% (+3500)" );
	}

	m_powerupsound.Play();
	return true;
}

bool VMadness::OnPlayerCollided( const Object& /*player*/, const Object& other ) {
	if( other.GetType() == Object::Car ) {
		ChangeScore( -7500 );
		ChangeHealth( -15.f );
		CreatePopText( L"Car Crash (-7500, -15 HP)" );
	}
	else {
		ChangeScore( -5000 );
		ChangeHealth( -5.f );
		CreatePopText( L"Crash (-5000, -5 HP)" );
	}

	//m_crashsound.Play();

	return true;
}

void VMadness::OnPlayerTouchedCurbs( const Object& /*player*/, bool /*left*/ ) {
}

void VMadness::ChangeScore( int delta ) {
	if( delta < 0 ) {
		if( static_cast<unsigned int>( delta * -1 ) > m_points ) {
			m_points = 0;
		}
		else {
			m_points -= static_cast<unsigned int>( delta * -1 );
		}
	}
	else {
		m_points += static_cast<unsigned int>( delta );
	}
}

void VMadness::CreatePopText( const sf::String& msg ) {
	sf::Text  text( msg, m_font );

	text.SetOrigin( static_cast<float>( text.GetRect().GetSize().x ) / 2.f, static_cast<float>( text.GetRect().GetSize().y ) / 2.f );
	text.SetPosition(
		static_cast<float>( m_window.GetWidth() ) / 2.f,
		static_cast<float>( m_window.GetHeight() ) / 2.f + static_cast<float>( m_poptexts.size() ) * text.GetRect().GetSize().y
	);

	m_poptexts.push_back( text );
}

void VMadness::ChangeLevel( unsigned char level ) {
	m_level = level;
	m_startup = true;
	m_startupclock.Reset();
	m_levelclock.Reset();
	m_fuelwarned = false;
	m_secondswarned = 0.f;
	m_fuel = 100.f;
	m_health = 100.f;
	m_street.Clear();

	if( level < 3 ) {
		m_street.SetLanes( 5 );
		m_street.SetSpeed( 5.f );
	}
	else if( level < 5 ) {
		m_street.SetLanes( 4 );
		m_street.SetSpeed( 7.f );
	}
	else if( level < 7 ) {
		m_street.SetLanes( 3 );
		m_street.SetSpeed( 9.f );
	}
	else {
		m_street.SetLanes( 3 );
		m_street.SetSpeed( 13.f );
	}

	m_player = &m_street.SpawnPlayer();

	std::stringstream  sstr;
	sstr << "Level " << static_cast<int>( m_level );
	SetBigText( sstr.str() );
}

void VMadness::SetBigText( const sf::String& str ) {
	m_leveltext.SetString( str );
	m_leveltext.SetOrigin( m_leveltext.GetRect().GetSize().x / 2.f, m_leveltext.GetRect().GetSize().y / 2.f );
}

void VMadness::ChangeHealth( float delta ) {
	m_health = std::max( m_health + delta, 0.f );

	m_player->SetColor(
		sf::Color(
			static_cast<unsigned char>( std::min( 255.f, std::max( 0.f, 255.f * m_health / 100.f ) ) ),
			255,
			255
		)
	);

	if( m_health == 0.f ) {
		SetBigText( L"Wrecked!" );
		m_gameover = true;
	}
	else if( m_health < 35.f ) {
		CreatePopText( L"HEALTH WARNING!" );
	}
}
