#include "Object.hpp"
#include <SFML/Graphics/RenderTarget.hpp>
#include <SFML/Graphics/Image.hpp>

Object::Object( const sf::Image& image, Type type, int flags ) :
	m_type( type ),
	m_flags( flags ),
	m_sprite( image ),
	m_rect( 0.f, 0.f, static_cast<float>( image.GetWidth() ), static_cast<float>( image.GetHeight() ) ),
	m_velocity( 0.f, 0.f ),
	m_rotationvelocity( 0.f )
{
	m_sprite.SetOrigin( static_cast<float>( image.GetWidth() ) / 2.f, static_cast<float>( image.GetHeight() ) / 2.f );
}

void Object::Update( float /*time*/ ) {
	Move( m_velocity.x, m_velocity.y );
	Rotate( m_rotationvelocity );
}

void Object::Render( sf::RenderTarget& target ) const {
	if( (m_flags & FlagKill) == 0 ) {
		target.Draw( m_sprite );
	}
}

void Object::Move( float x, float y ) {
	m_rect.Offset( x, y );
	UpdateSpritePosition();
}

const sf::FloatRect& Object::GetRect() const {
	return m_rect;
}

void Object::SetPosition( float x, float y ) {
	m_rect.Right = x + m_rect.GetSize().x;
	m_rect.Bottom = y + m_rect.GetSize().y;
	m_rect.Left = x;
	m_rect.Top = y;
	UpdateSpritePosition();
}

void Object::UpdateSpritePosition() {
	m_sprite.SetPosition(
		m_rect.Left + static_cast<float>( m_sprite.GetImage()->GetWidth() ) / 2.f,
		m_rect.Top + static_cast<float>( m_sprite.GetImage()->GetHeight() ) / 2.f
	);
}

void Object::Rotate( float angle ) {
	m_sprite.Rotate( angle );
}

void Object::SetRotationVelocity( float velocity ) {
	m_rotationvelocity = velocity;
}

void Object::SetVelocity( float x, float y ) {
	m_velocity.x = x;
	m_velocity.y = y;
}

const sf::Vector2f& Object::GetVelocity() const {
	return m_velocity;
}

void Object::SetRotation( float angle ) {
	m_sprite.SetRotation( angle );
}

bool Object::HasFlag( Flags flag ) const {
	return m_flags & flag;
}

void Object::MarkForRemoval() {
	m_flags |= FlagKill;
}

Object::Type Object::GetType() const {
	return m_type;
}

void Object::SetColor( const sf::Color& color ) {
	m_sprite.SetColor( color );
}
