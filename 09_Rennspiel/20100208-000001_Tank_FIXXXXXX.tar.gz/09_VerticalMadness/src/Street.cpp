#include "Street.hpp"
#include <SFML/Graphics/RenderTarget.hpp>
#include <SFML/System/Randomizer.hpp>
#include <iostream> // XXX

enum ImageType {
	Grass = 0,
	Lane = 1,
	Curb = 2,
	Ball = 3,
	Fuel = 4,
	Dreirad = 5,
	RepairKit = 6,
	NumImages
};

Street::Street( EventReceiver& receiver, const sf::Vector2i& size, unsigned int lanes ) :
	m_receiver( receiver ),
	m_size( size ),
	m_lanerect( 0.f, 0.f, 0.f, 0.f ),
	m_yoffset( 0.f ),
	m_speed( 5.f ),
	m_scrollview( sf::FloatRect( 0.f, 0.f, static_cast<float>( size.x ), static_cast<float>( size.y ) ) )
{
	m_images.resize( NumImages );
	LoadImage( Grass, "data/grass.png" );
	LoadImage( Lane, "data/lane.png" );
	LoadImage( Curb, "data/curb.png" );
	LoadImage( Ball, "data/ball.png" );
	LoadImage( Fuel, "data/fuel.png" );
	LoadImage( Dreirad, "data/dreirad.png" );
	LoadImage( RepairKit, "data/pliers.png" );

	m_grass.SetImage( m_images[Grass] );
	m_lane.SetImage( m_images[Lane] );
	m_curb.SetImage( m_images[Curb] );

	SetLanes( lanes );
}

void Street::LoadImage( unsigned int index, const std::string& filename ) {
	if( index >= m_images.size() ) {
		return;
	}

	m_images[index].LoadFromFile( filename );
	m_images[index].SetSmooth( false );
}

void Street::Update( float time ) {
	m_yoffset += m_speed;
	if( m_yoffset >= static_cast<float>( m_images[Lane].GetHeight() ) ) {
		m_yoffset -= static_cast<float>( m_images[Lane].GetHeight() );
		m_scrollview.Reset( sf::FloatRect( 0.f, 0.f, static_cast<float>( m_size.x ), static_cast<float>( m_size.y ) ) );
		m_scrollview.Move( 0.f, -m_yoffset );
	}
	else {
		m_scrollview.Move( 0.f, -m_speed );
	}

	ObjectList::iterator  iter( m_objects.begin() );
	ObjectList::iterator  iterend( m_objects.end() );

	while( iter != iterend ) {
		if( iter->HasFlag( Object::FlagKill ) ) {
			iter = RemoveObject( iter );
			continue;
		}

		iter->Update( time );

		if( iter->HasFlag( Object::FlagNoScroll ) == false ) {
			iter->Move( 0.f, m_speed );
		}

		// Check if object is out of range.
		if( iter->GetRect().Top > m_lanerect.Bottom ) {
			if( iter->HasFlag( Object::FlagPlayer ) == false ) {
				iter = RemoveObject( iter );
				continue;
			}

			iter->SetPosition( iter->GetRect().Left, m_lanerect.Bottom );
		}

		char  out( 0 );
		if( iter->GetRect().Left < m_lanerect.Left ) {
			out = -1;
		}
		else if( iter->GetRect().Right >= m_lanerect.Right ) {
			out = 1;
		}

		if( out != 0 ) {
			iter->SetPosition(
				out < 0 ? m_lanerect.Left : m_lanerect.Right - iter->GetRect().GetSize().x,
				iter->GetRect().Top
			);
		}

		// Check for collisions when object is player.
		if( iter->HasFlag( Object::FlagPlayer ) ) {
			ObjectPtrSet::iterator  citer( m_collisionobjects.begin() );
			ObjectPtrSet::iterator  citerend( m_collisionobjects.end() );

			while( citer != citerend ) {

				if( (*citer)->GetRect().Intersects( iter->GetRect() ) ) {
					if( (*citer)->HasFlag( Object::FlagPowerUp ) == false ) { // No powerup, this is gonna hurt. :-(
						if( m_receiver.OnPlayerCollided( *iter, **citer ) ) {
							(*citer)->MarkForRemoval();
						}
					}
					else {
						if( m_receiver.OnPowerupCollected( *iter, **citer ) ) {
							(*citer)->MarkForRemoval();
						}
					}
				}

				++citer;
			}
		}

		++iter;
	}

}

void Street::Render( sf::RenderTarget& target ) const {
	const sf::View&  oldview( target.GetView() );
	
	target.SetView( m_scrollview );

	for( float y = -static_cast<float>( m_images[Grass].GetHeight() ); y < static_cast<float>( m_size.y ); y += static_cast<float>( m_images[Grass].GetHeight() ) ) {
		for( float x = 0.f; x < static_cast<float>( m_size.x ); x += static_cast<float>( m_images[Grass].GetWidth() ) ) {
			m_grass.SetPosition( x, y );
			target.Draw( m_grass );
		}

		for( unsigned int lane = 0; lane < m_lanes; ++lane ) {
			m_lane.SetPosition(
				m_lanerect.Left + static_cast<float>( lane * m_images[Lane].GetWidth() ),
				y // Important: Grass' and lane's heights must be the same.
			);

			target.Draw( m_lane );
		}

		m_curb.SetPosition( m_lanerect.Left, y );
		target.Draw( m_curb );
		m_curb.SetPosition( m_lanerect.Right - static_cast<float>( m_images[Curb].GetWidth() ), y );
		target.Draw( m_curb );
	}

	target.SetView( target.GetDefaultView() );

	ObjectList::const_iterator  citer( m_objects.begin() );
	ObjectList::const_iterator  citerend( m_objects.end() );
	for( ; citer != citerend; ++citer ) {
		citer->Render( target );
	}

	target.SetView( oldview );
}

void Street::SetLanes( unsigned int lanes ) {
	if( lanes < 1 ) {
		lanes = 1;
	}

	m_lanes = lanes;

	m_lanerect.Left = static_cast<float>( m_size.x / 2 - m_lanes * m_images[Lane].GetWidth() / 2 );
	m_lanerect.Top = 0.f;
	m_lanerect.Right = m_lanerect.Left + static_cast<float>( m_lanes * m_images[Lane].GetWidth() );
	m_lanerect.Bottom = static_cast<float>( m_size.y );
}

void Street::SpawnObstacle() {
	Object  obstacle( m_images[Ball], Object::Generic, Object::FlagCollision );

	obstacle.SetPosition(
		sf::Randomizer::Random( m_lanerect.Left, m_lanerect.Right - static_cast<float>( m_images[Fuel].GetWidth() ) ),
		m_lanerect.Top
	);

	obstacle.SetRotationVelocity( 7.f );
	obstacle.SetVelocity( 0.f, sf::Randomizer::Random( -2.f, m_speed ) );

	AddObject( obstacle );
}

Object& Street::SpawnPlayer() {
	Object  player( m_images[Dreirad], Object::Car, Object::FlagCollision | Object::FlagPlayer | Object::FlagNoScroll );

	player.SetPosition(
		m_lanerect.Left + m_lanerect.GetSize().x / 2.f - player.GetRect().GetSize().x / 2.f,
		m_lanerect.Bottom - player.GetRect().GetSize().y
	);

	//player.SetRotation( 90.f );

	return AddObject( player );
}

Object& Street::AddObject( const Object& object ) {
	m_objects.push_back( object );

	if( object.HasFlag( Object::FlagCollision ) && object.HasFlag( Object::FlagPlayer ) == false ) {
		m_collisionobjects.insert( &m_objects.back() );
	}

	return m_objects.back();
}

Street::ObjectList::iterator Street::RemoveObject( const Street::ObjectList::iterator& iter ) {
	ObjectPtrSet::iterator  citer( m_collisionobjects.find( &(*iter) ) );

	if( citer != m_collisionobjects.end() ) {
		m_collisionobjects.erase( citer );
	}

	return m_objects.erase( iter );
}

void Street::SpawnFuel() {
	Object  fuel( m_images[Fuel], Object::PowerUpFuel, Object::FlagCollision | Object::FlagPowerUp );

	fuel.SetPosition(
		sf::Randomizer::Random( m_lanerect.Left, m_lanerect.Right - static_cast<float>( m_images[Fuel].GetWidth() ) ),
		m_lanerect.Top
	);

	AddObject( fuel );
}

void Street::Clear() {
	m_collisionobjects.clear();
	m_objects.clear();
}

void Street::SetSpeed( float speed ) {
	m_speed = speed;
}

void Street::SpawnCar() {
	Object  car( m_images[Dreirad], Object::Car, Object::FlagCollision );

	car.SetPosition(
		sf::Randomizer::Random( m_lanerect.Left, m_lanerect.Right - static_cast<float>( m_images[Fuel].GetWidth() ) ),
		m_lanerect.Top - static_cast<float>( m_images[Dreirad].GetHeight() )
	);

	car.SetRotation( 180.f );
	car.SetVelocity( 0.f, sf::Randomizer::Random( 1.f, 3.f ) );

	AddObject( car );
}

void Street::SpawnRepairKit() {
	Object  repairkit( m_images[RepairKit], Object::PowerUpRepairKit, Object::FlagCollision | Object::FlagPowerUp );

	repairkit.SetPosition(
		sf::Randomizer::Random( m_lanerect.Left, m_lanerect.Right - static_cast<float>( m_images[RepairKit].GetWidth() ) ),
		m_lanerect.Top - static_cast<float>( m_images[RepairKit].GetHeight() )
	);

	AddObject( repairkit );
}
