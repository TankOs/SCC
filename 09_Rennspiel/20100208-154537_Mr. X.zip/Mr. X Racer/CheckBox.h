#pragma once
#include <SFML/Graphics.hpp>
#include <vector>

class CheckBox;

class CheckBoxGroup {
	friend class CheckBox;
	std::vector<CheckBox*> Boxen;
	void Add(CheckBox* Obj);
	void Check(CheckBox* Activator);
};

class CheckBox : public sf::Drawable {
	friend class CheckBoxGroup;
private:
	sf::String Text;
	sf::Shape Rand;
	sf::Shape Line1, Line2;
	CheckBoxGroup *Group;
	bool Checked;
public:
	void Render(sf::RenderTarget& Target) const;
	CheckBox(sf::Vector2f Position, const sf::Unicode::Text& text = L"", CheckBoxGroup* group = 0, int LineWidth = 2, int Size = 15, bool CheckState = true, const sf::Color& LineCol = sf::Color(0,0,0));
	bool IsClicked(const sf::Vector2i& MousePosition);
	bool IsChecked() const;
};