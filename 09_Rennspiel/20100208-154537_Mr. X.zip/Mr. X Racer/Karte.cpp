#include "Karte.h"
#include <sstream>
#include <iostream>
#include <fstream>

Karte::Karte() {
	//Init Graphic
	Gras.LoadFromFile("Grafik/GrasTile.png");
	Erg�nzung.LoadFromFile("Grafik/Ergaenzung.png");
	Tiles.resize(24);
	std::ostringstream os;
	for(unsigned short i = 0; i < Tiles.size(); ++i) {
		os << i;
		if(i < 10) {
			Tiles[i].LoadFromFile("Grafik/0" + os.str() + ".png");
		}
		else {
			Tiles[i].LoadFromFile("Grafik/" + os.str() + ".png");
		}
		os.str("");
	}
}
void Karte::Render(sf::RenderTarget& Target) const {
	Target.Draw(Sp);
}
sf::Vector2<bool> Karte::Kollision(Auto& A) {
	for(int x = 0; x < A.Sp.GetSubRect().GetWidth(); ++x) {
		for(int y = 0; y < A.Sp.GetSubRect().GetHeight(); ++y) {
			if(A.Sp.GetPixel(x, y).a == 0) {
				continue;
			}
			sf::Vector2f temp = A.Sp.TransformToGlobal(sf::Vector2f(x, y));

			if(RenderedBackImage.GetPixel(temp.x, temp.y) == sf::Color(2,2,2)) {
				return(sf::Vector2<bool>(false, true));
			}
			if(RenderedBackImage.GetPixel(temp.x, temp.y) == sf::Color::Black) {
				return(sf::Vector2<bool>(true, false));
			}
		}
	}
	return(sf::Vector2<bool>(false, false));
}
bool Karte::LoadFile(const std::string& Kartenname) {
	sf::Vector2i StartPos;
	sf::Vector2i Size;

	std::ifstream ifs(("Karten/" + Kartenname + ".rsf").c_str());
	if(!ifs.good()) {
		return false;
	}
	std::string str;
	std::getline(ifs, str);
	if(str != "�#") {
		return false;
	}
	try {
		std::istringstream iss;
		//Zeile 1
		std::getline(ifs, str);
		iss.str(str.substr(0, str.find("|")));
		iss >> Size.x;
		iss.clear();
		iss.str(str.substr(str.find("|")+1));
		iss >> Size.y;
		iss.clear();
		//Zeile 2
		std::getline(ifs, str);
		iss.str(str.substr(0, str.find("|")));
		iss >> StartPos.x;
		iss.clear();
		iss.str(str.substr(str.find("|")+1));
		iss >> StartPos.y;
		iss.clear();
		//Startposition setzen
		Gr�n.Reset();
		Lila.Reset();
		Gr�n.Sp.SetPosition(StartPos.x * 300 + 149, StartPos.y * 300 + 188);
		Lila.Sp.SetPosition(StartPos.x * 300 + 149, StartPos.y * 300 + 188);
		//RenderedImage vorbereiten
		RenderedImage.Create(Size.x * 300, Size.y * 300, sf::Color(0,200,0));
		RenderedBackImage.Create(Size.x * 300, Size.y * 300, sf::Color(255,0,0));
		//Schleife
		for(int y = 0; y < Size.y; ++y) {
			for(int x = 0; x < Size.x; ++x) {
				RenderedImage.Copy(Gras, x*300, y*300);
			}
		}
		int temp;
		for(int y = 0; y < Size.y; ++y) {
			std::getline(ifs, str);
			for(int x = 0; x < Size.x; ++x) {
				iss.str(str.substr(0, 2));
				iss >> temp;
				if(temp != 24) {
					RenderedBackImage.Copy(Tiles[temp], x*300, y*300, sf::IntRect(0,0,0,0), true);
					RenderedImage.Copy(Tiles[temp], x*300, y*300, sf::IntRect(0,0,0,0), true);
					if(temp == 2 || temp == 9 || temp == 12 || temp == 18) {
						RenderedBackImage.Copy(Erg�nzung, (x-1)*300, y*300, sf::IntRect(0,0,0,0), true);
						RenderedImage.Copy(Erg�nzung, (x-1)*300, y*300, sf::IntRect(0,0,0,0), true);
					}
				}
				if(str.find("|") != -1) {
					str = str.substr(3);
				}
				iss.clear();
			}
		}
	}
	catch(...) {
		return false;
	}
	ifs.close(); 
	ChangeImage(Sp, RenderedImage, true);
	return true;
}