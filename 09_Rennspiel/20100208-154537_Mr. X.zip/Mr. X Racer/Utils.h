#ifndef RACER_UTILS_H
#define RACER_UTILS_H

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <sstream>
#include "Ranking.h"

#define BOGENMA�FAKTOR 57.295779513082320876798154814105f

sf::Color RandomGrey();
sf::Vector2f CreateVector(float Angle, float Speed);
void ChangeImage(sf::Sprite& sprite, const sf::Image& Img, const bool ChangeSize);

class Clock : public sf::Drawable {
	sf::Clock timer;
	float refresh;
	float Framerate;
	float Frametime;
	float SinceLastRefresh;
	unsigned int Counter;
public:
	Clock(float RefreshTime = 0.0f);
	void Refresh();
	const float& GetFrametime() const;
	void Render(sf::RenderTarget& Target) const;
};

class Converter {
	Converter() {}
	static std::ostringstream os;
	friend class Time;
public:
	template<typename T>
	static std::string ToString(const T& Obj) {
		os.str("");
		os << Obj;
		return(os.str());
	}
	static std::string ToZeitString(float Obj) {
		os.str("");
		os << Obj;
		std::string temp = os.str();
		if(temp.find(".") != -1) {
			temp.replace(temp.find("."), 1, ":");
		}
		else {
			temp += ":00";
		}
		temp = temp.substr(0, temp.find(":")+3);
		return(temp);
	}
};

#endif
