#ifndef RACER_KARTE_H
#define RACER_KARTE_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include "Utils.h"
#include "Auto.h"

class Karte : public sf::Drawable {
private:
	std::vector<sf::Image> Tiles;
	sf::Image Gras;
	sf::Image Erg�nzung;
	sf::Image RenderedImage;
	sf::Image RenderedBackImage;
public:
	Auto Lila, Gr�n;
	sf::Sprite Sp;
	Karte();
	void Render(sf::RenderTarget& Target) const;
	sf::Vector2<bool> Kollision(Auto& A);
	bool LoadFile(const std::string& Kartenname);
};

#endif
