#include "Button.h"

void Button::Render(sf::RenderTarget& Target) const {
	Target.Draw(Rand);
	Target.Draw(Text);
}
bool Button::IsClicked(const sf::Vector2i& MousePosition) const {
	return(MousePosition.x > Rand.GetPointPosition(0).x && MousePosition.x < Rand.GetPointPosition(2).x && MousePosition.y > Rand.GetPointPosition(0).y && MousePosition.y < Rand.GetPointPosition(2).y);
}
void Button::SetText(const sf::Unicode::Text& sText) {
	Text.SetText(sText);
}
sf::Unicode::Text Button::GetText() const {
	return(Text.GetText());
}
Button::Button(const sf::Unicode::Text& sText, const sf::Vector2f& Pos1, const sf::Vector2f& Pos2) {
	float Border = 8;
	Text.SetText(sText);
	Text.SetSize(40);
	Text.SetColor(sf::Color::Color(255,255,255));
	Text.SetPosition(((Pos2.x+Pos1.x) / 2 - Text.GetRect().GetWidth() / 2), ((Pos2.y+Pos1.y) / 2 - Text.GetRect().GetHeight() / 2));
	Rand = sf::Shape::Rectangle(Pos1.x + Border, Pos1.y + Border, Pos2.x - Border, Pos2.y - Border, sf::Color(0,0,0,0), Border, sf::Color(0,0,0,80));
}