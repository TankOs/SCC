#ifndef SFML_EL__RANKING_H
#define SFML_EL__RANKING_H

#include <vector>
#include <string>

template<typename T>
struct RankValue {
	RankValue();
	RankValue(const T& Val, const std::string& AI);
	T Value;
	std::string AddInfos;
};

template<typename T>
class Ranking {
private:
	std::vector<RankValue<T> > Values;
	void Sort();
	bool HighToLow;
public:
	//Default-Constructor
	//______________________
	Ranking();

	unsigned int size() const {
		return Values.size();
	}
	void pop_back() {
		Values.pop_back();
	}

	//Sets the sort order
	//	highToLow: true means values will be sorted from highest to lowest
	//______________________
	void SetSortOrder(bool highToLow);

	//Returns the sort order. true means values are sorted from highest to lowest
	//	Group: It will be added to this group
	//______________________
	bool GetSortOrder() const;

	//Reads values from a text file
	//	filename: Name of the file to read
	//______________________
	void ReadFromFile(const std::string& filename);

	//Saves this Ranking to a file
	//	filename: Name of the file to save
	//______________________
	void SaveToFile(const std::string& filename) const;

	//operator[] returns a reference to the value at the position "index"
	//	index: position of the value
	//______________________
	RankValue<T>& operator[] (unsigned int index);
	
	//Inserts a value to the ranking
	//	Value: Value to insert
	//______________________
	void Insert(const RankValue<T>& Value);
};

#include "Ranking.inl"

#endif
