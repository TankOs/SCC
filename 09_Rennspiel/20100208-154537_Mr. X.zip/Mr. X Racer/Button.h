#pragma once
#include <SFML/Graphics.hpp>

class Button : public sf::Drawable {
private:
	sf::Shape Rand;
	sf::String Text;
public:
	void Render(sf::RenderTarget& Target) const;
	bool IsClicked(const sf::Vector2i& MousePosition) const;
	void SetText(const sf::Unicode::Text& sText);
	sf::Unicode::Text GetText() const;
	Button() {}
	Button(const sf::Unicode::Text& sText, const sf::Vector2f& Pos1, const sf::Vector2f& Pos2);
};