#pragma once
#include <set>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include "Utils.h"

class Dust;

struct Partikel : public sf::Drawable {
	Dust *Owner;
	float Angle;
	float LifeTime;
	float AlphaTime;
	sf::Sprite Sp;
	Partikel(Dust* owner, float angle, sf::Sprite sp);
	void Process(std::multiset<Partikel>::iterator& i, float ElapsedTime, float Speed);
	void DecreaseAlpha();
private:
	void Render(sf::RenderTarget& Target) const;
};

bool operator<(const Partikel &P, const Partikel &Q);

class Dust : public sf::Drawable {
private:
	std::multiset<Partikel> Sprites;
	float ElapsedCreator, ElapsedFadeOut;
	static const float& Time;
	void New();
	void Render(sf::RenderTarget& Target) const;
public:
	void Erase(std::multiset<Partikel>::iterator& i);
	sf::Vector2f Position;
	float Angle;
	static const float Speed;
	Dust();
	void Run();
};