#include "CheckBox.h"

void CheckBoxGroup::Add(CheckBox* Obj) {
	Boxen.push_back(Obj);
}
void CheckBoxGroup::Check(CheckBox* Activator) {
	for(std::vector<CheckBox*>::iterator i = Boxen.begin(); i != Boxen.end(); ++i) {
		if(*i == Activator) {
			(*i)->Checked = true;
		}
		else {
			(*i)->Checked = false;
		}
	}
}

CheckBox::CheckBox(sf::Vector2f Position, const sf::Unicode::Text& text, CheckBoxGroup* group, int LineWidth, int Size, bool CheckState, const sf::Color& Col) : Group(group), Checked(CheckState) {
	if(Group != 0) {
		Group->Add(this);
	}
	Position.x += LineWidth;
	Position.y += LineWidth;
	Size -= LineWidth;
	Line1 = sf::Shape::Line((Position.x+1), Position.y+Size/2, (Position.x+Size/2-1), (Position.y+Size-1), LineWidth, Col);
	Line2 = sf::Shape::Line((Position.x+Size/2-1), (Position.y+Size-1), (Position.x+Size-1), (Position.y+1), LineWidth, Col);
	Rand = sf::Shape::Rectangle(Position.x, Position.y, Position.x+Size, Position.y+Size, sf::Color(0,0,0,0), LineWidth, sf::Color(Col.r,Col.g,Col.b,std::max(Col.a - 155, 0)));
	Text.SetText(text);
	Text.SetPosition(Position.x+Size+5, Position.y-6);
	Text.SetColor(Col);
	Text.SetSize(20);
}
void CheckBox::Render(sf::RenderTarget& Target) const {
	if(Checked) {
		Target.Draw(Line1);
		Target.Draw(Line2);
	}
	Target.Draw(Rand);
	Target.Draw(Text);
}
bool CheckBox::IsClicked(const sf::Vector2i& MousePosition) {
	bool b = MousePosition.x > Rand.GetPointPosition(0).x && MousePosition.x < Rand.GetPointPosition(2).x && MousePosition.y > Rand.GetPointPosition(0).y && MousePosition.y < Rand.GetPointPosition(2).y;
	if(b) {
		Checked = !Checked;
		Group->Check(this);
	}
	return(b);
}
bool CheckBox::IsChecked() const {
	return(Checked);
}