#include "Auto.h"
#include <cmath>
#include "Utils.h"

sf::Image Auto::Img1;
sf::Image Auto::Img2;
const float Auto::m = 1500;

Auto::Auto() {
	Qualm1.Angle = 180;
	Qualm2.Angle = 180;
}
void Auto::Init(bool Gr�n) {
	if(Gr�n) {
		Sp.SetImage(Img1);
		Lenkfaktor = 70;
		F = 4000;
	}
	else {
		Sp.SetImage(Img2);
		Lenkfaktor = 60;
		F = 5000;
	}
	Sp.SetCenter(Sp.GetImage()->GetWidth()/2, Sp.GetImage()->GetHeight()/2);
}
void Auto::Reset() {
	v = 0;
	Angle = 0;
	Sp.SetRotation(0);
}
void Auto::Render(sf::RenderTarget& Target) const {
	Target.Draw(Sp);
	Target.Draw(Qualm1);
	Target.Draw(Qualm2);
}
void Auto::Beschleunigen(bool Ja, bool Vorw�rts) {
	float a = 0;
	if(Ja) {
		if(Vorw�rts) {
			a = 40.0f * F / m + 0.012f * 9.81f * m;
		}
		else {
			a = -(40.0f * F / m + 0.012f * 9.81f * m);
		}
	}
	if(v < 0.0f) {
		a += (0.012f * 9.81f * m);
		if(v > -0.1f) {
			v = 0.0f;
		}
	}
	else if(v > 0.0f) {
		a -= (0.012f * 9.81f * m);
		if(v < +0.1f) {
			v = 0.0f;
		}
	}
	v += a * t;
}
void Auto::Move() {
	Qualm1.Run();
	Qualm2.Run();
	Sp.Move(CreateVector(Angle, v*t));
	Qualm1.Position = Sp.GetPosition() + CreateVector(198.28+Angle, 117);
	Qualm2.Position = Sp.GetPosition() + CreateVector(196.48+Angle, 116);
	Sp.SetRotation(Angle);
	Qualm1.Angle = 180+Angle;
	Qualm2.Angle = 180+Angle;
}
void Auto::Lenken(bool Rechts) {
	if(v < 0) {
		Rechts = !Rechts;
	}
	float lf = Lenkfaktor * t;
	float x = 150.0f * std::tan(lf / BOGENMA�FAKTOR);
	if(x > std::max(v, -v)*t) {
		x = std::max(v, -v)*t;
		lf = std::atan(x/150.0f) * BOGENMA�FAKTOR;
	}
	if(Rechts) {
		Angle -= lf;
	}
	else {
		Angle += lf;
	}
}
void Auto::Init() {
	Img1.LoadFromFile("Grafik/Auto1.png");
	Img2.LoadFromFile("Grafik/Auto2.png");
}