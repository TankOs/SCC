#include "ParticleSystem.h"
#include <cmath>

bool operator<(const Partikel &P, const Partikel &Q) {
	return(P.LifeTime > Q.LifeTime);
}

Partikel::Partikel(Dust *owner, float angle, sf::Sprite sp) : Angle(angle), LifeTime(0), Sp(sp), Owner(owner) {
}
void Partikel::Process(std::multiset<Partikel>::iterator& i, float ElapsedTime, float Speed) {
	LifeTime += ElapsedTime;
	if(LifeTime > 7.5f || Sp.GetColor().a == 0) {
		Owner->Erase(i);
	}
	else {
		Angle += sf::Randomizer::Random(-5, 5);
		Sp.Move(CreateVector(Angle, ElapsedTime*Speed));
	}
}
void Partikel::DecreaseAlpha() {
	sf::Color x = Sp.GetColor();
	x.a -= std::min<sf::Uint8>(1, x.a);
	Sp.SetColor(x);
}
void Partikel::Render(sf::RenderTarget& Target) const {
	Target.Draw(Sp);
}

void Dust::New() {
	sf::Sprite Sp;
	Sp.SetPosition(Position);
	Sp.SetScale(sf::Randomizer::Random(1.5f, 3.0f), sf::Randomizer::Random(1.5f, 3.0f));
	Sp.Rotate(sf::Randomizer::Random(0.0f, 360.0f));
	Sp.SetColor(RandomGrey());
	Sprites.insert(Partikel(this, Angle + sf::Randomizer::Random(-50.0f, 50.0f), Sp));
}
void Dust::Render(sf::RenderTarget& Target) const {
	for(std::multiset<Partikel>::const_reverse_iterator i = Sprites.rbegin(); i != Sprites.rend(); ++i) {
		Target.Draw(*i);
	}
}
void Dust::Run() {
	ElapsedFadeOut += Time;
	ElapsedCreator += Time;
	for(std::multiset<Partikel>::iterator i = Sprites.begin(); i != Sprites.end(); ++i) {
		i->Process(i, Time, Speed + sf::Randomizer::Random(-Speed/2, Speed/2));
	}
	if(ElapsedFadeOut > 0.05f) {
		for(std::multiset<Partikel>::iterator i = Sprites.begin(); i != Sprites.end(); ++i) {
			i->DecreaseAlpha();
		}
		ElapsedFadeOut -= 0.05f;
	}
	if(ElapsedCreator > 0.0005f) {
		New();
		ElapsedCreator -= 0.0005f;
	}
}
void Dust::Erase(std::multiset<Partikel>::iterator& i) {
	std::multiset<Partikel>::iterator m = i;
	++i;
	Sprites.erase(m);
}
Dust::Dust() : ElapsedFadeOut(0), ElapsedCreator(0) {
}

const float Dust::Speed = 7;