#include "Utils.h"
#include <cmath>

sf::Color RandomGrey() {
	sf::Uint8 i = static_cast<sf::Uint8>(sf::Randomizer::Random(80, 180));
	return(sf::Color(i, i, i, static_cast<sf::Uint8>(sf::Randomizer::Random(30, 150))));
}

sf::Vector2f CreateVector(float Angle, float Speed) {
	return(sf::Vector2f(-Speed * std::sin(Angle / BOGENMA�FAKTOR), -Speed * std::cos(Angle / BOGENMA�FAKTOR)));
}

void ChangeImage(sf::Sprite& sprite, const sf::Image& Img, const bool ChangeSize) {
	sprite.SetImage(Img);
	if(ChangeSize) {
		sprite.SetSubRect(sf::IntRect(0, 0, Img.GetWidth(), Img.GetHeight()));
	}
}

Clock::Clock(float RefreshTime) : refresh(RefreshTime), Framerate(0), Frametime(0), SinceLastRefresh(0), Counter(0) {
}
void Clock::Refresh() {
	Frametime = timer.GetElapsedTime();
	timer.Reset();
	SinceLastRefresh += Frametime;
	++Counter;
	if(SinceLastRefresh >= refresh) {
		Framerate = static_cast<float>(Counter)/SinceLastRefresh;
		SinceLastRefresh = 0;
		Counter = 0;
	}
}
const float& Clock::GetFrametime() const {
	return(Frametime);
}
void Clock::Render(sf::RenderTarget& Target) const {
	std::ostringstream os;
	os << Framerate;
	sf::String Str(os.str().substr(0, os.str().find(".")));
	Str.SetSize(15);
	Str.SetColor(sf::Color::Green);
	Str.SetPosition(sf::Vector2f(5, 5));
	Target.Draw(Str);
}

std::ostringstream Converter::os;