#ifndef RACER_AUTO_H
#define RACER_AUTO_H

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include "ParticleSystem.h"

class Auto : public sf::Drawable {
private:
	static sf::Image Img1;
	static sf::Image Img2;
	static const float& t;//In Main.cpp initialisieren.
	static const float m;
	float F;
	float Lenkfaktor;
	float v;
	float Angle;
public:
	sf::Sprite Sp;
	Dust Qualm1, Qualm2;

	// Init
	Auto();
	void Init(bool Gr�n);
	void Reset();
	static void Init();

	//Running
	void Beschleunigen(bool Ja, bool Vorw�rts);
	void Lenken(bool Rechts);
	void Move();

	//Drawing
	void Render(sf::RenderTarget& Target) const;
};

#endif
