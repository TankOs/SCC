#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>
#include <fstream>
#include "Utils.h"
#include "Button.h"
#include "Karte.h"
#include "CheckBox.h"

//Ranking
Ranking<float> Rank;
sf::String Scores[10];

//Sounds
sf::Music Z�ndung, Brumm; bool gebrummt = false;
//State-System
enum STATES {MENU, COUNTER, RENNEN, VERLOREN, HIGHSCORE, ENDE};
STATES Status = MENU;

//Init Time-System
sf::Clock Uhr;
unsigned int Count;
Clock Timer(0.5f);
const float& Auto::t(Timer.GetFrametime());
const float& Dust::Time(Timer.GetFrametime());

//Fenster einrichten
sf::Vector2f Resolution(sf::VideoMode::GetDesktopMode().Width, sf::VideoMode::GetDesktopMode().Height);
sf::RenderWindow RW(sf::VideoMode(Resolution.x, Resolution.y), "Mr. X Racer", sf::Style::Fullscreen);
const sf::Input& IP = RW.GetInput();
sf::Event EV;
sf::View KartenView(sf::FloatRect(-Resolution.x/2, -Resolution.y/2, Resolution.x/2, Resolution.y/2));
sf::View& DefaultView = RW.GetDefaultView();

//Men�2 initialisieren
CheckBoxGroup LilaGr�n;
CheckBox CB0(sf::Vector2f(10, Resolution.y/2 - 15), "Lila (Schnell aber schlechte Lenkung)", &LilaGr�n, 2, 15, false);
CheckBox CB1(sf::Vector2f(10, Resolution.y/2 + 15), "Gr�n (Gute Lenkung aber langsam)", &LilaGr�n);
Button BT_MEnde("Beenden (Esc)", sf::Vector2f(Resolution.x/2-150, 25), sf::Vector2f(Resolution.x/2+150, 100));
Button BT_SEnde("Beenden (Esc)", sf::Vector2f(Resolution.x/2-315, 25), sf::Vector2f(Resolution.x/2-15, 100));
Button BT_Men�("Hauptmen� (M)", sf::Vector2f(Resolution.x/2+15, 25), sf::Vector2f(Resolution.x/2+315, 100));
std::vector<Button> BT_Karten;
sf::Sprite Hintergrund;

//Karte einrichten
Karte Map;

//Autos initialisieren
Auto *Auto = &Map.Lila;

//Strings...
sf::String SCount, SInfo, Zeit;
std::string KartenName;

//Index lesen
void ReadKartenIndex() {
	std::ifstream ifs("Karten/Karten.index");
	std::string buffer;
	int i = 1;
	while(ifs.good()) {
		std::getline(ifs, buffer);
		BT_Karten.push_back(Button(buffer, sf::Vector2f(Resolution.x/2-250, i*100+25), sf::Vector2f(Resolution.x/2+250, i*100+110)));
		++i;
	}
	ifs.close();
}

// Karte �ffnen
void Start(std::string name) {
	KartenName = name;
	if(Map.LoadFile(name)) {
		Z�ndung.Play();
		if(CB0.IsChecked()) {
			Auto = &Map.Lila;
		}
		else {
			Auto = &Map.Gr�n;
		}
		Status = COUNTER;
		Count = 3;
		Uhr.Reset();
	}
}

// Process Men�
void Men�() {
	//Events abfangen
	while(RW.GetEvent(EV)) {
		switch(EV.Type) {
			case sf::Event::Closed:
				Status = ENDE;
				return;
			case sf::Event::KeyPressed:
				if(EV.Key.Code == sf::Key::Escape) {
					Status = ENDE;
					return;
				}
				break;
			case sf::Event::MouseButtonReleased:
				if(EV.MouseButton.Button == sf::Mouse::Left) {
					CB0.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y));
					CB1.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y));
					if(BT_MEnde.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						Status = ENDE;
					}
					for(unsigned int i = 0; i < BT_Karten.size(); ++i) {
						if(BT_Karten[i].IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
							Start(BT_Karten[i].GetText());
						}
					}
				}
				break;
			default:
				break;
		}
	}

	//Zeichnen
	RW.Draw(Hintergrund);
	RW.Draw(CB0);
	RW.Draw(CB1);
	RW.Draw(BT_MEnde);
	for(unsigned int i = 0; i < BT_Karten.size(); ++i) {
		RW.Draw(BT_Karten[i]);
	}
}

// Process Counter
void Counter() {
	//Events abfangen
	while(RW.GetEvent(EV)) {
		switch(EV.Type) {
			case sf::Event::Closed:
				Status = ENDE;
				return;
			case sf::Event::KeyPressed:
				if(EV.Key.Code == sf::Key::M) {
					Status = MENU;
					return;
				}
				if(EV.Key.Code == sf::Key::Escape) {
					Status = ENDE;
					return;
				}
				break;
			case sf::Event::MouseButtonReleased:
				if(EV.MouseButton.Button == sf::Mouse::Left) {
					if(BT_SEnde.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						Status = ENDE;
					}
					if(BT_Men�.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						Status = MENU;
					}
				}
				break;
			default:
				break;
		}
	}
	//Process Timer
	if(Uhr.GetElapsedTime() >= 1) {
		Count--;
		Uhr.Reset();
		if(Count <= 0) {
			Status = RENNEN;
		}
	}

	//Zeichnen
	KartenView.SetCenter(Auto->Sp.TransformToGlobal(Auto->Sp.GetCenter()));
	RW.SetView(KartenView);
	RW.Draw(Map);
	RW.Draw(*Auto);
	RW.SetView(DefaultView);
	RW.Draw(BT_SEnde);
	RW.Draw(BT_Men�);
	SCount.SetText(Converter::ToString(Count));
	SCount.SetPosition(Resolution.x/2 - SCount.GetRect().GetWidth()/2, Resolution.y/2 - SCount.GetRect().GetHeight()/2-75);
	RW.Draw(SInfo);
	RW.Draw(SCount);
}

// Process Rennen
void Rennen() {
	//Events abfangen
	while(RW.GetEvent(EV)) {
		switch(EV.Type) {
			case sf::Event::Closed:
				Status = ENDE;
				return;
			case sf::Event::KeyPressed:
				if(EV.Key.Code == sf::Key::Up) {
					if(!gebrummt) {
						Brumm.Play();
						gebrummt = true;
					}
				}
				if(EV.Key.Code == sf::Key::M) {
					Status = MENU;
					return;
				}
				if(EV.Key.Code == sf::Key::Escape) {
					Status = ENDE;
					return;
				}
				break;
			case sf::Event::KeyReleased:
				if(EV.Key.Code == sf::Key::Up) {
					gebrummt = false;
				}
			case sf::Event::MouseButtonReleased:
				if(EV.MouseButton.Button == sf::Mouse::Left) {
					if(BT_SEnde.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						Status = ENDE;
					}
					if(BT_Men�.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						Status = MENU;
					}
				}
				break;
			default:
				break;
		}
	}

	//Nutzereingaben und Rechnen
	if(IP.IsKeyDown(sf::Key::Right)) {
		Auto->Lenken(true);
	}
	if(IP.IsKeyDown(sf::Key::Left)) {
		Auto->Lenken(false);
	}
	Auto->Beschleunigen(IP.IsKeyDown(sf::Key::Up)||IP.IsKeyDown(sf::Key::Down), IP.IsKeyDown(sf::Key::Up));
	Auto->Move();
	sf::Vector2<bool> Erg = Map.Kollision(*Auto);
	if(Erg.y) { //Ziel
		Status = HIGHSCORE;
		while(Rank.size() > 0) {
			Rank.pop_back();
		}
		Rank.ReadFromFile("Karten/" + KartenName + ".rank");
		Rank.Insert(RankValue<float>(Uhr.GetElapsedTime(), ""));
		while(Rank.size() > 10) {
			Rank.pop_back();
		}
		Rank.SaveToFile("Karten/" + KartenName + ".rank");
	}
	else if(Erg.x) { //Bande
		Status = VERLOREN;
	}

	//Zeichnen
	KartenView.SetCenter(Auto->Sp.TransformToGlobal(Auto->Sp.GetCenter()));
	RW.SetView(KartenView);
	RW.Draw(Map);
	RW.Draw(*Auto);
	RW.SetView(DefaultView);
	RW.Draw(BT_SEnde);
	RW.Draw(BT_Men�);
	Zeit.SetText("Abgelaufene Zeit: " + Converter::ToZeitString(Uhr.GetElapsedTime()));
	Zeit.SetPosition(Resolution.x - Zeit.GetRect().GetWidth() - 5, Resolution.y - Zeit.GetRect().GetHeight() - 5);
	RW.Draw(Zeit);
}

//Verloren
void Verloren() {
	//Events abfangen
	while(RW.GetEvent(EV)) {
		switch(EV.Type) {
			case sf::Event::Closed:
				Status = ENDE;
				return;
			case sf::Event::KeyPressed:
				if(EV.Key.Code == sf::Key::Escape) {
					Status = ENDE;
					return;
				}
				if(EV.Key.Code == sf::Key::M) {
					Status = MENU;
					return;
				}
				break;
			case sf::Event::MouseButtonReleased:
				if(EV.MouseButton.Button == sf::Mouse::Left) {
					if(BT_SEnde.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						Status = ENDE;
					}
					if(BT_Men�.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						Status = MENU;
					}
				}
				break;
			default:
				break;
		}
	}

	//Zeichnen
	sf::String Verl("Verloren!");
	Verl.SetSize(100);
	Verl.SetColor(sf::Color::Red);
	Verl.SetPosition(Resolution.x/2 - Verl.GetRect().GetWidth()/2, Resolution.y/2 - Verl.GetRect().GetHeight()/2);
	RW.Draw(Verl);
	RW.Draw(BT_SEnde);
	RW.Draw(BT_Men�);
}

//Highscore
void Highscore() {
	//Events abfangen
	while(RW.GetEvent(EV)) {
		switch(EV.Type) {
			case sf::Event::Closed:
				Status = ENDE;
				return;
			case sf::Event::KeyPressed:
				if(EV.Key.Code == sf::Key::Escape) {
					Status = ENDE;
					return;
				}
				if(EV.Key.Code == sf::Key::M) {
					Status = MENU;
					return;
				}
				break;
			case sf::Event::MouseButtonReleased:
				if(EV.MouseButton.Button == sf::Mouse::Left) {
					if(BT_SEnde.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						Status = ENDE;
					}
					if(BT_Men�.IsClicked(sf::Vector2i(EV.MouseButton.X, EV.MouseButton.Y))) {
						Status = MENU;
					}
				}
				break;
			default:
				break;
		}
	}

	//Zeichnen
	for(unsigned int i = 0; i < Rank.size(); ++i) {
		Scores[i].SetText(Converter::ToZeitString(Rank[i].Value));
		Scores[i].SetPosition(Resolution.x/2 - Scores[i].GetRect().GetWidth()/2, 200 + 30*i);
		RW.Draw(Scores[i]);
	}
	RW.Draw(BT_SEnde);
	RW.Draw(BT_Men�);
}

//Einsprungpunkt
int main() {
	Rank.SetSortOrder(false);

	//Dateien laden
	Auto::Init();
	Brumm.OpenFromFile("Sound/Brumm.ogg");
	Z�ndung.OpenFromFile("Sound/Zuendung.ogg");

	//Autos einrichten
	Map.Gr�n.Init(true);
	Map.Lila.Init(false);

	//Fenster einrichten
	RW.UseVerticalSync(true);

	//Men� initialisieren
	sf::Image iHintergrund;
	iHintergrund.LoadFromFile("Grafik/Hintergrund.png");
	Hintergrund.SetImage(iHintergrund);
	Hintergrund.SetScale(Resolution.x / iHintergrund.GetWidth(), Resolution.y / iHintergrund.GetHeight());
	ReadKartenIndex();

	//Strings initialisieren
	SInfo.SetText("Bringen Sie das Auto schnell\nund UNBESCH�DIGT ans Ziel!");
	SInfo.SetSize(50);
	SInfo.SetPosition(Resolution.x/2 - SInfo.GetRect().GetWidth()/2, Resolution.y/2 - SInfo.GetRect().GetHeight()/2+150);
	SInfo.SetColor(sf::Color(30,30,30,225));
	SCount.SetSize(300);
	SCount.SetColor(sf::Color(90,80,80,225));
	Zeit.SetSize(30);
	Zeit.SetColor(sf::Color(255,255,255,225));

	//Hauptschleife
	while(Status != ENDE) {
		Timer.Refresh();

		switch(Status) {
			case MENU:
				Men�();
				break;
			case COUNTER:
				Counter();
				break;
			case RENNEN:
				Rennen();
				break;
			case HIGHSCORE:
				Highscore();
				break;
			case VERLOREN:
				Verloren();
				break;
			default:
				break;
		}

		RW.Draw(Timer);
		RW.Display();
		RW.Clear(sf::Color(70, 115, 9));
	}
	return(0);
}